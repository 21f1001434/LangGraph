from __future__ import annotations

"""One-time v6.17 compact semantic graph + extraction validation upgrade.

The migration is loss-preserving at the evidence layer. Historical navigation
placeholder nodes and weak Concept/summary nodes are moved into dedicated evidence
tables before being removed from the semantic graph. Existing sources, chunks,
PDFs, screenshots, facts and crawler frontier rows are preserved.
"""

import argparse
import hashlib
import json
import os
import re
import sqlite3
from collections import defaultdict
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.knowledge_ontology import CANONICAL_NODE_TYPES, CANONICAL_RELATIONSHIP_TYPES
from dell_crawler_core.product_intelligence import is_product_detail_url
from dell_crawler_core.snapshot_extract import canonicalize_url
from repair_v610 import (
    clear_stale_profile_lease,
    count_unexpired_worker_leases,
    inspect_runtime_processes,
    now,
    sqlite_backup,
    stamp,
)


def _loads(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value or ""))
    except Exception:
        return {} if default is None else default


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _token(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def _raw_schema_needs_v615(store: SQLiteKnowledgeGraph) -> bool:
    report = store.canonical_schema_report()
    raw_nodes = set((report.get("raw_node_types") or {}).keys())
    raw_rels = set((report.get("raw_relationship_types") or {}).keys())
    return bool(raw_nodes.difference(CANONICAL_NODE_TYPES) or raw_rels.difference(CANONICAL_RELATIONSHIP_TYPES))


def _preserve_node_as_evidence(store: SQLiteKnowledgeGraph, row: sqlite3.Row, kind: str, reason: str) -> None:
    node_id = int(row["id"])
    with store.connect() as conn:
        facts = [dict(x) for x in conn.execute(
            "SELECT predicate,value,unit,qualifiers_json,source_url,confidence,observed_at FROM facts WHERE subject_id=?",
            (node_id,),
        ).fetchall()]
        edges = [dict(x) for x in conn.execute(
            """
            SELECT e.predicate,e.source_url,e.confidence,
                   sn.node_key AS source_key,tn.node_key AS target_key,e.attributes_json
            FROM edges e JOIN nodes sn ON sn.id=e.source_id JOIN nodes tn ON tn.id=e.target_id
            WHERE e.source_id=? OR e.target_id=?
            """,
            (node_id, node_id),
        ).fetchall()]
    attrs = _loads(row["attributes_json"], {})
    source_url = str(attrs.get("source_url") or "")
    if not source_url and str(row["node_key"]).startswith("url:"):
        source_url = str(row["node_key"])[4:]
    store.record_extraction_evidence(
        source_url or "historical://crawler",
        {
            "node": {
                "node_key": row["node_key"], "node_type": row["node_type"],
                "name": row["name"], "attributes": attrs,
            },
            "facts": facts,
            "edges": edges,
        },
        evidence_kind=kind,
        reason=reason,
    )


def compact_unfetched_navigation_nodes(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    report = {"link_evidence_migrated": 0, "placeholder_nodes_removed": 0, "placeholder_nodes_retained": 0}
    with store.connect() as conn:
        rows = conn.execute(
            """
            SELECT n.* FROM nodes n
            WHERE n.node_key LIKE 'url:%'
              AND NOT EXISTS (
                SELECT 1 FROM sources s
                WHERE ('url:' || s.canonical_url)=n.node_key OR ('url:' || s.url)=n.node_key
              )
            ORDER BY n.id
            """
        ).fetchall()
    for row in rows:
        node_id = int(row["id"])
        node_key = str(row["node_key"] or "")
        target_url = canonicalize_url(node_key[4:]) if node_key.startswith("url:") else ""
        attrs = _loads(row["attributes_json"], {})
        with store.connect() as conn:
            fact_count = int(conn.execute("SELECT COUNT(*) FROM facts WHERE subject_id=?", (node_id,)).fetchone()[0])
            incident = conn.execute(
                "SELECT e.*,sn.node_key source_key,tn.node_key target_key FROM edges e JOIN nodes sn ON sn.id=e.source_id JOIN nodes tn ON tn.id=e.target_id WHERE e.source_id=? OR e.target_id=?",
                (node_id, node_id),
            ).fetchall()
        semantic_edges = [x for x in incident if str(x["predicate"] or "") not in {"LINKS_TO", "HAS_ENDPOINT", "MENTIONS", "DESCRIBES"}]
        product_signal = str(row["node_type"] or "") == "Product" and any(
            attrs.get(k) not in (None, "", [], {}) for k in (
                "order_code", "part_number", "model", "price", "processor", "graphics", "memory", "storage"
            )
        )
        if fact_count or semantic_edges or product_signal or not target_url:
            report["placeholder_nodes_retained"] += 1
            continue

        # Reconstruct every historical navigation edge as durable link evidence.
        migrated_any = False
        for edge in incident:
            if int(edge["target_id"]) != node_id:
                continue
            source_key = str(edge["source_key"] or "")
            source_url = source_key[4:] if source_key.startswith("url:") else str(edge["source_url"] or "")
            if source_url and target_url:
                migrated_any |= store.record_link_evidence(
                    source_url,
                    target_url,
                    label=str(row["name"] or target_url),
                    relation=str(edge["predicate"] or "LINKS_TO"),
                    resource_kind=str(attrs.get("resource_kind") or attrs.get("page_type") or ""),
                )
        discovered_from = str(attrs.get("discovered_from") or attrs.get("source_url") or "")
        if discovered_from and target_url:
            migrated_any |= store.record_link_evidence(
                discovered_from,
                target_url,
                label=str(row["name"] or target_url),
                relation="LINKS_TO",
                resource_kind=str(attrs.get("page_type") or ""),
            )
        report["link_evidence_migrated"] += int(bool(migrated_any))
        _preserve_node_as_evidence(store, row, "historical_navigation_placeholder", "unfetched_link_placeholder_compacted_v616")
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (node_id,))
        report["placeholder_nodes_removed"] += 1
    return report


def compact_evidence_only_nodes(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    report = {"concept_nodes_removed": 0, "summary_section_nodes_removed": 0}
    with store.connect() as conn:
        concept_rows = conn.execute("SELECT * FROM nodes WHERE node_type='Concept' ORDER BY id").fetchall()
        summary_rows = conn.execute(
            "SELECT * FROM nodes WHERE node_type='Section' AND node_key LIKE 'document-summary:%' ORDER BY id"
        ).fetchall()
    for row in concept_rows:
        _preserve_node_as_evidence(store, row, "historical_concept_node", "concept_compacted_to_evidence_v616")
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        report["concept_nodes_removed"] += 1
    for row in summary_rows:
        _preserve_node_as_evidence(store, row, "historical_summary_node", "summary_already_preserved_as_page_fact_and_chunks")
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        report["summary_section_nodes_removed"] += 1
    return report


def _product_identifiers(attrs: dict[str, Any]) -> list[tuple[str, str]]:
    result: list[tuple[str, str]] = []
    order = _token(attrs.get("order_code") or attrs.get("orderCode") or attrs.get("sku"))
    part = _token(attrs.get("part_number") or attrs.get("partNumber") or attrs.get("mpn"))
    raw_url = str(attrs.get("product_url") or attrs.get("url") or "").strip()
    product_url = canonicalize_url(raw_url) if raw_url and is_product_detail_url(raw_url) else ""
    if order:
        result.append(("order", order))
    if part:
        result.append(("part", part))
    if product_url:
        result.append(("url", product_url.casefold()))
    return result


def _merge_attrs(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in incoming.items():
        if value in (None, "", [], {}):
            continue
        if result.get(key) in (None, "", [], {}):
            result[key] = value
        elif isinstance(result.get(key), list) and isinstance(value, list):
            for item in value:
                if item not in result[key]:
                    result[key].append(item)
    return result


def merge_duplicate_products(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    report = {"duplicate_groups": 0, "product_nodes_merged": 0, "facts_moved": 0, "edges_moved": 0, "observations_moved": 0}
    with store.connect() as conn:
        rows = conn.execute("SELECT * FROM nodes WHERE node_type='Product' ORDER BY id").fetchall()
    if not rows:
        return report

    parent = {int(r["id"]): int(r["id"]) for r in rows}
    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    seen: dict[tuple[str, str], int] = {}
    attrs_by_id: dict[int, dict[str, Any]] = {}
    for row in rows:
        rid = int(row["id"])
        attrs = _loads(row["attributes_json"], {})
        attrs_by_id[rid] = attrs
        for ident in _product_identifiers(attrs):
            if ident in seen:
                union(seen[ident], rid)
            else:
                seen[ident] = rid

    groups: dict[int, list[sqlite3.Row]] = defaultdict(list)
    for row in rows:
        groups[find(int(row["id"]))].append(row)

    for members in groups.values():
        if len(members) < 2:
            continue
        report["duplicate_groups"] += 1

        def score(row: sqlite3.Row) -> tuple[int, int, int]:
            attrs = attrs_by_id[int(row["id"])]
            key = str(row["node_key"] or "")
            key_rank = 100 if key.startswith("product-order:") else 90 if key.startswith("product-part:") else 80 if key.startswith("product-url:") else 20
            complete = sum(int(attrs.get(k) not in (None, "", [], {})) for k in (
                "order_code", "part_number", "product_url", "model", "price", "processor", "graphics", "memory", "storage", "display", "operating_system"
            ))
            return key_rank, complete, -int(row["id"])

        canonical = max(members, key=score)
        canonical_id = int(canonical["id"])
        canonical_key = str(canonical["node_key"])
        merged_attrs = dict(attrs_by_id[canonical_id])
        aliases = list(merged_attrs.get("identity_aliases") or []) if isinstance(merged_attrs.get("identity_aliases"), list) else []

        for alias in members:
            alias_id = int(alias["id"])
            if alias_id == canonical_id:
                continue
            alias_key = str(alias["node_key"])
            alias_attrs = attrs_by_id[alias_id]
            merged_attrs = _merge_attrs(merged_attrs, alias_attrs)
            if alias_key not in aliases:
                aliases.append(alias_key)
            with store.connect() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO product_identity_aliases(alias_key,canonical_product_key,reason,observed_at) VALUES(?,?,?,?)",
                    (alias_key, canonical_key, "historical_strong_identity_duplicate_merged_v616", now()),
                )
                facts = conn.execute("SELECT * FROM facts WHERE subject_id=?", (alias_id,)).fetchall()
                for fact in facts:
                    before = conn.total_changes
                    conn.execute(
                        """
                        INSERT OR IGNORE INTO facts(subject_id,predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to)
                        VALUES(?,?,?,?,?,?,?,?,?,?)
                        """,
                        (canonical_id, fact["predicate"], fact["value"], fact["unit"], fact["qualifiers_json"], fact["source_url"], fact["confidence"], fact["observed_at"], fact["valid_from"], fact["valid_to"]),
                    )
                    report["facts_moved"] += int(conn.total_changes > before)

                edges = conn.execute("SELECT * FROM edges WHERE source_id=? OR target_id=?", (alias_id, alias_id)).fetchall()
                for edge in edges:
                    new_source = canonical_id if int(edge["source_id"]) == alias_id else int(edge["source_id"])
                    new_target = canonical_id if int(edge["target_id"]) == alias_id else int(edge["target_id"])
                    if new_source == new_target:
                        continue
                    existing = conn.execute(
                        "SELECT id,attributes_json,confidence FROM edges WHERE source_id=? AND predicate=? AND target_id=? AND source_url=?",
                        (new_source, edge["predicate"], new_target, edge["source_url"]),
                    ).fetchone()
                    if existing:
                        old_attrs = _loads(existing["attributes_json"], {})
                        new_attrs = _loads(edge["attributes_json"], {})
                        old_attrs.update({k: v for k, v in new_attrs.items() if k not in old_attrs})
                        conn.execute(
                            "UPDATE edges SET attributes_json=?,confidence=MAX(confidence,?),last_seen=? WHERE id=?",
                            (_json(old_attrs), float(edge["confidence"] or 0), now(), int(existing["id"])),
                        )
                    else:
                        conn.execute(
                            """
                            INSERT INTO edges(source_id,predicate,target_id,attributes_json,source_url,confidence,first_seen,last_seen)
                            VALUES(?,?,?,?,?,?,?,?)
                            """,
                            (new_source, edge["predicate"], new_target, edge["attributes_json"], edge["source_url"], edge["confidence"], edge["first_seen"], edge["last_seen"]),
                        )
                        report["edges_moved"] += 1

                observations = conn.execute("SELECT * FROM product_observations WHERE product_id=?", (alias_id,)).fetchall()
                for obs in observations:
                    before = conn.total_changes
                    conn.execute(
                        """
                        INSERT OR IGNORE INTO product_observations(
                            product_id,source_url,observed_at,observation_hash,price,list_price,currency,
                            model,order_code,completeness_score,fields_json
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                        """,
                        (canonical_id, obs["source_url"], obs["observed_at"], obs["observation_hash"], obs["price"], obs["list_price"], obs["currency"],
                         obs["model"], obs["order_code"], obs["completeness_score"], obs["fields_json"]),
                    )
                    report["observations_moved"] += int(conn.total_changes > before)
                conn.execute("DELETE FROM product_enrichment_state WHERE product_key=?", (alias_key,))
                conn.execute("DELETE FROM nodes WHERE id=?", (alias_id,))
            report["product_nodes_merged"] += 1

        merged_attrs["identity_aliases"] = aliases
        store.upsert_node(canonical_key, "Product", str(canonical["name"]), merged_attrs)

    return report


def rebuild_node_fts(store: SQLiteKnowledgeGraph) -> None:
    if not store.fts_available:
        return
    with store.connect() as conn:
        try:
            conn.execute("DELETE FROM nodes_fts")
            conn.execute(
                "INSERT INTO nodes_fts(name,node_type,attributes,node_key) SELECT name,node_type,attributes_json,node_key FROM nodes"
            )
        except sqlite3.OperationalError:
            pass


def repair(db: Path, knowledge: Path, *, force_active: bool = False, no_backup: bool = False) -> dict[str, Any]:
    root = Path(__file__).resolve().parent
    runtime_state = inspect_runtime_processes(root)
    lease = clear_stale_profile_lease(root)
    active_leases = count_unexpired_worker_leases(db)
    live_pids = list(runtime_state.get("live_pids") or [])
    if lease.get("status") == "live_owner":
        pid = int(lease.get("owner_pid") or 0)
        if pid and pid not in live_pids:
            live_pids.append(pid)
    if active_leases and live_pids and not force_active:
        raise SystemExit(
            f"Refusing to repair while crawler/browser PID(s) {sorted(set(live_pids))} are alive. Use Graceful Stop first."
        )
    if lease.get("status") == "live_owner" and not force_active:
        raise SystemExit(f"Browser profile is still owned by PID {lease.get('owner_pid')}. Stop it first.")

    backup = ""
    if not no_backup:
        target = db.with_name(f"{db.stem}.pre_v616_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity_before = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity_before.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity_before}")

    reset_in_progress = store.reset_in_progress() if not live_pids else 0
    v615_result: dict[str, Any] = {"skipped": True}
    if _raw_schema_needs_v615(store):
        from repair_v615 import repair as repair_v615
        v615_result = repair_v615(db, knowledge, no_backup=True)
        store = SQLiteKnowledgeGraph(db)

    placeholder = compact_unfetched_navigation_nodes(store)
    evidence_compaction = compact_evidence_only_nodes(store)
    products = merge_duplicate_products(store)
    rebuild_node_fts(store)
    projection = store.backfill_product_projection()
    revisit = store.schedule_product_revisit_sweep(
        min_score=0.85,
        max_attempts=4,
        no_gain_limit=2,
        min_gain=0.02,
        priority=0,
        revisit_missing_price=True,
        revisit_missing_specs=True,
        revisit_unmapped=True,
    )
    quality = store.semantic_quality_report()
    extractor = store.extractor_quality_report()
    schema = store.canonical_schema_report()
    with store.connect() as conn:
        integrity_after = str(conn.execute("PRAGMA integrity_check").fetchone()[0])

    knowledge.mkdir(parents=True, exist_ok=True)
    report = {
        "migration": "v6.x -> v6.17 compact semantic knowledge crawler",
        "database": str(db),
        "backup": backup,
        "runtime_state": runtime_state,
        "profile_lease": lease,
        "unexpired_worker_leases_before_repair": active_leases,
        "reset_in_progress": int(reset_in_progress),
        "integrity_before": integrity_before,
        "integrity_after": integrity_after,
        "v615_canonicalization": v615_result,
        "navigation_compaction": placeholder,
        "evidence_compaction": evidence_compaction,
        "product_deduplication": products,
        "product_projection": projection,
        "product_revisit_priming": revisit,
        "semantic_quality": quality,
        "extractor_quality": extractor,
        "canonical_schema": schema,
        "finished_at": now(),
    }
    path = knowledge / "SEMANTIC_KNOWLEDGE_REPAIR_V617.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade Dell crawler knowledge DB to v6.17 compact validated semantic mapping.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(db, Path(args.knowledge).expanduser().resolve(), force_active=args.force_active, no_backup=args.no_backup)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
