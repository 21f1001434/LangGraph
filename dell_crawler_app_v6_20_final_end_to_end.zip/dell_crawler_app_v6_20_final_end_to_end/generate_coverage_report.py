from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def main() -> int:
    parser = argparse.ArgumentParser(description='Generate a frontier/coverage snapshot from the durable SQLite database.')
    parser.add_argument('--db', default='knowledge/dell_en_uk.db')
    parser.add_argument('--out', default='knowledge/FRONTIER_COVERAGE_REPORT.json')
    args = parser.parse_args()

    db = Path(args.db).resolve()
    out = Path(args.out).resolve()
    store = SQLiteKnowledgeGraph(db)
    stats = store.stats()
    queue = stats.get('queue', {})
    unresolved = {
        key: int(queue.get(key, 0) or 0)
        for key in ('PENDING','IN_PROGRESS','FAILED','DEFERRED','DONE_WITH_HTTP_FALLBACK','DONE_INCOMPLETE','BLOCKED_CONFIGURATION')
        if int(queue.get(key, 0) or 0) > 0
    }
    dynamic = stats.get('dynamic_control_statuses', {}) if isinstance(stats.get('dynamic_control_statuses'), dict) else {}
    terminal_dynamic = {'STABLE_EXHAUSTED','CYCLE_EXHAUSTED','CONTROL_ABSENT','DISABLED','NAVIGATED','DIRECT_ENDPOINT'}
    nonterminal_dynamic = {
        key: int(value or 0) for key, value in dynamic.items()
        if key not in terminal_dynamic and int(value or 0) > 0
    }
    report = {
        'generated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
        'database': str(db),
        'clean_public_frontier_exhaustion': not unresolved and not nonterminal_dynamic,
        'queue': queue,
        'queue_lanes': stats.get('queue_lanes', {}),
        'unresolved_queue': unresolved,
        'dynamic_control_statuses': dynamic,
        'nonterminal_dynamic_controls': nonterminal_dynamic,
        'graph': stats,
        'note': 'Database-derived checkpoint. A running crawler refreshes this report automatically in v6.',
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f'\nCoverage report: {out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
