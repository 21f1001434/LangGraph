from __future__ import annotations

import argparse
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.document_pipeline import (
    normalize_pdf_download_url,
    quarantine_file,
    short_pdf_storage_path,
    validate_pdf_file,
)
from dell_crawler_core.frontier_scheduler import DOCUMENT, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sqlite_backup(source_path: Path, target_path: Path) -> None:
    source = sqlite3.connect(source_path, timeout=120)
    target = sqlite3.connect(target_path, timeout=120)
    try:
        source.execute("PRAGMA busy_timeout=120000")
        source.backup(target)
    finally:
        target.close()
        source.close()


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import psutil

        return bool(psutil.pid_exists(pid) and psutil.Process(pid).is_running())
    except Exception:
        try:
            if os.name == "nt":
                return False
            os.kill(pid, 0)
            return True
        except Exception:
            return False


def repair_profile_lease(root: Path) -> dict[str, Any]:
    profile = root / "browser_profile" / "dell_crawler"
    lease = profile.parent / f".{profile.name}.dell-crawler.lock"
    if not lease.exists():
        return {"lease_path": str(lease), "status": "absent"}
    try:
        payload = json.loads(lease.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    owner_pid = int(payload.get("pid") or 0)
    if pid_alive(owner_pid):
        return {"lease_path": str(lease), "status": "live_owner", "owner_pid": owner_pid}
    lease.unlink(missing_ok=True)
    return {"lease_path": str(lease), "status": "stale_removed", "owner_pid": owner_pid}


def archive_old_logs(knowledge: Path) -> dict[str, str]:
    archived: dict[str, str] = {}
    current_stamp = stamp()
    for name in ("PDF_FAILURES.jsonl", "PDF_TRANSPORT_EVENTS.jsonl"):
        source = knowledge / name
        if not source.is_file() or source.stat().st_size <= 0:
            continue
        target = knowledge / f"{source.stem}_PRE_V67_{current_stamp}{source.suffix}"
        source.replace(target)
        archived[name] = str(target)
    return archived


def quarantine_invalid_documents(knowledge: Path) -> dict[str, Any]:
    documents = knowledge / "documents"
    quarantine = knowledge / "document_quarantine"
    inspected = 0
    moved: list[dict[str, str]] = []
    if not documents.exists():
        return {"documents_directory": str(documents), "inspected": 0, "quarantined": 0, "files": []}
    for path in documents.rglob("*"):
        if not path.is_file() or not (
            path.name.casefold().endswith(".pdf") or path.name.casefold().endswith(".pdf.part")
        ):
            continue
        inspected += 1
        validation = validate_pdf_file(path, parse_structure=not path.name.casefold().endswith(".part"))
        if validation.ok:
            continue
        target = quarantine_file(path, quarantine, validation.reason)
        moved.append({"source": str(path), "quarantine": str(target or ""), "reason": validation.reason})
    return {
        "documents_directory": str(documents),
        "inspected": inspected,
        "quarantined": len(moved),
        "files": moved,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Prepare an existing Dell crawler database/evidence store for v6.7 DOM-href-first, "
            "Playwright browser-context PDF acquisition and duplicate-safe UI fallback."
        )
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="", help="Knowledge directory; defaults to database parent.")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    probe = sqlite3.connect(db, timeout=30)
    try:
        columns = {str(row[1]) for row in probe.execute("PRAGMA table_info(crawl_queue)").fetchall()}
        active_leases = 0
        if {"status", "lease_expires_at"}.issubset(columns):
            active_leases = int(
                probe.execute(
                    """
                    SELECT COUNT(*) FROM crawl_queue
                     WHERE status='IN_PROGRESS'
                       AND lease_expires_at<>''
                       AND lease_expires_at>?
                    """,
                    (now(),),
                ).fetchone()[0]
                or 0
            )
    finally:
        probe.close()
    if active_leases and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while {active_leases} unexpired worker lease(s) exist. "
            "Use Graceful Stop and wait for supervisor/worker to exit."
        )

    backup = ""
    existing_backups = sorted(db.parent.glob(f"{db.stem}.pre_v67_*{db.suffix}"))
    if not args.no_backup and (args.force_backup or not existing_backups):
        target = db.with_name(f"{db.stem}.pre_v67_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)
    elif existing_backups:
        backup = str(existing_backups[-1])

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset = store.reset_in_progress()
    invalid_files = quarantine_invalid_documents(knowledge)
    archived_logs = archive_old_logs(knowledge)
    profile_lease = repair_profile_lease(root)
    if profile_lease.get("status") == "live_owner" and not args.force_active:
        raise SystemExit(
            f"Persistent browser profile is still owned by PID {profile_lease.get('owner_pid')}. "
            "Stop the old worker/browser before repair."
        )

    ts = now()
    with store.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        reclassified = conn.execute(
            """
            UPDATE crawl_queue
               SET resource_class=?, lane_priority=?, updated_at=?
             WHERE (
                    lower(substr(url,1,instr(url||'?', '?')-1)) LIKE '%.pdf'
                    OR lower(url) LIKE '%.pdf.external%'
                   )
               AND resource_class<>?
            """,
            (DOCUMENT, lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount
        requeued = conn.execute(
            """
            UPDATE crawl_queue
               SET status='PENDING', priority=0, lane_priority=?, attempts=0,
                   lease_owner='', lease_expires_at='', not_before='',
                   last_error='Requeued by v6.7 browser-context exhaustive PDF acquisition',
                   updated_at=?
             WHERE resource_class=? AND status<>'SKIPPED_PERMANENT'
            """,
            (lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount
        stale_runs = conn.execute(
            "UPDATE crawl_runs SET status='INTERRUPTED', finished_at=? WHERE status='RUNNING'",
            (ts,),
        ).rowcount
        rows = conn.execute(
            "SELECT url,status,attempts,parent_url,relation FROM crawl_queue WHERE resource_class=? ORDER BY priority,url",
            (DOCUMENT,),
        ).fetchall()
        conn.commit()

    resolver = object.__new__(DellEnUkKnowledgeCrawler)
    resolver.store = store
    context_urls: list[str] = []
    descriptors: list[dict[str, str]] = []
    for row in rows:
        item = dict(row)
        descriptor = resolver._document_click_descriptor(item)
        if not descriptor:
            continue
        url = str(item.get("url") or "")
        context_urls.append(url)
        descriptors.append(
            {
                "url": url,
                "parent_url": str(item.get("parent_url") or ""),
                "label": str(descriptor.get("label") or ""),
                "href": str(descriptor.get("href") or ""),
                "source": str(descriptor.get("source") or ""),
            }
        )
    if context_urls:
        with store.connect() as conn:
            conn.executemany(
                "UPDATE crawl_queue SET relation='CONTROL_BROWSER_CONTEXT_DOCUMENT', updated_at=? WHERE url=?",
                [(ts, url) for url in context_urls],
            )

    aliases: list[dict[str, str]] = []
    paths: list[dict[str, Any]] = []
    for row in rows:
        queue_url = str(row["url"])
        download_url = normalize_pdf_download_url(queue_url)
        path = short_pdf_storage_path(knowledge / "documents", download_url)
        if queue_url != download_url:
            aliases.append({"queue_url": queue_url, "download_url": download_url})
        paths.append(
            {
                "queue_url": queue_url,
                "download_url": download_url,
                "local_path": str(path),
                "partial_path": str(path.with_suffix(path.suffix + ".part")),
                "partial_path_length": len(str(path.with_suffix(path.suffix + ".part"))),
            }
        )

    report = {
        "migration": "v6.6 -> v6.7",
        "database": str(db),
        "knowledge": str(knowledge),
        "sqlite_integrity": integrity,
        "backup": backup,
        "active_leases_before_repair": active_leases,
        "reset_in_progress": int(reset),
        "pdf_rows_reclassified_as_document": int(reclassified or 0),
        "documents_requeued": int(requeued or 0),
        "documents_marked_browser_context": len(context_urls),
        "browser_context_descriptors": descriptors,
        "stale_runs_closed": int(stale_runs or 0),
        "archived_pre_v67_logs": archived_logs,
        "profile_lease": profile_lease,
        "pdf_external_aliases": aliases,
        "short_path_projection": paths,
        "invalid_local_documents": invalid_files,
        "v67_transport_policy": {
            "standalone_httpx_pdf_enabled": False,
            "dom_href_first": True,
            "playwright_browser_context_request_first": True,
            "unique_visible_ui_click_fallback": True,
            "browser_viewer_text_and_screenshots": True,
            "canonical_consistency_validation": True,
        },
        "stats": store.stats(),
        "logs": {
            "recoverable_transport_events": str(knowledge / "PDF_TRANSPORT_EVENTS.jsonl"),
            "browser_recoveries": str(knowledge / "PDF_RECOVERIES.jsonl"),
            "completed_documents": str(knowledge / "PDF_SUCCESSES.jsonl"),
            "terminal_failures_only": str(knowledge / "PDF_FAILURES.jsonl"),
        },
    }
    out = knowledge / "V67_REPAIR_REPORT.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
