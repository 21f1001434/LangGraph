from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import psutil
from dotenv import load_dotenv

from dell_crawler_core.env_config import apply_compatibility_aliases
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

ROOT = Path(__file__).resolve().parent
RUNTIME_DIR = ROOT / "runtime"
STATUS_FILE = RUNTIME_DIR / "status.json"
EVENTS_FILE = RUNTIME_DIR / "events.jsonl"
COMMAND_FILE = RUNTIME_DIR / "command.json"
SERVICE_PID_FILE = RUNTIME_DIR / "crawler.pid"
WORKER_PID_FILE = RUNTIME_DIR / "worker.pid"
HEARTBEAT_FILE = RUNTIME_DIR / "heartbeat.json"
RESULT_FILE = RUNTIME_DIR / "last_result.json"
SUPERVISOR_STATE_FILE = RUNTIME_DIR / "supervisor.json"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    temp.replace(path)


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def append_event(payload: dict[str, Any]) -> None:
    EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with EVENTS_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")


def read_command() -> str:
    return str(read_json(COMMAND_FILE, {}).get("command") or "").strip().lower()


def heartbeat_age_seconds() -> float | None:
    payload = read_json(HEARTBEAT_FILE, {})
    stamp = str(payload.get("timestamp") or "")
    if not stamp:
        return None
    try:
        observed = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        return max(0.0, (datetime.now(timezone.utc) - observed.astimezone(timezone.utc)).total_seconds())
    except Exception:
        return None


def terminate_tree(process: subprocess.Popen[Any], timeout: float = 15.0) -> None:
    try:
        parent = psutil.Process(process.pid)
    except psutil.Error:
        return
    children = parent.children(recursive=True)
    for child in reversed(children):
        try:
            child.terminate()
        except psutil.Error:
            pass
    try:
        parent.terminate()
    except psutil.Error:
        pass
    _, alive = psutil.wait_procs([*children, parent], timeout=timeout)
    for item in alive:
        try:
            item.kill()
        except psutil.Error:
            pass


def database_from_config(raw: dict[str, Any]) -> Path:
    path = Path(raw.get("db_path") or "knowledge/dell_en_uk.db")
    return path if path.is_absolute() else ROOT / path


def frontier_is_clean(result: dict[str, Any]) -> bool:
    report = result.get("frontier_report") if isinstance(result.get("frontier_report"), dict) else {}
    return bool(report.get("clean_public_frontier_exhaustion"))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Crash/hang-resilient supervisor for the Dell crawler")
    parser.add_argument("--config", required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_path = Path(args.config).resolve()
    raw = read_json(config_path, {})
    if not isinstance(raw, dict) or not raw:
        raise RuntimeError(f"Invalid crawler configuration: {config_path}")

    load_dotenv(ROOT / ".env")
    apply_compatibility_aliases()
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    SERVICE_PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    write_json_atomic(COMMAND_FILE, {"command": "run", "updated_at": now_iso()})

    continuous = bool(raw.get("continuous_until_frontier_clean", True))
    stale_seconds = max(90, int(raw.get("supervisor_stale_seconds", 420)))
    startup_grace = max(60, int(raw.get("supervisor_startup_grace_seconds", 240)))
    poll_seconds = max(2.0, float(raw.get("supervisor_poll_seconds", 5.0)))
    max_restarts = max(0, int(raw.get("supervisor_max_restarts", 0)))
    base_backoff = max(1.0, float(raw.get("supervisor_restart_backoff_seconds", 10.0)))
    max_backoff = max(base_backoff, float(raw.get("supervisor_max_backoff_seconds", 300.0)))

    store = SQLiteKnowledgeGraph(database_from_config(raw))
    stop_requested = False
    active: subprocess.Popen[Any] | None = None

    def request_stop(signum: int, _frame: object) -> None:
        nonlocal stop_requested
        stop_requested = True
        write_json_atomic(COMMAND_FILE, {"command": "stop", "signal": signum, "updated_at": now_iso()})

    signal.signal(signal.SIGINT, request_stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, request_stop)

    restart_count = 0
    cycle = 0
    final_result: dict[str, Any] = {}

    try:
        while not stop_requested and read_command() not in {"stop", "pause"}:
            cycle += 1
            recovered = store.reset_expired_in_progress()
            worker_command = [sys.executable, str(ROOT / "crawler_worker.py"), "--config", str(config_path)]
            kwargs: dict[str, Any] = {
                "cwd": str(ROOT),
                "stdin": subprocess.DEVNULL,
            }
            if os.name == "nt":
                kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            else:
                kwargs["start_new_session"] = True
            result_mtime_before = RESULT_FILE.stat().st_mtime if RESULT_FILE.exists() else 0.0
            active = subprocess.Popen(worker_command, **kwargs)
            WORKER_PID_FILE.write_text(str(active.pid), encoding="utf-8")
            started_monotonic = time.monotonic()
            event = {
                "event": "supervisor_worker_started",
                "timestamp": now_iso(),
                "supervisor_pid": os.getpid(),
                "worker_pid": active.pid,
                "cycle": cycle,
                "restart_count": restart_count,
                "expired_leases_recovered": recovered,
            }
            write_json_atomic(SUPERVISOR_STATE_FILE, event)
            write_json_atomic(STATUS_FILE, event)
            append_event(event)

            stale_kill = False
            while active.poll() is None:
                if stop_requested or read_command() in {"stop", "pause"}:
                    stop_requested = True
                    # Give the worker time to observe command.json, finish its
                    # current atomic operation and close MCP cleanly. Force-kill
                    # only when the grace window expires.
                    graceful_deadline = time.monotonic() + 45.0
                    while active.poll() is None and time.monotonic() < graceful_deadline:
                        time.sleep(0.5)
                    if active.poll() is None:
                        terminate_tree(active)
                    break
                age = heartbeat_age_seconds()
                elapsed = time.monotonic() - started_monotonic
                if elapsed > startup_grace and (age is None or age > stale_seconds):
                    stale_kill = True
                    append_event({
                        "event": "supervisor_stale_worker_detected",
                        "timestamp": now_iso(),
                        "supervisor_pid": os.getpid(),
                        "worker_pid": active.pid,
                        "heartbeat_age_seconds": age,
                        "cycle": cycle,
                    })
                    terminate_tree(active)
                    break
                time.sleep(poll_seconds)

            exit_code = active.poll()
            if exit_code is None:
                try:
                    exit_code = active.wait(timeout=5)
                except Exception:
                    exit_code = -9
            WORKER_PID_FILE.unlink(missing_ok=True)
            result_is_fresh = bool(
                RESULT_FILE.exists() and RESULT_FILE.stat().st_mtime > result_mtime_before
            )
            final_result = read_json(RESULT_FILE, {}) if result_is_fresh else {}
            clean = bool(result_is_fresh and frontier_is_clean(final_result))

            cycle_event = {
                "event": "supervisor_worker_finished",
                "timestamp": now_iso(),
                "supervisor_pid": os.getpid(),
                "worker_pid": active.pid,
                "cycle": cycle,
                "exit_code": exit_code,
                "stale_kill": stale_kill,
                "frontier_clean": clean,
                "result_status": final_result.get("status", ""),
                "queue": store.queue_counts(),
            }
            write_json_atomic(SUPERVISOR_STATE_FILE, cycle_event)
            append_event(cycle_event)

            if stop_requested or read_command() in {"stop", "pause"}:
                break
            if str(final_result.get("status") or "") == "BLOCKED_CONFIGURATION":
                blocked = {
                    **cycle_event,
                    "event": "supervisor_configuration_blocked",
                    "worker_alive": False,
                    "remediation": (
                        "Install/select a Playwright MCP browser, then use Start / Resume. "
                        r"Windows helper: .\install_mcp_browser.ps1"
                    ),
                }
                write_json_atomic(STATUS_FILE, blocked)
                append_event(blocked)
                return 3
            if clean:
                final_event = {**cycle_event, "event": "supervisor_frontier_complete", "worker_alive": False}
                write_json_atomic(STATUS_FILE, final_event)
                append_event(final_event)
                return 0
            if not continuous:
                write_json_atomic(STATUS_FILE, {**cycle_event, "event": "supervisor_cycle_complete"})
                return int(exit_code or 0)

            restart_count += 1
            if max_restarts > 0 and restart_count > max_restarts:
                failure = {
                    **cycle_event,
                    "event": "supervisor_restart_budget_reached",
                    "worker_alive": False,
                }
                write_json_atomic(STATUS_FILE, failure)
                append_event(failure)
                return 2

            delay = min(max_backoff, base_backoff * (2 ** min(restart_count - 1, 6)))
            retry_event = {
                **cycle_event,
                "event": "supervisor_restarting",
                "restart_in_seconds": delay,
                "restart_count": restart_count,
            }
            write_json_atomic(STATUS_FILE, retry_event)
            append_event(retry_event)
            deadline = time.monotonic() + delay
            while time.monotonic() < deadline:
                if stop_requested or read_command() in {"stop", "pause"}:
                    stop_requested = True
                    break
                time.sleep(min(1.0, max(0.0, deadline - time.monotonic())))

        stopped = {
            "event": "supervisor_stopped",
            "timestamp": now_iso(),
            "supervisor_pid": os.getpid(),
            "worker_alive": False,
            "cycle": cycle,
            "queue": store.queue_counts(),
        }
        write_json_atomic(STATUS_FILE, stopped)
        append_event(stopped)
        return 0
    except Exception as exc:
        if active is not None and active.poll() is None:
            terminate_tree(active)
        failure = {
            "event": "supervisor_failed",
            "timestamp": now_iso(),
            "supervisor_pid": os.getpid(),
            "worker_alive": False,
            "error": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc(),
        }
        write_json_atomic(STATUS_FILE, failure)
        append_event(failure)
        return 1
    finally:
        WORKER_PID_FILE.unlink(missing_ok=True)
        SERVICE_PID_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    sys.exit(main())
