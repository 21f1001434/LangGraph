@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

%PYTHON% .\repair_v612.py --db knowledge\dell_en_uk.db --knowledge knowledge
if errorlevel 1 exit /b %errorlevel%

echo v6.12 repair completed. Starting Streamlit...
%PYTHON% -m streamlit run .\app.py
