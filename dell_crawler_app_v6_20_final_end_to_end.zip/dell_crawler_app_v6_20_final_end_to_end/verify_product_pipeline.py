from __future__ import annotations

import argparse
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _truthy_sql(field: str) -> str:
    return f"{field} IS NOT NULL AND TRIM(CAST({field} AS TEXT))<>''"


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify Dell product price/spec extraction and normalized projection.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--require-progress", action="store_true")
    parser.add_argument("--minimum-price-coverage", type=float, default=0.0)
    parser.add_argument("--minimum-spec-coverage", type=float, default=0.0)
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db, timeout=120)
    conn.row_factory = sqlite3.Row
    try:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        views = {str(row[0]) for row in conn.execute("SELECT name FROM sqlite_master WHERE type='view'").fetchall()}
        if "product_catalog_view" not in views:
            raise SystemExit("product_catalog_view is missing. Run repair_v610.py first.")
        total = int(conn.execute("SELECT COUNT(*) FROM product_catalog_view").fetchone()[0] or 0)
        with_price = int(conn.execute(f"SELECT COUNT(*) FROM product_catalog_view WHERE {_truthy_sql('price')}").fetchone()[0] or 0)
        with_list_price = int(conn.execute(f"SELECT COUNT(*) FROM product_catalog_view WHERE {_truthy_sql('list_price')}").fetchone()[0] or 0)
        with_model = int(conn.execute(f"SELECT COUNT(*) FROM product_catalog_view WHERE {_truthy_sql('model')}").fetchone()[0] or 0)
        with_order_code = int(conn.execute(f"SELECT COUNT(*) FROM product_catalog_view WHERE {_truthy_sql('order_code')}").fetchone()[0] or 0)
        spec_condition = " OR ".join(_truthy_sql(field) for field in ("processor", "graphics", "memory", "storage", "display", "operating_system"))
        with_specs = int(conn.execute(f"SELECT COUNT(*) FROM product_catalog_view WHERE {spec_condition}").fetchone()[0] or 0)
        complete = int(conn.execute("SELECT COUNT(*) FROM product_catalog_view WHERE COALESCE(completeness_score,0)>=0.85").fetchone()[0] or 0)
        observations = int(conn.execute("SELECT COUNT(*) FROM product_observations").fetchone()[0] or 0)
        product_sources = int(conn.execute("SELECT COUNT(*) FROM sources WHERE page_type='Product'").fetchone()[0] or 0)
        catalog_sources = int(conn.execute("SELECT COUNT(*) FROM sources WHERE page_type IN ('ProductCatalog','OfferCatalog')").fetchone()[0] or 0)
        queue = {
            str(row["status"]): int(row["count"])
            for row in conn.execute(
                """
                SELECT status,COUNT(*) AS count FROM crawl_queue
                WHERE lower(url) LIKE '%/spd/%' OR relation='HAS_PRODUCT_DETAIL'
                GROUP BY status
                """
            ).fetchall()
        }
        samples = [dict(row) for row in conn.execute(
            """
            SELECT product_id,product_name,family,price,list_price,currency,order_code,model,
                   processor,graphics,memory,storage,display,operating_system,rating,review_count,
                   completeness_score,product_url,source_url
            FROM product_catalog_view
            WHERE price IS NOT NULL OR processor IS NOT NULL OR graphics IS NOT NULL
            ORDER BY COALESCE(completeness_score,0) DESC,last_seen DESC
            LIMIT 30
            """
        ).fetchall()]
    finally:
        conn.close()

    price_coverage = round(100.0 * with_price / total, 2) if total else 0.0
    spec_coverage = round(100.0 * with_specs / total, 2) if total else 0.0
    complete_coverage = round(100.0 * complete / total, 2) if total else 0.0
    product_working = bool(total and with_price and with_specs and observations)
    report: dict[str, Any] = {
        "generated_at": now(), "database": str(db), "sqlite_integrity": integrity,
        "products": total, "products_with_price": with_price, "products_with_list_price": with_list_price,
        "products_with_model": with_model, "products_with_order_code": with_order_code,
        "products_with_core_specs": with_specs, "products_complete_85_percent": complete,
        "price_coverage_percent": price_coverage, "spec_coverage_percent": spec_coverage,
        "complete_coverage_percent": complete_coverage, "product_observations": observations,
        "product_sources": product_sources, "catalog_sources": catalog_sources,
        "product_detail_queue": queue, "product_pipeline_working": product_working,
        "requirements": {
            "progress": not args.require_progress or product_working,
            "minimum_price_coverage": price_coverage >= float(args.minimum_price_coverage),
            "minimum_spec_coverage": spec_coverage >= float(args.minimum_spec_coverage),
        },
        "sample_products": samples,
    }
    report["passed"] = integrity.casefold() == "ok" and all(report["requirements"].values())
    output = knowledge / "PRODUCT_PIPELINE_STATUS.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nProduct pipeline status: {output}")
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
