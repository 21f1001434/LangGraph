# v6.13 Full Dell Knowledge + Anti-Repeat Crawl

v6.13 addresses two separate goals: **stop repeatedly extracting the same evidence** and **expand the knowledge graph into authenticated read-only My Account content using the existing Dell SSO session**.

## Anti-repeat behavior

- Every frontier URL is canonicalized at the SQLite queue boundary, including removal of Dell/advertising tracking parameters.
- Exact rendered-content hashes are compared across source URLs. Alias pages remain auditable and retain their outgoing links, but the expensive Dell AIA/vision extraction is skipped when the same evidence has already been extracted.
- `DONE_INCOMPLETE` and HTTP-fallback pages are no longer blindly requeued on every restart. They remain visible as partial terminal evidence.
- Product revisits are separate and intentional: a product is revisited only when its canonical record still lacks an exact product URL, price, applicable specifications, or contains unresolved unmapped evidence. Attempts/no-gain sweeps remain bounded.
- `repair_v613.py` compacts historical tracking aliases and restores already-stored v6.12 rows from accidental PENDING states without deleting evidence.

## Authenticated Dell knowledge

The crawler reuses the persistent Playwright MCP profile. When My Account is not already authenticated it performs the deterministic handoff used by the supplied AgentQ code:

1. Open the Dell My Account probe page.
2. Enter only the configured email address.
3. Click the visible **Login / Continue / Sign In** control.
4. When Dell reports that SSO is available/enabled, click the visible handoff control again.
5. Reuse enterprise SSO/persistent-session authentication. The crawler never enters a password, OTP, security code, or payment data.

After sign-in it opens the live profile/account menu and discovers read-only destinations. Safe fallbacks include My Account overview, orders, profile settings, saved items, My Products/devices, and Dell Rewards. Payment/checkout/mutation routes and URLs carrying auth-secret parameters are blocked.

## Scope

The public crawler remains exhaustive for its configured Dell UK scope through robots/sitemaps, recursive links, product/catalog pages, support/KB/manuals/drivers, community, blogs, customer stories, enterprise solutions/resources, company/about/legal pages, PDFs/documents, visual assets, and safe read-only dynamic controls. Authenticated account pages are added to that graph when SSO is available.

This means **all discoverable in-scope evidence the crawler can lawfully and technically reach**, not hidden server-side data, inaccessible entitlements, CAPTCHA-protected material, private content outside the signed-in account, or unpublished values.

## Existing database upgrade

Gracefully stop the crawler, pause OneDrive sync for the active SQLite folder, and run:

```powershell
python .\repair_v613.py --db knowledge\dell_en_uk.db --knowledge knowledge
python -m streamlit run .\app.py
```

Or run `upgrade_v613.ps1`.
