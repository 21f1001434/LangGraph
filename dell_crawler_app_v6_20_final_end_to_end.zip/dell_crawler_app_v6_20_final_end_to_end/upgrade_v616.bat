@echo off
setlocal
set DB=knowledge\dell_en_uk.db
set KNOWLEDGE=knowledge
if not "%~1"=="" set DB=%~1
if not "%~2"=="" set KNOWLEDGE=%~2
echo Dell Crawler v6.16 upgrade - use Graceful Stop first.
python .\repair_v616.py --db "%DB%" --knowledge "%KNOWLEDGE%"
if errorlevel 1 exit /b %errorlevel%
python .\audit_knowledge_v616.py --db "%DB%" --require-clean
if errorlevel 1 exit /b %errorlevel%
python -m streamlit run .\app.py
