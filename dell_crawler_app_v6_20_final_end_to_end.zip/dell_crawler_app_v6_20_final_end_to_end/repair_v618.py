from __future__ import annotations

"""v6.18 semantic consolidation migration.

This upgrade preserves raw evidence/chunks/source pages while enforcing a classified,
deduplicated semantic graph.  It builds on the v6.17 repair, then classifies every
remaining graph node, moves ambiguous/schema-only nodes to evidence, and rewires
stable semantic duplicates to one canonical node.
"""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph, _loads, _json
from dell_crawler_core.semantic_consolidation import classify_and_consolidate
from repair_v610 import now, sqlite_backup, stamp
from repair_v617 import repair as repair_v617, _preserve_node_as_evidence, merge_duplicate_products, rebuild_node_fts


def _stamp_product_classification(store: SQLiteKnowledgeGraph) -> int:
    updated = 0
    with store.connect() as conn:
        rows = conn.execute("SELECT id,attributes_json FROM nodes WHERE node_type='Product'").fetchall()
        for row in rows:
            attrs = _loads(row["attributes_json"], {})
            desired = {
                "canonical_class": "Product",
                "classification_confidence": 1.0,
                "classification_reason": "product_identity_resolver",
                "classification_version": "v6.18",
            }
            changed = False
            for key, value in desired.items():
                if attrs.get(key) != value:
                    attrs[key] = value
                    changed = True
            if changed:
                conn.execute("UPDATE nodes SET attributes_json=? WHERE id=?", (_json(attrs), int(row["id"])))
                updated += 1
    return updated


def repair(db: Path, knowledge: Path, *, force_active: bool = False, no_backup: bool = False) -> dict[str, Any]:
    backup = ""
    if not no_backup:
        target = db.with_name(f"{db.stem}.pre_v618_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    # Run all v6.17 safety/migration work without producing another top-level backup.
    v617 = repair_v617(db, knowledge, force_active=force_active, no_backup=True)
    store = SQLiteKnowledgeGraph(db)

    with store.connect() as conn:
        integrity_before = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity_before.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed before v6.18 consolidation: {integrity_before}")

    product_dedup = merge_duplicate_products(store)
    products_classified = _stamp_product_classification(store)

    def preserve(row, kind: str, reason: str) -> None:
        _preserve_node_as_evidence(store, row, kind, reason)

    semantic = classify_and_consolidate(store, preserve_as_evidence=preserve)
    rebuild_node_fts(store)

    # Product aliases may become clearer after semantic edge rewiring; run once more
    # to make the final graph convergence deterministic and idempotent.
    product_dedup_final = merge_duplicate_products(store)
    _stamp_product_classification(store)
    rebuild_node_fts(store)

    projection = store.backfill_product_projection()
    revisit = store.schedule_product_revisit_sweep(
        min_score=0.85,
        max_attempts=4,
        no_gain_limit=2,
        min_gain=0.02,
        priority=0,
        revisit_missing_price=True,
        revisit_missing_specs=True,
        revisit_unmapped=True,
    )
    quality = store.semantic_quality_report()
    extractor = store.extractor_quality_report()
    schema = store.canonical_schema_report()
    with store.connect() as conn:
        integrity_after = str(conn.execute("PRAGMA integrity_check").fetchone()[0])

    knowledge.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "migration": "v6.x -> v6.18 classified + consolidated semantic crawler",
        "database": str(db),
        "backup": backup,
        "integrity_before": integrity_before,
        "integrity_after": integrity_after,
        "v617_base_repair": v617,
        "product_deduplication_pre": product_dedup,
        "products_classification_stamped": products_classified,
        "semantic_classification_and_consolidation": semantic,
        "product_deduplication_final": product_dedup_final,
        "product_projection": projection,
        "product_revisit_priming": revisit,
        "semantic_quality": quality,
        "extractor_quality": extractor,
        "canonical_schema": schema,
        "finished_at": now(),
    }
    path = knowledge / "SEMANTIC_KNOWLEDGE_REPAIR_V618.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade Dell crawler DB to v6.18 classified, deduplicated semantic mapping.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(db, Path(args.knowledge).expanduser().resolve(), force_active=args.force_active, no_backup=args.no_backup)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
