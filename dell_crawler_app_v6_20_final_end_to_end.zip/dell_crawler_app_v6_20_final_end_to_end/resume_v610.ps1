$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Virtual environment not found. Running setup first..."
    & .\setup.ps1
}

$python = ".\.venv\Scripts\python.exe"
& $python repair_v610.py --db knowledge\dell_en_uk.db --knowledge knowledge
& $python verify_product_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge
& $python verify_pdf_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge --require-no-raw-pdf-http --require-no-terminal-validation
& $python -m streamlit run app.py
