# Dell Crawler v6.11 — Extractor Quality Repair

This upgrade fixes the Product-node contamination and enrichment gaps visible in the extractor-quality audit.

## What changed

- Image/static-media URLs can no longer become Product node identities.
- Contaminated Product nodes are preserved as `VisualAsset` provenance records instead of being deleted.
- If the contaminated record contains a real order code, part number, model, price or specifications, v6.11 recovers a canonical Product node and copies its provenance.
- Dell SPD, APD, product-detail and configuration URLs are recognized as product-detail URLs.
- Catalogue cards prefer the real product-detail link over image/CDN links.
- Product-detail pages get a deterministic page-level extraction fallback so price, CPU, GPU, memory, storage, display and OS evidence can still bind to the Product when no catalogue card exists.
- Stored Product/ProductCatalog evidence is replayed once during repair; successful historical evidence is not deleted.
- Incomplete products that already have an exact Dell detail URL are requeued at high priority for enrichment.
- Streamlit Data view now shows media contamination, exact Dell URL coverage, retail-ready products and field coverage.

## One-time upgrade sequence

1. Use **Graceful Stop** in Streamlit and wait until the worker PID disappears.
2. Run:

```powershell
python .\repair_v611.py --db knowledge\dell_en_uk.db --knowledge knowledge
```

3. Review:
   - `knowledge\V611_EXTRACTOR_REPAIR_REPORT.json`
   - `knowledge\EXTRACTOR_QUALITY_REPORT_V611.json`
4. Start the UI:

```powershell
python -m streamlit run .\app.py
```

5. Click **Start / Resume**. The requeued exact product-detail URLs are processed first.

The repair creates a timestamped SQLite backup before changing the database unless `--no-backup` is explicitly supplied.
