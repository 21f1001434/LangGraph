@echo off
setlocal
cd /d "%~dp0"
set DB=knowledge\dell_en_uk.db
set KNOWLEDGE=knowledge
if not "%~1"=="" set DB=%~1
if not "%~2"=="" set KNOWLEDGE=%~2
set PY=.venv\Scripts\python.exe
if not exist "%PY%" set PY=python

echo Dell Crawler v6.17 final verified upgrade - use Graceful Stop first.
echo If this folder is under OneDrive, pause sync while SQLite is active.
"%PY%" .\repair_v617.py --db "%DB%" --knowledge "%KNOWLEDGE%"
if errorlevel 1 exit /b %errorlevel%
"%PY%" .\audit_knowledge_v617.py --db "%DB%" --require-clean
if errorlevel 1 exit /b %errorlevel%
"%PY%" .\release_verify_v617.py --db "%DB%"
if errorlevel 1 exit /b %errorlevel%
"%PY%" -m streamlit run .\app.py
