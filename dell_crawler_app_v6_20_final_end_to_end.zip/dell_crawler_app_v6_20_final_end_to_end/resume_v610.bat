@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe call setup.bat || exit /b 1
set PY=.venv\Scripts\python.exe
%PY% repair_v610.py --db knowledge\dell_en_uk.db --knowledge knowledge || exit /b 1
%PY% verify_product_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge || exit /b 1
%PY% verify_pdf_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge --require-no-raw-pdf-http --require-no-terminal-validation || exit /b 1
%PY% -m streamlit run app.py
