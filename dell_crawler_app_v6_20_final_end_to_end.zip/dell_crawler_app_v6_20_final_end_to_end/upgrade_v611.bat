@echo off
python .\repair_v611.py --db knowledge\dell_en_uk.db --knowledge knowledge
if errorlevel 1 exit /b %errorlevel%
echo v6.11 extractor-quality repair completed. Starting Streamlit...
python -m streamlit run .\app.py
