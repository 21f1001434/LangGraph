from __future__ import annotations

"""One-time v6.15 canonical knowledge repair for an existing crawler SQLite DB.

The repair is deliberately loss-preserving: it does not delete source pages, chunks,
facts or evidence. It bounds historical node/relationship types, quarantines clearly
non-semantic placeholders, merges edge collisions created by type canonicalisation,
and refreshes Product projections. A SQLite backup is created first.
"""

import argparse
import json
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.knowledge_ontology import canonical_node_type, canonical_relationship_type
from dell_crawler_core.product_intelligence import is_media_asset_url, is_product_detail_url, valid_product_name


def _loads(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(str(value or "{}"))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _page_context(attrs: dict[str, Any], node_key: str) -> bool:
    return bool(
        attrs.get("content_hash")
        or attrs.get("page_type")
        or attrs.get("discovered_from")
        or (node_key.startswith("url:") and not attrs.get("order_code") and not attrs.get("part_number"))
    )


def _repair_product_type(raw_type: str, name: str, attrs: dict[str, Any], node_key: str) -> tuple[str, str]:
    if raw_type != "Product":
        return raw_type, ""
    url = str(attrs.get("product_url") or attrs.get("url") or "")
    strong = bool(
        attrs.get("order_code")
        or attrs.get("part_number")
        or attrs.get("model")
        or is_product_detail_url(url)
        or any(attrs.get(k) for k in ("price", "current_price", "processor", "graphics", "memory", "storage", "display", "operating_system"))
    )
    if url and is_media_asset_url(url) and not strong:
        return "VisualAsset", "media_url_without_product_identity"
    if _page_context(attrs, node_key) and not strong:
        return "Page", "page_product_conflation"
    if not strong and not valid_product_name(name, structured=True):
        return "Concept", "insufficient_product_evidence"
    return "Product", ""


def backup_database(db: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    backup = db.with_name(f"{db.stem}.pre_v615_{stamp}{db.suffix}")
    src = sqlite3.connect(db, timeout=60)
    dst = sqlite3.connect(backup, timeout=60)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return backup


def repair(db: Path, knowledge: Path, *, no_backup: bool = False) -> dict[str, Any]:
    backup = "" if no_backup else str(backup_database(db))
    report: dict[str, Any] = {
        "version": "6.15",
        "database": str(db),
        "backup": str(backup),
        "started_at": _now(),
        "nodes_retyped": 0,
        "nodes_quarantined": 0,
        "edges_retyped": 0,
        "duplicate_edges_merged": 0,
        "raw_node_types_before": {},
        "raw_relationship_types_before": {},
    }

    conn = sqlite3.connect(db, timeout=60)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=60000")
        conn.execute("BEGIN IMMEDIATE")
        report["integrity_before"] = conn.execute("PRAGMA integrity_check").fetchone()[0]
        report["raw_node_types_before"] = {
            str(row[0]): int(row[1]) for row in conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")
        }
        report["raw_relationship_types_before"] = {
            str(row[0]): int(row[1]) for row in conn.execute("SELECT predicate,COUNT(*) FROM edges GROUP BY predicate")
        }
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS knowledge_validation_v615 (
                node_id INTEGER PRIMARY KEY,
                original_type TEXT NOT NULL,
                canonical_type TEXT NOT NULL,
                status TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '',
                validated_at TEXT NOT NULL
            )
            """
        )

        nodes = conn.execute("SELECT id,node_key,node_type,name,attributes_json FROM nodes ORDER BY id").fetchall()
        for row in nodes:
            node_id = int(row["id"])
            node_key = str(row["node_key"] or "")
            original = str(row["node_type"] or "Unknown")
            name = str(row["name"] or "")
            attrs = _loads(row["attributes_json"])
            context = "page" if _page_context(attrs, node_key) else "entity"
            canonical = canonical_node_type(original, context=context)
            canonical, product_reason = _repair_product_type(canonical, name, attrs, node_key)
            reason = product_reason
            status = "VALID"
            if attrs.get("unresolved_reference"):
                canonical = "Concept"
                reason = "unresolved_reference_preserved_as_evidence"
                status = "QUARANTINED"
            if canonical in {"Concept", "VisualAsset"} and context != "page":
                status = "QUARANTINED" if reason or attrs.get("unresolved_reference") else "EVIDENCE_ONLY"
            if original != canonical:
                attrs.setdefault("raw_node_type", original)
                report["nodes_retyped"] += 1
            if status == "QUARANTINED":
                attrs["graph_quarantined"] = True
                attrs["graph_quarantine_reason"] = reason or "non_semantic_evidence"
                report["nodes_quarantined"] += 1
            conn.execute(
                "UPDATE nodes SET node_type=?,attributes_json=?,last_seen=? WHERE id=?",
                (canonical, _json(attrs), _now(), node_id),
            )
            conn.execute(
                """
                INSERT INTO knowledge_validation_v615(node_id,original_type,canonical_type,status,reason,validated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(node_id) DO UPDATE SET
                    original_type=excluded.original_type,
                    canonical_type=excluded.canonical_type,
                    status=excluded.status,
                    reason=excluded.reason,
                    validated_at=excluded.validated_at
                """,
                (node_id, original, canonical, status, reason, _now()),
            )

        # Canonicalising several raw predicates can create UNIQUE-key collisions.
        # Merge provenance attributes into one surviving edge instead of failing.
        edges = conn.execute(
            "SELECT id,source_id,predicate,target_id,attributes_json,source_url,confidence,first_seen,last_seen FROM edges ORDER BY id"
        ).fetchall()
        for row in edges:
            edge_id = int(row["id"])
            raw_pred = str(row["predicate"] or "RELATED_TO")
            canonical_pred = canonical_relationship_type(raw_pred)
            if raw_pred == canonical_pred:
                continue
            attrs = _loads(row["attributes_json"])
            attrs.setdefault("raw_relationship_type", raw_pred)
            existing = conn.execute(
                "SELECT id,attributes_json,confidence FROM edges WHERE source_id=? AND predicate=? AND target_id=? AND source_url=? AND id<>? LIMIT 1",
                (row["source_id"], canonical_pred, row["target_id"], row["source_url"], edge_id),
            ).fetchone()
            if existing:
                merged = _loads(existing["attributes_json"])
                merged.update({k: v for k, v in attrs.items() if k not in merged})
                conn.execute(
                    "UPDATE edges SET attributes_json=?,confidence=MAX(confidence,?),last_seen=? WHERE id=?",
                    (_json(merged), float(row["confidence"] or 0), _now(), int(existing["id"])),
                )
                conn.execute("DELETE FROM edges WHERE id=?", (edge_id,))
                report["duplicate_edges_merged"] += 1
            else:
                conn.execute(
                    "UPDATE edges SET predicate=?,attributes_json=?,last_seen=? WHERE id=?",
                    (canonical_pred, _json(attrs), _now(), edge_id),
                )
            report["edges_retyped"] += 1

        report["integrity_after"] = conn.execute("PRAGMA integrity_check").fetchone()[0]
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    store = SQLiteKnowledgeGraph(db)
    try:
        report["product_projection"] = store.backfill_product_projection()
    except Exception as exc:
        report["product_projection"] = {"error": f"{type(exc).__name__}: {exc}"}
    report["canonical_schema"] = store.canonical_schema_report()
    report["extractor_quality"] = store.extractor_quality_report()
    report["finished_at"] = _now()
    knowledge.mkdir(parents=True, exist_ok=True)
    report_path = knowledge / "CANONICAL_KG_VALIDATION_V615.json"
    report_path.write_text(_json(report), encoding="utf-8")
    report["report_path"] = str(report_path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    args = parser.parse_args()
    db = Path(args.db).expanduser()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(db, Path(args.knowledge).expanduser())
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
