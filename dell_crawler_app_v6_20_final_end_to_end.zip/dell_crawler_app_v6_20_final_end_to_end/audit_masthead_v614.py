from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit v6.14 live Dell masthead taxonomy coverage")
    parser.add_argument("--report", default="knowledge/MASTHEAD_TAXONOMY_REPORT.json")
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    path = Path(args.report).resolve()
    if not path.exists():
        raise SystemExit(f"Masthead report not found: {path}. Start/Resume v6.14 once so live menu discovery can run.")
    data = json.loads(path.read_text(encoding="utf-8"))
    groups = data.get("groups") or {}
    print(f"Masthead status: {data.get('status', 'UNKNOWN')}")
    print(f"Safe URLs discovered: {data.get('url_count', len(data.get('urls') or []))}")
    print(f"Unsafe/transactional labels skipped: {len(data.get('unsafe_labels_skipped') or [])}")
    print()
    incomplete = []
    for name, detail in groups.items():
        status = str((detail or {}).get("status") or "UNKNOWN")
        urls = len((detail or {}).get("urls") or [])
        missing = (detail or {}).get("missing_expected_labels") or []
        print(f"{name}: {status} | urls={urls} | missing={len(missing)}")
        if missing:
            print("  missing: " + ", ".join(str(x) for x in missing))
        if status not in {"COMPLETE", "AUTH_NOT_READY"}:
            incomplete.append(name)
    if args.require_complete and incomplete:
        print("\nIncomplete masthead groups: " + ", ".join(incomplete))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
