from __future__ import annotations

import argparse
import json
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from repair_v611 import product_quality_audit


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only v6.12 product completion and extractor-quality audit.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    args = parser.parse_args()
    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    store = SQLiteKnowledgeGraph(db)
    result = {
        "quality": product_quality_audit(store),
        "enrichment": store.product_enrichment_status_report(),
        "queue": store.queue_counts(),
        "graph": store.stats(),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
