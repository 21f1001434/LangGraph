from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from repair_v610 import (
    clear_stale_profile_lease,
    count_unexpired_worker_leases,
    inspect_runtime_processes,
    sqlite_backup,
)
from repair_v611 import (
    product_quality_audit,
    reconstruct_and_replay_products,
    repair_contaminated_products,
)


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Upgrade/repair an existing Dell crawler database for v6.12 autonomous product completion. "
            "It preserves existing evidence, replays stored product sources, repairs contaminated product identities, "
            "and prequeues products that still need price/specification/mapping enrichment."
        )
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--max-attempts", type=int, default=4)
    parser.add_argument("--no-gain-limit", type=int, default=2)
    parser.add_argument("--min-score", type=float, default=0.85)
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    # Do not infer a live crawler from an old lease alone. Real runtime/browser PIDs are authoritative.
    runtime_state = inspect_runtime_processes(root)
    profile_lease = clear_stale_profile_lease(root)
    active_leases = count_unexpired_worker_leases(db)
    live_pids = [int(pid) for pid in (runtime_state.get("live_pids") or []) if int(pid or 0) > 0]
    profile_pid = int(profile_lease.get("owner_pid") or 0) if profile_lease.get("status") == "live_owner" else 0
    if profile_pid and profile_pid not in live_pids:
        live_pids.append(profile_pid)
    if live_pids and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while crawler/browser PID(s) {sorted(set(live_pids))} are alive. "
            "Use Graceful Stop first."
        )

    backup = ""
    if not args.no_backup:
        target = db.with_name(f"{db.stem}.pre_v612_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    # Initialising the store performs non-destructive schema migration, including product_enrichment_state.
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset_in_progress = store.reset_in_progress()
    before = product_quality_audit(store)

    # Re-run deterministic extraction over evidence already collected before spending network revisits.
    replay = reconstruct_and_replay_products(store)
    contamination = repair_contaminated_products(store)
    projection = store.backfill_product_projection()

    # Recoverable incomplete work from older versions remains eligible, but permanent failures stay permanent.
    requeued_incomplete_pages = store.requeue_statuses(
        ["DONE_INCOMPLETE"],
        error="v6.12 retry: recoverable incomplete extraction",
        priority_penalty=0,
    )

    # Prime the autonomous product completion queue. The crawler repeats this sweep automatically every
    # time the ordinary frontier drains, so this is only the first pass after migration.
    initial_revisit = store.schedule_product_revisit_sweep(
        min_score=max(0.0, min(1.0, float(args.min_score))),
        max_attempts=max(1, int(args.max_attempts)),
        no_gain_limit=max(1, int(args.no_gain_limit)),
        min_gain=0.02,
        priority=0,
        revisit_missing_price=True,
        revisit_missing_specs=True,
        revisit_unmapped=True,
    )

    after = product_quality_audit(store)
    enrichment = store.product_enrichment_status_report()
    queue = store.queue_counts()

    completion_report = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "version": "6.12",
        "database": str(db),
        "quality": after,
        "enrichment": enrichment,
        "queue": queue,
        "behavior": {
            "same_run_product_revisits": True,
            "missing_price_triggers_revisit": True,
            "missing_applicable_specs_trigger_revisit": True,
            "unresolved_unmapped_evidence_triggers_revisit": True,
            "missing_exact_pdp_triggers_source_identity_recovery": True,
            "recognized_aliases_are_mapped_to_canonical_product_fields": True,
            "successful_revisit_merges_into_canonical_product": True,
            "bounded_attempts_prevent_infinite_loops": True,
            "permanently_unavailable_pages_are_not_requeued": True,
            "values_are_not_fabricated_when_dell_does_not_publish_them": True,
        },
    }
    completion_path = knowledge / "PRODUCT_COMPLETION_REPORT_V612.json"
    completion_path.write_text(json.dumps(completion_report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    report = {
        "migration": "v6.11 -> v6.12 autonomous product completion",
        "database": str(db),
        "backup": backup,
        "sqlite_integrity": integrity,
        "runtime_process_state": runtime_state,
        "profile_lease": profile_lease,
        "unexpired_worker_leases_before_repair": active_leases,
        "orphaned_in_progress_reset": reset_in_progress,
        "before": before,
        "stored_source_product_replay": replay,
        "contamination_repair": contamination,
        "product_projection": projection,
        "recoverable_done_incomplete_requeued": requeued_incomplete_pages,
        "initial_product_revisit_sweep": initial_revisit,
        "after": after,
        "enrichment": enrichment,
        "queue": queue,
        "completion_report": str(completion_path),
    }
    report_path = knowledge / "V612_AUTONOMOUS_COMPLETION_REPAIR_REPORT.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nProduct completion report: {completion_path}")
    print(f"Repair report: {report_path}")
    print("\nv6.12 is ready. Start Streamlit and use Start / Resume; product revisits continue automatically in the same run.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
