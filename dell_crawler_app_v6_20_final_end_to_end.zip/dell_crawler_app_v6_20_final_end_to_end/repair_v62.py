from __future__ import annotations

import argparse
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from dell_crawler_core.document_pipeline import quarantine_file, validate_pdf_file
from dell_crawler_core.frontier_scheduler import DOCUMENT, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sqlite_backup(source_path: Path, target_path: Path) -> None:
    source = sqlite3.connect(source_path, timeout=120)
    target = sqlite3.connect(target_path, timeout=120)
    try:
        source.execute("PRAGMA busy_timeout=120000")
        source.backup(target)
    finally:
        target.close()
        source.close()


def quarantine_invalid_documents(knowledge: Path) -> dict[str, object]:
    documents = knowledge / "documents"
    quarantine = knowledge / "document_quarantine"
    inspected = 0
    invalid = 0
    moved: list[dict[str, str]] = []
    if not documents.exists():
        return {"documents_directory": str(documents), "inspected": 0, "quarantined": 0, "files": []}

    for path in documents.rglob("*"):
        if not path.is_file() or not (path.name.lower().endswith(".pdf") or path.name.lower().endswith(".pdf.part")):
            continue
        inspected += 1
        # A .part file only needs a PDF signature; a final .pdf must be readable.
        parse_structure = not path.name.lower().endswith(".part")
        validation = validate_pdf_file(path, parse_structure=parse_structure)
        if validation.ok:
            continue
        invalid += 1
        target = quarantine_file(path, quarantine, validation.reason)
        moved.append({
            "source": str(path),
            "quarantine": str(target or ""),
            "reason": validation.reason,
        })
    return {
        "documents_directory": str(documents),
        "inspected": inspected,
        "quarantined": invalid,
        "files": moved,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Prepare an existing Dell crawler database/evidence store for v6.2 verified PDF recovery."
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="", help="Knowledge directory; defaults to the database parent.")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true", help="Proceed even if an unexpired worker lease exists.")
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent

    # Never migrate underneath a live worker unless the operator explicitly
    # accepts that risk. Graceful Stop should clear or expire the lease.
    probe = sqlite3.connect(db, timeout=30)
    try:
        columns = {str(row[1]) for row in probe.execute("PRAGMA table_info(crawl_queue)").fetchall()}
        active_leases = 0
        if {"status", "lease_expires_at"}.issubset(columns):
            active_leases = int(probe.execute(
                "SELECT COUNT(*) FROM crawl_queue WHERE status='IN_PROGRESS' AND lease_expires_at<>'' AND lease_expires_at>?",
                (now(),),
            ).fetchone()[0] or 0)
    finally:
        probe.close()
    if active_leases and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while {active_leases} unexpired worker lease(s) exist. "
            "Use Graceful Stop and wait for the worker to exit, or pass --force-active only when certain no worker is alive."
        )

    backup = ""
    existing_backups = sorted(db.parent.glob(f"{db.stem}.pre_v62_*{db.suffix}"))
    if not args.no_backup and (args.force_backup or not existing_backups):
        backup_path = db.with_name(f"{db.stem}.pre_v62_{stamp()}{db.suffix}")
        sqlite_backup(db, backup_path)
        backup = str(backup_path)
    elif existing_backups:
        backup = str(existing_backups[-1])

    store = SQLiteKnowledgeGraph(db)
    integrity = ""
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.lower() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset = store.reset_in_progress()
    invalid_files = quarantine_invalid_documents(knowledge)
    ts = now()

    with store.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        # Correct legacy PDF rows that were classified as PAGE.
        reclassified = conn.execute(
            """
            UPDATE crawl_queue
               SET resource_class=?, lane_priority=?, updated_at=?
             WHERE (lower(substr(url,1,instr(url||'?', '?')-1)) LIKE '%.pdf'
                    OR lower(url) LIKE '%.pdf.external%')
               AND resource_class<>?
            """,
            (DOCUMENT, lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount

        # Requeue every unresolved document, not all HTML work. Already completed
        # evidence is preserved and no graph/source rows are deleted.
        requeued_documents = conn.execute(
            """
            UPDATE crawl_queue
               SET status='PENDING', priority=0, lane_priority=?, attempts=0,
                   lease_owner='', lease_expires_at='', not_before='',
                   last_error='Requeued by v6.2 verified PDF transport and validation recovery',
                   updated_at=?
             WHERE resource_class=?
               AND status NOT IN ('DONE','SKIPPED','SKIPPED_PERMANENT')
            """,
            (lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount

        stale_runs = conn.execute(
            """
            UPDATE crawl_runs
               SET status='INTERRUPTED', finished_at=?
             WHERE status='RUNNING'
            """,
            (ts,),
        ).rowcount
        conn.commit()

    report = {
        "migration": "v6.1 -> v6.2",
        "database": str(db),
        "knowledge": str(knowledge),
        "sqlite_integrity": integrity,
        "backup": backup,
        "active_leases_before_repair": active_leases,
        "reset_in_progress": int(reset),
        "pdf_rows_reclassified_as_document": int(reclassified or 0),
        "unresolved_documents_requeued": int(requeued_documents or 0),
        "stale_runs_closed": int(stale_runs or 0),
        "invalid_local_documents": invalid_files,
        "stats": store.stats(),
    }
    out = knowledge / "V62_REPAIR_REPORT.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
