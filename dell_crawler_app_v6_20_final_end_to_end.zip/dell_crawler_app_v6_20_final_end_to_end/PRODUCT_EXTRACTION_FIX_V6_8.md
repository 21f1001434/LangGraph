# v6.8 product price/specification extraction correction

## Production symptom

The product dashboard contained hundreds of Product rows, but nearly every normalized column was empty. Only one row had a price, even though the crawl evidence contained Dell prices, order codes, CPUs, GPUs, memory, storage, displays and ratings.

## Root causes found in the database and code

1. **Page-level association instead of product-level association**  
   Catalogue prices and specifications were extracted from the complete page and attached to the category-page node. Individual Product nodes retained only a name.

2. **Semantic node overwrite**  
   The same Dell product-detail URL could first be stored as `Product` and later be ingested as a generic `Endpoint`. The later ingestion replaced the stronger semantic type and sometimes replaced its title with a navigation label such as “Skip to main content”.

3. **Serialized structured evidence entered regex extraction**  
   JSON representations of DOM controls, links, trademarks and attributes were appended to visible text. Page-wide regex extraction then interpreted fragments from this JSON as CPU/GPU/display facts.

4. **No coherent catalogue-card boundary**  
   Product name, price, model/order code, rating and specifications were not extracted as one evidence unit. Values from adjacent product cards or financing/legal text could be mixed.

5. **Dashboard projection gap**  
   Facts existed in the provenance graph but were not projected into stable Product attributes. The dashboard expected `price`, `processor`, `memory`, etc. directly in `attributes_json` and therefore displayed blanks.

## v6.8 correction

- Captures coherent rendered `productCards` from the live DOM, including headings, text, links, images, buttons and data attributes.
- Parses Product JSON-LD and nested Offer data while preserving the Product association.
- Uses a visible-text fallback that stops before serialized DOM/JSON/vision evidence.
- Identifies purchasable configurations by Dell order code/SKU first, then part number, product URL and model.
- Separates current price, list price, ex-VAT price, discounts, financing and rewards.
- Attaches every price/specification fact and Offer to the correct Product node.
- Prevents generic Endpoint/WebPage ingestion from overwriting stronger semantic node types.
- Rejects legal, finance, promotional, footer and trademark-inventory text as product data.
- Projects the highest-quality provenance facts into normalized Product attributes.
- Creates `product_catalog_view` for dashboards and exports.
- Assigns a completeness score and records missing fields.
- Keeps incomplete product detail URLs in the durable queue instead of marking them complete.
- Replays already-stored catalogue/detail evidence during `repair_v68.py`, so existing multi-day work is reused.

## Migration test on the supplied database snapshot

A copy of the uploaded SQLite database was migrated; the original was not modified.

```text
SQLite integrity                         ok
Stored product/catalog sources replayed 32
Coherent product records recovered       94
Recovered records with price             92
Recovered records with core specs        81
Normalized products after filtering      290
Normalized products with price           109
Normalized products with core specs       99
Price coverage                          37.59%
Specification coverage                 34.14%
Product observations                     94
Product detail URLs pending              212
Promotional/legal names in view            0
```

The pending product-detail pages are deliberately resumed so price/configuration/specification coverage can continue increasing. The migration does not invent values to force 100% coverage.

## Correct dashboard query

```sql
SELECT *
FROM product_catalog_view
ORDER BY completeness_score DESC, product_name;
```

`nodes` and `facts` remain the provenance graph; `product_catalog_view` is the stable normalized serving projection.
