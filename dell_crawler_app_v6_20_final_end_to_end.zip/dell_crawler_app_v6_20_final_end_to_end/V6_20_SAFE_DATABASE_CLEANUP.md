# Dell Crawler v6.20 — Safe Legacy Database Cleanup

v6.20 extends v6.19 with an automatic database-hygiene phase during repair/upgrade.
A SQLite backup is created **before** cleanup.

## Deleted automatically

- old `interactions` runtime telemetry
- old `self_heal_events`
- stale `dynamic_control_progress` and `control_progress`
- old `web_state_observations`
- old `action_decisions` / raw `action_trajectories`
- all but the latest configurable crawl-run records (default: 3)
- orphan semantic/product aliases
- orphan product-enrichment state
- orphan extraction-validation rows
- empty 404/410 source tombstones that contain no retained evidence/content/provenance
- irrelevant `SKIPPED` / `SKIPPED_DUPLICATE_ASSET` queue rows with no retained source/link evidence

## Explicitly preserved

- source pages with useful content
- chunks, semantic nodes, edges and facts
- extraction evidence and link provenance
- product observations/history
- canonical aliases that still resolve
- `action_policy_memory` (the distilled adaptive UI-learning memory)
- queue rows required for resume/revisit suppression, including DONE, DONE_INCOMPLETE,
  FAILED, DEFERRED and SKIPPED_PERMANENT

The cleanup ends with integrity/foreign-key checks, `PRAGMA optimize`, WAL checkpoint,
and `VACUUM` to reclaim unused database pages.

Run:

```powershell
python .\repair_v620.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v620.py --db knowledge\dell_en_uk.db --require-clean
```

Or use `upgrade_v620.ps1` / `upgrade_v620.bat`.
