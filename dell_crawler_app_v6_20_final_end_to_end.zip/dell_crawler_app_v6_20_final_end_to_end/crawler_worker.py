from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from dell_crawler_core.market_context import market_for_locale, normalize_locale
from dell_crawler_core.aia import DellAIAClient
from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.env_config import apply_compatibility_aliases
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime
from dell_crawler_core.snapshot_extract import seed_urls_for_scope

ROOT = Path(__file__).resolve().parent
RUNTIME_DIR = ROOT / "runtime"
STATUS_FILE = RUNTIME_DIR / "status.json"
EVENTS_FILE = RUNTIME_DIR / "events.jsonl"
COMMAND_FILE = RUNTIME_DIR / "command.json"
WORKER_PID_FILE = RUNTIME_DIR / "worker.pid"
HEARTBEAT_FILE = RUNTIME_DIR / "heartbeat.json"
RESULT_FILE = RUNTIME_DIR / "last_result.json"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    tmp.replace(path)


def append_event(payload: dict[str, Any]) -> None:
    EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with EVENTS_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")


def read_command() -> str:
    try:
        payload = json.loads(COMMAND_FILE.read_text(encoding="utf-8"))
        return str(payload.get("command") or "").strip().lower()
    except Exception:
        return ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Background worker for the Dell crawler application")
    parser.add_argument("--config", required=True, help="Path to a JSON crawl configuration")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_path = Path(args.config).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    load_dotenv(ROOT / ".env")
    apply_compatibility_aliases()
    raw = json.loads(config_path.read_text(encoding="utf-8"))

    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    WORKER_PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    write_json_atomic(COMMAND_FILE, {"command": "run", "updated_at": now_iso()})

    scope = str(raw.get("scope") or "full_en_uk_discovery")
    locale = normalize_locale(raw.get("locale") or "en-uk")
    market = str(raw.get("market") or market_for_locale(locale))
    seeds = list(seed_urls_for_scope(scope, locale=locale))
    seeds.extend(str(url).strip() for url in raw.get("start_urls", []) if str(url).strip())
    seeds = list(dict.fromkeys(seeds))

    db_path = Path(raw.get("db_path") or "knowledge/dell_en_uk.db")
    if not db_path.is_absolute():
        db_path = ROOT / db_path
    output_dir = Path(raw.get("output_dir") or "knowledge")
    if not output_dir.is_absolute():
        output_dir = ROOT / output_dir

    runtime = PlaywrightMCPRuntime(
        browser=str(raw.get("browser") or "chrome"),
        headless=bool(raw.get("headless", False)),
        mode=str(raw.get("browser_mode") or "persistent"),
        user_data_dir=str(raw.get("user_data_dir") or "browser_profile/dell_crawler"),
        output_dir=str(output_dir / "evidence"),
        extra_args=str(raw.get("playwright_extra_args") or os.getenv("PLAYWRIGHT_MCP_EXTRA_ARGS", "")),
        package_version=str(raw.get("playwright_mcp_version") or os.getenv("PLAYWRIGHT_MCP_VERSION", "0.0.78")),
        executable_path=str(raw.get("browser_executable_path") or os.getenv("PLAYWRIGHT_MCP_EXECUTABLE_PATH", "")),
        start_timeout_seconds=int(raw.get("mcp_start_timeout_seconds", 180)),
    )

    store = SQLiteKnowledgeGraph(db_path)
    use_llm = bool(raw.get("use_llm", True))
    vision_mode = str(raw.get("vision_mode") or "auto").lower()
    use_vision = vision_mode != "off"
    aia = DellAIAClient()
    extractor = DellContentExtractor(
        aia=aia,
        use_llm=use_llm,
        use_vision=use_vision,
        vision_cache_dir=output_dir / "vision_cache",
        text_cache_dir=output_dir / "text_cache",
        text_cache_enabled=bool(raw.get("llm_text_cache_enabled", True)),
        llm_chunk_chars=int(raw.get("llm_chunk_chars", 12000)),
        llm_chunk_overlap=int(raw.get("llm_chunk_overlap", 700)),
        max_llm_chunks=int(raw.get("max_llm_chunks", 0)),
        hierarchical_summaries=bool(raw.get("hierarchical_summaries", True)),
        extract_all_reviews=bool(raw.get("extract_all_reviews", True)),
    )

    crawl_config = CrawlConfig(
        start_urls=seeds,
        market=market,
        locale=locale,
        scope_name=scope,
        max_pages=int(raw.get("max_pages", 0)),
        max_depth=int(raw.get("max_depth", -1)),
        max_interactions_per_page=int(raw.get("max_interactions_per_page", -1)),
        delay_seconds=float(raw.get("delay_seconds", 1.5)),
        download_pdfs=bool(raw.get("download_pdfs", True)),
        max_pdf_mb=int(raw.get("max_pdf_mb", 0)),
        use_llm_extraction=use_llm,
        use_vision_extraction=use_vision,
        vision_mode=vision_mode,
        vision_full_page=bool(raw.get("vision_full_page", True)),
        vision_interactions=bool(raw.get("vision_interactions", True)),
        vision_pdf_pages=bool(raw.get("vision_pdf_pages", True)),
        download_visual_assets=bool(raw.get("download_visual_assets", True)),
        pdf_render_dpi=int(raw.get("pdf_render_dpi", 144)),
        vision_pdf_every_page=bool(raw.get("vision_pdf_every_page", False)),
        document_download_resume=bool(raw.get("document_download_resume", True)),
        screenshot_every_page=bool(raw.get("screenshot_every_page", False)),
        react_enabled=bool(raw.get("react_enabled", True)),
        react_use_llm=bool(raw.get("react_use_llm", True)),
        self_heal_enabled=bool(raw.get("self_heal_enabled", True)),
        max_page_retries=int(raw.get("max_page_retries", 6)),
        max_control_retries=int(raw.get("max_control_retries", 4)),
        max_mcp_restarts=int(raw.get("max_mcp_restarts", 3)),
        retry_base_seconds=float(raw.get("retry_base_seconds", 1.5)),
        retry_max_seconds=float(raw.get("retry_max_seconds", 45.0)),
        http_fallback_on_browser_failure=bool(raw.get("http_fallback", True)),
        completeness_judge=bool(raw.get("completeness_judge", True)),
        deep_scan_lazy_content=bool(raw.get("deep_scan", True)),
        deep_scan_stable_rounds=int(raw.get("deep_scan_stable_rounds", 2)),
        max_deep_scan_rounds=int(raw.get("max_deep_scan_rounds", 0)),
        deep_scan_fallback_round_guard=int(raw.get("deep_scan_fallback_round_guard", 80)),
        emergency_max_actions_per_page=int(raw.get("emergency_max_actions_per_page", 0)),
        exhaust_repeatable_controls=bool(raw.get("exhaust_repeatable_controls", True)),
        repeatable_control_stable_rounds=int(raw.get("repeatable_control_stable_rounds", 2)),
        repeatable_control_max_clicks=int(raw.get("repeatable_control_max_clicks", 0)),
        capture_dynamic_state_evidence=bool(raw.get("capture_dynamic_state_evidence", True)),
        extract_all_reviews=bool(raw.get("extract_all_reviews", True)),
        enrich_html_structure=bool(raw.get("enrich_html_structure", True)),
        capture_browser_structured_dom=bool(raw.get("capture_browser_structured_dom", True)),
        capture_network_inventory=bool(raw.get("capture_network_inventory", True)),
        extract_video_metadata=bool(raw.get("extract_video_metadata", True)),
        discover_robots_sitemaps=bool(raw.get("discover_robots_sitemaps", True)),
        recursive_shadow_dom=bool(raw.get("recursive_shadow_dom", True)),
        capture_same_origin_iframes=bool(raw.get("capture_same_origin_iframes", True)),
        scroll_sweep_enabled=bool(raw.get("scroll_sweep_enabled", True)),
        process_public_api_gets=bool(raw.get("process_public_api_gets", True)),
        process_office_documents=bool(raw.get("process_office_documents", True)),
        process_transcripts=bool(raw.get("process_transcripts", True)),
        record_binary_asset_metadata=bool(raw.get("record_binary_asset_metadata", True)),
        coverage_contract_enabled=bool(raw.get("coverage_contract_enabled", True)),
        minimum_page_coverage=float(raw.get("minimum_page_coverage", 0.72)),
        include_support_content=bool(raw.get("include_support_content", True)),
        include_blog_content=bool(raw.get("include_blog_content", True)),
        include_authenticated_account_knowledge=bool(raw.get("include_authenticated_account_knowledge", True)),
        require_authenticated_account_knowledge=bool(raw.get("require_authenticated_account_knowledge", False)),
        login_email=str(raw.get("login_email") or os.getenv("DELL_LOGIN_EMAIL") or os.getenv("DELL_DEMO_EMAIL") or ""),
        profile_name=str(raw.get("profile_name") or os.getenv("DELL_PROFILE_NAME") or ""),
        auth_probe_url=str(raw.get("auth_probe_url") or os.getenv("DELL_AUTH_PROBE_URL") or ""),
        auth_wait_seconds=float(raw.get("auth_wait_seconds", 90.0)),
        include_masthead_taxonomy_discovery=bool(raw.get("include_masthead_taxonomy_discovery", True)),
        require_masthead_taxonomy_coverage=bool(raw.get("require_masthead_taxonomy_coverage", False)),
        masthead_max_submenu_depth=int(raw.get("masthead_max_submenu_depth", 4)),
        masthead_max_actions=int(raw.get("masthead_max_actions", 250)),
        exact_content_dedupe_enabled=bool(raw.get("exact_content_dedupe_enabled", True)),
        duplicate_content_min_chars=int(raw.get("duplicate_content_min_chars", 400)),
        resume_requeue_done_incomplete=bool(raw.get("resume_requeue_done_incomplete", False)),
        resume_requeue_http_fallback=bool(raw.get("resume_requeue_http_fallback", False)),
        discover_embedded_documents=bool(raw.get("discover_embedded_documents", True)),
        llm_chunk_chars=int(raw.get("llm_chunk_chars", 12000)),
        llm_chunk_overlap=int(raw.get("llm_chunk_overlap", 700)),
        max_llm_chunks=int(raw.get("max_llm_chunks", 0)),
        hierarchical_summaries=bool(raw.get("hierarchical_summaries", True)),
        respect_robots=bool(raw.get("respect_robots", True)),
        robots_fail_closed=bool(raw.get("robots_fail_closed", False)),
        resume=True,
        retry_recoverable_on_resume=bool(raw.get("retry_recoverable_on_resume", True)),
        include_linked_dell_ecosystem=bool(raw.get("include_linked_dell_ecosystem", True)),
        include_community_feedback=bool(raw.get("include_community_feedback", True)),
        agentq_action_model_enabled=bool(raw.get("agentq_action_model_enabled", True)),
        agentq_actor_critic_enabled=bool(raw.get("agentq_actor_critic_enabled", True)),
        agentq_action_memory_enabled=bool(raw.get("agentq_action_memory_enabled", True)),
        agentq_mcts_exploration_enabled=bool(raw.get("agentq_mcts_exploration_enabled", True)),
        agentq_exploration_weight=float(raw.get("agentq_exploration_weight", 1.25)),
        agentq_llm_critic_enabled=bool(raw.get("agentq_llm_critic_enabled", True)),
        agentq_llm_critic_margin=float(raw.get("agentq_llm_critic_margin", 0.65)),
        dom_mutation_observer_enabled=bool(raw.get("dom_mutation_observer_enabled", True)),
        mutation_quiet_window_ms=int(raw.get("mutation_quiet_window_ms", 700)),
        mutation_max_wait_seconds=float(raw.get("mutation_max_wait_seconds", 12.0)),
        worker_lease_seconds=int(raw.get("worker_lease_seconds", 900)),
        frontier_lane_scheduler_enabled=bool(raw.get("frontier_lane_scheduler_enabled", True)),
        dedupe_visual_asset_variants=bool(raw.get("dedupe_visual_asset_variants", True)),
        process_visual_assets_as_lane=bool(raw.get("process_visual_assets_as_lane", True)),
        asset_browser_fallback_on_403=bool(raw.get("asset_browser_fallback_on_403", True)),
        document_browser_fallback_on_403=bool(raw.get("document_browser_fallback_on_403", True)),
        document_browser_chunk_bytes=int(raw.get("document_browser_chunk_bytes", 262144)),
        document_browser_single_response_max_bytes=int(raw.get("document_browser_single_response_max_bytes", 8 * 1024 * 1024)),
        document_browser_api_request_enabled=bool(raw.get("document_browser_api_request_enabled", True)),
        document_browser_navigation_probe_enabled=bool(raw.get("document_browser_navigation_probe_enabled", True)),
        document_network_body_capture_enabled=bool(raw.get("document_network_body_capture_enabled", True)),
        document_direct_http_enabled=bool(raw.get("document_direct_http_enabled", False)),
        document_dom_href_first_enabled=bool(raw.get("document_dom_href_first_enabled", True)),
        document_browser_context_request_first=bool(raw.get("document_browser_context_request_first", False)),
        document_browser_context_request_fallback=bool(raw.get("document_browser_context_request_fallback", True)),
        document_ui_click_fallback_enabled=bool(raw.get("document_ui_click_fallback_enabled", True)),
        document_unique_target_marker_enabled=bool(raw.get("document_unique_target_marker_enabled", True)),
        document_capture_all_href_candidates=bool(raw.get("document_capture_all_href_candidates", True)),
        document_require_canonical_match=bool(raw.get("document_require_canonical_match", False)),
        document_canonical_match_mode=str(raw.get("document_canonical_match_mode", "warn")),
        document_click_timeout_seconds=float(raw.get("document_click_timeout_seconds", 30.0)),
        document_profile_lock_backoff_seconds=float(raw.get("document_profile_lock_backoff_seconds", 15.0)),
        document_profile_lock_max_wait_seconds=float(raw.get("document_profile_lock_max_wait_seconds", 180.0)),
        document_click_first_enabled=bool(raw.get("document_click_first_enabled", True)),
        document_click_replay_timeout_seconds=float(raw.get("document_click_replay_timeout_seconds", 18.0)),
        document_click_use_direct_http_fallback=bool(raw.get("document_click_use_direct_http_fallback", False)),
        document_recovery_first=bool(raw.get("document_recovery_first", True)),
        document_recovery_success_target=int(raw.get("document_recovery_success_target", 3)),
        document_max_attempts=int(raw.get("document_max_attempts", 2)),
        document_invalid_quarantine=bool(raw.get("document_invalid_quarantine", True)),
        browser_pdf_viewer_extraction_enabled=bool(raw.get("browser_pdf_viewer_extraction_enabled", True)),
        browser_pdf_viewer_text_enabled=bool(raw.get("browser_pdf_viewer_text_enabled", True)),
        browser_pdf_viewer_vision_enabled=bool(raw.get("browser_pdf_viewer_vision_enabled", True)),
        browser_pdf_viewer_capture_screenshots=bool(raw.get("browser_pdf_viewer_capture_screenshots", True)),
        browser_pdf_viewer_stable_rounds=int(raw.get("browser_pdf_viewer_stable_rounds", 2)),
        browser_pdf_viewer_max_viewports=int(raw.get("browser_pdf_viewer_max_viewports", 0)),
        browser_pdf_viewer_fallback_guard=int(raw.get("browser_pdf_viewer_fallback_guard", 1200)),
        browser_pdf_viewer_wait_seconds=float(raw.get("browser_pdf_viewer_wait_seconds", 0.8)),
        coverage_checkpoint_every_items=int(raw.get("coverage_checkpoint_every_items", 20)),
        coverage_checkpoint_seconds=int(raw.get("coverage_checkpoint_seconds", 300)),
        llm_text_cache_enabled=bool(raw.get("llm_text_cache_enabled", True)),
        stable_control_context_identity=bool(raw.get("stable_control_context_identity", True)),
        control_progress_ttl_hours=int(raw.get("control_progress_ttl_hours", 168)),
        extract_product_cards=bool(raw.get("extract_product_cards", True)),
        product_detail_completion_enabled=bool(raw.get("product_detail_completion_enabled", True)),
        product_min_completeness=float(raw.get("product_min_completeness", 0.85)),
        product_require_price_on_commerce_pages=bool(raw.get("product_require_price_on_commerce_pages", True)),
        product_reprocess_existing_sources_on_upgrade=bool(raw.get("product_reprocess_existing_sources_on_upgrade", True)),
        product_revisit_enabled=bool(raw.get("product_revisit_enabled", True)),
        product_revisit_max_attempts=int(raw.get("product_revisit_max_attempts", 4)),
        product_revisit_max_sweeps=int(raw.get("product_revisit_max_sweeps", 8)),
        product_revisit_no_gain_limit=int(raw.get("product_revisit_no_gain_limit", 2)),
        product_revisit_min_gain=float(raw.get("product_revisit_min_gain", 0.02)),
        product_revisit_priority=int(raw.get("product_revisit_priority", 0)),
        product_revisit_missing_price=bool(raw.get("product_revisit_missing_price", True)),
        product_revisit_missing_specs=bool(raw.get("product_revisit_missing_specs", True)),
        product_revisit_unmapped_evidence=bool(raw.get("product_revisit_unmapped_evidence", True)),
    )

    crawler_holder: dict[str, DellEnUkKnowledgeCrawler] = {}
    heartbeat_stop = threading.Event()
    heartbeat_state: dict[str, Any] = {
        "event": "worker_initialising",
        "url": "",
        "run_id": "",
    }
    heartbeat_interval = max(2.0, float(raw.get("heartbeat_interval_seconds", 10.0)))

    def write_heartbeat() -> None:
        payload = {
            "timestamp": now_iso(),
            "worker_pid": os.getpid(),
            "worker_alive": True,
            **heartbeat_state,
        }
        write_json_atomic(HEARTBEAT_FILE, payload)

    def heartbeat_loop() -> None:
        while not heartbeat_stop.is_set():
            try:
                write_heartbeat()
            except Exception:
                pass
            heartbeat_stop.wait(heartbeat_interval)

    heartbeat_thread = threading.Thread(target=heartbeat_loop, name="crawler-heartbeat", daemon=True)
    heartbeat_thread.start()

    def status_callback(event: dict[str, Any]) -> None:
        event = {**event, "worker_pid": os.getpid(), "worker_alive": True}
        heartbeat_state.update({
            "event": str(event.get("event") or "worker_progress"),
            "url": str(event.get("url") or ""),
            "run_id": str(event.get("run_id") or ""),
        })
        write_heartbeat()
        write_json_atomic(STATUS_FILE, event)
        append_event(event)
        if read_command() in {"stop", "pause"}:
            crawler = crawler_holder.get("crawler")
            if crawler is not None:
                crawler.stop()

    crawler = DellEnUkKnowledgeCrawler(
        runtime=runtime,
        store=store,
        extractor=extractor,
        config=crawl_config,
        output_dir=output_dir,
        status_callback=status_callback,
    )
    crawler_holder["crawler"] = crawler

    def request_stop(signum: int, _frame: object) -> None:
        write_json_atomic(COMMAND_FILE, {"command": "stop", "signal": signum, "updated_at": now_iso()})
        crawler.stop()

    signal.signal(signal.SIGINT, request_stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, request_stop)

    start_payload = {
        "event": "worker_started",
        "timestamp": now_iso(),
        "worker_pid": os.getpid(),
        "worker_alive": True,
        "config_path": str(config_path),
        "database": str(db_path),
        "start_urls": seeds,
        "stats": store.stats(),
    }
    write_json_atomic(STATUS_FILE, start_payload)
    append_event(start_payload)

    try:
        result = crawler.run()
        write_json_atomic(RESULT_FILE, result)
        final_event = {
            "event": "worker_finished",
            "timestamp": now_iso(),
            "worker_pid": os.getpid(),
            "worker_alive": False,
            "result": result,
            "stats": result.get("stats", {}),
        }
        write_json_atomic(STATUS_FILE, final_event)
        append_event(final_event)
        return 0 if str(result.get("status")) not in {"FAILED"} else 1
    except Exception as exc:
        failure = {
            "event": "worker_failed",
            "timestamp": now_iso(),
            "worker_pid": os.getpid(),
            "worker_alive": False,
            "error": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc(),
        }
        write_json_atomic(STATUS_FILE, failure)
        append_event(failure)
        return 1
    finally:
        heartbeat_stop.set()
        try:
            heartbeat_thread.join(timeout=2.0)
        except Exception:
            pass
        try:
            write_json_atomic(
                HEARTBEAT_FILE,
                {
                    "timestamp": now_iso(),
                    "worker_pid": os.getpid(),
                    "worker_alive": False,
                    "event": "worker_exited",
                },
            )
        except Exception:
            pass
        try:
            WORKER_PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
