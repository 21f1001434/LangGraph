from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path


def scalar(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> int:
    row = conn.execute(sql, params).fetchone()
    return int(row[0] or 0) if row else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify current Dell crawler extraction progress.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    args = parser.parse_args()
    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    try:
        queue = {r[0]: int(r[1]) for r in conn.execute("SELECT status, COUNT(*) FROM crawl_queue GROUP BY status")}
        lanes = {
            r[0]: {rr[0]: int(rr[1]) for rr in conn.execute(
                "SELECT status, COUNT(*) FROM crawl_queue WHERE resource_class=? GROUP BY status", (r[0],)
            )}
            for r in conn.execute("SELECT DISTINCT resource_class FROM crawl_queue ORDER BY resource_class")
        }
        pdf_sources = scalar(conn, "SELECT COUNT(*) FROM sources WHERE lower(mime_type) LIKE '%pdf%' OR lower(url) LIKE '%.pdf%'")
        pdf_nodes = scalar(conn, "SELECT COUNT(*) FROM nodes WHERE node_type IN ('Document','DocumentSummary','DocumentSection')")
        deferred_docs = [dict(r) for r in conn.execute(
            "SELECT url, attempts, last_error FROM crawl_queue WHERE resource_class='DOCUMENT' AND status='DEFERRED' ORDER BY attempts DESC LIMIT 20"
        )]
        latest_run = conn.execute("SELECT * FROM crawl_runs ORDER BY started_at DESC LIMIT 1").fetchone()
        payload = {
            "database": str(db),
            "queue": queue,
            "queue_lanes": lanes,
            "pdf_sources": pdf_sources,
            "document_graph_nodes": pdf_nodes,
            "deferred_documents": deferred_docs,
            "latest_run": dict(latest_run) if latest_run else {},
            "pdf_working": pdf_sources > 0 and not (lanes.get("DOCUMENT", {}).get("DEFERRED", 0) and lanes.get("DOCUMENT", {}).get("DONE", 0) == 0),
            "success_events_to_watch": [
                "pdf_start", "document_download_progress", "document_browser_fallback_start",
                "pdf_text_progress", "pdf_visual_progress", "pdf_done"
            ],
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
    finally:
        conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
