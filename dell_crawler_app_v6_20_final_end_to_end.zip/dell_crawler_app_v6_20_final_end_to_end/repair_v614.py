from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.snapshot_extract import canonicalize_url
from repair_v610 import (
    clear_stale_profile_lease,
    count_unexpired_worker_leases,
    inspect_runtime_processes,
    sqlite_backup,
)
from repair_v611 import (
    product_quality_audit,
    reconstruct_and_replay_products,
    repair_contaminated_products,
)


TARGETED_REVISIT_RELATIONS = {"PRODUCT_DETAIL_ENRICHMENT", "PRODUCT_IDENTITY_RECOVERY"}
ACTIONABLE = {"PENDING", "FAILED", "DEFERRED", "BLOCKED_CONFIGURATION", "IN_PROGRESS"}


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _loads(value: str, default: Any) -> Any:
    try:
        return json.loads(value or "")
    except Exception:
        return default


def compact_repeated_frontier(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    """Stop historical URL/content aliases from being extracted again after upgrade.

    Completed evidence is preserved. Old tracking aliases are retired, while a
    canonical actionable row is created only when no canonical row exists. Rows
    that v6.12 blindly requeued despite already having stored evidence are restored
    to DONE/DONE_INCOMPLETE unless they are an intentional product-enrichment job.
    """
    stats = {
        "queue_rows_checked": 0,
        "tracking_aliases_retired": 0,
        "canonical_actionable_rows_created": 0,
        "stored_rows_restored_terminal": 0,
        "stored_exact_content_aliases_retired": 0,
    }
    with store.connect() as conn:
        rows = [dict(row) for row in conn.execute("SELECT * FROM crawl_queue ORDER BY discovered_at,url").fetchall()]

    for row in rows:
        stats["queue_rows_checked"] += 1
        url = str(row.get("url") or "")
        relation = str(row.get("relation") or "").upper()
        status = str(row.get("status") or "").upper()
        canonical = canonicalize_url(url) or url

        if canonical != url:
            existing = store.queue_item(canonical)
            if not existing and status in ACTIONABLE:
                created = store.enqueue(
                    canonical,
                    depth=int(row.get("depth") or 0),
                    priority=int(row.get("priority") or 50),
                    parent_url=str(row.get("parent_url") or ""),
                    relation=str(row.get("relation") or "LINKS_TO"),
                    force=False,
                    resource_class=str(row.get("resource_class") or ""),
                    resource_key=str(row.get("resource_key") or ""),
                )
                stats["canonical_actionable_rows_created"] += int(bool(created))
            with store.connect() as conn:
                conn.execute(
                    """
                    UPDATE crawl_queue SET status='SKIPPED_DUPLICATE_URL',
                        last_error=?, lease_owner='', lease_expires_at='', not_before='', updated_at=?
                    WHERE url=?
                    """,
                    (f"Canonical duplicate of {canonical}"[:4000], datetime.now(timezone.utc).isoformat(timespec="seconds"), url),
                )
            stats["tracking_aliases_retired"] += 1
            continue

        if status != "PENDING" or relation in TARGETED_REVISIT_RELATIONS:
            continue

        with store.connect() as conn:
            source = conn.execute(
                "SELECT url,content_hash,metadata_json FROM sources WHERE url=? OR canonical_url=? ORDER BY fetched_at DESC LIMIT 1",
                (url, url),
            ).fetchone()
        if not source:
            continue

        content_hash = str(source["content_hash"] or "")
        if content_hash:
            duplicate = store.duplicate_source_for_hash(content_hash, url)
            if duplicate:
                store.mark_queue(url, "SKIPPED_DUPLICATE_CONTENT", f"Stored evidence duplicates {duplicate.get('url') or duplicate.get('canonical_url')}")
                stats["stored_exact_content_aliases_retired"] += 1
                continue

        metadata = _loads(str(source["metadata_json"] or "{}"), {})
        coverage = metadata.get("coverage_contract") if isinstance(metadata, dict) else {}
        passed = bool(coverage.get("passed")) if isinstance(coverage, dict) else False
        restore_status = "DONE" if passed else "DONE_INCOMPLETE"
        store.mark_queue(url, restore_status, "Existing stored evidence preserved by v6.14 anti-repeat migration")
        stats["stored_rows_restored_terminal"] += 1

    return stats


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Upgrade/repair an existing Dell crawler database for v6.14 full Dell knowledge. "
            "It preserves evidence, compacts repeated URL/content work, repairs product identities, "
            "and primes only targeted incomplete-product revisits."
        )
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--max-attempts", type=int, default=4)
    parser.add_argument("--no-gain-limit", type=int, default=2)
    parser.add_argument("--min-score", type=float, default=0.85)
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    runtime_state = inspect_runtime_processes(root)
    profile_lease = clear_stale_profile_lease(root)
    active_leases = count_unexpired_worker_leases(db)
    live_pids = [int(pid) for pid in (runtime_state.get("live_pids") or []) if int(pid or 0) > 0]
    profile_pid = int(profile_lease.get("owner_pid") or 0) if profile_lease.get("status") == "live_owner" else 0
    if profile_pid and profile_pid not in live_pids:
        live_pids.append(profile_pid)
    if live_pids and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while crawler/browser PID(s) {sorted(set(live_pids))} are alive. "
            "Use Graceful Stop first."
        )

    backup = ""
    if not args.no_backup:
        target = db.with_name(f"{db.stem}.pre_v614_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset_in_progress = store.reset_in_progress()
    repeat_compaction = compact_repeated_frontier(store)
    before = product_quality_audit(store)
    replay = reconstruct_and_replay_products(store)
    contamination = repair_contaminated_products(store)
    projection = store.backfill_product_projection()

    # Intentionally do NOT requeue every DONE_INCOMPLETE page. v6.14 revisits only
    # products whose canonical projection still lacks price/applicable specs/PDP or
    # has unresolved unmapped evidence. This removes the resume loop seen in v6.12.
    initial_revisit = store.schedule_product_revisit_sweep(
        min_score=max(0.0, min(1.0, float(args.min_score))),
        max_attempts=max(1, int(args.max_attempts)),
        no_gain_limit=max(1, int(args.no_gain_limit)),
        min_gain=0.02,
        priority=0,
        revisit_missing_price=True,
        revisit_missing_specs=True,
        revisit_unmapped=True,
    )

    after = product_quality_audit(store)
    enrichment = store.product_enrichment_status_report()
    queue = store.queue_counts()
    report = {
        "migration": "v6.13 -> v6.14 full Dell knowledge + masthead taxonomy + anti-repeat frontier",
        "database": str(db),
        "backup": backup,
        "sqlite_integrity": integrity,
        "runtime_process_state": runtime_state,
        "profile_lease": profile_lease,
        "unexpired_worker_leases_before_repair": active_leases,
        "orphaned_in_progress_reset": reset_in_progress,
        "anti_repeat_compaction": repeat_compaction,
        "before": before,
        "stored_source_product_replay": replay,
        "contamination_repair": contamination,
        "product_projection": projection,
        "initial_targeted_product_revisit_sweep": initial_revisit,
        "after": after,
        "enrichment": enrichment,
        "queue": queue,
        "behavior": {
            "blind_done_incomplete_resume_requeue": False,
            "tracking_aliases_share_canonical_frontier_identity": True,
            "exact_duplicate_rendered_content_is_not_reextracted": True,
            "targeted_product_revisit_remains_enabled": True,
            "authenticated_myaccount_is_seeded_after_sso": True,
            "live_masthead_taxonomy_discovery_runs_at_crawl_start": True,
            "masthead_transactional_controls_are_never_activated": True,
            "password_otp_payment_automation": False,
        },
    }
    report_path = knowledge / "V614_FULL_MASTHEAD_REPAIR_REPORT.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {report_path}")
    print("\nv6.14 is ready. Start Streamlit and use Start / Resume. Ordinary pages are not blindly re-extracted; targeted product enrichment remains bounded and active.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
