from __future__ import annotations

import argparse
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.frontier_scheduler import PAGE, classify_frontier_url, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sqlite_backup(source_path: Path, target_path: Path) -> None:
    source = sqlite3.connect(source_path, timeout=120)
    target = sqlite3.connect(target_path, timeout=120)
    try:
        source.execute("PRAGMA busy_timeout=120000")
        source.backup(target)
    finally:
        target.close()
        source.close()


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import psutil

        return bool(psutil.pid_exists(pid) and psutil.Process(pid).is_running())
    except Exception:
        try:
            if os.name == "nt":
                return False
            os.kill(pid, 0)
            return True
        except Exception:
            return False


def clear_stale_profile_lease(root: Path) -> dict[str, Any]:
    profile = root / "browser_profile" / "dell_crawler"
    lease = profile.parent / f".{profile.name}.dell-crawler.lock"
    if not lease.exists():
        return {"lease_path": str(lease), "status": "absent"}
    try:
        payload = json.loads(lease.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    owner_pid = int(payload.get("pid") or 0)
    if pid_alive(owner_pid):
        return {"lease_path": str(lease), "status": "live_owner", "owner_pid": owner_pid}
    lease.unlink(missing_ok=True)
    return {"lease_path": str(lease), "status": "stale_removed", "owner_pid": owner_pid}


def inspect_runtime_processes(root: Path) -> dict[str, Any]:
    """Return live/stale crawler process markers without trusting stale PID files."""
    runtime = root / "runtime"
    markers: list[dict[str, Any]] = []
    live_pids: list[int] = []
    for name in ("crawler.pid", "worker.pid"):
        path = runtime / name
        try:
            pid = int(path.read_text(encoding="utf-8").strip())
        except Exception:
            pid = 0
        live = pid_alive(pid)
        markers.append({"path": str(path), "pid": pid, "live": live})
        if live:
            live_pids.append(pid)
        elif path.exists():
            path.unlink(missing_ok=True)
    return {"markers": markers, "live_pids": sorted(set(live_pids))}


def count_unexpired_worker_leases(db: Path) -> int:
    probe = sqlite3.connect(db, timeout=30)
    try:
        columns = {str(row[1]) for row in probe.execute("PRAGMA table_info(crawl_queue)").fetchall()}
        if not {"status", "lease_expires_at"}.issubset(columns):
            return 0
        return int(
            probe.execute(
                "SELECT COUNT(*) FROM crawl_queue "
                "WHERE status='IN_PROGRESS' AND lease_expires_at<>'' AND lease_expires_at>?",
                (now(),),
            ).fetchone()[0]
            or 0
        )
    finally:
        probe.close()


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Upgrade an existing Dell crawler database to v6.10.1 resilient JSON/payload normalisation, "
            "adaptive product completeness and page-specific coverage validation."
        )
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument(
        "--only-incomplete",
        action="store_true",
        help="Requeue only DONE_INCOMPLETE and adaptively incomplete product detail pages instead of replaying all stored public sources once.",
    )
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    runtime_state = inspect_runtime_processes(root)
    lease = clear_stale_profile_lease(root)
    active = count_unexpired_worker_leases(db)
    live_pids = list(runtime_state.get("live_pids") or [])
    profile_pid = int(lease.get("owner_pid") or 0) if lease.get("status") == "live_owner" else 0
    if profile_pid and profile_pid not in live_pids:
        live_pids.append(profile_pid)

    # A database lease can outlive a stopped/crashed worker for up to the lease
    # duration. Refuse only when an actual crawler/browser process is alive.
    # Otherwise reset the abandoned IN_PROGRESS rows safely below.
    if active and live_pids and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while {active} active worker lease(s) and live PID(s) "
            f"{sorted(set(live_pids))} exist. Use Graceful Stop or Force Stop first."
        )
    if lease.get("status") == "live_owner" and not args.force_active:
        raise SystemExit(f"Browser profile is still owned by PID {lease.get('owner_pid')}. Stop the old worker/browser first.")
    abandoned_active_leases = active if active and not live_pids else 0
    if abandoned_active_leases:
        print(
            f"Detected {abandoned_active_leases} unexpired database lease(s), but no live crawler/browser PID. "
            "Treating them as abandoned and recovering them safely."
        )

    backup = ""
    if not args.no_backup:
        target = db.with_name(f"{db.stem}.pre_v610_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset = store.reset_in_progress()
    projection = store.backfill_product_projection()
    completeness = store.product_completeness_report()
    ts = now()

    with store.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        stale_runs = int(
            conn.execute("UPDATE crawl_runs SET status='INTERRUPTED',finished_at=? WHERE status='RUNNING'", (ts,)).rowcount
            or 0
        )
        incomplete_requeued = int(
            conn.execute(
                """
                UPDATE crawl_queue
                SET status='PENDING',attempts=0,lease_owner='',lease_expires_at='',not_before='',
                    last_error='Requeued by v6.10 adaptive coverage and payload recovery',updated_at=?
                WHERE status='DONE_INCOMPLETE'
                """,
                (ts,),
            ).rowcount
            or 0
        )

        source_requeued = 0
        if not args.only_incomplete:
            rows = conn.execute(
                """
                SELECT DISTINCT COALESCE(NULLIF(canonical_url,''),url) AS source_url,page_type
                FROM sources
                WHERE COALESCE(NULLIF(canonical_url,''),url)<>''
                """
            ).fetchall()
            for row in rows:
                url = str(row["source_url"] or "")
                if not url:
                    continue
                resource_class = classify_frontier_url(url)
                source_requeued += int(
                    conn.execute(
                        """
                        UPDATE crawl_queue
                        SET status='PENDING',attempts=0,lease_owner='',lease_expires_at='',not_before='',
                            last_error='One-time v6.10 replay for resilient extraction normalization',updated_at=?
                        WHERE url=? AND status NOT IN ('SKIPPED_PERMANENT','BLOCKED_CONFIGURATION')
                        """,
                        (ts, url),
                    ).rowcount
                    or 0
                )
                existing = conn.execute("SELECT 1 FROM crawl_queue WHERE url=?", (url,)).fetchone()
                if not existing:
                    conn.execute(
                        """
                        INSERT INTO crawl_queue(
                            url,depth,priority,parent_url,relation,status,attempts,last_error,
                            discovered_at,updated_at,resource_class,lane_priority
                        )
                        VALUES(?,0,5,'','UPGRADE_REPLAY','PENDING',0,
                               'One-time v6.10 replay for resilient extraction normalization',?,?,?,?)
                        """,
                        (url, ts, ts, resource_class, lane_priority(resource_class)),
                    )
                    source_requeued += 1
        conn.commit()

    detail_requeued = 0
    for item in completeness.get("incomplete_products") or []:
        url = str(item.get("product_url") or "")
        if not url or "/spd/" not in url.lower():
            continue
        store.enqueue(
            url,
            depth=1,
            priority=1,
            parent_url=str(item.get("source_url") or ""),
            relation="HAS_PRODUCT_DETAIL",
            resource_class=PAGE,
        )
        with store.connect() as conn:
            detail_requeued += int(
                conn.execute(
                    """
                    UPDATE crawl_queue
                    SET status='PENDING',priority=1,lane_priority=?,attempts=0,lease_owner='',lease_expires_at='',not_before='',
                        last_error='Adaptive product fields incomplete; requeued by v6.10',updated_at=?
                    WHERE url=? AND status<>'SKIPPED_PERMANENT'
                    """,
                    (lane_priority(PAGE), ts, url),
                ).rowcount
                or 0
            )

    completeness = store.product_completeness_report()
    product_report = knowledge / "PRODUCT_COMPLETENESS_REPORT.json"
    product_report.write_text(json.dumps(completeness, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    report = {
        "migration": "v6.9/v6.10 -> v6.10.1",
        "database": str(db),
        "knowledge": str(knowledge),
        "sqlite_integrity": integrity,
        "backup": backup,
        "profile_lease": lease,
        "runtime_process_state": runtime_state,
        "unexpired_worker_leases_before_repair": active,
        "abandoned_unexpired_leases_recovered": abandoned_active_leases,
        "reset_in_progress": int(reset),
        "stale_runs_closed": stale_runs,
        "done_incomplete_requeued": incomplete_requeued,
        "stored_sources_requeued_for_one_time_replay": source_requeued,
        "adaptive_product_detail_urls_requeued": detail_requeued,
        "product_projection": projection,
        "product_completeness": completeness,
        "product_completeness_report": str(product_report),
        "stats": store.stats(),
        "v610_contract": {
            "tolerant_json_parser": True,
            "single_repair_attempt_for_invalid_aia_json": True,
            "payload_alias_normalisation": True,
            "unsupported_fields_preserved_as_unmapped_evidence": True,
            "cached_text_payloads_normalised_on_replay": True,
            "adaptive_product_completeness": True,
            "page_specific_topic_applicability": True,
            "recoverable_coverage_separated_from_terminal_failures": True,
            "access_blocks_and_corrupt_content_remain_terminal": True,
        },
    }
    output = knowledge / "V610_REPAIR_REPORT.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
