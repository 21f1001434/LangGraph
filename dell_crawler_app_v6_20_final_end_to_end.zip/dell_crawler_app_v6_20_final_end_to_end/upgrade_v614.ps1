$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
python .\repair_v614.py --db knowledge\dell_en_uk.db --knowledge knowledge
python -m streamlit run .\app.py
