from __future__ import annotations

import argparse
import csv
import json
import sqlite3
from pathlib import Path
from typing import Any


def main() -> int:
    parser = argparse.ArgumentParser(description="Export the normalized Dell product catalogue from SQLite.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--csv", default="knowledge/PRODUCT_CATALOG.csv")
    parser.add_argument("--json", dest="json_path", default="knowledge/PRODUCT_CATALOG.json")
    parser.add_argument("--minimum-completeness", type=float, default=0.0)
    args = parser.parse_args()

    db = Path(args.db)
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT * FROM product_catalog_view
            WHERE COALESCE(completeness_score,0) >= ?
            ORDER BY COALESCE(completeness_score,0) DESC, product_name COLLATE NOCASE
            """,
            (float(args.minimum_completeness),),
        ).fetchall()
    finally:
        conn.close()

    records: list[dict[str, Any]] = [dict(row) for row in rows]
    csv_path = Path(args.csv)
    json_path = Path(args.json_path)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(records[0].keys()) if records else []
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        if fields:
            writer.writeheader()
            writer.writerows(records)
    json_path.write_text(json.dumps(records, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"products": len(records), "csv": str(csv_path), "json": str(json_path)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
