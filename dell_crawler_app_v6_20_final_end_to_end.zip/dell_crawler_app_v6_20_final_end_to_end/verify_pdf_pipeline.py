from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path
from typing import Any

from dell_crawler_core.document_pipeline import normalize_pdf_download_url, validate_pdf_file


def scalar(conn: sqlite3.Connection, sql: str, params: tuple[Any, ...] = ()) -> int:
    row = conn.execute(sql, params).fetchone()
    return int(row[0] or 0) if row else 0


def read_jsonl(path: Path, limit: int = 10000) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]:
        if not raw.strip():
            continue
        try:
            value = json.loads(raw)
        except Exception:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify whether Dell PDF download, extraction, vision and persistence are working.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="", help="Knowledge directory; defaults to database parent.")
    parser.add_argument("--require-success", action="store_true", help="Exit non-zero until at least one PDF is extracted from binary bytes or browser-viewer text+vision evidence.")
    parser.add_argument(
        "--require-no-click-http-403",
        action="store_true",
        help="Compatibility check: fail if a browser-context document logged a raw direct HTTP 401/403.",
    )
    parser.add_argument(
        "--require-no-raw-pdf-http",
        action="store_true",
        help="Fail if any post-v6.7 PDF transport event used the standalone direct_http stage.",
    )
    parser.add_argument(
        "--require-no-terminal-validation",
        action="store_true",
        help="Fail if the current v6.10 run has any terminal PDF validation failures.",
    )
    args = parser.parse_args()

    db = Path(args.db).resolve()
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    try:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        queue = {
            str(row["status"]): int(row["n"])
            for row in conn.execute(
                "SELECT status,COUNT(*) n FROM crawl_queue WHERE resource_class='DOCUMENT' GROUP BY status"
            )
        }
        pdf_sources = scalar(
            conn,
            "SELECT COUNT(*) FROM sources WHERE lower(coalesce(mime_type,'')) LIKE '%pdf%' OR lower(url) LIKE '%.pdf%'",
        )
        document_sources = scalar(conn, "SELECT COUNT(*) FROM sources WHERE page_type='Document'")
        browser_viewer_sources = scalar(
            conn,
            """
            SELECT COUNT(*) FROM sources
             WHERE lower(coalesce(mime_type,'')) LIKE '%pdf%'
               AND (
                    lower(coalesce(metadata_json,'')) LIKE '%playwright_pdf_viewer_text_vision%'
                    OR lower(coalesce(metadata_json,'')) LIKE '%"browser_pdf_viewer_processed": true%'
               )
            """,
        )
        pdf_queue = scalar(conn, "SELECT COUNT(*) FROM crawl_queue WHERE lower(url) LIKE '%.pdf%'")
        click_document_rows = [
            dict(row)
            for row in conn.execute(
                """
                SELECT url,parent_url,status,attempts
                  FROM crawl_queue
                 WHERE resource_class='DOCUMENT'
                   AND relation IN ('CONTROL_CLICK_DOCUMENT','CONTROL_BROWSER_CONTEXT_DOCUMENT')
                """
            )
        ]
        recent_failures = [
            dict(row)
            for row in conn.execute(
                """
                SELECT source_url,stage,failure_class,action,status,attempt,detail,observed_at
                  FROM self_heal_events
                 WHERE stage='pdf_document'
                 ORDER BY id DESC LIMIT 12
                """
            )
        ]
    finally:
        conn.close()

    documents_dir = knowledge / "documents"
    valid_local = 0
    invalid_local = 0
    bytes_local = 0
    local_files: list[dict[str, Any]] = []
    if documents_dir.exists():
        for path in sorted(documents_dir.rglob("*.pdf")):
            validation = validate_pdf_file(path, parse_structure=True)
            if validation.ok:
                valid_local += 1
                bytes_local += int(path.stat().st_size)
            else:
                invalid_local += 1
            local_files.append({"path": str(path), **validation.to_dict()})

    transport_events = read_jsonl(knowledge / "PDF_TRANSPORT_EVENTS.jsonl")
    recovery_events = read_jsonl(knowledge / "PDF_RECOVERIES.jsonl")
    success_events = read_jsonl(knowledge / "PDF_SUCCESSES.jsonl")
    terminal_failures = read_jsonl(knowledge / "PDF_FAILURES.jsonl")
    validation_rejections = read_jsonl(knowledge / "PDF_VALIDATION_REJECTIONS.jsonl")
    direct_403_events = [
        row for row in transport_events
        if str(row.get("stage") or "") == "direct_http"
        and int(row.get("http_status") or 0) in {401, 403}
    ]
    click_document_keys = {normalize_pdf_download_url(str(row.get("url") or "")) for row in click_document_rows}
    click_http_403_events = [
        row for row in direct_403_events
        if normalize_pdf_download_url(str(row.get("url") or row.get("request_url") or ""))
        in click_document_keys
    ]
    browser_context_recoveries = [
        row for row in recovery_events
        if str(row.get("strategy") or row.get("recovery_strategy") or "").startswith((
            "playwright_browser_context_",
            "playwright_unique_source_control_",
            "playwright_source_control_",
        ))
    ]
    browser_context_successes = [
        row for row in success_events
        if str(row.get("download_strategy") or row.get("fetch_mode") or "").startswith((
            "playwright_browser_context_",
            "playwright_unique_source_control_",
            "playwright_source_control_",
        ))
    ]

    terminal_validation_failures = [
        row for row in terminal_failures
        if bool(row.get("terminal_validation_failure"))
        or "validation" in str(row.get("stage") or "").casefold()
        or "documentvalidationerror" in str(row.get("error") or "").casefold()
    ]
    recovered_after_rejection = [
        row for row in [*recovery_events, *success_events]
        if bool(row.get("recovered_after_validation_rejection"))
    ]
    rejection_groups: dict[str, int] = {}
    for row in validation_rejections:
        key = "|".join((
            normalize_pdf_download_url(str(row.get("url") or "")),
            str(row.get("stage") or ""),
            str(row.get("reason") or ""),
        ))
        rejection_groups[key] = rejection_groups.get(key, 0) + 1
    duplicate_rejection_groups = {key: value for key, value in rejection_groups.items() if value > 1}

    binary_working = bool(valid_local > 0)
    viewer_working = bool(browser_viewer_sources > 0)
    working = bool(pdf_sources > 0 and (binary_working or viewer_working) and queue.get("DONE", 0) > 0)
    report = {
        "database": str(db),
        "knowledge": str(knowledge),
        "sqlite_integrity": integrity,
        "pdf_working": working,
        "pdf_sources": pdf_sources,
        "document_sources": document_sources,
        "browser_viewer_sources": browser_viewer_sources,
        "pdf_queue_total": pdf_queue,
        "document_queue": queue,
        "valid_local_pdfs": valid_local,
        "invalid_local_pdfs": invalid_local,
        "local_pdf_bytes": bytes_local,
        "local_files": local_files[-25:],
        "transport_event_count": len(transport_events),
        "direct_http_401_403_count": len(direct_403_events),
        "click_first_document_count": len(click_document_rows),
        "click_first_direct_http_401_403_count": len(click_http_403_events),
        "browser_context_document_count": len(click_document_rows),
        "browser_context_recovery_count": len(browser_context_recoveries),
        "browser_context_success_count": len(browser_context_successes),
        "raw_direct_http_event_count": len([row for row in transport_events if str(row.get("stage") or "") == "direct_http"]),
        "browser_recovery_count": len(recovery_events),
        "pdf_success_log_count": len(success_events),
        "candidate_validation_rejection_count": len(validation_rejections),
        "recovered_after_validation_rejection_count": len(recovered_after_rejection),
        "duplicate_validation_rejection_groups": duplicate_rejection_groups,
        "terminal_pdf_failure_count": len(terminal_failures),
        "terminal_pdf_validation_failure_count": len(terminal_validation_failures),
        "latest_pdf_success": success_events[-1] if success_events else {},
        "latest_pdf_recovery": recovery_events[-1] if recovery_events else {},
        "latest_terminal_pdf_failure": terminal_failures[-1] if terminal_failures else {},
        "recent_pdf_recovery_events": recent_failures,
        "interpretation": (
            "v6.10 retains the real source-page button click first for button-linked PDFs, then captures the browser download, exact network body, "
            "or browser-viewer text plus screenshots. Browser-context requests are bounded fallbacks and standalone raw PDF HTTP is disabled. "
            "Candidate validation rejections are recoverable diagnostics in PDF_VALIDATION_REJECTIONS.jsonl; only PDF_FAILURES.jsonl terminal records "
            "represent unresolved document failures."
        ),
        "success_criteria": {
            "pdf_sources_gt_zero": pdf_sources > 0,
            "valid_local_pdfs_or_browser_viewer_evidence": binary_working or viewer_working,
            "valid_local_pdfs_gt_zero": valid_local > 0,
            "browser_viewer_sources_gt_zero": browser_viewer_sources > 0,
            "document_done_gt_zero": queue.get("DONE", 0) > 0,
            "no_direct_http_401_403_for_browser_context_documents": len(click_http_403_events) == 0,
            "no_raw_direct_http_pdf_events": len([row for row in transport_events if str(row.get("stage") or "") == "direct_http"]) == 0,
            "no_terminal_pdf_validation_failures": len(terminal_validation_failures) == 0,
            "validation_rejections_are_deduplicated": not duplicate_rejection_groups,
        },
    }
    out = knowledge / "PDF_PIPELINE_STATUS.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nStatus report: {out}")
    if args.require_success and not working:
        return 2
    if args.require_no_click_http_403 and click_http_403_events:
        return 3
    if args.require_no_raw_pdf_http and any(str(row.get("stage") or "") == "direct_http" for row in transport_events):
        return 4
    if args.require_no_terminal_validation and terminal_validation_failures:
        return 5
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
