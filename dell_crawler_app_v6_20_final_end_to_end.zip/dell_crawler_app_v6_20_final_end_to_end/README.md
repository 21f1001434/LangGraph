# v6.20 final release

v6.20 adds automatic safe cleanup of irrelevant legacy database/runtime data during repair/upgrade. It creates a backup first, preserves semantic knowledge/evidence/product history and learned `action_policy_memory`, removes stale telemetry/orphans/empty tombstones, validates foreign keys/integrity, and vacuums the SQLite database. See `V6_20_SAFE_DATABASE_CLEANUP.md`.

# Dell.com Autonomous Knowledge Crawler v6.19

## v6.19 final market-aware classified release

v6.19 is the final verification hardening release. It keeps the v6.18 classified/consolidated graph model and adds market-correct extraction so US/India/Canada/Australia/EU evidence is no longer stamped as UK/GBP. Category and ProductFamily naming variants are consolidated before export; third-party products are not automatically branded Dell or model-only merged without brand evidence; and Dell AIA text/vision prompts are constrained to the bounded ontology so CPU/GPU/RAM/storage/display/OS/battery/color remain Product facts instead of scattered nodes. Locale correctness now also covers HTTP/PDF request language, support archetypes, hreflang filtering, blog scope, browser PDF requests and country-first Dell locale aliases.

For an existing database, use **Graceful Stop** and run:

```powershell
python .\repair_v619.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v619.py --db knowledge\dell_en_uk.db --require-clean
python .\release_verify_v619.py --db knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

A clean v6.19 graph requires `unclassified_semantic_nodes = 0`, `duplicate_semantic_identity_pairs = 0`, `duplicate_product_identity_pairs = 0`, `currency_market_mismatches = 0`, `products_with_price_without_currency = 0`, `node_classification_coverage = 1.0`, and `clean_for_semantic_sync = true`.

See `V6_19_FINAL_MARKET_AWARE_VALIDATED_CRAWLER.md`.

## Previous release history

## v6.17 final verified release

v6.17 adds a final semantic relationship validity gate and a reproducible release/runtime verifier on top of the v6.16 compact crawler. Unresolved local relationship references are now retained as evidence rather than counted as graph relationships. Use `repair_v617.py`, `audit_knowledge_v617.py --require-clean`, and `release_verify_v617.py` before a long upgraded crawl. See `V6_17_FINAL_VERIFICATION.md`.

## v6.17 validated compact semantic crawler

v6.17 fixes the over-fragmented graph at crawler ingestion time. Discovered but unfetched links are stored as `link_evidence` instead of placeholder graph nodes; arbitrary/weak model entities are validated before graph admission and retained as evidence when rejected; generic Concept/Section noise is compacted; Product identity is deduplicated with strong Dell identifiers; and normalized exact-content hashing prevents repeated extraction for aliases/DOM whitespace churn. Product enrichment, full masthead discovery, Dell SSO read-only account crawling, PDFs/vision and the broader Dell knowledge frontier remain enabled.

For an existing database, use **Graceful Stop** and run:

```powershell
python .\repair_v616.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v617.py --db knowledge\dell_en_uk.db --require-clean
python -m streamlit run .\app.py
```

See `V6_16_VALIDATED_END_TO_END_CRAWLER.md`.


## v6.14 full masthead/tab extraction

v6.14 verifies and explicitly crawls the complete live Dell masthead rather than relying only on sitemap/recursive links. It expands **Artificial Intelligence, IT Infrastructure, Computers & Accessories, Services, Support, Deals, Financing**, their safe nested flyouts, and the authenticated **Account / Profile** menu. The resulting pages enter the existing canonical frontier, so repeated global-menu links do not cause repeated extraction.

It writes `knowledge/MASTHEAD_TAXONOMY_REPORT.json` so you can see which menu labels were observed, which URLs were queued, and any partial/missing tab coverage. Transactional controls such as Make a Payment, checkout, sign-in/sign-out and account mutations are recorded but never activated. Use `DELL_LOCALE=en-us` to match the screenshots or keep `en-uk` for the existing UK database.

For an existing database, Graceful Stop first and run `python .\repair_v614.py --db knowledge\dell_en_uk.db --knowledge knowledge`, then start Streamlit and click **Start / Resume**.



## v6.13 full Dell knowledge + anti-repeat crawler

v6.13 prevents the crawler from repeatedly spending extraction work on URL aliases or identical rendered evidence, while keeping **bounded targeted revisits** for products that genuinely still lack price/applicable specs/exact PDP identity or contain unresolved unmapped evidence. It also reuses the persistent Dell SSO browser session to crawl read-only My Account knowledge (overview, orders, profile settings, saved items, My Products/devices, and Rewards) after the deterministic email → Login/Continue → SSO-available → Login/Continue handoff. Passwords, OTPs, payment data and account mutations are never automated.

Run `repair_v613.py` once on an existing database; unlike v6.12 it does **not** blindly requeue every `DONE_INCOMPLETE` page. See `V6_13_FULL_DELL_KNOWLEDGE.md`.

A resumable, provenance-first crawler for Dell knowledge in the configured locale. It combines Playwright MCP, Dell AIA text and vision models, ReAct/self-healing, a durable SQLite frontier and Knowledge Graph, coherent product extraction, click-first PDF recovery, full document text/visual processing, and JSON/GraphML/catalog exports.




## v6.12 autonomous product completion

v6.12 automatically revisits canonical products that still have **no price, missing applicable specifications, no exact Dell product-detail URL, or unresolved/unmapped evidence**. This happens inside the same crawler run: when the normal frontier drains, the worker audits product completeness, requeues the exact `/spd/`/`/apd/` detail page (or revisits the source catalog to recover the identity), re-extracts the rendered page, maps known aliases/nested evidence, merges recovered facts into the canonical Product, and repeats with bounded no-gain/attempt limits. It never fabricates an unavailable Dell value.

For an existing database, use **Graceful Stop** and run:

```powershell
python .\repair_v612.py --db knowledge\dell_en_uk.db --knowledge knowledge
python -m streamlit run .\app.py
```

Then click **Start / Resume**. The crawler continues product-completion sweeps automatically; you do not need to run repair again. See `V6_12_AUTONOMOUS_PRODUCT_COMPLETION.md`.

## v6.11 extractor-quality fix

v6.11 prevents Dell image/static URLs from becoming Product identities, recovers contaminated Product nodes into stable order/part/model/detail-URL identities, recognizes SPD/APD product routes, adds product-detail page fallback extraction, replays stored product evidence without deleting it, and requeues incomplete exact product URLs for enrichment. Run `python .\repair_v611.py --db knowledge\dell_en_uk.db --knowledge knowledge` once after a graceful stop. See `V6_11_EXTRACTOR_QUALITY_FIX.md`.

## v6.10.1 repair hotfix

This hotfix addresses the two errors visible after stopping the Streamlit UI:

- an unexpired SQLite worker lease was treated as a live crawler even when no crawler, worker, or browser-profile owner process was running;
- the one-time source replay insert supplied 13 SQL values for 12 columns when a stored source did not already have a queue row.

`repair_v610.py` now checks real runtime PIDs, removes stale PID/profile markers, safely resets orphaned `IN_PROGRESS` rows, and uses the corrected replay insert. A genuinely live crawler process still blocks repair unless `--force-active` is explicitly supplied.

## What v6.10 fixes

The earlier package correctly separated recoverable PDF candidates from terminal PDF failures, but live runs could still show many validation issues for three reasons:

1. Dell AIA responses that contained valid information in fenced, single-quoted, trailing-comma, array-wrapped, or token-truncated JSON were treated as invalid.
2. Every product was scored against the same fields, so servers were penalized for no display, monitors for no operating system, and pages without ratings for no review count.
3. A page archetype listed every section that might exist, and optional sections not present on a specific page could be counted as extraction gaps.

v6.10 changes the pipeline:

```text
Captured Dell evidence
        ↓
Deterministic extraction always retained
        ↓
Dell AIA JSON mode
        ↓
Tolerant parser + one bounded repair attempt
        ↓
Payload normalizer
  • aliases accepted
  • singleton/list shape differences accepted
  • relation references repaired structurally
  • unsupported fields preserved as unmapped evidence
        ↓
Category-aware product completeness
        ↓
Page-specific coverage contract
  • exposed-but-missing section → recoverable retry
  • section not exposed on this URL → informational only
  • access block/corrupt/unusable response → terminal failure
```

No usable evidence is discarded merely because a model used a slightly different JSON shape. Unknown fields are stored in `unmapped_evidence` with provenance rather than silently dropped.

## Validation meaning in the dashboard

- **Coverage recovery pending**: the page exposed content that still needs a retry, such as an unexpanded review section. It is not a terminal failure.
- **Product enrichment pending**: a product detail URL is queued because an applicable field advertised by that source is missing.
- **JSON/payload repairs**: malformed or non-standard model output was normalized successfully.
- **Unmapped evidence preserved**: additional model fields were retained instead of discarded.
- **Intermediate rejects**: invalid or incomplete PDF acquisition candidates rejected before another browser recovery strategy succeeded.
- **Terminal validation / terminal coverage**: all configured recovery paths were exhausted, or the response was an access block/corrupt payload.

## Product completeness is now adaptive

Examples:

- PowerEdge server: processor, memory and storage are applicable; display and desktop operating system are not automatically required.
- Monitor: display is applicable; processor, storage and operating system are not automatically required.
- Laptop: processor, memory, storage, display and operating system are applicable; graphics becomes applicable when the page advertises it or the product family implies it.
- Commerce page: price is required only when the page exposes commerce/price evidence.
- Ratings and review count are required only when review evidence is exposed.

The normalized view remains:

```sql
SELECT *
FROM product_catalog_view
ORDER BY completeness_score DESC, product_name;
```

## Upgrade an existing v6.9/v6.10/v6.11 crawl

### 1. Stop safely

Use **Graceful Stop** and wait for the supervisor and worker to show **Stopped**. Close older crawler terminals using the same browser profile.

### 2. Preserve runtime data

If you are moving into a new v6.12 folder, copy your existing `.env`, `knowledge\` directory and browser profile. Keep `knowledge\dell_en_uk.db`, downloaded documents, screenshots, caches and exports.

### 3. Run the v6.12 repair once

```powershell
python -m pip install -r requirements.txt
python .\repair_v612.py --db knowledge\dell_en_uk.db --knowledge knowledge
python -m streamlit run .\app.py
```

Or use:

```powershell
.\upgrade_v612.ps1
```

`repair_v612.py` creates a SQLite-consistent backup, recovers stale worker state, replays stored product evidence, repairs media-URL Product contamination, rebuilds product projections, requeues recoverable incomplete pages, and primes the first autonomous product-completion sweep. After that, **Start / Resume** handles later revisits automatically; do not repeatedly run the repair script.

## Fresh installation

For the v6.12 package:

```powershell
cd dell_crawler_app_v6_12_autonomous_product_completion
.\setup.ps1
.\run_app.ps1
```

For an upgraded database, `upgrade_v612.ps1` runs the one-time repair and then launches Streamlit.

Or:

```bat
setup.bat
run_app.bat
```

If Playwright MCP cannot launch a browser, run `install_mcp_browser.ps1` or select an installed Edge/Chrome channel in the UI.

## Verify before a long run

```powershell
python -m compileall -q .
pytest -q
python verify_product_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge
python verify_pdf_pipeline.py --db knowledge\dell_en_uk.db --knowledge knowledge --require-no-raw-pdf-http --require-no-terminal-validation
```

The packaged v6.13 validation suite contains 132 passing tests, including malformed/truncated JSON recovery, unknown-field preservation, adaptive product scoring, page-specific coverage applicability, coherent product extraction, PDF browser recovery and validation-truth tests.

## PDF acquisition retained from v6.9

For a brochure, spec sheet, whitepaper or manual exposed by a Dell page control:

```text
Restore source page
      ↓
Click the real visible PDF control
      ↓
Capture browser download, exact network body, or browser PDF viewer
      ↓
Wait for file size to settle
      ↓
Validate PDF signature and structure
      ↓
Extract all text and render visual pages
      ↓
Persist document, sections, facts, entities, links and provenance
```

A browser-context request remains a bounded fallback. Standalone raw PDF HTTP is disabled by default. Valid signed/redirected browser PDFs are retained with URL-alias provenance rather than rejected solely because the final URL changed.

Proof files:

```text
knowledge\PDF_PIPELINE_STATUS.json
knowledge\PDF_SUCCESSES.jsonl
knowledge\PDF_RECOVERIES.jsonl
knowledge\PDF_VALIDATION_REJECTIONS.jsonl
knowledge\PDF_FAILURES.jsonl
```

`PDF_FAILURES.jsonl` contains terminal failures only.

## Export the normalized catalogue

```powershell
python export_product_catalog.py --db knowledge\dell_en_uk.db --csv knowledge\PRODUCT_CATALOG.csv --json knowledge\PRODUCT_CATALOG.json
```

## Scope and truthful limits

The crawler continues through the allowed public Dell UK frontier without a fixed page/depth/document limit. It covers pages, dynamic controls, reviews, offers, configurations, specifications, documents, images, public JSON/XML, open shadow roots and same-origin iframes.

It is read-only. It does not purchase products, mutate carts/accounts, submit forms, bypass authentication/CAPTCHA, or circumvent access controls.

No crawler can guarantee access to private content outside the signed-in account, expired, geo-restricted, unlinked or server-side undiscoverable content. v6.13 retains processed evidence, normalizes recoverable formatting/mapping problems, revisits incomplete products automatically, and keeps true unresolved access/corruption/unpublished-value gaps visible rather than inventing data.

## v6.15 canonical knowledge mapping

v6.15 prevents arbitrary LLM/schema.org types and unresolved relationship placeholders from
fragmenting the Knowledge Graph. Product identity is kept separate from Page identity, media URLs
cannot become Product URLs, and historical data can be repaired with:

```powershell
python .\repair_v615.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v615.py --db knowledge\dell_en_uk.db
```

The repair preserves source evidence and writes `knowledge/CANONICAL_KG_VALIDATION_V615.json`.
