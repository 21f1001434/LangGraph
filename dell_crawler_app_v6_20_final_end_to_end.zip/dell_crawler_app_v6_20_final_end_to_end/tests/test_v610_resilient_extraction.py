from __future__ import annotations

from dell_crawler_core.coverage_audit import audit_page
from dell_crawler_core.crawl_models import CrawlPage, SafeControl
from dell_crawler_core.extraction_normalizer import normalize_extraction_payload
from dell_crawler_core.product_intelligence import adaptive_product_completeness
from dell_crawler_core.utils import extract_json_object


def test_v610_json_parser_recovers_common_model_formatting() -> None:
    raw = """Explanation before data
```json
{'products': [{'name': 'Dell Pro Max', 'price': '£1,999'},], 'warnings': [],}
```
"""
    parsed = extract_json_object(raw)
    assert parsed is not None
    assert parsed["products"][0]["name"] == "Dell Pro Max"


def test_v610_json_parser_closes_token_limited_container() -> None:
    parsed = extract_json_object('{"entities":[{"name":"Dell PowerEdge"}],"facts":[')
    assert parsed is not None
    assert parsed["entities"][0]["name"] == "Dell PowerEdge"
    assert parsed["facts"] == []


def test_v610_payload_normalizer_preserves_aliases_and_unknown_fields() -> None:
    payload = {
        "products": [{"name": "Dell Pro Max", "url": "/en-uk/shop/test", "processor": "Intel Core Ultra"}],
        "specs": {"memory": "64 GB DDR5"},
        "links": {"label": "Brochure", "href": "/docs/test.pdf"},
        "custom_analysis": {"why_it_matters": "Workstation use case"},
    }
    normalized = normalize_extraction_payload(payload, source_url="https://www.dell.com/en-uk/page")
    assert any(item["type"] == "Product" for item in normalized["entities"])
    assert any(item["predicate"] == "MEMORY" for item in normalized["facts"])
    assert normalized["endpoints"][0]["url"] == "https://www.dell.com/docs/test.pdf"
    assert normalized["unmapped_evidence"][0]["field"] == "custom_analysis"


def test_v610_product_completeness_is_category_aware() -> None:
    score, missing, applicable = adaptive_product_completeness(
        {
            "product_name": "Dell PowerEdge R760 Server",
            "product_url": "https://www.dell.com/en-uk/shop/servers/poweredge-r760/spd/poweredge-r760",
            "price": "5999.00",
            "processor": "Intel Xeon Gold",
            "memory": "256 GB DDR5 ECC",
            "storage": "3.84 TB NVMe SSD",
            "category": "Server",
        }
    )
    assert score == 1.0
    assert "display" not in applicable
    assert "operating_system" not in applicable
    assert missing == []


def _base_page(*, controls: list[SafeControl] | None = None) -> CrawlPage:
    return CrawlPage(
        url="https://www.dell.com/en-uk/shop/test/spd/model",
        canonical_url="https://www.dell.com/en-uk/shop/test/spd/model",
        title="Dell Test Product",
        page_type="Product",
        snapshot="",
        visible_text=("Dell Test Product overview with public product information. " * 20),
        links=[],
        controls=controls or [],
        metadata={
            "dell_page_archetype": {"expected_topics": ["tech specs", "offers", "accessories"]},
            "repeatable_controls_complete": True,
            "browser_structured_dom": {"ok": True},
            "html_enrichment": {"counts": {}},
            "network_inventory": {"request_count": 1},
        },
    )


def test_v610_unexposed_optional_topics_are_not_validation_failures() -> None:
    audit = audit_page(_base_page())
    assert audit.passed is True
    assert audit.missing_topics == []
    assert set(audit.not_observed_topics) == {"tech specs", "offers", "accessories"}


def test_v610_exposed_but_unextracted_topic_remains_recoverable() -> None:
    page = _base_page(
        controls=[SafeControl(label="Tech Specs", ref="button-1", role="button", context="Open technical specifications")]
    )
    audit = audit_page(page)
    assert audit.passed is False
    assert audit.status == "recoverable"
    assert "tech specs" in audit.missing_topics
    assert audit.hard_failures == []
