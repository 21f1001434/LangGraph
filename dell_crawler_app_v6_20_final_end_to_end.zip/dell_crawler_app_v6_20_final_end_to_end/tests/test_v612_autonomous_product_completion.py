from __future__ import annotations

from pathlib import Path

from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.product_intelligence import (
    bind_page_product_evidence,
    normalized_product_attribute,
)


def test_loose_product_field_aliases_map_to_canonical_projection():
    assert normalized_product_attribute("CPU Model") == "processor"
    assert normalized_product_attribute("ramCapacity") == "memory"
    assert normalized_product_attribute("SSD Capacity") == "storage"
    assert normalized_product_attribute("currentPriceGBP") == "price"
    assert normalized_product_attribute("operatingSystem") == "operating_system"
    assert normalized_product_attribute("totally_unknown_analysis") == ""


def test_product_detail_page_binds_page_and_unmapped_evidence_to_product():
    url = "https://www.dell.com/en-uk/shop/dell-laptops/dell-pro/spd/dell-pro-pc14250-laptop/test"
    page = CrawlPage(
        url=url,
        canonical_url=url,
        title="Dell Pro PC14250 Laptop",
        page_type="Product",
        snapshot="",
        visible_text="Dell Pro PC14250 Laptop",
        metadata={},
    )
    extraction = {
        "entities": [
            {
                "key": "product_record_0",
                "node_key": f"url:{url}",
                "type": "Product",
                "name": "Dell Pro PC14250 Laptop",
                "attributes": {"url": url, "product_url": url, "source_url": url},
            }
        ],
        "product_records": [
            {
                "node_key": f"url:{url}",
                "name": "Dell Pro PC14250 Laptop",
                "attributes": {"url": url, "product_url": url, "source_url": url},
            }
        ],
        "facts": [
            {"subject_key": "page", "predicate": "CPU Model", "value": "Intel Core Ultra 7 265U", "confidence": 0.8},
        ],
        "unmapped_evidence": [
            {"field": "technicalSpecifications", "value": {"ramCapacity": "32 GB DDR5", "ssdCapacity": "1 TB NVMe SSD"}, "evidence_kind": "text"},
            {"field": "currentPriceGBP", "value": "£1,299.00", "evidence_kind": "text"},
            {"field": "marketing_commentary", "value": "Unstructured prose", "evidence_kind": "text"},
        ],
        "normalization_notes": [],
    }

    result = bind_page_product_evidence(page, extraction)
    attrs = extraction["product_records"][0]["attributes"]
    assert attrs["processor"] == "Intel Core Ultra 7 265U"
    assert attrs["memory"] == "32 GB DDR5"
    assert attrs["storage"] == "1 TB NVMe SSD"
    assert attrs["price"] == "£1,299.00"
    assert result["unmapped_fields_mapped"] == 2
    assert result["unmapped_fields_remaining"] == 1
    assert extraction["unmapped_evidence"][0]["field"] == "marketing_commentary"
    product_facts = [f for f in extraction["facts"] if f.get("subject_key") == "product_record_0"]
    assert {f["predicate"] for f in product_facts} >= {"CPU", "MEMORY", "STORAGE", "PRICE_GBP"}


def test_incomplete_product_is_requeued_then_marked_complete(tmp_path: Path):
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    pdp = "https://www.dell.com/en-uk/shop/laptops/test/spd/test-laptop/config"
    key = f"url:{pdp}"
    store.upsert_node(
        key,
        "Product",
        "Dell Test Laptop",
        {
            "product_url": pdp,
            "url": pdp,
            "source_url": pdp,
            "product_category": "Laptop",
            "model": "TEST-14",
        },
    )
    store.refresh_product_projection(key)

    first = store.schedule_product_revisit_sweep(max_attempts=4, no_gain_limit=2)
    assert first["products_needing_revisit"] == 1
    assert first["urls_requeued"] == 1
    queued = store.queue_item(pdp)
    assert queued and queued["status"] == "PENDING"
    assert queued["relation"] == "PRODUCT_DETAIL_ENRICHMENT"

    # Simulate the revisit recovering the missing commerce/spec fields.
    store.upsert_node(
        key,
        "Product",
        "Dell Test Laptop",
        {
            "product_url": pdp,
            "url": pdp,
            "source_url": pdp,
            "product_category": "Laptop",
            "model": "TEST-14",
            "price": "1299.00",
            "current_price": "1299.00",
            "processor": "Intel Core Ultra 7",
            "graphics": "Intel Arc Graphics",
            "memory": "32 GB DDR5",
            "storage": "1 TB NVMe SSD",
            "display": "14 inch QHD+",
            "operating_system": "Windows 11 Pro",
            "unresolved_unmapped_evidence_count": 0,
        },
    )
    second = store.schedule_product_revisit_sweep(max_attempts=4, no_gain_limit=2)
    assert second["products_completed"] == 1
    state = store.product_enrichment_status_report()
    assert state["status_counts"]["COMPLETE"] == 1


def test_missing_pdp_revisits_source_catalog_for_identity_recovery(tmp_path: Path):
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    source = "https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops"
    key = "product-order:abc123"
    store.upsert_node(
        key,
        "Product",
        "Dell Example Laptop",
        {
            "source_url": source,
            "order_code": "ABC123",
            "product_category": "Laptop",
            "price": "999.00",
        },
    )
    store.refresh_product_projection(key)
    sweep = store.schedule_product_revisit_sweep(max_attempts=3)
    assert sweep["identity_recovery_requeues"] == 1
    item = store.queue_item(source)
    assert item and item["relation"] == "PRODUCT_IDENTITY_RECOVERY"


def test_missing_price_and_unmapped_evidence_force_revisit_even_when_score_is_high(tmp_path: Path):
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    pdp = "https://www.dell.com/en-uk/shop/servers/test/spd/test-server/config"
    key = "product-order:srv100"
    store.upsert_node(
        key,
        "Product",
        "Dell Test Server",
        {
            "product_url": pdp,
            "source_url": pdp,
            "order_code": "SRV100",
            "product_category": "Server",
            "processor": "Intel Xeon",
            "memory": "64 GB",
            "storage": "2 TB SSD",
            "unresolved_unmapped_evidence_count": 1,
        },
    )
    store.refresh_product_projection(key)
    sweep = store.schedule_product_revisit_sweep(max_attempts=4, no_gain_limit=2)
    assert sweep["urls_requeued"] == 1
    state = store.product_enrichment_status_report()["pending_samples"][0]
    assert "missing_price" in state["last_reason"]
    assert "unmapped=1" in state["last_reason"]


def test_no_gain_revisits_are_bounded_and_exhaustion_is_not_double_counted(tmp_path: Path):
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    pdp = "https://www.dell.com/en-uk/shop/laptops/no-gain/spd/no-gain/config"
    key = f"url:{pdp}"
    store.upsert_node(
        key,
        "Product",
        "Dell No Gain Laptop",
        {
            "product_url": pdp,
            "source_url": pdp,
            "product_category": "Laptop",
            "model": "NOGAIN-14",
        },
    )
    store.refresh_product_projection(key)

    first = store.schedule_product_revisit_sweep(max_attempts=8, no_gain_limit=2)
    second = store.schedule_product_revisit_sweep(max_attempts=8, no_gain_limit=2)
    third = store.schedule_product_revisit_sweep(max_attempts=8, no_gain_limit=2)
    fourth = store.schedule_product_revisit_sweep(max_attempts=8, no_gain_limit=2)

    assert first["urls_requeued"] == 1
    assert second["urls_requeued"] == 1
    assert third["products_exhausted"] == 1
    assert third["urls_requeued"] == 0
    assert fourth["products_exhausted"] == 0
    assert fourth["urls_requeued"] == 0
    status = store.product_enrichment_status_report()["status_counts"]
    assert status["EXHAUSTED_NO_GAIN"] == 1
