from __future__ import annotations

import json
import logging
import threading
from pathlib import Path

from dell_crawler_core.crawl_models import CrawlConfig
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.mcp_runtime import (
    AsyncLoopThread,
    PlaywrightMCPRuntime,
    _MCPExpectedShutdownNoiseFilter,
)


def test_shutdown_filter_only_suppresses_expected_close_noise() -> None:
    closing = threading.Event()
    filt = _MCPExpectedShutdownNoiseFilter(closing)
    record = logging.LogRecord(
        name="mcp.client.streamable_http",
        level=logging.ERROR,
        pathname=__file__,
        lineno=1,
        msg="Error parsing SSE message",
        args=(),
        exc_info=None,
    )
    assert filt.filter(record) is True
    closing.set()
    # Without the known exception type, the record must remain visible.
    assert filt.filter(record) is True
    try:
        import anyio
        raise anyio.ClosedResourceError
    except Exception as exc:
        record.exc_info = (type(exc), exc, exc.__traceback__)
    assert filt.filter(record) is False


def test_async_loop_thread_stops_cleanly() -> None:
    import asyncio

    thread = AsyncLoopThread()

    async def sleeper() -> None:
        await asyncio.sleep(3600)

    future = thread.schedule(sleeper())
    thread.stop()
    assert not thread.thread.is_alive()
    assert future.cancelled() or future.done()


def test_v61_document_fallback_defaults_are_enabled() -> None:
    config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    assert config.document_browser_fallback_on_403 is True
    assert config.document_browser_chunk_bytes >= 65536
    assert config.document_browser_single_response_max_bytes >= 1024 * 1024


def test_browser_chunk_parser_accepts_mcp_result() -> None:
    payload = {
        "ok": True,
        "status": 206,
        "contentType": "application/pdf",
        "contentRange": "bytes 0-4/5",
        "contentLength": "5",
        "bytes": 5,
        "base64": "JVBERi0=",
    }

    class FakeRuntime:
        def evaluate_readonly(self, function: str, intent: str = ""):
            assert function.startswith("async () =>")
            return {"ok": True, "detail": "### Result\n" + json.dumps(payload)}

        _parse_json_detail = staticmethod(PlaywrightMCPRuntime._parse_json_detail)

    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.runtime = FakeRuntime()
    parsed = crawler._browser_fetch_resource_chunk("https://www.dell.com/test.pdf", 0, 4)
    assert parsed["status"] == 206
    assert parsed["bytes"] == 5
