from __future__ import annotations

from pathlib import Path

from dell_crawler_core.authenticated_session import DellAuthenticatedSession, safe_authenticated_account_url
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def test_safe_authenticated_account_urls_are_read_only() -> None:
    allowed = [
        "https://www.dell.com/myaccount/en-uk/overview",
        "https://www.dell.com/myaccount/en-uk/orders",
        "https://www.dell.com/myaccount/en-uk/account-settings/profile",
        "https://www.dell.com/myaccount/en-uk/saved-items",
        "https://www.dell.com/myaccount/en-uk/myproducts",
        "https://www.dell.com/myaccount/en-uk/rewards",
    ]
    assert all(safe_authenticated_account_url(url) for url in allowed)
    assert not safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/payment")
    assert not safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/overview?access_token=secret")
    assert not safe_authenticated_account_url("https://evil.example/myaccount/en-uk/overview")


class FakeAuthRuntime:
    def __init__(self) -> None:
        self.stage = 0
        self.typed: list[str] = []
        self.clicks: list[str] = []
        self.output_dir = "."

    def navigate(self, url: str, intent: str = ""):
        self.stage = 0
        return {"ok": True, "detail": url}

    def wait(self, seconds: float, intent: str = ""):
        return {"ok": True}

    def snapshot(self, boxes: bool = True, intent: str = ""):
        if self.stage == 0:
            detail = (
                "Page URL: https://www.dell.com/signin\n"
                "Page Title: Sign In\n"
                '- textbox "Email or Mobile Number" [ref=e1]\n'
                '- button "Login" [ref=e2]'
            )
        elif self.stage == 1:
            detail = (
                "Page URL: https://www.dell.com/signin\n"
                "Page Title: Sign In\n"
                '- textbox "Email or Mobile Number" [ref=e1]\n'
                '- button "Login" [ref=e2]'
            )
        elif self.stage == 2:
            detail = (
                "Page URL: https://www.dell.com/signin\n"
                "Page Title: Sign In\n"
                "SSO is available for this account\n"
                '- button "Login" [ref=e3]'
            )
        else:
            detail = (
                "Page URL: https://www.dell.com/myaccount/en-uk/overview\n"
                "Page Title: My Account\n"
                "Welcome back\n"
                '- link "Profile Settings" [ref=e4]\n'
                "  - /url: /myaccount/en-uk/account-settings/profile"
            )
        return {"ok": True, "detail": detail}

    def type_text(self, ref: str, label: str, text: str, submit: bool = False, slowly: bool = False, intent: str = ""):
        self.typed.append(text)
        self.stage = 1
        return {"ok": True}

    def click(self, ref: str, label: str, intent: str = ""):
        self.clicks.append(label)
        if self.stage == 1:
            self.stage = 2
        elif self.stage == 2:
            self.stage = 3
        return {"ok": True}

    def hover(self, ref: str, label: str, intent: str = ""):
        return {"ok": True}


def test_sso_login_flow_types_email_and_clicks_second_login() -> None:
    runtime = FakeAuthRuntime()
    auth = DellAuthenticatedSession(runtime, email="person@example.com", profile_name="Person", wait_seconds=5)
    result = auth.ensure_authenticated()
    assert result.authenticated is True
    assert runtime.typed == ["person@example.com"]
    assert runtime.clicks == ["Login", "Login"]
    assert "login_handoff_1" in result.steps and "login_handoff_2" in result.steps
    assert not any("password" in value.lower() for value in runtime.typed)


def test_tracking_aliases_share_one_frontier_identity(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    first = "https://www.dell.com/en-uk/shop/test?utm_source=x&gclid=abc"
    second = "https://www.dell.com/en-uk/shop/test?fbclid=def"
    assert store.enqueue(first)
    assert not store.enqueue(second)
    counts = store.queue_counts()
    assert sum(counts.values()) == 1


def test_duplicate_source_for_exact_hash(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.upsert_source(
        "https://www.dell.com/en-uk/a", "https://www.dell.com/en-uk/a", "A", "WebPage",
        "samehash", 200, "", "", "text/html", {},
    )
    found = store.duplicate_source_for_hash("samehash", "https://www.dell.com/en-uk/b")
    assert found and found["url"].endswith("/a")


def test_account_url_filter_rejects_mutations_but_keeps_account_knowledge() -> None:
    # Route-level policy used before account pages enter the durable frontier.
    assert safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/orders")
    assert safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/saved-items")
    assert not safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/checkout")
    assert not safe_authenticated_account_url("https://www.dell.com/myaccount/en-uk/update")
