from __future__ import annotations

import json
from pathlib import Path

import httpx
from PIL import Image, ImageDraw

from dell_crawler_core.browser_pdf_viewer import (
    clean_accessibility_text,
    parse_pdf_page_position,
    perceptual_image_signature,
)
from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def test_pdf_viewer_page_marker_parsing() -> None:
    assert parse_pdf_page_position('Page 7 of 22') == (7, 22)
    assert parse_pdf_page_position('7 / 22 pages') == (7, 22)
    assert parse_pdf_page_position('no marker') == (0, 0)


def test_snapshot_cleanup_removes_ephemeral_refs() -> None:
    value = '### Snapshot\n- document "Page 1 of 2" [ref=e1]\n- text "AI workstation" [box=1,2,3,4]'
    cleaned = clean_accessibility_text(value)
    assert 'Page 1 of 2' in cleaned
    assert 'AI workstation' in cleaned
    assert '[ref=' not in cleaned
    assert '[box=' not in cleaned


def test_perceptual_signature_is_stable_for_same_page(tmp_path: Path) -> None:
    path = tmp_path / 'page.png'
    image = Image.new('RGB', (800, 1000), 'white')
    ImageDraw.Draw(image).text((50, 200), 'PDF page 1', fill='black')
    image.save(path)
    assert perceptual_image_signature(path) == perceptual_image_signature(path)


class FakeAIA:
    vision_model = 'fake-vision'

    def __init__(self) -> None:
        self.vision_calls = 0

    def vision_json(self, path: Path, prompt: str, fallback: dict) -> dict:
        self.vision_calls += 1
        return {
            'summary': f'Vision extracted browser PDF evidence from {Path(path).name}',
            'image_role': 'document_page',
            'visible_text': ['Architecture diagram', 'GPU', 'Memory'],
            'entities': [],
            'relations': [],
            'facts': [
                {
                    'subject_key': 'page',
                    'predicate': 'VISUAL_OBSERVATION',
                    'value': 'Architecture diagram with GPU and memory',
                    'unit': '',
                    'qualifiers': {'evidence_type': 'vision'},
                    'confidence': 0.9,
                }
            ],
            'use_cases': [],
            'questions_answerable': ['What does the PDF diagram show?'],
            'warnings': [],
        }


class FakePDFViewerRuntime:
    def __init__(self, output_dir: Path, url: str) -> None:
        self.started = True
        self.server_url = 'http://127.0.0.1:9999/mcp'
        self.tools = {'browser_snapshot', 'browser_take_screenshot'}
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.url = url
        self.page = 1
        self.current_tab = 0
        self.pdf_open = False

    def tabs(self, action: str, url: str = '', **_: object) -> dict:
        assert action == 'new'
        self.pdf_open = True
        self.url = url
        self.current_tab = 1
        self.page = 1
        return {'ok': True}

    def tab_inventory(self, **_: object) -> list[dict]:
        tabs = [
            {'index': 0, 'url': 'https://www.dell.com/en-uk/source', 'current': self.current_tab == 0},
        ]
        if self.pdf_open:
            tabs.append({'index': 1, 'url': self.url, 'current': self.current_tab == 1})
        return tabs

    def select_tab(self, index: int, **_: object) -> dict:
        self.current_tab = index
        return {'ok': True}

    def close_tab(self, index: int, **_: object) -> dict:
        if index == 1:
            self.pdf_open = False
            self.current_tab = 0
        return {'ok': True}

    def snapshot(self, **_: object) -> dict:
        detail = (
            '### Snapshot\n'
            f'- document "Page {self.page} of 2" [ref=e1]\n'
            f'- text "Browser PDF page {self.page}: Dell AI workstation architecture and requirements" [ref=e2]'
        )
        return {'ok': True, 'detail': detail}

    def evaluate_readonly(self, _expression: str, **_: object) -> dict:
        payload = {
            'url': self.url,
            'title': 'Dell Browser PDF Test',
            'texts': [f'Page {self.page} of 2. Text layer for page {self.page}.'],
            'labels': [f'Page {self.page} of 2'],
        }
        return {'ok': True, 'detail': '### Result\n' + json.dumps(json.dumps(payload))}

    def screenshot(self, filename: str, **_: object) -> dict:
        path = self.output_dir / filename
        image = Image.new('RGB', (900, 1100), 'white')
        draw = ImageDraw.Draw(image)
        draw.rectangle((30, 150, 870, 1040), outline='black', width=4)
        draw.text((80, 220), f'Dell PDF Page {self.page}', fill='black')
        draw.text((80, 280), f'AI workstation architecture page {self.page}', fill='black')
        image.save(path)
        return {'ok': True, 'detail': f'Saved screenshot to {path}'}

    def press_key(self, key: str, **_: object) -> dict:
        if key in {'Control+Home', 'Home'}:
            self.page = 1
        elif key == 'PageDown':
            self.page = min(2, self.page + 1)
        return {'ok': True}

    def wait(self, *_: object, **__: object) -> dict:
        return {'ok': True}


def test_browser_open_pdf_uses_text_and_vision_when_binary_download_fails(tmp_path: Path) -> None:
    pdf_url = 'https://www.delltechnologies.com/asset/en-uk/test/browser-only.pdf'
    knowledge = tmp_path / 'knowledge'
    runtime = FakePDFViewerRuntime(tmp_path / 'mcp', pdf_url)
    aia = FakeAIA()
    store = SQLiteKnowledgeGraph(knowledge / 'dell.db')
    config = CrawlConfig(
        start_urls=['https://www.dell.com/en-uk'],
        use_llm_extraction=False,
        use_vision_extraction=True,
        vision_mode='all',
        vision_pdf_pages=True,
        vision_pdf_every_page=True,
        browser_pdf_viewer_extraction_enabled=True,
        browser_pdf_viewer_text_enabled=True,
        browser_pdf_viewer_vision_enabled=True,
        browser_pdf_viewer_stable_rounds=1,
        browser_pdf_viewer_fallback_guard=8,
        browser_pdf_viewer_wait_seconds=0.0,
    )
    extractor = DellContentExtractor(
        aia=aia,
        use_llm=False,
        use_vision=True,
        vision_cache_dir=knowledge / 'vision_cache',
        text_cache_dir=knowledge / 'text_cache',
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)

    crawler.http.close()
    crawler.http = httpx.Client(
        transport=httpx.MockTransport(lambda request: httpx.Response(403, request=request, text='Forbidden')),
        follow_redirects=True,
    )
    crawler._capture_pdf_network_body = lambda *_args, **_kwargs: False  # type: ignore[method-assign]

    def fail_browser_api(*_args: object, **_kwargs: object):
        raise RuntimeError('browser APIRequestContext deliberately unavailable in test')

    crawler._download_via_browser_api_chunks = fail_browser_api  # type: ignore[method-assign]

    counts = crawler._process_pdf(
        {
            'url': pdf_url,
            'depth': 0,
            'parent_url': 'https://www.dell.com/en-uk/source',
        }
    )

    assert crawler.stats.pdfs_stored == 1
    assert crawler.stats.pdf_binary_files_stored == 0
    assert crawler.stats.pdf_browser_only_processed == 1
    assert crawler.stats.pdf_browser_viewer_viewports >= 2
    assert crawler.stats.pdf_browser_viewer_text_chars > 0
    assert aia.vision_calls >= 2
    assert counts['_completeness_score'] >= 0

    with store.connect() as conn:
        row = conn.execute(
            'SELECT raw_path,mime_type,metadata_json FROM sources WHERE lower(mime_type) LIKE "%pdf%" LIMIT 1'
        ).fetchone()
    assert row is not None
    assert row['raw_path'] == ''
    metadata = json.loads(row['metadata_json'])
    assert metadata['download_strategy'] == 'playwright_pdf_viewer_text_vision'
    assert metadata['browser_pdf_viewer_processed'] is True
    assert metadata['binary_pdf_available'] is False
    assert metadata['vision_evidence_count'] >= 2
    assert len(metadata['visual_evidence']) >= 2
    assert Path(metadata['browser_pdf_viewer_capture']['manifest_path']).exists()
    crawler.http.close()


def test_repair_v64_requeues_document_jobs(tmp_path: Path) -> None:
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    knowledge = tmp_path / 'knowledge'
    knowledge.mkdir()
    db = knowledge / 'dell.db'
    store = SQLiteKnowledgeGraph(db)
    url = 'https://www.delltechnologies.com/asset/en-uk/retry.pdf.external'
    assert store.enqueue(url, resource_class='PAGE')
    store.mark_queue(url, 'DEFERRED', 'previous PDF failure')

    result = subprocess.run(
        [
            sys.executable,
            str(root / 'repair_v64.py'),
            '--db',
            str(db),
            '--knowledge',
            str(knowledge),
            '--no-backup',
        ],
        cwd=root,
        env={**__import__('os').environ, 'PYTHONPATH': str(root)},
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    item = store.queue_item(url)
    assert item is not None
    assert item['resource_class'] == 'DOCUMENT'
    assert item['status'] == 'PENDING'
    report = json.loads((knowledge / 'V64_REPAIR_REPORT.json').read_text(encoding='utf-8'))
    assert report['migration'] == 'v6.3 -> v6.4'


def test_verifier_accepts_persisted_browser_viewer_pdf(tmp_path: Path) -> None:
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    knowledge = tmp_path / 'knowledge'
    knowledge.mkdir()
    db = knowledge / 'dell.db'
    store = SQLiteKnowledgeGraph(db)
    url = 'https://www.delltechnologies.com/asset/en-uk/viewer-only.pdf'
    assert store.enqueue(url, resource_class='DOCUMENT')
    store.mark_queue(url, 'DONE')
    store.upsert_source(
        url,
        url,
        'Viewer-only Dell PDF',
        'Document',
        'abc123',
        200,
        str(knowledge / 'browser_pdf_viewer' / 'page.png'),
        '',
        'application/pdf',
        {
            'download_strategy': 'playwright_pdf_viewer_text_vision',
            'browser_pdf_viewer_processed': True,
            'binary_pdf_available': False,
            'vision_evidence_count': 1,
        },
    )

    result = subprocess.run(
        [
            sys.executable,
            str(root / 'verify_pdf_pipeline.py'),
            '--db',
            str(db),
            '--knowledge',
            str(knowledge),
            '--require-success',
        ],
        cwd=root,
        env={**__import__('os').environ, 'PYTHONPATH': str(root)},
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    report = json.loads((knowledge / 'PDF_PIPELINE_STATUS.json').read_text(encoding='utf-8'))
    assert report['pdf_working'] is True
    assert report['browser_viewer_sources'] == 1
    assert report['valid_local_pdfs'] == 0
