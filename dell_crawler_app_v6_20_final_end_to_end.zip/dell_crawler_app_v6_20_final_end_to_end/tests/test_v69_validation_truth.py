from __future__ import annotations

import io
import json
import threading
import time
from pathlib import Path

from pypdf import PdfWriter

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig, CrawlStats
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.document_pipeline import validate_pdf_file_stable
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def _pdf_bytes(title: str = "Dell validated PDF") -> bytes:
    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": title})
    writer.write(buffer)
    return buffer.getvalue()


class NoopAIA:
    vision_model = ""

    def vision_json(self, *args, **kwargs):
        return kwargs.get("fallback", {})


def _bare_crawler(tmp_path: Path) -> DellEnUkKnowledgeCrawler:
    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    crawler.stats = CrawlStats(run_id="TEST", started_at="2026-08-06T00:00:00+00:00")
    crawler.run_id = "TEST"
    crawler.output_dir = tmp_path
    crawler.document_quarantine_dir = tmp_path / "quarantine"
    crawler.pdf_failure_log = tmp_path / "PDF_FAILURES.jsonl"
    crawler.pdf_validation_log = tmp_path / "PDF_VALIDATION_REJECTIONS.jsonl"
    crawler.pdf_recovery_log = tmp_path / "PDF_RECOVERIES.jsonl"
    crawler.pdf_success_log = tmp_path / "PDF_SUCCESSES.jsonl"
    crawler._emit = lambda *args, **kwargs: None
    return crawler


def test_candidate_validation_rejection_is_not_terminal_failure(tmp_path: Path) -> None:
    crawler = _bare_crawler(tmp_path)
    invalid = tmp_path / "candidate.pdf"
    invalid.write_text("<html>Access denied</html>", encoding="utf-8")

    crawler._quarantine_invalid_document(
        invalid,
        "HTML/access-denied response",
        url="https://www.dell.com/asset/test.pdf",
        stage="browser_candidate_validation",
    )

    assert crawler.stats.pdf_validation_rejections == 1
    assert crawler.stats.pdf_validation_failures == 0
    assert crawler.stats.pdf_terminal_validation_failures == 0
    assert crawler.stats.pdf_download_failures == 0
    rows = [json.loads(line) for line in crawler.pdf_validation_log.read_text(encoding="utf-8").splitlines()]
    assert rows[0]["recoverable"] is True
    assert rows[0]["terminal"] is False


def test_terminal_validation_failure_counted_once_per_url(tmp_path: Path) -> None:
    crawler = _bare_crawler(tmp_path)
    url = "https://www.dell.com/asset/test.pdf"
    crawler._record_pdf_failure(url, "terminal_validation", "DocumentValidationError: invalid PDF")
    crawler._record_pdf_failure(url, "terminal_validation", "DocumentValidationError: invalid PDF")

    assert crawler.stats.pdf_download_failures == 2
    assert crawler.stats.pdf_terminal_validation_failures == 1
    assert crawler.stats.pdf_validation_failures == 1


def test_recovery_after_candidate_rejection_is_reported(tmp_path: Path) -> None:
    crawler = _bare_crawler(tmp_path)
    url = "https://www.dell.com/asset/recovered.pdf"
    invalid = tmp_path / "candidate.pdf"
    invalid.write_text("not a pdf", encoding="utf-8")
    crawler._quarantine_invalid_document(invalid, "missing %PDF- signature", url=url)
    crawler._record_pdf_recovery(url, "source_button_viewer")

    assert crawler.stats.pdf_validation_rejections == 1
    assert crawler.stats.pdf_validation_recovered == 1
    assert crawler.stats.pdf_recoveries == 1


def test_stable_pdf_validation_waits_for_browser_writer(tmp_path: Path) -> None:
    final = _pdf_bytes()
    path = tmp_path / "browser-download.pdf"
    path.write_bytes(final[:40])

    def finish() -> None:
        time.sleep(0.06)
        path.write_bytes(final)

    thread = threading.Thread(target=finish)
    thread.start()
    result = validate_pdf_file_stable(path, parse_structure=True, attempts=10, settle_seconds=0.03)
    thread.join()

    assert result.ok is True
    assert result.pages == 1


class ClickPrimaryRuntime:
    def __init__(self, output_dir: Path, payload: bytes, parent: str, requested: str) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.payload = payload
        self.parent = parent
        self.requested = requested
        self.current_url = parent
        self.started = True
        self.server_url = "http://127.0.0.1:9999/mcp"
        self.tools = {"browser_run_code", "browser_evaluate", "browser_tabs"}
        self.clicks = 0
        self.api_requests = 0

    def start(self):
        return {"ok": True}

    def keep_single_dell_tab(self):
        return {"ok": True}

    def tab_inventory(self, **kwargs):
        return [{"index": 0, "url": self.current_url, "current": True}]

    def select_tab(self, index: int, **kwargs):
        return {"ok": True}

    def tabs(self, action: str, url: str = "", **kwargs):
        if action == "new" and url:
            self.current_url = url
        return {"ok": True}

    def navigate(self, url: str, **kwargs):
        self.current_url = url
        return {"ok": True}

    def wait(self, *args, **kwargs):
        return {"ok": True}

    def evaluate_readonly(self, expression: str, **kwargs):
        if "candidates:results" in expression:
            payload = {
                "ok": True,
                "pageUrl": self.parent,
                "candidates": [{
                    "url": self.requested,
                    "raw": self.requested,
                    "label": "Download PDF",
                    "visible": True,
                    "frameUrl": self.parent,
                    "rootKind": "document",
                    "attr": "href",
                }],
            }
        else:
            payload = {"url": self.current_url, "title": "Dell", "readyState": "complete", "hasEmbed": False}
        return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}

    def run_application_code(self, code: str, **kwargs):
        if "page.context().request.get" in code:
            self.api_requests += 1
            raise AssertionError("browser context request must not run before source click")
        if "matchCount:matches.length" in code:
            self.clicks += 1
            download = self.output_dir / "downloaded.pdf"
            download.write_bytes(self.payload)
            payload = {"ok": True, "status": "clicked", "matchCount": 1, "chosenHref": self.requested}
            return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}
        return {"ok": True, "detail": "### Result\n\"{}\""}

    @staticmethod
    def _parse_json_detail(detail: str):
        raw = detail.split("### Result", 1)[-1].strip()
        value = json.loads(raw)
        if isinstance(value, str):
            value = json.loads(value)
        return value

    def network_requests(self, **kwargs):
        return {"ok": True, "detail": ""}

    def click(self, *args, **kwargs):
        return {"ok": False, "detail": "not needed"}

    def snapshot(self, **kwargs):
        return {"ok": True, "detail": ""}

    def close_tab(self, *args, **kwargs):
        return {"ok": True}


def test_button_linked_pdf_uses_real_click_before_browser_request(tmp_path: Path) -> None:
    parent = "https://www.dell.com/en-uk/product"
    requested = "https://www.delltechnologies.com/asset/en-uk/spec.pdf"
    runtime = ClickPrimaryRuntime(tmp_path / "mcp", _pdf_bytes(), parent, requested)
    knowledge = tmp_path / "knowledge"
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    store.upsert_source(
        parent,
        parent,
        "Dell product",
        "Product",
        "hash",
        metadata={"browser_structured_dom": {"controls": [{"tag": "a", "label": "Download PDF", "attrs": {"href": requested}}]}},
    )
    config = CrawlConfig(
        start_urls=[parent],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        document_direct_http_enabled=False,
        document_browser_context_request_first=False,
        document_browser_context_request_fallback=True,
        document_ui_click_fallback_enabled=True,
        document_click_first_enabled=True,
    )
    extractor = DellContentExtractor(
        aia=NoopAIA(),
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)
    path = crawler.document_dir / "result.pdf"
    result = crawler._download_resource_resumable(
        requested,
        path,
        {"url": requested, "_queue_url": requested, "parent_url": parent, "relation": "CONTROL_CLICK_DOCUMENT"},
    )

    assert runtime.clicks == 1
    assert runtime.api_requests == 0
    assert result[2]["x-dell-fetch-mode"] == "playwright_unique_source_control_download"
    assert validate_pdf_file_stable(path, parse_structure=True).ok
    crawler.http.close()


def test_valid_browser_pdf_redirect_is_kept_in_warn_mode(tmp_path: Path) -> None:
    parent = "https://www.dell.com/en-uk/product"
    requested = "https://www.delltechnologies.com/asset/en-uk/spec.pdf"
    final = "https://downloads.dell.com/signed/temporary-document-123.pdf?token=abc"
    runtime = ClickPrimaryRuntime(tmp_path / "mcp", _pdf_bytes(), parent, requested)
    knowledge = tmp_path / "knowledge"
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    config = CrawlConfig(
        start_urls=[parent],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        document_browser_context_request_first=True,
        document_ui_click_fallback_enabled=False,
        document_require_canonical_match=False,
        document_canonical_match_mode="warn",
    )
    extractor = DellContentExtractor(
        aia=NoopAIA(),
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)
    path = crawler.document_dir / "redirect.pdf"

    def acquire(candidate: str, target: Path, parent_url: str):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(_pdf_bytes())
        return final, 200, {"content-type": "application/pdf"}, target.stat().st_size

    crawler._download_via_browser_api_chunks = acquire  # type: ignore[method-assign]
    result = crawler._download_resource_via_browser_context_first(
        {"url": requested, "_queue_url": requested, "parent_url": parent},
        path,
        {"parent_url": parent, "queue_url": requested, "request_url": requested, "href": requested, "label": "PDF"},
    )

    assert result[0] == final
    assert path.exists()
    assert crawler.stats.pdf_canonical_alias_accepts == 1
    assert crawler.stats.pdf_canonical_mismatch_failures == 0
    crawler.http.close()
