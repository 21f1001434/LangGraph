from __future__ import annotations

from pathlib import Path

from dell_crawler_core.frontier_scheduler import (
    ASSET,
    PAGE,
    asset_family_key,
    asset_resolution_score,
    classify_frontier_url,
    semantic_control_context_key,
)
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.snapshot import parse_nodes
from dell_crawler_core.ui_safe import arrow_safe_records


def test_arrow_safe_records_handles_mixed_metadata() -> None:
    records = [
        {"metadata": {"page": 1, "attempt": "1"}, "count": 1},
        {"metadata": {"page": "1", "tags": ["a", 2]}, "count": "2"},
    ]
    safe = arrow_safe_records(records)
    assert safe[0]["count"] == "1"
    assert safe[1]["count"] == "2"
    assert isinstance(safe[0]["metadata"], str)
    assert '"page": 1' in safe[0]["metadata"]
    assert '"page": "1"' in safe[1]["metadata"]


def test_dell_image_service_is_asset_even_with_psd_source_path() -> None:
    url = "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/foo.psd?fmt=png&wid=1200&hei=675"
    assert classify_frontier_url(url) == ASSET


def test_asset_family_dedupes_scene7_resize_variants() -> None:
    a = "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=400&hei=225"
    b = "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=webp&wid=1600&hei=900"
    assert asset_family_key(a) == asset_family_key(b)
    assert asset_resolution_score(b) > asset_resolution_score(a)


def test_page_lane_claims_before_asset_lane(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    asset = "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=1600&hei=900"
    page = "https://www.dell.com/en-uk/shop/scc/sc/workstations"
    # Give the asset a numerically better ordinary priority; lane priority must still win.
    store.enqueue(asset, priority=0)
    store.enqueue(page, priority=99)
    claimed = store.next_pending(lease_owner="test")
    assert claimed is not None
    assert claimed["url"] == page
    assert claimed["resource_class"] == PAGE


def test_enqueue_asset_keeps_higher_resolution_variant(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    low = "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=400&hei=225"
    high = "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=1600&hei=900"
    assert store.enqueue(low)
    assert store.enqueue(high)
    low_row = store.queue_item(low)
    high_row = store.queue_item(high)
    assert low_row is not None and low_row["status"] == "SKIPPED_DUPLICATE_ASSET"
    assert high_row is not None and high_row["status"] == "PENDING"


def test_compact_legacy_asset_variants(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    urls = [
        "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=400&hei=225",
        "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=800&hei=450",
        "https://i.dell.com/is/image/DellContent/content/dam/foo.psd?fmt=png&wid=1600&hei=900",
    ]
    # Simulate a v5 DB/frontier by bypassing the v6 family dedupe via force.
    for url in urls:
        store.enqueue(url, force=True)
    store.classify_legacy_frontier()
    result = store.compact_pending_asset_variants()
    assert result["families_compacted"] == 1
    assert result["variants_skipped"] == 2
    statuses = {url: store.queue_item(url)["status"] for url in urls}  # type: ignore[index]
    assert statuses[urls[-1]] == "PENDING"
    assert statuses[urls[0]] == "SKIPPED_DUPLICATE_ASSET"
    assert statuses[urls[1]] == "SKIPPED_DUPLICATE_ASSET"


def test_snapshot_control_context_survives_ref_changes() -> None:
    snapshot_a = '''
- article "Dell Pro Max 16"
  - heading "Dell Pro Max 16" [level=3]
  - button "Explore Options" [ref=e101]
'''
    snapshot_b = '''
- article "Dell Pro Max 16"
  - heading "Dell Pro Max 16" [level=3]
  - button "Explore Options" [ref=f99e12]
'''
    node_a = next(n for n in parse_nodes(snapshot_a) if n.name == "Explore Options")
    node_b = next(n for n in parse_nodes(snapshot_b) if n.name == "Explore Options")
    assert node_a.context == "Dell Pro Max 16"
    assert node_b.context == "Dell Pro Max 16"
    assert semantic_control_context_key(node_a.role, node_a.name, node_a.context, "EXPAND") == semantic_control_context_key(
        node_b.role, node_b.name, node_b.context, "EXPAND"
    )


def test_completed_control_memory_persists(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    url = "https://www.dell.com/en-uk/shop/example"
    key = semantic_control_context_key("button", "Explore Options", "Product A", "EXPAND")
    store.upsert_control_progress(
        url,
        key,
        label="Explore Options",
        context="Product A",
        action_kind="EXPAND",
        status="EXPANDED",
        information_gain=4,
    )
    assert key in store.recent_completed_control_keys(url, max_age_hours=72)


def test_queue_lane_counts_exposes_page_and_asset(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.enqueue("https://www.dell.com/en-uk")
    store.enqueue("https://i.dell.com/is/image/DellContent/content/dam/x.psd?wid=1200&hei=700")
    lanes = store.queue_lane_counts()
    assert lanes[PAGE]["PENDING"] == 1
    assert lanes[ASSET]["PENDING"] == 1


def test_preferred_document_lane_is_not_starved_by_pages(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.enqueue("https://www.dell.com/en-uk/page-a", priority=1)
    store.enqueue("https://www.dell.com/en-uk/page-b", priority=1)
    brochure = "https://www.dell.com/content/dam/documents/brochure.pdf"
    store.enqueue(brochure, priority=99)
    claimed = store.next_pending(lease_owner="test", preferred_resource_class="DOCUMENT")
    assert claimed is not None
    assert claimed["url"] == brochure
    assert claimed["resource_class"] == "DOCUMENT"


def test_historical_action_memory_migrates_once(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    with store.connect() as conn:
        conn.execute(
            """
            INSERT INTO action_trajectories(
                run_id,source_url,page_type,state_signature,control_key,stable_key,label,role,
                occurrence,status,reward,success,action_json,outcome_json,observed_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
            """,
            (
                "run", "https://www.dell.com/en-uk", "Product", "sig",
                "link|manuals documentation|0", "legacy-stable", "Manuals & Documentation",
                "link", 0, "DIRECT_ENDPOINT", 2.0, 1, "{}", '{"detail":{"target_url":"https://example"}}',
            ),
        )
    first = store.migrate_historical_control_progress()
    second = store.migrate_historical_control_progress()
    assert first["historical_controls_migrated"] == 1
    assert second["historical_controls_migrated"] == 0
    assert "link|manuals documentation|0" in store.recent_completed_control_keys("https://www.dell.com/en-uk")


def test_recent_terminal_dynamic_control_memory(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.upsert_dynamic_control(
        "https://www.dell.com/en-uk/product",
        {
            "key": "button|show more reviews|0",
            "label": "Show More Reviews",
            "role": "button",
            "status": "CYCLE_EXHAUSTED",
            "clicks": 9,
            "progress_events": 8,
            "no_progress_rounds": 1,
            "state_count": 10,
            "last_signature": "abc",
            "last_detail": "done",
        },
    )
    keys = store.recent_terminal_dynamic_control_keys("https://www.dell.com/en-uk/product")
    assert "button|show more reviews|0" in keys
