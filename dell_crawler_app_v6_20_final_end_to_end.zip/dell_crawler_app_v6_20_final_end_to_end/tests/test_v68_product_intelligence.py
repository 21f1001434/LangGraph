from __future__ import annotations

import json
from pathlib import Path

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.product_intelligence import parse_product_card


def _page(text: str, page_type: str = "ProductCatalog", metadata: dict | None = None) -> CrawlPage:
    return CrawlPage(
        url="https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops",
        canonical_url="https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops",
        title="Dell laptops",
        page_type=page_type,
        snapshot="",
        visible_text=text,
        links=[],
        controls=[],
        content_hash="x",
        metadata=metadata or {},
    )


def test_product_card_keeps_price_and_specs_together() -> None:
    card = {
        "name": "Dell 14 Laptop",
        "url": "https://www.dell.com/en-uk/shop/laptops-2-in-1-pcs/dell-14-laptop/spd/dell-dc14255-laptop/cndc1425503",
        "text": """Dell 14 Laptop
Order Code cndc1425503
4.6 out of 5 stars. 11 reviews
Original Price
£649.00
Dell Price
£499.00
Save £150.00 (23%)
£415.83 excluding VAT @20%
AMD Ryzen™ 5 220, 6 cores
Windows 11 Home
AMD Radeon™ Graphics
8GB, 1x8GB, DDR5, 5600MT/s
512 GB SSD
14.0-in. display Full HD+ (1920X1200) WVA
Starting at 1.54 kg
Configure and buy""",
    }
    record = parse_product_card(card, "https://www.dell.com/en-uk", "rendered_product_card")
    assert record is not None
    assert record.order_code == "cndc1425503"
    assert record.current_price == "499"
    assert record.list_price == "649"
    assert record.discount == "150"
    assert record.discount_percent == "23"
    assert "Ryzen" in record.processor
    assert "Radeon" in record.graphics
    assert "DDR5" in record.memory
    assert "SSD" in record.storage
    assert "14.0" in record.display
    assert record.operating_system == "Windows 11 Home"
    assert record.rating == "4.6"
    assert record.review_count == "11"
    assert record.canonical_identity() == "product-order:cndc1425503"


def test_finance_and_discount_are_not_product_price() -> None:
    record = parse_product_card(
        {
            "name": "Dell Pro 14 Plus Laptop",
            "text": """Dell Pro 14 Plus Laptop
Model: PB14250
£1,395.00
Get it now for as low as £58.12 over 24 months with 0% interest.
£199.20 off select configuration
Explore Options""",
        },
        "https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops",
        "rendered_product_card",
    )
    assert record is not None
    assert record.current_price == "1395"
    assert record.discount == "199.2"
    assert record.current_price != "58.12"
    assert record.current_price != "199.2"


def test_catalog_regex_does_not_read_serialized_dom_as_specs() -> None:
    text = """Compare Dell 16 Laptop with other products
Dell 16 Laptop
Model: DC16250
£679.00
Intel® Core™ 5-120U, 10 cores
Intel® Graphics
8 GB DDR5
512 GB SSD
16.0-in. display Full HD+ (1920X1200) WVA
Explore Options

===== RENDERED BROWSER STRUCTURED EVIDENCE =====
{"controls":[{"label":"NVIDIA Corporation trademarks","rootKind":"document","attrs":{"href":"https://example"}}]}"""
    extraction = DellContentExtractor(aia=None, use_llm=False, use_vision=False).deterministic_extract(_page(text))
    records = extraction["product_records"]
    assert records
    attrs = records[0]["attributes"]
    assert attrs["price"] == "679"
    assert attrs["processor"] == "Intel® Core™ 5-120U, 10 cores"
    assert attrs["graphics"] == "Intel® Graphics"
    assert "rootKind" not in attrs["graphics"]


def test_product_type_cannot_be_overwritten_by_endpoint(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    key = "url:https://www.dell.com/en-uk/shop/x/spd/model/order"
    store.upsert_node(key, "Product", "Dell Product", {"price": "499"})
    store.upsert_node(key, "Endpoint", "View offer", {"purpose": "open"})
    node = store.node_by_key(key)
    assert node is not None
    assert node["node_type"] == "Product"
    assert node["name"] == "Dell Product"
    assert node["attributes"]["price"] == "499"
    assert node["attributes"]["purpose"] == "open"


def test_ingestion_projects_product_fields_to_catalog_view(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    page = _page("Dell 14 Laptop")
    store.ingest_page(page)
    extraction = DellContentExtractor(aia=None, use_llm=False, use_vision=False).deterministic_extract(
        _page(
            """Dell 14 Laptop
Order Code cndc1425503
Original Price
£649.00
Dell Price
£499.00
AMD Ryzen™ 5 220, 6 cores
Windows 11 Home
AMD Radeon™ Graphics
8GB DDR5
512 GB SSD
14.0-in. display Full HD+
Configure and buy"""
        )
    )
    store.ingest_extraction(page.canonical_url, extraction)
    with store.connect() as conn:
        row = conn.execute(
            "SELECT * FROM product_catalog_view WHERE order_code='cndc1425503'"
        ).fetchone()
    assert row is not None
    assert row["price"] == "499"
    assert row["list_price"] == "649"
    assert "Ryzen" in row["processor"]
    assert "Radeon" in row["graphics"]
    assert "DDR5" in row["memory"]
    assert "SSD" in row["storage"]


def test_projection_rejects_serialized_json_noise(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    key = "url:https://www.dell.com/en-uk/shop/x/spd/model/order"
    store.upsert_node(key, "Product", "Dell Product", {"url": key[4:]})
    store.add_fact(key, "GPU", 'Adapters", "rootKind": "document", "attrs": {"href": "x"}', key[4:], confidence=0.72)
    store.add_fact(key, "GPU", "Intel® Arc™ Graphics", key[4:], confidence=0.96, qualifiers={"extraction": "rendered_product_card"})
    store.add_fact(key, "PRICE_GBP", "£499.00", key[4:], confidence=0.96, qualifiers={"extraction": "rendered_product_card"})
    attrs = store.refresh_product_projection(key)
    assert attrs["graphics"] == "Intel® Arc™ Graphics"
    assert attrs["price"] == "499.00"
    assert "rootKind" not in json.dumps(attrs)


def test_legal_finance_line_is_not_product_name():
    from dell_crawler_core.product_intelligence import parse_product_card
    record = parse_product_card({
        "text": "Subject to approval. Ts and Cs apply.\nOrder Code: cndb1425006sc_noac\n£899\nIntel Core Ultra 7"
    }, "https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops", "catalog_text_fallback")
    assert record is None


def test_trademark_inventory_is_not_graphics_spec(tmp_path):
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    assert not store._valid_product_value(
        "graphics",
        "NVIDIA logo, GeForce, GeForce RTX, GeForce RTX Super, GeForce GTX, GRID, SHIELD, CUDA, G-SYNC",
    )


def test_promotional_heading_is_not_product_name():
    from dell_crawler_core.product_intelligence import parse_product_card
    record = parse_product_card({
        "text": "Student exclusive XPS 13 price + 10% on everything else\nOrder Code: cndx1326001cc\n£699\nIntel Core 5"
    }, "https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops", "catalog_text_fallback")
    assert record is None
