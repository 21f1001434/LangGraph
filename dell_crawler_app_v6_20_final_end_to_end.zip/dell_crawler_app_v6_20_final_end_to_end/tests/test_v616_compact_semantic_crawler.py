from __future__ import annotations

from pathlib import Path

from dell_crawler_core.crawl_models import CrawlPage, DiscoveredLink
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.snapshot_extract import stable_text_hash


def _page(url: str, title: str, *, links=None, page_type: str = "WebPage") -> CrawlPage:
    return CrawlPage(
        url=url,
        canonical_url=url,
        title=title,
        page_type=page_type,
        snapshot="",
        visible_text=f"{title} useful Dell knowledge",
        links=list(links or []),
        content_hash=stable_text_hash(f"{title} useful Dell knowledge"),
    )


def test_discovered_link_is_evidence_until_target_is_fetched(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/laptops"
    target = "https://www.dell.com/en-uk/shop/laptops/scr/laptops"
    store.ingest_page(_page(source, "Laptops", links=[DiscoveredLink(label="All laptops", url=target)]))
    assert store.node_by_key(f"url:{target}") is None
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM link_evidence WHERE target_url=?", (target,)).fetchone()[0] == 1

    store.ingest_page(_page(target, "All laptops"))
    assert store.node_by_key(f"url:{target}") is not None
    with store.connect() as conn:
        source_id = conn.execute("SELECT id FROM nodes WHERE node_key=?", (f"url:{source}",)).fetchone()[0]
        target_id = conn.execute("SELECT id FROM nodes WHERE node_key=?", (f"url:{target}",)).fetchone()[0]
        assert conn.execute(
            "SELECT COUNT(*) FROM edges WHERE source_id=? AND target_id=? AND predicate='LINKS_TO'",
            (source_id, target_id),
        ).fetchone()[0] == 1


def test_unknown_schema_concept_is_preserved_without_graph_node(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/test"
    store.ingest_page(_page(source, "Test"))
    store.ingest_extraction(source, {
        "entities": [{"key": "battery1", "type": "Battery", "name": "6-cell battery", "attributes": {"capacity": "86 Wh"}}],
        "facts": [{"subject_key": "battery1", "predicate": "CAPACITY", "value": "86 Wh"}],
    })
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type='Concept'").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM extraction_evidence WHERE source_url=?", (source,)).fetchone()[0] >= 1
        page_id = conn.execute("SELECT id FROM nodes WHERE node_key=?", (f"url:{source}",)).fetchone()[0]
        assert conn.execute("SELECT COUNT(*) FROM facts WHERE subject_id=? AND predicate='CAPACITY'", (page_id,)).fetchone()[0] == 1


def test_product_identity_reuses_existing_strong_identifier(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source1 = "https://www.dell.com/en-uk/shop/a/spd/model/config-a"
    source2 = "https://www.dell.com/en-uk/shop/b/spd/model/config-b"
    store.ingest_page(_page(source1, "Dell Pro 14", page_type="Product"))
    store.ingest_extraction(source1, {"entities": [{
        "key": "p1", "type": "Product", "name": "Dell Pro 14",
        "attributes": {"order_code": "ABC123", "product_url": source1, "price": "999"},
    }]})
    store.ingest_page(_page(source2, "Dell Pro 14", page_type="Product"))
    store.ingest_extraction(source2, {"entities": [{
        "key": "p2", "type": "Product", "name": "Dell Pro 14",
        "attributes": {"order_code": "ABC123", "product_url": source2, "memory": "32 GB"},
    }]})
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type='Product'").fetchone()[0] == 1
        row = conn.execute("SELECT attributes_json FROM nodes WHERE node_type='Product'").fetchone()
        attrs = __import__('json').loads(row[0])
        assert str(attrs.get('price')) == '999'
        assert attrs.get('memory') == '32 GB'


def test_market_is_inferred_from_actual_locale(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    url = "https://www.dell.com/en-us/shop/laptops"
    store.ingest_page(_page(url, "US laptops"))
    node = store.node_by_key(f"url:{url}")
    assert node is not None
    assert node["attributes"]["market"] == "US"
    assert node["attributes"]["locale"] == "en-us"
    assert store.node_by_key("market:us") is not None


def test_stable_text_hash_ignores_whitespace_only_churn() -> None:
    a = "Dell Pro\n\nIntel Core    32 GB RAM"
    b = "Dell Pro Intel Core 32 GB RAM"
    assert stable_text_hash(a) == stable_text_hash(b)


def test_same_model_distinct_order_codes_are_not_duplicate_identities(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.upsert_node("product-order:a1", "Product", "Dell Pro 14", {
        "brand": "Dell", "model": "Dell Pro 14", "order_code": "A1",
        "product_url": "https://www.dell.com/en-uk/shop/x/spd/dell-pro-14/a1",
    })
    store.upsert_node("product-order:b2", "Product", "Dell Pro 14", {
        "brand": "Dell", "model": "Dell Pro 14", "order_code": "B2",
        "product_url": "https://www.dell.com/en-uk/shop/x/spd/dell-pro-14/b2",
    })
    report = store.semantic_quality_report()
    assert report["duplicate_product_identity_pairs"] == 0


def test_unresolved_local_relationship_is_evidence_not_graph_edge(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/test-unresolved-relation"
    store.ingest_page(_page(source, "Relation Test"))
    result = store.ingest_extraction(source, {
        "entities": [{"key": "brand1", "type": "Brand", "name": "Dell"}],
        "relations": [
            {"source_key": "brand1", "predicate": "RELATED_TO", "target_key": "missing_local_entity"},
        ],
    })
    assert result["validation_relations_rejected"] == 1
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM edges WHERE source_url=? AND predicate='RELATED_TO'", (source,)).fetchone()[0] == 0
        row = conn.execute(
            "SELECT payload_json FROM extraction_evidence WHERE source_url=? ORDER BY id DESC LIMIT 1",
            (source,),
        ).fetchone()
        assert row is not None
        assert "relationship_endpoint_unresolved" in row[0]


def test_pdf_diagnostic_fallback_never_writes_to_source_cwd(tmp_path: Path, monkeypatch) -> None:
    from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
    from dell_crawler_core.crawl_models import CrawlStats
    crawler = DellEnUkKnowledgeCrawler.__new__(DellEnUkKnowledgeCrawler)
    crawler.stats = CrawlStats(run_id="test-run", started_at="2026-01-01T00:00:00Z")
    crawler.run_id = "test-run"
    crawler.status_callback = None
    monkeypatch.chdir(tmp_path)
    crawler._record_pdf_transport_event("https://downloads.dell.com/test.pdf", "test")
    crawler._record_pdf_validation_rejection("https://downloads.dell.com/test.pdf", "test", "bad candidate")
    assert not (tmp_path / "PDF_TRANSPORT_EVENTS.jsonl").exists()
    assert not (tmp_path / "PDF_VALIDATION_REJECTIONS.jsonl").exists()
