from pathlib import Path

from dell_crawler_core.crawl_models import CrawlConfig
from dell_crawler_core.snapshot_extract import extract_safe_controls, seed_urls_for_scope


def test_default_config_is_unbounded() -> None:
    config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    assert config.max_pages == 0
    assert config.max_depth == -1
    assert config.max_interactions_per_page == -1
    assert config.repeatable_control_max_clicks == 0
    assert config.max_pdf_mb == 0


def test_full_scope_contains_dell_uk_seed() -> None:
    seeds = seed_urls_for_scope("full_en_uk_discovery")
    assert seeds
    assert any("dell.com/en-uk" in url for url in seeds)


def test_show_more_reviews_is_repeatable_safe_control() -> None:
    snapshot = '''
    - button "+ Show More Reviews" [ref=e101]
    - button "Read Brochure" [ref=e102]
    - button "Add to Basket" [ref=e103]
    '''
    controls = extract_safe_controls(snapshot)
    labels = {item.label: item for item in controls}
    assert "+ Show More Reviews" in labels
    assert labels["+ Show More Reviews"].repeatable is True
    assert labels["+ Show More Reviews"].review_control is True
    assert "Read Brochure" in labels
    assert labels["Read Brochure"].document_control is True
    assert "Add to Basket" not in labels


def test_app_files_exist() -> None:
    root = Path(__file__).resolve().parents[1]
    for filename in ["app.py", "crawler_worker.py", "requirements.txt", "run_app.ps1", "README.md"]:
        assert (root / filename).exists()


def test_full_scope_is_live_site_informed() -> None:
    seeds = seed_urls_for_scope("full_en_uk_discovery")
    expected_fragments = [
        "/shop/scc/sc/workstations",
        "/shop/scc/sc/servers",
        "/shop/scc/sc/storage-products",
        "/shop/scc/sc/networking-products",
        "/support/home/en-uk",
        "/en-uk/blog",
    ]
    for fragment in expected_fragments:
        assert any(fragment in url for url in seeds), fragment


def test_current_dell_read_only_control_vocabulary() -> None:
    snapshot = '''
    - tab "Tech Specs" [ref=e1]
    - tab "Features and Design" [ref=e2]
    - tab "Ratings & Reviews" [ref=e3]
    - tab "Drivers, Manuals & Support" [ref=e4]
    - button "Expand All" [ref=e5]
    - button "Previous Slide" [ref=e6]
    - button "Next Slide" [ref=e7]
    - link "Read eBook" [ref=e8]
    - button "Watch Video" [ref=e9]
    - button "Buy Now" [ref=e10]
    - button "Contact Sales" [ref=e11]
    '''
    controls = extract_safe_controls(snapshot)
    labels = {control.label: control for control in controls}
    for label in [
        "Tech Specs", "Features and Design", "Ratings & Reviews",
        "Drivers, Manuals & Support", "Expand All", "Previous Slide",
        "Next Slide", "Read eBook", "Watch Video",
    ]:
        assert label in labels
    assert labels["Expand All"].repeatable is True
    assert labels["Next Slide"].repeatable is True
    assert labels["Read eBook"].document_control is True
    assert "Buy Now" not in labels
    assert "Contact Sales" not in labels


def test_structured_html_enrichment_extracts_product_offer_review_faq_and_resources() -> None:
    from dell_crawler_core.html_enrichment import analyse_html_document, structured_evidence_to_text

    html = '''
    <html lang="en-GB"><head><title>Dell Test Workstation</title>
    <link rel="canonical" href="/en-uk/shop/test/spd/test-model">
    <script type="application/ld+json">
    {"@context":"https://schema.org","@graph":[
      {"@type":"Product","name":"Dell Pro Max Test","sku":"ABC123","brand":{"@type":"Brand","name":"Dell"}},
      {"@type":"Offer","price":"1999.99","priceCurrency":"GBP","availability":"https://schema.org/InStock"},
      {"@type":"Review","name":"Excellent workstation","reviewRating":{"@type":"Rating","ratingValue":"5"},"reviewBody":"Fast for AI workloads."},
      {"@type":"Question","name":"What GPU is supported?","acceptedAnswer":{"@type":"Answer","text":"NVIDIA RTX GPUs."}},
      {"@type":"VideoObject","name":"Product tour","contentUrl":"https://www.dell.com/videos/product-tour.mp4"}
    ]}
    </script></head><body>
      <a data-download-url="/content/dam/documents/test-brochure.pdf">Read Brochure</a>
      <table><tr><th>Memory</th><td>64 GB DDR5</td></tr></table>
      <dl><dt>Storage</dt><dd>2 TB NVMe SSD</dd></dl>
      <h2>How is it configured?</h2><p>Choose CPU, GPU, memory and storage.</p>
      <img src="/images/workstation.jpg" alt="Dell workstation front view" width="800" height="600">
      <video src="/videos/demo.mp4" title="Demo"></video>
    </body></html>
    '''
    evidence = analyse_html_document(html, "https://www.dell.com/en-uk/shop/test/spd/test-model")
    counts = evidence["counts"]
    assert counts["products"] == 1
    assert counts["offers"] == 1
    assert counts["reviews"] == 1
    assert counts["faqs"] >= 1
    assert counts["resources"] >= 1
    assert counts["tables"] == 1
    assert counts["definition_pairs"] == 1
    assert counts["videos"] >= 1
    text = structured_evidence_to_text(evidence)
    assert "Dell Pro Max Test" in text
    assert "test-brochure.pdf" in text
    assert "64 GB DDR5" in text


def test_deterministic_extractor_uses_json_ld_evidence() -> None:
    from dell_crawler_core.content_extractor import DellContentExtractor
    from dell_crawler_core.crawl_models import CrawlPage
    from dell_crawler_core.html_enrichment import analyse_html_document

    html = '''<html><head><script type="application/ld+json">{"@graph":[
      {"@type":"Product","name":"Dell AI Workstation","sku":"AI-001"},
      {"@type":"Offer","price":"2500","priceCurrency":"GBP"},
      {"@type":"Review","name":"Strong GPU performance","reviewRating":{"ratingValue":"4"},"reviewBody":"Useful for local inference."},
      {"@type":"Question","name":"Can it run AI models?","acceptedAnswer":{"text":"Yes, subject to model and GPU memory requirements."}}
    ]}</script></head><body>Dell AI Workstation</body></html>'''
    enrichment = analyse_html_document(html, "https://www.dell.com/en-uk/shop/test/spd/ai-workstation")
    page = CrawlPage(
        url="https://www.dell.com/en-uk/shop/test/spd/ai-workstation",
        canonical_url="https://www.dell.com/en-uk/shop/test/spd/ai-workstation",
        title="Dell AI Workstation",
        page_type="Product",
        snapshot="",
        visible_text="Dell AI Workstation",
        metadata={"html_enrichment": enrichment},
    )
    extraction = DellContentExtractor(aia=None, use_llm=False, use_vision=False).deterministic_extract(page)
    assert any(entity.get("name") == "Dell AI Workstation" for entity in extraction["entities"])
    assert any(offer.get("price") == "2500" for offer in extraction["offers"])
    assert any(review.get("rating") == "4" for review in extraction["reviews"])
    assert any(faq.get("question") == "Can it run AI models?" for faq in extraction["faqs"])


def test_v3_supervisor_and_exhaustive_pdf_defaults() -> None:
    root = Path(__file__).resolve().parents[1]
    assert (root / "crawler_supervisor.py").exists()
    config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    assert config.vision_pdf_every_page is True
    assert config.document_download_resume is True
    assert config.worker_lease_seconds >= 600


def test_durable_queue_lease_can_be_claimed_and_completed(tmp_path: Path) -> None:
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    store = SQLiteKnowledgeGraph(tmp_path / "crawler.db")
    url = "https://www.dell.com/en-uk/test"
    assert store.enqueue(url, depth=1, priority=5)
    claimed = store.next_pending(lease_owner="test-worker", lease_seconds=120)
    assert claimed is not None
    assert claimed["url"] == url
    assert claimed["status"] == "IN_PROGRESS"
    assert claimed["lease_owner"] == "test-worker"
    assert store.touch_queue(url, lease_owner="test-worker", lease_seconds=120)
    store.mark_queue(url, "DONE")
    item = store.queue_item(url)
    assert item is not None
    assert item["status"] == "DONE"
    assert item["lease_owner"] == ""


def test_failed_dynamic_control_requeues_completed_source(tmp_path: Path) -> None:
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    store = SQLiteKnowledgeGraph(tmp_path / "crawler.db")
    url = "https://www.dell.com/en-uk/shop/test/spd/model"
    store.enqueue(url)
    store.mark_queue(url, "DONE")
    store.upsert_dynamic_control(
        url,
        {
            "key": "button|show more reviews|0",
            "label": "Show More Reviews",
            "role": "button",
            "status": "FAILED",
            "clicks": 2,
        },
    )
    assert store.requeue_unfinished_dynamic_controls() == 1
    assert store.queue_item(url)["status"] == "PENDING"


def test_agentq_defaults_and_mutation_observer_are_enabled() -> None:
    config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    assert config.agentq_action_model_enabled is True
    assert config.agentq_actor_critic_enabled is True
    assert config.agentq_action_memory_enabled is True
    assert config.agentq_mcts_exploration_enabled is True
    assert config.dom_mutation_observer_enabled is True


def test_web_representation_control_fingerprint_survives_ref_refresh() -> None:
    from dell_crawler_core.agentic_control import WebRepresentationModel
    from dell_crawler_core.crawl_models import CrawlPage, SafeControl

    model = WebRepresentationModel()
    page1 = CrawlPage(
        url="https://www.dell.com/en-uk/test",
        canonical_url="https://www.dell.com/en-uk/test",
        title="Dell Test",
        page_type="Product",
        snapshot='- heading "Ratings" [ref=h1]\n- button "+ Show More Reviews" [ref=e101]\n- paragraph "Customer feedback" [ref=p1]',
        visible_text="Dell Test Ratings Customer feedback",
    )
    page2 = CrawlPage(
        url=page1.url,
        canonical_url=page1.canonical_url,
        title=page1.title,
        page_type=page1.page_type,
        snapshot='- heading "Ratings" [ref=h9]\n- button "+ Show More Reviews" [ref=e909]\n- paragraph "Customer feedback" [ref=p7]',
        visible_text=page1.visible_text,
    )
    c1 = SafeControl("+ Show More Reviews", "e101", "button", repeatable=True, review_control=True)
    c2 = SafeControl("+ Show More Reviews", "e909", "button", repeatable=True, review_control=True)
    semantic1, stable1, _ = model.control_key(page1, c1, 0)
    semantic2, stable2, _ = model.control_key(page2, c2, 0)
    assert semantic1 == semantic2
    assert stable1 == stable2


def test_actor_critic_prioritises_high_value_document_control(tmp_path: Path) -> None:
    from dell_crawler_core.agentic_control import AgentQInspiredActionModel
    from dell_crawler_core.crawl_models import CrawlPage, SafeControl
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    store = SQLiteKnowledgeGraph(tmp_path / "crawler.db")
    page = CrawlPage(
        url="https://www.dell.com/en-uk/lp/test",
        canonical_url="https://www.dell.com/en-uk/lp/test",
        title="Dell AI Infrastructure",
        page_type="AISolutionPage",
        snapshot='- button "Next Slide" [ref=e1]\n- button "Read Brochure" [ref=e2]',
        visible_text="Dell AI infrastructure overview",
        metadata={"dell_page_archetype": {"expected_topics": ["requirements", "resources"]}},
    )
    next_slide = SafeControl("Next Slide", "e1", "button", repeatable=True)
    brochure = SafeControl("Read Brochure", "e2", "button", document_control=True, resource_kind="Brochure")
    model = AgentQInspiredActionModel(store=store, aia=None, use_llm_critic=False)
    selection = model.choose(
        page,
        [
            (next_slide, 0, ("button", "next slide", 0), "button|next slide|0", ""),
            (brochure, 0, ("button", "read brochure", 0), "button|read brochure|0", ""),
        ],
        {},
    )
    assert selection.selected.label == "Read Brochure"
    assert store.stats()["action_decisions"] == 1
    assert store.stats()["web_state_observations"] == 1


def test_action_outcome_updates_durable_policy_memory(tmp_path: Path) -> None:
    from dell_crawler_core.agentic_control import ActionOutcome, AgentQInspiredActionModel
    from dell_crawler_core.crawl_models import CrawlPage, SafeControl
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    store = SQLiteKnowledgeGraph(tmp_path / "crawler.db")
    page = CrawlPage(
        url="https://www.dell.com/en-uk/shop/test",
        canonical_url="https://www.dell.com/en-uk/shop/test",
        title="Dell Product",
        page_type="Product",
        snapshot='- tab "Tech Specs" [ref=e1]',
        visible_text="Dell Product",
    )
    control = SafeControl("Tech Specs", "e1", "tab")
    model = AgentQInspiredActionModel(store=store, aia=None, use_llm_critic=False)
    selection = model.choose(
        page,
        [(control, 0, ("tab", "tech specs", 0), "tab|tech specs|0", "")],
        {},
    )
    outcome = ActionOutcome(
        reward=7.5,
        success=True,
        status="EXPANDED",
        new_text_lines=12,
        new_text_chars=900,
        new_links=1,
        new_documents=0,
        review_delta=0,
        healed=False,
    )
    model.learn(run_id="test-run", page=page, selection=selection, outcome=outcome)
    memory = store.get_action_policy("Product", selection.selected.control_key)
    assert memory["visits"] == 1
    assert memory["successes"] == 1
    assert memory["average_reward"] == 7.5
    assert store.stats()["action_trajectories"] == 1


def test_mcp_runtime_exposes_mutation_observer_tools() -> None:
    from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime

    runtime = PlaywrightMCPRuntime()
    assert callable(runtime.install_mutation_observer)
    assert callable(runtime.read_mutation_state)
    assert callable(runtime.wait_for_dom_quiet)


def test_uk_en_requirement_is_normalised_to_live_dell_locale() -> None:
    from dell_crawler_core.snapshot_extract import canonicalize_url

    assert canonicalize_url("https://www.dell.com/uk-en/shop/test") == "https://www.dell.com/en-uk/shop/test"


def test_public_data_detection_is_api_shaped_not_normal_product_page() -> None:
    from dell_crawler_core.resource_ingestion import is_public_data_url

    assert not is_public_data_url("https://www.dell.com/en-uk/shop/laptops/spd/model")
    assert is_public_data_url("https://www.dell.com/api/reviews/product/ABC?format=json")
    assert is_public_data_url("https://www.dell.com/content/api/product/specification/ABC")
    assert not is_public_data_url("https://www.dell.com/api/account/profile?format=json")


def test_sensitive_public_endpoint_query_values_are_removed() -> None:
    from dell_crawler_core.resource_ingestion import sanitize_public_api_url

    value = sanitize_public_api_url(
        "https://www.dell.com/api/reviews?product=ABC&token=secret&sessionid=bad&locale=en-GB"
    )
    assert "product=ABC" in value
    assert "locale=en-GB" in value
    assert "secret" not in value
    assert "sessionid" not in value


def test_network_candidate_extraction_is_read_only_and_filtered() -> None:
    from dell_crawler_core.resource_ingestion import public_get_candidates

    detail = """
    GET https://www.dell.com/api/reviews/product/ABC?format=json 200
    POST https://www.dell.com/api/reviews/product/ABC 200
    GET https://www.dell.com/api/account/profile?format=json 200
    GET https://www.dell.com/analytics/pixel?product=ABC 200
    GET https://www.dell.com/api/product/specification/ABC?sessionid=private 200
    """
    values = public_get_candidates(detail)
    assert len(values) == 2
    assert all("account" not in value and "analytics" not in value for value in values)
    assert all("sessionid" not in value for value in values)


def test_resource_extractor_understands_json_and_transcript(tmp_path: Path) -> None:
    from dell_crawler_core.resource_ingestion import extract_resource

    json_path = tmp_path / "product.json"
    json_path.write_text('{"model":"Dell Test","gpu":"RTX","url":"https://www.dell.com/en-uk/test"}', encoding="utf-8")
    data = extract_resource(json_path, "https://www.dell.com/api/product/test?format=json")
    assert data.kind == "PublicData"
    assert "Dell Test" in data.text
    assert "https://www.dell.com/en-uk/test" in data.embedded_urls

    transcript_path = tmp_path / "demo.vtt"
    transcript_path.write_text("WEBVTT\n\n00:00:00.000 --> 00:00:02.000\nAI workstation overview\n", encoding="utf-8")
    transcript = extract_resource(transcript_path, "https://www.dell.com/videos/demo.vtt")
    assert transcript.kind == "Transcript"
    assert "AI workstation overview" in transcript.text
    assert transcript.metadata["cue_count"] == 1


def test_coverage_contract_requires_declared_reviews_to_be_reconciled() -> None:
    from dell_crawler_core.coverage_audit import audit_page
    from dell_crawler_core.crawl_models import CrawlPage

    page = CrawlPage(
        url="https://www.dell.com/en-uk/shop/test/spd/model",
        canonical_url="https://www.dell.com/en-uk/shop/test/spd/model",
        title="Dell Test Workstation",
        page_type="Product",
        snapshot="",
        visible_text=("Dell Test Workstation processor memory storage graphics tech specs ratings and reviews " * 8),
        links=[],
        metadata={
            "repeatable_controls_complete": True,
            "browser_structured_dom": {"controls": []},
            "html_enrichment": {"counts": {}},
            "network_inventory": {"public_get_candidates": []},
            "review_metrics": {"declared_review_count": 3},
            "reviews_extracted": 2,
        },
    )
    audit = audit_page(page)
    assert audit.checks["reviews_reconciled"] is False
    assert any("declared=3" in gap for gap in audit.gaps)


def test_coverage_contract_accepts_rich_complete_product_page() -> None:
    from dell_crawler_core.coverage_audit import audit_page
    from dell_crawler_core.crawl_models import CrawlPage, DiscoveredLink

    expected = [
        "processor", "operating system", "graphics", "memory", "storage",
        "tech specs", "ratings and reviews", "drivers/manuals/support", "offers",
    ]
    page = CrawlPage(
        url="https://www.dell.com/en-uk/shop/test/spd/model",
        canonical_url="https://www.dell.com/en-uk/shop/test/spd/model",
        title="Dell Pro Max Test Workstation",
        page_type="Product",
        snapshot="",
        visible_text=(
            "Dell Pro Max Test Workstation. Processor Intel Core Ultra. Operating system Windows 11. "
            "NVIDIA graphics GPU. 64 GB DDR5 memory. 2 TB NVMe SSD storage. Tech Specs. "
            "Ratings & Reviews. Drivers, Manuals & Support. Special Offers. " * 5
        ),
        links=[DiscoveredLink(label="Manual", url="https://www.dell.com/support/manual.pdf")],
        metadata={
            "dell_page_archetype": {"expected_topics": expected},
            "repeatable_controls_complete": True,
            "browser_structured_dom": {"controls": [{"label": "Tech Specs"}]},
            "html_enrichment": {"counts": {"products": 1}},
            "network_inventory": {"public_get_candidates": []},
            "review_metrics": {"declared_review_count": 2},
            "reviews_extracted": 2,
            "vision_candidate_image_count": 0,
        },
    )
    audit = audit_page(page)
    assert audit.passed is True
    assert audit.missing_topics == []


def test_robots_gate_discovers_declared_sitemaps() -> None:
    from dell_crawler_core.dell_crawler import RobotsGate

    class Response:
        text = "User-agent: *\nAllow: /\nSitemap: https://www.dell.com/en-uk/sitemap.xml\nSitemap: https://example.com/not-dell.xml\n"

        @staticmethod
        def raise_for_status() -> None:
            return None

    class Client:
        @staticmethod
        def get(*args, **kwargs):
            return Response()

    gate = RobotsGate(Client(), "DellCrawlerTest")
    values = gate.sitemap_urls("https://www.dell.com/en-uk")
    assert values == ["https://www.dell.com/en-uk/sitemap.xml"]


def test_recursive_rendered_dom_capture_includes_shadow_iframe_and_captions() -> None:
    root = Path(__file__).resolve().parents[1]
    source = (root / "dell_crawler_core" / "dell_crawler.py").read_text(encoding="utf-8")
    assert "shadowRoot" in source
    assert "contentDocument" in source
    assert "formOptions" in source
    assert "captions" in source
    assert "css-background" in source


def test_v5_autonomous_discovery_defaults_are_enabled() -> None:
    config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"])
    assert config.discover_robots_sitemaps is True
    assert config.recursive_shadow_dom is True
    assert config.capture_same_origin_iframes is True
    assert config.scroll_sweep_enabled is True
    assert config.process_public_api_gets is True
    assert config.process_office_documents is True
    assert config.process_transcripts is True
    assert config.record_binary_asset_metadata is True
    assert config.coverage_contract_enabled is True
    assert config.minimum_page_coverage > 0


def test_public_json_pagination_discovers_only_next_page(tmp_path: Path) -> None:
    from dell_crawler_core.resource_ingestion import extract_resource

    path = tmp_path / "reviews.json"
    path.write_text(
        '{"page":1,"totalPages":4,"reviews":[{"title":"Good"}]}',
        encoding="utf-8",
    )
    item = extract_resource(path, "https://www.dell.com/api/reviews/product/ABC?page=1&format=json")
    assert item.metadata["pagination_urls"] == [
        "https://www.dell.com/api/reviews/product/ABC?page=2&format=json"
    ]
    assert "page=2" in item.embedded_urls[-1]


def test_public_json_cursor_pagination_is_preserved(tmp_path: Path) -> None:
    from dell_crawler_core.resource_ingestion import extract_resource

    path = tmp_path / "reviews.json"
    path.write_text('{"nextCursor":"abc-2","items":[1,2]}', encoding="utf-8")
    item = extract_resource(path, "https://www.dell.com/api/reviews/product/ABC?format=json")
    assert any("cursor=abc-2" in url for url in item.metadata["pagination_urls"])


def test_reviews_from_paginated_public_api_are_associated_with_product(tmp_path: Path) -> None:
    from dell_crawler_core.crawl_models import CrawlPage
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    store = SQLiteKnowledgeGraph(tmp_path / "crawler.db")
    product_url = "https://www.dell.com/en-uk/shop/test/spd/model"
    api_url_1 = "https://www.dell.com/api/reviews/product/ABC?page=1&format=json"
    api_url_2 = "https://www.dell.com/api/reviews/product/ABC?page=2&format=json"
    store.ingest_page(CrawlPage(
        url=product_url, canonical_url=product_url, title="Dell Model", page_type="Product",
        snapshot="", visible_text="Dell Model",
    ))
    store.ingest_page(CrawlPage(
        url=api_url_1, canonical_url=api_url_1, title="Reviews page 1", page_type="PublicData",
        snapshot="", visible_text="Review data",
    ))
    store.ingest_page(CrawlPage(
        url=api_url_2, canonical_url=api_url_2, title="Reviews page 2", page_type="PublicData",
        snapshot="", visible_text="Review data",
    ))
    store.ingest_extraction(api_url_1, {"reviews": [
        {"review_id": "r1", "title": "Good", "body": "Good workstation", "rating": 5},
    ]}, association_url=product_url)
    store.ingest_extraction(api_url_2, {"reviews": [
        {"review_id": "r2", "title": "Fast", "body": "Fast for AI", "rating": 4},
    ]}, association_url=product_url)
    assert store.review_count_for_page(product_url) == 2


def test_public_json_reviews_are_extracted_individually_and_deterministically(tmp_path: Path) -> None:
    from dell_crawler_core.content_extractor import DellContentExtractor
    from dell_crawler_core.crawl_models import CrawlPage
    from dell_crawler_core.resource_ingestion import extract_resource

    path = tmp_path / "reviews.json"
    path.write_text(
        '''{"totalReviewCount":2,"page":1,"totalPages":1,"reviews":[
        {"reviewId":"A1","reviewTitle":"Excellent","reviewText":"Fast for local AI inference.","rating":5,"nickname":"User One","verifiedPurchaser":true},
        {"reviewId":"A2","reviewTitle":"Useful","reviewText":"Good memory capacity.","ratingValue":4,"author":{"name":"User Two"}}
        ]}''',
        encoding="utf-8",
    )
    resource = extract_resource(path, "https://www.dell.com/api/reviews/product/ABC?format=json")
    assert resource.metadata["structured_review_count"] == 2
    assert resource.metadata["declared_review_count"] == 2
    page = CrawlPage(
        url="https://www.dell.com/api/reviews/product/ABC?format=json",
        canonical_url="https://www.dell.com/api/reviews/product/ABC?format=json",
        title="Dell public reviews",
        page_type="PublicData",
        snapshot="",
        visible_text=resource.text,
        metadata=resource.metadata,
    )
    extraction = DellContentExtractor(aia=None, use_llm=False, use_vision=False).deterministic_extract(page)
    assert len(extraction["reviews"]) == 2
    assert {review["review_id"] for review in extraction["reviews"]} == {"A1", "A2"}
    assert extraction["reviews"][0]["evidence_type"] == "public_json_api_customer_opinion"


# --- v5.1 broadened public-web extraction coverage -------------------------

def test_v51_new_seeds_cover_support_community_learn_and_legal() -> None:
    from dell_crawler_core.dell_site_profile import DELL_UK_DISCOVERY_SEEDS
    from dell_crawler_core.snapshot_extract import is_en_uk_scope, is_sitemap_url

    joined = "\n".join(DELL_UK_DISCOVERY_SEEDS)
    for token in (
        "/support/kbdoc/en-uk",
        "/community/en/",
        "/en-uk/dt/learn/",
        "dell-customer-stories",
        "privacy-policy",
        "infohub.delltechnologies.com",
    ):
        assert token in joined, f"missing broadened seed containing {token}"

    # Every seed must be reachable: either a sitemap (handled separately) or in public UK scope.
    for url in DELL_UK_DISCOVERY_SEEDS:
        assert is_sitemap_url(url) or is_en_uk_scope(url, True, True), f"seed dropped by scope gate: {url}"


def test_v51_specific_support_subtypes_beat_generic_support() -> None:
    from dell_crawler_core.dell_site_profile import archetype_for

    cases = {
        "https://www.dell.com/support/kbdoc/en-uk/000123347/x": "SupportArticle",
        "https://www.dell.com/support/contents/en-uk/videos/videoplayer/x/1": "SupportVideo",
        "https://www.dell.com/support/contents/en-uk/category/product-support/self-support-knowledgebase": "SupportKnowledgeBase",
        "https://www.dell.com/community/en/conversations/laptops/x/td-p/1": "CommunityFeedbackThread",
        "https://www.dell.com/community/en/categories": "CommunitySpace",
        "https://www.dell.com/en-uk/lp/dell-customer-stories": "CustomerStory",
        "https://www.dell.com/en-uk/dt/learn/index.htm": "LearnGlossary",
        "https://www.dell.com/en-uk/lp/privacy-policy": "LegalPolicy",
        "https://www.dell.com/en-uk/dt/corporate/about-us.htm": "CompanyPage",
    }
    hint = "manuals drivers downloads warranty what is guide customer story"
    for url, expected in cases.items():
        arch = archetype_for(url, "", hint)
        assert arch is not None and arch.name == expected, f"{url} -> {arch and arch.name}"


def test_v51_support_article_meets_its_own_coverage_contract() -> None:
    from dell_crawler_core.crawl_models import CrawlPage
    from dell_crawler_core.coverage_audit import audit_page
    from dell_crawler_core.dell_site_profile import archetype_for

    text = (
        "Summary: this article explains a driver issue you may experience.\n"
        "Cause: this is because of a version mismatch.\n"
        "Resolution: follow these steps to resolve. Open SupportAssist, detect drivers, install firmware.\n"
        "Applies to: Latitude, Inspiron, XPS laptops.\n"
        "Article Number: 000123347  Article Type: How To  Version: 42  Last Modified: 06 Feb 2026\n"
        "Related articles: how to download and install Dell drivers."
    )
    url = "https://www.dell.com/support/kbdoc/en-uk/000123347/x"
    arch = archetype_for(url, "Dell Drivers FAQ", text)
    assert arch.name == "SupportArticle"
    meta = {
        "dell_page_archetype": {"name": arch.name, "expected_topics": list(arch.expected_topics)},
        "browser_structured_dom": {"ok": True},
        "network_inventory": {"x": 1},
        "html_enrichment": {"meta": {}},
        "repeatable_controls_complete": True,
    }
    page = CrawlPage(
        url=url, canonical_url=url, title="Dell Drivers FAQ", page_type=arch.name,
        snapshot="", visible_text=text, links=[], controls=[], metadata=meta,
    )
    audit = audit_page(page, minimum_score=0.72)
    assert audit.passed
    assert not audit.missing_topics


def test_v51_support_and_community_scopes_resolve_seeds() -> None:
    from dell_crawler_core.snapshot_extract import seed_urls_for_scope

    support = seed_urls_for_scope("support")
    community = seed_urls_for_scope("community")
    assert any("/support/" in u for u in support)
    assert any("/community/" in u for u in community)

# --- v5.2 Playwright MCP schema compatibility and loop-break fixes ---------

def test_v52_browser_evaluate_adapts_current_function_schema() -> None:
    from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime

    runtime = object.__new__(PlaywrightMCPRuntime)
    runtime.tools = {
        "browser_evaluate": {
            "schema": {
                "type": "object",
                "properties": {"function": {"type": "string"}},
                "required": ["function"],
            }
        }
    }
    adapted = runtime._adapt_args("browser_evaluate", {"expression": "document.title"})
    assert set(adapted) == {"function"}
    assert adapted["function"] == "() => (document.title)"


def test_v52_browser_evaluate_remains_compatible_with_legacy_expression_schema() -> None:
    from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime

    runtime = object.__new__(PlaywrightMCPRuntime)
    runtime.tools = {
        "browser_evaluate": {
            "schema": {
                "type": "object",
                "properties": {"expression": {"type": "string"}},
                "required": ["expression"],
            }
        }
    }
    adapted = runtime._adapt_args("browser_evaluate", {"function": "() => document.title"})
    assert adapted == {"expression": "() => document.title"}


def test_v52_scroll_uses_keyboard_when_evaluate_is_unavailable() -> None:
    from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime

    runtime = object.__new__(PlaywrightMCPRuntime)
    runtime.evaluate_readonly = lambda *args, **kwargs: {
        "ok": False, "status": "tool_missing", "detail": "browser_evaluate unavailable"
    }
    pressed: list[str] = []

    def press(key: str, intent: str = "") -> dict:
        pressed.append(key)
        return {"ok": True, "status": "ok"}

    runtime.press_key = press
    result = PlaywrightMCPRuntime.scroll_next_viewport(runtime)
    assert result["ok"]
    assert result["status"] == "scroll_key_fallback"
    assert pressed == ["PageDown"]


def test_v52_deep_scan_terminal_heal_does_not_loop_forever() -> None:
    from types import SimpleNamespace
    from dell_crawler_core.crawl_models import CrawlPage, CrawlStats
    from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
    from dell_crawler_core.react_self_heal import HealAction, ReActDecision

    class Runtime:
        started = True
        calls = 0

        def scroll_next_viewport(self, intent: str = "") -> dict:
            self.calls += 1
            return {"ok": False, "status": "mcp_tool_error", "detail": "schema failure"}

        def scroll_to_top(self, intent: str = "") -> dict:
            return {"ok": True}

    class Healer:
        def decide(self, context):
            return ReActDecision("UNKNOWN_TRANSIENT", HealAction.HTTP_FALLBACK, "terminal", retry=False)

        def execute(self, runtime, decision, url):
            return {"ok": True, "status": "http_fallback"}

    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.config = SimpleNamespace(
        deep_scan_lazy_content=True,
        deep_scan_stable_rounds=2,
        max_deep_scan_rounds=0,
        max_control_retries=4,
        scroll_sweep_enabled=True,
        self_heal_enabled=True,
        delay_seconds=0.0,
        emergency_action_budget_allows=lambda attempted: True,
    )
    crawler.runtime = Runtime()
    crawler.healer = Healer()
    crawler.stats = CrawlStats(run_id="test", started_at="now")
    crawler._stopped = False
    crawler._record_heal = lambda *args, **kwargs: None
    page = CrawlPage(
        url="https://www.dell.com/en-uk",
        canonical_url="https://www.dell.com/en-uk",
        title="Dell UK",
        page_type="Home",
        snapshot="root",
        visible_text="Dell UK",
    )
    result = crawler._deep_scan_lazy_content(page)
    assert result is page
    assert crawler.runtime.calls == 1
    assert any("Stopped lazy-page scrolling" in warning for warning in page.metadata["self_heal_warnings"])


def test_v52_decodes_current_mcp_result_wrapper() -> None:
    from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime

    detail = '### Result\n"{\\"before\\":0,\\"after\\":590,\\"atBottom\\":false}"'
    assert PlaywrightMCPRuntime._parse_json_detail(detail) == {
        "before": 0,
        "after": 590,
        "atBottom": False,
    }


def test_v52_browser_missing_is_classified_as_fatal_configuration() -> None:
    from dell_crawler_core.react_self_heal import FailureClassifier, ReActContext

    context = ReActContext(
        url="https://www.dell.com/en-uk",
        stage="html_page",
        error='Error: Browser "chrome-for-testing" is not installed. Run install-browser.',
    )
    assert FailureClassifier.classify(context) == "MCP_BROWSER_MISSING"


def _scan_page(text: str, *, links: list[str] | None = None, controls: list[str] | None = None):
    from dell_crawler_core.crawl_models import CrawlPage, DiscoveredLink, SafeControl

    return CrawlPage(
        url="https://www.dell.com/en-uk",
        canonical_url="https://www.dell.com/en-uk",
        title="Dell UK",
        page_type="LandingPage",
        snapshot=text,
        visible_text=text,
        links=[DiscoveredLink(label=value, url=f"https://www.dell.com/en-uk/{value}") for value in (links or [])],
        controls=[SafeControl(label=value, ref=f"e{index}", role="button") for index, value in enumerate(controls or [])],
    )


def test_lazy_scan_converges_at_stable_bottom_despite_snapshot_churn() -> None:
    from dell_crawler_core.deep_content import LazyScanConvergence

    tracker = LazyScanConvergence(stable_rounds_required=2)
    tracker.prime(_scan_page("Dell UK\nProducts\nSlide 1 of 4", links=["products"]))

    first = tracker.observe(
        _scan_page("Dell UK\nProducts\nAI PCs\nSlide 2 of 4", links=["products"]),
        {"before": 5200, "after": 5979, "height": 6653, "viewport": 780, "atBottom": True},
    )
    assert first["converged"] is False

    # Auto-rotating hero content changes, but the page has not gained any new
    # vertical frontier. The second identical bottom geometry must terminate.
    second = tracker.observe(
        _scan_page("Dell UK\nProducts\nWorkstations\nSlide 3 of 4", links=["products"]),
        {"before": 5979, "after": 5979, "height": 6653, "viewport": 780, "atBottom": True},
    )
    assert second["converged"] is True
    assert second["reason"] == "bottom_geometry_stable"
    assert second["round"] == 2


def test_lazy_scan_keeps_scrolling_while_vertical_frontier_grows() -> None:
    from dell_crawler_core.deep_content import LazyScanConvergence

    tracker = LazyScanConvergence(stable_rounds_required=2)
    tracker.prime(_scan_page("Dell UK"))
    for index in range(1, 6):
        observation = tracker.observe(
            _scan_page(f"Dell UK\nSection {index}", links=[f"item-{index}"]),
            {
                "before": (index - 1) * 700,
                "after": index * 700,
                "height": 9000 + index * 500,
                "viewport": 800,
                "atBottom": False,
            },
        )
        assert observation["converged"] is False
        assert observation["meaningful_growth"] is True


def test_lazy_scan_adaptive_guard_is_page_local_not_site_limit() -> None:
    from dell_crawler_core.deep_content import LazyScanConvergence

    tracker = LazyScanConvergence(stable_rounds_required=2, fallback_round_guard=12)
    tracker.prime(_scan_page("Dell UK"))
    final = None
    # No scroll telemetry: a broken browser cannot hold one queue item forever.
    for _ in range(12):
        final = tracker.observe(_scan_page("Dell UK\nRotating message"), {})
        if final["converged"]:
            break
    assert final is not None
    assert final["converged"] is True
    assert final["reason"] in {"semantic_no_growth", "adaptive_page_guard"}


def test_merge_page_evidence_preserves_deep_scan_completion_metadata() -> None:
    from dell_crawler_core.crawl_models import CrawlPage
    from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler

    base = CrawlPage(
        url="https://www.dell.com/en-uk",
        canonical_url="https://www.dell.com/en-uk",
        title="Dell UK",
        page_type="LandingPage",
        snapshot="base",
        visible_text="base evidence",
        metadata={
            "deep_scan_terminal_reason": "bottom_geometry_stable",
            "deep_scan_at_bottom": True,
        },
    )
    after = CrawlPage(
        url=base.url,
        canonical_url=base.canonical_url,
        title=base.title,
        page_type=base.page_type,
        snapshot="after",
        visible_text="base evidence\nexpanded evidence",
        metadata={"interaction_capture": True},
    )
    merged = DellEnUkKnowledgeCrawler._merge_page_evidence(base, [after])
    assert merged.metadata["deep_scan_terminal_reason"] == "bottom_geometry_stable"
    assert merged.metadata["deep_scan_at_bottom"] is True
    assert merged.metadata["interaction_capture"] is True


def test_v53_crawler_method_exits_live_stuck_pattern_after_two_bottom_observations() -> None:
    from types import SimpleNamespace
    from dell_crawler_core.crawl_models import CrawlPage, CrawlStats
    from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler

    class Runtime:
        started = True

        def __init__(self) -> None:
            self.calls = 0

        def scroll_next_viewport(self, intent: str = "") -> dict:
            self.calls += 1
            return {
                "ok": True,
                "scroll_state": {
                    "before": 5979,
                    "after": 5979,
                    "height": 6653,
                    "viewport": 780,
                    "atBottom": True,
                },
            }

        def wait(self, *args, **kwargs) -> dict:
            return {"ok": True}

        def scroll_to_top(self, intent: str = "") -> dict:
            return {"ok": True}

    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.config = SimpleNamespace(
        deep_scan_lazy_content=True,
        deep_scan_stable_rounds=2,
        deep_scan_fallback_round_guard=80,
        max_deep_scan_rounds=0,
        max_control_retries=4,
        scroll_sweep_enabled=True,
        self_heal_enabled=True,
        delay_seconds=0.0,
        emergency_action_budget_allows=lambda attempted: True,
    )
    crawler.runtime = Runtime()
    crawler.stats = CrawlStats(run_id="test", started_at="now")
    crawler._stopped = False
    crawler._emit = lambda *args, **kwargs: None
    base = _scan_page("Dell UK\nHome")
    captures = iter([
        _scan_page("Dell UK\nRotating promotion A"),
        _scan_page("Dell UK\nRotating promotion B"),
        _scan_page("Dell UK\nRotating promotion C"),
    ])
    crawler._capture_page = lambda *args, **kwargs: next(captures)

    result = crawler._deep_scan_lazy_content(base)
    assert crawler.runtime.calls == 2
    assert result.metadata["deep_scan_terminal_reason"] == "bottom_geometry_stable"
    assert result.metadata["deep_scan_at_bottom"] is True
    assert result.metadata["deep_scan_rounds"] == 2
