from __future__ import annotations

from pathlib import Path

from dell_crawler_core.extraction_normalizer import normalize_extraction_payload
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.knowledge_ontology import canonical_node_type, canonical_relationship_type
from dell_crawler_core.product_intelligence import ProductRecord


def test_unbounded_schema_types_are_bounded():
    assert canonical_node_type("Battery") == "Concept"
    assert canonical_node_type("AggregateRating") == "Review"
    assert canonical_node_type("AISolutionPage", context="page") == "Page"
    assert canonical_relationship_type("HAS_PROCESSOR") == "RELATED_TO" or canonical_relationship_type("HAS_PROCESSOR") == "RELATED_TO"
    assert canonical_relationship_type("HAS_COMPATIBILITY") == "COMPATIBLE_WITH"


def test_unresolved_relation_does_not_create_placeholder_node():
    payload = normalize_extraction_payload(
        {
            "entities": [{"key": "p1", "type": "Product", "name": "Dell XPS 14", "model": "9440"}],
            "relations": [{"source_key": "p1", "predicate": "HAS_PROCESSOR", "target_key": "cpu_missing"}],
        },
        source_url="https://www.dell.com/en-uk/shop/spd/xps-14-9440",
    )
    assert all(e.get("key") != "cpu_missing" for e in payload["entities"])
    assert payload["relations"] == []
    assert any(item.get("field") == "unresolved_relation" for item in payload["unmapped_evidence"])


def test_product_url_identity_is_separate_from_page_identity():
    record = ProductRecord(
        name="Dell XPS 14",
        source_url="https://www.dell.com/en-uk/shop/spd/xps-14-9440",
        product_url="https://www.dell.com/en-uk/shop/spd/xps-14-9440",
    )
    assert record.canonical_identity().startswith("product-url:")
    assert not record.canonical_identity().startswith("url:")


def test_store_reports_bounded_schema(tmp_path: Path):
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    store.upsert_node("a", "Battery", "Battery", {"value": "6 cell"})
    store.upsert_node("b", "AggregateRating", "4.8", {"rating": 4.8})
    store.upsert_edge("a", "HAS_COMPATIBILITY", "b", "https://example.test")
    report = store.canonical_schema_report()
    assert report["raw_node_type_count"] <= report["canonical_node_type_count"] + 2
    assert "Concept" in report["canonical_node_types"]
    assert "Review" in report["canonical_node_types"]
    assert "COMPATIBLE_WITH" in report["canonical_relationship_types"]
