from __future__ import annotations

from pathlib import Path, PureWindowsPath

from dell_crawler_core.document_pipeline import (
    normalize_pdf_download_url,
    short_pdf_storage_path,
)


def test_pdf_external_alias_is_not_sent_to_cdn() -> None:
    source = (
        "https://www.delltechnologies.com/asset/en-uk/products/laptops/"
        "four-reasons-to-refresh.pdf.external?ref=ai"
    )
    assert normalize_pdf_download_url(source) == (
        "https://www.delltechnologies.com/asset/en-uk/products/laptops/"
        "four-reasons-to-refresh.pdf?ref=ai"
    )


def test_regular_pdf_url_is_unchanged() -> None:
    source = "https://www.delltechnologies.com/asset/en-uk/solutions/esg-agentic-ai-research.pdf"
    assert normalize_pdf_download_url(source) == source


def test_external_alias_and_real_pdf_share_one_storage_file(tmp_path: Path) -> None:
    real = "https://www.delltechnologies.com/asset/en-uk/solutions/research.pdf"
    alias = real + ".external"
    assert short_pdf_storage_path(tmp_path, real) == short_pdf_storage_path(tmp_path, alias)


def test_short_hash_path_stays_below_windows_legacy_limit() -> None:
    # This is the exact long OneDrive-style root from the production failure log.
    root = PureWindowsPath(
        r"C:\Users\Adheesh_Srivastava\OneDrive - Dell Technologies\Desktop\VishnuBaghvan"
        r"\Browser Testing\Search\KB Builder\knowledge\documents"
    )
    url = (
        "https://www.delltechnologies.com/asset/en-uk/products/laptops-and-2-in-1s/"
        "briefs-summaries/four-reasons-to-refresh-to-ai-pcs-leave-behind-brochure.pdf.external"
    )
    # Build the platform-independent relative part with the production helper.
    relative = short_pdf_storage_path(Path("documents"), url).relative_to("documents")
    full = root.joinpath(*relative.parts)
    part = PureWindowsPath(str(full) + ".part")
    assert len(str(part)) < 240
    assert part.name.endswith(".pdf.part")
    assert ".external" not in str(part)


def test_process_pdf_external_uses_real_url_and_hash_path(tmp_path: Path) -> None:
    import io
    import json

    import httpx
    from pypdf import PdfWriter

    from dell_crawler_core.content_extractor import DellContentExtractor
    from dell_crawler_core.crawl_models import CrawlConfig
    from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": "External Alias Test"})
    writer.write(buffer)
    payload = buffer.getvalue()
    requested: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requested.append(str(request.url))
        assert str(request.url).endswith("/alias-test.pdf")
        return httpx.Response(
            200,
            headers={"content-type": "application/pdf", "content-length": str(len(payload))},
            content=payload,
        )

    class Runtime:
        started = False
        output_dir = tmp_path / "mcp"

    knowledge = tmp_path / "knowledge"
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    config = CrawlConfig(
        start_urls=["https://www.dell.com/en-uk"],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        vision_pdf_pages=False,
        document_direct_http_enabled=True,
    )
    extractor = DellContentExtractor(
        aia=None,
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(Runtime(), store, extractor, config, output_dir=knowledge)
    crawler.http.close()
    crawler.http = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)

    queue_url = "https://www.delltechnologies.com/asset/en-uk/test/alias-test.pdf.external"
    crawler._process_pdf({"url": queue_url, "depth": 0, "parent_url": "https://www.dell.com/en-uk"})
    assert requested == ["https://www.delltechnologies.com/asset/en-uk/test/alias-test.pdf"]

    with store.connect() as conn:
        row = conn.execute("SELECT raw_path,metadata_json FROM sources LIMIT 1").fetchone()
    assert row is not None
    raw_path = Path(row["raw_path"])
    assert raw_path.exists()
    assert len(raw_path.name) == 68  # 64 hex characters plus .pdf
    metadata = json.loads(row["metadata_json"])
    assert metadata["discovered_url"].endswith(".pdf.external")
    assert metadata["download_url"].endswith(".pdf")
    crawler.http.close()


def test_repair_v63_requeues_and_projects_external_alias(tmp_path: Path) -> None:
    import json
    import subprocess
    import sys

    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

    root = Path(__file__).resolve().parents[1]
    knowledge = tmp_path / "knowledge"
    knowledge.mkdir()
    db = knowledge / "dell.db"
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.delltechnologies.com/asset/en-uk/test.pdf.external"
    assert store.enqueue(url, resource_class="PAGE")
    store.mark_queue(url, "DEFERRED", "old path failure")

    result = subprocess.run(
        [
            sys.executable,
            str(root / "repair_v63.py"),
            "--db",
            str(db),
            "--knowledge",
            str(knowledge),
            "--no-backup",
        ],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr + result.stdout
    item = store.queue_item(url)
    assert item is not None
    assert item["resource_class"] == "DOCUMENT"
    assert item["status"] == "PENDING"
    report = json.loads((knowledge / "V63_REPAIR_REPORT.json").read_text(encoding="utf-8"))
    assert report["pdf_external_aliases"][0]["download_url"].endswith("test.pdf")
    assert report["short_path_projection"][0]["local_path_length"] < 240
