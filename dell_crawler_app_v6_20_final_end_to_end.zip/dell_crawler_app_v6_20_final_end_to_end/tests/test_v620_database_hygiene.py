from __future__ import annotations

from pathlib import Path

from dell_crawler_core.db_hygiene import purge_irrelevant_legacy_data
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def test_v620_purges_runtime_but_preserves_knowledge_and_policy(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    now = "2026-09-16T12:00:00+00:00"
    with store.connect() as conn:
        conn.execute("INSERT INTO sources(url,canonical_url,title,page_type,content_hash,fetched_at,http_status) VALUES(?,?,?,?,?,?,?)",
                     ("https://www.dell.com/en-us/p/x", "https://www.dell.com/en-us/p/x", "X", "ProductPage", "h", now, 200))
        conn.execute("INSERT INTO chunks(source_url,chunk_index,heading,text,content_hash) VALUES(?,?,?,?,?)",
                     ("https://www.dell.com/en-us/p/x", 0, "", "Useful product text", "c"))
        conn.execute("INSERT INTO interactions(source_url,label,observed_at) VALUES(?,?,?)", ("u", "old", now))
        conn.execute("INSERT INTO self_heal_events(observed_at) VALUES(?)", (now,))
        conn.execute("INSERT INTO web_state_observations(source_url,state_signature,observed_at) VALUES(?,?,?)", ("u", "s", now))
        conn.execute("INSERT INTO action_decisions(source_url,observed_at) VALUES(?,?)", ("u", now))
        conn.execute("INSERT INTO action_trajectories(source_url,control_key,observed_at) VALUES(?,?,?)", ("u", "k", now))
        conn.execute("INSERT INTO action_policy_memory(page_type,control_key,visits,updated_at) VALUES(?,?,?,?)", ("WebPage", "k", 4, now))
    result = purge_irrelevant_legacy_data(store, keep_crawl_runs=3, vacuum=False)
    assert result["ok"] is True
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM self_heal_events").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM web_state_observations").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM action_decisions").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM action_trajectories").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM action_policy_memory").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0] == 1


def test_v620_removes_only_empty_dead_sources_and_preserves_permanent_queue(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    now = "2026-09-16T12:00:00+00:00"
    dead = "https://www.dell.com/en-us/dead"
    evidenced = "https://www.dell.com/en-us/dead-with-evidence"
    with store.connect() as conn:
        conn.execute("INSERT INTO sources(url,canonical_url,title,page_type,content_hash,fetched_at,http_status) VALUES(?,?,?,?,?,?,?)",
                     (dead, dead, "", "WebPage", "", now, 404))
        conn.execute("INSERT INTO sources(url,canonical_url,title,page_type,content_hash,fetched_at,http_status) VALUES(?,?,?,?,?,?,?)",
                     (evidenced, evidenced, "", "WebPage", "", now, 410))
        conn.execute("INSERT INTO extraction_evidence(source_url,evidence_kind,evidence_hash,payload_json,reason,observed_at) VALUES(?,?,?,?,?,?)",
                     (evidenced, "unmapped", "e", "{}", "keep", now))
        conn.execute("INSERT INTO crawl_queue(url,status,discovered_at,updated_at) VALUES(?,?,?,?)", (dead, "SKIPPED_PERMANENT", now, now))
    purge_irrelevant_legacy_data(store, vacuum=False)
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM sources WHERE url=?", (dead,)).fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM sources WHERE url=?", (evidenced,)).fetchone()[0] == 1
        assert conn.execute("SELECT status FROM crawl_queue WHERE url=?", (dead,)).fetchone()[0] == "SKIPPED_PERMANENT"


def test_v620_removes_orphans_and_irrelevant_skipped_rows(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    now = "2026-09-16T12:00:00+00:00"
    with store.connect() as conn:
        conn.execute("INSERT INTO semantic_entity_aliases(alias_key,canonical_node_key,node_type,observed_at) VALUES(?,?,?,?)", ("x", "missing", "Brand", now))
        conn.execute("INSERT INTO product_identity_aliases(alias_key,canonical_product_key,observed_at) VALUES(?,?,?)", ("x", "missing", now))
        conn.execute("INSERT INTO product_enrichment_state(product_key,product_id,updated_at) VALUES(?,?,?)", ("missing", 999, now))
        conn.execute("INSERT INTO extraction_validation(source_url,report_json,validated_at) VALUES(?,?,?)", ("https://www.dell.com/en-us/missing", "{}", now))
        conn.execute("INSERT INTO crawl_queue(url,status,discovered_at,updated_at) VALUES(?,?,?,?)", ("https://www.dell.com/en-us/skip", "SKIPPED", now, now))
    result = purge_irrelevant_legacy_data(store, vacuum=False)
    assert result["deleted"]["orphan_semantic_aliases"] == 1
    assert result["deleted"]["orphan_product_identity_aliases"] == 1
    assert result["deleted"]["orphan_product_enrichment_rows"] == 1
    assert result["deleted"]["orphan_validation_rows"] == 1
    assert result["deleted"]["irrelevant_skipped_queue_rows"] == 1
