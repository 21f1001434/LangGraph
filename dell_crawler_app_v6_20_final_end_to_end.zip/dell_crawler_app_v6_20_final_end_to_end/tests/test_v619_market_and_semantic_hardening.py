from __future__ import annotations

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.market_context import infer_market_context, price_predicate
from dell_crawler_core.product_intelligence import parse_product_card
from dell_crawler_core.semantic_identity import semantic_entity_key


def _page(url: str, text: str, *, page_type: str = "Product") -> CrawlPage:
    return CrawlPage(
        url=url,
        canonical_url=url,
        title="Dell Test",
        page_type=page_type,
        snapshot="",
        visible_text=text,
    )


def test_market_context_is_url_aware_and_does_not_default_to_gbp() -> None:
    us = infer_market_context("https://www.dell.com/en-us/shop/test")
    india = infer_market_context("https://www.dell.com/en-in/shop/test")
    global_page = infer_market_context("https://infohub.delltechnologies.com/test")
    assert (us.market, us.currency) == ("US", "USD")
    assert (india.market, india.currency) == ("IN", "INR")
    assert global_page.currency == ""
    assert price_predicate("GBP") == "PRICE_GBP"
    assert price_predicate("USD") == "PRICE"


def test_deterministic_extractor_maps_us_price_as_usd() -> None:
    page = _page(
        "https://www.dell.com/en-us/shop/test/spd/test-model",
        "Dell Test Laptop\nDell Price $1,299.99\nIntel Core Ultra 7\n32 GB DDR5 memory\n1 TB SSD storage",
    )
    extraction = DellContentExtractor(aia=None, use_llm=False, use_vision=False).deterministic_extract(page)
    assert extraction["page"]["market"] == "US"
    assert extraction["page"]["currency"] == "USD"
    price_facts = [f for f in extraction["facts"] if f.get("predicate") in {"PRICE", "PRICE_GBP"}]
    assert any(f.get("predicate") == "PRICE" and f.get("unit") == "USD" for f in price_facts)
    assert not any(f.get("predicate") == "PRICE_GBP" for f in price_facts)


def test_product_card_uses_market_currency_and_does_not_invent_dell_brand() -> None:
    source = "https://www.dell.com/en-us/shop/accessories/scr/accessories"
    raw = {
        "name": "Logitech MX Keys S Keyboard",
        "url": "https://www.dell.com/en-us/shop/logitech-mx-keys-s/apd/123-abc/pc-accessories",
        "text": "Logitech MX Keys S Keyboard\nDell Price $109.99\nOrder Code 123-ABC",
    }
    record = parse_product_card(raw, source)
    assert record is not None
    assert record.currency == "USD"
    assert record.brand == ""
    assert record.current_price == "109.99"


def test_category_plural_and_heading_suffixes_converge() -> None:
    one = semantic_entity_key("Category", "Laptop", {})
    two = semantic_entity_key("Category", "Laptops", {})
    three = semantic_entity_key("Category", "Laptop Products Category", {})
    assert one == two == three == "category:laptop"


def test_family_dell_prefix_and_series_suffix_converge_when_brand_known() -> None:
    one = semantic_entity_key("ProductFamily", "Dell Pro", {"brand": "Dell"})
    two = semantic_entity_key("ProductFamily", "Pro Series", {"brand": "Dell Technologies, Inc."})
    assert one == two == "product-family:dell:pro"


def test_repair_v619_rekeys_category_and_corrects_legacy_us_gbp(tmp_path) -> None:
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
    from repair_v619 import repair

    db = tmp_path / "knowledge" / "kg.db"
    db.parent.mkdir(parents=True)
    store = SQLiteKnowledgeGraph(db)
    source = "https://www.dell.com/en-us/shop/laptops/scr/laptops"
    store.ingest_page(_page(source, "Dell laptops", page_type="ProductCatalog"))
    store.upsert_node("legacy:cat:1", "Category", "Laptops", {"source_url": source})
    store.upsert_node("legacy:cat:2", "Category", "Laptop Products Category", {"source_url": source})
    product_key = "product-order:test-us-1"
    store.upsert_node(product_key, "Product", "Dell Test Laptop", {
        "source_url": source,
        "order_code": "TEST-US-1",
        "price": "1299.99",
        "currency": "GBP",
        "product_category": "Laptop",
    })
    store.add_fact(product_key, "PRICE_GBP", "1299.99", source, unit="GBP", confidence=0.9)

    result = repair(db, db.parent, force_active=True, no_backup=True)
    assert result["integrity_after"].casefold() == "ok"

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        categories = conn.execute("SELECT node_key FROM nodes WHERE node_type='Category'").fetchall()
        product = conn.execute("SELECT attributes_json FROM nodes WHERE node_key=?", (product_key,)).fetchone()
        old_price = conn.execute("SELECT COUNT(*) FROM facts WHERE subject_id=(SELECT id FROM nodes WHERE node_key=?) AND predicate='PRICE_GBP'", (product_key,)).fetchone()[0]
        new_price = conn.execute("SELECT unit FROM facts WHERE subject_id=(SELECT id FROM nodes WHERE node_key=?) AND predicate='PRICE'", (product_key,)).fetchone()
    import json
    attrs = json.loads(product["attributes_json"])
    assert [row["node_key"] for row in categories] == ["category:laptop"]
    assert attrs["currency"] == "USD"
    assert old_price == 0
    assert new_price["unit"] == "USD"
    quality = store.semantic_quality_report()
    assert quality["currency_market_mismatches"] == 0
    assert quality["clean_for_semantic_sync"] is True


def test_locale_helpers_drive_scope_and_http_language() -> None:
    from dell_crawler_core.market_context import accept_language_for_locale, hreflang_aliases, market_for_locale, normalize_locale
    from dell_crawler_core.snapshot_extract import canonicalize_url, is_locale_scope

    assert normalize_locale("in-en") == "en-in"
    assert market_for_locale("en-in") == "IN"
    assert accept_language_for_locale("en-in") == "en-IN,en;q=0.9"
    assert hreflang_aliases("en-uk") == {"en-uk", "en-gb", "x-default"}
    assert canonicalize_url("https://www.dell.com/in-en/shop/test") == "https://www.dell.com/en-in/shop/test"
    assert canonicalize_url("https://www.dell.com/support/home/in-en") == "https://www.dell.com/support/home/en-in"
    assert is_locale_scope("https://www.dell.com/en-in/shop/test", locale="en-in") is True
    assert is_locale_scope("https://www.dell.com/en-uk/shop/test", locale="en-in") is False


def test_unbranded_model_only_products_do_not_merge_by_model(tmp_path) -> None:
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph, _sanitize_product_entity

    first_key, first_type, _, first_attrs = _sanitize_product_entity(
        "Acme Dock Model X", {"model": "X"}, "", "legacy:first", "https://www.dell.com/en-us/shop/accessories"
    )
    second_key, second_type, _, second_attrs = _sanitize_product_entity(
        "Contoso Display Model X", {"model": "X"}, "", "legacy:second", "https://www.dell.com/en-us/shop/accessories"
    )
    assert first_type == second_type == "Product"
    assert first_key != second_key

    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.upsert_node(first_key, "Product", "Acme Dock Model X", first_attrs)
    resolved = store.resolve_product_node_key(second_key, second_attrs, "Contoso Display Model X")
    assert resolved == second_key


def test_support_archetypes_are_locale_neutral() -> None:
    from dell_crawler_core.dell_site_profile import archetype_for

    india = archetype_for("https://www.dell.com/support/home/en-in", text="Drivers and downloads")
    us_video = archetype_for("https://www.dell.com/support/contents/en-us/videos/test", text="Video title")
    assert india is not None and india.name == "SupportManualsAndDrivers"
    assert us_video is not None and us_video.name == "SupportVideo"
