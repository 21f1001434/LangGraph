from __future__ import annotations

from dell_crawler_core.dell_site_profile import seed_urls_for_profile
from dell_crawler_core.masthead_discovery import DellMastheadDiscovery, EXPECTED_MENU_MANIFEST
from dell_crawler_core.snapshot_extract import is_locale_scope


def test_manifest_covers_user_supplied_top_tabs_and_children() -> None:
    assert set(EXPECTED_MENU_MANIFEST) >= {
        "Artificial Intelligence", "IT Infrastructure", "Computers & Accessories",
        "Services", "Support", "Deals", "Financing", "Account / Profile",
    }
    assert "Drivers & Downloads" in EXPECTED_MENU_MANIFEST["Support"]
    assert "Workstations" in EXPECTED_MENU_MANIFEST["Computers & Accessories"]
    assert "Dell APEX Subscriptions" in EXPECTED_MENU_MANIFEST["IT Infrastructure"]
    assert "Dell Outlet (Certified Refurbished)" in EXPECTED_MENU_MANIFEST["Deals"]
    assert "Make a Payment - Home" in EXPECTED_MENU_MANIFEST["Financing"]


def test_locale_scope_and_seed_localization_support_us_and_uk() -> None:
    assert is_locale_scope("https://www.dell.com/en-us/shop/laptops", locale="en-us")
    assert not is_locale_scope("https://www.dell.com/en-us/shop/laptops", locale="en-uk")
    assert is_locale_scope("https://www.dell.com/support/home/en-us", locale="en-us")
    seeds = seed_urls_for_profile("public_catalog", locale="en-us")
    assert any("/en-us/shop/" in url for url in seeds)
    assert not any("/en-uk/shop/" in url for url in seeds)


class FakeRuntime:
    def __init__(self) -> None:
        self.state = "root"
        self.clicked: list[str] = []
        self.hovered: list[str] = []
        self.current_url = "https://www.dell.com/en-us"

    def navigate(self, url: str, intent: str = ""):
        self.state = "root"
        self.current_url = url
        return {"ok": True}

    def wait(self, *args, **kwargs):
        return {"ok": True}

    def hover(self, ref: str, label: str, intent: str = ""):
        self.hovered.append(label)
        if label in {"Support", "Deals", "Financing"}:
            self.state = label.lower()
        return {"ok": True}

    def click(self, ref: str, label: str, intent: str = ""):
        self.clicked.append(label)
        if label == "Artificial Intelligence":
            self.current_url = "https://www.dell.com/en-us/shop/dell-ai-solutions/sc/artificial-intelligence"
            self.state = "ai"
        elif label in {"Support", "Deals", "Financing"}:
            self.state = label.lower()
        return {"ok": True}

    def snapshot(self, boxes: bool = True, intent: str = ""):
        return {"ok": True, "detail": self._snapshot()}

    def _snapshot(self) -> str:
        head = f"Page URL: {self.current_url}\nPage Title: Dell\n"
        if self.state == "root":
            return head + "\n".join([
                '- link "Artificial Intelligence" [ref=ai]',
                '  - /url: /en-us/shop/dell-ai-solutions/sc/artificial-intelligence',
                '- button "IT Infrastructure" [ref=it]',
                '- button "Computers & Accessories" [ref=pc]',
                '- button "Services" [ref=svc]',
                '- button "Support" [ref=sup]',
                '- button "Deals" [ref=deal]',
                '- button "Financing" [ref=fin]',
            ])
        if self.state == "support":
            return head + "\n".join([
                '- button "Support" [ref=sup]',
                '- link "Support Home" [ref=s1]', '  - /url: /support/home/en-us',
                '- link "Drivers & Downloads" [ref=s2]', '  - /url: /support/home/en-us?app=drivers',
                '- link "Manuals & Documentation" [ref=s3]', '  - /url: /support/home/en-us?app=manuals',
                '- link "Community" [ref=s4]', '  - /url: /community/en/',
            ])
        if self.state == "deals":
            return head + "\n".join([
                '- button "Deals" [ref=deal]',
                '- link "View All Deals" [ref=d1]', '  - /url: /en-us/shop/dell-deals/cp/dell-deals',
                '- link "Laptop Deals" [ref=d2]', '  - /url: /en-us/shop/deals/laptops',
                '- button "Discounts, Offers & Coupons" [ref=d3] [expanded=false]',
            ])
        if self.state == "financing":
            return head + "\n".join([
                '- button "Financing" [ref=fin]',
                '- link "For Home Purchases" [ref=f1]', '  - /url: /en-us/lp/dell-financing',
                '- link "For Business Purchases" [ref=f2]', '  - /url: /en-us/lp/business-financing',
                '- link "Make a Payment - Home" [ref=f3]', '  - /url: /en-us/payment/home',
            ])
        return head


def test_masthead_discovery_queues_safe_pages_and_never_activates_payment() -> None:
    runtime = FakeRuntime()
    result = DellMastheadDiscovery(runtime, locale="en-us", max_actions=80).discover()
    assert any("/support/home/en-us" in url for url in result.urls)
    assert any("/shop/dell-deals/" in url for url in result.urls)
    assert any("/lp/dell-financing" in url for url in result.urls)
    assert not any("/payment/" in url for url in result.urls)
    assert all("Make a Payment" not in label for label in runtime.clicked)
