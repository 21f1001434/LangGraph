from __future__ import annotations

import io
import json
import subprocess
import sys
from pathlib import Path

import httpx
from pypdf import PdfWriter

from dell_crawler_core.crawl_models import CrawlConfig, CrawlStats
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.document_pipeline import (
    parse_mcp_network_request_indices,
    validate_pdf_bytes,
    validate_pdf_file,
)
from dell_crawler_core.frontier_scheduler import DOCUMENT
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime


def pdf_bytes() -> bytes:
    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": "Dell PDF Test"})
    writer.write(buffer)
    return buffer.getvalue()


class FakeStore:
    def touch_queue(self, *args, **kwargs):
        return True


class FakeRuntime:
    output_dir = Path(".")
    started = False


def crawler_for(tmp_path: Path, handler) -> DellEnUkKnowledgeCrawler:
    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"], document_direct_http_enabled=True)
    crawler.stats = CrawlStats(run_id="TEST", started_at="2026-07-29T00:00:00+00:00")
    crawler.run_id = "TEST"
    crawler._stopped = False
    crawler.http = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    crawler.store = FakeStore()
    crawler.runtime = FakeRuntime()
    crawler.document_dir = tmp_path / "documents"
    crawler.document_dir.mkdir()
    crawler.document_quarantine_dir = tmp_path / "quarantine"
    crawler.pdf_failure_log = tmp_path / "PDF_FAILURES.jsonl"
    crawler._emit = lambda *args, **kwargs: None
    return crawler


def test_html_block_page_is_not_accepted_as_pdf() -> None:
    result = validate_pdf_bytes(b"<!doctype html><html><title>Access Denied</title></html>")
    assert result.ok is False
    assert "HTML" in result.reason


def test_valid_pdf_passes_signature_and_structure(tmp_path: Path) -> None:
    path = tmp_path / "valid.pdf"
    path.write_bytes(pdf_bytes())
    result = validate_pdf_file(path, parse_structure=True)
    assert result.ok is True
    assert result.pages == 1


def test_direct_http_200_html_immediately_uses_browser_recovery(tmp_path: Path) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, headers={"content-type": "text/html"}, content=b"<html>Access denied</html>")

    crawler = crawler_for(tmp_path, handler)
    recovered = pdf_bytes()
    calls = []

    def browser(url: str, path: Path, parent_url: str = ""):
        calls.append((url, parent_url))
        path.write_bytes(recovered)
        return url, 200, {
            "content-type": "application/pdf",
            "content-length": str(len(recovered)),
            "x-dell-fetch-mode": "test_browser_recovery",
        }, len(recovered)

    crawler._download_resource_via_browser = browser
    path = crawler.document_dir / "test.pdf"
    result = crawler._download_resource_resumable(
        "https://www.delltechnologies.com/asset/en-uk/test.pdf",
        path,
        {"parent_url": "https://www.dell.com/en-uk/test"},
    )
    assert calls
    assert result[2]["x-dell-fetch-mode"] == "test_browser_recovery"
    assert validate_pdf_file(path).ok
    assert crawler.stats.document_http_header_retries == 1


def test_valid_direct_pdf_is_atomically_saved(tmp_path: Path) -> None:
    payload = pdf_bytes()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, headers={"content-type": "application/pdf"}, content=payload)

    crawler = crawler_for(tmp_path, handler)
    path = crawler.document_dir / "direct.pdf"
    result = crawler._download_resource_resumable("https://www.dell.com/direct.pdf", path, {})
    assert path.exists()
    assert not path.with_suffix(".pdf.part").exists()
    assert validate_pdf_file(path).ok
    assert result[2]["x-dell-fetch-mode"] == "direct_http"
    assert crawler.stats.pdf_direct_downloads == 1


def test_invalid_existing_pdf_is_quarantined_before_redownload(tmp_path: Path) -> None:
    payload = pdf_bytes()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, headers={"content-type": "application/pdf"}, content=payload)

    crawler = crawler_for(tmp_path, handler)
    path = crawler.document_dir / "existing.pdf"
    path.write_text("<html>Request rejected</html>", encoding="utf-8")
    crawler._download_resource_resumable("https://www.dell.com/existing.pdf", path, {})
    assert validate_pdf_file(path).ok
    assert crawler.stats.pdf_invalid_files_quarantined == 1
    assert any(crawler.document_quarantine_dir.iterdir())


def test_browser_api_request_chunk_parser_uses_fixed_application_code(tmp_path: Path) -> None:
    payload = {
        "ok": True,
        "status": 206,
        "headers": {"content-type": "application/pdf"},
        "contentType": "application/pdf",
        "contentRange": "bytes 0-4/5",
        "contentLength": "5",
        "bytes": 5,
        "base64": "JVBERi0=",
    }

    class Runtime:
        def run_application_code(self, code: str, intent: str = ""):
            assert "page.context().request.get" in code
            return {"ok": True, "detail": "### Result\n" + json.dumps(payload)}

        _parse_json_detail = staticmethod(PlaywrightMCPRuntime._parse_json_detail)

    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.runtime = Runtime()
    result = crawler._browser_api_fetch_resource_chunk("https://www.dell.com/test.pdf", "", 0, 4)
    assert result["status"] == 206
    assert result["bytes"] == 5


def test_current_network_request_schema_uses_static() -> None:
    runtime = object.__new__(PlaywrightMCPRuntime)
    runtime.tools = {
        "browser_network_requests": {
            "schema": {
                "type": "object",
                "properties": {"static": {"type": "boolean"}},
            }
        }
    }
    adapted = runtime._adapt_args("browser_network_requests", {"includeStatic": True})
    assert adapted == {"static": True}


def test_network_request_index_parser_finds_pdf() -> None:
    detail = """
    # 11 GET https://example.com/other.js
    [27] GET https://www.delltechnologies.com/asset/en-uk/test.pdf 200
    """
    assert parse_mcp_network_request_indices(detail, "https://www.delltechnologies.com/asset/en-uk/test.pdf") == [27]


def test_repair_v62_reclassifies_and_requeues_pdf(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]
    db = tmp_path / "dell.db"
    knowledge = tmp_path / "knowledge"
    knowledge.mkdir()
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.delltechnologies.com/asset/en-uk/test.pdf"
    assert store.enqueue(url, resource_class="PAGE")
    store.mark_queue(url, "DEFERRED", "old failure")

    result = subprocess.run(
        [
            sys.executable,
            str(root / "repair_v62.py"),
            "--db",
            str(db),
            "--knowledge",
            str(knowledge),
            "--no-backup",
        ],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr + result.stdout
    item = store.queue_item(url)
    assert item is not None
    assert item["resource_class"] == DOCUMENT
    assert item["status"] == "PENDING"
    assert item["attempts"] == 0


def test_pdf_pipeline_downloads_extracts_and_persists_source(tmp_path: Path) -> None:
    from dell_crawler_core.content_extractor import DellContentExtractor

    payload = pdf_bytes()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "application/pdf", "content-length": str(len(payload))},
            content=payload,
        )

    class Runtime:
        started = False
        output_dir = tmp_path / "mcp"

    store = SQLiteKnowledgeGraph(tmp_path / "knowledge" / "dell.db")
    config = CrawlConfig(
        start_urls=["https://www.dell.com/en-uk"],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        vision_pdf_pages=False,
        document_direct_http_enabled=True,
    )
    extractor = DellContentExtractor(
        aia=None,
        use_llm=False,
        use_vision=False,
        vision_cache_dir=tmp_path / "knowledge" / "vision_cache",
        text_cache_dir=tmp_path / "knowledge" / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(
        runtime=Runtime(),
        store=store,
        extractor=extractor,
        config=config,
        output_dir=tmp_path / "knowledge",
    )
    crawler.http.close()
    crawler.http = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    url = "https://www.delltechnologies.com/asset/en-uk/test-integration.pdf"
    counts = crawler._process_pdf({"url": url, "depth": 0, "parent_url": "https://www.dell.com/en-uk"})
    stats = store.stats()
    assert crawler.stats.pdfs_stored == 1
    assert stats["sources"] == 1
    assert counts["_completeness_score"] >= 0
    with store.connect() as conn:
        row = conn.execute("SELECT mime_type,raw_path,metadata_json FROM sources LIMIT 1").fetchone()
        assert row is not None
        assert row["mime_type"] == "application/pdf"
        assert Path(row["raw_path"]).exists()
        metadata = json.loads(row["metadata_json"])
        assert metadata["download_strategy"] == "direct_http"
        assert metadata["pdf_validation"]["ok"] is True
    crawler.http.close()
