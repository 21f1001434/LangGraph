from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

ROOT = Path(__file__).resolve().parents[1]
REPAIR = ROOT / "repair_v610.py"


def _run_repair(db: Path, knowledge: Path, *extra: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            str(REPAIR),
            "--db",
            str(db),
            "--knowledge",
            str(knowledge),
            "--no-backup",
            *extra,
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=60,
        check=False,
    )


def test_v610_repair_replays_source_missing_queue_row(tmp_path: Path) -> None:
    db = tmp_path / "knowledge" / "dell_en_uk.db"
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.dell.com/en-uk/shop/example/spd/example-product"
    store.upsert_source(
        url=url,
        canonical_url=url,
        title="Example Product",
        page_type="Product",
        content_hash="abc123",
        http_status=200,
    )

    result = _run_repair(db, db.parent)

    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    with store.connect() as conn:
        row = conn.execute(
            "SELECT status,resource_class,lane_priority FROM crawl_queue WHERE url=?",
            (url,),
        ).fetchone()
    assert row is not None
    assert row["status"] == "PENDING"
    assert row["resource_class"]


def test_v610_repair_recovers_unexpired_orphan_lease(tmp_path: Path) -> None:
    db = tmp_path / "knowledge" / "dell_en_uk.db"
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.dell.com/en-uk/shop/orphan/spd/orphan-product"
    store.enqueue(url, depth=0, priority=1)
    future = (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat(timespec="seconds")
    with store.connect() as conn:
        conn.execute(
            """
            UPDATE crawl_queue
            SET status='IN_PROGRESS',lease_owner='stopped-worker',lease_expires_at=?
            WHERE url=?
            """,
            (future, url),
        )

    result = _run_repair(db, db.parent, "--only-incomplete")

    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    assert "Treating them as abandoned" in result.stdout
    with store.connect() as conn:
        row = conn.execute(
            "SELECT status,lease_owner,lease_expires_at FROM crawl_queue WHERE url=?",
            (url,),
        ).fetchone()
    assert row["status"] == "PENDING"
    assert row["lease_owner"] == ""
    assert row["lease_expires_at"] == ""

    report = json.loads((db.parent / "V610_REPAIR_REPORT.json").read_text(encoding="utf-8"))
    assert report["unexpired_worker_leases_before_repair"] == 1
    assert report["abandoned_unexpired_leases_recovered"] == 1
