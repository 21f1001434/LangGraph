from __future__ import annotations

import base64
import io
import json
from pathlib import Path

import httpx
from pypdf import PdfWriter

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.document_pipeline import (
    parse_mcp_network_request_entries,
    pdf_urls_consistent,
    validate_pdf_file,
)
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime


PARENT = "https://www.dell.com/en-uk/shop/servers/poweredge"
REQUESTED = "https://www.dell.com/asset/en-uk/products/servers/poweredge-rack-series-spec-sheet.pdf.external"
CANONICAL = "https://www.delltechnologies.com/assetlink/documents/enterprise/uk/en/products/servers/technical-support/poweredge-rack-series-spec-sheet.pdf"


def _pdf_bytes() -> bytes:
    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": "Dell PowerEdge Rack Series"})
    writer.write(buffer)
    return buffer.getvalue()


class NoopAIA:
    vision_model = ""

    def vision_json(self, *args, **kwargs):
        return kwargs.get("fallback", {})


class DuplicateHrefBrowserRuntime:
    def __init__(self, root: Path, payload: bytes) -> None:
        self.output_dir = root
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.payload = payload
        self.started = True
        self.server_url = "http://127.0.0.1:9999/mcp"
        self.tools = {"browser_evaluate", "browser_run_code", "browser_tabs"}
        self.current_url = PARENT
        self.run_code_calls = 0
        self.click_code_calls = 0

    def start(self):
        return {"ok": True}

    def keep_single_dell_tab(self):
        return {"ok": True}

    def tab_inventory(self, **kwargs):
        return [{"index": 0, "url": self.current_url, "current": True}]

    def select_tab(self, index: int, **kwargs):
        return {"ok": True}

    def tabs(self, action: str, url: str = "", **kwargs):
        if action == "new" and url:
            self.current_url = url
        return {"ok": True}

    def navigate(self, url: str, **kwargs):
        self.current_url = url
        return {"ok": True}

    def wait(self, *args, **kwargs):
        return {"ok": True}

    def evaluate_readonly(self, expression: str, **kwargs):
        if "candidates:results" in expression:
            duplicates = [
                {
                    "url": REQUESTED,
                    "raw": REQUESTED,
                    "label": "View spec sheet",
                    "visible": i == 0,
                    "frameUrl": PARENT,
                    "rootKind": "document",
                    "attr": "href",
                }
                for i in range(84)
            ]
            duplicates.append(
                {
                    "url": CANONICAL,
                    "raw": CANONICAL,
                    "label": "Download spec sheet",
                    "visible": True,
                    "frameUrl": PARENT,
                    "rootKind": "shadow",
                    "attr": "data-download-url",
                }
            )
            payload = {"ok": True, "pageUrl": PARENT, "candidates": duplicates}
        else:
            payload = {
                "url": self.current_url,
                "title": "Dell source page",
                "readyState": "complete",
                "hasEmbed": False,
                "bodyTextChars": 1000,
            }
        return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}

    def run_application_code(self, code: str, **kwargs):
        self.run_code_calls += 1
        if "page.context().request.get" in code:
            result = {
                "ok": True,
                "status": 200,
                "url": CANONICAL,
                "headers": {
                    "content-type": "application/pdf",
                    "content-length": str(len(self.payload)),
                },
                "contentType": "application/pdf",
                "contentRange": "",
                "contentLength": str(len(self.payload)),
                "totalBodyBytes": len(self.payload),
                "rangeHonored": False,
                "requestedStart": 0,
                "requestedEnd": 262143,
                "bytes": len(self.payload),
                "base64": base64.b64encode(self.payload).decode("ascii"),
            }
            return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(result))}
        if "matchCount:matches.length" in code:
            self.click_code_calls += 1
            payload = {"ok": True, "status": "clicked", "matchCount": 84, "chosenHref": CANONICAL}
            return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}
        return {"ok": True, "detail": "### Result\n\"{}\""}

    @staticmethod
    def _parse_json_detail(detail: str):
        raw = detail.split("### Result", 1)[-1].strip()
        value = json.loads(raw)
        if isinstance(value, str):
            value = json.loads(value)
        return value

    def network_requests(self, **kwargs):
        return {"ok": True, "detail": ""}

    def click(self, *args, **kwargs):
        raise AssertionError("strict global locator must not be used when browser-context href succeeds")

    def snapshot(self, **kwargs):
        return {"ok": True, "detail": ""}


def _crawler(tmp_path: Path, runtime: DuplicateHrefBrowserRuntime):
    knowledge = tmp_path / "knowledge"
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    store.upsert_source(
        PARENT,
        PARENT,
        "PowerEdge",
        "ProductFamily",
        "hash",
        metadata={
            "browser_structured_dom": {
                "controls": [
                    {"tag": "a", "label": "View spec sheet", "attrs": {"href": REQUESTED}}
                ]
            }
        },
    )
    config = CrawlConfig(
        start_urls=[PARENT],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        document_direct_http_enabled=False,
        document_dom_href_first_enabled=True,
        document_browser_context_request_first=True,
        document_ui_click_fallback_enabled=True,
    )
    extractor = DellContentExtractor(
        aia=NoopAIA(),
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)
    return crawler


def test_duplicate_dom_hrefs_are_deduped_and_downloaded_in_browser_context(tmp_path: Path) -> None:
    payload = _pdf_bytes()
    runtime = DuplicateHrefBrowserRuntime(tmp_path / "mcp", payload)
    crawler = _crawler(tmp_path, runtime)
    raw_http_calls = 0

    def forbidden(request: httpx.Request) -> httpx.Response:
        nonlocal raw_http_calls
        raw_http_calls += 1
        raise AssertionError("standalone httpx PDF transport must stay disabled")

    crawler.http.close()
    crawler.http = httpx.Client(transport=httpx.MockTransport(forbidden))
    path = crawler.document_dir / "browser-context.pdf"
    result = crawler._download_resource_resumable(
        REQUESTED,
        path,
        {"url": REQUESTED, "_queue_url": REQUESTED, "parent_url": PARENT, "relation": "CONTROL_CLICK_DOCUMENT"},
    )

    assert raw_http_calls == 0
    assert result[2]["x-dell-fetch-mode"] == "playwright_browser_context_href"
    assert validate_pdf_file(path, parse_structure=True).ok
    assert crawler.stats.pdf_browser_context_primary_downloads == 1
    assert crawler.stats.pdf_dom_href_candidates == 2
    assert crawler.stats.pdf_duplicate_href_groups >= 83
    assert runtime.click_code_calls == 0
    context = crawler._last_pdf_acquisition_context[REQUESTED.replace(".external", "")]
    assert len(context["candidate_urls"]) == 2
    crawler.http.close()


def test_network_list_parser_and_canonical_redirect_consistency() -> None:
    detail = (
        "# 42 GET https://www.dell.com/asset/en-uk/a.pdf\n"
        "[43] 200 https://www.delltechnologies.com/assetlink/doc/original/a.pdf\n"
    )
    rows = parse_mcp_network_request_entries(detail)
    assert [row["index"] for row in rows] == [42, 43]
    assert pdf_urls_consistent(
        "https://www.dell.com/asset/en-uk/a.pdf.external",
        "https://www.delltechnologies.com/assetlink/doc/original/a.pdf",
    )
    assert not pdf_urls_consistent(
        "https://www.dell.com/asset/en-uk/a.pdf",
        "https://www.dell.com/asset/en-uk/unrelated.pdf",
    )


def test_persistent_profile_lease_blocks_second_live_owner(tmp_path: Path) -> None:
    profile = tmp_path / "profile" / "dell_crawler"
    runtime = PlaywrightMCPRuntime(user_data_dir=str(profile), output_dir=str(tmp_path / "out"))
    runtime._profile_lease_path.parent.mkdir(parents=True, exist_ok=True)
    runtime._profile_lease_path.write_text(
        json.dumps({"pid": 424242, "user_data_dir": str(profile)}),
        encoding="utf-8",
    )
    runtime._pid_alive = lambda pid: pid == 424242  # type: ignore[method-assign]
    try:
        ok, info = runtime._acquire_profile_lease()
        assert ok is False
        assert info["owner_pid"] == 424242
        assert "already owned" in info["error"]
    finally:
        runtime._profile_lease_path.unlink(missing_ok=True)
        runtime.loop_thread.stop()


def test_repair_v67_requeues_documents_and_archives_old_transport_log(tmp_path: Path) -> None:
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    knowledge = tmp_path / "knowledge"
    knowledge.mkdir()
    store = SQLiteKnowledgeGraph(knowledge / "dell_en_uk.db")
    assert store.enqueue(
        REQUESTED,
        parent_url=PARENT,
        relation="CONTROL_CLICK_DOCUMENT",
        resource_class="PAGE",
    )
    store.mark_queue(REQUESTED, "DEFERRED", "HTTP 403")
    (knowledge / "PDF_TRANSPORT_EVENTS.jsonl").write_text(
        json.dumps({"stage": "direct_http", "http_status": 403, "url": REQUESTED}) + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            sys.executable,
            str(root / "repair_v67.py"),
            "--db",
            str(knowledge / "dell_en_uk.db"),
            "--knowledge",
            str(knowledge),
            "--no-backup",
        ],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=90,
    )
    assert result.returncode == 0, result.stderr + result.stdout
    report = json.loads((knowledge / "V67_REPAIR_REPORT.json").read_text(encoding="utf-8"))
    assert report["sqlite_integrity"] == "ok"
    assert report["documents_requeued"] == 1
    assert report["documents_marked_browser_context"] == 1
    assert not (knowledge / "PDF_TRANSPORT_EVENTS.jsonl").exists()
    assert list(knowledge.glob("PDF_TRANSPORT_EVENTS_PRE_V67_*.jsonl"))
    with store.connect() as conn:
        row = conn.execute("SELECT status,resource_class,attempts,relation FROM crawl_queue WHERE url=?", (REQUESTED,)).fetchone()
    assert dict(row) == {
        "status": "PENDING",
        "resource_class": "DOCUMENT",
        "attempts": 0,
        "relation": "CONTROL_BROWSER_CONTEXT_DOCUMENT",
    }
