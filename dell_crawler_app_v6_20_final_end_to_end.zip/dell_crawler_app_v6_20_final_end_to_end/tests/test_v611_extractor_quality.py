from __future__ import annotations

from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.product_intelligence import (
    ProductRecord,
    extract_product_records,
    is_media_asset_url,
    is_product_detail_url,
    parse_product_card,
)


def test_media_url_never_becomes_product_identity() -> None:
    image = "https://i.dell.com/sites/csimages/App-Merchandizing_Images/all/laptop.png"
    rec = ProductRecord(name="Dell Pro 14 Laptop", source_url="https://www.dell.com/en-uk/shop/laptops/scr/laptops", product_url=image)
    assert is_media_asset_url(image)
    assert rec.canonical_identity().startswith("product:")
    assert not rec.canonical_identity().startswith("url:https://i.dell.com")


def test_product_card_prefers_apd_detail_url_over_image() -> None:
    source = "https://www.dell.com/en-uk/shop/accessories/scr/accessories"
    apd = "https://www.dell.com/en-uk/shop/dell-usb-c-dock/apd/470-abcd/pc-accessories"
    image = "https://i.dell.com/image/DelContent/123/product.png"
    rec = parse_product_card(
        {
            "name": "Dell USB-C Dock WD19",
            "url": image,
            "links": [{"href": image, "label": "image"}, {"href": apd, "label": "Dell USB-C Dock WD19"}],
            "text": "Dell USB-C Dock WD19\nOrder Code: 470-ABCD\nDell Price £149.99",
        },
        source,
    )
    assert rec is not None
    assert is_product_detail_url(rec.product_url)
    assert "/apd/" in rec.product_url


def test_ingest_quarantines_media_only_product(tmp_path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/laptops/scr/laptops"
    store.upsert_node(f"url:{source}", "ProductCatalog", "Laptops", {"url": source})
    image = "https://www.dell.com/image/DellContent/content/dam/product-images/laptop.png"
    store.ingest_extraction(
        source,
        {
            "entities": [
                {
                    "key": "p1",
                    "type": "Product",
                    "name": "Dell",
                    "url": image,
                    "node_key": f"url:{image}",
                    "attributes": {},
                }
            ]
        },
    )
    # v6.18: media-only pseudo-products are kept as extraction evidence and do
    # not create VisualAsset/Product graph nodes.
    node = store.node_by_key(f"url:{image}")
    assert node is None
    quality = store.semantic_quality_report()
    assert quality["visual_asset_nodes"] == 0
    assert quality["extraction_evidence_rows"] >= 1


def test_ingest_recovers_product_with_image_and_order_code(tmp_path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/laptops/scr/laptops"
    store.upsert_node(f"url:{source}", "ProductCatalog", "Laptops", {"url": source})
    image = "https://www.dell.com/image/DellContent/content/dam/product-images/pro14.png"
    store.ingest_extraction(
        source,
        {
            "entities": [
                {
                    "key": "p1",
                    "type": "Product",
                    "name": "Dell Pro 14 Laptop",
                    "url": image,
                    "node_key": f"url:{image}",
                    "attributes": {"order_code": "CNB14250", "price": "899.00"},
                }
            ]
        },
    )
    product = store.node_by_key("product-order:cnb14250")
    assert product is not None
    assert product["node_type"] == "Product"
    assert product["attributes"]["image"] == image
    assert not product["attributes"].get("product_url")


def test_product_detail_page_fallback_binds_specs_to_product() -> None:
    url = "https://www.dell.com/en-uk/shop/dell-laptops/dell-pro-14-laptop/spd/dell-pro-pb14250-laptop"
    page = CrawlPage(
        url=url,
        canonical_url=url,
        title="Dell Pro 14 Laptop | Dell UK",
        page_type="Product",
        snapshot="",
        visible_text=(
            "Dell Pro 14 Laptop\n"
            "Model: PB14250\n"
            "Order Code: CNB14250\n"
            "Dell Price £899.00\n"
            "Intel Core Ultra 7 265U processor\n"
            "32 GB DDR5 memory\n"
            "1 TB NVMe SSD storage\n"
            "14 inch display\n"
            "Windows 11 Pro"
        ),
        metadata={
            "browser_structured_dom": {
                "headings": [{"text": "Dell Pro 14 Laptop"}],
                "definitions": [
                    {"term": "Processor", "definition": "Intel Core Ultra 7 265U"},
                    {"term": "Memory", "definition": "32 GB DDR5"},
                ],
                "tables": [],
            }
        },
    )
    records = extract_product_records(page)
    assert records
    rec = max(records, key=lambda item: item.completeness_score())
    assert rec.product_url == url
    assert rec.current_price == "899"
    assert "Intel" in rec.processor
    assert "32 GB" in rec.memory
    assert rec.order_code == "CNB14250"
