from __future__ import annotations

import io
import json
import subprocess
import sys
from pathlib import Path

import httpx
from PIL import Image, ImageDraw
from pypdf import PdfWriter

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig, CrawlStats
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def pdf_bytes() -> bytes:
    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Title": "Recovered Dell PDF"})
    writer.write(buffer)
    return buffer.getvalue()


class FakeStore:
    def touch_queue(self, *args, **kwargs):
        return True


class MinimalRuntime:
    output_dir = Path(".")
    started = False


def crawler_for_transport(tmp_path: Path, handler) -> DellEnUkKnowledgeCrawler:
    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.config = CrawlConfig(start_urls=["https://www.dell.com/en-uk"], document_direct_http_enabled=True)
    crawler.stats = CrawlStats(run_id="TEST", started_at="2026-07-30T00:00:00+00:00")
    crawler.run_id = "TEST"
    crawler._stopped = False
    crawler.http = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    crawler.store = FakeStore()
    crawler.runtime = MinimalRuntime()
    crawler.output_dir = tmp_path
    crawler.document_dir = tmp_path / "documents"
    crawler.document_dir.mkdir()
    crawler.document_quarantine_dir = tmp_path / "quarantine"
    crawler.pdf_failure_log = tmp_path / "PDF_FAILURES.jsonl"
    crawler.pdf_transport_log = tmp_path / "PDF_TRANSPORT_EVENTS.jsonl"
    crawler.pdf_success_log = tmp_path / "PDF_SUCCESSES.jsonl"
    crawler.pdf_recovery_log = tmp_path / "PDF_RECOVERIES.jsonl"
    crawler._emit = lambda *args, **kwargs: None
    return crawler


def test_recovered_direct_403_is_transport_event_not_terminal_failure(tmp_path: Path) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, request=request, text="Forbidden")

    crawler = crawler_for_transport(tmp_path, handler)
    recovered = pdf_bytes()

    def browser(url: str, path: Path, parent_url: str = ""):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(recovered)
        crawler._record_pdf_recovery(url, "test_browser_recovery", bytes=len(recovered))
        return url, 200, {
            "content-type": "application/pdf",
            "content-length": str(len(recovered)),
            "x-dell-fetch-mode": "test_browser_recovery",
        }, len(recovered)

    crawler._download_resource_via_browser = browser  # type: ignore[method-assign]
    path = crawler.document_dir / "recovered.pdf"
    result = crawler._download_resource_resumable(
        "https://www.delltechnologies.com/asset/en-uk/recovered.pdf",
        path,
        {"parent_url": "https://www.dell.com/en-uk/source"},
    )

    assert result[1] == 200
    assert path.exists()
    assert crawler.stats.pdf_download_failures == 0
    assert crawler.stats.pdf_transport_events == 1
    assert crawler.stats.pdf_recoveries == 1
    assert not crawler.pdf_failure_log.exists()
    transport = [
        json.loads(line)
        for line in crawler.pdf_transport_log.read_text(encoding="utf-8").splitlines()
    ]
    assert transport[0]["http_status"] == 403
    assert transport[0]["terminal"] is False
    crawler.http.close()


class EmptyTabListingPDFRuntime:
    """Simulates an MCP build whose tab-list text cannot be parsed."""

    def __init__(self, output_dir: Path, url: str) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.started = True
        self.server_url = "http://127.0.0.1:9999/mcp"
        self.tools = {"browser_snapshot", "browser_take_screenshot"}
        self.url = url
        self.page = 1
        self.opened = False

    def start(self):
        return {"ok": True}

    def tab_inventory(self, **_: object):
        return []

    def tabs(self, action: str, **_: object):
        if action == "new":
            self.opened = True
        if action == "close":
            self.opened = False
        return {"ok": True}

    def navigate(self, url: str, **_: object):
        self.url = url
        return {"ok": True}

    def evaluate_readonly(self, expression: str, **_: object):
        if "hasEmbed" in expression:
            payload = {
                "url": self.url,
                "title": "Dell PDF Viewer",
                "readyState": "complete",
                "hasEmbed": True,
                "bodyTextChars": 10,
            }
        else:
            payload = {
                "url": self.url,
                "title": "Dell PDF Viewer",
                "texts": [f"Page {self.page} of 2. Dell AI architecture text."],
                "labels": [f"Page {self.page} of 2"],
            }
        return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}

    def snapshot(self, **_: object):
        return {
            "ok": True,
            "detail": (
                "### Snapshot\n"
                f'- document "Page {self.page} of 2"\n'
                f'- text "Dell PDF page {self.page} AI workload requirements"'
            ),
        }

    def screenshot(self, filename: str, **_: object):
        path = self.output_dir / filename
        image = Image.new("RGB", (900, 1100), "white")
        draw = ImageDraw.Draw(image)
        draw.text((80, 250), f"Dell PDF Page {self.page}", fill="black")
        image.save(path)
        return {"ok": True, "detail": f"Saved screenshot to {path}"}

    def run_application_code(self, code: str, **_: object):
        if "PageDown" in code:
            self.page = min(2, self.page + 1)
        elif "Home" in code:
            self.page = 1
        return {"ok": True, "detail": "{}"}

    def press_key(self, key: str, **_: object):
        if key == "PageDown":
            self.page = min(2, self.page + 1)
        return {"ok": True}

    def wait(self, *_: object, **__: object):
        return {"ok": True}

    def network_requests(self, **_: object):
        return {"ok": False}

    def select_tab(self, *_: object, **__: object):
        return {"ok": True}


class NoopAIA:
    vision_model = ""

    def vision_json(self, *args, **kwargs):
        return kwargs.get("fallback", {})


def test_browser_viewer_runs_even_when_tab_inventory_is_empty_and_global_vision_off(tmp_path: Path) -> None:
    url = "https://www.delltechnologies.com/asset/en-uk/browser-only.pdf"
    knowledge = tmp_path / "knowledge"
    runtime = EmptyTabListingPDFRuntime(tmp_path / "mcp", url)
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    config = CrawlConfig(
        start_urls=["https://www.dell.com/en-uk"],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        browser_pdf_viewer_extraction_enabled=True,
        browser_pdf_viewer_capture_screenshots=True,
        browser_pdf_viewer_text_enabled=True,
        browser_pdf_viewer_vision_enabled=False,
        browser_pdf_viewer_stable_rounds=1,
        browser_pdf_viewer_fallback_guard=6,
        browser_pdf_viewer_wait_seconds=0.0,
    )
    extractor = DellContentExtractor(
        aia=NoopAIA(),
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)
    crawler._capture_pdf_network_body = lambda *_args, **_kwargs: False  # type: ignore[method-assign]
    crawler._download_via_browser_api_chunks = (  # type: ignore[method-assign]
        lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("API disabled in test"))
    )

    result = crawler._download_resource_via_browser(
        url,
        knowledge / "documents" / "unused.pdf",
        parent_url="https://www.dell.com/en-uk/source",
    )

    assert result[2]["x-dell-fetch-mode"] == "playwright_pdf_viewer_text_vision"
    capture = crawler._get_browser_pdf_viewer_capture(url)
    assert capture["usable"] is True
    assert capture["screenshot_count"] >= 2
    assert capture["text_chars"] > 0
    assert runtime.opened is False
    crawler.http.close()


def test_repair_v65_archives_mixed_legacy_failure_log(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]
    knowledge = tmp_path / "knowledge"
    knowledge.mkdir()
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    url = "https://www.delltechnologies.com/asset/en-uk/retry.pdf"
    assert store.enqueue(url, resource_class="DOCUMENT")
    store.mark_queue(url, "DEFERRED", "previous failure")
    (knowledge / "PDF_FAILURES.jsonl").write_text(
        json.dumps({"stage": "direct_http", "http_status": 403}) + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            sys.executable,
            str(root / "repair_v65.py"),
            "--db",
            str(knowledge / "dell.db"),
            "--knowledge",
            str(knowledge),
            "--no-backup",
        ],
        cwd=root,
        env={**__import__("os").environ, "PYTHONPATH": str(root)},
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    report = json.loads((knowledge / "V65_REPAIR_REPORT.json").read_text(encoding="utf-8"))
    assert report["migration"] == "v6.4 -> v6.5"
    archived = Path(report["archived_legacy_pdf_failure_log"])
    assert archived.exists()
    assert not (knowledge / "PDF_FAILURES.jsonl").exists()
    assert store.queue_item(url)["status"] == "PENDING"
