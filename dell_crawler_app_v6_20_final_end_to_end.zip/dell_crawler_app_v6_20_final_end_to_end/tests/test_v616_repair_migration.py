from pathlib import Path

from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.snapshot_extract import stable_text_hash
from repair_v616 import compact_evidence_only_nodes, compact_unfetched_navigation_nodes, merge_duplicate_products


def _fetched_page(url: str) -> CrawlPage:
    text = "Fetched Dell page knowledge"
    return CrawlPage(
        url=url,
        canonical_url=url,
        title="Fetched Dell page",
        page_type="WebPage",
        snapshot="",
        visible_text=text,
        links=[],
        content_hash=stable_text_hash(text),
    )


def test_historical_graph_noise_is_compacted_without_losing_evidence(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    source = "https://www.dell.com/en-uk/shop/source"
    target = "https://www.dell.com/en-uk/shop/unfetched"
    store.ingest_page(_fetched_page(source))
    store.upsert_node(f"url:{target}", "Page", "Unfetched target", {"discovered_from": source})
    store.upsert_edge(f"url:{source}", "LINKS_TO", f"url:{target}", source_url=source)
    store.upsert_node("concept:legacy", "Concept", "Legacy attribute", {"source_url": source})
    store.add_fact("concept:legacy", "DETAIL", "preserve me", source_url=source)

    nav = compact_unfetched_navigation_nodes(store)
    evidence = compact_evidence_only_nodes(store)

    assert nav["placeholder_nodes_removed"] == 1
    assert evidence["concept_nodes_removed"] == 1
    assert store.node_by_key(f"url:{target}") is None
    assert store.node_by_key("concept:legacy") is None
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM link_evidence WHERE target_url=?", (target,)).fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM extraction_evidence").fetchone()[0] >= 2
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_historical_products_merge_only_on_strong_identity(tmp_path: Path) -> None:
    store = SQLiteKnowledgeGraph(tmp_path / "kg.db")
    store.upsert_node("legacy:p1", "Product", "Dell Pro 14", {
        "order_code": "SAME123", "model": "Dell Pro 14", "price": "999",
        "product_url": "https://www.dell.com/en-uk/shop/x/spd/dell-pro-14/a",
    })
    store.upsert_node("legacy:p2", "Product", "Dell Pro 14", {
        "order_code": "SAME123", "model": "Dell Pro 14", "memory": "32 GB",
        "product_url": "https://www.dell.com/en-uk/shop/x/spd/dell-pro-14/b",
    })
    # Same model but a different strong order code must remain a separate configuration.
    store.upsert_node("legacy:p3", "Product", "Dell Pro 14", {
        "order_code": "OTHER456", "model": "Dell Pro 14", "memory": "64 GB",
        "product_url": "https://www.dell.com/en-uk/shop/x/spd/dell-pro-14/c",
    })

    result = merge_duplicate_products(store)
    assert result["product_nodes_merged"] == 1
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type='Product'").fetchone()[0] == 2
        rows = conn.execute("SELECT attributes_json FROM nodes WHERE node_type='Product'").fetchall()
    import json
    attrs = [json.loads(row[0]) for row in rows]
    merged = next(item for item in attrs if item.get("order_code") == "SAME123")
    assert merged.get("price") == "999"
    assert merged.get("memory") == "32 GB"
