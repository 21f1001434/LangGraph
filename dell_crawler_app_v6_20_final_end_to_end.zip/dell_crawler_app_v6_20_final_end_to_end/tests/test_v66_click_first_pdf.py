from __future__ import annotations

import io
import json
from pathlib import Path

import httpx
from PIL import Image, ImageDraw
from pypdf import PdfWriter

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlConfig, CrawlStats
from dell_crawler_core.dell_crawler import DellEnUkKnowledgeCrawler
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


PARENT = "https://www.dell.com/en-uk/lp/dt/ai-technologies"
PDF = "https://www.delltechnologies.com/asset/en-uk/solutions/test/document.pdf"


def _pdf_bytes() -> bytes:
    buffer = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.write(buffer)
    return buffer.getvalue()


class NoopAIA:
    vision_model = ""

    def vision_json(self, *args, **kwargs):
        return kwargs.get("fallback", {})


class ParentClickViewerRuntime:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.started = True
        self.server_url = "http://127.0.0.1:9999/mcp"
        self.tools = {"browser_snapshot", "browser_take_screenshot"}
        self.current_tab = 0
        self.pdf_open = False
        self.url = PARENT
        self.page = 1
        self.click_targets: list[str] = []

    def start(self):
        return {"ok": True}

    def tabs(self, action: str, url: str = "", **_: object):
        if action == "new":
            self.current_tab = 2
            self.url = url or PARENT
            return {"ok": True}
        if action == "close":
            self.pdf_open = False
            self.current_tab = 0
            self.url = PARENT
            return {"ok": True}
        return {"ok": True}

    def tab_inventory(self, **_: object):
        tabs = [{"index": 0, "url": PARENT, "current": self.current_tab == 0}]
        if self.pdf_open:
            tabs.append({"index": 1, "url": PDF, "current": self.current_tab == 1})
        return tabs

    def select_tab(self, index: int, **_: object):
        self.current_tab = index
        self.url = PDF if index == 1 else PARENT
        return {"ok": True}

    def close_tab(self, index: int, **_: object):
        if index == 1:
            self.pdf_open = False
            self.current_tab = 0
            self.url = PARENT
        return {"ok": True}

    def navigate(self, url: str, **_: object):
        self.url = url
        self.current_tab = 0
        return {"ok": True}

    def click(self, target: str, element: str, **_: object):
        self.click_targets.append(target)
        self.pdf_open = True
        self.current_tab = 1
        self.url = PDF
        self.page = 1
        return {"ok": True}

    def snapshot(self, **_: object):
        if self.current_tab == 0:
            return {
                "ok": True,
                "detail": (
                    '### Snapshot\n'
                    '- link "Read White Paper" [ref=e42]\n'
                    f'  - /url: {PDF}\n'
                ),
            }
        return {
            "ok": True,
            "detail": (
                "### Snapshot\n"
                f'- document "Page {self.page} of 2" [ref=e1]\n'
                f'- text "Dell PDF page {self.page}: AI architecture and requirements" [ref=e2]'
            ),
        }

    def evaluate_readonly(self, expression: str, **_: object):
        if "hasEmbed" in expression:
            payload = {
                "url": self.url,
                "title": "Dell PDF Viewer" if self.current_tab == 1 else "Dell source",
                "readyState": "complete",
                "hasEmbed": self.current_tab == 1,
                "bodyTextChars": 100,
            }
        else:
            payload = {
                "url": self.url,
                "title": "Dell PDF Viewer",
                "texts": [f"Page {self.page} of 2. AI workstation content."],
                "labels": [f"Page {self.page} of 2"],
            }
        return {"ok": True, "detail": "### Result\n" + json.dumps(json.dumps(payload))}

    def screenshot(self, filename: str, **_: object):
        path = self.output_dir / filename
        image = Image.new("RGB", (900, 1100), "white")
        draw = ImageDraw.Draw(image)
        draw.text((60, 200), f"Dell PDF Page {self.page}", fill="black")
        image.save(path)
        return {"ok": True, "detail": f"Saved screenshot to {path}"}

    def press_key(self, key: str, **_: object):
        if key in {"Home", "Control+Home"}:
            self.page = 1
        elif key == "PageDown":
            self.page = min(2, self.page + 1)
        return {"ok": True}

    def run_application_code(self, code: str, **_: object):
        if "PageDown" in code:
            self.page = min(2, self.page + 1)
        elif "Home" in code:
            self.page = 1
        return {"ok": True, "detail": "{}"}

    def wait(self, *_: object, **__: object):
        return {"ok": True}

    def network_requests(self, **_: object):
        return {"ok": False, "detail": "none"}


def _make_crawler(tmp_path: Path, runtime: ParentClickViewerRuntime):
    knowledge = tmp_path / "knowledge"
    store = SQLiteKnowledgeGraph(knowledge / "dell.db")
    store.upsert_source(
        PARENT,
        PARENT,
        "Dell AI technologies",
        "AISolutionPage",
        "hash",
        metadata={
            "browser_structured_dom": {
                "controls": [
                    {
                        "tag": "a",
                        "label": "Read White Paper",
                        "attrs": {"href": PDF},
                    }
                ]
            }
        },
    )
    config = CrawlConfig(
        start_urls=[PARENT],
        use_llm_extraction=False,
        use_vision_extraction=False,
        vision_mode="off",
        browser_pdf_viewer_extraction_enabled=True,
        browser_pdf_viewer_capture_screenshots=True,
        browser_pdf_viewer_text_enabled=True,
        browser_pdf_viewer_vision_enabled=False,
        browser_pdf_viewer_stable_rounds=1,
        browser_pdf_viewer_fallback_guard=6,
        browser_pdf_viewer_wait_seconds=0.0,
        document_click_first_enabled=True,
        document_click_use_direct_http_fallback=False,
        document_click_replay_timeout_seconds=5.0,
    )
    extractor = DellContentExtractor(
        aia=NoopAIA(),
        use_llm=False,
        use_vision=False,
        vision_cache_dir=knowledge / "vision_cache",
        text_cache_dir=knowledge / "text_cache",
    )
    crawler = DellEnUkKnowledgeCrawler(runtime, store, extractor, config, output_dir=knowledge)
    return crawler, store


def test_descriptor_resolves_real_parent_button(tmp_path: Path) -> None:
    runtime = ParentClickViewerRuntime(tmp_path / "mcp")
    crawler, _store = _make_crawler(tmp_path, runtime)
    descriptor = crawler._document_click_descriptor(
        {"url": PDF, "parent_url": PARENT, "relation": "HAS_ENDPOINT"}
    )
    assert descriptor["label"] == "Read White Paper"
    assert descriptor["href"] == PDF
    assert "browser_structured_dom" in descriptor["source"]
    crawler.http.close()


def test_click_linked_pdf_skips_direct_http_entirely(tmp_path: Path) -> None:
    runtime = ParentClickViewerRuntime(tmp_path / "mcp")
    crawler, _store = _make_crawler(tmp_path, runtime)
    called = {"http": 0}

    def forbidden_http(request: httpx.Request) -> httpx.Response:
        called["http"] += 1
        raise AssertionError("direct HTTP must not run for a source-button PDF")

    crawler.http.close()
    crawler.http = httpx.Client(transport=httpx.MockTransport(forbidden_http))
    path = crawler.document_dir / "test.pdf"
    result = crawler._download_resource_resumable(
        PDF,
        path,
        {"url": PDF, "_queue_url": PDF, "parent_url": PARENT, "relation": "HAS_ENDPOINT"},
    )

    assert called["http"] == 0
    assert result[2]["x-dell-fetch-mode"] == "playwright_source_control_viewer_text_vision"
    assert crawler.stats.pdf_browser_click_replays == 1
    assert crawler.stats.pdf_direct_http_skipped_for_click == 1
    assert crawler.stats.pdf_browser_click_viewer_captures == 1
    assert runtime.click_targets == ["e42"]
    assert not crawler.pdf_transport_log.exists()
    crawler.http.close()


def test_control_relation_uses_click_even_without_historical_metadata(tmp_path: Path) -> None:
    crawler = object.__new__(DellEnUkKnowledgeCrawler)
    crawler.store = type("Store", (), {"get_source_metadata": lambda self, url: {}})()
    item = {"url": PDF, "parent_url": PARENT, "relation": "CONTROL_HAS_DIRECT_ENDPOINT"}
    descriptor = crawler._document_click_descriptor(item)
    assert descriptor["request_url"] == PDF
    assert descriptor["source"] == "queue_relation"
