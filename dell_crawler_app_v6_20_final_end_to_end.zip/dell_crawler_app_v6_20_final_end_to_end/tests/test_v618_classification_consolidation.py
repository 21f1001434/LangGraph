from __future__ import annotations

from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.crawl_models import CrawlPage
from repair_v618 import repair


def _page(store: SQLiteKnowledgeGraph, url: str) -> None:
    store.ingest_page(CrawlPage(url=url, canonical_url=url, title="Dell page", page_type="WebPage", snapshot="", visible_text="Dell", content_hash="h" + str(abs(hash(url)))))


def test_generic_product_is_classified_and_persisted_as_product(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    source = "https://www.dell.com/en-us/shop/dell-pro/spd/dell-pro-pb14250-laptop"
    _page(store, source)
    store.ingest_extraction(source, {
        "entities": [{
            "key": "x",
            "type": "Entity",
            "name": "Dell Pro 14 Premium",
            "attributes": {"order_code": "BTO123", "processor": "Intel Core Ultra 7"},
        }]
    })
    with store.connect() as conn:
        row = conn.execute("SELECT node_type,attributes_json FROM nodes WHERE node_type='Product'").fetchone()
    assert row is not None
    assert row["node_type"] == "Product"
    quality = store.semantic_quality_report()
    assert quality["unclassified_semantic_nodes"] == 0


def test_brand_aliases_converge_to_one_semantic_node(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    a = "https://www.dell.com/en-us/a"
    b = "https://www.dell.com/en-us/b"
    _page(store, a)
    _page(store, b)
    store.ingest_extraction(a, {"entities": [{"key": "brand1", "type": "Brand", "name": "Dell Technologies, Inc."}]})
    store.ingest_extraction(b, {"entities": [{"key": "brand2", "type": "Manufacturer", "name": "Dell Technologies"}]})
    with store.connect() as conn:
        rows = conn.execute("SELECT node_key,node_type,name FROM nodes WHERE node_type='Brand'").fetchall()
    assert len(rows) == 1
    assert rows[0]["node_key"] == "brand:dell-technologies"
    assert store.semantic_quality_report()["duplicate_semantic_identity_pairs"] == 0


def test_schema_fragment_remains_evidence_not_node(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    source = "https://www.dell.com/en-us/test"
    _page(store, source)
    store.ingest_extraction(source, {
        "entities": [{"key": "battery", "type": "Battery", "name": "6 Cell", "attributes": {"value": "86 Wh"}}]
    })
    with store.connect() as conn:
        count = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type IN ('Concept','Battery','Entity','Unknown','VisualAsset')").fetchone()[0]
        evidence = conn.execute("SELECT COUNT(*) FROM extraction_evidence").fetchone()[0]
    assert count == 0
    assert evidence >= 1


def test_repair_v618_classifies_and_merges_historical_scattered_nodes(tmp_path: Path) -> None:
    db = tmp_path / "knowledge" / "kg.db"
    db.parent.mkdir(parents=True)
    store = SQLiteKnowledgeGraph(db)
    source = "https://www.dell.com/en-us/home"
    _page(store, source)
    # Simulate historical scattered duplicates with model-generated keys.
    store.upsert_node("legacy:brand:1", "Brand", "Dell Technologies, Inc.", {"source_url": source})
    store.upsert_node("legacy:brand:2", "Manufacturer", "Dell Technologies", {"source_url": source})
    store.upsert_node("legacy:noise", "Attribute", "Battery", {"source_url": source, "value": "6 cell"})

    result = repair(db, db.parent, force_active=True, no_backup=True)
    assert result["integrity_after"].casefold() == "ok"
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        brands = conn.execute("SELECT node_key,node_type FROM nodes WHERE node_type='Brand'").fetchall()
        noise = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type NOT IN ('Page','Product','ProductFamily','Category','Brand','Offer','Review','Document','SupportArticle','FAQ','Requirement','Compatibility','UseCase','Workload','Solution','Service','Software','Organization','Market','AccountTopic')").fetchone()[0]
        aliases = conn.execute("SELECT COUNT(*) FROM semantic_entity_aliases").fetchone()[0]
    assert len(brands) == 1
    assert brands[0]["node_key"] == "brand:dell-technologies"
    assert noise == 0
    assert aliases >= 1
    quality = store.semantic_quality_report()
    assert quality["node_classification_coverage"] == 1.0
    assert quality["duplicate_semantic_identity_pairs"] == 0
    assert quality["clean_for_semantic_sync"] is True
