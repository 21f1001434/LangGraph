from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import psutil
import streamlit as st
from dotenv import load_dotenv

from dell_crawler_core.market_context import market_for_locale, normalize_locale
from dell_crawler_core.env_config import apply_compatibility_aliases
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.mcp_runtime import PlaywrightMCPRuntime
from dell_crawler_core.ui_safe import arrow_safe_records
from dell_crawler_core.snapshot_extract import seed_urls_for_scope

ROOT = Path(__file__).resolve().parent
RUNTIME_DIR = ROOT / "runtime"
KNOWLEDGE_DIR = ROOT / "knowledge"
REPORTS_DIR = ROOT / "reports"
CONFIG_FILE = RUNTIME_DIR / "crawl_config.json"
STATUS_FILE = RUNTIME_DIR / "status.json"
EVENTS_FILE = RUNTIME_DIR / "events.jsonl"
COMMAND_FILE = RUNTIME_DIR / "command.json"
PID_FILE = RUNTIME_DIR / "crawler.pid"
WORKER_LOG = RUNTIME_DIR / "worker.log"
DEFAULT_DB = KNOWLEDGE_DIR / "dell_en_uk.db"

for directory in (RUNTIME_DIR, KNOWLEDGE_DIR, REPORTS_DIR):
    directory.mkdir(parents=True, exist_ok=True)

load_dotenv(ROOT / ".env")
RUNTIME_CONFIG = apply_compatibility_aliases()

st.set_page_config(
    page_title="Dell.com Autonomous Knowledge Crawler v6.19",
    page_icon="🕷️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {max-width: 1550px; padding-top: 1.1rem; padding-bottom: 3rem;}
    .hero {padding:1.1rem 1.3rem; border:1px solid rgba(100,100,100,.20); border-radius:18px;
           background:linear-gradient(135deg,rgba(0,112,190,.14),rgba(85,70,170,.07)); margin-bottom:1rem;}
    .hero h1 {margin:0; font-size:2rem;} .hero p {margin:.35rem 0 0; opacity:.84;}
    div[data-testid="stMetric"] {border:1px solid rgba(120,120,120,.18); padding:.65rem; border-radius:14px;}
    div.stButton > button {border-radius:11px; min-height:2.6rem; font-weight:650;}
    .small-muted {opacity:.72; font-size:.9rem;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
      <h1>🕷️ Dell.com Autonomous Knowledge Crawler v6.19</h1>
      <p>A validated Dell knowledge-acquisition crawler with compact semantic mapping, anti-repeat extraction, full masthead/SSO coverage, product completion, document/vision understanding and resumable provenance.</p>
    </div>
    """,
    unsafe_allow_html=True,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def env_flag(name: str, default: bool) -> bool:
    raw = str(os.getenv(name, "")).strip().lower()
    if raw in {"1", "true", "yes", "y", "on", "enabled"}:
        return True
    if raw in {"0", "false", "no", "n", "off", "disabled"}:
        return False
    return default


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    temp.replace(path)


def get_pid() -> int | None:
    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
        return pid if pid > 0 else None
    except Exception:
        return None


def process_running() -> tuple[bool, int | None]:
    pid = get_pid()
    if not pid or not psutil.pid_exists(pid):
        return False, pid
    try:
        process = psutil.Process(pid)
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE, pid
    except (psutil.Error, OSError):
        return False, pid


def start_worker(config: dict[str, Any]) -> tuple[bool, str]:
    running, pid = process_running()
    if running:
        return False, f"Crawler supervisor is already running with PID {pid}."
    write_json_atomic(CONFIG_FILE, config)
    write_json_atomic(COMMAND_FILE, {"command": "run", "updated_at": now_iso()})
    log_handle = WORKER_LOG.open("a", encoding="utf-8")
    command = [sys.executable, str(ROOT / "crawler_supervisor.py"), "--config", str(CONFIG_FILE)]
    kwargs: dict[str, Any] = {
        "cwd": str(ROOT),
        "stdout": log_handle,
        "stderr": subprocess.STDOUT,
        "stdin": subprocess.DEVNULL,
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        kwargs["start_new_session"] = True
    try:
        process = subprocess.Popen(command, **kwargs)
        PID_FILE.write_text(str(process.pid), encoding="utf-8")
        return True, f"Crawler supervisor started with PID {process.pid}; it will restart failed or stalled workers until the public frontier is clean."
    except Exception as exc:
        return False, f"Could not start crawler supervisor: {type(exc).__name__}: {exc}"
    finally:
        log_handle.close()


def request_stop() -> None:
    write_json_atomic(COMMAND_FILE, {"command": "stop", "updated_at": now_iso()})


def force_stop() -> tuple[bool, str]:
    running, pid = process_running()
    if not running or not pid:
        PID_FILE.unlink(missing_ok=True)
        return True, "No crawler process is running."
    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for process in children:
            process.terminate()
        parent.terminate()
        _, alive = psutil.wait_procs([parent, *children], timeout=8)
        for process in alive:
            process.kill()
        PID_FILE.unlink(missing_ok=True)
        return True, "Crawler supervisor, worker and child MCP processes were stopped. Queue, partial PDFs and graph state remain resumable."
    except Exception as exc:
        return False, f"Force stop failed: {type(exc).__name__}: {exc}"


def tail_text(path: Path, lines: int = 120) -> str:
    if not path.exists():
        return ""
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            data = handle.readlines()
        return "".join(data[-lines:])
    except Exception:
        return ""


def human_status(status: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    event = str(status.get("event") or "Not started")
    stats = status.get("stats") or {}
    if event == "worker_finished" and isinstance(status.get("result"), dict):
        stats = status["result"].get("stats") or stats
    return event, stats if isinstance(stats, dict) else {}


with st.sidebar:
    st.header("Crawler runtime")
    db_value = st.text_input("SQLite knowledge database", str(DEFAULT_DB.relative_to(ROOT)))
    browser_mode = st.selectbox("Browser mode", ["persistent", "extension"], index=0)
    browser_choices = ["chrome", "msedge"] if browser_mode == "extension" else ["chrome", "msedge", "firefox", "webkit"]
    browser = st.selectbox("Browser", browser_choices, index=0)
    headless = st.checkbox("Headless browser", value=False, disabled=browser_mode == "extension")
    user_data_dir = st.text_input("Persistent browser profile", "browser_profile/dell_crawler")
    browser_executable_path = st.text_input(
        "Browser executable path (optional)",
        os.getenv("PLAYWRIGHT_MCP_EXECUTABLE_PATH", ""),
        help="Leave blank for automatic Chrome/Edge detection. Set the full chrome.exe or msedge.exe path only when channel detection fails.",
    )
    mcp_version = st.text_input("Playwright MCP package version", os.getenv("PLAYWRIGHT_MCP_VERSION", "0.0.78"))

    st.divider()
    st.subheader("Dell AIA")
    st.json(RUNTIME_CONFIG.public_summary())
    st.caption("Secrets are read only from your local .env and are never displayed by this application.")

    if st.button("Run environment preflight", width="stretch"):
        with st.spinner("Checking Node, npx, Python MCP and HTTP dependencies..."):
            st.json(PlaywrightMCPRuntime.environment_preflight())
    st.caption("If MCP reports that chrome-for-testing is missing, run install_mcp_browser.ps1 once, then resume.")

control_tab, activity_tab, data_tab, export_tab = st.tabs(
    ["▶ Crawl control", "📡 Live activity", "🗃 Extracted data", "📦 Export"]
)

with control_tab:
    left, right = st.columns([1.12, 1])
    with left:
        st.subheader("Coverage")
        scope = st.selectbox(
            "Discovery scope",
            ["full_dell_locale_discovery", "full_en_uk_discovery", "public_catalog", "ai_workstation_bootstrap"],
            index=0,
        )
        locale = normalize_locale(st.text_input(
            "Dell locale",
            value=os.getenv("DELL_LOCALE", "en-uk"),
            help="Examples: en-uk, en-us, en-in, en-ca. v6.19 derives market/currency and live navigation from the configured locale.",
        ))
        default_market = market_for_locale(locale)
        market = st.text_input("Market label", value=os.getenv("DELL_MARKET", default_market))
        unlimited = st.toggle("Unlimited pages, link depth and safe controls", value=True)
        if unlimited:
            max_pages, max_depth, max_interactions = 0, -1, -1
            st.success("The supervised crawler keeps recovering and resuming until the canonical queue, repeatable controls and document frontier are exhausted.")
        else:
            max_pages = int(st.number_input("Page limit", min_value=1, max_value=1_000_000, value=100, step=10))
            max_depth = int(st.number_input("Link-depth limit", min_value=0, max_value=1000, value=4, step=1))
            max_interactions = int(st.number_input("Safe-control limit per page", min_value=0, max_value=10000, value=30, step=1))

        delay_seconds = float(st.number_input("Delay between URLs (seconds)", 0.0, 60.0, 1.5, 0.5))
        respect_robots = st.toggle("Respect robots.txt", value=True)
        include_ecosystem = st.toggle("Follow official linked Dell resource sites", value=True)
        include_community = st.toggle("Include public Dell Community feedback", value=True)

        st.subheader("Deep extraction")
        exhaust_repeatable = st.toggle("Exhaust Show More / Load More / review pagination", value=True)
        extract_reviews = st.toggle("Store every loaded product review", value=True)
        embedded_docs = st.toggle("Discover brochures, eBooks and PDFs hidden in buttons/embeds", value=True)
        download_pdfs = st.toggle("Download and read complete PDFs", value=True)
        enrich_html = st.toggle("Extract JSON-LD, product schema, FAQs, tables and application JSON", value=True)
        browser_structured_dom = st.toggle("Read the final rendered DOM through Playwright MCP", value=True)
        network_inventory = st.toggle("Record public page network endpoint inventory", value=True)
        extract_videos = st.toggle("Extract public video and transcript endpoints", value=True)
        include_support = st.toggle("Include Dell support, manuals, drivers and knowledge articles", value=True)
        include_blog = st.toggle("Include Dell blog and editorial evidence for this locale", value=True)

        st.subheader("Complete Dell masthead / tab coverage")
        include_masthead_taxonomy = st.toggle(
            "Discover and crawl every safe top navigation tab and nested flyout",
            value=env_flag("DELL_CRAWL_MASTHEAD_TAXONOMY", True),
            help="Expands Artificial Intelligence, IT Infrastructure, Computers & Accessories, Services, Support, Deals, Financing, nested menu parents, and the signed-in Account/Profile menu. Canonical URL/content dedupe prevents these global links from causing repeated extraction.",
        )
        masthead_depth = int(st.number_input("Maximum masthead submenu depth", 1, 8, 4, 1, disabled=not include_masthead_taxonomy))
        masthead_actions = int(st.number_input("Masthead discovery action safety budget", 20, 1000, 250, 10, disabled=not include_masthead_taxonomy))

        st.subheader("Authenticated Dell / My Account knowledge")
        include_authenticated_account = st.toggle(
            "Reuse Dell SSO and crawl read-only My Account knowledge",
            value=env_flag("DELL_CRAWL_AUTH_ACCOUNT", True),
            help="Uses the persistent browser profile. It types only the configured email, clicks Dell Login/Continue, clicks the SSO-enabled Login/Continue handoff again, then reuses the authenticated session. Passwords, OTPs, payment and account mutations are never automated.",
        )
        login_email = st.text_input(
            "Dell login email",
            value=os.getenv("DELL_LOGIN_EMAIL") or os.getenv("DELL_DEMO_EMAIL") or "adheesh.srivastava@dellteam.com",
            disabled=not include_authenticated_account,
        )
        profile_name = st.text_input(
            "Dell masthead profile name (optional)",
            value=os.getenv("DELL_PROFILE_NAME", "Adheesh"),
            disabled=not include_authenticated_account,
        )
        auth_wait_seconds = float(st.number_input(
            "SSO wait window (seconds)", 10, 600, int(os.getenv("DELL_AUTH_WAIT_SECONDS", "90")), 10,
            disabled=not include_authenticated_account,
        ))

        st.subheader("Repeat extraction protection")
        exact_content_dedupe = st.toggle(
            "Skip Dell AIA/vision when exact rendered content was already extracted",
            value=True,
            help="The alias/source and newly discovered links are still stored. Only duplicate expensive extraction is skipped.",
        )
        deep_scan = st.toggle("Scroll lazy content until semantic convergence", value=True)
        completeness = st.toggle("Judge page-type extraction completeness", value=True)

    with right:
        st.subheader("LLM and vision")
        use_llm = st.toggle("Use Dell AIA text model", value=True)
        vision_mode = st.selectbox("Vision mode", ["auto", "all", "off"], index=0)
        vision_full_page = st.toggle("Analyse full-page screenshots", value=True, disabled=vision_mode == "off")
        vision_interactions = st.toggle("Analyse newly expanded panels and review states", value=True, disabled=vision_mode == "off")
        vision_pdf_pages = st.toggle("Render and understand every visual PDF page", value=True, disabled=vision_mode == "off" or not download_pdfs)
        browser_pdf_viewer_extraction = st.toggle(
            "When a PDF opens in the browser, extract viewer text + page screenshots",
            value=True,
            disabled=not download_pdfs,
            help="Final fallback for PDFs that render in Chrome/Edge but reject binary downloads. The crawler walks the PDF viewer, captures accessibility/DOM text, screenshots each new viewport and sends those images to Dell AIA Vision.",
        )
        download_visual_assets = st.toggle("Download meaningful product/diagram images", value=True, disabled=vision_mode == "off")

        st.subheader("v6.19 validated knowledge mapping, full coverage, and anti-repeat extraction")
        lane_scheduler = st.toggle("Use fast PAGE / DOCUMENT / DATA / ASSET frontier lanes", value=True)
        dedupe_asset_variants = st.toggle("Deduplicate resized i.dell.com image variants", value=True)
        llm_text_cache = st.toggle("Cache Dell AIA text extraction across resumes", value=True, disabled=not use_llm)
        stable_control_memory = st.toggle("Persist completed one-shot controls across worker restarts", value=True)
        extract_product_cards = st.toggle("Extract coherent product cards and configurations", value=env_flag("DELL_CRAWL_EXTRACT_PRODUCT_CARDS", True))
        product_detail_completion = st.toggle("Require product detail completeness before DONE", value=env_flag("DELL_CRAWL_PRODUCT_DETAIL_COMPLETION", True))
        product_require_price = st.toggle("Require price on commerce product pages", value=env_flag("DELL_CRAWL_PRODUCT_REQUIRE_PRICE", True))
        product_min_completeness = float(st.slider("Minimum product completeness", 0.50, 1.00, float(os.getenv("DELL_CRAWL_PRODUCT_MIN_COMPLETENESS", "0.85")), 0.05))
        product_revisit = st.toggle(
            "Automatically revisit products missing price/specifications or unresolved mapped evidence",
            value=env_flag("DELL_CRAWL_PRODUCT_REVISIT", True),
            help="When the normal frontier drains, the worker reopens incomplete Dell product-detail pages in the same run. Products without a resolved PDP URL revisit their source catalogue first.",
        )
        product_revisit_attempts = int(st.number_input("Maximum enrichment revisits per product", 1, 12, 4, 1, disabled=not product_revisit))
        product_revisit_no_gain = int(st.number_input("Stop after no-improvement revisits", 1, 6, 2, 1, disabled=not product_revisit))

        st.subheader("AgentQ-inspired action intelligence")
        agentq_action_model = st.toggle("Enable web representation + actor/critic action model", value=True)
        agentq_memory = st.toggle("Learn successful control trajectories across pages and runs", value=True, disabled=not agentq_action_model)
        agentq_mcts = st.toggle("Use MCTS-inspired exploration/exploitation score", value=True, disabled=not agentq_action_model)
        agentq_llm_critic = st.toggle("Use Dell AIA critic only for ambiguous action choices", value=True, disabled=not agentq_action_model or not use_llm)
        dom_mutation_observer = st.toggle("Use DOM mutation observer for React settle detection", value=True)

        st.subheader("ReAct self-healing")
        react_enabled = st.toggle("Enable ReAct recovery", value=True)
        self_heal = st.toggle("Enable browser and control self-healing", value=True)
        react_llm = st.toggle("Use Dell AIA to choose from approved recovery actions", value=True, disabled=not react_enabled)
        max_page_retries = int(st.number_input("Retries per URL", 1, 50, 6, 1))
        max_control_retries = int(st.number_input("Retries per control", 1, 20, 4, 1))
        max_mcp_restarts = int(st.number_input("MCP restarts per page cycle", 0, 20, 3, 1))
        http_fallback = st.toggle("Use public HTTP fallback after browser recovery", value=True)
        continuous_until_clean = st.toggle(
            "Keep supervising until the public frontier is clean",
            value=True,
            help="Automatically restarts crashed or stalled workers and resumes the durable queue. Zero restart limit means no fixed restart ceiling.",
        )
        supervisor_stale_seconds = int(st.number_input(
            "Restart worker when heartbeat is stale (seconds)",
            min_value=120,
            max_value=3600,
            value=420,
            step=30,
        ))

        st.subheader("Seeds")
        st.code("\n".join(seed_urls_for_scope(scope, locale=locale)), language="text")
        custom_seeds = st.text_area(
            "Additional seed URLs, one per line",
            placeholder=f"https://www.dell.com/{locale}/...",
            height=110,
        )

    with st.expander("Live Dell full-tab extraction profile", expanded=False):
        st.markdown(
            """
            The full profile starts from the configured Dell locale home, live masthead/flyout discovery and sitemap discovery, then covers product and category pages,
            Artificial Intelligence, IT Infrastructure, Computers & Accessories, Services, Support, Deals, Financing, AI solutions, workstations, servers, storage, networking, cyber resilience, Rewards,
            manuals, drivers, knowledge articles, blogs, customer stories, FAQs, resource carousels and public documents.
            Dynamic controls are re-located after every click and repeated until semantic convergence. v6.14 first expands every safe global Dell masthead tab and nested flyout so JS-only navigation cannot be missed, writes MASTHEAD_TAXONOMY_REPORT.json, then runs the existing click-first PDF recovery, authenticated read-only My Account crawling and autonomous product-completion sweeps. Canonical frontier + exact-content dedupe prevents global menu links from causing repeated extraction. Incomplete products are revisited only when price/specification/mapping evidence can still improve or until the bounded no-gain budget is exhausted.
            """
        )
        st.code("Ratings & Reviews · Show More Reviews · Tech Specs · Features and Design · Special Offers · Expand All · Read eBook · Read Brochure · Customer Stories · Previous/Next Slide", language="text")

    db_path = Path(db_value)
    if not db_path.is_absolute():
        db_path = ROOT / db_path

    config = {
        "scope": scope,
        "locale": locale,
        "market": market.strip() or market_for_locale(locale),
        "start_urls": [line.strip() for line in custom_seeds.splitlines() if line.strip()],
        "db_path": str(db_path),
        "output_dir": str(KNOWLEDGE_DIR),
        "browser_mode": browser_mode,
        "browser": browser,
        "headless": False if browser_mode == "extension" else headless,
        "user_data_dir": user_data_dir,
        "browser_executable_path": browser_executable_path,
        "playwright_mcp_version": mcp_version,
        "max_pages": max_pages,
        "max_depth": max_depth,
        "max_interactions_per_page": max_interactions,
        "delay_seconds": delay_seconds,
        "respect_robots": respect_robots,
        "include_linked_dell_ecosystem": include_ecosystem,
        "include_community_feedback": include_community,
        "exhaust_repeatable_controls": exhaust_repeatable,
        "extract_all_reviews": extract_reviews,
        "enrich_html_structure": enrich_html,
        "capture_browser_structured_dom": browser_structured_dom,
        "capture_network_inventory": network_inventory,
        "extract_video_metadata": extract_videos,
        "discover_robots_sitemaps": True,
        "recursive_shadow_dom": True,
        "capture_same_origin_iframes": True,
        "scroll_sweep_enabled": True,
        "process_public_api_gets": True,
        "process_office_documents": True,
        "process_transcripts": True,
        "record_binary_asset_metadata": True,
        "coverage_contract_enabled": True,
        "minimum_page_coverage": 0.72,
        "include_support_content": include_support,
        "include_blog_content": include_blog,
        "include_masthead_taxonomy_discovery": include_masthead_taxonomy,
        "require_masthead_taxonomy_coverage": False,
        "masthead_max_submenu_depth": masthead_depth,
        "masthead_max_actions": masthead_actions,
        "include_authenticated_account_knowledge": include_authenticated_account,
        "require_authenticated_account_knowledge": False,
        "login_email": login_email.strip(),
        "profile_name": profile_name.strip(),
        "auth_wait_seconds": auth_wait_seconds,
        "exact_content_dedupe_enabled": exact_content_dedupe,
        "duplicate_content_min_chars": 400,
        "resume_requeue_done_incomplete": False,
        "resume_requeue_http_fallback": False,
        "discover_embedded_documents": embedded_docs,
        "download_pdfs": download_pdfs,
        "max_pdf_mb": 0,
        "deep_scan": deep_scan,
        "deep_scan_stable_rounds": 2,
        "max_deep_scan_rounds": 0,
        "deep_scan_fallback_round_guard": 80,
        "completeness_judge": completeness,
        "use_llm": use_llm,
        "vision_mode": vision_mode,
        "vision_full_page": vision_full_page,
        "vision_interactions": vision_interactions,
        "vision_pdf_pages": vision_pdf_pages,
        "vision_pdf_every_page": vision_mode != "off",
        "document_download_resume": True,
        "document_browser_fallback_on_403": True,
        "document_browser_chunk_bytes": 262144,
        "document_browser_single_response_max_bytes": 8388608,
        "document_browser_api_request_enabled": True,
        "document_browser_navigation_probe_enabled": True,
        "document_network_body_capture_enabled": True,
        "document_direct_http_enabled": env_flag("DELL_CRAWL_DOCUMENT_DIRECT_HTTP", False),
        "document_dom_href_first_enabled": True,
        "document_browser_context_request_first": env_flag("DELL_CRAWL_DOCUMENT_BROWSER_CONTEXT_REQUEST_FIRST", False),
        "document_browser_context_request_fallback": env_flag("DELL_CRAWL_DOCUMENT_BROWSER_CONTEXT_REQUEST_FALLBACK", True),
        "document_ui_click_fallback_enabled": True,
        "document_unique_target_marker_enabled": True,
        "document_capture_all_href_candidates": True,
        "document_require_canonical_match": env_flag("DELL_CRAWL_DOCUMENT_REQUIRE_CANONICAL_MATCH", False),
        "document_canonical_match_mode": os.getenv("DELL_CRAWL_DOCUMENT_CANONICAL_MATCH_MODE", "warn"),
        "document_click_timeout_seconds": float(os.getenv("DELL_CRAWL_DOCUMENT_CLICK_TIMEOUT_SECONDS", "30.0")),
        "document_profile_lock_backoff_seconds": 15.0,
        "document_profile_lock_max_wait_seconds": 180.0,
        "document_click_first_enabled": env_flag("DELL_CRAWL_DOCUMENT_CLICK_FIRST", True),
        "document_click_replay_timeout_seconds": float(os.getenv("DELL_CRAWL_DOCUMENT_CLICK_TIMEOUT_SECONDS", "18.0")),
        "document_click_use_direct_http_fallback": env_flag(
            "DELL_CRAWL_DOCUMENT_CLICK_DIRECT_HTTP_FALLBACK", False
        ),
        "document_recovery_first": True,
        "document_recovery_success_target": 3,
        "document_max_attempts": 2,
        "document_invalid_quarantine": True,
        "browser_pdf_viewer_extraction_enabled": browser_pdf_viewer_extraction,
        "browser_pdf_viewer_text_enabled": True,
        "browser_pdf_viewer_capture_screenshots": True,
        "browser_pdf_viewer_vision_enabled": vision_mode != "off",
        "browser_pdf_viewer_stable_rounds": 2,
        "browser_pdf_viewer_max_viewports": 0,
        "browser_pdf_viewer_fallback_guard": 1200,
        "browser_pdf_viewer_wait_seconds": 0.8,
        "download_visual_assets": download_visual_assets,
        "pdf_render_dpi": 144,
        "react_enabled": react_enabled,
        "self_heal_enabled": self_heal,
        "react_use_llm": react_llm,
        "max_page_retries": max_page_retries,
        "max_control_retries": max_control_retries,
        "max_mcp_restarts": max_mcp_restarts,
        "http_fallback": http_fallback,
        "retry_recoverable_on_resume": True,
        "capture_dynamic_state_evidence": True,
        "repeatable_control_stable_rounds": 2,
        "repeatable_control_max_clicks": 0,
        "llm_chunk_chars": 12000,
        "llm_chunk_overlap": 700,
        "max_llm_chunks": 0,
        "hierarchical_summaries": True,
        "agentq_action_model_enabled": agentq_action_model,
        "agentq_actor_critic_enabled": agentq_action_model,
        "agentq_action_memory_enabled": agentq_memory,
        "agentq_mcts_exploration_enabled": agentq_mcts,
        "agentq_exploration_weight": 1.25,
        "agentq_llm_critic_enabled": agentq_llm_critic,
        "agentq_llm_critic_margin": 0.65,
        "dom_mutation_observer_enabled": dom_mutation_observer,
        "mutation_quiet_window_ms": 700,
        "mutation_max_wait_seconds": 12.0,
        "continuous_until_frontier_clean": continuous_until_clean,
        "supervisor_stale_seconds": supervisor_stale_seconds,
        "supervisor_startup_grace_seconds": 240,
        "supervisor_poll_seconds": 5,
        "supervisor_max_restarts": 0,
        "supervisor_restart_backoff_seconds": 10,
        "supervisor_max_backoff_seconds": 300,
        "heartbeat_interval_seconds": 10,
        "worker_lease_seconds": max(600, supervisor_stale_seconds + 180),
        "frontier_lane_scheduler_enabled": lane_scheduler,
        "dedupe_visual_asset_variants": dedupe_asset_variants,
        "process_visual_assets_as_lane": True,
        "asset_browser_fallback_on_403": True,
        "coverage_checkpoint_every_items": 20,
        "coverage_checkpoint_seconds": 300,
        "llm_text_cache_enabled": llm_text_cache,
        "stable_control_context_identity": stable_control_memory,
        "control_progress_ttl_hours": 168,
        "extract_product_cards": extract_product_cards,
        "product_detail_completion_enabled": product_detail_completion,
        "product_min_completeness": product_min_completeness,
        "product_require_price_on_commerce_pages": product_require_price,
        "product_reprocess_existing_sources_on_upgrade": True,
        "product_revisit_enabled": product_revisit,
        "product_revisit_max_attempts": product_revisit_attempts,
        "product_revisit_max_sweeps": max(4, product_revisit_attempts * 2),
        "product_revisit_no_gain_limit": product_revisit_no_gain,
        "product_revisit_min_gain": 0.02,
        "product_revisit_priority": 0,
        "product_revisit_missing_price": True,
        "product_revisit_missing_specs": True,
        "product_revisit_unmapped_evidence": True,
    }

    running, current_pid = process_running()
    status = read_json(STATUS_FILE, {})
    event_name, event_stats = human_status(status)

    st.divider()
    status_cols = st.columns([1.4, 1, 1, 1])
    status_cols[0].metric("Supervisor", f"Running · PID {current_pid}" if running else "Stopped")
    status_cols[1].metric("Last event", event_name)
    status_cols[2].metric("Processed", int(event_stats.get("pages_seen", 0)))
    status_cols[3].metric("Pending", int(event_stats.get("queue_remaining", 0)))

    button_cols = st.columns(4)
    if button_cols[0].button("Start / Resume", type="primary", width="stretch", disabled=running):
        ok, message = start_worker(config)
        (st.success if ok else st.error)(message)
        time.sleep(0.4)
        st.rerun()
    if button_cols[1].button("Graceful Stop", width="stretch", disabled=not running):
        request_stop()
        st.info("Stop requested. The current operation will finish, then queue and database state will be preserved.")
    if button_cols[2].button("Force Stop", width="stretch", disabled=not running):
        ok, message = force_stop()
        (st.success if ok else st.error)(message)
        st.rerun()
    if button_cols[3].button("Save Configuration", width="stretch"):
        write_json_atomic(CONFIG_FILE, config)
        st.success(f"Saved to {CONFIG_FILE.name}")

    with st.expander("Danger zone"):
        confirm = st.text_input("Type DELETE to remove the crawler database, evidence and runtime state")
        if st.button("Delete crawler data", disabled=running or confirm != "DELETE"):
            for target in (KNOWLEDGE_DIR, RUNTIME_DIR, REPORTS_DIR):
                if target.exists():
                    shutil.rmtree(target)
                target.mkdir(parents=True, exist_ok=True)
            st.success("Crawler data was removed. Application source code was not changed.")
            st.rerun()

with activity_tab:
    st.subheader("Live crawler status")

    @st.fragment(run_every="2s")
    def live_activity() -> None:
        running, pid = process_running()
        status = read_json(STATUS_FILE, {})
        event, stats = human_status(status)
        queue = stats.get("queue", {}) if isinstance(stats.get("queue"), dict) else {}

        cols = st.columns(8)
        cols[0].metric("Supervisor", f"PID {pid}" if running else "Stopped")
        cols[1].metric("Event", event)
        cols[2].metric("Seen", int(stats.get("pages_seen", 0)))
        cols[3].metric("Stored", int(stats.get("pages_stored", 0)))
        cols[4].metric("PDFs", int(stats.get("pdfs_stored", 0)))
        cols[5].metric("Reviews", int(stats.get("reviews_extracted", 0)))
        cols[6].metric("Public data", int(stats.get("public_api_resources_stored", 0)))
        cols[7].metric("Self-healed", int(stats.get("heal_successes", 0)))

        detail_cols = st.columns(8)
        detail_cols[0].metric("Coverage audits", int(stats.get("coverage_audits", 0)))
        detail_cols[1].metric("Coverage recovery pending", int(stats.get("coverage_recoverable_gaps", stats.get("coverage_contract_failures", 0))))
        detail_cols[2].metric("Office docs", int(stats.get("office_documents_stored", 0)))
        detail_cols[3].metric("Transcripts", int(stats.get("transcripts_stored", 0)))
        detail_cols[4].metric("JSON-LD", int(stats.get("json_ld_records", 0)))
        detail_cols[5].metric("FAQs", int(stats.get("faq_records_extracted", 0)))
        detail_cols[6].metric("Shadow roots", int(stats.get("shadow_dom_captures", 0)))
        detail_cols[7].metric("Iframes", int(stats.get("iframe_dom_captures", 0)))
        terminal_coverage = int(stats.get("coverage_terminal_failures", 0))
        if terminal_coverage:
            st.error(f"{terminal_coverage} page(s) ended with a terminal evidence failure such as an access block or unusable response.")
        elif int(stats.get("coverage_recoverable_gaps", 0)):
            st.caption("Coverage items shown above are queued enrichment/recovery work, not terminal validation failures.")

        product_cols = st.columns(5)
        product_cols[0].metric("Products extracted", int(stats.get("product_records_extracted", 0)))
        product_cols[1].metric("Products with price", int(stats.get("product_records_with_price", 0)))
        product_cols[2].metric("Products with core specs", int(stats.get("product_records_with_core_specs", 0)))
        product_cols[3].metric("Product detail URLs", int(stats.get("product_detail_urls_enqueued", 0)))
        product_cols[4].metric("Product enrichment pending", int(stats.get("product_completeness_failures", 0)))
        revisit_cols = st.columns(5)
        revisit_cols[0].metric("Revisit sweeps", int(stats.get("product_revisit_sweeps", 0)))
        revisit_cols[1].metric("Revisit URLs queued", int(stats.get("product_revisit_urls_enqueued", 0)))
        revisit_cols[2].metric("Products completed by revisit", int(stats.get("product_revisit_products_completed", 0)))
        revisit_cols[3].metric("Revisit exhausted", int(stats.get("product_revisit_products_exhausted", 0)))
        revisit_cols[4].metric("Unmapped fields recovered", int(stats.get("product_unmapped_fields_mapped", 0)))
        normalization_cols = st.columns(2)
        normalization_cols[0].metric("JSON/payload repairs", int(stats.get("normalization_repairs", 0)))
        normalization_cols[1].metric("Unmapped evidence preserved", int(stats.get("unmapped_evidence_preserved", 0)))

        pdf_cols = st.columns(6)
        pdf_cols[0].metric("PDF completed", int(stats.get("pdf_successes", stats.get("pdfs_stored", 0))))
        pdf_cols[1].metric("Binary PDFs", int(stats.get("pdf_binary_files_stored", 0)))
        pdf_cols[2].metric("Browser-viewer PDFs", int(stats.get("pdf_browser_only_processed", 0)))
        pdf_cols[3].metric("PDF summaries", int(stats.get("documents_summarized", 0)))
        pdf_cols[4].metric("Viewer screenshots", int(stats.get("pdf_browser_viewer_viewports", 0)))
        pdf_cols[5].metric("PDF MB", round(int(stats.get("document_bytes_downloaded", 0)) / (1024 * 1024), 1))

        pdf_truth_cols = st.columns(7)
        pdf_truth_cols[0].metric("Source-button clicks", int(stats.get("pdf_browser_click_replays", 0)))
        pdf_truth_cols[1].metric(
            "Click byte/viewer captures",
            int(stats.get("pdf_browser_click_downloads", 0))
            + int(stats.get("pdf_browser_click_viewer_captures", 0)),
        )
        pdf_truth_cols[2].metric("Intermediate rejects", int(stats.get("pdf_validation_rejections", 0)))
        pdf_truth_cols[3].metric("Recovered after rejection", int(stats.get("pdf_validation_recovered", 0)))
        pdf_truth_cols[4].metric("Recovered PDFs", int(stats.get("pdf_recoveries", 0)))
        pdf_truth_cols[5].metric("Terminal failures", int(stats.get("pdf_download_failures", 0)))
        pdf_truth_cols[6].metric(
            "Terminal validation",
            int(stats.get("pdf_terminal_validation_failures", stats.get("pdf_validation_failures", 0))),
        )

        transport_events = int(stats.get("pdf_transport_events", 0))
        if transport_events:
            st.caption(
                f"PDF transport diagnostics: {transport_events}. Candidate rejections are recoverable acquisition checks; "
                "only Terminal failures and Terminal validation indicate unresolved document work."
            )
        candidate_rejections = int(stats.get("pdf_validation_rejections", 0))
        terminal_validation = int(stats.get("pdf_terminal_validation_failures", stats.get("pdf_validation_failures", 0)))
        if candidate_rejections > 0 and terminal_validation == 0:
            st.info(
                f"{candidate_rejections} PDF candidate(s) were rejected during recovery, but none is a terminal validation failure. "
                "The crawler is continuing through source-click, network-body, browser-viewer, and browser-context fallback paths."
            )

        if int(stats.get("pdf_successes", stats.get("pdfs_stored", 0))) == 0 and int(stats.get("pdf_download_failures", 0)) > 0:
            st.warning(
                "PDF links are being attempted but no PDF has completed text/vision extraction yet. "
                "Use v6.19 repair/resume. PDFs should emit pdf_dom_candidates followed by pdf_browser_context_acquisition_done, or a unique-control/viewer fallback. Standalone PDF HTTP is disabled by default. Check PDF_SUCCESSES.jsonl for completed documents and PDF_FAILURES.jsonl only for terminal failures."
            )
        if event in {"supervisor_configuration_blocked", "crawl_blocked_configuration", "crawler_configuration_blocked"}:
            st.error(str(status.get("remediation") or "Playwright MCP browser setup is incomplete. Run install_mcp_browser.ps1 or select an installed Chrome/Edge channel, then Start / Resume."))

        child_pid = status.get("worker_pid")
        if child_pid:
            st.caption(f"Active child worker PID: {child_pid} · supervisor automatically restarts it after crashes or stale heartbeats.")

        pending = int(stats.get("queue_remaining", queue.get("PENDING", 0) if isinstance(queue, dict) else 0))
        processed = int(stats.get("pages_seen", 0))
        ratio = processed / max(1, processed + pending)
        st.progress(min(1.0, max(0.0, ratio)), text=f"{processed} processed · {pending} currently pending")

        compact = {key: value for key, value in status.items() if key not in {"traceback", "stats", "result"}}
        st.json(compact)
        if status.get("traceback"):
            with st.expander("Latest traceback"):
                st.code(str(status["traceback"]), language="text")

        frontier_path = KNOWLEDGE_DIR / "FRONTIER_COVERAGE_REPORT.json"
        if frontier_path.exists():
            with st.expander("Frontier and coverage contract report", expanded=False):
                st.json(read_json(frontier_path, {}))

        st.markdown("**Worker log**")
        st.code(tail_text(WORKER_LOG, 140) or "No worker log yet.", language="text")

    live_activity()

with data_tab:
    st.subheader("Knowledge database")
    selected_db = Path(db_value)
    if not selected_db.is_absolute():
        selected_db = ROOT / selected_db
    store = SQLiteKnowledgeGraph(selected_db)
    graph_stats = store.stats()
    metrics = st.columns(7)
    metrics[0].metric("Sources", graph_stats["sources"])
    metrics[1].metric("Nodes", graph_stats["nodes"])
    metrics[2].metric("Edges", graph_stats["edges"])
    metrics[3].metric("Facts", graph_stats["facts"])
    metrics[4].metric("Chunks", graph_stats["chunks"])
    metrics[5].metric("Interactions", graph_stats["interactions"])
    metrics[6].metric("Dynamic controls", graph_stats["dynamic_controls"])

    st.markdown("**Extractor data quality + compact semantic mapping (v6.19)**")
    quality = store.extractor_quality_report()
    quality_cols = st.columns(5)
    quality_cols[0].metric("Canonical products", int(quality.get("products", 0)))
    quality_cols[1].metric("Media-contaminated", int(quality.get("media_contaminated_nodes", 0)))
    quality_cols[2].metric("Exact Dell URL coverage", f"{float(quality.get('exact_dell_url_coverage_percent', 0)):.2f}%")
    quality_cols[3].metric("Retail-ready products", int(quality.get("retail_ready_products", 0)))
    quality_cols[4].metric("Exact product URLs", int(quality.get("exact_dell_product_urls", 0)))
    if int(quality.get("media_contaminated_nodes", 0)):
        st.error(
            "Product nodes are still using image/static-media URLs as identity. Stop the crawler and run "
            "`python .\\repair_v618.py --db knowledge\\dell_en_uk.db --knowledge knowledge`, then resume. "
            "v6.19 preserves the media evidence separately, recovers a stable Product identity, validates the semantic graph, and automatically revisits incomplete product/detail sources until bounded completion."
        )
    else:
        st.success("No media/static URL is being used as a Product identity.")
    field_coverage = quality.get("field_coverage_percent", {}) if isinstance(quality.get("field_coverage_percent"), dict) else {}
    if field_coverage:
        st.dataframe(
            arrow_safe_records([{"field": key, "coverage_percent": value} for key, value in field_coverage.items()]),
            width="stretch", hide_index=True,
        )
    if quality.get("contaminated_samples"):
        with st.expander("Contaminated Product-node samples"):
            st.dataframe(arrow_safe_records(quality.get("contaminated_samples") or []), width="stretch", hide_index=True)

    enrichment = store.product_enrichment_status_report()
    st.markdown("**Autonomous product-completion state**")
    enrich_cols = st.columns(5)
    statuses = enrichment.get("status_counts", {}) if isinstance(enrichment, dict) else {}
    enrich_cols[0].metric("Queued revisits", int(statuses.get("QUEUED", 0) or 0))
    enrich_cols[1].metric("Completed", int(statuses.get("COMPLETE", 0) or 0))
    enrich_cols[2].metric("No-gain exhausted", int(statuses.get("EXHAUSTED_NO_GAIN", 0) or 0))
    enrich_cols[3].metric("Attempt exhausted", int(statuses.get("EXHAUSTED_ATTEMPTS", 0) or 0))
    enrich_cols[4].metric("No usable URL", int(statuses.get("BLOCKED_NO_URL", 0) or 0))
    with st.expander("Product completion details"):
        st.json(enrichment)

    search_query = st.text_input("Search extracted content", placeholder="AI workstation, GPU memory, product review, coupon...")
    if search_query:
        results = store.search(search_query, limit=50)
        st.dataframe(arrow_safe_records(results), width="stretch", hide_index=True)

    source_col, heal_col = st.columns(2)
    with source_col:
        st.markdown("**Recently extracted sources**")
        st.dataframe(arrow_safe_records(store.recent_sources(100)), width="stretch", hide_index=True)
    with heal_col:
        st.markdown("**Recent self-healing actions**")
        st.dataframe(arrow_safe_records(store.recent_self_heal_events(100)), width="stretch", hide_index=True)

    st.markdown("**v6.19 semantic graph readiness**")
    semantic_quality = store.semantic_quality_report()
    sem_cols = st.columns(10)
    sem_cols[0].metric("Fetched sources", int(semantic_quality.get("sources", 0)))
    sem_cols[1].metric("Semantic nodes", int(semantic_quality.get("semantic_nodes", 0)))
    sem_cols[2].metric("Link evidence", int(semantic_quality.get("link_evidence_rows", 0)))
    sem_cols[3].metric("Unfetched placeholders", int(semantic_quality.get("unfetched_placeholder_nodes", 0)))
    sem_cols[4].metric("Unclassified nodes", int(semantic_quality.get("unclassified_semantic_nodes", 0)))
    sem_cols[5].metric("Duplicate semantic IDs", int(semantic_quality.get("duplicate_semantic_identity_pairs", 0)))
    sem_cols[6].metric("Duplicate product IDs", int(semantic_quality.get("duplicate_product_identity_pairs", 0)))
    sem_cols[7].metric("Classification", f"{float(semantic_quality.get('node_classification_coverage', 0))*100:.1f}%")
    sem_cols[8].metric("Validation records", int(semantic_quality.get("validated_sources", 0)))
    sem_cols[9].metric("Graph/source ratio", float(semantic_quality.get("graph_node_to_source_ratio", 0)))
    if semantic_quality.get("clean_for_semantic_sync"):
        st.success("Semantic graph is clean for canonical Neo4j synchronization: every graph node is canonically classified, and no unfetched placeholders, evidence-only graph nodes, duplicate semantic identities, or duplicate strong Product identities were detected.")
    else:
        st.warning(
            "Historical graph noise is still present. Use Graceful Stop and run "
            "`python .\\repair_v618.py --db knowledge\\dell_en_uk.db --knowledge knowledge`, then audit with "
            "`python .\\audit_knowledge_v618.py --db knowledge\\dell_en_uk.db --require-clean`."
        )
    with st.expander("Semantic graph readiness details"):
        st.json(semantic_quality)

    st.markdown("**Canonical graph-schema audit**")
    schema_quality = store.canonical_schema_report()
    schema_cols = st.columns(6)
    schema_cols[0].metric("Raw node types", int(schema_quality.get("raw_node_type_count", 0)))
    schema_cols[1].metric("Canonical node types", int(schema_quality.get("canonical_node_type_count", 0)))
    schema_cols[2].metric("Raw relationship types", int(schema_quality.get("raw_relationship_type_count", 0)))
    schema_cols[3].metric("Canonical relationship types", int(schema_quality.get("canonical_relationship_type_count", 0)))
    schema_cols[4].metric("Unresolved placeholders", int(schema_quality.get("unresolved_placeholder_nodes", 0)))
    schema_cols[5].metric("Quarantined", int(schema_quality.get("quarantined_nodes", 0)))
    if int(schema_quality.get("raw_node_type_count", 0)) > int(schema_quality.get("canonical_node_type_count", 0)):
        st.info(
            "Historical/raw evidence can contain many source-specific types, but v6.19 validates and bounds the semantic ontology. "
            "New extraction no longer creates arbitrary labels from JSON keys or unresolved relation references."
        )
    with st.expander("Canonical schema mapping details"):
        st.json(schema_quality)

    st.markdown("**Node types**")
    st.json(graph_stats.get("node_types", {}))
    st.markdown("**Queue state**")
    st.json(graph_stats.get("queue", {}))
    st.markdown("**Fast frontier lanes**")
    st.json(graph_stats.get("queue_lanes", {}))
    frontier_path = KNOWLEDGE_DIR / "FRONTIER_COVERAGE_REPORT.json"
    if frontier_path.exists():
        st.markdown("**Latest frontier coverage audit**")
        st.json(read_json(frontier_path, {}))

with export_tab:
    st.subheader("Export crawler output")
    selected_db = Path(db_value)
    if not selected_db.is_absolute():
        selected_db = ROOT / selected_db
    store = SQLiteKnowledgeGraph(selected_db)

    export_cols = st.columns(3)
    if export_cols[0].button("Export JSON", width="stretch"):
        path = store.export_json(REPORTS_DIR / "dell_crawler_export.json")
        st.success(f"Created {path}")
    if export_cols[1].button("Export GraphML", width="stretch"):
        path = store.export_graphml(REPORTS_DIR / "dell_crawler_graph.graphml")
        st.success(f"Created {path}")
    if export_cols[2].button("Create crawl bundle", width="stretch"):
        archive_base = REPORTS_DIR / "dell_crawler_bundle"
        archive = shutil.make_archive(str(archive_base), "zip", root_dir=KNOWLEDGE_DIR)
        st.success(f"Created {archive}")

    for export_file in sorted(REPORTS_DIR.glob("*")):
        if export_file.is_file():
            st.download_button(
                f"Download {export_file.name}",
                data=export_file.read_bytes(),
                file_name=export_file.name,
                mime="application/zip" if export_file.suffix == ".zip" else "application/octet-stream",
                key=f"download-{export_file.name}-{export_file.stat().st_mtime_ns}",
                width="stretch",
            )
