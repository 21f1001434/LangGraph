@echo off
setlocal
cd /d "%~dp0"
where npx >nul 2>nul || (echo npx was not found. Install Node.js 20+ and reopen Command Prompt. & exit /b 1)
echo Installing the Playwright MCP Chrome-for-Testing browser...
call npx -y @playwright/mcp@0.0.78 install-browser chrome-for-testing
if errorlevel 1 exit /b %errorlevel%
echo Browser installation complete. Return to the app and click Start / Resume.
