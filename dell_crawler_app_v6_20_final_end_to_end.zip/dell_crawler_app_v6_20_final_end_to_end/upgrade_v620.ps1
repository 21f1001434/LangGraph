param(
  [string]$Python = "python",
  [string]$Db = "knowledge\dell_en_uk.db",
  [string]$Knowledge = "knowledge",
  [int]$KeepCrawlRuns = 3
)
$ErrorActionPreference = "Stop"
Write-Host "Dell Crawler v6.20 final upgrade + safe old DB cleanup" -ForegroundColor Cyan
Write-Host "Use Graceful Stop first. Pause OneDrive sync while SQLite is being repaired/vacuumed." -ForegroundColor Yellow
Write-Host "A pre_v620 backup is created before any cleanup. Semantic knowledge/evidence is preserved." -ForegroundColor Green
& $Python .\repair_v620.py --db $Db --knowledge $Knowledge --keep-crawl-runs $KeepCrawlRuns
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\audit_knowledge_v620.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\release_verify_v620.py --db $Db
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python -m streamlit run .\app.py
