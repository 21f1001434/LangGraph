param(
  [string]$Db = "knowledge\dell_en_uk.db",
  [string]$Knowledge = "knowledge",
  [switch]$NoStart
)
$ErrorActionPreference = "Stop"
Write-Host "Dell Crawler v6.16 upgrade" -ForegroundColor Cyan
Write-Host "Use Graceful Stop in the UI before running this command." -ForegroundColor Yellow
python .\repair_v616.py --db $Db --knowledge $Knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python .\audit_knowledge_v616.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (-not $NoStart) {
  python -m streamlit run .\app.py
}
