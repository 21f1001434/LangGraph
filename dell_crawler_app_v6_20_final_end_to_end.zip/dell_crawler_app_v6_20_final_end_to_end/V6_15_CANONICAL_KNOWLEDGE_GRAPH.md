# v6.15 Canonical Knowledge Graph

v6.15 separates **raw evidence retention** from the **semantic graph schema**.

The crawler still keeps source pages, chunks, facts and unsupported evidence for audit,
but arbitrary LLM/schema.org types can no longer become graph labels. Unresolved
relation references are preserved as unmapped evidence instead of placeholder nodes.

Canonical semantic types are bounded to product, family, category, brand, offer,
review, document/section/support, FAQ, requirement/compatibility, use case/workload,
solution/service/software, organization/market/account knowledge and a small set of
provenance/evidence types.

Product specifications remain properties/facts; they do not become one label per JSON
key. Brand/category/family are materialized as stable semantic dimensions with bounded
relationships.

For an existing database:

```powershell
# Gracefully stop the crawler first.
python .\repair_v615.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v615.py --db knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

The repair creates a `pre_v615` backup before changing graph node/edge classifications.
