# v6.14 Full Dell Masthead Taxonomy Coverage

v6.14 adds a deterministic discovery pass for Dell global navigation before the normal durable crawl starts.

The pass opens and audits the current live menu families shown in the supplied screenshots:

- Artificial Intelligence
- IT Infrastructure
- Computers & Accessories
- Services
- Support
- Deals
- Financing
- Account / Profile when Dell SSO is authenticated

Every safe nested flyout is expanded up to the configured depth. URLs exposed only after hover/click are added to the same canonical frontier as sitemap and ordinary links, so existing URL/content deduplication prevents repeated extraction.

`knowledge/MASTHEAD_TAXONOMY_REPORT.json` records expected labels, observed labels, discovered URLs, partial/missing menu groups and transactional labels that were deliberately skipped. Payment, checkout, sign-in/sign-out and account mutation actions are never activated.

The locale is configurable (`DELL_LOCALE=en-uk` or `en-us`). Bootstrap seeds are localised and the live masthead remains the runtime source of truth.
