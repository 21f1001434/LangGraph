# Dell Crawler v6.19 — Final Market-Aware Classified Crawler

v6.19 is a verification-driven hardening release on top of v6.18.

## Additional fixes discovered during final verification

- Removed remaining UK-only extraction assumptions from deterministic HTML, JSON-LD, product-card and Dell AIA/vision prompts.
- Market, locale and currency are inferred per source URL/evidence (for example en-us→USD, en-in→INR, en-uk→GBP, en-ca→CAD, en-au→AUD, major EU locales→EUR).
- `PRICE_GBP` is retained only as a backward-compatible UK predicate; non-UK extraction uses market-neutral `PRICE` with an explicit currency unit.
- Existing legacy non-UK rows incorrectly stamped GBP are repaired during `repair_v619.py`.
- Third-party products sold on Dell.com are no longer automatically branded `Dell` when the source did not provide a brand.
- Category variants such as `Laptop`, `Laptops`, and `Laptop Products Category` converge to one semantic identity.
- Product-family variants such as `Dell Pro` and `Pro Series` converge when brand evidence is available.
- Dell AIA text/vision prompts now explicitly restrict entities to the bounded ontology and instruct CPU/GPU/RAM/storage/display/OS/color/battery to remain product facts/properties rather than standalone graph nodes.
- Strict graph readiness now also checks for product price/currency mismatches and missing currency on priced products.

- Locale hardening now also covers HTTP/PDF `Accept-Language`, support-page archetypes, hreflang filtering, browser PDF requests, blog filtering, run IDs and country-first Dell locale aliases (for example `in-en` → `en-in`).
- The UI/worker derive the canonical market from the locale when `DELL_MARKET` is left blank; `.env.example` now recommends that safer default.
- Identity-poor third-party products are no longer merged by a model-only match when no brand is present; this prevents two unrelated marketplace/accessory items sharing a model token from collapsing into one Product.

## Required clean state

`audit_knowledge_v619.py --require-clean` requires zero unclassified nodes, zero duplicate semantic/product identities, zero unfetched placeholder graph nodes, zero currency-market mismatches, and 100% classification coverage.
