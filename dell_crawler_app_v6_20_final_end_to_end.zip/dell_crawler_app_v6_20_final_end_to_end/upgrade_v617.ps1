param(
  [string]$Db = "knowledge\dell_en_uk.db",
  [string]$Knowledge = "knowledge",
  [switch]$NoStart,
  [switch]$SkipTests
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Dell Crawler v6.17 final verified upgrade" -ForegroundColor Cyan
Write-Host "Use Graceful Stop first. If this project is under OneDrive, pause sync while SQLite is being repaired/crawled." -ForegroundColor Yellow

$Python = ".\.venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { $Python = "python" }

& $Python .\repair_v617.py --db $Db --knowledge $Knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\audit_knowledge_v617.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$verifyArgs = @(".\release_verify_v617.py", "--db", $Db)
if ($SkipTests) { $verifyArgs += "--skip-tests" }
& $Python @verifyArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (-not $NoStart) {
  & $Python -m streamlit run .\app.py
}
