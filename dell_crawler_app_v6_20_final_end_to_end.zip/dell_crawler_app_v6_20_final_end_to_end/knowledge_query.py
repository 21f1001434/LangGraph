from __future__ import annotations

import argparse
import json
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def main() -> int:
    parser = argparse.ArgumentParser(description="Query the Dell crawler SQLite knowledge graph.")
    parser.add_argument("query", nargs="+", help="Knowledge question/search terms")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--limit", type=int, default=12)
    args = parser.parse_args()
    db = Path(args.db)
    if not db.is_file():
        raise SystemExit(f"Database not found: {db}")
    store = SQLiteKnowledgeGraph(db)
    results = store.search(" ".join(args.query), limit=max(1, min(50, args.limit)))
    print(json.dumps(results, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
