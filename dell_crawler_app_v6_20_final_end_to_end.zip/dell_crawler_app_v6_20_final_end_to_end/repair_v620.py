from __future__ import annotations

"""v6.20 final repair: v6.19 canonical repair + safe legacy DB cleanup."""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.db_hygiene import purge_irrelevant_legacy_data
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from repair_v610 import now, sqlite_backup, stamp
from repair_v619 import repair as repair_v619
from repair_v617 import rebuild_node_fts


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    keep_crawl_runs: int = 3,
    keep_old_runtime_data: bool = False,
    no_vacuum: bool = False,
) -> dict[str, Any]:
    backup = ""
    if not no_backup:
        target = db.with_name(f"{db.stem}.pre_v620_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    # Reuse every v6.19 semantic/market repair, but suppress its nested backup.
    base = repair_v619(db, knowledge, force_active=force_active, no_backup=True)
    store = SQLiteKnowledgeGraph(db)

    cleanup = purge_irrelevant_legacy_data(
        store,
        keep_crawl_runs=max(0, int(keep_crawl_runs)),
        purge_runtime_telemetry=not bool(keep_old_runtime_data),
        vacuum=not bool(no_vacuum),
    )
    if not cleanup.get("ok"):
        raise SystemExit(f"Database hygiene failed: {cleanup}")

    # Hygiene may remove old FTS-relevant source rows. Rebuild indexes from the
    # retained canonical knowledge only.
    rebuild_node_fts(store)
    try:
        store.rebuild_chunk_fts()
    except AttributeError:
        # Older internal helper name may not exist; schema init keeps chunks FTS
        # usable and runtime search has a LIKE fallback.
        pass

    quality = store.semantic_quality_report()
    extractor = store.extractor_quality_report()
    schema = store.canonical_schema_report()
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]

    if integrity.casefold() != "ok" or fk:
        raise SystemExit(f"Post-cleanup DB validation failed: integrity={integrity}, foreign_keys={fk[:10]}")

    knowledge.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "migration": "v6.x -> v6.20 final canonical crawler + safe legacy DB cleanup",
        "database": str(db),
        "backup": backup,
        "v619_base_repair": base,
        "database_hygiene": cleanup,
        "semantic_quality": quality,
        "extractor_quality": extractor,
        "canonical_schema": schema,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "finished_at": now(),
    }
    path = knowledge / "DATABASE_REPAIR_V620.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade Dell crawler DB to v6.20 and purge irrelevant old runtime DB data safely.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--keep-crawl-runs", type=int, default=3)
    parser.add_argument("--keep-old-runtime-data", action="store_true", help="Preserve old browser/runtime telemetry instead of purging it.")
    parser.add_argument("--no-vacuum", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(
        db,
        Path(args.knowledge).expanduser().resolve(),
        force_active=args.force_active,
        no_backup=args.no_backup,
        keep_crawl_runs=args.keep_crawl_runs,
        keep_old_runtime_data=args.keep_old_runtime_data,
        no_vacuum=args.no_vacuum,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
