from __future__ import annotations

import argparse
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.content_extractor import DellContentExtractor
from dell_crawler_core.crawl_models import CrawlPage, DiscoveredLink
from dell_crawler_core.document_pipeline import normalize_pdf_download_url
from dell_crawler_core.frontier_scheduler import DOCUMENT, PAGE, classify_frontier_url, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.product_intelligence import extract_product_records, extraction_payload_for_products


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sqlite_backup(source_path: Path, target_path: Path) -> None:
    source = sqlite3.connect(source_path, timeout=120)
    target = sqlite3.connect(target_path, timeout=120)
    try:
        source.execute("PRAGMA busy_timeout=120000")
        source.backup(target)
    finally:
        target.close()
        source.close()


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import psutil
        return bool(psutil.pid_exists(pid) and psutil.Process(pid).is_running())
    except Exception:
        try:
            if os.name == "nt":
                return False
            os.kill(pid, 0)
            return True
        except Exception:
            return False


def clear_stale_profile_lease(root: Path) -> dict[str, Any]:
    profile = root / "browser_profile" / "dell_crawler"
    lease = profile.parent / f".{profile.name}.dell-crawler.lock"
    if not lease.exists():
        return {"lease_path": str(lease), "status": "absent"}
    try:
        payload = json.loads(lease.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    owner_pid = int(payload.get("pid") or 0)
    if pid_alive(owner_pid):
        return {"lease_path": str(lease), "status": "live_owner", "owner_pid": owner_pid}
    lease.unlink(missing_ok=True)
    return {"lease_path": str(lease), "status": "stale_removed", "owner_pid": owner_pid}


def source_links(conn: sqlite3.Connection, source_url: str) -> list[DiscoveredLink]:
    output: list[DiscoveredLink] = []
    seen: set[str] = set()
    queue_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(crawl_queue)").fetchall()}
    if {"url", "parent_url"}.issubset(queue_columns):
        for row in conn.execute(
            "SELECT url,relation,priority FROM crawl_queue WHERE parent_url=? ORDER BY priority,url",
            (source_url,),
        ).fetchall():
            url = str(row["url"] or "")
            if not url or url in seen:
                continue
            seen.add(url)
            output.append(DiscoveredLink(
                label=url, url=url, source="existing_frontier", relation=str(row["relation"] or "LINKS_TO"),
                priority=int(row["priority"] or 50), resource_kind="ProductDetail" if "/spd/" in url.lower() else "",
            ))
    page = conn.execute("SELECT id FROM nodes WHERE node_key=?", (f"url:{source_url}",)).fetchone()
    if page:
        for row in conn.execute(
            """
            SELECT n.node_key,n.name,e.predicate,n.attributes_json
            FROM edges e JOIN nodes n ON n.id=e.target_id
            WHERE e.source_id=?
            """,
            (int(page["id"]),),
        ).fetchall():
            attrs = json.loads(str(row["attributes_json"] or "{}")) if row["attributes_json"] else {}
            url = str(attrs.get("url") or (str(row["node_key"])[4:] if str(row["node_key"]).startswith("url:") else ""))
            if not url or url in seen:
                continue
            seen.add(url)
            output.append(DiscoveredLink(
                label=str(row["name"] or url), url=url, source="existing_graph",
                relation=str(row["predicate"] or "LINKS_TO"), priority=2 if "/spd/" in url.lower() else 50,
                resource_kind="ProductDetail" if "/spd/" in url.lower() else "",
            ))
    return output


def replay_product_sources(store: SQLiteKnowledgeGraph) -> dict[str, Any]:
    extractor = DellContentExtractor(aia=None, use_llm=False, use_vision=False)
    processed = records = prices = specs = observations = 0
    failures: list[dict[str, str]] = []
    with store.connect() as conn:
        sources = conn.execute(
            """
            SELECT url,canonical_url,title,page_type,content_hash,http_status,metadata_json
            FROM sources
            WHERE page_type IN ('Product','ProductCatalog','OfferCatalog')
            ORDER BY fetched_at
            """
        ).fetchall()
    for source in sources:
        source_url = str(source["canonical_url"] or source["url"])
        try:
            with store.connect() as conn:
                text = "\n".join(
                    str(row["text"] or "") for row in conn.execute(
                        "SELECT text FROM chunks WHERE source_url IN (?,?) ORDER BY chunk_index",
                        (str(source["url"]), source_url),
                    ).fetchall()
                )
                links = source_links(conn, source_url)
            metadata = json.loads(str(source["metadata_json"] or "{}"))
            page = CrawlPage(
                url=str(source["url"]), canonical_url=source_url, title=str(source["title"] or source_url),
                page_type=str(source["page_type"] or "WebPage"), snapshot="", visible_text=text,
                links=links, controls=[], http_status=source["http_status"],
                content_hash=str(source["content_hash"] or ""), metadata=metadata,
            )
            product_records = extract_product_records(page)
            # Keep only records with a stable identity plus at least one commercial
            # or technical field. This prevents old page footer text from creating
            # name-only Product nodes during migration.
            product_records = [
                item for item in product_records
                if (item.product_url or item.model or item.order_code or item.part_number)
                and any((item.current_price, item.processor, item.graphics, item.memory, item.storage,
                         item.display, item.operating_system, item.rating, item.review_count))
            ]
            if not product_records:
                processed += 1
                continue
            payload = extraction_payload_for_products(page, product_records)
            store.ingest_extraction(source_url, payload)
            processed += 1
            records += len(product_records)
            prices += sum(bool(item.current_price) for item in product_records)
            specs += sum(bool(item.processor or item.graphics or item.memory or item.storage or item.display or item.operating_system) for item in product_records)
            observations += len(product_records)
        except Exception as exc:
            failures.append({"url": source_url, "error": f"{type(exc).__name__}: {exc}"})
    return {
        "sources_processed": processed,
        "product_records_recovered": records,
        "product_records_with_price": prices,
        "product_records_with_core_specs": specs,
        "observations_attempted": observations,
        "failures": failures,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade an existing Dell crawler DB to v6.8 product-level price/spec extraction.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--skip-source-replay", action="store_true")
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    probe = sqlite3.connect(db, timeout=30)
    probe.row_factory = sqlite3.Row
    try:
        columns = {str(row[1]) for row in probe.execute("PRAGMA table_info(crawl_queue)").fetchall()}
        active = 0
        if {"status", "lease_expires_at"}.issubset(columns):
            active = int(probe.execute(
                "SELECT COUNT(*) FROM crawl_queue WHERE status='IN_PROGRESS' AND lease_expires_at<>'' AND lease_expires_at>?",
                (now(),),
            ).fetchone()[0] or 0)
    finally:
        probe.close()
    if active and not args.force_active:
        raise SystemExit(f"Refusing to repair while {active} active worker lease(s) exist. Use Graceful Stop first.")

    lease = clear_stale_profile_lease(root)
    if lease.get("status") == "live_owner" and not args.force_active:
        raise SystemExit(f"Browser profile is still owned by PID {lease.get('owner_pid')}. Stop the old worker/browser first.")

    backup = ""
    existing = sorted(db.parent.glob(f"{db.stem}.pre_v68_*{db.suffix}"))
    if not args.no_backup and (args.force_backup or not existing):
        target = db.with_name(f"{db.stem}.pre_v68_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)
    elif existing:
        backup = str(existing[-1])

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset = store.reset_in_progress()
    ts = now()
    with store.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        # Restore semantic page types/names that older endpoint ingestion had
        # overwritten with generic Endpoint labels such as 'Skip to main content'.
        semantic_rows = conn.execute("SELECT url,canonical_url,title,page_type FROM sources").fetchall()
        semantic_reclassified = 0
        for row in semantic_rows:
            key = f"url:{str(row['canonical_url'] or row['url'])}"
            semantic_reclassified += int(conn.execute(
                "UPDATE nodes SET node_type=?,name=?,last_seen=? WHERE node_key=?",
                (str(row["page_type"] or "WebPage"), str(row["title"] or row["canonical_url"] or row["url"]), ts, key),
            ).rowcount or 0)

        pdf_reclassified = conn.execute(
            """
            UPDATE crawl_queue SET resource_class=?,lane_priority=?,updated_at=?
            WHERE (lower(substr(url,1,instr(url||'?', '?')-1)) LIKE '%.pdf' OR lower(url) LIKE '%.pdf.external%')
              AND resource_class<>?
            """,
            (DOCUMENT, lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount
        documents_requeued = conn.execute(
            """
            UPDATE crawl_queue SET status='PENDING',priority=0,lane_priority=?,attempts=0,
                   lease_owner='',lease_expires_at='',not_before='',
                   last_error='Requeued by v6.8 browser-context PDF and product extraction',updated_at=?
            WHERE resource_class=? AND status<>'SKIPPED_PERMANENT'
            """,
            (lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount
        product_pages_requeued = conn.execute(
            """
            UPDATE crawl_queue SET status='PENDING',priority=1,lane_priority=?,attempts=0,
                   lease_owner='',lease_expires_at='',not_before='',
                   last_error='Requeued by v6.8 coherent product-card extraction',updated_at=?
            WHERE url IN (SELECT COALESCE(NULLIF(canonical_url,''),url) FROM sources
                          WHERE page_type IN ('Product','ProductCatalog','OfferCatalog'))
              AND status<>'SKIPPED_PERMANENT'
            """,
            (lane_priority(PAGE), ts),
        ).rowcount
        stale_runs = conn.execute("UPDATE crawl_runs SET status='INTERRUPTED',finished_at=? WHERE status='RUNNING'", (ts,)).rowcount
        conn.commit()

    replay = {"skipped": True}
    if not args.skip_source_replay:
        replay = replay_product_sources(store)

    projection = store.backfill_product_projection()
    completeness = store.product_completeness_report()

    # Queue every known incomplete product detail URL at high priority. Existing
    # completed data remains in the graph; the page is revisited only to fill gaps.
    detail_requeued = 0
    for item in completeness.get("incomplete_products") or []:
        url = str(item.get("product_url") or "")
        if not url or "/spd/" not in url.lower():
            continue
        detail_requeued += int(store.enqueue(
            url, depth=1, priority=1, parent_url=str(item.get("source_url") or ""),
            relation="HAS_PRODUCT_DETAIL", resource_class=PAGE,
        ))
        with store.connect() as conn:
            conn.execute(
                """
                UPDATE crawl_queue SET status='PENDING',priority=1,lane_priority=?,attempts=0,
                       lease_owner='',lease_expires_at='',not_before='',
                       last_error='Incomplete product fields; requeued by v6.8',updated_at=?
                WHERE url=? AND status<>'SKIPPED_PERMANENT'
                """,
                (lane_priority(PAGE), ts, url),
            )

    completeness = store.product_completeness_report()
    product_status_path = knowledge / "PRODUCT_COMPLETENESS_REPORT.json"
    product_status_path.write_text(json.dumps(completeness, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    report = {
        "migration": "v6.7 -> v6.8",
        "database": str(db), "knowledge": str(knowledge), "sqlite_integrity": integrity,
        "backup": backup, "active_leases_before_repair": active, "profile_lease": lease,
        "reset_in_progress": int(reset), "semantic_source_nodes_reclassified": semantic_reclassified,
        "pdf_rows_reclassified": int(pdf_reclassified or 0), "documents_requeued": int(documents_requeued or 0),
        "product_pages_requeued": int(product_pages_requeued or 0), "incomplete_product_detail_urls_requeued": detail_requeued,
        "stale_runs_closed": int(stale_runs or 0), "existing_source_product_replay": replay,
        "product_projection": projection, "product_completeness": completeness,
        "product_completeness_report": str(product_status_path), "stats": store.stats(),
        "v68_contract": {
            "coherent_product_cards": True,
            "catalog_price_facts_attached_to_product": True,
            "generic_endpoint_cannot_overwrite_product_type": True,
            "serialized_dom_excluded_from_regex_specs": True,
            "product_detail_pages_requeued_until_complete": True,
            "pdf_browser_context_pipeline_preserved": True,
        },
    }
    output = knowledge / "V68_REPAIR_REPORT.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
