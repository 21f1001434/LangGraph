# v6.10.1 repair hotfix

## Symptoms fixed

1. `Refusing to repair while 1 active worker lease(s) exist` even after the Streamlit application and crawler process had stopped.
2. `sqlite3.OperationalError: 13 values for 12 columns` from `repair_v610.py` during one-time source replay.

## Root causes

- The repair utility trusted only the future `lease_expires_at` timestamp. A stopped worker can leave an unexpired lease until its 15-minute lease window ends.
- The source replay `INSERT INTO crawl_queue` statement had one extra placeholder after `last_error`. The branch was reached only for a source already stored in `sources` but absent from `crawl_queue`.

## Corrections

- Runtime `crawler.pid` and `worker.pid` markers are checked against live OS processes. Stale markers are removed.
- The persistent-browser profile lease is checked and stale ownership is removed.
- When an unexpired database lease exists but no real crawler/browser owner exists, it is classified as abandoned and reset to `PENDING`.
- A real live crawler still blocks repair unless `--force-active` is intentionally used.
- The replay insert now supplies exactly 12 values for 12 columns.
- Regression tests cover both the missing-queue-row replay branch and orphaned unexpired lease recovery.

## Command

```powershell
python .\repair_v610.py --db knowledge\dell_en_uk.db --knowledge knowledge
python -m streamlit run .\app.py
```

Existing completed sources, product evidence, PDFs, screenshots, graph records, and queue history are preserved.
