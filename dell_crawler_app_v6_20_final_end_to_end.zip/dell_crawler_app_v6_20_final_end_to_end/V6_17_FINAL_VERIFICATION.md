# Dell.com Autonomous Knowledge Crawler v6.17 — Final Verified Release

v6.17 is the final hardening pass on the v6.16 compact semantic crawler.

## Additional v6.17 safeguards

- Rejects hallucinated/unresolved **local** relationship endpoints during extraction validation. The raw relation is preserved in `unmapped_evidence` instead of being counted as a valid graph relationship.
- Keeps explicit persisted graph node keys (`type:value`) eligible for DB-level resolution, so legitimate cross-page relationships are not silently discarded.
- Adds `release_verify_v617.py` for reproducible local verification of Python compatibility, imports, compilation, tests, SQLite integrity/semantic quality and package manifest hashes.
- Adds `upgrade_v617.ps1` / `upgrade_v617.bat` to perform repair, strict knowledge audit, release verification and then start Streamlit.

All v6.16 protections remain in place: canonical frontier URL identity, exact rendered-content dedupe, bounded product revisits, product identity repair, compact semantic ontology, evidence preservation, complete masthead discovery, read-only Dell SSO account crawling, PDF/document recovery and Dell AIA text/vision extraction.

## Existing database

Gracefully stop the crawler first. If the active project/database is inside OneDrive, pause OneDrive synchronization while SQLite is being repaired/crawled.

```powershell
python .\repair_v617.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v617.py --db knowledge\dell_en_uk.db --require-clean
python .\release_verify_v617.py --db knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

Or:

```powershell
.\upgrade_v617.ps1
```

## Fresh install

```powershell
.\setup.ps1
.\run_app.ps1
```

Configure `.env` before enabling Dell AIA. `DELL_LOGIN_EMAIL` is used only for the deterministic Dell email → Login/Continue → SSO handoff. Passwords, OTPs and payment/account mutation flows are not automated.
