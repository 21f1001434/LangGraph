from __future__ import annotations

import argparse
import json
from pathlib import Path

from dell_crawler_core.db_hygiene import database_hygiene_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def build_report(db: Path) -> dict:
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]
    return {
        "release": "v6.20",
        "semantic_quality": store.semantic_quality_report(),
        "extractor_quality": store.extractor_quality_report(),
        "product_completeness": store.product_completeness_report(),
        "product_enrichment": store.product_enrichment_status_report(),
        "canonical_schema": store.canonical_schema_report(),
        "database_hygiene": database_hygiene_report(store),
        "database_stats": store.stats(),
        "integrity_check": integrity,
        "foreign_key_violations": fk,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit Dell crawler v6.20 semantic quality + database hygiene.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--output", default="")
    parser.add_argument("--require-clean", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if args.output:
        Path(args.output).expanduser().write_text(text, encoding="utf-8")
    if args.require_clean:
        quality = report["semantic_quality"]
        hygiene = report["database_hygiene"]
        ephem = sum(int(v) for v in hygiene.get("ephemeral_runtime_rows", {}).values())
        dirty = any(int(hygiene.get(k, 0)) for k in (
            "orphan_semantic_aliases", "orphan_product_identity_aliases",
            "orphan_product_enrichment_rows", "orphan_validation_rows", "dead_empty_sources",
            "irrelevant_skipped_queue_rows",
        ))
        if (
            not bool(quality.get("clean_for_semantic_sync"))
            or report["integrity_check"].casefold() != "ok"
            or report["foreign_key_violations"]
            or ephem != 0
            or dirty
        ):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
