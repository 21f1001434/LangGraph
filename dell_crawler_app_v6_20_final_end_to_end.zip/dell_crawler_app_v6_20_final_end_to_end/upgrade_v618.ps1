param(
  [string]$Python = "python",
  [string]$Db = "knowledge\dell_en_uk.db",
  [string]$Knowledge = "knowledge"
)
$ErrorActionPreference = "Stop"
Write-Host "Dell Crawler v6.18 classified + consolidated semantic upgrade" -ForegroundColor Cyan
Write-Host "Use Graceful Stop first. Pause OneDrive sync while SQLite is being repaired/crawled." -ForegroundColor Yellow
& $Python .\repair_v618.py --db $Db --knowledge $Knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\audit_knowledge_v618.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\release_verify_v618.py --db $Db
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python -m streamlit run .\app.py
