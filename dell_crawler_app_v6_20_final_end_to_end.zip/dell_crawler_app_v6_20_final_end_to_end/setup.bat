@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.11+ was not found on PATH. & exit /b 1)
where node >nul 2>nul || (echo Node.js 20+ was not found on PATH. & exit /b 1)
if not exist .venv python -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if not exist .env copy .env.example .env >nul
echo Setup complete. If MCP says its browser is missing, run install_mcp_browser.bat once. Use resume_v610.bat for an existing crawl or run_app.bat for a fresh UI.
