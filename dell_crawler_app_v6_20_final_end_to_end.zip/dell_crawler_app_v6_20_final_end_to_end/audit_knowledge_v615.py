from __future__ import annotations
import argparse, json
from pathlib import Path
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph

parser = argparse.ArgumentParser()
parser.add_argument("--db", default="knowledge/dell_en_uk.db")
args = parser.parse_args()
db = Path(args.db)
if not db.exists():
    raise SystemExit(f"Database not found: {db}")
store = SQLiteKnowledgeGraph(db)
print(json.dumps({
    "canonical_schema": store.canonical_schema_report(),
    "extractor_quality": store.extractor_quality_report(),
    "product_completion": store.product_enrichment_status_report(),
}, indent=2, ensure_ascii=False, default=str))
