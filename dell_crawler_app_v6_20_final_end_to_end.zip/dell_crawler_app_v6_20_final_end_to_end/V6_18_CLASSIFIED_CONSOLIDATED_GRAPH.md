# Dell Crawler v6.18 — Classified + Consolidated Semantic Graph

v6.18 hardens graph quality before Neo4j export.

## Guarantees

- Every admitted graph node belongs to the bounded canonical ontology.
- Generic/unknown model objects are promoted only when deterministic evidence supports a class; otherwise they stay in extraction evidence.
- Schema fragments, arbitrary attributes, sections and visual/CDN objects do not become semantic graph nodes.
- Stable identities converge repeated Brand, Category, ProductFamily, Organization, Market, Service, Software, Solution, Workload, UseCase, FAQ, Offer and Review observations across pages.
- Product identity remains stricter: order code -> part number -> exact Dell PDP -> model fallback only when identity-poor.
- Historical duplicate nodes are merged with facts/relationships rewired to the canonical node.
- Old alias keys are retained in `semantic_entity_aliases` for auditability.
- Self-loops and duplicate relationships created by historical scattered nodes are removed during repair.
- Raw evidence, chunks and source records are preserved.

## Upgrade

```powershell
python .\repair_v618.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v618.py --db knowledge\dell_en_uk.db --require-clean
python .\release_verify_v618.py --db knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

A clean database reports:

- `unclassified_semantic_nodes = 0`
- `duplicate_semantic_identity_pairs = 0`
- `duplicate_product_identity_pairs = 0`
- `node_classification_coverage = 1.0`
- `clean_for_semantic_sync = true`
