$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Virtual environment not found. Running setup first..."
    & .\setup.ps1
}
& .\.venv\Scripts\python.exe -m streamlit run app.py
