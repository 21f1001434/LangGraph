from __future__ import annotations

import argparse
import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dell_crawler_core.crawl_models import CrawlPage
from dell_crawler_core.frontier_scheduler import PAGE, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.product_intelligence import (
    adaptive_product_completeness,
    extract_product_records,
    extraction_payload_for_products,
    is_media_asset_url,
    is_product_detail_url,
    valid_product_name,
)
from repair_v610 import (
    clear_stale_profile_lease,
    count_unexpired_worker_leases,
    inspect_runtime_processes,
    sqlite_backup,
)


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def slug(value: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "-", str(value or "").casefold()).strip("-")
    return clean[:220] or "unknown"


def loads(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value) if value else default
    except Exception:
        return default


def first(attrs: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = attrs.get(key)
        if value not in (None, "", [], {}):
            return re.sub(r"\s+", " ", str(value)).strip()
    return ""


def canonical_product_key(name: str, attrs: dict[str, Any], source_url: str = "") -> str:
    order = first(attrs, "order_code", "orderCode", "sku")
    part = first(attrs, "part_number", "partNumber", "mpn")
    model = first(attrs, "model")
    product_url = first(attrs, "product_url", "productUrl", "url")
    if not is_product_detail_url(product_url, source_url):
        product_url = source_url if is_product_detail_url(source_url) else ""
    if order:
        return f"product-order:{slug(order)}"
    if part:
        return f"product-part:{slug(part)}"
    if product_url:
        return f"url:{product_url}"
    if model:
        return f"product-model:{slug((first(attrs, 'brand') or 'Dell') + '-' + model)}"
    return f"product:{slug(name)}"


def reconstruct_and_replay_products(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    """Re-run deterministic product extraction over already-stored source evidence."""
    counters = {"sources_replayed": 0, "records_recovered": 0, "sources_with_products": 0}
    with store.connect() as conn:
        rows = conn.execute(
            """
            SELECT url,canonical_url,title,page_type,content_hash,http_status,metadata_json
            FROM sources
            WHERE page_type IN ('Product','ProductCatalog','OfferCatalog')
               OR metadata_json LIKE '%productCards%'
            ORDER BY fetched_at ASC
            """
        ).fetchall()
    for row in rows:
        source_url = str(row["canonical_url"] or row["url"] or "")
        if not source_url:
            continue
        with store.connect() as conn:
            chunks = conn.execute(
                "SELECT text FROM chunks WHERE source_url IN (?,?) ORDER BY chunk_index ASC",
                (str(row["url"] or ""), source_url),
            ).fetchall()
        visible_text = "\n\n".join(str(item["text"] or "") for item in chunks)
        metadata = loads(str(row["metadata_json"] or "{}"), {})
        page = CrawlPage(
            url=str(row["url"] or source_url),
            canonical_url=source_url,
            title=str(row["title"] or source_url),
            page_type=str(row["page_type"] or "WebPage"),
            snapshot="",
            visible_text=visible_text,
            http_status=row["http_status"],
            content_hash=str(row["content_hash"] or ""),
            metadata=metadata if isinstance(metadata, dict) else {},
        )
        records = extract_product_records(page)
        counters["sources_replayed"] += 1
        if not records:
            continue
        counters["sources_with_products"] += 1
        counters["records_recovered"] += len(records)
        store.upsert_node(f"url:{source_url}", page.page_type, page.title or source_url, {"url": source_url})
        store.ingest_extraction(source_url, extraction_payload_for_products(page, records))
    return counters


def copy_product_provenance(store: SQLiteKnowledgeGraph, old_id: int, new_key: str) -> dict[str, int]:
    moved = {"facts_copied": 0, "edges_copied": 0}
    with store.connect() as conn:
        facts = conn.execute(
            "SELECT predicate,value,unit,qualifiers_json,source_url,confidence,valid_from,valid_to FROM facts WHERE subject_id=?",
            (old_id,),
        ).fetchall()
        incoming = conn.execute(
            """
            SELECT s.node_key AS other_key,e.predicate,e.attributes_json,e.source_url,e.confidence
            FROM edges e JOIN nodes s ON s.id=e.source_id WHERE e.target_id=?
            """,
            (old_id,),
        ).fetchall()
        outgoing = conn.execute(
            """
            SELECT t.node_key AS other_key,e.predicate,e.attributes_json,e.source_url,e.confidence
            FROM edges e JOIN nodes t ON t.id=e.target_id WHERE e.source_id=?
            """,
            (old_id,),
        ).fetchall()
    for row in facts:
        moved["facts_copied"] += int(store.add_fact(
            new_key, str(row["predicate"]), str(row["value"]), str(row["source_url"] or ""),
            str(row["unit"] or ""), loads(str(row["qualifiers_json"] or "{}"), {}),
            float(row["confidence"] or 0.8), str(row["valid_from"] or ""), str(row["valid_to"] or ""),
        ))
    for row in incoming:
        other = str(row["other_key"] or "")
        if other and other != new_key and store.node_by_key(other):
            moved["edges_copied"] += int(store.upsert_edge(
                other, str(row["predicate"] or "RELATED_TO"), new_key,
                str(row["source_url"] or ""), loads(str(row["attributes_json"] or "{}"), {}), float(row["confidence"] or 0.8),
            ))
    for row in outgoing:
        other = str(row["other_key"] or "")
        if other and other != new_key and store.node_by_key(other):
            moved["edges_copied"] += int(store.upsert_edge(
                new_key, str(row["predicate"] or "RELATED_TO"), other,
                str(row["source_url"] or ""), loads(str(row["attributes_json"] or "{}"), {}), float(row["confidence"] or 0.8),
            ))
    return moved


def repair_contaminated_products(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    """Recover Product nodes whose node key/url is actually a media asset."""
    result = {
        "contaminated_found": 0,
        "products_recovered_to_stable_identity": 0,
        "media_nodes_quarantined": 0,
        "facts_copied": 0,
        "edges_copied": 0,
    }
    with store.connect() as conn:
        rows = conn.execute("SELECT id,node_key,name,attributes_json FROM nodes WHERE node_type='Product'").fetchall()
    for row in rows:
        attrs = loads(str(row["attributes_json"] or "{}"), {})
        if not isinstance(attrs, dict):
            attrs = {}
        node_key = str(row["node_key"] or "")
        node_url = node_key[4:] if node_key.startswith("url:") else ""
        attr_url = first(attrs, "product_url", "url")
        media_url = ""
        for candidate in (node_url, attr_url):
            if candidate and is_media_asset_url(candidate, first(attrs, "source_url")):
                media_url = candidate
                break
        if not media_url:
            continue
        result["contaminated_found"] += 1
        name = str(row["name"] or "").strip()
        source_url = first(attrs, "source_url")
        clean_attrs = dict(attrs)
        clean_attrs["image"] = first(clean_attrs, "image") or media_url
        clean_attrs["recovered_media_url"] = media_url
        for key in ("url", "product_url", "productUrl"):
            if is_media_asset_url(str(clean_attrs.get(key) or ""), source_url):
                clean_attrs.pop(key, None)
        strong = bool(
            first(clean_attrs, "order_code", "orderCode", "sku", "part_number", "partNumber", "mpn", "model")
            or any(first(clean_attrs, key) for key in (
                "price", "current_price", "list_price", "processor", "cpu", "graphics", "gpu",
                "memory", "storage", "display", "operating_system", "os",
            ))
        )
        can_recover = strong or valid_product_name(name, structured=True)
        if can_recover:
            target_key = canonical_product_key(name, clean_attrs, source_url)
            if target_key != node_key:
                store.upsert_node(target_key, "Product", name or target_key, {**clean_attrs, "recovered_from_media_product_key": node_key})
                copied = copy_product_provenance(store, int(row["id"]), target_key)
                result["facts_copied"] += copied["facts_copied"]
                result["edges_copied"] += copied["edges_copied"]
                store.refresh_product_projection(target_key)
                result["products_recovered_to_stable_identity"] += 1

        quarantine_attrs = dict(attrs)
        quarantine_attrs["url"] = media_url
        quarantine_attrs["image"] = media_url
        quarantine_attrs["quarantined_from_product"] = True
        quarantine_attrs["quarantine_reason"] = "media_url_used_as_product_identity"
        quarantine_attrs["quarantined_at"] = now()
        with store.connect() as conn:
            conn.execute(
                "UPDATE nodes SET node_type='VisualAsset',attributes_json=?,last_seen=? WHERE id=?",
                (json.dumps(quarantine_attrs, ensure_ascii=False, sort_keys=True, default=str), now(), int(row["id"])),
            )
            # Refresh FTS when the optional table exists.
            try:
                conn.execute("DELETE FROM nodes_fts WHERE node_key=?", (node_key,))
                conn.execute(
                    "INSERT INTO nodes_fts(name,node_type,attributes,node_key) VALUES(?,?,?,?)",
                    (name or node_key, "VisualAsset", json.dumps(quarantine_attrs, ensure_ascii=False, sort_keys=True, default=str), node_key),
                )
            except sqlite3.OperationalError:
                pass
        result["media_nodes_quarantined"] += 1
    return result


def product_quality_audit(store: SQLiteKnowledgeGraph) -> dict[str, Any]:
    with store.connect() as conn:
        rows = conn.execute("SELECT node_key,name,attributes_json FROM nodes WHERE node_type='Product'").fetchall()
    total = len(rows)
    field_counts = {key: 0 for key in ("model", "part_number", "order_code", "processor", "graphics", "memory", "storage", "display", "operating_system", "price")}
    contaminated = 0
    exact_urls = 0
    retail_ready = 0
    incomplete: list[dict[str, Any]] = []
    for row in rows:
        attrs = loads(str(row["attributes_json"] or "{}"), {})
        if not isinstance(attrs, dict):
            attrs = {}
        attrs.setdefault("product_name", str(row["name"] or ""))
        url = first(attrs, "product_url", "url")
        node_url = str(row["node_key"] or "")[4:] if str(row["node_key"] or "").startswith("url:") else ""
        if is_media_asset_url(url or node_url, first(attrs, "source_url")):
            contaminated += 1
        if is_product_detail_url(url):
            exact_urls += 1
        for key in field_counts:
            if key == "price":
                value = first(attrs, "price", "current_price")
            else:
                value = first(attrs, key)
            field_counts[key] += int(bool(value))
        score, missing, applicable = adaptive_product_completeness(attrs)
        if score >= 0.85 and is_product_detail_url(url) and bool(first(attrs, "price", "current_price")):
            retail_ready += 1
        elif len(incomplete) < 5000:
            incomplete.append({
                "node_key": str(row["node_key"] or ""), "name": str(row["name"] or ""),
                "score": score, "missing_fields": missing, "applicable_fields": applicable,
                "product_url": url, "source_url": first(attrs, "source_url"),
            })
    return {
        "generated_at": now(),
        "products": total,
        "media_contaminated_products": contaminated,
        "exact_dell_product_urls": exact_urls,
        "exact_dell_url_coverage_percent": round(100.0 * exact_urls / total, 2) if total else 0.0,
        "retail_ready_products": retail_ready,
        "field_counts": field_counts,
        "field_coverage_percent": {key: round(100.0 * count / total, 2) if total else 0.0 for key, count in field_counts.items()},
        "incomplete_products": sorted(incomplete, key=lambda item: (item["score"], item["name"]))[:5000],
    }


def requeue_incomplete_product_details(store: SQLiteKnowledgeGraph, audit: dict[str, Any]) -> int:
    queued = 0
    for item in audit.get("incomplete_products") or []:
        url = str(item.get("product_url") or "")
        if not is_product_detail_url(url):
            continue
        store.enqueue(
            url, depth=1, priority=1, parent_url=str(item.get("source_url") or ""),
            relation="PRODUCT_DETAIL_ENRICHMENT", force=True, resource_class=PAGE,
        )
        with store.connect() as conn:
            conn.execute(
                """
                UPDATE crawl_queue SET status='PENDING',priority=1,lane_priority=?,attempts=0,
                    lease_owner='',lease_expires_at='',not_before='',
                    last_error='v6.11 extractor-quality enrichment replay',updated_at=?
                WHERE url=? AND status<>'SKIPPED_PERMANENT'
                """,
                (lane_priority(PAGE), now(), url),
            )
        queued += 1
    return queued


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair media-contaminated Product nodes and recover Dell product detail enrichment for v6.11.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true")
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent

    runtime_state = inspect_runtime_processes(root)
    lease = clear_stale_profile_lease(root)
    active_leases = count_unexpired_worker_leases(db)
    live_pids = list(runtime_state.get("live_pids") or [])
    profile_pid = int(lease.get("owner_pid") or 0) if lease.get("status") == "live_owner" else 0
    if profile_pid and profile_pid not in live_pids:
        live_pids.append(profile_pid)
    if live_pids and not args.force_active:
        raise SystemExit(f"Refusing to repair while crawler/browser PID(s) {sorted(set(live_pids))} are alive. Use Graceful Stop first.")

    backup = ""
    if not args.no_backup:
        target = db.with_name(f"{db.stem}.pre_v611_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    store.reset_in_progress()
    before = product_quality_audit(store)
    replay = reconstruct_and_replay_products(store)
    contamination = repair_contaminated_products(store)
    projection = store.backfill_product_projection()
    after = product_quality_audit(store)
    requeued = requeue_incomplete_product_details(store, after)
    after = product_quality_audit(store)

    audit_path = knowledge / "EXTRACTOR_QUALITY_REPORT_V611.json"
    audit_path.write_text(json.dumps(after, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report = {
        "migration": "v6.10.1 -> v6.11 extractor-quality",
        "database": str(db),
        "backup": backup,
        "sqlite_integrity": integrity,
        "runtime_process_state": runtime_state,
        "profile_lease": lease,
        "unexpired_worker_leases_before_repair": active_leases,
        "before": before,
        "stored_source_product_replay": replay,
        "contamination_repair": contamination,
        "product_projection": projection,
        "product_detail_urls_requeued": requeued,
        "after": after,
        "quality_contract": {
            "media_urls_never_product_identity": True,
            "apd_spd_and_detail_routes_recognized": True,
            "product_detail_page_fallback_extraction": True,
            "stored_source_replay_without_data_loss": True,
            "contaminated_nodes_quarantined_not_deleted": True,
            "incomplete_exact_product_urls_requeued": True,
        },
    }
    report_path = knowledge / "V611_EXTRACTOR_REPAIR_REPORT.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nExtractor quality report: {audit_path}")
    print(f"Repair report: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
