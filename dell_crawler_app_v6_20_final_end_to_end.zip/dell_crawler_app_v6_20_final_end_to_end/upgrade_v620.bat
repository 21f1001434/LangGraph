@echo off
setlocal
set "PY=python"
set "DB=knowledge\dell_en_uk.db"
set "KNOWLEDGE=knowledge"
echo Dell Crawler v6.20 final upgrade + safe old DB cleanup
echo A pre_v620 backup is created before cleanup. Knowledge/evidence is preserved.
%PY% .\repair_v620.py --db "%DB%" --knowledge "%KNOWLEDGE%" --keep-crawl-runs 3 || exit /b 1
%PY% .\audit_knowledge_v620.py --db "%DB%" --require-clean || exit /b 1
%PY% .\release_verify_v620.py --db "%DB%" || exit /b 1
%PY% -m streamlit run .\app.py
