# v6.10 resilient extraction and adaptive validation

## Root causes corrected

### 1. Non-standard Dell AIA JSON

The model could return useful content with markdown fences, explanatory text, single quotes, trailing commas, comments, bare keys, a top-level list, or output truncated near the token limit. Earlier parsing accepted only a narrow strict-JSON form, so usable model evidence could fall back to an empty payload.

v6.10 adds:

- safe standard-library parsing and repair without code execution;
- JSON-mode request support with gateway fallback;
- one bounded text-model repair attempt when parsing still fails;
- normalization of old cached chunk payloads during replay;
- deterministic extraction retention even when model JSON is unrecoverable.

### 2. Payload shape mismatch

A model may use `product`, `products`, `links`, `specs`, a singleton object where a list is expected, or additional fields outside the requested schema.

v6.10 normalizes aliases and shapes, repairs structural relation references, and stores unsupported fields in `unmapped_evidence`. Evidence is not silently discarded merely because its field name differs from the requested template.

### 3. Uniform product validation

A single completeness template caused false gaps. Examples included requiring a display on a PowerEdge server, an operating system on a monitor, or reviews on a page that did not expose ratings.

v6.10 determines applicable fields from product category, identity, source text, advertised specifications and commerce/review evidence. Missing fields are reported only when applicable to that product/source.

### 4. Static archetype validation

Page archetypes describe sections that may exist across a family of Dell pages. They do not guarantee every section exists on every URL.

v6.10 distinguishes:

- **matched**: evidence captured;
- **exposed but missing**: the page showed a control/link/structured marker, so recovery is required;
- **not observed**: the section was not exposed on that URL and is informational only;
- **terminal**: access/security challenge, unusable response, corrupt content, or exhausted recovery.

## Migration

Run:

```powershell
python repair_v610.py --db knowledge\dell_en_uk.db --knowledge knowledge
```

The default one-time replay reprocesses stored public sources using the v6.10 normalization and validation rules. Use `--only-incomplete` for a smaller replay limited to unresolved pages and adaptively incomplete product details.

## Verification

```powershell
python -m compileall -q .
pytest -q
```

The package validation suite contains 114 passing tests.
