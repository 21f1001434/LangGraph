@echo off
setlocal
set "PY=python"
set "DB=knowledge\dell_en_uk.db"
set "KNOWLEDGE=knowledge"
echo Dell Crawler v6.18 classified + consolidated semantic upgrade
%PY% .\repair_v618.py --db "%DB%" --knowledge "%KNOWLEDGE%" || exit /b 1
%PY% .\audit_knowledge_v618.py --db "%DB%" --require-clean || exit /b 1
%PY% .\release_verify_v618.py --db "%DB%" || exit /b 1
%PY% -m streamlit run .\app.py
