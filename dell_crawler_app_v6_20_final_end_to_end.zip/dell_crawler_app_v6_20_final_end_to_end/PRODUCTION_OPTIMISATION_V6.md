# Production optimisation v6

## Goal

Turn the crawler from an exhaustive browser-action explorer into an **autonomous knowledge acquisition system** that remains deep while moving through Dell UK materially faster.

The design rule is:

> Exhaust information, not browser actions.

## Findings from the real five-day run

The supplied production database contained a substantial graph but still had a large unresolved frontier. The main inefficiencies were not a lack of extraction logic; they were scheduler and replay problems:

1. HTML pages, documents and image resources shared one queue priority model.
2. Hundreds of `i.dell.com` resized image variants occupied frontier work.
3. React ref changes and process restarts could cause successful one-shot actions to be attempted again.
4. terminal repeatable-control state existed in SQLite but was not used as a resume guard.
5. Dell AIA text extraction could be repeated for identical evidence after restart.
6. long Dell image URLs could produce fragile Windows/OneDrive filenames.
7. an HTTP 403 on a visual was treated primarily as a download failure instead of a change-of-acquisition-strategy signal.
8. Streamlit repeatedly attempted to Arrow-serialize heterogeneous `metadata` object columns.

## v6 execution model

### 1. Typed frontier

Every URL is classified before work:

- `SITEMAP`: XML discovery indexes
- `PAGE`: browser-rendered HTML
- `DOCUMENT`: PDF/Office/text documents
- `DATA`: public JSON/XML/CSV/captions
- `ASSET`: visual evidence
- `BINARY`: metadata-only binary resources

The browser is therefore reserved for work that needs a browser.

### 2. Fair lane interleaving

A single long-running worker follows a weighted lane pattern dominated by pages while still processing documents/data/assets. Sitemaps always win because they expand the frontier.

The pattern is intentionally conservative rather than launching many parallel browser contexts, because the crawler uses a persistent Dell regional/session profile and Playwright MCP browser state.

### 3. Visual-family dedupe

Dell Scene7/image-service URLs often differ only by width, height or output format. The source host/path becomes the family identity. Pending variants in one family are compacted and the best available resolution is retained.

No existing graph facts are deleted by this compaction; it affects redundant pending visual processing.

### 4. Durable semantic control identity

Playwright MCP refs are temporary. v6 combines role, label, nearby stable card/section context and action kind to identify a control across React rerenders.

Successful one-shot controls are stored in `control_progress`.

### 5. Historical action-memory migration

The v5 database already contained successful `action_trajectories`. `repair_v6.py` migrates successful terminal trajectories into the new completion memory. This allows an existing crawl to benefit from work it already performed.

### 6. Repeatable-control resume memory

`dynamic_control_progress` terminal states such as `CYCLE_EXHAUSTED`, `STABLE_EXHAUSTED`, `CONTROL_ABSENT`, `NAVIGATED` and `DIRECT_ENDPOINT` are consulted before a repeated widget is clicked again.

This is especially important for:

- `+ Show More Reviews`
- `Show More Reviews`
- `Load More`
- review pagination
- carousels
- next/previous slides

### 7. HTTP → browser visual recovery

Visual acquisition is:

```text
HTTP fetch with Dell page Referer
        |
   success? ---- yes ---> content-addressed asset -> vision
        |
        no (401/403)
        v
Playwright browser navigation/render
        |
 screenshot evidence
        |
 Dell AIA vision
```

The fallback is read-only and does not bypass authentication or access controls.

### 8. Evidence/model caches

- vision results are cached by content/model hash;
- v6 adds text extraction and hierarchical summary caches;
- resumed runs therefore spend model calls on new evidence rather than identical prior evidence.

### 9. Adaptive PDF vision

All available PDF text is parsed page-by-page. In `auto` mode, vision is applied to pages with raster images, substantial vector drawings/diagrams, or little extractable text. Use `vision_mode=all` when every PDF page must be rendered to the vision model.

### 10. Arrow-safe UI

All rich dashboard rows are normalized into display strings before Streamlit/PyArrow conversion. The SQLite representation remains rich JSON; only the UI copy is flattened.

## Existing production database migration result

Validation against a copy of the supplied database produced:

- SQLite integrity: `ok`
- existing frontier rows classified: 1,523
- duplicate pending visual variants skipped: 231
- historical successful one-shot control records imported: 1,024
- graph preserved: 9,400 nodes / 28,711 edges / 14,320 facts at that snapshot

The original user-supplied database was never modified by validation.

## Why the crawler remains deep

The optimisation does **not** remove these behaviours:

- recursive sitemap/link discovery
- accessibility + rendered DOM extraction
- Shadow DOM and same-origin iframe inspection
- structured JSON-LD/application evidence
- safe read-only dynamic controls
- repeated review/load-more exhaustion
- PDF/Office/document extraction
- Dell AIA text and vision enrichment
- ReAct/self-heal
- coverage contracts and incomplete-page requeue
- provenance and source URLs
- public Dell Community evidence when enabled

It removes duplicate acquisition work and schedules each evidence type through the appropriate mechanism.
