$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    throw "npx was not found. Install Node.js 20+ and reopen PowerShell."
}
Write-Host "Installing the Playwright MCP Chrome-for-Testing browser..."
& npx -y @playwright/mcp@0.0.78 install-browser chrome-for-testing
if ($LASTEXITCODE -ne 0) { throw "Playwright MCP browser installation failed with exit code $LASTEXITCODE." }
Write-Host "Browser installation complete. Return to the app and click Start / Resume."
