@echo off
setlocal
cd /d "%~dp0"
python .\repair_v614.py --db knowledge\dell_en_uk.db --knowledge knowledge || exit /b 1
python -m streamlit run .\app.py
