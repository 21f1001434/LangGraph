$ErrorActionPreference = "Stop"
$python = if (Test-Path ".\venv\Scripts\python.exe") { ".\venv\Scripts\python.exe" } elseif (Test-Path ".\.venv\Scripts\python.exe") { ".\.venv\Scripts\python.exe" } else { "python" }
Write-Host "Running v6.13 anti-repeat + full knowledge migration..."
& $python .\repair_v613.py --db knowledge\dell_en_uk.db --knowledge knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "v6.13 repair completed. Starting Streamlit..."
& $python -m streamlit run .\app.py
