from __future__ import annotations

import argparse
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from dell_crawler_core.document_pipeline import (
    normalize_pdf_download_url,
    quarantine_file,
    short_pdf_storage_path,
    validate_pdf_file,
)
from dell_crawler_core.frontier_scheduler import DOCUMENT, lane_priority
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sqlite_backup(source_path: Path, target_path: Path) -> None:
    source = sqlite3.connect(source_path, timeout=120)
    target = sqlite3.connect(target_path, timeout=120)
    try:
        source.execute("PRAGMA busy_timeout=120000")
        source.backup(target)
    finally:
        target.close()
        source.close()


def archive_legacy_pdf_failure_log(knowledge: Path) -> str:
    """Archive pre-v6.5 mixed transport/failure logs.

    Older versions wrote every recoverable direct HTTP 403 into
    PDF_FAILURES.jsonl even when browser recovery later succeeded. v6.5 keeps
    PDF_FAILURES terminal-only and moves the existing mixed log out of the way.
    """
    source = knowledge / "PDF_FAILURES.jsonl"
    if not source.is_file() or source.stat().st_size <= 0:
        return ""
    target = knowledge / f"PDF_FAILURES_PRE_V65_{stamp()}.jsonl"
    source.replace(target)
    return str(target)


def quarantine_invalid_documents(knowledge: Path) -> dict[str, object]:
    documents = knowledge / "documents"
    quarantine = knowledge / "document_quarantine"
    inspected = 0
    invalid = 0
    moved: list[dict[str, str]] = []
    if not documents.exists():
        return {"documents_directory": str(documents), "inspected": 0, "quarantined": 0, "files": []}

    for path in documents.rglob("*"):
        if not path.is_file() or not (
            path.name.lower().endswith(".pdf")
            or path.name.lower().endswith(".pdf.part")
        ):
            continue
        inspected += 1
        parse_structure = not path.name.lower().endswith(".part")
        validation = validate_pdf_file(path, parse_structure=parse_structure)
        if validation.ok:
            continue
        invalid += 1
        target = quarantine_file(path, quarantine, validation.reason)
        moved.append(
            {
                "source": str(path),
                "quarantine": str(target or ""),
                "reason": validation.reason,
            }
        )
    return {
        "documents_directory": str(documents),
        "inspected": inspected,
        "quarantined": invalid,
        "files": moved,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Prepare an existing Dell crawler database/evidence store for v6.5 "
            "verified browser-PDF text+vision recovery and truthful failure logging."
        )
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="", help="Knowledge directory; defaults to the database parent.")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--force-backup", action="store_true")
    parser.add_argument("--force-active", action="store_true", help="Proceed only when certain no worker is alive.")
    args = parser.parse_args()

    db = Path(args.db).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge = Path(args.knowledge).resolve() if args.knowledge else db.parent
    knowledge.mkdir(parents=True, exist_ok=True)

    probe = sqlite3.connect(db, timeout=30)
    try:
        columns = {str(row[1]) for row in probe.execute("PRAGMA table_info(crawl_queue)").fetchall()}
        active_leases = 0
        if {"status", "lease_expires_at"}.issubset(columns):
            active_leases = int(
                probe.execute(
                    """
                    SELECT COUNT(*) FROM crawl_queue
                     WHERE status='IN_PROGRESS'
                       AND lease_expires_at<>''
                       AND lease_expires_at>?
                    """,
                    (now(),),
                ).fetchone()[0]
                or 0
            )
    finally:
        probe.close()

    if active_leases and not args.force_active:
        raise SystemExit(
            f"Refusing to repair while {active_leases} unexpired worker lease(s) exist. "
            "Use Graceful Stop and wait for the worker to exit."
        )

    backup = ""
    existing_backups = sorted(db.parent.glob(f"{db.stem}.pre_v65_*{db.suffix}"))
    if not args.no_backup and (args.force_backup or not existing_backups):
        backup_path = db.with_name(f"{db.stem}.pre_v65_{stamp()}{db.suffix}")
        sqlite_backup(db, backup_path)
        backup = str(backup_path)
    elif existing_backups:
        backup = str(existing_backups[-1])

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity.lower() != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")

    reset = store.reset_in_progress()
    invalid_files = quarantine_invalid_documents(knowledge)
    archived_failure_log = archive_legacy_pdf_failure_log(knowledge)
    ts = now()

    with store.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        reclassified = conn.execute(
            """
            UPDATE crawl_queue
               SET resource_class=?, lane_priority=?, updated_at=?
             WHERE (
                    lower(substr(url,1,instr(url||'?', '?')-1)) LIKE '%.pdf'
                    OR lower(url) LIKE '%.pdf.external%'
                   )
               AND resource_class<>?
            """,
            (DOCUMENT, lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount

        requeued_documents = conn.execute(
            """
            UPDATE crawl_queue
               SET status='PENDING',
                   priority=0,
                   lane_priority=?,
                   attempts=0,
                   lease_owner='',
                   lease_expires_at='',
                   not_before='',
                   last_error='Requeued by v6.5 verified browser-PDF recovery',
                   updated_at=?
             WHERE resource_class=?
               AND status NOT IN ('SKIPPED_PERMANENT')
            """,
            (lane_priority(DOCUMENT), ts, DOCUMENT),
        ).rowcount

        stale_runs = conn.execute(
            """
            UPDATE crawl_runs
               SET status='INTERRUPTED', finished_at=?
             WHERE status='RUNNING'
            """,
            (ts,),
        ).rowcount

        rows = conn.execute(
            """
            SELECT url,status,attempts,parent_url
              FROM crawl_queue
             WHERE resource_class=?
             ORDER BY priority,url
            """,
            (DOCUMENT,),
        ).fetchall()
        conn.commit()

    aliases: list[dict[str, str]] = []
    projected_paths: list[dict[str, object]] = []
    for row in rows:
        url = str(row["url"])
        acquisition = normalize_pdf_download_url(url)
        path = short_pdf_storage_path(knowledge / "documents", acquisition)
        if acquisition != url:
            aliases.append({"queue_url": url, "download_url": acquisition})
        projected_paths.append(
            {
                "queue_url": url,
                "download_url": acquisition,
                "local_path": str(path),
                "partial_path": str(path.with_suffix(path.suffix + ".part")),
                "local_path_length": len(str(path.with_suffix(path.suffix + ".part"))),
            }
        )

    report = {
        "migration": "v6.4 -> v6.5",
        "database": str(db),
        "knowledge": str(knowledge),
        "sqlite_integrity": integrity,
        "backup": backup,
        "active_leases_before_repair": active_leases,
        "reset_in_progress": int(reset),
        "pdf_rows_reclassified_as_document": int(reclassified or 0),
        "documents_requeued_for_verified_processing": int(requeued_documents or 0),
        "stale_runs_closed": int(stale_runs or 0),
        "archived_legacy_pdf_failure_log": archived_failure_log,
        "pdf_external_aliases": aliases,
        "short_path_projection": projected_paths,
        "invalid_local_documents": invalid_files,
        "stats": store.stats(),
        "new_logs": {
            "recoverable_transport_events": str(knowledge / "PDF_TRANSPORT_EVENTS.jsonl"),
            "browser_recoveries": str(knowledge / "PDF_RECOVERIES.jsonl"),
            "completed_documents": str(knowledge / "PDF_SUCCESSES.jsonl"),
            "terminal_failures_only": str(knowledge / "PDF_FAILURES.jsonl"),
        },
    }
    out = knowledge / "V65_REPAIR_REPORT.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nRepair report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
