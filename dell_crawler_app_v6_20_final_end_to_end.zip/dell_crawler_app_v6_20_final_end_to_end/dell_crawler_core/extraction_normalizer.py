from __future__ import annotations

"""Loss-minimising normalisation for Dell AIA text and vision payloads.

Model output is treated as untrusted evidence. The normaliser accepts common shape
variations and preserves unsupported sections in ``unmapped_evidence`` instead of
silently discarding them. It does not invent product facts.
"""

import hashlib
import re
from typing import Any
from urllib.parse import urljoin

from .knowledge_ontology import canonical_node_type, canonical_relationship_type
from .product_intelligence import is_media_asset_url, is_product_detail_url


LIST_KEYS = (
    "entities",
    "relations",
    "facts",
    "use_cases",
    "offers",
    "endpoints",
    "reviews",
    "document_sections",
    "requirements",
    "compatibility",
    "faqs",
    "recommendations",
    "questions_answerable",
    "warnings",
    "normalization_notes",
    "unmapped_evidence",
)

KNOWN_KEYS = {
    "page",
    "chunk_summary",
    "summary",
    "document_summary",
    "vision_text",
    "vision_evidence",
    "chunk_count",
    "chunk_summaries",
    "product_records",
    "image_role",
    "visible_text",
    *LIST_KEYS,
}

ALIASES = {
    "entity": "entities",
    "relation": "relations",
    "fact": "facts",
    "use_case": "use_cases",
    "usecases": "use_cases",
    "offer": "offers",
    "link": "endpoints",
    "links": "endpoints",
    "resources": "endpoints",
    "documents": "endpoints",
    "endpoint": "endpoints",
    "review": "reviews",
    "section": "document_sections",
    "sections": "document_sections",
    "requirement": "requirements",
    "compatible": "compatibility",
    "faq": "faqs",
    "recommendation": "recommendations",
    "questions": "questions_answerable",
    "answerable_questions": "questions_answerable",
    "warning": "warnings",
    "notes": "normalization_notes",
}


def _clean(value: Any, limit: int = 30000) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _as_list(value: Any) -> list[Any]:
    if value in (None, "", [], {}):
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _confidence(value: Any, default: float = 0.7) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except Exception:
        return default


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().casefold() in {"1", "true", "yes", "y", "verified", "mandatory"}


def _source_url(item: dict[str, Any], source_url: str) -> str:
    raw = _clean(item.get("source_url") or item.get("source") or item.get("url"), 4000)
    if raw and source_url:
        return urljoin(source_url, raw)
    return raw or source_url


def _item_key(prefix: str, index: int, *parts: Any) -> str:
    basis = "|".join(_clean(part, 1000) for part in parts)
    digest = hashlib.sha256(basis.encode("utf-8", errors="ignore")).hexdigest()[:12]
    return f"{prefix}_{index}_{digest}"


def _normalise_entity(value: Any, index: int, source_url: str) -> dict[str, Any] | None:
    if isinstance(value, str):
        value = {"name": value}
    if not isinstance(value, dict):
        return None
    name = _clean(value.get("name") or value.get("title") or value.get("label") or value.get("value"), 1000)
    raw_entity_type = _clean(value.get("type") or value.get("entity_type") or value.get("category") or "Entity", 120)
    entity_type = canonical_node_type(raw_entity_type, context="entity")
    url = _source_url(value, source_url) if value.get("url") or value.get("source_url") else ""
    explicit_key = _clean(value.get("key") or value.get("id") or value.get("node_key"), 240)
    key = explicit_key
    attributes = _dict(value.get("attributes"))

    # Product identity hygiene: catalogue cards frequently expose an image/CDN URL
    # before the actual PDP anchor. Never let that media URL become the Product
    # identity. Preserve it as evidence and keep only exact Dell PDP URLs as the
    # canonical Product URL.
    is_product = entity_type == "Product"
    if is_product and url:
        if is_media_asset_url(url, source_url):
            attributes.setdefault("image_url", url)
            attributes.setdefault("recovered_media_url", url)
            url = ""
        elif is_product_detail_url(url, source_url):
            attributes.setdefault("product_url", url)
        else:
            attributes.setdefault("source_page_url", url)
            url = ""

    reserved = {"key", "id", "node_key", "type", "entity_type", "category", "name", "title", "label", "url", "source_url", "attributes"}
    extras = {k: v for k, v in value.items() if k not in reserved and v not in (None, "", [], {})}
    if extras:
        attributes = {**attributes, **extras}

    if not key:
        if is_product:
            key = _item_key(
                "product", index, entity_type, name,
                attributes.get("model"), attributes.get("part_number"),
                attributes.get("order_code"), attributes.get("product_url") or url,
            )
        else:
            key = _item_key("entity", index, entity_type, name, url)
    if raw_entity_type and raw_entity_type != entity_type:
        attributes.setdefault("raw_entity_type", raw_entity_type)
    if source_url:
        attributes.setdefault("source_url", source_url)
    if not name:
        name = key
        attributes.setdefault("unresolved_name", True)
    return {"key": key, "type": entity_type or "Entity", "name": name, "url": url, "attributes": attributes}


def _normalise_relation(value: Any, index: int) -> dict[str, Any] | None:
    if isinstance(value, str):
        value = {"predicate": "RELATED_TO", "target_key": value}
    if not isinstance(value, dict):
        return None
    source_key = _clean(value.get("source_key") or value.get("source") or value.get("from") or "page", 240)
    target_key = _clean(value.get("target_key") or value.get("target") or value.get("to"), 240)
    raw_predicate = _clean(value.get("predicate") or value.get("relation") or value.get("type") or "RELATED_TO", 160).upper().replace(" ", "_")
    predicate = canonical_relationship_type(raw_predicate)
    if not target_key:
        target_key = _item_key("unresolved_relation_target", index, predicate, value)
    return {
        "source_key": source_key or "page",
        "predicate": predicate or "RELATED_TO",
        "target_key": target_key,
        "attributes": {**_dict(value.get("attributes")), **({"raw_relationship_type": raw_predicate} if raw_predicate != predicate else {})},
        "confidence": _confidence(value.get("confidence")),
    }


def _normalise_fact(value: Any, index: int, source_url: str) -> dict[str, Any] | None:
    if isinstance(value, str):
        value = {"predicate": "OBSERVATION", "value": value}
    if not isinstance(value, dict):
        return None
    fact_value = value.get("value")
    if fact_value in (None, "", [], {}):
        fact_value = value.get("description") or value.get("text") or value.get("name")
    if fact_value in (None, "", [], {}):
        return None
    qualifiers = _dict(value.get("qualifiers"))
    if source_url:
        qualifiers.setdefault("source_url", source_url)
    return {
        "subject_key": _clean(value.get("subject_key") or value.get("subject") or "page", 240) or "page",
        "predicate": _clean(value.get("predicate") or value.get("field") or value.get("type") or "OBSERVATION", 160).upper().replace(" ", "_"),
        "value": fact_value if isinstance(fact_value, (dict, list)) else _clean(fact_value),
        "unit": _clean(value.get("unit"), 80),
        "qualifiers": qualifiers,
        "confidence": _confidence(value.get("confidence")),
        "valid_from": _clean(value.get("valid_from") or value.get("validFrom"), 100),
        "valid_to": _clean(value.get("valid_to") or value.get("validTo"), 100),
    }


def _normalise_named(value: Any, index: int, source_url: str, kind: str) -> dict[str, Any] | None:
    if isinstance(value, str):
        value = {"name": value}
    if not isinstance(value, dict):
        return None
    item = dict(value)
    name = _clean(item.get("name") or item.get("title") or item.get("label") or item.get("question") or item.get("recommendation"), 2000)
    if kind == "faqs":
        question = _clean(item.get("question") or item.get("name") or item.get("title"), 4000)
        answer = item.get("answer") or item.get("acceptedAnswer") or item.get("description") or item.get("text")
        if isinstance(answer, dict):
            answer = answer.get("text") or answer.get("answerText") or answer.get("description")
        return {"question": question, "answer": _clean(answer, 20000), "source_url": _source_url(item, source_url)} if question or answer else None
    if kind == "endpoints":
        url = _clean(item.get("url") or item.get("href") or item.get("link"), 4000)
        if url and source_url:
            url = urljoin(source_url, url)
        if not url:
            return None
        return {
            "key": _clean(item.get("key") or item.get("id"), 240) or _item_key("endpoint", index, url),
            "label": name or url,
            "url": url,
            "purpose": _clean(item.get("purpose") or item.get("description"), 4000),
            "action": _clean(item.get("action") or "open", 40),
            "resource_kind": _clean(item.get("resource_kind") or item.get("kind") or item.get("type"), 120),
            **{k: v for k, v in item.items() if k in {"relation", "priority", "source"}},
        }
    if kind == "reviews":
        body = _clean(item.get("body") or item.get("reviewBody") or item.get("description") or item.get("text"), 30000)
        title = _clean(item.get("title") or item.get("headline") or item.get("name"), 2000)
        rating_obj = _dict(item.get("reviewRating"))
        author_obj = item.get("author")
        if isinstance(author_obj, dict):
            author_obj = author_obj.get("name")
        rating = _clean(item.get("rating") or item.get("ratingValue") or rating_obj.get("ratingValue"), 40)
        review_id = _clean(item.get("review_id") or item.get("id"), 240)
        if not review_id:
            review_id = _item_key("review", index, source_url, title, body, rating)
        return {
            "review_id": review_id,
            "title": title,
            "rating": rating,
            "author": _clean(author_obj, 500),
            "date": _clean(item.get("date") or item.get("datePublished") or item.get("dateCreated"), 100),
            "body": body,
            "pros": [_clean(x, 2000) for x in _as_list(item.get("pros") or item.get("positiveNotes")) if _clean(x)],
            "cons": [_clean(x, 2000) for x in _as_list(item.get("cons") or item.get("negativeNotes")) if _clean(x)],
            "recommend": _clean(item.get("recommend") or item.get("recommendation"), 2000),
            "verified": _bool(item.get("verified")),
            "helpful_count": _clean(item.get("helpful_count") or item.get("helpfulCount"), 40),
            "source_url": _source_url(item, source_url),
            "opinion_topics": [_clean(x, 500) for x in _as_list(item.get("opinion_topics")) if _clean(x)],
        }
    item.setdefault("source_url", _source_url(item, source_url))
    if kind == "offers":
        item.setdefault("name", name or _clean(item.get("description") or "Dell offer", 2000))
        item["volatile"] = True if item.get("volatile") is None else _bool(item.get("volatile"))
    elif kind == "document_sections":
        item.setdefault("title", name or f"Document section {index + 1}")
    elif kind == "requirements":
        item.setdefault("name", name or _clean(item.get("description"), 2000) or f"Requirement {index + 1}")
        item["mandatory"] = _bool(item.get("mandatory"))
    elif kind == "compatibility":
        item.setdefault("subject", _clean(item.get("product") or item.get("name") or "page", 1000))
        item.setdefault("compatible_with", _clean(item.get("target") or item.get("value") or item.get("description"), 2000))
        item.setdefault("status", _clean(item.get("status") or "unknown", 80))
    elif kind == "recommendations":
        item.setdefault("recommendation", _clean(item.get("description") or item.get("text") or name, 10000))
        item.setdefault("audience", _clean(item.get("audience") or "", 1000))
    elif kind == "use_cases":
        item.setdefault("name", name or _clean(item.get("description"), 2000) or f"Use case {index + 1}")
    return item


def _map_product_aliases(payload: dict[str, Any], source_url: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    entities: list[dict[str, Any]] = []
    facts: list[dict[str, Any]] = []
    products = payload.get("products") or payload.get("product")
    for index, product in enumerate(_as_list(products)):
        if isinstance(product, str):
            product = {"name": product}
        if not isinstance(product, dict):
            continue
        entity = _normalise_entity({**product, "type": product.get("type") or "Product"}, index, source_url)
        if entity:
            entities.append(entity)
            key = entity["key"]
            for field, value in product.items():
                if field in {"key", "id", "name", "title", "type", "url", "source_url", "attributes"} or value in (None, "", [], {}):
                    continue
                facts.append(_normalise_fact({"subject_key": key, "predicate": field, "value": value, "confidence": 0.72}, len(facts), source_url))
    specs = payload.get("specifications") or payload.get("specs")
    if isinstance(specs, dict):
        for field, value in specs.items():
            fact = _normalise_fact({"subject_key": "page", "predicate": field, "value": value, "confidence": 0.72}, len(facts), source_url)
            if fact:
                facts.append(fact)
    return entities, [fact for fact in facts if fact]


def normalize_extraction_payload(payload: Any, *, source_url: str = "", evidence_kind: str = "text") -> dict[str, Any]:
    if isinstance(payload, list):
        payload = {"entities": payload}
    if not isinstance(payload, dict):
        payload = {"warnings": [f"{evidence_kind} extraction returned a non-object payload."], "unmapped_evidence": [payload]}
    working = dict(payload)
    for old, new in ALIASES.items():
        if old in working and new not in working:
            working[new] = working.pop(old)
        elif old in working:
            working[new] = [*_as_list(working.get(new)), *_as_list(working.pop(old))]

    result: dict[str, Any] = {
        "page": working.get("page") if isinstance(working.get("page"), dict) else {},
        "chunk_summary": _clean(working.get("chunk_summary") or working.get("summary"), 30000),
        "summary": _clean(working.get("summary") or working.get("chunk_summary"), 30000),
        "entities": [],
        "relations": [],
        "facts": [],
        "use_cases": [],
        "offers": [],
        "endpoints": [],
        "reviews": [],
        "document_sections": [],
        "requirements": [],
        "compatibility": [],
        "faqs": [],
        "recommendations": [],
        "questions_answerable": [],
        "warnings": [],
        "normalization_notes": [],
        "unmapped_evidence": [],
    }
    if isinstance(working.get("page"), str):
        result["page"] = {"summary": _clean(working["page"], 30000)}
    if source_url:
        result["page"].setdefault("url", source_url)

    alias_entities, alias_facts = _map_product_aliases(working, source_url)
    result["entities"].extend(alias_entities)
    result["facts"].extend(alias_facts)

    converters = {
        "entities": lambda value, index: _normalise_entity(value, index, source_url),
        "relations": lambda value, index: _normalise_relation(value, index),
        "facts": lambda value, index: _normalise_fact(value, index, source_url),
        "use_cases": lambda value, index: _normalise_named(value, index, source_url, "use_cases"),
        "offers": lambda value, index: _normalise_named(value, index, source_url, "offers"),
        "endpoints": lambda value, index: _normalise_named(value, index, source_url, "endpoints"),
        "reviews": lambda value, index: _normalise_named(value, index, source_url, "reviews"),
        "document_sections": lambda value, index: _normalise_named(value, index, source_url, "document_sections"),
        "requirements": lambda value, index: _normalise_named(value, index, source_url, "requirements"),
        "compatibility": lambda value, index: _normalise_named(value, index, source_url, "compatibility"),
        "faqs": lambda value, index: _normalise_named(value, index, source_url, "faqs"),
        "recommendations": lambda value, index: _normalise_named(value, index, source_url, "recommendations"),
    }
    for key, converter in converters.items():
        for index, value in enumerate(_as_list(working.get(key))):
            item = converter(value, index)
            if item is not None:
                result[key].append(item)

    for key in ("questions_answerable", "warnings", "normalization_notes"):
        for value in _as_list(working.get(key)):
            text = _clean(value, 10000)
            if text:
                result[key].append(text)
    existing_notes = working.get("_normalization_notes")
    for value in _as_list(existing_notes):
        text = _clean(value, 10000)
        if text:
            result["normalization_notes"].append(text)

    passthrough = ("document_summary", "vision_text", "vision_evidence", "chunk_count", "chunk_summaries", "product_records", "image_role", "visible_text")
    for key in passthrough:
        if working.get(key) not in (None, "", [], {}):
            result[key] = working[key]

    ignored_aliases = {"products", "product", "specifications", "specs", "_normalization_notes"}
    for key, value in working.items():
        if key in KNOWN_KEYS or key in ignored_aliases or value in (None, "", [], {}):
            continue
        result["unmapped_evidence"].append({"field": key, "value": value, "evidence_kind": evidence_kind})
    if result["unmapped_evidence"]:
        result["normalization_notes"].append(
            f"Preserved {len(result['unmapped_evidence'])} unsupported field(s) as unmapped evidence instead of discarding them."
        )

    # Do not turn unresolved relation references into graph nodes.  Older builds
    # created one placeholder node for every model-generated reference, which caused
    # schema/node explosion. Preserve the evidence for audit and ingest only fully
    # resolved relationships.
    known_entity_keys = {str(item.get("key") or "") for item in result["entities"]}
    resolved_relations: list[dict[str, Any]] = []
    for relation in result["relations"]:
        unresolved: list[str] = []
        for ref_name in ("source_key", "target_key"):
            ref = str(relation.get(ref_name) or "")
            if ref and ref not in {"page", "source", "primary_subject"} and ref not in known_entity_keys and ":" not in ref:
                unresolved.append(ref)
        if unresolved:
            result["unmapped_evidence"].append({
                "field": "unresolved_relation",
                "value": relation,
                "reason": "relation_reference_not_emitted_as_entity",
                "unresolved_refs": unresolved,
                "evidence_kind": evidence_kind,
            })
            continue
        resolved_relations.append(relation)
    result["relations"] = resolved_relations

    for key in LIST_KEYS:
        if key in result:
            unique: list[Any] = []
            seen: set[str] = set()
            for item in result[key]:
                marker = repr(item)
                if marker in seen:
                    continue
                seen.add(marker)
                unique.append(item)
            result[key] = unique
    return result
