from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None  # type: ignore


@dataclass(slots=True)
class BrowserPDFViewerCapture:
    source_url: str
    final_url: str = ""
    title: str = ""
    page_count: int = 0
    pages_observed: list[int] = field(default_factory=list)
    text_blocks: list[str] = field(default_factory=list)
    visual_evidence: list[dict[str, Any]] = field(default_factory=list)
    screenshot_count: int = 0
    text_chars: int = 0
    warnings: list[str] = field(default_factory=list)
    manifest_path: str = ""
    extraction_mode: str = "playwright_pdf_viewer_text_vision"

    @property
    def usable(self) -> bool:
        return bool(self.text_blocks or self.visual_evidence)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["usable"] = self.usable
        return payload


def decode_mcp_text(detail: str) -> str:
    """Decode scalar text from current and legacy Playwright MCP wrappers."""
    raw = str(detail or "").strip()
    if not raw:
        return ""

    candidates: list[str] = [raw]
    for line in reversed(raw.splitlines()):
        value = line.strip()
        if not value or value.startswith("###") or value.startswith("```"):
            continue
        candidates.append(value)
        break

    for candidate in candidates:
        value: Any = candidate
        for _ in range(3):
            if isinstance(value, str):
                try:
                    decoded = json.loads(value)
                except Exception:
                    break
                value = decoded
                continue
            break
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False, default=str)
    return raw


def clean_accessibility_text(value: str, max_chars: int = 60000) -> str:
    """Convert an MCP accessibility snapshot into compact evidence text."""
    lines: list[str] = []
    seen: set[str] = set()
    for raw_line in str(value or "").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("###") or line.startswith("```"):
            continue
        line = re.sub(r"\s*\[ref=[^\]]+\]", "", line)
        line = re.sub(r"\s*\[box=[^\]]+\]", "", line)
        line = re.sub(r"^\s*[-*]\s*", "", line)
        line = re.sub(r"\s+", " ", line).strip()
        if not line or line in seen:
            continue
        seen.add(line)
        lines.append(line)
        if sum(len(item) + 1 for item in lines) >= max_chars:
            break
    return "\n".join(lines)[:max_chars]


_PAGE_PATTERNS = (
    re.compile(r"\bpage\s*(\d{1,6})\s*(?:of|/)\s*(\d{1,6})\b", re.I),
    re.compile(r"\b(\d{1,6})\s*(?:of|/)\s*(\d{1,6})\s*pages?\b", re.I),
    re.compile(r'"pageNumber"\s*:\s*(\d{1,6}).{0,80}?"(?:docLength|pageCount)"\s*:\s*(\d{1,6})', re.I | re.S),
)


def parse_pdf_page_position(text: str) -> tuple[int, int]:
    value = str(text or "")
    for pattern in _PAGE_PATTERNS:
        match = pattern.search(value)
        if not match:
            continue
        current, total = int(match.group(1)), int(match.group(2))
        if 0 < current <= max(total, current) and total > 0:
            return current, total
    return 0, 0


def perceptual_image_signature(path: str | Path) -> str:
    """Return a stable low-cost signature that ignores most toolbar animation."""
    image_path = Path(path)
    if Image is None:
        return hashlib.sha256(image_path.read_bytes()).hexdigest()
    with Image.open(image_path) as image:
        image = image.convert("L")
        width, height = image.size
        top = max(0, int(height * 0.14))
        bottom = max(top + 1, int(height * 0.98))
        # Crop the animated toolbar, normalise dimensions, then hash the pixels.
        # This is stable for the same rendered page while retaining enough detail
        # to distinguish pages that differ mainly in text or a small diagram.
        image = image.crop((0, top, width, bottom)).resize((96, 96))
        payload = image.tobytes()
    return hashlib.sha256(payload).hexdigest()


def dedupe_visual_evidence(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in items:
        marker = str(item.get("content_hash") or item.get("path") or "")
        if not marker or marker in seen:
            continue
        seen.add(marker)
        output.append(item)
    return output


def dedupe_text_blocks(values: list[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        clean = re.sub(r"\s+", " ", str(value or "")).strip()
        if not clean:
            continue
        marker = hashlib.sha256(clean.encode("utf-8", errors="ignore")).hexdigest()
        if marker in seen:
            continue
        seen.add(marker)
        output.append(str(value).strip())
    return output
