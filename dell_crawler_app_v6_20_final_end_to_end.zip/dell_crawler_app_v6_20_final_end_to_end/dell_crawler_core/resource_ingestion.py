from __future__ import annotations

"""Safe extraction helpers for public Dell resources beyond HTML and PDF.

The crawler never executes downloaded files.  It extracts text/metadata from common
public knowledge formats and records unsupported/binary assets as provenance nodes.
"""

import csv
import hashlib
import io
import json
import mimetypes
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from bs4 import BeautifulSoup


TEXT_EXTENSIONS = {".txt", ".md", ".rst", ".log", ".csv", ".tsv", ".json", ".xml", ".yaml", ".yml", ".vtt", ".srt", ".ttml"}
OFFICE_EXTENSIONS = {".docx", ".pptx", ".xlsx", ".xlsm"}
ARCHIVE_OR_BINARY_EXTENSIONS = {
    ".zip", ".7z", ".rar", ".exe", ".msi", ".cab", ".iso", ".dmg", ".pkg", ".bin", ".img",
    ".rom", ".fw", ".deb", ".rpm", ".jar", ".war", ".tar", ".gz", ".bz2", ".xz",
}
CAPTION_EXTENSIONS = {".vtt", ".srt", ".ttml"}
PUBLIC_DATA_EXTENSIONS = {".json", ".xml", ".csv", ".tsv", ".txt", ".vtt", ".srt", ".ttml"}

SENSITIVE_QUERY_KEYS = {
    "token", "access_token", "auth", "authorization", "session", "sessionid", "sid", "jwt", "code",
    "password", "passwd", "secret", "client_secret", "email", "phone", "customerid", "userid", "user_id",
    "accountid", "account_id", "orderid", "order_id", "cartid", "cart_id", "service_tag", "servicetag",
}

PUBLIC_API_ALLOW_RE = re.compile(
    r"(?:review|rating|product|catalog|offer|deal|price|spec|configuration|content|resource|document|manual|"
    r"support|knowledge|article|faq|search|recommend|compatib|warranty|service|accessor|video|transcript|caption|graphql)",
    re.I,
)
PUBLIC_API_BLOCK_RE = re.compile(
    r"(?:analytics|telemetry|tracking|pixel|beacon|adservice|doubleclick|facebook|segment|akamai|rum|auth|oauth|"
    r"login|signin|account|profile|order|checkout|payment|cart|basket|address|contact|feedback|survey|chat|session)",
    re.I,
)


@dataclass(slots=True)
class ExtractedResource:
    title: str
    text: str
    mime_type: str
    kind: str
    metadata: dict[str, Any] = field(default_factory=dict)
    embedded_urls: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def extension_for_url(url: str) -> str:
    return Path(urlparse(url).path).suffix.lower()


def is_supported_document_url(url: str) -> bool:
    return extension_for_url(url) in (TEXT_EXTENSIONS | OFFICE_EXTENSIONS)


def is_caption_url(url: str) -> bool:
    return extension_for_url(url) in CAPTION_EXTENSIONS


def is_binary_asset_url(url: str) -> bool:
    return extension_for_url(url) in ARCHIVE_OR_BINARY_EXTENSIONS


def is_public_data_url(url: str) -> bool:
    ext = extension_for_url(url)
    parsed = urlparse(url)
    path = parsed.path.lower()
    if ext in PUBLIC_DATA_EXTENSIONS:
        return True
    api_shaped = bool(
        re.search(r"(?:^|/)(?:api|graphql|services?|data|feeds?|ajax)(?:/|$)", path, re.I)
        or re.search(r"/(?:content|search|product|review|rating|offer|catalog)/api(?:/|$)", path, re.I)
        or re.search(r"(?:^|[?&])(?:format|output|responseType)=(?:json|xml|csv)", parsed.query, re.I)
    )
    return bool(api_shaped and PUBLIC_API_ALLOW_RE.search(url) and not PUBLIC_API_BLOCK_RE.search(url))


def sanitize_public_api_url(url: str) -> str:
    """Remove sensitive query keys before storing/fetching a public endpoint."""
    parsed = urlparse(url)
    if PUBLIC_API_BLOCK_RE.search(parsed.path):
        return ""
    clean_query: list[tuple[str, str]] = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=False):
        if key.lower() in SENSITIVE_QUERY_KEYS:
            continue
        clean_query.append((key, value))
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", urlencode(clean_query, doseq=True), ""))


def public_get_candidates(detail: str) -> list[str]:
    """Extract likely read-only GET endpoints from Playwright MCP network output."""
    candidates: list[str] = []
    seen: set[str] = set()
    for line in (detail or "").splitlines():
        if not re.search(r"\bGET\b", line, re.I):
            continue
        for match in re.findall(r"https?://[^\s)\]>\"']+", line):
            candidate = sanitize_public_api_url(match.rstrip(".,;:"))
            if not candidate or candidate in seen:
                continue
            if PUBLIC_API_BLOCK_RE.search(candidate) or not PUBLIC_API_ALLOW_RE.search(candidate):
                continue
            seen.add(candidate)
            candidates.append(candidate)
    return candidates


def _clean_text(value: str) -> str:
    value = value.replace("\x00", "")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def _urls(text: str) -> list[str]:
    seen: set[str] = set()
    values: list[str] = []
    for match in re.finditer(r"https?://[^\s<>()\[\]{}\"']+", text or "", re.I):
        value = match.group(0).rstrip(".,;:")
        if value not in seen:
            seen.add(value)
            values.append(value)
    return values


def _decode_bytes(payload: bytes, preferred: str = "") -> str:
    encodings = [preferred, "utf-8-sig", "utf-8", "utf-16", "cp1252", "latin-1"]
    for encoding in encodings:
        if not encoding:
            continue
        try:
            return payload.decode(encoding)
        except Exception:
            continue
    return payload.decode("utf-8", errors="replace")


def _safe_next_url(source_url: str, raw: str) -> str:
    candidate = sanitize_public_api_url(urljoin(source_url, str(raw or "").strip()))
    if not candidate or not candidate.startswith(("http://", "https://")):
        return ""
    return candidate


def _json_pagination_urls(data: Any, source_url: str) -> list[str]:
    """Discover explicit and deterministic next-page URLs from public JSON.

    Only the next page/cursor is generated. Subsequent responses repeat the same
    process, so a large public review feed is exhausted without pre-enqueuing an
    unbounded synthetic range.
    """
    values: list[str] = []
    seen: set[str] = set()

    def add(raw: Any) -> None:
        if not isinstance(raw, (str, int, float)):
            return
        candidate = _safe_next_url(source_url, str(raw))
        if candidate and candidate not in seen:
            seen.add(candidate)
            values.append(candidate)

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            lowered = {str(key).lower(): value for key, value in node.items()}
            for key, value in node.items():
                low = str(key).lower().replace("_", "").replace("-", "")
                if low in {"next", "nexturl", "nextlink", "nexthref", "nextpageurl"}:
                    if isinstance(value, dict):
                        for nested in ("href", "url", "link"):
                            if nested in value:
                                add(value[nested])
                    else:
                        add(value)
                elif low in {"href", "url", "link", "contenturl", "downloadurl"} and isinstance(value, str):
                    add(value)
            # Page-number pagination. Respect an existing parameter name when possible.
            page_key = next((key for key in ("page", "pagenumber", "pageno", "currentpage") if key in lowered), "")
            total_key = next((key for key in ("totalpages", "pagecount", "numpages") if key in lowered), "")
            if page_key and total_key:
                try:
                    current = int(lowered[page_key])
                    total_pages = int(lowered[total_key])
                    if 0 <= current < total_pages:
                        parsed = urlparse(source_url)
                        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
                        actual_key = next((key for key in query if key.lower().replace("_", "").replace("-", "") == page_key), "page")
                        # Support both zero- and one-based APIs by advancing one step.
                        query[actual_key] = str(current + 1)
                        add(urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", urlencode(query), "")))
                except Exception:
                    pass
            # Offset pagination.
            if "offset" in lowered and "total" in lowered:
                limit_value = lowered.get("limit", lowered.get("pagesize", lowered.get("size", 0)))
                try:
                    offset = int(lowered["offset"]); total = int(lowered["total"]); limit = int(limit_value)
                    if limit > 0 and offset + limit < total:
                        parsed = urlparse(source_url)
                        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
                        query[next((key for key in query if key.lower() == "offset"), "offset")] = str(offset + limit)
                        if not any(key.lower() in {"limit", "pagesize", "size"} for key in query):
                            query["limit"] = str(limit)
                        add(urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", urlencode(query), "")))
                except Exception:
                    pass
            # Cursor pagination.
            next_cursor = lowered.get("nextcursor", lowered.get("continuationtoken", lowered.get("nexttoken")))
            if next_cursor not in (None, "", False):
                parsed = urlparse(source_url)
                query = dict(parse_qsl(parsed.query, keep_blank_values=True))
                cursor_key = next((key for key in query if key.lower() in {"cursor", "continuationtoken", "nextcursor"}), "cursor")
                query[cursor_key] = str(next_cursor)
                add(urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", urlencode(query), "")))
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(data)
    current = sanitize_public_api_url(source_url)
    return [value for value in values if value and value != current]


def _json_scalar(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return str(value).strip()
    if isinstance(value, dict):
        for key in ("name", "displayName", "value", "text", "ratingValue"):
            if key in value:
                text = _json_scalar(value.get(key))
                if text:
                    return text
    return ""


def _json_review_records(data: Any, source_url: str) -> list[dict[str, Any]]:
    """Extract individual customer reviews from common public JSON shapes."""
    records: list[dict[str, Any]] = []
    seen: set[str] = set()

    def pick(node: dict[str, Any], names: tuple[str, ...]) -> Any:
        normalized = {re.sub(r"[^a-z0-9]", "", str(key).lower()): value for key, value in node.items()}
        for name in names:
            if name in normalized:
                return normalized[name]
        return None

    def walk(node: Any, path: str = "") -> None:
        if isinstance(node, dict):
            title = _json_scalar(pick(node, ("title", "headline", "summary", "subject", "reviewtitle")))
            body = _json_scalar(pick(node, ("reviewtext", "reviewbody", "body", "comments", "comment", "content", "description")))
            rating_raw = pick(node, ("rating", "ratingvalue", "stars", "score", "overallrating"))
            rating = _json_scalar(rating_raw)
            review_id = _json_scalar(pick(node, ("reviewid", "id", "submissionid", "contentid")))
            author = _json_scalar(pick(node, ("author", "reviewer", "nickname", "username", "displayname")))
            date = _json_scalar(pick(node, ("datepublished", "createdate", "createdat", "submissiontime", "date", "published")))
            helpful = _json_scalar(pick(node, ("helpfulcount", "helpfulvotes", "totalpositivefeedbackcount", "helpful")))
            recommend = _json_scalar(pick(node, ("recommend", "recommended", "isrecommended", "wouldrecommend")))
            verified_raw = pick(node, ("verified", "verifiedpurchase", "isverified", "isverifiedpurchaser", "verifiedpurchaser"))
            path_review = "review" in path.lower()
            explicit_review_keys = any(
                re.sub(r"[^a-z0-9]", "", str(key).lower()) in {"reviewtext", "reviewbody", "reviewid", "reviewtitle"}
                for key in node
            )
            looks_like_review = bool(
                (rating and (body or title) and (path_review or explicit_review_keys or author or date))
                or (explicit_review_keys and (body or title))
            )
            if looks_like_review:
                digest_basis = f"{source_url}|{review_id}|{title}|{body}|{rating}|{author}|{date}"
                stable_id = review_id or hashlib.sha256(digest_basis.encode("utf-8", errors="ignore")).hexdigest()[:32]
                if stable_id not in seen:
                    seen.add(stable_id)
                    records.append({
                        "review_id": stable_id,
                        "title": title,
                        "body": body,
                        "rating": rating,
                        "author": author,
                        "date": date,
                        "recommend": recommend,
                        "verified": str(verified_raw).strip().lower() in {"1", "true", "yes", "verified", "verified purchaser"},
                        "helpful_count": helpful,
                        "source_url": source_url,
                        "evidence_type": "public_json_api_customer_opinion",
                    })
            for key, value in node.items():
                walk(value, f"{path}/{key}")
        elif isinstance(node, list):
            for index, value in enumerate(node):
                walk(value, f"{path}/{index}")

    walk(data)
    return records


def _json_declared_review_count(data: Any) -> int:
    candidates: list[int] = []
    count_keys = {"totalreviewcount", "reviewcount", "totalreviews", "numreviews", "numberofreviews"}

    def walk(node: Any, path: str = "") -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                normalized = re.sub(r"[^a-z0-9]", "", str(key).lower())
                if normalized in count_keys or (normalized == "total" and "review" in path.lower()):
                    try:
                        candidates.append(int(float(str(value))))
                    except Exception:
                        pass
                walk(value, f"{path}/{key}")
        elif isinstance(node, list):
            for value in node:
                walk(value, path)

    walk(data)
    return max(candidates) if candidates else 0


def _extract_json(text: str, source_url: str = "") -> tuple[str, dict[str, Any]]:
    data = json.loads(text)
    pretty = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    kind = type(data).__name__
    pagination = _json_pagination_urls(data, source_url) if source_url else []
    reviews = _json_review_records(data, source_url) if source_url else []
    return pretty, {
        "json_root_type": kind,
        "pagination_urls": pagination,
        "structured_reviews": reviews,
        "structured_review_count": len(reviews),
        "declared_review_count": _json_declared_review_count(data),
    }


def _extract_xml(text: str) -> tuple[str, dict[str, Any]]:
    soup = BeautifulSoup(text, "xml")
    values: list[str] = []
    for node in soup.find_all(True):
        if node.find(True, recursive=False):
            continue
        value = " ".join(node.stripped_strings)
        if value:
            values.append(f"{node.name}: {value}")
    return "\n".join(values) or soup.get_text("\n", strip=True), {"xml_root": soup.find().name if soup.find() else ""}


def _extract_csv(text: str, delimiter: str = ",") -> tuple[str, dict[str, Any]]:
    rows: list[list[str]] = []
    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    for row in reader:
        rows.append([str(cell).strip() for cell in row])
    rendered = "\n".join(" | ".join(row) for row in rows)
    return rendered, {"rows": len(rows), "columns_max": max((len(row) for row in rows), default=0)}


def _extract_vtt_or_srt(text: str) -> tuple[str, dict[str, Any]]:
    lines: list[str] = []
    cue_count = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.upper() == "WEBVTT" or re.fullmatch(r"\d+", line):
            continue
        if "-->" in line:
            cue_count += 1
            continue
        line = re.sub(r"<[^>]+>", "", line)
        if not lines or lines[-1] != line:
            lines.append(line)
    return "\n".join(lines), {"cue_count": cue_count}


def _extract_docx(path: Path) -> tuple[str, dict[str, Any]]:
    from docx import Document  # type: ignore

    document = Document(str(path))
    parts: list[str] = []
    for paragraph in document.paragraphs:
        if paragraph.text.strip():
            parts.append(paragraph.text.strip())
    for t_index, table in enumerate(document.tables, start=1):
        parts.append(f"===== TABLE {t_index} =====")
        for row in table.rows:
            parts.append(" | ".join(cell.text.strip() for cell in row.cells))
    for rel in document.part.rels.values():
        target = str(getattr(rel, "target_ref", "") or "")
        if target.startswith(("http://", "https://")):
            parts.append(target)
    return "\n".join(parts), {"paragraphs": len(document.paragraphs), "tables": len(document.tables)}


def _extract_pptx(path: Path) -> tuple[str, dict[str, Any]]:
    from pptx import Presentation  # type: ignore

    presentation = Presentation(str(path))
    parts: list[str] = []
    for index, slide in enumerate(presentation.slides, start=1):
        parts.append(f"===== SLIDE {index} =====")
        for shape in slide.shapes:
            if hasattr(shape, "text") and str(shape.text).strip():
                parts.append(str(shape.text).strip())
            if getattr(shape, "has_table", False):
                for row in shape.table.rows:
                    parts.append(" | ".join(cell.text.strip() for cell in row.cells))
        notes_slide = getattr(slide, "notes_slide", None)
        if notes_slide:
            note_texts = [str(shape.text).strip() for shape in notes_slide.shapes if hasattr(shape, "text") and str(shape.text).strip()]
            if note_texts:
                parts.append("[NOTES] " + "\n".join(note_texts))
    return "\n".join(parts), {"slides": len(presentation.slides)}


def _extract_xlsx(path: Path) -> tuple[str, dict[str, Any]]:
    from openpyxl import load_workbook  # type: ignore

    workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
    parts: list[str] = []
    rows_total = 0
    for worksheet in workbook.worksheets:
        parts.append(f"===== SHEET {worksheet.title} =====")
        for row in worksheet.iter_rows(values_only=True):
            values = ["" if value is None else str(value) for value in row]
            if any(value.strip() for value in values):
                parts.append(" | ".join(values))
                rows_total += 1
    return "\n".join(parts), {"sheets": len(workbook.worksheets), "rows": rows_total}


def extract_resource(path: Path, url: str, mime_type: str = "") -> ExtractedResource:
    ext = path.suffix.lower() or extension_for_url(url)
    mime_type = mime_type.split(";", 1)[0].strip().lower() or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    title = path.name
    warnings: list[str] = []
    metadata: dict[str, Any] = {"extension": ext, "bytes": path.stat().st_size}
    text = ""
    kind = "Document"

    try:
        if ext == ".docx":
            text, extra = _extract_docx(path)
            kind = "WordDocument"
            metadata.update(extra)
        elif ext == ".pptx":
            text, extra = _extract_pptx(path)
            kind = "Presentation"
            metadata.update(extra)
        elif ext in {".xlsx", ".xlsm"}:
            text, extra = _extract_xlsx(path)
            kind = "Spreadsheet"
            metadata.update(extra)
        elif ext in {".vtt", ".srt"}:
            raw = _decode_bytes(path.read_bytes())
            text, extra = _extract_vtt_or_srt(raw)
            kind = "Transcript"
            metadata.update(extra)
        elif ext == ".ttml":
            raw = _decode_bytes(path.read_bytes())
            text, extra = _extract_xml(raw)
            kind = "Transcript"
            metadata.update(extra)
        elif ext == ".json" or "json" in mime_type:
            raw = _decode_bytes(path.read_bytes())
            text, extra = _extract_json(raw, url)
            kind = "PublicData"
            metadata.update(extra)
        elif ext == ".xml" or "xml" in mime_type:
            raw = _decode_bytes(path.read_bytes())
            text, extra = _extract_xml(raw)
            kind = "PublicData"
            metadata.update(extra)
        elif ext in {".csv", ".tsv"}:
            raw = _decode_bytes(path.read_bytes())
            text, extra = _extract_csv(raw, "\t" if ext == ".tsv" else ",")
            kind = "PublicData"
            metadata.update(extra)
        elif ext in TEXT_EXTENSIONS or mime_type.startswith("text/"):
            text = _decode_bytes(path.read_bytes())
            kind = "Transcript" if ext in CAPTION_EXTENSIONS else "TextDocument"
        elif ext in ARCHIVE_OR_BINARY_EXTENSIONS:
            kind = "BinaryAsset"
            text = f"Public Dell binary/download asset metadata only. File: {path.name}; bytes: {path.stat().st_size}; mime: {mime_type}."
        elif zipfile.is_zipfile(path):
            kind = "Archive"
            with zipfile.ZipFile(path) as archive:
                names = archive.namelist()
            metadata["archive_entries"] = names[:5000]
            metadata["archive_entry_count"] = len(names)
            text = "\n".join(names)
        else:
            raw = path.read_bytes()
            text = _decode_bytes(raw)
            if not text.strip():
                kind = "BinaryAsset"
                text = f"Public Dell resource metadata only. File: {path.name}; bytes: {len(raw)}; mime: {mime_type}."
    except Exception as exc:
        warnings.append(f"Resource extraction failed for {path.name}: {type(exc).__name__}: {exc}")
        kind = "BinaryAsset" if ext in ARCHIVE_OR_BINARY_EXTENSIONS else "Document"
        text = f"Public Dell resource metadata. File: {path.name}; bytes: {path.stat().st_size}; mime: {mime_type}."

    text = _clean_text(text)
    embedded_urls = _urls(text)
    for value in metadata.get("pagination_urls") or []:
        if value not in embedded_urls:
            embedded_urls.append(value)
    return ExtractedResource(
        title=title,
        text=text,
        mime_type=mime_type,
        kind=kind,
        metadata=metadata,
        embedded_urls=embedded_urls,
        warnings=warnings,
    )
