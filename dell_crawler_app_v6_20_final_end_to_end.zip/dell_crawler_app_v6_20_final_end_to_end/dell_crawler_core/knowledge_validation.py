from __future__ import annotations

"""Strict semantic validation for crawler extraction payloads.

The crawler preserves every raw/model observation, but only high-value, well-formed
semantic entities are admitted to the property graph.  Navigation placeholders,
schema.org implementation details, visual assets, arbitrary concepts and weak LLM
entities are retained as evidence rows instead of becoming Neo4j-facing nodes.
"""

from copy import deepcopy
from dataclasses import dataclass, asdict, field
import hashlib
import re
from typing import Any

from .knowledge_ontology import canonical_node_type, canonical_relationship_type
from .product_intelligence import (
    CANONICAL_ATTRIBUTE_PREDICATE,
    normalized_product_attribute,
    is_product_detail_url,
    is_media_asset_url,
    valid_product_name,
)
from .snapshot_extract import canonicalize_url
from .semantic_identity import (
    GRAPH_NODE_TYPES, EVIDENCE_ONLY_TYPES, classify_entity, classification_attributes, semantic_entity_key,
)


EVIDENCE_ONLY_NODE_TYPES = set(EVIDENCE_ONLY_TYPES)
SEMANTIC_NODE_TYPES = set(GRAPH_NODE_TYPES)

_WEAK_NAME_RE = re.compile(
    r"^(?:entity|unknown|thing|attribute|property|value|item|resource|endpoint|open|"
    r"learn more|view more|show more|click here|details|view details|explore options|"
    r"configure and buy|buy now|https?://)\b",
    re.I,
)


@dataclass(slots=True)
class ValidationReport:
    source_url: str
    entities_input: int = 0
    entities_admitted: int = 0
    entities_evidence_only: int = 0
    entities_deduped: int = 0
    entities_classified: int = 0
    entities_unclassified: int = 0
    classification_counts: dict[str, int] = field(default_factory=dict)
    relations_input: int = 0
    relations_admitted: int = 0
    relations_rejected: int = 0
    facts_input: int = 0
    facts_admitted: int = 0
    product_facts_canonicalized: int = 0
    endpoints_input: int = 0
    endpoints_deduped: int = 0
    unmapped_preserved: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _clean(value: Any, limit: int = 4000) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _attrs(entity: dict[str, Any]) -> dict[str, Any]:
    attrs = entity.get("attributes") if isinstance(entity.get("attributes"), dict) else {}
    reserved = {"key", "id", "node_key", "type", "entity_type", "name", "title", "label", "url", "source_url", "attributes"}
    merged = dict(attrs)
    for key, value in entity.items():
        if key not in reserved and value not in (None, "", [], {}):
            merged.setdefault(key, value)
    return merged


def _meaningful_name(name: str) -> bool:
    text = _clean(name, 500)
    if len(text) < 2 or len(text) > 500:
        return False
    if _WEAK_NAME_RE.match(text):
        return False
    if re.fullmatch(r"[\W_]+", text):
        return False
    return True


def _product_has_identity(name: str, attrs: dict[str, Any], url: str, source_url: str) -> bool:
    product_url = _clean(attrs.get("product_url") or attrs.get("url") or url, 4000)
    if product_url and is_product_detail_url(product_url, source_url):
        return True
    if any(_clean(attrs.get(k), 500) for k in ("order_code", "orderCode", "part_number", "partNumber", "mpn", "model")):
        return True
    commercial = any(attrs.get(k) not in (None, "", [], {}) for k in (
        "price", "current_price", "list_price", "processor", "cpu", "graphics", "gpu",
        "memory", "storage", "display", "operating_system", "os",
    ))
    return bool(commercial and valid_product_name(name, structured=True))


def _entity_admission(entity: dict[str, Any], source_url: str) -> tuple[bool, str, str, dict[str, Any]]:
    name = _clean(entity.get("name") or entity.get("title") or entity.get("label") or "", 1000)
    attrs = _attrs(entity)
    url = canonicalize_url(_clean(entity.get("url") or attrs.get("url") or "", 4000), source_url) if (entity.get("url") or attrs.get("url")) else ""
    classification = classify_entity(entity, source_url, context="entity")
    attrs.update(classification_attributes(classification))
    entity_type = classification.node_type or "EVIDENCE_ONLY"

    if classification.node_type is None:
        return False, classification.reason or "unclassified_evidence", entity_type, attrs
    if entity_type in EVIDENCE_ONLY_NODE_TYPES or entity_type not in SEMANTIC_NODE_TYPES:
        return False, "evidence_only_type", entity_type, attrs
    if entity_type == "Product":
        if url and is_media_asset_url(url, source_url) and not _product_has_identity(name, attrs, "", source_url):
            return False, "media_asset_not_product", "VisualAsset", attrs
        if not _product_has_identity(name, attrs, url, source_url):
            return False, "product_without_stable_identity", entity_type, attrs
        return True, "", entity_type, attrs
    if entity_type in {"Brand", "Category", "ProductFamily", "Organization", "Market", "AccountTopic", "Service", "Software", "Solution", "Workload", "UseCase", "Requirement", "Compatibility", "FAQ"}:
        if not _meaningful_name(name):
            return False, "weak_semantic_name", entity_type, attrs
    if entity_type == "Offer":
        signal = any(attrs.get(k) not in (None, "", [], {}) for k in (
            "price", "list_price", "coupon_code", "promotion", "benefit", "discount", "discount_percent", "valid_to", "eligibility",
        ))
        if not signal and not _meaningful_name(name):
            return False, "offer_without_commercial_signal", entity_type, attrs
    if entity_type == "Review":
        signal = any(attrs.get(k) not in (None, "", [], {}) for k in ("body", "rating", "reviewBody", "author", "date"))
        if not signal and not _meaningful_name(name):
            return False, "review_without_evidence", entity_type, attrs
    # Every admitted node must have a deterministic identity. Products use the
    # dedicated product resolver; all other types must resolve here.
    if entity_type != "Product":
        stable_key = semantic_entity_key(entity_type, name, attrs, url=url, source_url=source_url)
        if not stable_key:
            return False, "semantic_identity_unresolved", entity_type, attrs
        attrs.setdefault("semantic_identity_key", stable_key)
    return True, "", entity_type, attrs


def _entity_fingerprint(entity: dict[str, Any], source_url: str) -> str:
    attrs = _attrs(entity)
    classification = classify_entity(entity, source_url, context="entity")
    entity_type = classification.node_type or "EVIDENCE_ONLY"
    name = _clean(entity.get("name") or entity.get("title") or entity.get("label"), 1000)
    if entity_type != "Product":
        stable = semantic_entity_key(entity_type, name, attrs, url=_clean(entity.get("url") or attrs.get("url"), 4000), source_url=source_url)
        if stable:
            return hashlib.sha256(stable.encode("utf-8", errors="ignore")).hexdigest()
    strong = [
        _clean(attrs.get("order_code") or attrs.get("orderCode"), 500).casefold(),
        _clean(attrs.get("part_number") or attrs.get("partNumber") or attrs.get("mpn"), 500).casefold(),
        canonicalize_url(_clean(attrs.get("product_url") or entity.get("url") or "", 4000), source_url),
        _clean(attrs.get("model"), 500).casefold(),
    ]
    basis = "|".join([entity_type, *(x for x in strong if x), name.casefold()])
    return hashlib.sha256(basis.encode("utf-8", errors="ignore")).hexdigest()


def validate_extraction_payload(extraction: dict[str, Any] | None, source_url: str) -> tuple[dict[str, Any], dict[str, Any]]:
    payload = deepcopy(extraction or {}) if isinstance(extraction, dict) else {}
    report = ValidationReport(source_url=source_url)
    payload.setdefault("unmapped_evidence", [])
    if not isinstance(payload["unmapped_evidence"], list):
        payload["unmapped_evidence"] = [payload["unmapped_evidence"]]

    raw_entities = payload.get("entities") if isinstance(payload.get("entities"), list) else []
    report.entities_input = len(raw_entities)
    admitted: list[dict[str, Any]] = []
    admitted_keys: set[str] = set()
    rejected_keys: set[str] = set()
    seen_entities: set[str] = set()
    local_type: dict[str, str] = {}
    for index, raw in enumerate(raw_entities):
        if not isinstance(raw, dict):
            payload["unmapped_evidence"].append({"field": "entity", "value": raw, "reason": "invalid_entity_shape"})
            report.entities_evidence_only += 1
            continue
        item = dict(raw)
        local_key = _clean(item.get("key") or item.get("id") or f"entity_{index}", 240)
        ok, reason, entity_type, attrs = _entity_admission(item, source_url)
        item["type"] = entity_type
        item["attributes"] = attrs
        local_type[local_key] = entity_type
        if ok:
            report.entities_classified += 1
            report.classification_counts[entity_type] = int(report.classification_counts.get(entity_type, 0)) + 1
        else:
            report.entities_unclassified += int(entity_type == "EVIDENCE_ONLY")
        if not ok:
            rejected_keys.add(local_key)
            payload["unmapped_evidence"].append({
                "field": "entity", "value": raw, "reason": reason,
                "canonical_type": entity_type, "source_url": source_url,
            })
            report.entities_evidence_only += 1
            continue
        fp = _entity_fingerprint(item, source_url)
        if fp in seen_entities:
            report.entities_deduped += 1
            payload["unmapped_evidence"].append({"field": "duplicate_entity", "value": raw, "reason": "semantic_duplicate_in_same_extraction"})
            continue
        seen_entities.add(fp)
        admitted.append(item)
        admitted_keys.add(local_key)
        report.entities_admitted += 1
    payload["entities"] = admitted

    raw_relations = payload.get("relations") if isinstance(payload.get("relations"), list) else []
    report.relations_input = len(raw_relations)
    clean_relations: list[dict[str, Any]] = []
    seen_rel: set[tuple[str, str, str]] = set()
    for raw in raw_relations:
        if not isinstance(raw, dict):
            report.relations_rejected += 1
            continue
        source_ref = _clean(raw.get("source_key") or raw.get("source") or "page", 240) or "page"
        target_ref = _clean(raw.get("target_key") or raw.get("target"), 240)
        predicate = canonical_relationship_type(raw.get("predicate") or raw.get("relation") or raw.get("type") or "RELATED_TO")
        # Local extraction references must resolve to an admitted entity (or the
        # current page/source). Explicit persisted graph node keys contain ':' and
        # are allowed through for the store to verify against the DB. This prevents
        # model-hallucinated local endpoints from being counted as valid relations.
        source_is_unknown_local = bool(source_ref and ":" not in source_ref and source_ref not in admitted_keys and source_ref not in {"page", "source"})
        target_is_unknown_local = bool(target_ref and ":" not in target_ref and target_ref not in admitted_keys)
        bad = (
            (source_ref in rejected_keys)
            or (target_ref in rejected_keys)
            or (not target_ref)
            or source_is_unknown_local
            or target_is_unknown_local
        )
        if bad:
            reason = "relationship_endpoint_not_semantic"
            if source_is_unknown_local or target_is_unknown_local:
                reason = "relationship_endpoint_unresolved"
            payload["unmapped_evidence"].append({"field": "relation", "value": raw, "reason": reason})
            report.relations_rejected += 1
            continue
        marker = (source_ref, predicate, target_ref)
        if marker in seen_rel:
            continue
        seen_rel.add(marker)
        item = dict(raw)
        item["source_key"] = source_ref
        item["target_key"] = target_ref
        item["predicate"] = predicate
        clean_relations.append(item)
        report.relations_admitted += 1
    payload["relations"] = clean_relations

    raw_facts = payload.get("facts") if isinstance(payload.get("facts"), list) else []
    report.facts_input = len(raw_facts)
    clean_facts: list[dict[str, Any]] = []
    seen_fact: set[tuple[str, str, str]] = set()
    for raw in raw_facts:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        subject = _clean(item.get("subject_key") or item.get("subject") or "page", 240) or "page"
        if subject in rejected_keys:
            qualifiers = item.get("qualifiers") if isinstance(item.get("qualifiers"), dict) else {}
            item["qualifiers"] = {**qualifiers, "evidence_only_subject": subject}
            subject = "page"
            item["subject_key"] = "page"
        pred = _clean(item.get("predicate") or item.get("field") or item.get("type") or "OBSERVATION", 160)
        if local_type.get(subject) == "Product":
            canonical_field = normalized_product_attribute(pred)
            if canonical_field:
                new_pred = CANONICAL_ATTRIBUTE_PREDICATE.get(canonical_field, pred.upper())
                if new_pred != pred:
                    report.product_facts_canonicalized += 1
                item["predicate"] = new_pred
        marker = (subject, _clean(item.get("predicate") or pred, 160).upper(), _clean(item.get("value"), 4000).casefold())
        if marker in seen_fact:
            continue
        seen_fact.add(marker)
        clean_facts.append(item)
        report.facts_admitted += 1
    payload["facts"] = clean_facts

    endpoints = payload.get("endpoints") if isinstance(payload.get("endpoints"), list) else []
    report.endpoints_input = len(endpoints)
    clean_endpoints: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    for raw in endpoints:
        if not isinstance(raw, dict):
            continue
        url = canonicalize_url(_clean(raw.get("url") or raw.get("href") or raw.get("link"), 4000), source_url)
        if not url:
            continue
        if url in seen_urls:
            report.endpoints_deduped += 1
            continue
        seen_urls.add(url)
        item = dict(raw)
        item["url"] = url
        clean_endpoints.append(item)
    payload["endpoints"] = clean_endpoints

    report.unmapped_preserved = len(payload.get("unmapped_evidence") or [])
    payload["semantic_validation"] = report.to_dict()
    return payload, report.to_dict()
