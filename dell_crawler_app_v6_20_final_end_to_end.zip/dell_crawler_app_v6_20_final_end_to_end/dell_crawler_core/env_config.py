from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Mapping


TRUE_VALUES = {'1', 'true', 'yes', 'y', 'on', 'enabled'}
FALSE_VALUES = {'0', 'false', 'no', 'n', 'off', 'disabled'}


def first_nonempty(env: Mapping[str, str], *names: str, default: str = '') -> str:
    """Return the first configured, non-empty environment value."""
    for name in names:
        value = env.get(name)
        if value is not None and str(value).strip() != '':
            return str(value).strip()
    return default


def env_bool(env: Mapping[str, str], name: str, default: bool) -> bool:
    raw = str(env.get(name, '')).strip().lower()
    if not raw:
        return default
    if raw in TRUE_VALUES:
        return True
    if raw in FALSE_VALUES:
        return False
    return default


def env_float(env: Mapping[str, str], name: str, default: float) -> float:
    raw = str(env.get(name, '')).strip()
    if not raw:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class RuntimeConfig:
    """Normalized configuration supporting the user's existing Dell `.env` names.

    The names visible in the supplied environment (`BASE_URL`, `MODEL_NAME`,
    `CLIENT_ID`, `CLIENT_SECRET`, and so on) take precedence. Existing `AIA_*`
    and `DELL_AIA_*` names remain supported for backward compatibility.
    """

    base_url: str
    text_model: str
    vision_model: str
    temperature: float
    client_id: str
    client_secret: str
    token_url: str
    scope: str
    static_token: str
    use_dell_sso: bool
    dell_auth_mode: str
    use_llm_form_planner: bool
    use_autogen: bool

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> 'RuntimeConfig':
        source = env or os.environ
        auth_mode = first_nonempty(source, 'DELL_AUTH_MODE', default='auto').lower()
        if auth_mode not in {'auto', 'manual', 'disabled', 'off'}:
            auth_mode = 'auto'
        return cls(
            base_url=first_nonempty(
                source,
                'BASE_URL',
                'AIA_BASE_URL',
                'DELL_AIA_BASE_URL',
                default='https://aia.gateway.dell.com/genai/dev/v1',
            ).rstrip('/'),
            text_model=first_nonempty(
                source,
                'MODEL_NAME',
                'AIA_TEXT_MODEL',
                'DELL_AIA_TEXT_MODEL',
                default='gpt-oss-120b',
            ),
            vision_model=first_nonempty(
                source,
                'VISION_MODEL_NAME',
                'AIA_VISION_MODEL',
                'DELL_AIA_VISION_MODEL',
                default='gemma-3-27b-it',
            ),
            temperature=env_float(source, 'TEMPERATURE', env_float(source, 'AIA_TEMPERATURE', 0.2)),
            client_id=first_nonempty(source, 'CLIENT_ID', 'AIA_CLIENT_ID', 'DELL_AIA_CLIENT_ID'),
            client_secret=first_nonempty(source, 'CLIENT_SECRET', 'AIA_CLIENT_SECRET', 'DELL_AIA_CLIENT_SECRET'),
            token_url=first_nonempty(source, 'TOKEN_URL', 'AIA_TOKEN_URL', 'DELL_AIA_TOKEN_URL'),
            scope=first_nonempty(source, 'SCOPE', 'AIA_SCOPE', 'DELL_AIA_SCOPE'),
            static_token=first_nonempty(source, 'AIA_STATIC_BEARER_TOKEN', 'DELL_AIA_TOKEN'),
            use_dell_sso=env_bool(source, 'USE_DELL_SSO', True),
            dell_auth_mode=auth_mode,
            use_llm_form_planner=env_bool(source, 'HIP_USE_LLM_FORM_PLANNER', True),
            use_autogen=env_bool(source, 'AIA_USE_AUTOGEN', True),
        )

    def public_summary(self) -> dict[str, object]:
        """Return a secret-safe configuration summary for UI and reports."""
        return {
            'base_url': self.base_url,
            'text_model': self.text_model,
            'vision_model': self.vision_model,
            'temperature': self.temperature,
            'credentials_configured': bool(self.client_id and self.client_secret) or bool(self.static_token),
            'token_url_configured': bool(self.token_url),
            'use_dell_sso': self.use_dell_sso,
            'dell_auth_mode': self.dell_auth_mode,
            'hip_use_llm_form_planner': self.use_llm_form_planner,
            'aia_use_autogen': self.use_autogen,
        }


def apply_compatibility_aliases(env: dict[str, str] | None = None) -> RuntimeConfig:
    """Populate legacy aliases without printing or persisting secret values.

    This lets older modules or third-party integrations continue to read `AIA_*`
    names while the user's existing `.env` can stay unchanged.
    """
    target = env if env is not None else os.environ
    config = RuntimeConfig.from_env(target)
    alias_values = {
        'AIA_BASE_URL': config.base_url,
        'AIA_TEXT_MODEL': config.text_model,
        'AIA_VISION_MODEL': config.vision_model,
        'AIA_TEMPERATURE': str(config.temperature),
        'AIA_CLIENT_ID': config.client_id,
        'AIA_CLIENT_SECRET': config.client_secret,
        'AIA_TOKEN_URL': config.token_url,
        'AIA_SCOPE': config.scope,
    }
    for name, value in alias_values.items():
        if value and not str(target.get(name, '')).strip():
            target[name] = value
    return config
