from __future__ import annotations

"""Deterministic Dell SSO bootstrap for read-only authenticated knowledge crawling.

The crawler is allowed to enter only the configured email address and to activate
Dell's Continue/Login handoff controls. It never enters passwords, OTPs, security
answers, payment data, or performs account mutations. The persistent Playwright
profile is reused so a previously authenticated SSO session can be consumed without
re-running login on every crawl.
"""

import re
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qsl, urlparse

from .market_context import normalize_locale
from .snapshot import parse_nodes
from .snapshot_extract import canonicalize_url, extract_links, is_trusted_dell_url


AUTH_SECRET_QUERY_KEYS = {
    "token", "access_token", "id_token", "refresh_token", "authorization", "auth",
    "session", "sessionid", "sid", "jwt", "code", "state", "password", "passwd",
    "secret", "client_secret",
}

_ACCOUNT_MUTATION_RE = re.compile(
    r"(?:/payment(?:/|$)|/checkout(?:/|$)|/cart(?:/|$)|/basket(?:/|$)|"
    r"/delete(?:/|$)|/remove(?:/|$)|/create(?:/|$)|/edit(?:/|$)|/update(?:/|$)|"
    r"/address(?:/|$)|/contact(?:/|$)|/messages?(?:/|$))",
    re.I,
)

_ACCOUNT_PATH_RE = re.compile(r"^/myaccount/[a-z]{2}-[a-z]{2}(?:/|$)", re.I)
_SIGNIN_RE = re.compile(
    r"(?:sign[ -]?in|login|email(?: or mobile number)?|continue to sign in|single sign-on|sso)",
    re.I,
)
_SIGNED_IN_RE = re.compile(
    r"(?:sign out|welcome back|account navigation|my account|profile settings|my products|saved items|"
    r"dell rewards balance|rewards and membership)",
    re.I,
)
_SSO_MESSAGE_RE = re.compile(
    r"(?:single sign-on(?: is)? enabled|sso(?: is)? available|continue to sign in using your sso|"
    r"myaccess\.dell\.com|agentlessdsso)",
    re.I,
)
_SECRET_PROMPT_RE = re.compile(
    r"(?:password|one[- ]time passcode|otp|security code|authenticator|verify your identity)",
    re.I,
)


@dataclass(slots=True)
class AuthResult:
    ok: bool
    status: str
    authenticated: bool
    url: str = ""
    title: str = ""
    steps: list[str] = field(default_factory=list)
    account_urls: list[str] = field(default_factory=list)
    detail: str = ""
    manual_checkpoint: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "status": self.status,
            "authenticated": self.authenticated,
            "url": self.url,
            "title": self.title,
            "steps": list(self.steps),
            "account_urls": list(self.account_urls),
            "detail": self.detail,
            "manual_checkpoint": self.manual_checkpoint,
        }


def safe_authenticated_account_url(url: str, base_url: str = "https://www.dell.com/en-uk") -> bool:
    """Allow only read-only Dell My Account summary/navigation routes.

    Query strings containing authentication secrets are rejected instead of being
    stored in the knowledge graph. Mutation/payment routes are never crawled.
    """
    canonical = canonicalize_url(url, base_url)
    if not canonical or not is_trusted_dell_url(canonical):
        return False
    parsed = urlparse(canonical)
    host = parsed.netloc.lower().split(":")[0]
    if host not in {"www.dell.com", "dell.com"}:
        return False
    if not _ACCOUNT_PATH_RE.match(parsed.path):
        return False
    if _ACCOUNT_MUTATION_RE.search(parsed.path):
        return False
    query_keys = {key.lower() for key, _ in parse_qsl(parsed.query, keep_blank_values=True)}
    if query_keys.intersection(AUTH_SECRET_QUERY_KEYS):
        return False
    return True


def _page_url_title(snapshot: str) -> tuple[str, str]:
    url_m = re.search(r"Page URL:\s*(\S+)", snapshot or "", re.I)
    title_m = re.search(r"Page Title:\s*(.+)", snapshot or "", re.I)
    return (
        canonicalize_url(url_m.group(1).strip()) if url_m else "",
        title_m.group(1).strip() if title_m else "",
    )


def _is_signin_surface(snapshot: str, url: str = "") -> bool:
    text = f"{snapshot}\n{url}"
    has_auth_ui = bool(_SIGNIN_RE.search(text))
    has_email_box = any(
        node.role.lower() in {"textbox", "combobox"}
        and re.search(r"email(?: or mobile number)?", node.name or "", re.I)
        for node in parse_nodes(snapshot)
    )
    return has_email_box or bool(has_auth_ui and re.search(r"/sign|/login|identity|auth", url, re.I))


def _masthead_profile_signed_in(snapshot: str, profile_name: str = "") -> bool:
    if profile_name:
        profile = re.escape(profile_name)
        button = re.search(
            rf'button\s+"{profile}"[^\n]*\[ref=[^\]]+\](?P<tail>.{{0,700}})',
            snapshot or "",
            re.I | re.S,
        )
        if button and re.search(r"✓|checkmark|signed[ -]?in|authenticated", button.group("tail"), re.I):
            return True
    return bool(_SIGNED_IN_RE.search(snapshot or "") and not _is_signin_surface(snapshot))


def _find_email_node(snapshot: str):
    return next(
        (
            node
            for node in parse_nodes(snapshot)
            if node.role.lower() in {"textbox", "combobox"}
            and re.search(r"email(?: or mobile number)?", node.name or "", re.I)
            and not node.disabled
        ),
        None,
    )


def _find_handoff_node(snapshot: str):
    candidates = []
    for node in parse_nodes(snapshot):
        if node.disabled or node.role.lower() not in {"button", "link", "menuitem"}:
            continue
        label = re.sub(r"\s+", " ", node.name or "").strip()
        if re.fullmatch(r"(?:continue|login|log in|sign in|continue to sign in)", label, re.I):
            score = 100
            if re.fullmatch(r"continue", label, re.I):
                score += 10
            candidates.append((score, node))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


class DellAuthenticatedSession:
    def __init__(
        self,
        runtime: Any,
        *,
        email: str,
        profile_name: str = "",
        locale: str = "en-uk",
        auth_probe_url: str = "",
        wait_seconds: float = 90.0,
        emit: Any | None = None,
    ) -> None:
        self.runtime = runtime
        self.email = (email or "").strip()
        self.profile_name = (profile_name or "").strip()
        self.locale = normalize_locale(locale)
        self.auth_probe_url = auth_probe_url or f"https://www.dell.com/myaccount/{self.locale}/overview"
        self.wait_seconds = max(5.0, float(wait_seconds))
        self.emit = emit

    def _event(self, event: str, **payload: Any) -> None:
        if self.emit:
            try:
                self.emit(event, **payload)
            except Exception:
                pass

    def _snapshot(self, intent: str) -> tuple[str, str, str]:
        result = self.runtime.snapshot(boxes=True, intent=intent)
        detail = str(result.get("detail") or "")
        url, title = _page_url_title(detail)
        return detail, url, title

    def ensure_authenticated(self) -> AuthResult:
        steps: list[str] = []
        if not self.email:
            return AuthResult(
                ok=False,
                status="AUTH_EMAIL_NOT_CONFIGURED",
                authenticated=False,
                detail="Set DELL_LOGIN_EMAIL (or DELL_DEMO_EMAIL) before authenticated crawling.",
                manual_checkpoint=True,
            )

        nav = self.runtime.navigate(self.auth_probe_url, "Probe Dell My Account using the persistent SSO browser profile")
        steps.append("navigate_auth_probe")
        if not nav.get("ok"):
            return AuthResult(False, "AUTH_PROBE_NAVIGATION_FAILED", False, steps=steps, detail=str(nav.get("detail") or ""))
        self.runtime.wait(1.5, intent="Wait for Dell sign-in/My Account route to render")
        snapshot, url, title = self._snapshot("Inspect Dell authentication state")

        if _masthead_profile_signed_in(snapshot, self.profile_name) or (
            safe_authenticated_account_url(url) and not _is_signin_surface(snapshot, url)
        ):
            self._event("auth_session_reused", url=url, title=title)
            return AuthResult(True, "AUTHENTICATED_REUSED", True, url=url, title=title, steps=steps)

        typed_email = False
        handoff_clicks = 0
        deadline = time.monotonic() + self.wait_seconds
        while time.monotonic() < deadline:
            if _masthead_profile_signed_in(snapshot, self.profile_name) or (
                safe_authenticated_account_url(url) and not _is_signin_surface(snapshot, url)
            ):
                self._event("auth_session_ready", url=url, title=title, handoff_clicks=handoff_clicks)
                return AuthResult(True, "AUTHENTICATED", True, url=url, title=title, steps=steps)

            email_node = _find_email_node(snapshot)
            if email_node and not typed_email:
                result = self.runtime.type_text(
                    email_node.ref,
                    email_node.name or "Email or Mobile Number",
                    self.email,
                    submit=False,
                    slowly=False,
                    intent="Enter configured Dell login email only",
                )
                if not result.get("ok"):
                    return AuthResult(False, "AUTH_EMAIL_ENTRY_FAILED", False, url=url, title=title, steps=steps, detail=str(result.get("detail") or ""))
                typed_email = True
                steps.append("email_entered")
                self._event("auth_email_entered", url=url)
                self.runtime.wait(0.4, intent="Wait for Dell login handoff control")
                snapshot, url, title = self._snapshot("Refresh Dell sign-in snapshot after email entry")
                continue

            handoff = _find_handoff_node(snapshot)
            sso_stage = bool(_SSO_MESSAGE_RE.search(snapshot))
            if handoff and handoff_clicks < 2:
                result = self.runtime.click(
                    handoff.ref,
                    handoff.name or "Continue",
                    intent=(
                        "Click Dell SSO-enabled login handoff a second time"
                        if sso_stage or handoff_clicks >= 1
                        else "Click Dell login/Continue after entering configured email"
                    ),
                )
                if not result.get("ok"):
                    return AuthResult(False, "AUTH_HANDOFF_CLICK_FAILED", False, url=url, title=title, steps=steps, detail=str(result.get("detail") or ""))
                handoff_clicks += 1
                steps.append(f"login_handoff_{handoff_clicks}")
                self._event("auth_handoff_clicked", url=url, click_index=handoff_clicks, sso_stage=sso_stage)
                self.runtime.wait(1.0, intent="Wait for Dell SSO handoff to advance")
                snapshot, url, title = self._snapshot("Inspect Dell SSO state after login handoff")
                continue

            # If enterprise SSO presents an actual secret/OTP prompt, wait for the
            # user or the corporate seamless SSO mechanism; never type the secret.
            manual = bool(_SECRET_PROMPT_RE.search(snapshot) or _SSO_MESSAGE_RE.search(snapshot))
            if manual:
                self._event("auth_manual_checkpoint", url=url, title=title)
            self.runtime.wait(1.0, intent="Wait for Dell enterprise SSO to complete without entering secrets")
            snapshot, url, title = self._snapshot("Poll Dell authenticated session")

        return AuthResult(
            ok=False,
            status="AUTHENTICATION_REQUIRED",
            authenticated=False,
            url=url,
            title=title,
            steps=steps,
            detail="Dell SSO did not reach an authenticated My Account page within the configured wait window.",
            manual_checkpoint=True,
        )

    def discover_account_urls(self) -> list[str]:
        """Discover read-only My Account destinations from the live profile menu."""
        home = f"https://www.dell.com/{self.locale}"
        self.runtime.navigate(home, "Open Dell home page to discover authenticated account navigation")
        self.runtime.wait(0.8, intent="Wait for Dell authenticated masthead")
        snapshot, _, _ = self._snapshot("Capture authenticated Dell masthead")

        nodes = parse_nodes(snapshot)
        profile_candidates = []
        for node in nodes:
            if node.disabled or node.role.lower() not in {"button", "menuitem", "link"}:
                continue
            hay = f"{node.name} {node.line}"
            score = 0
            if self.profile_name and re.fullmatch(re.escape(self.profile_name), node.name or "", re.I):
                score = 1000
            elif re.search(r"\b(profile|account)\b", node.name or "", re.I):
                score = 500
            if score:
                profile_candidates.append((score, node))
        if profile_candidates:
            node = max(profile_candidates, key=lambda item: item[0])[1]
            click = self.runtime.click(node.ref, node.name or "Account", intent="Open Dell authenticated profile menu for read-only destination discovery")
            if not click.get("ok"):
                self.runtime.hover(node.ref, node.name or "Account", intent="Hover Dell profile menu when click did not open it")
            self.runtime.wait(0.5, intent="Wait for Dell account menu")
            snapshot, _, _ = self._snapshot("Capture Dell authenticated account menu")

        urls: list[str] = []
        seen: set[str] = set()
        for link in extract_links(snapshot, home):
            candidate = canonicalize_url(link.url, home)
            if candidate and safe_authenticated_account_url(candidate, home) and candidate not in seen:
                seen.add(candidate)
                urls.append(candidate)

        # These two routes are known from the supplied AgentQ Dell workflow and
        # are safe read-only summary destinations. Live menu discovery remains the
        # primary source for every other account destination.
        for fallback in (
            f"https://www.dell.com/myaccount/{self.locale}/overview",
            f"https://www.dell.com/myaccount/{self.locale}/orders",
            f"https://www.dell.com/myaccount/{self.locale}/account-settings/profile",
            f"https://www.dell.com/myaccount/{self.locale}/saved-items",
            f"https://www.dell.com/myaccount/{self.locale}/myproducts",
            f"https://www.dell.com/myaccount/{self.locale}/rewards",
        ):
            candidate = canonicalize_url(fallback)
            if candidate not in seen:
                seen.add(candidate)
                urls.append(candidate)
        self._event("auth_account_destinations_discovered", count=len(urls), urls=urls[:30])
        return urls
