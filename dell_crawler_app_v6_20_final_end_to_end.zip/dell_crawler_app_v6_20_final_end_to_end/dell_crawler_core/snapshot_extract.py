from __future__ import annotations

import hashlib
import html
import re
from dataclasses import dataclass
from typing import Iterable
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from .market_context import normalize_locale

from .crawl_models import DiscoveredLink, SafeControl
from .deep_content import (
    is_document_control,
    is_repeatable_control,
    is_review_control,
    resource_kind,
)
from .snapshot import parse_nodes
from .resource_ingestion import is_binary_asset_url, is_public_data_url, is_supported_document_url
from .dell_site_profile import (
    DOCUMENT_LABEL_PATTERNS,
    READ_ONLY_CONTROL_PATTERNS,
    archetype_for,
    seed_urls_for_profile,
)


DELL_TRUSTED_DOMAINS = {
    "dell.com",
    "www.dell.com",
    "i.dell.com",
    "dl.dell.com",
    "downloads.dell.com",
    "delltechnologies.com",
    "www.delltechnologies.com",
    "education.dell.com",
    "democenter.dell.com",
    "automation.dell.com",
    "infohub.delltechnologies.com",
    "developer.dell.com",
}

# Query keys that do not change the actual source content and cause crawl duplicates.
TRACKING_QUERY_KEYS = {
    "gacd",
    "gclid",
    "dgc",
    "cid",
    "lid",
    "acd",
    "ven1",
    "ven2",
    "ven3",
    "ref",
    "referrer",
    "redirect",
    "~ck",
    "c",
    "cs",
    "l",
    "s",
    "stp",
    "oc",
    "hve",
    "link_number",
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_content",
    "utm_term",
    "fbclid",
    "msclkid",
    "dclid",
    "gclsrc",
    "refid",
    "sourceid",
    "campaignid",
    "adgroupid",
    "creativeid",
    "trk",
    "trackingid",
    "cmp",
    "cmpid",
    "cachebuster",
    "cb",
}

BLOCKED_PATH_PATTERNS = [
    r"/cart(?:/|$)",
    r"/purchase(?:/|$)",
    r"/checkout(?:/|$)",
    r"/payment(?:/|$)",
    r"/signin(?:/|$)",
    r"/login(?:/|$)",
    r"/myaccount/",
    r"/identity/",
    r"/search(?:/|$)",
    r"/webapps/",
    r"/api/",
]

SAFE_CONTROL_RE = re.compile(
    r"\b(?:" + "|".join(f"(?:{pattern})" for pattern in READ_ONLY_CONTROL_PATTERNS) + r")\b",
    re.I,
)


UNSAFE_CONTROL_RE = re.compile(
    r"\b(add to (?:cart|basket)|buy now|checkout|proceed|place order|pay now|"
    r"submit order|sign in|sign out|create account|delete|remove|save changes|"
    r"contact sales|call me|chat now|send feedback|submit feedback|accept all cookies|"
    r"reply|post reply|new conversation|start conversation|create post|kudos?|subscribe|"
    r"mark as solution|accept as solution|report abuse|was this helpful)\b",
    re.I,
)

PRIORITY_HINTS: list[tuple[re.Pattern[str], int]] = [
    (re.compile(r"/spd/|workstation|precision|pro-max|artificial-intelligence|ai-pc|poweredge-ai", re.I), 5),
    (re.compile(r"customer-stor|use-case|solution|resource|whitepaper|community/en/conversations|\.pdf(?:$|\?)", re.I), 12),
    (re.compile(r"offer|deal|rewards|service|support|manual|documentation", re.I), 20),
    (re.compile(r"/shop/|/lp/|/blog/", re.I), 35),
]


@dataclass(slots=True)
class SnapshotPageInfo:
    url: str
    title: str


def canonicalize_url(url: str, base_url: str = "https://www.dell.com/en-uk") -> str:
    raw = html.unescape((url or "").strip())
    if not raw:
        return ""
    if raw.startswith("//"):
        raw = "https:" + raw
    raw = urljoin(base_url, raw)
    parsed = urlparse(raw)
    scheme = "https" if parsed.scheme in {"http", "https", ""} else parsed.scheme.lower()
    host = parsed.netloc.lower().split("@")[(-1)]
    if host.endswith(":443"):
        host = host[:-4]
    path = re.sub(r"/{2,}", "/", parsed.path or "/")
    # Dell sometimes emits country-first locale aliases (for example /uk-en).
    # Normalize known aliases before scope checks/deduplication so redirects do not
    # create duplicate frontier identities.
    alias_map = {"uk-en": "en-uk", "us-en": "en-us", "in-en": "en-in", "ca-en": "en-ca", "ca-fr": "fr-ca", "au-en": "en-au"}
    parts = path.split("/")
    for index, part in enumerate(parts):
        alias = alias_map.get(part.casefold())
        if alias:
            parts[index] = alias
    path = "/".join(parts) or "/"
    if path != "/":
        path = path.rstrip("/")
    kept = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=False):
        lk = key.lower()
        if lk in TRACKING_QUERY_KEYS or lk.startswith("utm_"):
            continue
        # Dell listing pages sometimes need filters such as appref. Keep those.
        kept.append((key, value))
    query = urlencode(sorted(kept), doseq=True)
    return urlunparse((scheme, host, path, "", query, ""))


def is_trusted_dell_url(url: str) -> bool:
    parsed = urlparse(url)
    host = parsed.netloc.lower().split(":")[0]
    return any(host == domain or host.endswith("." + domain) for domain in DELL_TRUSTED_DOMAINS)


def is_locale_scope(
    url: str,
    locale: str = "en-uk",
    allow_cross_dell_assets: bool = True,
    include_community_feedback: bool = True,
) -> bool:
    """Return True for public knowledge in the configured Dell locale.

    Marketing/shop pages use ``/<locale>`` while Support commonly places the
    locale later in the path.  English Community is shared across locales.
    Authenticated ``/myaccount/`` routes are intentionally excluded here and are
    admitted only by the authenticated-session safety gate in the crawler.
    """
    canonical = canonicalize_url(url)
    if not canonical or not is_trusted_dell_url(canonical):
        return False
    parsed = urlparse(canonical)
    host = parsed.netloc.lower().split(":")[0]
    path = parsed.path.lower()
    loc = normalize_locale(locale)

    if host in {"www.dell.com", "dell.com"}:
        locale_marketing = path == f"/{loc}" or path.startswith(f"/{loc}/")
        locale_support = path.startswith("/support/") and (f"/{loc}" in path or path.endswith(f"/{loc}"))
        english_community = include_community_feedback and loc.startswith("en-") and (
            path == "/community/en" or path.startswith("/community/en/")
        )
        # Global sitemap indexes are discovery infrastructure and are filtered
        # again when each contained URL enters the frontier.
        global_sitemap = path.endswith(".xml") and "sitemap" in path
        if not (locale_marketing or locale_support or english_community or global_sitemap):
            return False
    elif not allow_cross_dell_assets:
        return False

    if any(re.search(pattern, path, re.I) for pattern in BLOCKED_PATH_PATTERNS):
        return False
    return True


def is_en_uk_scope(
    url: str,
    allow_cross_dell_assets: bool = True,
    include_community_feedback: bool = True,
) -> bool:
    """Backward-compatible UK wrapper used by older tests/integrations."""
    return is_locale_scope(
        url,
        locale="en-uk",
        allow_cross_dell_assets=allow_cross_dell_assets,
        include_community_feedback=include_community_feedback,
    )


def is_pdf_url(url: str) -> bool:
    path = urlparse(url).path.lower()
    return path.endswith(".pdf") or "/asset/" in path and "pdf" in path


def is_document_url(url: str) -> bool:
    """Return True for public knowledge documents supported by the crawler."""
    return is_pdf_url(url) or is_supported_document_url(url)


def is_public_resource_url(url: str) -> bool:
    """Return True for document, transcript, structured-data or binary metadata resources."""
    return is_document_url(url) or is_public_data_url(url) or is_binary_asset_url(url)


def is_sitemap_url(url: str) -> bool:
    """Return True only for Dell-hosted XML sitemap endpoints.

    The human-readable locale sitemap page remains an ordinary HTML page.
    XML sitemap indexes are allowed as discovery infrastructure, but every URL
    found inside them is still passed through the configured locale scope gate.
    """
    canonical = canonicalize_url(url)
    if not canonical or not is_trusted_dell_url(canonical):
        return False
    path = urlparse(canonical).path.lower()
    return path.endswith(".xml") and "sitemap" in path


def priority_for_url(url: str, label: str = "") -> int:
    haystack = f"{url} {label}"
    for regex, priority in PRIORITY_HINTS:
        if regex.search(haystack):
            return priority
    return 50


def classify_page(url: str, title: str = "", text: str = "") -> str:
    haystack = f"{url} {title} {text[:5000]}".lower()
    path = urlparse(url).path.lower()
    if is_pdf_url(url):
        return "Document"
    archetype = archetype_for(url, title, text)
    if archetype is not None:
        return archetype.name
    if "/shop/" in path and ("/scr/" in path or "/sc/" in path or "/sf/" in path or "/ar/" in path):
        if "deal" in haystack or "offer" in haystack:
            return "OfferCatalog"
        return "ProductCatalog"
    if "/support/kbdoc/" in path:
        return "SupportArticle"
    if "/support/manuals/" in path or "/support/product-details/" in path:
        return "ManualOrSupport"
    if "customer stor" in haystack:
        return "CustomerStory"
    if "/lp/" in path:
        if "artificial intelligence" in haystack or re.search(r"\bai\b", haystack):
            return "AISolutionPage"
        if "deal" in haystack or "offer" in haystack:
            return "OfferPage"
        return "LandingPage"
    if "service" in haystack:
        return "ServicePage"
    if "solution" in haystack:
        return "SolutionPage"
    return "WebPage"


def extract_page_info(snapshot: str) -> SnapshotPageInfo:
    url_match = re.search(r"^-\s*Page URL:\s*(.+)$", snapshot or "", re.M)
    title_match = re.search(r"^-\s*Page Title:\s*(.+)$", snapshot or "", re.M)
    return SnapshotPageInfo(
        url=(url_match.group(1).strip() if url_match else ""),
        title=(title_match.group(1).strip() if title_match else ""),
    )


def _visible_candidates(line: str) -> Iterable[str]:
    quoted = re.search(
        r'-\s*(?:heading|link|button|tab|menuitem|strong|paragraph|textbox|combobox|generic|listitem|cell|rowheader|columnheader)\s+"([^"]+)"',
        line,
        re.I,
    )
    if quoted:
        yield quoted.group(1)
    direct = re.search(r"-\s*text:\s*(.+)$", line, re.I)
    if direct:
        yield direct.group(1)
    suffix = re.search(r"\](?:\s*\[[^\]]+\])*:\s*(.+)$", line)
    if suffix:
        value = suffix.group(1)
        if not value.lstrip().startswith("/"):
            yield value


def extract_visible_text(snapshot: str, max_chars: int = 90000) -> str:
    values: list[str] = []
    seen: set[str] = set()
    for raw in (snapshot or "").splitlines():
        for candidate in _visible_candidates(raw.strip()):
            value = re.sub(r"\s+", " ", html.unescape(candidate)).strip(' `"')
            if not value or len(value) > 1200:
                continue
            if value.startswith(("http://", "https://", "/url:")):
                continue
            key = value.casefold()
            if key in seen:
                continue
            seen.add(key)
            values.append(value)
            if sum(len(v) + 1 for v in values) >= max_chars:
                return "\n".join(values)[:max_chars]
    return "\n".join(values)[:max_chars]


def extract_links(snapshot: str, base_url: str) -> list[DiscoveredLink]:
    lines = (snapshot or "").splitlines()
    links: list[DiscoveredLink] = []
    seen: set[str] = set()
    link_header = re.compile(r'-\s*link(?:\s+"([^"]*)")?[^\n]*?\[ref=([^\]]+)\]', re.I)
    url_line = re.compile(r"/url:\s*(\S.+)$", re.I)

    for index, raw in enumerate(lines):
        match = link_header.search(raw)
        if not match:
            continue
        label = re.sub(r"\s+", " ", html.unescape(match.group(1) or "")).strip()
        ref = match.group(2).strip()
        url_value = ""
        for child in lines[index + 1 : min(len(lines), index + 7)]:
            # Stop when a sibling/top-level role starts at the same or lower indentation.
            if child.strip().startswith("-") and len(child) - len(child.lstrip()) <= len(raw) - len(raw.lstrip()):
                break
            um = url_line.search(child)
            if um:
                url_value = um.group(1).strip().strip('"')
                break
        if not url_value:
            # Some snapshot versions place URL after a colon on the link line.
            inline = re.search(r"(?:/url:|href=)\s*([^\s\]]+)", raw, re.I)
            if inline:
                url_value = inline.group(1).strip().strip('"')
        if not url_value:
            continue
        canonical = canonicalize_url(url_value, base_url)
        if not canonical or canonical in seen:
            continue
        seen.add(canonical)
        links.append(
            DiscoveredLink(
                label=label or canonical,
                url=canonical,
                ref=ref,
                source="snapshot",
                relation="HAS_ENDPOINT" if label else "LINKS_TO",
                priority=priority_for_url(canonical, label),
            )
        )
    return links


def extract_safe_controls(snapshot: str, limit: int | None = None) -> list[SafeControl]:
    """Extract every safe read-only knowledge control, including repeatable widgets.

    Duplicate labels are retained when references differ. Controls such as
    ``+ Show More Reviews`` are marked repeatable so the crawler can click them
    again after the DOM refreshes until the review/resource frontier converges.
    Brochure, eBook, whitepaper, datasheet, case-study, and PDF launch controls
    are also retained even when Dell implements them as JavaScript buttons.
    """
    controls: list[SafeControl] = []
    seen: set[tuple[str, str, str]] = set()
    for node in parse_nodes(snapshot or ""):
        role = (node.role or "").lower()
        label = re.sub(r"\s+", " ", node.name or "").strip()
        if role not in {"button", "tab", "menuitem", "link"} or not label:
            continue
        if node.disabled or UNSAFE_CONTROL_RE.search(label) or not SAFE_CONTROL_RE.search(label):
            continue
        key = (role, label.casefold(), node.ref)
        if key in seen:
            continue
        seen.add(key)
        repeatable = is_repeatable_control(label)
        review_control = is_review_control(label)
        document_control = is_document_control(label)
        if role == "tab":
            action_kind = "tab"
        elif role == "link":
            action_kind = "navigate"
        elif repeatable:
            action_kind = "repeatable_expand"
        elif document_control:
            action_kind = "resource_open"
        else:
            action_kind = "expand"
        priority = 5 if re.search(
            r"spec|feature|resource|document|manual|use case|customer stor|review|brochure|white\s*paper|datasheet|pdf",
            label,
            re.I,
        ) else 20
        controls.append(
            SafeControl(
                label=label,
                ref=node.ref,
                role=role,
                action_kind=action_kind,
                priority=priority,
                repeatable=repeatable,
                review_control=review_control,
                document_control=document_control,
                resource_kind=resource_kind(label),
                disabled=node.disabled,
                context=node.context,
            )
        )
    controls.sort(
        key=lambda x: (
            x.priority,
            0 if x.document_control else 1,
            0 if x.review_control else 1,
            x.label.casefold(),
            x.ref,
        )
    )
    if limit is not None and limit >= 0:
        return controls[:limit]
    return controls


def content_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", errors="ignore")).hexdigest()


def stable_text_hash(text: str) -> str:
    """Hash semantically identical rendered text despite harmless whitespace/DOM churn.

    This remains exact after normalization: it does not fuzzy-merge similar product
    pages. It only removes zero-width characters, HTML entity differences and
    whitespace variation that otherwise caused repeat Dell AIA extraction.
    """
    value = html.unescape(str(text or ""))
    value = value.replace("\u200b", "").replace("\ufeff", "")
    value = re.sub(r"[\t\r\n ]+", " ", value).strip()
    return hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()


def seed_urls_for_scope(scope_name: str, locale: str = "en-uk") -> list[str]:
    return seed_urls_for_profile(scope_name, locale=locale)

