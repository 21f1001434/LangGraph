from __future__ import annotations

"""Deterministic Dell product-card and product-detail extraction.

The earlier crawler captured a large amount of page text, but prices and technical
specifications were frequently attached to the catalogue page/endpoint rather than
an individual Product node.  This module keeps product identity and evidence
association together.

It consumes, in priority order:
1. structured ``productCards`` captured from the live rendered DOM;
2. Product JSON-LD on detail pages;
3. visible catalogue text as a compatibility fallback.

No value is invented.  Every normalized field retains the source text and URL.
"""

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
import hashlib
import re
from typing import Any, Iterable
from urllib.parse import urlparse

from .crawl_models import CrawlPage
from .snapshot_extract import canonicalize_url
from .market_context import infer_market_context, normalize_currency, price_predicate


SPACE_RE = re.compile(r"\s+")
PRICE_TOKEN_RE = re.compile(r"[£$€₹¥]\s*([0-9][0-9,]*(?:\.\d{1,2})?)", re.I)
MODEL_RE = re.compile(r"\bModel\s*:\s*([A-Z0-9][A-Z0-9._/-]{1,80})", re.I)
ORDER_CODE_RE = re.compile(r"\b(?:Order\s*Code|OrderCode|SKU|Part\s*Number|Part\s*No\.?|MPN)\s*[:#]?\s*([A-Z0-9][A-Z0-9._/-]{3,120})", re.I)
RATING_RE = re.compile(r"\b([1-5](?:\.\d)?)\s*(?:out of 5 stars?|stars?)", re.I)
RATING_COUNT_RE = re.compile(r"\b([0-9][0-9,]*)\s+reviews?\b", re.I)
SAVE_RE = re.compile(r"\bSave\s+[£$€₹¥]\s*([0-9][0-9,]*(?:\.\d{1,2})?)(?:\s*\((\d{1,3})%\))?", re.I)
PERCENT_OFF_RE = re.compile(r"\b(\d{1,3})%\s*off\b", re.I)
FINANCE_RE = re.compile(
    r"(?:as low as\s*)?[£$€₹¥]\s*([0-9][0-9,]*(?:\.\d{1,2})?)\s*(?:per month|/month|over)"
    r"(?:[^\n]{0,80}?\b(\d{1,3})\s*months?)?(?:[^\n]{0,80}?\b(\d+(?:\.\d+)?)%\s*interest)?",
    re.I,
)
VAT_RE = re.compile(r"[£$€₹¥]\s*([0-9][0-9,]*(?:\.\d{1,2})?)\s+excluding\s+VAT(?:\s*@\s*(\d+(?:\.\d+)?)%)?", re.I)
REWARD_RE = re.compile(r"[£$€₹¥]\s*([0-9][0-9,]*(?:\.\d{1,2})?)\s+(?:back\s+)?in\s+Dell\s+Rewards?", re.I)
WEIGHT_RE = re.compile(r"\b(?:Starting at|From|Weight:?\s*)\s*([0-9]+(?:\.[0-9]+)?)\s*(kg|lb|lbs)\b", re.I)
BATTERY_RE = re.compile(r"\b(?:Up to\s+)?([0-9]+(?:\.\d+)?)\s*hours?\b[^\n]{0,80}(?:battery|streaming)", re.I)
TOPS_RE = re.compile(r"\b([0-9]+(?:\.\d+)?)\s*TOPS\b", re.I)
DISPLAY_RE = re.compile(
    r"\b([0-9]{1,2}(?:\.[0-9])?)\s*(?:-?in(?!-1)(?:\.|\b)|inches?\b|[”\"])(?:\s+display)?[^\n]{0,180}",
    re.I,
)
MEMORY_RE = re.compile(
    r"\b(?:up to\s+)?([0-9]{1,4})\s*(GB|TB)\b[^\n]{0,100}?\b(?:DDR[3-6]|LPDDR[3-6]X?|ECC|RAM|memory)\b[^\n]{0,100}",
    re.I,
)
STORAGE_RE = re.compile(
    r"\b(?:up to\s+)?([0-9]{1,4})\s*(GB|TB)\b[^\n]{0,100}?\b(?:SSD|NVMe|HDD|hard drive|storage)\b[^\n]{0,100}",
    re.I,
)
CPU_LINE_RE = re.compile(
    r"\b(?:Intel(?:®)?\s+(?:Core(?:™)?|Xeon(?:®)?|Celeron|Pentium)|Core(?:™)?\s+Ultra(?:™)?|"
    r"AMD(?:®)?(?:\s+Ryzen(?:™)?|\s+EPYC(?:™)?|\s+Threadripper(?:™)?)|"
    r"Qualcomm(?:®)?\s+Snapdragon(?:®)?|NVIDIA\s+Grace|Apple\s+M\d)[^\n]{0,220}",
    re.I,
)
GPU_LINE_RE = re.compile(
    r"\b(?:NVIDIA(?:®)?\s+(?:(?:GeForce\s+)?RTX(?:™)?(?:\s+PRO)?(?:\s+[A-Z0-9-]+)?|A\d{2,4}|L\d{1,3}|T\d{2,4})|"
    r"AMD(?:®)?\s+Radeon(?:™)?(?:\s+[A-Z0-9 -]+)?|Intel(?:®)?\s+Arc(?:™)?(?:\s+[A-Z0-9 -]+)?|"
    r"Intel(?:®)?\s+(?:UHD\s+)?Graphics)[^\n]{0,180}",
    re.I,
)
OS_LINE_RE = re.compile(r"\b(?:Windows\s+11(?:\s+(?:Home|Pro))?|Ubuntu(?:\s+Linux)?|Red Hat Enterprise Linux|RHEL)[^\n]{0,120}", re.I)
NETWORK_RE = re.compile(r"\b(?:Wi-?Fi\s*[67](?:E)?|Bluetooth\s*[0-9.]+|Thunderbolt\s*[45]|[0-9]+\s*GbE|Ethernet|InfiniBand)[^\n]{0,140}", re.I)
WARRANTY_RE = re.compile(r"\b(?:ProSupport Plus|ProSupport|Premium Support Plus|Premium Support|Basic Onsite Service|Next Business Day|warranty)[^\n]{0,200}", re.I)
CONDITION_RE = re.compile(r"\b(New|Refurbished|Used|Open Box)\b", re.I)
AVAILABILITY_RE = re.compile(r"\b(In Stock|Out of Stock|Available|Temporarily unavailable|Ships? in [^\n]{1,80})\b", re.I)

PRODUCT_ACTION_RE = re.compile(
    r"^(?:Compare\s+)?(.+?)(?:\s+with other products|\s+Explore Options|\s+Configure and buy|\s+View Product Page)$",
    re.I,
)
COMPARE_START_RE = re.compile(r"^Compare\s+(.+?)\s+with other products$", re.I)
ACTION_ONLY_RE = re.compile(r"^(?:Compare|Explore Options|Configure and buy|View Product Page|View offer|Previous|Next|〈|〉)$", re.I)
NOISE_NAME_RE = re.compile(
    r"^(?:New|Recommended laptop deals|Select \d+ or more products|Sort by:|Showing page|Original Price|Dell Price|Base model from|Color:|Weight Details|"
    r"Subject to approval.*|Terms and conditions.*|Ts and Cs apply.*|PayPal Credit.*|Representative APR.*|"
    r"Available for online purchases.*|Estimated value.*|Financing.*|Dell Rewards.*)$",
    re.I,
)
PRODUCT_NAME_SIGNAL_RE = re.compile(
    r"\b(?:Dell|XPS|Alienware|Inspiron|Precision|Latitude|OptiPlex|PowerEdge|PowerStore|PowerScale|PowerFlex|"
    r"UltraSharp|Chromebook|Vostro|ProSupport|Laptop|Notebook|Desktop|Workstation|Server|Monitor|Display|Dock|"
    r"Keyboard|Mouse|Headset|Webcam|Adapter|Storage|Switch|Appliance|Tablet|Thin Client|Gaming PC)\b",
    re.I,
)
PRODUCT_NAME_LEGAL_RE = re.compile(
    r"(?:subject to approval|terms (?:and|&) conditions|ts and cs|representative apr|credit is provided|"
    r"finance agreement|monthly payments|privacy|copyright|all rights reserved|estimated value|"
    r"student exclusive|employee exclusive|member exclusive|% on everything else|special offer|coupon)",
    re.I,
)

MEDIA_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".svg", ".ico",
    ".bmp", ".tif", ".tiff", ".mp4", ".webm", ".mov", ".m4v", ".mp3",
    ".wav", ".ogg", ".woff", ".woff2", ".ttf", ".eot", ".css", ".js",
}
MEDIA_PATH_RE = re.compile(
    r"/(?:image|images|img|media|assets?|content/dam|dellcontent|product-images?|thumbnails?)(?:/|$)",
    re.I,
)
PRODUCT_DETAIL_PATH_RE = re.compile(
    r"/(?:spd|apd|product-details?|productdetail|configuration)(?:/|$)", re.I
)


def is_media_asset_url(url: str, base_url: str = "") -> bool:
    """Return True when a URL is clearly an image/static-media resource.

    Product records must never use these resources as their canonical identity.
    Dell catalogue cards often expose an image before a product-detail anchor, and
    LLM extraction can otherwise promote that image URL into a Product node key.
    """
    absolute = canonicalize_url(str(url or ""), base_url)
    if not absolute:
        return False
    parsed = urlparse(absolute)
    path = parsed.path.casefold()
    suffix = "." + path.rsplit(".", 1)[-1] if "." in path.rsplit("/", 1)[-1] else ""
    if suffix in MEDIA_EXTENSIONS:
        return True
    return bool(MEDIA_PATH_RE.search(path))


def is_product_detail_url(url: str, base_url: str = "") -> bool:
    """Accept only a real Dell product/detail URL for Product identity.

    This intentionally rejects generic links, catalogue pages and image/CDN URLs.
    The accepted patterns cover Dell SPD systems and APD accessories plus the
    current product-details/configuration routes.
    """
    absolute = canonicalize_url(str(url or ""), base_url)
    if not absolute or is_media_asset_url(absolute):
        return False
    parsed = urlparse(absolute)
    host = parsed.netloc.casefold().split(":", 1)[0]
    if not (host == "dell.com" or host.endswith(".dell.com")):
        return False
    return bool(PRODUCT_DETAIL_PATH_RE.search(parsed.path))


def valid_product_name(name: str, *, structured: bool = False) -> bool:
    clean = SPACE_RE.sub(" ", str(name or "")).strip(" -|:")
    if not (3 <= len(clean) <= 260):
        return False
    if NOISE_NAME_RE.match(clean) or PRODUCT_NAME_LEGAL_RE.search(clean):
        return False
    if PRODUCT_NAME_SIGNAL_RE.search(clean):
        return True
    # Product JSON-LD may use a short commercial name that omits the Dell brand.
    # Keep it only when the source explicitly declared a Product object.
    return bool(structured and re.search(r"[A-Za-z].*\d|\d.*[A-Za-z]", clean))

FAMILY_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("Dell Pro Max", re.compile(r"\bDell\s+Pro\s+Max\b|\bPrecision\b", re.I)),
    ("Dell Pro Plus", re.compile(r"\bDell\s+Pro\s+Plus\b", re.I)),
    ("Dell Pro", re.compile(r"\bDell\s+Pro\b|\bLatitude\b|\bOptiPlex\b", re.I)),
    ("XPS", re.compile(r"\bXPS\b", re.I)),
    ("Alienware", re.compile(r"\bAlienware\b", re.I)),
    ("Inspiron", re.compile(r"\bInspiron\b", re.I)),
    ("Precision", re.compile(r"\bPrecision\b", re.I)),
    ("PowerEdge", re.compile(r"\bPowerEdge\b", re.I)),
    ("PowerStore", re.compile(r"\bPowerStore\b", re.I)),
    ("PowerScale", re.compile(r"\bPowerScale\b", re.I)),
    ("PowerFlex", re.compile(r"\bPowerFlex\b", re.I)),
    ("Dell", re.compile(r"\bDell\b", re.I)),
)

CATEGORY_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("Mobile Workstation", re.compile(r"mobile workstation|precision.*laptop|pro max.*laptop", re.I)),
    ("Fixed Workstation", re.compile(r"workstation|precision.*(?:tower|desktop)|pro max.*(?:tower|desktop)", re.I)),
    ("Laptop", re.compile(r"laptop|notebook|2-in-1|chromebook", re.I)),
    ("Desktop", re.compile(r"desktop|tower|micro|small form factor|all-in-one", re.I)),
    ("Server", re.compile(r"server|poweredge", re.I)),
    ("Monitor", re.compile(r"monitor|display", re.I)),
    ("Storage", re.compile(r"storage|powerstore|powerscale|powerflex", re.I)),
    ("Networking", re.compile(r"switch|networking|ethernet", re.I)),
    ("Accessory", re.compile(r"dock|adapter|keyboard|mouse|headset|webcam|bag|battery", re.I)),
)

PREDICATE_TO_ATTRIBUTE = {
    "PRICE": "price",
    "PRICE_GBP": "price",
    "SALE_PRICE": "price",
    "DELL_PRICE": "price",
    "LIST_PRICE": "list_price",
    "ORIGINAL_PRICE": "list_price",
    "PRICE_EX_VAT": "price_ex_vat",
    "DISCOUNT": "discount",
    "DISCOUNT_PERCENT": "discount_percent",
    "CURRENCY": "currency",
    "MODEL": "model",
    "ORDER_CODE": "order_code",
    "SKU": "order_code",
    "MPN": "part_number",
    "PART_NUMBER": "part_number",
    "BRAND": "brand",
    "FAMILY": "family",
    "PRODUCT_CATEGORY": "product_category",
    "CPU": "processor",
    "PROCESSOR": "processor",
    "GPU": "graphics",
    "MEMORY": "memory",
    "RAM": "memory",
    "STORAGE": "storage",
    "DISPLAY": "display",
    "OS": "operating_system",
    "OPERATING_SYSTEM": "operating_system",
    "WEIGHT": "weight",
    "BATTERY_LIFE": "battery_life",
    "AI_PERFORMANCE": "ai_performance",
    "NETWORKING": "networking",
    "WARRANTY_SUPPORT": "warranty",
    "WARRANTY": "warranty",
    "SUPPORT": "support",
    "SHIPPING": "shipping",
    "PROMOTION": "promotion",
    "AVAILABILITY": "availability",
    "CONDITION": "condition",
    "CUSTOMER_RATING": "rating",
    "RATING": "rating",
    "AVERAGE_RATING": "rating",
    "REVIEW_COUNT": "review_count",
    "DECLARED_REVIEW_COUNT": "review_count",
    "FINANCING": "financing",
    "REWARD": "rewards",
    "REWARD_EARN": "rewards",
}


PRODUCT_FIELD_WEIGHTS: dict[str, float] = {
    "name": 1.2,
    "product_url": 1.0,
    "model": 0.7,
    "order_code": 0.8,
    "price": 1.0,
    "processor": 1.0,
    "graphics": 0.9,
    "memory": 0.8,
    "storage": 0.8,
    "display": 0.7,
    "operating_system": 0.6,
    "rating": 0.35,
    "review_count": 0.35,
}


def adaptive_product_completeness(attributes: dict[str, Any]) -> tuple[float, list[str], list[str]]:
    """Score only fields that are applicable to the observed product/evidence.

    Servers do not need a display, monitors do not need an operating system, and a
    non-commerce support record should not fail because no live price is exposed.
    Identity and any fields advertised by the source remain required.
    """
    attrs = dict(attributes or {})
    values = {
        "name": attrs.get("name") or attrs.get("product_name"),
        "product_url": attrs.get("product_url") or attrs.get("url"),
        "model": attrs.get("model"),
        "order_code": attrs.get("order_code"),
        "price": attrs.get("price") or attrs.get("current_price"),
        "processor": attrs.get("processor") or attrs.get("cpu"),
        "graphics": attrs.get("graphics") or attrs.get("gpu"),
        "memory": attrs.get("memory"),
        "storage": attrs.get("storage"),
        "display": attrs.get("display"),
        "operating_system": attrs.get("operating_system") or attrs.get("os"),
        "rating": attrs.get("rating"),
        "review_count": attrs.get("review_count"),
    }
    context = " ".join(
        str(attrs.get(key) or "")
        for key in (
            "name", "product_name", "family", "product_category", "category", "description",
            "raw_text", "raw_card_text", "source_url", "product_url", "url", "evidence_type",
        )
    ).casefold()
    applicable = {"name", "product_url"}
    if any(values.get(key) for key in ("model", "order_code", "part_number")) or re.search(r"\b(?:model|sku|order code|part number)\b", context):
        applicable.update({"model", "order_code"})

    commerce = bool(values["price"]) or bool(re.search(r"[£$€₹¥]", context)) or bool(
        re.search(r"\b(?:starting at|current price|list price|price|save|discount|excluding vat|per month|special offer)\b", context)
    )
    if commerce:
        applicable.add("price")

    monitor = bool(re.search(r"\b(?:monitor|display|ultrasharp)\b", context))
    server_or_storage = bool(re.search(r"\b(?:poweredge|server|rack|tower server|powerscale|powerstore|storage array|network switch)\b", context))
    client_device = bool(re.search(r"\b(?:laptop|notebook|desktop|workstation|precision|latitude|inspiron|xps|alienware|optiplex|dell pro|max)\b", context))
    component_or_accessory = bool(re.search(r"\b(?:adapter|dock|keyboard|mouse|headset|cable|battery|accessory|component)\b", context))

    advertised = {
        field for field in ("processor", "graphics", "memory", "storage", "display", "operating_system")
        if values.get(field) or re.search(
            {
                "processor": r"\b(?:processor|cpu|intel|amd|xeon|ryzen)\b",
                "graphics": r"\b(?:graphics|gpu|nvidia|radeon|rtx|arc)\b",
                "memory": r"\b(?:memory|ram|ddr\d)\b",
                "storage": r"\b(?:storage|ssd|nvme|hdd|hard drive)\b",
                "display": r"\b(?:display|screen|inch|oled|uhd|qhd|fhd)\b",
                "operating_system": r"\b(?:operating system|windows|ubuntu|linux|rhel)\b",
            }[field],
            context,
        )
    }
    applicable.update(advertised)
    if monitor:
        applicable.add("display")
    elif server_or_storage:
        applicable.update({"processor", "memory", "storage"})
    elif client_device and not component_or_accessory:
        applicable.update({"processor", "memory", "storage"})
        if re.search(r"\b(?:laptop|notebook|workstation|precision|xps|alienware|dell pro|max)\b", context):
            applicable.add("graphics")
        if re.search(r"\b(?:laptop|notebook|xps|latitude|inspiron|alienware)\b", context):
            applicable.add("display")
        applicable.add("operating_system")

    review_available = bool(values["rating"] or values["review_count"]) or bool(re.search(r"\b(?:reviews?|ratings?|stars?)\b", context))
    if review_available:
        applicable.update({"rating", "review_count"})

    # A source may expose only one stable identity token. Do not require both model
    # and order code when one is present and the other is not advertised.
    if "model" in applicable and "order_code" in applicable:
        if values["model"] and not re.search(r"\b(?:order code|sku|part number)\b", context):
            applicable.discard("order_code")
        elif values["order_code"] and not re.search(r"\bmodel\b", context):
            applicable.discard("model")

    ordered = [field for field in PRODUCT_FIELD_WEIGHTS if field in applicable]
    total = sum(PRODUCT_FIELD_WEIGHTS[field] for field in ordered)
    found = sum(PRODUCT_FIELD_WEIGHTS[field] for field in ordered if values.get(field) not in (None, "", [], {}))
    missing = [field for field in ordered if values.get(field) in (None, "", [], {})]
    return (round(found / total, 4) if total else 1.0, missing, ordered)


@dataclass(slots=True)
class ProductRecord:
    name: str
    source_url: str
    product_url: str = ""
    model: str = ""
    order_code: str = ""
    part_number: str = ""
    family: str = ""
    category: str = ""
    brand: str = ""
    current_price: str = ""
    list_price: str = ""
    price_ex_vat: str = ""
    currency: str = ""
    discount: str = ""
    discount_percent: str = ""
    rating: str = ""
    review_count: str = ""
    condition: str = ""
    availability: str = ""
    seller: str = "Dell"
    warranty: str = ""
    support: str = ""
    shipping: str = ""
    promotion: str = ""
    financing: str = ""
    rewards: str = ""
    processor: str = ""
    graphics: str = ""
    memory: str = ""
    storage: str = ""
    display: str = ""
    operating_system: str = ""
    networking: str = ""
    weight: str = ""
    battery_life: str = ""
    ai_performance: str = ""
    image: str = ""
    description: str = ""
    evidence_type: str = "rendered_product_card"
    raw_text: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)

    def canonical_identity(self) -> str:
        # A Dell order code/SKU identifies a purchasable configuration. Prefer it
        # over a shared model landing URL so different prices/configurations are
        # not collapsed into one Product node.
        if self.order_code:
            return f"product-order:{_slug(self.order_code)}"
        if self.part_number:
            return f"product-part:{_slug(self.part_number)}"
        if self.product_url and is_product_detail_url(self.product_url, self.source_url):
            return f"product-url:{canonicalize_url(self.product_url, self.source_url)}"
        if self.model:
            return f"product-model:{_slug(self.brand + '-' + self.model)}"
        return f"product:{_slug(_canonical_product_name(self.name))}"

    def completeness_fields(self) -> dict[str, str]:
        return {
            "name": self.name,
            "product_url": self.product_url,
            "model": self.model,
            "order_code": self.order_code,
            "price": self.current_price,
            "processor": self.processor,
            "graphics": self.graphics,
            "memory": self.memory,
            "storage": self.storage,
            "display": self.display,
            "operating_system": self.operating_system,
            "rating": self.rating,
            "review_count": self.review_count,
        }

    def completeness_score(self) -> float:
        score, _, _ = adaptive_product_completeness({
            **self.completeness_fields(),
            "name": self.name,
            "product_name": self.name,
            "family": self.family,
            "product_category": self.category,
            "description": self.description,
            "raw_text": self.raw_text,
            "evidence_type": self.evidence_type,
            "source_url": self.source_url,
        })
        return score

    def completeness_details(self) -> tuple[float, list[str], list[str]]:
        return adaptive_product_completeness({
            **self.completeness_fields(),
            "name": self.name,
            "product_name": self.name,
            "family": self.family,
            "product_category": self.category,
            "description": self.description,
            "raw_text": self.raw_text,
            "evidence_type": self.evidence_type,
            "source_url": self.source_url,
        })

    def to_entity(self, index: int = 0) -> dict[str, Any]:
        attrs = {
            "url": self.product_url,
            "source_url": self.source_url,
            "brand": self.brand,
            "family": self.family,
            "product_category": self.category,
            "model": self.model,
            "order_code": self.order_code,
            "part_number": self.part_number,
            "price": self.current_price,
            "current_price": self.current_price,
            "list_price": self.list_price,
            "price_ex_vat": self.price_ex_vat,
            "currency": self.currency,
            "discount": self.discount,
            "discount_percent": self.discount_percent,
            "rating": self.rating,
            "review_count": self.review_count,
            "condition": self.condition,
            "availability": self.availability,
            "seller": self.seller,
            "warranty": self.warranty,
            "support": self.support,
            "shipping": self.shipping,
            "promotion": self.promotion,
            "financing": self.financing,
            "rewards": self.rewards,
            "processor": self.processor,
            "cpu": self.processor,
            "graphics": self.graphics,
            "gpu": self.graphics,
            "memory": self.memory,
            "storage": self.storage,
            "display": self.display,
            "operating_system": self.operating_system,
            "networking": self.networking,
            "weight": self.weight,
            "battery_life": self.battery_life,
            "ai_performance": self.ai_performance,
            "image": self.image,
            "description": self.description,
            "evidence_type": self.evidence_type,
            "completeness_score": self.completeness_score(),
            "missing_fields": self.completeness_details()[1],
            "applicable_completeness_fields": self.completeness_details()[2],
            "raw_card_text": self.raw_text[:20000],
            **(self.attributes or {}),
        }
        return {
            "key": f"product_record_{index}",
            "node_key": self.canonical_identity(),
            "type": "Product",
            "name": self.name[:1000],
            "url": self.product_url,
            "attributes": attrs,
        }

    def facts(self, local_key: str) -> list[dict[str, Any]]:
        values: list[tuple[str, str, str, dict[str, Any]]] = [
            ("BRAND", self.brand, "", {}),
            ("FAMILY", self.family, "", {}),
            ("PRODUCT_CATEGORY", self.category, "", {}),
            ("MODEL", self.model, "", {}),
            ("ORDER_CODE", self.order_code, "", {}),
            ("PART_NUMBER", self.part_number, "", {}),
            (price_predicate(self.currency), self.current_price, self.currency, {"volatile": True, "price_type": "current"}),
            ("LIST_PRICE", self.list_price, self.currency, {"volatile": True, "price_type": "list"}),
            ("PRICE_EX_VAT", self.price_ex_vat, self.currency, {"volatile": True, "includes_vat": False}),
            ("DISCOUNT", self.discount, self.currency, {"volatile": True}),
            ("DISCOUNT_PERCENT", self.discount_percent, "%", {"volatile": True}),
            ("CPU", self.processor, "", {}),
            ("GPU", self.graphics, "", {}),
            ("MEMORY", self.memory, "", {}),
            ("STORAGE", self.storage, "", {}),
            ("DISPLAY", self.display, "", {}),
            ("OS", self.operating_system, "", {}),
            ("NETWORKING", self.networking, "", {}),
            ("WEIGHT", self.weight, "", {}),
            ("BATTERY_LIFE", self.battery_life, "", {}),
            ("AI_PERFORMANCE", self.ai_performance, "TOPS", {}),
            ("CUSTOMER_RATING", self.rating, "stars", {"review_count": self.review_count}),
            ("REVIEW_COUNT", self.review_count, "count", {}),
            ("CONDITION", self.condition, "", {}),
            ("AVAILABILITY", self.availability, "", {"volatile": True}),
            ("SELLER", self.seller, "", {}),
            ("WARRANTY", self.warranty, "", {}),
            ("SUPPORT", self.support, "", {}),
            ("SHIPPING", self.shipping, "", {"volatile": True}),
            ("PROMOTION", self.promotion, "", {"volatile": True}),
            ("FINANCING", self.financing, "", {"volatile": True}),
            ("REWARD", self.rewards, self.currency, {"volatile": True}),
        ]
        output: list[dict[str, Any]] = []
        for predicate, value, unit, qualifiers in values:
            if value in (None, "", [], {}):
                continue
            output.append({
                "subject_key": local_key,
                "predicate": predicate,
                "value": str(value),
                "unit": unit,
                "confidence": 0.96 if self.evidence_type in {"rendered_product_card", "public_json_ld_product"} else 0.84,
                "qualifiers": {
                    "extraction": self.evidence_type,
                    "source_url": self.source_url,
                    **qualifiers,
                },
            })
        return output


def _clean(value: Any, limit: int = 20000) -> str:
    return SPACE_RE.sub(" ", str(value or "")).strip()[:limit]


def _line_clean(value: Any) -> str:
    text = str(value or "").replace("\u00a0", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _slug(value: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "-", str(value or "").casefold()).strip("-")
    return clean[:220] or hashlib.sha256(str(value or "").encode("utf-8", errors="ignore")).hexdigest()[:24]


def _canonical_product_name(name: str) -> str:
    value = _clean(name, 1000)
    value = re.sub(r"^(?:Compare|New)\s+", "", value, flags=re.I)
    value = re.sub(r"\s+(?:with other products|Explore Options|Configure and buy|View Product Page)$", "", value, flags=re.I)
    value = re.sub(r"^Dell\s+", "", value, flags=re.I)
    return _clean(value, 1000)


def _decimal_text(value: str) -> str:
    raw = str(value or "").replace(",", "").strip()
    if not raw:
        return ""
    try:
        parsed = Decimal(raw)
    except InvalidOperation:
        return raw
    result = f"{parsed:.2f}"
    return result.rstrip("0").rstrip(".")


def _first_match(regex: re.Pattern[str], text: str, group: int = 0) -> str:
    match = regex.search(text or "")
    return _clean(match.group(group), 1000) if match else ""


def _all_matches(regex: re.Pattern[str], text: str, group: int = 0) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    for match in regex.finditer(text or ""):
        value = _clean(match.group(group), 1000)
        marker = value.casefold()
        if value and marker not in seen:
            seen.add(marker)
            values.append(value)
    return values


def infer_family(name: str, url: str = "") -> str:
    haystack = f"{name} {url}"
    for family, pattern in FAMILY_PATTERNS:
        if pattern.search(haystack):
            return family
    return ""


def infer_category(name: str, url: str = "", text: str = "") -> str:
    haystack = f"{name} {url} {text[:1000]}"
    for category, pattern in CATEGORY_PATTERNS:
        if pattern.search(haystack):
            return category
    return ""


def _best_product_url(raw: dict[str, Any], source_url: str, name: str) -> str:
    """Choose only a Dell product-detail URL, never an image or generic link."""
    candidates: list[str] = []
    for key in ("productUrl", "product_url", "url", "href", "canonical"):
        if raw.get(key):
            candidates.append(str(raw.get(key)))
    for item in raw.get("links") or []:
        if not isinstance(item, dict):
            continue
        href = str(item.get("href") or item.get("url") or "")
        label = _clean(item.get("label") or item.get("text") or "", 1000)
        if not href:
            continue
        if is_product_detail_url(href, source_url) or (_canonical_product_name(name) and _canonical_product_name(name).casefold() in label.casefold()):
            candidates.insert(0, href)
        else:
            candidates.append(href)
    for candidate in candidates:
        absolute = canonicalize_url(candidate, source_url)
        if is_product_detail_url(absolute, source_url):
            return absolute
    # On an actual product-detail page the canonical page itself is valid and is
    # a better identity than an unrelated card/image resource.
    if is_product_detail_url(source_url):
        return canonicalize_url(source_url)
    return ""


def _name_from_card(raw: dict[str, Any], text: str) -> str:
    explicit = _clean(raw.get("name") or raw.get("title") or raw.get("productName") or raw.get("product_name"), 1000)
    if explicit and not NOISE_NAME_RE.match(explicit):
        return re.sub(r"^New\s+", "", explicit, flags=re.I).strip()
    headings = raw.get("headings") if isinstance(raw.get("headings"), list) else []
    for value in headings:
        candidate = _clean(value.get("text") if isinstance(value, dict) else value, 1000)
        if candidate and not NOISE_NAME_RE.match(candidate) and len(candidate) < 220:
            return re.sub(r"^New\s+", "", candidate, flags=re.I).strip()
    lines = [line.strip() for line in _line_clean(text).splitlines() if line.strip()]
    for line in lines:
        match = COMPARE_START_RE.match(line)
        if match:
            return re.sub(r"^New\s+", "", _clean(match.group(1), 1000), flags=re.I).strip()
    for index, line in enumerate(lines):
        if ORDER_CODE_RE.search(line) or MODEL_RE.search(line):
            for previous in reversed(lines[max(0, index - 4):index]):
                if len(previous) <= 220 and not ACTION_ONLY_RE.match(previous) and not NOISE_NAME_RE.match(previous):
                    return re.sub(r"^New\s+", "", previous, flags=re.I).strip()
    for line in lines:
        if 3 <= len(line) <= 220 and re.search(r"\b(?:Dell|XPS|Alienware|Inspiron|Precision|Latitude|PowerEdge|Monitor|Laptop|Desktop|Workstation)\b", line, re.I):
            if not ACTION_ONLY_RE.match(line):
                return re.sub(r"^New\s+", "", line, flags=re.I).strip()
    return ""


def _extract_prices(text: str, raw: dict[str, Any], source_url: str = "") -> dict[str, str]:
    """Extract product price fields without mistaking finance/discount/reward values.

    Dell cards frequently contain four or more pound amounts: list price, current
    price, monthly finance, discount and rewards.  The older last-number heuristic
    incorrectly selected values such as ``£199.20 off`` as the product price.
    This implementation classifies every amount by its local line context first.
    """
    flattened = _line_clean(text)
    lines = [line.strip() for line in flattened.splitlines() if line.strip()]
    result = {
        "current_price": "",
        "list_price": "",
        "price_ex_vat": "",
        "discount": "",
        "discount_percent": "",
        "currency": infer_market_context(
            source_url,
            explicit_currency=raw.get("currency") or raw.get("priceCurrency"),
            evidence_text=text,
        ).currency,
    }
    for key, target in (("price", "current_price"), ("currentPrice", "current_price"), ("dellPrice", "current_price"),
                        ("salePrice", "current_price"), ("listPrice", "list_price"), ("originalPrice", "list_price"),
                        ("priceExVat", "price_ex_vat")):
        if raw.get(key) not in (None, "", [], {}):
            token = str(raw.get(key))
            match = PRICE_TOKEN_RE.search(token)
            result[target] = _decimal_text(match.group(1) if match else token)

    candidates: list[dict[str, Any]] = []
    for index, line in enumerate(lines):
        for match in PRICE_TOKEN_RE.finditer(line):
            value = _decimal_text(match.group(1))
            if not value:
                continue
            previous = lines[index - 1].casefold() if index > 0 else ""
            context = f"{previous} | {line.casefold()}"
            same = line.casefold()
            kind = "unlabelled"
            if re.search(r"excluding\s+vat", same):
                kind = "ex_vat"
            elif re.search(r"(?:per month|/month|over\s+\d{1,3}\s+months?|paypal credit|as low as)", same):
                kind = "finance"
            elif re.search(r"(?:dell rewards?|cashback|reward)", same):
                kind = "reward"
            elif re.search(r"(?:save\s+[£$€₹¥]|[£$€₹¥]\s*[\d,.]+\s+off|off select configuration|discount)", same):
                kind = "discount"
            elif re.search(r"(?:original price|list price|was\s*[£$€₹¥]|rrp)", context):
                kind = "list"
            elif re.search(r"(?:dell price|sale price|now\s*[£$€₹¥]|base model from|starting (?:at|from)|from\s*[£$€₹¥])", context):
                kind = "current"
            candidates.append({"value": value, "kind": kind, "index": index, "line": line, "same": same})

    vat = VAT_RE.search(flattened)
    if vat:
        result["price_ex_vat"] = _decimal_text(vat.group(1))
    save = SAVE_RE.search(flattened)
    if save:
        result["discount"] = _decimal_text(save.group(1))
        result["discount_percent"] = save.group(2) or ""
    else:
        off = next((item for item in candidates if item["kind"] == "discount"), None)
        if off:
            result["discount"] = off["value"]
        if percent := PERCENT_OFF_RE.search(flattened):
            result["discount_percent"] = percent.group(1)

    if not result["list_price"]:
        labelled = next((item["value"] for item in candidates if item["kind"] == "list"), "")
        result["list_price"] = labelled
    if not result["current_price"]:
        labelled = next((item["value"] for item in candidates if item["kind"] == "current"), "")
        result["current_price"] = labelled

    usable = [item["value"] for item in candidates if item["kind"] == "unlabelled"]
    # Preserve order while removing exact repeats caused by nested DOM text.
    usable = list(dict.fromkeys(usable))
    if not result["current_price"] and usable:
        if len(usable) >= 2 and result["discount"]:
            # Dell configuration cards commonly show list/current prices as two
            # consecutive unlabelled values followed by an explicit saving.
            try:
                first, second, saving = map(Decimal, (usable[0], usable[1], result["discount"]))
                if abs((first - second) - saving) <= Decimal("1.01") and first >= second:
                    result["list_price"], result["current_price"] = usable[0], usable[1]
                else:
                    result["current_price"] = usable[0]
            except InvalidOperation:
                result["current_price"] = usable[0]
        else:
            result["current_price"] = usable[0]
    if not result["list_price"] and len(usable) >= 2 and result["current_price"] == usable[1]:
        result["list_price"] = usable[0]
    if result["current_price"] and result["list_price"] == result["current_price"]:
        result["list_price"] = ""
    return result


def _extract_line(regex: re.Pattern[str], text: str) -> str:
    values = _all_matches(regex, text, 0)
    return " | ".join(values[:6])


def parse_product_card(raw: dict[str, Any], source_url: str, evidence_type: str = "rendered_product_card") -> ProductRecord | None:
    text = _line_clean(raw.get("text") or raw.get("raw_text") or raw.get("content") or "")
    name = _name_from_card(raw, text)
    if not name:
        return None
    name = re.sub(r"^(?:(?:Configure and buy|Compare|New)\s+)+", "", name, flags=re.I).strip()
    name = re.sub(r"(?:\s*\|\s*Dell UK){2,}$", " | Dell UK", name, flags=re.I)
    # Reject legal/finance/page-chrome text that can precede an order code in a
    # catalogue snapshot. Structured Product JSON-LD gets a narrowly-scoped
    # exception for commercial names containing an alphanumeric model token.
    if not valid_product_name(name, structured=evidence_type == "public_json_ld_product"):
        return None

    product_url = _best_product_url(raw, source_url, name)
    model = _clean(raw.get("model") or _first_match(MODEL_RE, text, 1), 200)
    order_code = _clean(raw.get("orderCode") or raw.get("order_code") or raw.get("sku") or _first_match(ORDER_CODE_RE, text, 1), 240)
    part_number = _clean(raw.get("partNumber") or raw.get("part_number") or raw.get("mpn"), 240)
    prices = _extract_prices(text, raw, source_url)
    rating = _clean(raw.get("rating") or _first_match(RATING_RE, text, 1), 40)
    review_count = _clean(raw.get("reviewCount") or raw.get("review_count") or _first_match(RATING_COUNT_RE, text, 1), 40).replace(",", "")
    family = _clean(raw.get("family") or infer_family(name, product_url), 200)
    category = _clean(raw.get("category") or infer_category(name, product_url, text), 200)
    brand_value = raw.get("brand")
    if isinstance(brand_value, dict):
        brand_value = brand_value.get("name")
    brand = _clean(brand_value, 100)
    if not brand and re.search(r"\b(?:Dell|XPS|Alienware|Inspiron|Precision|Latitude|OptiPlex|PowerEdge|PowerStore|PowerScale|PowerFlex|UltraSharp)\b", name, re.I):
        brand = "Dell"
    image = _clean(raw.get("image") or raw.get("imageUrl") or raw.get("image_url"), 4000)
    if not image:
        images = raw.get("images") if isinstance(raw.get("images"), list) else []
        if images:
            first = images[0]
            image = _clean(first.get("src") if isinstance(first, dict) else first, 4000)

    finance_match = FINANCE_RE.search(text)
    financing = ""
    if finance_match:
        financing = _clean(finance_match.group(0), 1000)
    reward_match = REWARD_RE.search(text)
    rewards = _decimal_text(reward_match.group(1)) if reward_match else ""
    weight_match = WEIGHT_RE.search(text)
    weight = f"{weight_match.group(1)} {weight_match.group(2)}" if weight_match else ""
    battery_match = BATTERY_RE.search(text)
    battery_life = f"{battery_match.group(1)} hours" if battery_match else ""
    tops_match = TOPS_RE.search(text)
    ai_performance = tops_match.group(1) if tops_match else ""
    condition = _clean(raw.get("condition") or _first_match(CONDITION_RE, text, 1), 120)
    availability = _clean(raw.get("availability") or _first_match(AVAILABILITY_RE, text, 1), 220)
    warranty = _clean(raw.get("warranty") or _extract_line(WARRANTY_RE, text), 1500)
    shipping_lines = [line for line in text.splitlines() if re.search(r"free delivery|free shipping|delivery by|ships? in|estimated delivery", line, re.I)]
    promotion_lines = [line for line in text.splitlines() if re.search(r"special offer|save\s+[£$€₹¥]|%\s*off|coupon|promotion|limited time|price match", line, re.I)]

    record = ProductRecord(
        name=name,
        source_url=source_url,
        product_url=product_url,
        model=model,
        order_code=order_code,
        part_number=part_number,
        family=family,
        category=category,
        brand=brand,
        current_price=prices["current_price"],
        list_price=prices["list_price"],
        price_ex_vat=prices["price_ex_vat"],
        currency=prices["currency"],
        discount=prices["discount"],
        discount_percent=prices["discount_percent"],
        rating=rating,
        review_count=review_count,
        condition=condition,
        availability=availability,
        seller=_clean(raw.get("seller"), 200),
        warranty=warranty,
        support=_clean(raw.get("support"), 1000),
        shipping=" | ".join(dict.fromkeys(_clean(line, 700) for line in shipping_lines if _clean(line, 700))),
        promotion=" | ".join(dict.fromkeys(_clean(line, 700) for line in promotion_lines if _clean(line, 700))),
        financing=financing,
        rewards=rewards,
        processor=_clean(raw.get("processor") or raw.get("cpu") or _extract_line(CPU_LINE_RE, text), 2000),
        graphics=_clean(raw.get("graphics") or raw.get("gpu") or _extract_line(GPU_LINE_RE, text), 2000),
        memory=_clean(raw.get("memory") or raw.get("ram") or _extract_line(MEMORY_RE, text), 1600),
        storage=_clean(raw.get("storage") or _extract_line(STORAGE_RE, text), 1600),
        display=_clean(raw.get("display") or _extract_line(DISPLAY_RE, text), 1600),
        operating_system=_clean(raw.get("operatingSystem") or raw.get("operating_system") or raw.get("os") or _extract_line(OS_LINE_RE, text), 1000),
        networking=_clean(raw.get("networking") or _extract_line(NETWORK_RE, text), 1000),
        weight=weight,
        battery_life=battery_life,
        ai_performance=ai_performance,
        image=image,
        description=_clean(raw.get("description"), 6000),
        evidence_type=evidence_type,
        raw_text=text,
        attributes={
            "dom_selector": raw.get("selector", ""),
            "dom_index": raw.get("index", ""),
            "root_kind": raw.get("rootKind", ""),
            "buttons": raw.get("buttons", []),
            "links": raw.get("links", []),
            "data_attributes": raw.get("dataAttributes", {}),
        },
    )
    # A name-only record from generic page text is too weak and creates noisy
    # Product nodes. Structured cards can be kept with URL/model/order/price/spec.
    if evidence_type == "catalog_text_fallback" and not any([
        record.product_url, record.model, record.order_code, record.current_price,
        record.processor, record.graphics, record.memory, record.storage,
    ]):
        return None
    return record


def _dedupe_records(records: Iterable[ProductRecord]) -> list[ProductRecord]:
    output: list[ProductRecord] = []
    index_by_key: dict[str, int] = {}
    for record in records:
        key = record.canonical_identity()
        if key not in index_by_key:
            index_by_key[key] = len(output)
            output.append(record)
            continue
        existing = output[index_by_key[key]]
        # Merge only non-empty values; prefer the more complete record and retain
        # both evidence descriptions in attributes.
        primary, secondary = (record, existing) if record.completeness_score() > existing.completeness_score() else (existing, record)
        for field_name in ProductRecord.__dataclass_fields__:
            if field_name in {"attributes", "raw_text"}:
                continue
            if not getattr(primary, field_name) and getattr(secondary, field_name):
                setattr(primary, field_name, getattr(secondary, field_name))
        primary.raw_text = "\n\n".join(dict.fromkeys(filter(None, [primary.raw_text, secondary.raw_text])))[:30000]
        primary.attributes = {**secondary.attributes, **primary.attributes}
        output[index_by_key[key]] = primary
    return output


def _catalog_blocks(text: str) -> list[str]:
    """Split repeated catalogue snapshots into product-sized evidence blocks."""
    lines = [line.strip() for line in _line_clean(text).splitlines() if line.strip()]
    footer_re = re.compile(
        r"^(?:First page|Previous page|Next page|Last page|Showing page|Price Match|Dell Rewards|"
        r"Learn More About Dell|FAQs?:|Manage|Site Map|Account|Support Home|Connect with Us|"
        r"Our Offerings|Our Company|Resources|Privacy Centre|Copyright|Terms & Conditions|"
        r"===== PUBLIC HTML|===== RENDERED BROWSER)", re.I
    )
    compare_re = COMPARE_START_RE
    order_start_re = re.compile(r"^(?:Configure and buy\s+)?(.+)$", re.I)

    blocks: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        if compare_re.match(line):
            if current:
                blocks.append(current)
            current = [line]
            continue
        if current:
            if footer_re.match(line):
                blocks.append(current)
                current = []
                continue
            current.append(line)
            # A completed card always ends at its product action.  Ending here
            # avoids absorbing page footer/legal text or a deal-configuration grid.
            if re.match(r"^(?:Explore Options|Configure and buy)\b", line, re.I) and any(
                MODEL_RE.search(value) or ORDER_CODE_RE.search(value) or PRICE_TOKEN_RE.search(value)
                for value in current
            ):
                blocks.append(current)
                current = []
            elif len(current) >= 100:
                blocks.append(current)
                current = []
    if current:
        blocks.append(current)

    # Configuration/deal cards use Product Name + Order Code instead of Compare.
    starts: list[int] = []
    for index, line in enumerate(lines[:-1]):
        if ORDER_CODE_RE.search(lines[index + 1]):
            candidate = order_start_re.sub(r"\1", line).strip()
            if 3 <= len(candidate) <= 220 and not NOISE_NAME_RE.match(candidate):
                starts.append(index)
    for position, start_index in enumerate(starts):
        natural_end = starts[position + 1] if position + 1 < len(starts) else min(len(lines), start_index + 70)
        end_index = natural_end
        for cursor in range(start_index + 2, natural_end):
            line = lines[cursor]
            if footer_re.match(line) or compare_re.match(line):
                end_index = cursor
                break
            if re.match(r"^Configure and buy\b", line, re.I) and cursor > start_index + 2:
                end_index = cursor + 1
                break
        block = lines[start_index:end_index]
        if len(" ".join(block)) >= 30:
            blocks.append(block)

    rendered: list[str] = []
    seen: set[str] = set()
    for block in blocks:
        text_block = "\n".join(block).strip()
        if not text_block or len(text_block) > 5000:
            continue
        # Reject a candidate that accidentally spans multiple distinct products.
        compare_count = len(COMPARE_START_RE.findall(text_block))
        order_count = len(ORDER_CODE_RE.findall(text_block))
        model_count = len(MODEL_RE.findall(text_block))
        if compare_count > 1 or order_count > 1 or model_count > 1:
            continue
        marker = hashlib.sha256(SPACE_RE.sub(" ", text_block).casefold().encode("utf-8", errors="ignore")).hexdigest()
        if marker not in seen:
            seen.add(marker)
            rendered.append(text_block)
    return rendered


def _link_for_block(page: CrawlPage, name: str, model: str, order_code: str) -> str:
    tokens = [value.casefold() for value in (_canonical_product_name(name), model, order_code) if value]
    scored: list[tuple[int, str]] = []
    for link in page.links:
        candidate = canonicalize_url(link.url, page.canonical_url)
        if not candidate:
            continue
        haystack = f"{link.label} {candidate}".casefold()
        score = 0
        if is_product_detail_url(candidate, page.canonical_url):
            score += 8
        for token in tokens:
            if token and token in haystack:
                score += 10
        if score:
            scored.append((score, candidate))
    return max(scored, default=(0, ""))[1]


def records_from_catalog_text(page: CrawlPage) -> list[ProductRecord]:
    records: list[ProductRecord] = []
    # Visible text is preferred; structured evidence may contain the same content
    # repeated. Cap the fallback input only after all rendered product-card blocks
    # have been found by their deterministic markers.
    text = page.visible_text or ""
    text = re.split(r"\n+===== (?:PUBLIC HTML STRUCTURED EVIDENCE|RENDERED BROWSER STRUCTURED EVIDENCE|DELL AIA VISION EVIDENCE) =====", text, maxsplit=1)[0]
    for block in _catalog_blocks(text):
        raw: dict[str, Any] = {"text": block}
        record = parse_product_card(raw, page.canonical_url, "catalog_text_fallback")
        if not record:
            continue
        record.product_url = record.product_url or _link_for_block(page, record.name, record.model, record.order_code)
        records.append(record)
    return _dedupe_records(records)


def records_from_browser_dom(page: CrawlPage) -> list[ProductRecord]:
    metadata = page.metadata if isinstance(page.metadata, dict) else {}
    dom = metadata.get("browser_structured_dom") if isinstance(metadata.get("browser_structured_dom"), dict) else {}
    cards = dom.get("productCards") if isinstance(dom.get("productCards"), list) else []
    records = [
        record
        for record in (parse_product_card(card, page.canonical_url, "rendered_product_card") for card in cards if isinstance(card, dict))
        if record is not None
    ]
    return _dedupe_records(records)


def records_from_json_ld(page: CrawlPage) -> list[ProductRecord]:
    metadata = page.metadata if isinstance(page.metadata, dict) else {}
    enrichment = metadata.get("html_enrichment") if isinstance(metadata.get("html_enrichment"), dict) else {}
    schema = enrichment.get("schema_entities") if isinstance(enrichment.get("schema_entities"), dict) else {}
    records: list[ProductRecord] = []

    property_map = {
        "processor": "processor", "cpu": "processor",
        "graphics": "graphics", "graphics card": "graphics", "gpu": "graphics",
        "memory": "memory", "ram": "memory", "system memory": "memory",
        "storage": "storage", "hard drive": "storage", "solid state drive": "storage",
        "display": "display", "screen": "display",
        "operating system": "operatingSystem", "os": "operatingSystem",
        "model": "model", "order code": "orderCode", "sku": "sku",
        "part number": "partNumber", "warranty": "warranty", "weight": "weight",
    }

    for product in schema.get("products") or []:
        if not isinstance(product, dict):
            continue
        aggregate = product.get("aggregateRating") if isinstance(product.get("aggregateRating"), dict) else {}
        brand = product.get("brand")
        if isinstance(brand, dict):
            brand = brand.get("name")
        additional: dict[str, Any] = {}
        raw_properties = product.get("additionalProperty") or product.get("additionalProperties") or []
        if isinstance(raw_properties, dict):
            raw_properties = [raw_properties]
        for item in raw_properties if isinstance(raw_properties, list) else []:
            if not isinstance(item, dict):
                continue
            prop_name = _clean(item.get("name") or item.get("propertyID"), 200).casefold()
            prop_value = _clean(item.get("value") or item.get("description"), 2000)
            target = property_map.get(prop_name)
            if target and prop_value:
                additional[target] = prop_value

        offers = product.get("offers")
        if isinstance(offers, dict):
            offer_items = [offers]
        elif isinstance(offers, list):
            offer_items = [item for item in offers if isinstance(item, dict)]
        else:
            offer_items = [{}]
        if not offer_items:
            offer_items = [{}]

        for offer_index, offer in enumerate(offer_items):
            price_spec = offer.get("priceSpecification") if isinstance(offer.get("priceSpecification"), dict) else {}
            offer_sku = offer.get("sku") or offer.get("mpn") or product.get("sku")
            raw = {
                "name": offer.get("name") or product.get("name"),
                "description": product.get("description"),
                "url": offer.get("url") or product.get("url") or product.get("@id") or page.canonical_url,
                "sku": offer_sku,
                "mpn": offer.get("mpn") or product.get("mpn"),
                "model": offer.get("model") or product.get("model") or additional.get("model"),
                "orderCode": additional.get("orderCode") or offer_sku,
                "partNumber": additional.get("partNumber") or product.get("mpn"),
                "brand": brand,
                "image": product.get("image"),
                "price": offer.get("price") or offer.get("lowPrice") or price_spec.get("price"),
                "listPrice": offer.get("highPrice") or price_spec.get("maxPrice"),
                "currency": offer.get("priceCurrency") or price_spec.get("priceCurrency"),
                "condition": offer.get("itemCondition"),
                "availability": offer.get("availability"),
                "rating": aggregate.get("ratingValue"),
                "reviewCount": aggregate.get("ratingCount") or aggregate.get("reviewCount"),
                **additional,
                "text": "\n".join(filter(None, [
                    _clean(offer.get("name") or product.get("name"), 1000),
                    _clean(product.get("description"), 6000),
                    _clean(product.get("model"), 500),
                    _clean(offer_sku, 500),
                    *[_clean(value, 2000) for value in additional.values()],
                ])),
                "json_ld_offer_index": offer_index,
            }
            record = parse_product_card(raw, page.canonical_url, "public_json_ld_product")
            if record:
                records.append(record)
    return _dedupe_records(records)


def record_from_product_detail_page(page: CrawlPage) -> ProductRecord | None:
    """Build one deterministic record from a Dell product-detail page.

    Product pages do not always render a catalogue-style card.  This fallback
    binds page-level price/spec evidence to the canonical product URL instead of
    leaving it stranded on the WebPage node.
    """
    if page.page_type != "Product" and not is_product_detail_url(page.canonical_url):
        return None
    metadata = page.metadata if isinstance(page.metadata, dict) else {}
    dom = metadata.get("browser_structured_dom") if isinstance(metadata.get("browser_structured_dom"), dict) else {}
    headings = [
        _clean(item.get("text") if isinstance(item, dict) else item, 1000)
        for item in (dom.get("headings") or [])
    ]
    headings = [value for value in headings if value]
    name = next((value for value in headings if valid_product_name(value)), "")
    if not name:
        title = re.sub(r"\s*[|\-]\s*Dell(?: Technologies)?(?: UK)?\s*$", "", page.title or "", flags=re.I).strip()
        name = title if valid_product_name(title, structured=True) else ""
    if not name:
        return None

    structured_lines: list[str] = []
    for item in dom.get("definitions") or []:
        if isinstance(item, dict):
            term = _clean(item.get("term"), 300)
            definition = _clean(item.get("definition"), 1600)
            if term and definition:
                structured_lines.append(f"{term}: {definition}")
    for table in dom.get("tables") or []:
        if not isinstance(table, dict):
            continue
        for row in table.get("rows") or []:
            if isinstance(row, list) and len(row) >= 2:
                left, right = _clean(row[0], 300), _clean(" | ".join(str(x) for x in row[1:]), 1800)
                if left and right:
                    structured_lines.append(f"{left}: {right}")
    text = "\n".join(filter(None, [page.visible_text, *structured_lines]))

    # Map labelled definition/table values into explicit fields before regex
    # fallback so specs such as CPU/GPU are not missed because Dell changed the
    # surrounding prose layout.
    labelled: dict[str, str] = {}
    aliases = {
        "processor": ("processor", "cpu"),
        "graphics": ("graphics", "gpu", "graphics card"),
        "memory": ("memory", "ram", "system memory"),
        "storage": ("storage", "hard drive", "solid state drive"),
        "display": ("display", "screen"),
        "operatingSystem": ("operating system", "os"),
        "model": ("model",),
        "orderCode": ("order code", "sku"),
        "partNumber": ("part number", "mpn"),
    }
    for line in structured_lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        norm = SPACE_RE.sub(" ", key).strip().casefold()
        for target, names in aliases.items():
            if any(norm == alias or norm.startswith(alias + " ") for alias in names):
                labelled.setdefault(target, value.strip())

    raw: dict[str, Any] = {
        "name": name,
        "url": page.canonical_url,
        "text": text,
        "headings": headings,
        **labelled,
    }
    record = parse_product_card(raw, page.canonical_url, "product_detail_page")
    return record


def extract_product_records(page: CrawlPage) -> list[ProductRecord]:
    records: list[ProductRecord] = []
    records.extend(records_from_browser_dom(page))
    records.extend(records_from_json_ld(page))
    detail_record = record_from_product_detail_page(page)
    if detail_record is not None:
        records.append(detail_record)
    # Use text fallback only when structured DOM did not capture cards, or to fill
    # missing catalogue products. The deduper merges richer records by identity.
    if page.page_type in {"ProductCatalog", "OfferCatalog", "Product"}:
        records.extend(records_from_catalog_text(page))
    return _dedupe_records(records)


def extraction_payload_for_products(page: CrawlPage, records: list[ProductRecord]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "entities": [],
        "relations": [],
        "facts": [],
        "offers": [],
        "endpoints": [],
        "product_records": [],
    }
    market_context = infer_market_context(page.canonical_url)
    for index, record in enumerate(records):
        if not record.currency:
            record.currency = market_context.currency
        local_key = f"product_record_{index}"
        entity = record.to_entity(index)
        payload["entities"].append(entity)
        payload["relations"].append({
            "source_key": "page",
            "predicate": "LISTS_PRODUCT" if page.page_type in {"ProductCatalog", "OfferCatalog"} else "DESCRIBES_PRODUCT",
            "target_key": local_key,
            "attributes": {"evidence_type": record.evidence_type, "completeness_score": record.completeness_score()},
            "confidence": 0.98,
        })
        payload["facts"].extend(record.facts(local_key))
        if record.product_url:
            payload["endpoints"].append({
                "key": f"product_endpoint_{index}",
                "label": record.name,
                "url": record.product_url,
                "purpose": "Open Dell product detail/configuration page to complete all specifications and current pricing",
                "action": "open",
                "resource_kind": "ProductDetail",
                "source": record.evidence_type,
                "relation": "HAS_PRODUCT_DETAIL",
                "priority": 2 if record.completeness_score() < 0.85 else 8,
            })
        if any([record.current_price, record.list_price, record.discount, record.promotion, record.financing, record.rewards]):
            offer_name = f"{record.name} current Dell {market_context.market} offer" if market_context.market != "GLOBAL" else f"{record.name} current Dell offer"
            payload["offers"].append({
                "name": offer_name,
                "product_key": local_key,
                "product_node_key": record.canonical_identity(),
                "product_name": record.name,
                "price": record.current_price,
                "list_price": record.list_price,
                "price_ex_vat": record.price_ex_vat,
                "currency": record.currency,
                "discount": record.discount,
                "discount_percent": record.discount_percent,
                "promotion": record.promotion,
                "financing": record.financing,
                "rewards": record.rewards,
                "market": market_context.market,
                "source_url": page.canonical_url,
                "volatile": True,
                "evidence_type": record.evidence_type,
            })
        payload["product_records"].append({
            "node_key": record.canonical_identity(),
            "name": record.name,
            "attributes": entity["attributes"],
            "facts": record.facts(local_key),
        })
    return payload


def merge_product_payload(base: dict[str, Any], product_payload: dict[str, Any]) -> dict[str, Any]:
    for key in ("entities", "relations", "facts", "offers", "endpoints", "product_records"):
        values = product_payload.get(key) if isinstance(product_payload.get(key), list) else []
        if not values:
            continue
        base.setdefault(key, [])
        base[key].extend(values)
    return base


PRODUCT_ATTRIBUTE_ALIASES: dict[str, str] = {
    # identity
    "productname": "name", "product_name": "name", "title": "name",
    "producturl": "product_url", "product_url": "product_url", "pdpurl": "product_url", "pdp_url": "product_url",
    "detailurl": "product_url", "detail_url": "product_url", "canonicalurl": "product_url", "canonical_url": "product_url",
    "modelnumber": "model", "model_number": "model", "modelname": "model", "model_name": "model",
    "ordercode": "order_code", "order_code": "order_code", "skuid": "order_code", "sku_id": "order_code",
    "partnumber": "part_number", "part_number": "part_number", "mpn": "part_number",
    # commerce
    "price": "price", "currentprice": "price", "current_price": "price", "saleprice": "price", "sale_price": "price",
    "dellprice": "price", "dell_price": "price", "pricegbp": "price", "price_gbp": "price",
    "offerprice": "price", "offer_price": "price", "finalprice": "price", "final_price": "price",
    "listprice": "list_price", "list_price": "list_price", "originalprice": "list_price", "original_price": "list_price",
    "rrp": "list_price", "msrp": "list_price", "priceexvat": "price_ex_vat", "price_ex_vat": "price_ex_vat",
    "discountpercent": "discount_percent", "discount_percent": "discount_percent", "discountpercentage": "discount_percent",
    "currency": "currency", "pricecurrency": "currency", "price_currency": "currency",
    # core specifications
    "cpu": "processor", "processor": "processor", "processormodel": "processor", "processor_model": "processor",
    "processortype": "processor", "processor_type": "processor", "cpumodel": "processor", "cpu_model": "processor",
    "gpu": "graphics", "graphics": "graphics", "graphicscard": "graphics", "graphics_card": "graphics",
    "graphicsprocessor": "graphics", "graphics_processor": "graphics", "gpumodel": "graphics", "gpu_model": "graphics",
    "ram": "memory", "memory": "memory", "systemmemory": "memory", "system_memory": "memory",
    "memorysize": "memory", "memory_size": "memory", "ramcapacity": "memory", "ram_capacity": "memory",
    "storage": "storage", "storagesize": "storage", "storage_size": "storage", "storagecapacity": "storage",
    "storage_capacity": "storage", "harddrive": "storage", "hard_drive": "storage", "ssd": "storage", "nvme": "storage",
    "display": "display", "screen": "display", "screensize": "display", "screen_size": "display",
    "displaysize": "display", "display_size": "display", "displayresolution": "display", "display_resolution": "display",
    "os": "operating_system", "operatingsystem": "operating_system", "operating_system": "operating_system",
    "network": "networking", "networking": "networking", "connectivity": "networking",
    "warranty": "warranty", "support": "support", "availability": "availability", "stockstatus": "availability",
    "stock_status": "availability", "rating": "rating", "averagerating": "rating", "average_rating": "rating",
    "reviewcount": "review_count", "review_count": "review_count", "ratingscount": "review_count", "rating_count": "review_count",
}

CANONICAL_ATTRIBUTE_PREDICATE: dict[str, str] = {
    "name": "PRODUCT_NAME", "product_url": "PRODUCT_URL", "model": "MODEL", "order_code": "ORDER_CODE",
    "part_number": "PART_NUMBER", "price": "PRICE", "list_price": "LIST_PRICE", "price_ex_vat": "PRICE_EX_VAT",
    "discount": "DISCOUNT", "discount_percent": "DISCOUNT_PERCENT", "currency": "CURRENCY",
    "processor": "CPU", "graphics": "GPU", "memory": "MEMORY", "storage": "STORAGE", "display": "DISPLAY",
    "operating_system": "OS", "networking": "NETWORKING", "warranty": "WARRANTY", "support": "SUPPORT",
    "availability": "AVAILABILITY", "rating": "CUSTOMER_RATING", "review_count": "REVIEW_COUNT",
}


def _predicate_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().casefold()).strip("_")


def normalized_product_attribute(predicate: str) -> str:
    """Map loose model/DOM field names onto the canonical Product projection.

    Dell AIA and page JSON do not always use the exact same property spelling.
    This mapper intentionally accepts common camelCase/snake_case/label variants
    but does not infer a value when the field meaning itself is ambiguous.
    """
    raw = str(predicate or "")
    direct = PREDICATE_TO_ATTRIBUTE.get(raw.upper())
    if direct:
        return direct
    token = _predicate_token(raw)
    compact = token.replace("_", "")
    if token in PRODUCT_ATTRIBUTE_ALIASES:
        return PRODUCT_ATTRIBUTE_ALIASES[token]
    if compact in PRODUCT_ATTRIBUTE_ALIASES:
        return PRODUCT_ATTRIBUTE_ALIASES[compact]

    # Conservative semantic fallbacks for labels seen in Dell specification tables.
    if any(x in token for x in ("processor", "cpu")) and "support" not in token:
        return "processor"
    if any(x in token for x in ("graphics", "gpu", "video_card", "video_adapter")):
        return "graphics"
    if any(x in token for x in ("memory", "ram")) and "gpu" not in token and "graphics" not in token:
        return "memory"
    if any(x in token for x in ("storage", "ssd", "nvme", "hard_drive", "harddisk")):
        return "storage"
    if any(x in token for x in ("display", "screen", "panel")) and "adapter" not in token:
        return "display"
    if token in {"operating_system_name", "installed_os", "preinstalled_os"}:
        return "operating_system"
    if "price" in token:
        if any(x in token for x in ("list", "original", "rrp", "msrp", "was")):
            return "list_price"
        if "vat" in token and any(x in token for x in ("ex", "excluding", "without")):
            return "price_ex_vat"
        if not any(x in token for x in ("monthly", "finance", "saving", "discount", "reward")):
            return "price"
    return ""


def _flatten_mappable_evidence(field: str, value: Any, *, depth: int = 0) -> list[tuple[str, Any, str]]:
    """Return (canonical_field, value, path) triples from an unknown payload section."""
    if depth > 3:
        return []
    mapped: list[tuple[str, Any, str]] = []
    canonical = normalized_product_attribute(field)
    if canonical and value not in (None, "", [], {}):
        if isinstance(value, dict):
            # Prefer an explicit value text rather than serialising a whole object.
            candidate = value.get("value") or value.get("text") or value.get("name") or value.get("description")
            if candidate not in (None, "", [], {}):
                mapped.append((canonical, candidate, field))
        elif isinstance(value, list):
            clean = [str(item).strip() for item in value if item not in (None, "", [], {})]
            if clean:
                mapped.append((canonical, " | ".join(dict.fromkeys(clean))[:4000], field))
        else:
            mapped.append((canonical, value, field))
    if isinstance(value, dict):
        for child_key, child_value in value.items():
            child_path = f"{field}.{child_key}" if field else str(child_key)
            mapped.extend(_flatten_mappable_evidence(child_path, child_value, depth=depth + 1))
            # Also map the final child label by itself, because wrapper names such
            # as technicalSpecifications.processor are not meaningful predicates.
            mapped.extend(_flatten_mappable_evidence(str(child_key), child_value, depth=depth + 1))
    elif isinstance(value, list):
        for index, child in enumerate(value[:200]):
            if isinstance(child, dict):
                mapped.extend(_flatten_mappable_evidence(f"{field}[{index}]", child, depth=depth + 1))
    # Stable de-duplication.
    unique: list[tuple[str, Any, str]] = []
    seen: set[tuple[str, str]] = set()
    for canonical_field, mapped_value, path in mapped:
        marker = (canonical_field, SPACE_RE.sub(" ", str(mapped_value)).strip().casefold())
        if marker in seen:
            continue
        seen.add(marker)
        unique.append((canonical_field, mapped_value, path))
    return unique


def bind_page_product_evidence(page: CrawlPage, extraction: dict[str, Any]) -> dict[str, int]:
    """Bind page-scoped/misaligned evidence to the canonical Product on a PDP.

    A model can correctly read ``RAM Capacity`` or ``currentPrice`` but emit it as
    a page fact/top-level field. Earlier builds preserved that evidence yet the
    Product projection could not use it. On a real Dell product-detail page there
    is a safe one-to-one association to the best matching Product record, so this
    pass duplicates only recognised fields onto that Product with provenance.
    Truly unknown evidence remains in ``unmapped_evidence`` and is used as a
    revisit trigger instead of being discarded.
    """
    result = {"facts_mapped": 0, "unmapped_fields_mapped": 0, "unmapped_fields_remaining": 0}
    if not isinstance(extraction, dict):
        return result
    if page.page_type != "Product" and not is_product_detail_url(page.canonical_url):
        return result
    records = [item for item in (extraction.get("product_records") or []) if isinstance(item, dict)]
    if not records:
        return result

    canonical_page = canonicalize_url(page.canonical_url)
    def record_rank(record: dict[str, Any]) -> tuple[int, float]:
        attrs = record.get("attributes") if isinstance(record.get("attributes"), dict) else {}
        product_url = canonicalize_url(str(attrs.get("product_url") or attrs.get("url") or ""), page.canonical_url)
        exact = int(bool(product_url and product_url.rstrip("/") == canonical_page.rstrip("/")))
        try:
            score = float(attrs.get("completeness_score") or 0)
        except Exception:
            score = 0.0
        return exact, score

    target = max(records, key=record_rank)
    target_node_key = str(target.get("node_key") or "")
    target_attrs = target.get("attributes") if isinstance(target.get("attributes"), dict) else {}
    target["attributes"] = target_attrs

    local_key = str(target.get("local_key") or "")
    target_entity: dict[str, Any] | None = None
    for entity in extraction.get("entities") or []:
        if not isinstance(entity, dict):
            continue
        if target_node_key and str(entity.get("node_key") or "") == target_node_key:
            target_entity = entity
            local_key = str(entity.get("key") or local_key)
            break
    if not local_key:
        return result

    def accept_value(field: str, value: Any) -> bool:
        if value in (None, "", [], {}):
            return False
        text = SPACE_RE.sub(" ", str(value)).strip()
        if not text:
            return False
        if field == "product_url":
            return is_product_detail_url(text, page.canonical_url)
        if field in {"price", "list_price", "price_ex_vat"}:
            return bool(PRICE_TOKEN_RE.search(text) or re.fullmatch(r"[0-9][0-9,]*(?:\.\d{1,2})?", text))
        return len(text) <= 5000

    copied_facts: list[dict[str, Any]] = []
    for fact in list(extraction.get("facts") or []):
        if not isinstance(fact, dict):
            continue
        subject = str(fact.get("subject_key") or fact.get("subject") or "page")
        if subject not in {"page", "source", "primary_subject", f"url:{page.canonical_url}"}:
            continue
        field = normalized_product_attribute(str(fact.get("predicate") or fact.get("field") or ""))
        value = fact.get("value")
        if not field or not accept_value(field, value):
            continue
        qualifiers = fact.get("qualifiers") if isinstance(fact.get("qualifiers"), dict) else {}
        copied = {
            **fact,
            "subject_key": local_key,
            "predicate": (price_predicate(infer_market_context(page.canonical_url, explicit_currency=fact.get("unit"), evidence_text=str(value)).currency)
                          if field == "price" else CANONICAL_ATTRIBUTE_PREDICATE.get(field, str(fact.get("predicate") or field).upper())),
            "qualifiers": {**qualifiers, "mapped_from_page_fact": True, "source_url": page.canonical_url},
            "confidence": min(0.92, float(fact.get("confidence") or 0.72)),
        }
        copied_facts.append(copied)
        if target_attrs.get(field) in (None, "", [], {}):
            target_attrs[field] = SPACE_RE.sub(" ", str(value)).strip()[:5000]
        result["facts_mapped"] += 1

    unresolved: list[Any] = []
    mapped_evidence_fields: list[str] = []
    for item in extraction.get("unmapped_evidence") or []:
        if not isinstance(item, dict):
            unresolved.append(item)
            continue
        field = str(item.get("field") or "")
        value = item.get("value")
        matches = _flatten_mappable_evidence(field, value)
        accepted = 0
        for canonical_field, mapped_value, path in matches:
            if not accept_value(canonical_field, mapped_value):
                continue
            copied_facts.append({
                "subject_key": local_key,
                "predicate": (price_predicate(infer_market_context(page.canonical_url, evidence_text=str(mapped_value)).currency)
                              if canonical_field == "price" else CANONICAL_ATTRIBUTE_PREDICATE.get(canonical_field, canonical_field.upper())),
                "value": SPACE_RE.sub(" ", str(mapped_value)).strip()[:5000],
                "unit": (infer_market_context(page.canonical_url, evidence_text=str(mapped_value)).currency
                         if canonical_field in {"price", "list_price", "price_ex_vat"} else ""),
                "confidence": 0.74,
                "qualifiers": {
                    "extraction": "mapped_unstructured_evidence",
                    "mapped_from": path,
                    "source_url": page.canonical_url,
                },
            })
            if target_attrs.get(canonical_field) in (None, "", [], {}):
                target_attrs[canonical_field] = SPACE_RE.sub(" ", str(mapped_value)).strip()[:5000]
            mapped_evidence_fields.append(path)
            accepted += 1
        if accepted:
            result["unmapped_fields_mapped"] += 1
        else:
            unresolved.append(item)

    if copied_facts:
        extraction.setdefault("facts", []).extend(copied_facts)
    extraction["unmapped_evidence"] = unresolved
    result["unmapped_fields_remaining"] = len(unresolved)
    target_attrs["unresolved_unmapped_evidence_count"] = len(unresolved)
    target_attrs["unresolved_unmapped_evidence_fields"] = [
        str(item.get("field") or "") for item in unresolved if isinstance(item, dict) and item.get("field")
    ][:100]
    if mapped_evidence_fields:
        existing = target_attrs.get("mapped_evidence_fields") if isinstance(target_attrs.get("mapped_evidence_fields"), list) else []
        target_attrs["mapped_evidence_fields"] = list(dict.fromkeys([*existing, *mapped_evidence_fields]))[:200]
        extraction.setdefault("normalization_notes", []).append(
            f"Mapped {len(mapped_evidence_fields)} previously non-canonical product field(s) onto the Dell product record."
        )

    score, missing, applicable = adaptive_product_completeness({
        **target_attrs,
        "name": target.get("name") or target_attrs.get("product_name") or "",
        "product_name": target.get("name") or target_attrs.get("product_name") or "",
        "source_url": page.canonical_url,
    })
    target_attrs["completeness_score"] = score
    target_attrs["missing_fields"] = missing
    target_attrs["applicable_completeness_fields"] = applicable
    if target_entity is not None:
        entity_attrs = target_entity.get("attributes") if isinstance(target_entity.get("attributes"), dict) else {}
        target_entity["attributes"] = {**entity_attrs, **target_attrs}
    return result
