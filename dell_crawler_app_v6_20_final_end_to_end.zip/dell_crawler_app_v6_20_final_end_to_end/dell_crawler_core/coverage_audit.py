from __future__ import annotations

"""Deterministic evidence-coverage contracts for autonomous Dell crawling."""

import re
from dataclasses import asdict, dataclass, field
from typing import Any

from .crawl_models import CrawlPage


TOPIC_PATTERNS: dict[str, tuple[str, ...]] = {
    "product name/model": (r"\bmodel\b", r"\border code\b", r"\bsku\b"),
    "configuration cards": (r"configuration\s+\d+", r"select (?:base )?configuration", r"build your own"),
    "price and savings": (r"£\s?[\d,.]+", r"\bprice\b", r"\bsave\b", r"discount"),
    "processor": (r"\bprocessor\b", r"\bcpu\b", r"intel\s+(?:core|xeon)", r"amd\s+(?:ryzen|epyc)"),
    "operating system": (r"operating system", r"windows\s+11", r"ubuntu", r"linux"),
    "graphics": (r"graphics", r"\bgpu\b", r"nvidia", r"radeon", r"intel\s+arc"),
    "memory": (r"\bmemory\b", r"\bram\b", r"ddr\d"),
    "storage": (r"\bstorage\b", r"\bssd\b", r"nvme", r"hard drive"),
    "tech specs": (r"tech(?:nical)? specs?", r"specifications?"),
    "features and design": (r"features?(?: and design)?", r"design"),
    "ratings and reviews": (r"ratings?\s*(?:&|and)\s*reviews?", r"customer(?:s)? (?:say|review)", r"stars? out of"),
    "drivers/manuals/support": (r"drivers?", r"manuals?", r"support"),
    "services": (r"\bservices?\b", r"prosupport", r"onsite service"),
    "software": (r"\bsoftware\b", r"microsoft 365", r"security software"),
    "accessories": (r"accessories", r"docking", r"adapter", r"keyboard", r"mouse"),
    "offers": (r"special offers?", r"coupon", r"promo", r"save\s+£", r"financing"),
    "ports": (r"\bports?\b", r"usb", r"thunderbolt", r"hdmi"),
    "dimensions": (r"dimensions?", r"starting weight", r"height:", r"width:", r"depth:"),
    "AI use cases": (r"use cases?", r"generative ai", r"computer vision", r"machine learning", r"inference", r"training"),
    "workloads": (r"workloads?", r"inference", r"training", r"fine[- ]?tuning", r"rag\b"),
    "PC/workstation": (r"workstations?", r"ai pc", r"dell pro max", r"precision"),
    "servers": (r"servers?", r"poweredge"),
    "networking": (r"networking", r"ethernet", r"infiniband", r"switch"),
    "security/governance": (r"security", r"governance", r"privacy", r"cyber"),
    "validated architecture": (r"reference architecture", r"validated design", r"blueprint"),
    "customer evidence": (r"customer stor(?:y|ies)", r"case study", r"customers?"),
    "FAQs": (r"\bfaq\b", r"frequently asked", r"common(?:ly)? asked questions?"),
    "resources": (r"resources?", r"brochure", r"white\s*paper", r"e-?book", r"datasheet", r"brief"),
    "title": (r".{4,}",),
    "author": (r"\bauthor\b", r"\bby\s+[A-Z]"),
    "publication date": (r"\b(?:20\d{2}|19\d{2})\b", r"published", r"updated"),
    "article body": (r".{200,}",),
    "question/problem": (r"\bproblem\b", r"\bissue\b", r"\bquestion\b"),
    "responses": (r"responses?", r"replies?", r"solution"),
    "accepted solution": (r"accepted solution", r"solution verified", r"solved"),
    # Support knowledge-base articles.
    "article title": (r".{6,}",),
    "summary/symptoms": (r"symptom", r"summary", r"this article", r"you may (?:see|experience|notice)"),
    "cause": (r"\bcause\b", r"because", r"due to", r"reason"),
    "resolution/steps": (r"resolution", r"\bsteps?\b", r"to resolve", r"follow these", r"how to", r"workaround"),
    "affected products": (r"affected products?", r"applies to", r"impacted", r"supported (?:products?|systems?|models?)"),
    "article number": (r"article number", r"\b0{2}\d{6,}\b", r"kbdoc"),
    "article type": (r"article type", r"how to", r"solution\b", r"informational"),
    "publication/last modified date": (r"last modified", r"published", r"\bversion\b", r"\b(?:20\d{2}|19\d{2})\b"),
    "version": (r"\bversion\b\s*[:\-]?\s*\d", r"\bv\d"),
    "related articles": (r"related articles?", r"see also", r"more information", r"additional resources?"),
    # Support manuals / drivers / warranty.
    "product identification": (r"service tag", r"express service code", r"identify (?:your|my) product", r"enter (?:a|your) product"),
    "drivers and downloads": (r"drivers?", r"downloads?", r"firmware", r"\bbios\b"),
    "manuals and documents": (r"manuals?", r"documentation", r"user guide", r"owner'?s manual", r"setup guide"),
    "diagnostics": (r"diagnostics?", r"scan", r"detect drivers", r"\bsupportassist\b"),
    "warranty and service": (r"warranty", r"\bservice\b", r"prosupport", r"contract", r"coverage"),
    "warranty and service options": (r"warranty", r"service options?", r"prosupport", r"onsite"),
    "parts and accessories": (r"parts?", r"spare", r"accessor", r"replacement"),
    "parts and repairs": (r"parts?", r"repairs?", r"replacement", r"self[- ]?repair"),
    "regulatory and safety": (r"regulatory", r"safety", r"compliance", r"certification"),
    "regulatory": (r"regulatory", r"safety", r"compliance", r"certification"),
    "advisories": (r"advisor", r"security update", r"vulnerabilit", r"\bcve\b"),
    "overview": (r"overview", r"about (?:this|your)", r"introduction"),
    "articles": (r"articles?", r"knowledge base", r"how to"),
    "videos": (r"videos?", r"watch", r"tutorial", r"transcript"),
    # Support video / media.
    "video title": (r".{4,}",),
    "description": (r".{20,}",),
    "transcript/captions": (r"transcript", r"caption", r"\[music\]", r"\bsubtitle"),
    "product/topic": (r"product", r"topic", r"category", r"model"),
    "related resources": (r"related", r"resources?", r"see also", r"more"),
    # Support knowledge base library / category.
    "category overview": (r"category", r"overview", r"support (?:library|topics)"),
    "self-service topics": (r"self[- ]?(?:service|support)", r"troubleshoot", r"how to", r"topics?"),
    "knowledge articles": (r"articles?", r"knowledge", r"kbdoc", r"how to"),
    "diagnostics and tools": (r"diagnostics?", r"tools?", r"supportassist", r"scan"),
    "contact and service options": (r"contact", r"service options?", r"chat", r"call", r"request"),
    "security advisories": (r"security", r"advisor", r"vulnerabilit", r"\bcve\b", r"patch"),
    # Community spaces and threads.
    "space/category name": (r".{3,}",),
    "discussion threads": (r"threads?", r"discussion", r"topics?", r"replies?", r"posts?"),
    "product areas": (r"laptop", r"desktop", r"server", r"monitor", r"storage", r"networking", r"product"),
    "pinned or knowledge articles": (r"pinned", r"knowledge", r"faq", r"how to", r"sticky"),
    "activity": (r"repl(?:y|ies)", r"views?", r"latest", r"\d+\s+(?:days?|hours?|weeks?)\s+ago", r"posted"),
    "related links": (r"related", r"see also", r"links?", r"more"),
    "thread title": (r".{4,}",),
    "product/model": (r"\bmodel\b", r"latitude|inspiron|xps|precision|optiplex|poweredge|alienware|vostro"),
    "dates": (r"\b(?:20\d{2}|19\d{2})\b", r"\d+\s+(?:days?|hours?|weeks?|months?)\s+ago", r"posted|updated"),
    # Customer stories.
    "customer/organisation": (r"customer", r"company", r"organi[sz]ation", r"\bltd\b", r"\binc\b", r"university|hospital|bank"),
    "industry": (r"industry", r"sector", r"healthcare|finance|manufacturing|retail|education|government|media"),
    "challenge": (r"challenge", r"problem", r"needed", r"struggl", r"pain point", r"objective"),
    "solution": (r"solution", r"deployed", r"implemented", r"chose dell", r"using dell"),
    "Dell products used": (r"poweredge|precision|latitude|xps|optiplex|powerstore|powerscale|powerflex|apex|vxrail|dell pro"),
    "results and outcomes": (r"results?", r"outcomes?", r"improved", r"reduced", r"increased", r"\d+%", r"savings?"),
    "quote/testimonial": (r"[\u201c\"']", r"said", r"according to", r"testimonial"),
    # Learn / glossary / educational.
    "topic/term": (r".{3,}",),
    "definition/overview": (r"\bis\b", r"refers to", r"defined as", r"means", r"overview"),
    "how it works": (r"how (?:it|they) works?", r"process", r"mechanism", r"works by"),
    "benefits": (r"benefits?", r"advantages?", r"why", r"helps?", r"enables?"),
    "use cases": (r"use cases?", r"applications?", r"scenarios?", r"examples?"),
    "related Dell products/solutions": (r"dell", r"solutions?", r"products?", r"poweredge|precision|apex"),
    "further reading": (r"learn more", r"read more", r"further", r"related", r"resources?"),
    "related Dell products/solutions ": (r"dell",),
    # Legal / policy.
    "policy/document title": (r".{4,}",),
    "policy/topic title": (r".{4,}",),
    "scope and applicability": (r"applies to", r"scope", r"this (?:policy|agreement|document)", r"these terms"),
    "key terms and clauses": (r"\bterms?\b", r"clause", r"section \d", r"conditions?", r"shall|liable|warrant"),
    "effective/updated date": (r"effective", r"last (?:updated|revised)", r"\b(?:20\d{2}|19\d{2})\b", r"version"),
    "consumer rights": (r"consumer rights?", r"right to", r"cancel", r"refund", r"statutory"),
    "contact or governance": (r"contact", r"data protection officer", r"governance", r"complaints?", r"email|address"),
    # Company pages.
    "company/topic overview": (r".{20,}",),
    "leadership or organisation": (r"leadership", r"executives?", r"ceo|coo|cfo", r"team", r"board"),
    "commitments or programmes": (r"commitment", r"programme|program", r"initiative", r"goals?", r"pledge"),
    "milestones or figures": (r"\d[\d,]*", r"milestone", r"since \d{4}", r"billion|million"),
    "contact": (r"contact", r"email", r"phone", r"address", r"get in touch"),
}


@dataclass(slots=True)
class CoverageAudit:
    score: float
    passed: bool
    status: str = "complete"
    expected_topics: list[str] = field(default_factory=list)
    applicable_topics: list[str] = field(default_factory=list)
    matched_topics: list[str] = field(default_factory=list)
    missing_topics: list[str] = field(default_factory=list)
    not_observed_topics: list[str] = field(default_factory=list)
    checks: dict[str, bool] = field(default_factory=dict)
    hard_failures: list[str] = field(default_factory=list)
    recoverable_gaps: list[str] = field(default_factory=list)
    informational_notes: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    suggested_actions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _topic_found(topic: str, text: str) -> bool:
    patterns = TOPIC_PATTERNS.get(topic, (re.escape(topic),))
    return any(re.search(pattern, text, re.I | re.S) for pattern in patterns)


def _safe_int(value: Any) -> int:
    try:
        return max(0, int(float(value or 0)))
    except Exception:
        return 0


def _exposure_text(page: CrawlPage, metadata: dict[str, Any]) -> str:
    """Signals showing that a section/resource exists even if extraction missed it."""
    parts: list[str] = []
    for control in page.controls:
        parts.extend([str(control.label or ""), str(control.context or ""), str(control.resource_kind or "")])
    for link in page.links:
        parts.extend([str(link.label or ""), str(link.relation or ""), str(link.resource_kind or ""), str(link.url or "")])
    browser_dom = metadata.get("browser_structured_dom")
    if isinstance(browser_dom, dict):
        for key in ("controls", "links", "headings", "tabs", "accordions", "buttons"):
            value = browser_dom.get(key)
            if value not in (None, "", [], {}):
                parts.append(str(value)[:200_000])
    enrichment = metadata.get("html_enrichment")
    if isinstance(enrichment, dict):
        for key in ("hidden_documents", "tables", "faqs", "videos", "schema_entities", "counts"):
            value = enrichment.get(key)
            if value not in (None, "", [], {}):
                parts.append(str(value)[:200_000])
    return "\n".join(parts)[:1_000_000]


def _access_blocked(title: str, text: str) -> bool:
    sample = f"{title}\n{text[:12000]}"
    patterns = (
        r"\baccess denied\b",
        r"\brequest blocked\b",
        r"\bforbidden\b",
        r"\bverify you are human\b",
        r"\bcaptcha\b",
        r"\bunusual traffic\b",
        r"\btemporarily blocked\b",
        r"\bsecurity challenge\b",
        r"\bthe requested url was rejected\b",
    )
    return any(re.search(pattern, sample, re.I) for pattern in patterns)


def audit_page(page: CrawlPage, *, minimum_score: float = 0.72) -> CoverageAudit:
    metadata = page.metadata if isinstance(page.metadata, dict) else {}
    archetype = metadata.get("dell_page_archetype") if isinstance(metadata.get("dell_page_archetype"), dict) else {}
    expected = list(dict.fromkeys(
        str(value).strip() for value in archetype.get("expected_topics") or [] if str(value).strip()
    ))
    text = f"{page.title}\n{page.visible_text}"[:2_000_000]
    exposure = _exposure_text(page, metadata)
    matched = [topic for topic in expected if _topic_found(topic, text)]

    # A static archetype describes possible sections, not sections guaranteed on
    # every URL. A topic becomes a retry requirement only when the rendered page
    # exposed a matching control/link/structured marker but the captured evidence
    # still lacks it. This removes false validation gaps without hiding real misses.
    exposed_but_missing = [
        topic for topic in expected
        if topic not in matched and exposure and _topic_found(topic, exposure)
    ]
    applicable = list(dict.fromkeys([*matched, *exposed_but_missing]))
    not_observed = [topic for topic in expected if topic not in applicable]

    browser_dom = metadata.get("browser_structured_dom") if isinstance(metadata.get("browser_structured_dom"), dict) else {}
    network = metadata.get("network_inventory") if isinstance(metadata.get("network_inventory"), dict) else {}
    visual = metadata.get("visual_evidence") if isinstance(metadata.get("visual_evidence"), list) else []
    candidates = _safe_int(metadata.get("vision_candidate_image_count"))
    analysed = _safe_int(metadata.get("vision_evidence_count"))
    review_metrics = metadata.get("review_metrics") if isinstance(metadata.get("review_metrics"), dict) else {}
    declared_reviews = _safe_int(review_metrics.get("declared_review_count"))
    extracted_reviews = _safe_int(metadata.get("reviews_extracted"))

    resource_types = {"Document", "PublicData", "Transcript", "BinaryAsset", "WordDocument", "Presentation", "Spreadsheet"}
    minimum_text = {
        "BinaryAsset": 1,
        "VisualAsset": 1,
        "PublicData": 20,
        "Transcript": 20,
        "Document": 80,
        "WordDocument": 80,
        "Presentation": 40,
        "Spreadsheet": 20,
    }.get(page.page_type, 250)
    blocked = _access_blocked(page.title, page.visible_text)
    reviews_reconciled = declared_reviews == 0 or extracted_reviews >= declared_reviews
    long_form = page.page_type in {"Document", "Transcript", "PublicData", "WordDocument", "Presentation"} and len(page.visible_text.strip()) >= 2_000
    summary_present = bool(metadata.get("document_summary_present"))

    checks = {
        "has_title": bool(page.title.strip()),
        "has_substantive_text": len(page.visible_text.strip()) >= minimum_text,
        "access_not_blocked": not blocked,
        "has_link_inventory": bool(page.links) or page.page_type in resource_types,
        "browser_dom_captured": (bool(browser_dom) and not browser_dom.get("capture_error")) or page.page_type in resource_types,
        "dynamic_controls_terminal": bool(metadata.get("repeatable_controls_complete", True)),
        "structured_html_captured": bool(metadata.get("html_enrichment")) or page.page_type in resource_types,
        "network_inventory_captured": bool(network) or page.page_type in resource_types,
        "visual_candidates_processed": candidates == 0 or analysed > 0,
        "reviews_reconciled": reviews_reconciled,
        # Summary is an enrichment signal. Full source text/chunks remain valid
        # evidence when the AIA model is unavailable or returns unrepairable JSON.
        "document_summary_present": not long_form or summary_present,
    }

    topic_score = (len(matched) / len(applicable)) if applicable else 1.0
    core_names = ("has_title", "has_substantive_text", "access_not_blocked")
    capture_names = ("has_link_inventory", "browser_dom_captured", "structured_html_captured", "network_inventory_captured")
    completion_names = ("dynamic_controls_terminal", "visual_candidates_processed", "reviews_reconciled")
    core_score = sum(int(checks[name]) for name in core_names) / len(core_names)
    capture_score = sum(int(checks[name]) for name in capture_names) / len(capture_names)
    completion_score = sum(int(checks[name]) for name in completion_names) / len(completion_names)
    score = round(0.45 * core_score + 0.25 * capture_score + 0.20 * topic_score + 0.10 * completion_score, 4)

    hard_failures: list[str] = []
    recoverable: list[str] = []
    informational: list[str] = []
    suggestions: list[str] = []

    if blocked:
        hard_failures.append("The captured response is an access/security challenge rather than the requested Dell content.")
        suggestions.append("DEFER_ACCESS_BLOCK")
    if not checks["has_title"]:
        hard_failures.append("No usable page title was captured.")
        suggestions.append("RETRY_PAGE_CAPTURE")
    if not checks["has_substantive_text"]:
        hard_failures.append(f"Captured text is below the minimum evidence threshold for {page.page_type}.")
        suggestions.append("RETRY_PAGE_CAPTURE")
    if exposed_but_missing:
        recoverable.append("Exposed sections still missing from captured evidence: " + ", ".join(exposed_but_missing))
        suggestions.append("REVISIT_HIGH_VALUE_CONTROLS")
    if not checks["dynamic_controls_terminal"]:
        recoverable.append("One or more repeatable controls have not reached semantic convergence.")
        suggestions.append("EXHAUST_DYNAMIC_CONTROLS")
    if not checks["browser_dom_captured"] and page.page_type not in resource_types:
        recoverable.append("Rendered DOM representation was not captured.")
        suggestions.append("RETRY_BROWSER_DOM")
    if not checks["visual_candidates_processed"]:
        recoverable.append(f"{candidates} meaningful visual candidate(s) remain without vision extraction.")
        suggestions.append("RETRY_VISION")
    if not checks["reviews_reconciled"]:
        recoverable.append(f"Review reconciliation is incomplete: declared={declared_reviews}, extracted={extracted_reviews}.")
        suggestions.append("RETRY_REVIEW_EXPANSION_OR_PUBLIC_API")
    if long_form and not summary_present:
        informational.append("Full long-form text was retained, but optional hierarchical summary enrichment is not yet available.")
        suggestions.append("RETRY_DOCUMENT_SUMMARY")
    if not_observed:
        informational.append(
            "Archetype topics not exposed by this specific page were not treated as failures: " + ", ".join(not_observed)
        )

    completion_blockers = (
        bool(exposed_but_missing)
        or not checks["dynamic_controls_terminal"]
        or not checks["reviews_reconciled"]
        or not checks["visual_candidates_processed"]
    )
    passed = not hard_failures and not completion_blockers and score >= float(minimum_score)
    status = "complete" if passed else ("terminal" if hard_failures else "recoverable")
    gaps = [*hard_failures, *recoverable]

    return CoverageAudit(
        score=score,
        passed=passed,
        status=status,
        expected_topics=expected,
        applicable_topics=applicable,
        matched_topics=matched,
        missing_topics=exposed_but_missing,
        not_observed_topics=not_observed,
        checks=checks,
        hard_failures=hard_failures,
        recoverable_gaps=recoverable,
        informational_notes=informational,
        gaps=gaps,
        suggested_actions=list(dict.fromkeys(suggestions)),
    )

