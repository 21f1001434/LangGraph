from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class DiscoveredLink:
    label: str
    url: str
    ref: str = ""
    source: str = "snapshot"
    relation: str = "LINKS_TO"
    priority: int = 50
    resource_kind: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SafeControl:
    label: str
    ref: str
    role: str
    action_kind: str = "expand"
    priority: int = 50
    repeatable: bool = False
    review_control: bool = False
    document_control: bool = False
    resource_kind: str = ""
    disabled: bool = False
    context: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CrawlPage:
    url: str
    canonical_url: str
    title: str
    page_type: str
    snapshot: str
    visible_text: str
    links: list[DiscoveredLink] = field(default_factory=list)
    controls: list[SafeControl] = field(default_factory=list)
    screenshot_path: str = ""
    screenshot_paths: list[str] = field(default_factory=list)
    visual_assets: list[dict[str, Any]] = field(default_factory=list)
    http_status: int | None = None
    content_hash: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CrawlConfig:
    start_urls: list[str]
    market: str = ""
    locale: str = "en-uk"

    # No site-frontier cap by default. The crawl ends only when the canonical,
    # resumable queue is exhausted.
    max_pages: int = 0
    max_depth: int = -1

    # No normal safe-control cap. Dynamic controls are exhausted by semantic
    # convergence, disappearance, disabled state, navigation, or cycle detection.
    max_interactions_per_page: int = -1
    delay_seconds: float = 1.5

    download_pdfs: bool = True
    max_pdf_mb: int = 0

    use_llm_extraction: bool = True
    use_vision_extraction: bool = True
    vision_mode: str = "auto"
    vision_full_page: bool = True
    vision_interactions: bool = True
    vision_pdf_pages: bool = True
    download_visual_assets: bool = True
    min_visual_asset_bytes: int = 4096
    max_visual_assets_per_page: int = 0
    pdf_render_dpi: int = 144
    # Render every PDF page for vision by default. Vector diagrams and tables may
    # not be reported as embedded images, so image-count heuristics alone are not
    # sufficient for exhaustive document understanding.
    vision_pdf_every_page: bool = True
    document_download_resume: bool = True

    screenshot_every_page: bool = False

    react_enabled: bool = True
    react_use_llm: bool = True
    self_heal_enabled: bool = True
    max_page_retries: int = 6
    max_control_retries: int = 4
    max_mcp_restarts: int = 3
    retry_base_seconds: float = 1.5
    retry_max_seconds: float = 45.0
    http_fallback_on_browser_failure: bool = True
    completeness_judge: bool = True
    deep_scan_lazy_content: bool = True
    deep_scan_stable_rounds: int = 2
    max_deep_scan_rounds: int = 0
    # Used only when scroll geometry telemetry is unavailable. This is a page-local
    # anti-stall guard, not a site page/depth limit.
    deep_scan_fallback_round_guard: int = 80

    # Zero disables a fixed action ceiling. Semantic no-progress/cycle detection
    # remains active so an infinite carousel or broken widget cannot loop forever.
    emergency_max_actions_per_page: int = 0

    # Exhaust dynamic components such as +Show More Reviews, Load More, Show More,
    # Next Slide, and JS-driven resource controls until they truly stop yielding
    # new evidence. No normal click cap is applied when max clicks is zero.
    exhaust_repeatable_controls: bool = True
    repeatable_control_stable_rounds: int = 2
    repeatable_control_max_clicks: int = 0
    capture_dynamic_state_evidence: bool = True
    extract_all_reviews: bool = True

    # Capture structured public page evidence beyond visible text.  The HTTP
    # representation contributes JSON-LD, product/offer/review schema, tables,
    # FAQ markup, hidden resource URLs, image metadata and application JSON.
    enrich_html_structure: bool = True
    capture_browser_structured_dom: bool = True
    capture_network_inventory: bool = True
    extract_video_metadata: bool = True

    # v6.8 product intelligence: keep each rendered product card/configuration
    # as a coherent unit and require product-detail enrichment for missing fields.
    extract_product_cards: bool = True
    product_detail_completion_enabled: bool = True
    product_min_completeness: float = 0.85
    product_require_price_on_commerce_pages: bool = True
    product_reprocess_existing_sources_on_upgrade: bool = True

    # v6.12 autonomous product completion. When the normal frontier becomes
    # empty, the worker audits canonical Product nodes and automatically revisits
    # Dell PDPs (or their source catalogue when the PDP URL is still unresolved)
    # until missing price/spec/mapping evidence improves or the bounded no-gain
    # budget is exhausted. This avoids requiring a manual Start/Resume cycle.
    product_revisit_enabled: bool = True
    product_revisit_max_attempts: int = 4
    product_revisit_max_sweeps: int = 8
    product_revisit_no_gain_limit: int = 2
    product_revisit_min_gain: float = 0.02
    product_revisit_priority: int = 0
    product_revisit_missing_price: bool = True
    product_revisit_missing_specs: bool = True
    product_revisit_unmapped_evidence: bool = True

    # Autonomous discovery beyond ordinary anchors. These remain read-only and
    # restricted to trusted Dell endpoints.
    discover_robots_sitemaps: bool = True
    recursive_shadow_dom: bool = True
    capture_same_origin_iframes: bool = True
    scroll_sweep_enabled: bool = True
    process_public_api_gets: bool = True
    process_office_documents: bool = True
    process_transcripts: bool = True
    record_binary_asset_metadata: bool = True

    # Deterministic page-level evidence contracts are evaluated after the ReAct
    # completeness judge. Low-coverage pages remain resumable instead of being
    # silently treated as complete.
    coverage_contract_enabled: bool = True
    minimum_page_coverage: float = 0.72
    include_support_content: bool = True
    include_blog_content: bool = True

    # v6.13 authenticated Dell knowledge. The browser uses the same persistent
    # profile as the public crawl, performs only the deterministic email ->
    # Login/Continue -> SSO handoff, and then discovers read-only My Account
    # destinations. Passwords/OTP/payment actions are never automated.
    include_authenticated_account_knowledge: bool = True
    require_authenticated_account_knowledge: bool = False
    login_email: str = ""
    profile_name: str = ""
    auth_probe_url: str = ""
    auth_wait_seconds: float = 90.0

    # v6.14 deterministic global-navigation coverage. Dell's masthead child
    # destinations are frequently injected only after hover/click and can therefore
    # be absent from the ordinary page snapshot. This pass expands every current
    # public tab and safe nested flyout, audits the expected taxonomy, and adds the
    # resulting URLs to the canonical durable frontier.
    include_masthead_taxonomy_discovery: bool = True
    require_masthead_taxonomy_coverage: bool = False
    masthead_max_submenu_depth: int = 4
    masthead_max_actions: int = 250

    # v6.13 repeat-extraction suppression. Canonical URLs are de-duplicated at
    # queue insertion and exact duplicate rendered content bypasses repeated Dell
    # AIA/vision extraction while still preserving aliases and newly discovered
    # links. Partial pages are not blindly requeued on every application restart.
    exact_content_dedupe_enabled: bool = True
    duplicate_content_min_chars: int = 400
    resume_requeue_done_incomplete: bool = False
    resume_requeue_http_fallback: bool = False

    # Discover resource links hidden in data-* attributes, scripts, iframes,
    # embeds, objects, and JS launch controls, not only ordinary <a href> tags.
    discover_embedded_documents: bool = True

    # Dell AIA long-form extraction. Zero chunk count means every chunk is
    # processed; no text is silently truncated before KG extraction/summarisation.
    llm_chunk_chars: int = 12000
    llm_chunk_overlap: int = 700
    max_llm_chunks: int = 0
    hierarchical_summaries: bool = True

    respect_robots: bool = True
    robots_fail_closed: bool = False
    resume: bool = True
    retry_recoverable_on_resume: bool = True
    scope_name: str = "full_en_uk_discovery"
    include_linked_dell_ecosystem: bool = True
    include_community_feedback: bool = True

    # AgentQ/course-inspired intelligence. This does not replace the deterministic
    # safety gate or Playwright MCP. It ranks only already-approved read-only
    # controls using a web representation model, actor/critic scoring,
    # MCTS-inspired exploration and durable trajectory memory.
    agentq_action_model_enabled: bool = True
    agentq_actor_critic_enabled: bool = True
    agentq_action_memory_enabled: bool = True
    agentq_mcts_exploration_enabled: bool = True
    agentq_exploration_weight: float = 1.25
    agentq_llm_critic_enabled: bool = True
    agentq_llm_critic_margin: float = 0.65

    # DOM mutation telemetry helps distinguish a genuinely stuck click from a
    # delayed React update. The observer is installed through application-owned
    # browser_evaluate code; page text and the LLM never generate JavaScript.
    dom_mutation_observer_enabled: bool = True
    mutation_quiet_window_ms: int = 700
    mutation_max_wait_seconds: float = 12.0

    # Queue leases let a supervisor safely recover a URL after a worker crash or
    # an MCP/browser hang without losing the durable frontier.
    worker_lease_seconds: int = 900

    # v6 production scheduler: keep expensive browser work focused on HTML while
    # documents/data/assets use dedicated lightweight lanes. All lanes remain
    # exhaustive; this changes ordering and processing cost, not scope.
    frontier_lane_scheduler_enabled: bool = True
    dedupe_visual_asset_variants: bool = True
    process_visual_assets_as_lane: bool = True
    asset_browser_fallback_on_403: bool = True

    # Public Dell document endpoints sometimes reject a separate raw HTTP
    # client while the same resource is available in the authorised browser
    # session. Retry with browser-like headers and, when necessary, use a
    # fixed application-owned same-origin browser fetch in bounded chunks.
    document_browser_fallback_on_403: bool = True
    document_browser_chunk_bytes: int = 262144
    document_browser_single_response_max_bytes: int = 8 * 1024 * 1024
    # v6.2: a browser-context APIRequestContext is not constrained by page CORS
    # and shares the persistent browser cookie jar. It is used after normal HTTP
    # and real browser navigation/network-response recovery have been attempted.
    document_browser_api_request_enabled: bool = True
    document_browser_navigation_probe_enabled: bool = True
    document_network_body_capture_enabled: bool = True

    # v6.7: all PDFs are acquired through the live Playwright browser context by
    # default. The crawler first extracts and de-duplicates every PDF href from
    # the rendered DOM/shadow DOM/same-origin frames, then uses the browser
    # context request (cookies, user-agent, locale and source-page referer). A
    # real UI click is a fallback for user-gesture-gated resources. Raw httpx
    # transport is opt-in only, preventing the repeated Dell CDN 403 loop seen in
    # the production run.
    document_direct_http_enabled: bool = False
    document_dom_href_first_enabled: bool = True
    # v6.9: source-page click is primary for button-linked documents. Browser
    # APIRequestContext is a fallback only after the real UI gesture fails.
    document_browser_context_request_first: bool = False
    document_browser_context_request_fallback: bool = True
    document_ui_click_fallback_enabled: bool = True
    document_unique_target_marker_enabled: bool = True
    document_capture_all_href_candidates: bool = True
    # Canonical URL mismatches caused false rejection of valid signed/redirected
    # PDFs. In warn mode, validated browser-acquired bytes are retained and the
    # observed URL is stored as an alias; strict mode remains opt-in.
    document_require_canonical_match: bool = False
    document_canonical_match_mode: str = "warn"
    document_click_timeout_seconds: float = 30.0
    document_profile_lock_backoff_seconds: float = 15.0
    document_profile_lock_max_wait_seconds: float = 180.0

    # Compatibility: documents exposed by a Dell page control can be acquired by replaying
    # that real browser click in the persistent Playwright session. The crawler
    # does not probe the CDN with a separate HTTP client first, so click-gated
    # PDFs preserve the page referrer, user gesture, cookies and browser state.
    document_click_first_enabled: bool = True
    document_click_replay_timeout_seconds: float = 18.0
    document_click_use_direct_http_fallback: bool = False
    document_recovery_first: bool = True
    document_recovery_success_target: int = 3
    document_max_attempts: int = 3
    document_invalid_quarantine: bool = True

    # v6.5: when a PDF renders in the browser but its binary bytes cannot be
    # downloaded, exhaust the built-in PDF viewer with accessibility snapshots
    # plus viewport screenshots. Text and Dell AIA vision evidence are persisted
    # as a valid document source instead of repeatedly deferring the URL.
    browser_pdf_viewer_extraction_enabled: bool = True
    browser_pdf_viewer_text_enabled: bool = True
    # Always persist browser-viewer screenshots as durable evidence. Dell AIA
    # vision analysis is applied when configured, but screenshot acquisition
    # itself no longer depends on the vision toggle.
    browser_pdf_viewer_capture_screenshots: bool = True
    browser_pdf_viewer_vision_enabled: bool = True
    browser_pdf_viewer_stable_rounds: int = 2
    browser_pdf_viewer_max_viewports: int = 0
    browser_pdf_viewer_fallback_guard: int = 1200
    browser_pdf_viewer_wait_seconds: float = 0.8

    # Persist crawl coverage during long multi-day runs instead of only at process
    # shutdown. This is why v6 always has a usable frontier report after a crash.
    coverage_checkpoint_every_items: int = 20
    coverage_checkpoint_seconds: int = 300

    # Durable Dell AIA text cache makes resumed runs and duplicated Dell content
    # dramatically faster without reducing extraction depth.
    llm_text_cache_enabled: bool = True

    # Stable semantic control identities survive React ref/ordinal changes. The
    # crawler still exhausts distinct controls, but does not re-click the same
    # product-card action after a DOM refresh.
    stable_control_context_identity: bool = True
    control_progress_ttl_hours: int = 168

    def page_budget_allows(self, processed: int) -> bool:
        return self.max_pages <= 0 or processed < self.max_pages

    def depth_allows_children(self, current_depth: int) -> bool:
        return self.max_depth < 0 or current_depth < self.max_depth

    def depth_allows_item(self, depth: int) -> bool:
        return self.max_depth < 0 or depth <= self.max_depth

    def interaction_budget_allows(self, attempted: int) -> bool:
        return self.max_interactions_per_page < 0 or attempted < self.max_interactions_per_page

    def repeatable_click_budget_allows(self, attempted: int) -> bool:
        return self.repeatable_control_max_clicks <= 0 or attempted < self.repeatable_control_max_clicks

    def emergency_action_budget_allows(self, attempted: int) -> bool:
        return self.emergency_max_actions_per_page <= 0 or attempted < self.emergency_max_actions_per_page

    def visual_asset_budget_allows(self, stored: int) -> bool:
        return self.max_visual_assets_per_page <= 0 or stored < self.max_visual_assets_per_page

    def pdf_size_allows(self, byte_count: int) -> bool:
        return self.max_pdf_mb <= 0 or byte_count <= self.max_pdf_mb * 1024 * 1024

    def llm_chunk_budget_allows(self, processed: int) -> bool:
        return self.max_llm_chunks <= 0 or processed < self.max_llm_chunks

    def normalized_vision_mode(self) -> str:
        value = (self.vision_mode or "auto").strip().lower()
        return value if value in {"off", "auto", "all"} else "auto"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        if "login_email" in payload:
            payload["login_email_configured"] = bool(str(payload.get("login_email") or "").strip())
            payload["login_email"] = "<configured>" if payload["login_email_configured"] else ""
        return payload


@dataclass(slots=True)
class CrawlStats:
    run_id: str
    started_at: str
    finished_at: str = ""
    pages_seen: int = 0
    pages_stored: int = 0
    pages_failed: int = 0
    pages_skipped: int = 0
    pdfs_stored: int = 0
    documents_summarized: int = 0
    embedded_documents_discovered: int = 0
    structured_html_documents: int = 0
    json_ld_records: int = 0
    structured_dom_captures: int = 0
    network_requests_observed: int = 0
    faq_records_extracted: int = 0
    video_endpoints_extracted: int = 0
    product_schema_records: int = 0
    product_records_extracted: int = 0
    product_records_with_price: int = 0
    product_records_with_core_specs: int = 0
    product_detail_urls_enqueued: int = 0
    product_completeness_failures: int = 0
    product_revisit_sweeps: int = 0
    product_revisit_urls_enqueued: int = 0
    product_revisit_products_completed: int = 0
    product_revisit_products_exhausted: int = 0
    product_unmapped_fields_mapped: int = 0
    duplicate_content_extractions_skipped: int = 0
    authenticated_account_pages_seeded: int = 0
    authenticated_account_pages_stored: int = 0
    masthead_groups_complete: int = 0
    masthead_groups_partial: int = 0
    masthead_menu_urls_discovered: int = 0
    masthead_menu_urls_seeded: int = 0
    masthead_unsafe_items_skipped: int = 0
    offer_schema_records: int = 0
    reviews_extracted: int = 0
    repeatable_control_clicks: int = 0
    repeatable_controls_exhausted: int = 0
    dynamic_states_captured: int = 0
    visual_assets_stored: int = 0
    visual_evidence_analyzed: int = 0
    pdf_pages_visualized: int = 0
    pdf_download_resumes: int = 0
    document_bytes_downloaded: int = 0
    react_decisions: int = 0
    heal_attempts: int = 0
    heal_successes: int = 0
    controls_healed: int = 0
    pages_healed: int = 0
    stuck_events: int = 0
    mcp_restarts: int = 0
    http_fallback_pages: int = 0
    deferred_pages: int = 0
    deep_scan_rounds: int = 0
    low_completeness_pages: int = 0
    web_state_observations: int = 0
    action_decisions: int = 0
    actor_critic_reranks: int = 0
    llm_critic_reranks: int = 0
    action_memory_updates: int = 0
    mutation_events_observed: int = 0
    mutation_settle_waits: int = 0
    coverage_audits: int = 0
    # Recoverable evidence gaps are retried and are not terminal validation failures.
    coverage_contract_failures: int = 0
    coverage_recoverable_gaps: int = 0
    coverage_terminal_failures: int = 0
    normalization_repairs: int = 0
    unmapped_evidence_preserved: int = 0
    robots_sitemaps_discovered: int = 0
    public_api_resources_stored: int = 0
    office_documents_stored: int = 0
    transcripts_stored: int = 0
    binary_assets_recorded: int = 0
    shadow_dom_captures: int = 0
    iframe_dom_captures: int = 0
    scroll_sweeps: int = 0
    nodes_created: int = 0
    edges_created: int = 0
    facts_created: int = 0
    queue_remaining: int = 0
    page_lane_processed: int = 0
    document_lane_processed: int = 0
    data_lane_processed: int = 0
    asset_lane_processed: int = 0
    binary_lane_processed: int = 0
    duplicate_asset_variants_skipped: int = 0
    asset_browser_fallbacks: int = 0
    document_browser_fallbacks: int = 0
    document_http_header_retries: int = 0
    pdf_direct_downloads: int = 0
    pdf_browser_navigation_downloads: int = 0
    pdf_browser_click_downloads: int = 0
    pdf_browser_click_viewer_captures: int = 0
    pdf_browser_click_replays: int = 0
    pdf_direct_http_skipped_for_click: int = 0
    pdf_browser_api_downloads: int = 0
    pdf_network_body_downloads: int = 0
    pdf_invalid_files_quarantined: int = 0
    # Candidate-level validation rejections are recoverable diagnostics. They
    # must not be displayed as final document failures.
    pdf_validation_rejections: int = 0
    pdf_validation_recovered: int = 0
    pdf_terminal_validation_failures: int = 0
    # Backward-compatible terminal-only alias used by older dashboards.
    pdf_validation_failures: int = 0
    # Terminal failures only. Recoverable 401/403 transport events are tracked
    # separately so the UI does not report a recovered PDF as failed.
    pdf_download_failures: int = 0
    pdf_transport_events: int = 0
    pdf_recoveries: int = 0
    pdf_successes: int = 0
    pdf_binary_files_stored: int = 0
    pdf_browser_viewer_opens: int = 0
    pdf_browser_viewer_viewports: int = 0
    pdf_browser_viewer_text_chars: int = 0
    pdf_browser_only_processed: int = 0
    pdf_browser_context_primary_downloads: int = 0
    pdf_dom_href_candidates: int = 0
    pdf_duplicate_href_groups: int = 0
    pdf_unique_target_clicks: int = 0
    pdf_ui_click_fallbacks: int = 0
    pdf_direct_http_disabled_skips: int = 0
    pdf_profile_lock_requeues: int = 0
    pdf_canonical_mismatch_failures: int = 0
    pdf_canonical_alias_accepts: int = 0
    llm_text_cache_hits: int = 0
    stable_control_dedupes: int = 0
    coverage_checkpoints_written: int = 0
    status: str = "RUNNING"
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
