from __future__ import annotations

"""Deterministic semantic classification and identity for the Dell crawler.

v6.19 uses this module before graph persistence.  The model may suggest a type/name,
but only a bounded class with deterministic evidence is allowed to become a semantic
node.  Ambiguous observations remain extraction evidence.  Stable semantic keys make
the same entity converge to one node across pages, restarts and extraction methods.
"""

from dataclasses import dataclass
import hashlib
import re
from typing import Any

from .knowledge_ontology import canonical_node_type
from .product_intelligence import is_media_asset_url, is_product_detail_url, valid_product_name
from .snapshot_extract import canonicalize_url

CLASSIFICATION_VERSION = "v6.19"

GRAPH_NODE_TYPES: frozenset[str] = frozenset({
    "Page", "Product", "ProductFamily", "Category", "Brand", "Offer", "Review",
    "Document", "SupportArticle", "FAQ", "Requirement", "Compatibility", "UseCase",
    "Workload", "Solution", "Service", "Software", "Organization", "Market", "AccountTopic",
})

EVIDENCE_ONLY_TYPES: frozenset[str] = frozenset({"Concept", "Section", "VisualAsset"})

_LEGAL_SUFFIX_RE = re.compile(
    r"\b(?:incorporated|inc|corp(?:oration)?|limited|ltd|llc|plc|pvt|private|company|co)\b\.?,?",
    re.I,
)
_GENERIC_NAME_RE = re.compile(
    r"^(?:entity|unknown|thing|attribute|property|value|item|resource|endpoint|page|section|"
    r"learn more|view more|show more|click here|details|open|image|photo|asset)$",
    re.I,
)


@dataclass(frozen=True, slots=True)
class Classification:
    node_type: str | None
    confidence: float
    reason: str


def _clean(value: Any, limit: int = 4000) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _attrs(entity: dict[str, Any]) -> dict[str, Any]:
    attrs = entity.get("attributes") if isinstance(entity.get("attributes"), dict) else {}
    result = dict(attrs)
    reserved = {"key", "id", "node_key", "type", "entity_type", "name", "title", "label", "url", "source_url", "attributes"}
    for key, value in entity.items():
        if key not in reserved and value not in (None, "", [], {}):
            result.setdefault(key, value)
    return result


def normalized_semantic_name(value: Any, *, strip_legal_suffix: bool = False) -> str:
    text = _clean(value, 1000).casefold().replace("&", " and ")
    if strip_legal_suffix:
        text = _LEGAL_SUFFIX_RE.sub(" ", text)
    text = re.sub(r"[®™©]", "", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _slug(value: Any) -> str:
    text = normalized_semantic_name(value)
    slug = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return slug[:180]


_CATEGORY_CANONICAL: dict[str, str] = {
    "laptop": "laptop", "laptops": "laptop", "notebook": "laptop", "notebooks": "laptop",
    "laptop computer": "laptop", "laptop computers": "laptop", "laptops and 2 in 1 pcs": "laptop",
    "2 in 1": "laptop", "2 in 1 pcs": "laptop",
    "desktop": "desktop", "desktops": "desktop", "desktop computer": "desktop", "desktop computers": "desktop",
    "all in one": "desktop", "all in ones": "desktop",
    "workstation": "workstation", "workstations": "workstation",
    "mobile workstation": "mobile workstation", "mobile workstations": "mobile workstation",
    "server": "server", "servers": "server",
    "monitor": "monitor", "monitors": "monitor", "display": "monitor", "displays": "monitor",
    "accessory": "accessory", "accessories": "accessory", "pc accessory": "accessory", "pc accessories": "accessory",
    "storage": "storage", "storage product": "storage", "storage products": "storage",
    "networking": "networking", "networking product": "networking", "networking products": "networking",
}

def canonical_category_name(value: Any) -> str:
    token = normalized_semantic_name(value)
    token = re.sub(r"\b(?:product|products|category|categories)\b", " ", token)
    token = re.sub(r"\s+", " ", token).strip()
    if token in _CATEGORY_CANONICAL:
        return _CATEGORY_CANONICAL[token]
    # Conservative English singularisation for common catalogue headings only.
    if token.endswith("ies") and len(token) > 5:
        candidate = token[:-3] + "y"
        if candidate in _CATEGORY_CANONICAL.values():
            return candidate
    if token.endswith("s") and token[:-1] in _CATEGORY_CANONICAL.values():
        return token[:-1]
    return token


def canonical_family_name(value: Any, brand: Any = "") -> str:
    token = normalized_semantic_name(value)
    token = re.sub(r"\b(?:product )?family$|\bseries$", "", token).strip()
    brand_token = normalized_semantic_name(brand, strip_legal_suffix=True)
    if brand_token in {"dell", "dell technologies"} and token.startswith("dell "):
        token = token[5:].strip()
    return token


def _first(attrs: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = _clean(attrs.get(key), 2000)
        if value:
            return value
    return ""


def _has_product_signal(name: str, attrs: dict[str, Any], url: str, source_url: str) -> bool:
    candidate_url = _first(attrs, "product_url", "productUrl", "url") or url
    if candidate_url and is_product_detail_url(candidate_url, source_url):
        return True
    if _first(attrs, "order_code", "orderCode", "sku", "part_number", "partNumber", "mpn", "model"):
        return True
    commercial = any(attrs.get(k) not in (None, "", [], {}) for k in (
        "price", "current_price", "list_price", "processor", "cpu", "graphics", "gpu",
        "memory", "storage", "display", "operating_system", "os",
    ))
    return bool(commercial and valid_product_name(name, structured=True))


def classify_entity(entity: dict[str, Any], source_url: str = "", *, context: str = "entity") -> Classification:
    """Classify one extracted object into the bounded semantic ontology.

    Explicit known types win.  Generic/unknown types can be promoted only when the
    payload itself contains strong deterministic signals.  Otherwise the observation
    is evidence-only and must not become a graph node.
    """
    raw_type = entity.get("type") or entity.get("entity_type") or "Entity"
    name = _clean(entity.get("name") or entity.get("title") or entity.get("label"), 1000)
    attrs = _attrs(entity)
    raw_url = _clean(entity.get("url") or attrs.get("url") or attrs.get("product_url"), 4000)
    url = canonicalize_url(raw_url, source_url) if raw_url else ""

    canonical = canonical_node_type(raw_type, context=context)
    raw_token = re.sub(r"[^a-z0-9]+", "", str(raw_type or "").casefold())

    # Visual/schema fragments never become semantic nodes.  They remain searchable
    # evidence/assets outside the graph.
    if canonical in EVIDENCE_ONLY_TYPES:
        # Generic raw types may still have strong evidence for a real semantic class.
        if raw_token not in {"entity", "unknown", "thing", "attribute", "propertyvalue", "resource", "endpoint", ""}:
            return Classification(None, 1.0, f"evidence_only_explicit_type:{canonical}")
    elif canonical in GRAPH_NODE_TYPES:
        # Guard against Product labels attached only to an image/CDN URL.
        if canonical == "Product" and url and is_media_asset_url(url, source_url) and not _has_product_signal(name, attrs, "", source_url):
            return Classification(None, 1.0, "media_asset_mislabeled_as_product")
        return Classification(canonical, 0.99, "explicit_or_canonical_type")

    # Deterministic promotion for generic/unknown records.
    if _has_product_signal(name, attrs, url, source_url):
        return Classification("Product", 0.98, "strong_product_identity_or_commercial_signal")

    offer_signal = any(attrs.get(k) not in (None, "", [], {}) for k in (
        "coupon_code", "promo_code", "discount", "discount_percent", "valid_to", "offer_price", "sale_price", "eligibility",
    ))
    if offer_signal:
        return Classification("Offer", 0.95, "commercial_offer_signal")

    review_signal = any(attrs.get(k) not in (None, "", [], {}) for k in (
        "reviewBody", "review_body", "rating", "author", "reviewer", "datePublished", "review_date",
    ))
    if review_signal:
        return Classification("Review", 0.94, "review_signal")

    faq_signal = bool(_first(attrs, "question", "answer", "acceptedAnswer", "faq_question", "faq_answer"))
    if faq_signal:
        return Classification("FAQ", 0.94, "faq_question_answer_signal")

    lowered_url = url.casefold()
    mime = _first(attrs, "mime_type", "content_type").casefold()
    if lowered_url.endswith(".pdf") or "application/pdf" in mime or any(token in lowered_url for token in ("/manuals/", "/manual/", "/documents/")):
        return Classification("Document", 0.96, "document_url_or_mime")
    if "/support/" in lowered_url and any(token in lowered_url for token in ("kbdoc", "article", "knowledge", "manual", "drivers")):
        return Classification("SupportArticle", 0.93, "support_url_pattern")
    if any(token in lowered_url for token in ("/myaccount", "/account/", "/order-status", "/rewards")):
        return Classification("AccountTopic", 0.91, "account_url_pattern")

    # A fetched page is always classifiable as Page if it has a real URL.
    if context == "page" and url:
        return Classification("Page", 0.90, "fetched_page_fallback")

    return Classification(None, 0.0, "ambiguous_unclassified_evidence")


def semantic_entity_key(
    node_type: str,
    name: str,
    attrs: dict[str, Any] | None = None,
    *,
    url: str = "",
    source_url: str = "",
) -> str:
    """Return the stable graph identity for a classified non-Product entity.

    Empty string means there is not enough stable evidence to safely create a node.
    Product identity remains handled by the dedicated product resolver because order
    code/part number/PDP precedence and configuration separation are more involved.
    """
    attrs = dict(attrs or {})
    node_type = str(node_type or "")
    clean_name = _clean(name, 1000)
    raw_url = url or _first(attrs, "url", "product_url", "canonical_url")
    canonical_url = canonicalize_url(raw_url, source_url) if raw_url else ""

    if node_type in {"Page", "Document", "SupportArticle"}:
        if canonical_url:
            return f"url:{canonical_url}"
        return ""

    if node_type == "Brand":
        token = normalized_semantic_name(clean_name, strip_legal_suffix=True)
        return f"brand:{_slug(token)}" if token and not _GENERIC_NAME_RE.match(token) else ""

    if node_type == "Organization":
        token = normalized_semantic_name(clean_name, strip_legal_suffix=True)
        return f"organization:{_slug(token)}" if token and not _GENERIC_NAME_RE.match(token) else ""

    if node_type == "ProductFamily":
        family = clean_name or _first(attrs, "family", "product_family", "series")
        brand_value = _first(attrs, "brand", "manufacturer")
        family_token = canonical_family_name(family, brand_value)
        brand_token = normalized_semantic_name(brand_value, strip_legal_suffix=True)
        if brand_token in {"dell", "dell technologies"}:
            brand_token = "dell"
        # Do not invent a brand for a family.  When the source omits brand, use a
        # neutral namespace so third-party families cannot be silently labelled Dell.
        brand_key = _slug(brand_token) if brand_token else "unbranded"
        return f"product-family:{brand_key}:{_slug(family_token)}" if family_token else ""

    if node_type == "Category":
        token = canonical_category_name(clean_name or _first(attrs, "category", "category_name"))
        return f"category:{_slug(token)}" if token and not _GENERIC_NAME_RE.match(token) else ""

    if node_type == "Market":
        code = _first(attrs, "market", "market_code", "country_code", "code")
        token = normalized_semantic_name(code or clean_name)
        return f"market:{_slug(token)}" if token else ""

    if node_type == "Offer":
        code = _first(attrs, "coupon_code", "promo_code", "offer_id", "id")
        if code:
            return f"offer-code:{_slug(code)}"
        if canonical_url:
            return f"offer-url:{canonical_url}"
        basis = "|".join(filter(None, [
            normalized_semantic_name(clean_name),
            normalized_semantic_name(_first(attrs, "discount", "discount_percent", "price", "offer_price", "sale_price")),
            normalized_semantic_name(_first(attrs, "valid_to", "end_date", "expiry")),
        ]))
        return f"offer:{hashlib.sha256(basis.encode()).hexdigest()[:24]}" if basis else ""

    if node_type == "Review":
        review_id = _first(attrs, "review_id", "id")
        if review_id:
            return f"review-id:{_slug(review_id)}"
        if canonical_url:
            return f"review-url:{canonical_url}"
        basis = "|".join(filter(None, [
            normalized_semantic_name(_first(attrs, "author", "reviewer")),
            normalized_semantic_name(_first(attrs, "date", "review_date", "datePublished")),
            normalized_semantic_name(_first(attrs, "rating")),
            normalized_semantic_name(_first(attrs, "body", "reviewBody", "review_body") or clean_name),
        ]))
        return f"review:{hashlib.sha256(basis.encode()).hexdigest()[:24]}" if basis else ""

    if node_type == "FAQ":
        question = _first(attrs, "question", "faq_question") or clean_name
        token = normalized_semantic_name(question)
        return f"faq:{hashlib.sha256(token.encode()).hexdigest()[:24]}" if token else ""

    if node_type in {"Requirement", "Compatibility", "UseCase", "Workload", "Solution", "Service", "Software", "AccountTopic"}:
        token = normalized_semantic_name(clean_name)
        if not token or _GENERIC_NAME_RE.match(token):
            return ""
        prefix = re.sub(r"(?<!^)(?=[A-Z])", "-", node_type).casefold()
        return f"{prefix}:{_slug(token)}"

    return ""


def classification_attributes(classification: Classification) -> dict[str, Any]:
    return {
        "canonical_class": classification.node_type or "EVIDENCE_ONLY",
        "classification_confidence": round(float(classification.confidence), 4),
        "classification_reason": classification.reason,
        "classification_version": CLASSIFICATION_VERSION,
    }
