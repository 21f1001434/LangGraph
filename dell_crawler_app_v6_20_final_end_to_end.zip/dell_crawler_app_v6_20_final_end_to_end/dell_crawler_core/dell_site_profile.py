from __future__ import annotations

"""Live-site-informed Dell locale crawling profile.

The profile is deliberately data-only.  It captures page families, discovery seeds,
read-only interaction vocabulary, and deterministic completeness expectations observed
on public Dell pages for the configured locale.  The crawler still discovers the actual DOM at runtime and
never assumes that a label or route must exist.
"""

from dataclasses import dataclass
import re
from typing import Iterable
from urllib.parse import urlparse, urlunparse

from .market_context import normalize_locale


@dataclass(frozen=True, slots=True)
class PageArchetype:
    name: str
    path_patterns: tuple[str, ...]
    title_or_text_patterns: tuple[str, ...] = ()
    expected_topics: tuple[str, ...] = ()
    high_value_controls: tuple[str, ...] = ()

    def matches(self, url: str, title: str = "", text: str = "") -> bool:
        path = urlparse(url).path.lower()
        if self.path_patterns and not any(re.search(pattern, path, re.I) for pattern in self.path_patterns):
            return False
        haystack = f"{title}\n{text[:5000]}"
        return not self.title_or_text_patterns or any(
            re.search(pattern, haystack, re.I) for pattern in self.title_or_text_patterns
        )


# Public Dell route families and representative current entry points.  These are
# seeds, not a hard-coded site inventory; recursive sitemap/link discovery expands them.
DELL_UK_DISCOVERY_SEEDS: tuple[str, ...] = (
    "https://www.dell.com/en-uk",
    "https://www.dell.com/en-uk/lp/sitemap",
    "https://www.dell.com/sitemap.xml",
    "https://www.dell.com/en-uk/sitemap.xml",
    # Client devices and accessories.
    "https://www.dell.com/en-uk/shop/dell-laptops/scr/laptops",
    "https://www.dell.com/en-uk/shop/desktop-computers/scr/desktops",
    "https://www.dell.com/en-uk/shop/scc/sc/workstations",
    "https://www.dell.com/en-uk/shop/monitors-monitor-accessories/ar/4009",
    "https://www.dell.com/en-uk/shop/accessories/ar/5436",
    # AI and enterprise infrastructure.
    "https://www.dell.com/en-uk/shop/dell-ai-solutions/sc/artificial-intelligence",
    "https://www.dell.com/en-uk/lp/learn-about-ai-pcs",
    "https://www.dell.com/en-uk/lp/dell-pro-max-nvidia-ai-dev",
    "https://www.dell.com/en-uk/lp/dt/nvidia-ai",
    "https://www.dell.com/en-uk/shop/poweredge-ai-servers/sf/poweredge-ai-servers",
    "https://www.dell.com/en-uk/shop/scc/sc/servers",
    "https://www.dell.com/en-uk/shop/scc/sc/storage-products",
    "https://www.dell.com/en-uk/shop/scc/sc/networking-products",
    "https://www.dell.com/en-uk/shop/scc/sc/cyber-resilience",
    # Deals, rewards and financing/disclaimers.
    "https://www.dell.com/en-uk/shop/dell-deals/cp/dell-deals",
    "https://www.dell.com/en-uk/lp/dell-rewards",
    # Support, manuals, articles and videos.
    "https://www.dell.com/support/home/en-uk",
    "https://www.dell.com/support/home/en-uk?app=manuals",
    "https://www.dell.com/support/home/en-uk?app=drivers",
    "https://www.dell.com/support/home/en-uk?app=products",
    "https://www.dell.com/support/contents/en-uk/category/product-support/self-support-knowledgebase",
    "https://www.dell.com/support/contents/en-uk/category/product-support/self-support-knowledgebase/software-and-downloads/download-center/drivers-and-downloads",
    "https://www.dell.com/support/contents/en-uk/category/contact-information",
    "https://www.dell.com/support/incidents-online/en-uk/srsearch",
    "https://www.dell.com/support/kbdoc/en-uk",
    "https://www.dell.com/support/security/en-uk",
    # Read-only English community knowledge (self-service Q&A and accepted solutions).
    "https://www.dell.com/community/en/",
    "https://www.dell.com/community/en/categories",
    "https://www.dell.com/community/en/spaces",
    # Editorial, learning and customer evidence.
    "https://www.dell.com/en-uk/blog/",
    "https://www.dell.com/en-uk/dt/learn/index.htm",
    "https://www.dell.com/en-uk/lp/dell-customer-stories",
    # Dell Technologies enterprise solutions, resources and infohub (public, Dell-owned).
    "https://www.dell.com/en-uk/dt/solutions/index.htm",
    "https://www.dell.com/en-uk/dt/what-we-do/index.htm",
    "https://infohub.delltechnologies.com/",
    # Segments: small and medium business plus public sector marketing.
    "https://www.dell.com/en-uk/dt/what-we-do/small-business.htm",
    "https://www.dell.com/en-uk/shop/dell-small-business/cp/small-business",
    # Company, legal and policy pages (public, discoverable and stable).
    "https://www.dell.com/en-uk/dt/corporate/about-us.htm",
    "https://www.dell.com/en-uk/lp/terms-and-conditions-of-sale-consumer",
    "https://www.dell.com/en-uk/lp/privacy-policy",
    "https://www.dell.com/en-uk/lp/accessibility",
    "https://www.dell.com/en-uk/dt/corporate/social-impact.htm",
)

AI_WORKSTATION_SEEDS: tuple[str, ...] = tuple(
    url for url in DELL_UK_DISCOVERY_SEEDS
    if any(token in url for token in ("artificial-intelligence", "ai-pc", "pro-max", "nvidia-ai", "workstations", "poweredge-ai"))
)

PUBLIC_CATALOG_SEEDS: tuple[str, ...] = tuple(
    url for url in DELL_UK_DISCOVERY_SEEDS
    if any(token in url for token in ("/scr/", "/ar/", "/scc/sc/", "/deals", "/artificial-intelligence", "/workstations"))
)

SUPPORT_SEEDS: tuple[str, ...] = tuple(
    url for url in DELL_UK_DISCOVERY_SEEDS if "/support/" in url
)

COMMUNITY_SEEDS: tuple[str, ...] = tuple(
    url for url in DELL_UK_DISCOVERY_SEEDS if "/community/" in url
)

# Dell currently uses several labels and component families across product, category,
# support, resource carousel and FAQ pages.  Matching is intentionally semantic and
# generic so future wording variants continue to work.
READ_ONLY_CONTROL_PATTERNS: tuple[str, ...] = (
    r"learn more", r"read more", r"view details", r"explore", r"browse", r"get started",
    r"customisation", r"customization", r"customise(?: now)?", r"customize(?: now)?",
    r"configure(?: now)?", r"build your own", r"view configurations?", r"show all options?",
    r"tech(?:nical)? specs?", r"specifications?", r"features?(?: and design)?", r"ports?",
    r"dimensions?(?: and weight)?", r"services?", r"software", r"accessories?",
    r"special offers?", r"offers?", r"deals?", r"financing", r"rewards?",
    r"ratings?(?:\s*&\s*|\s+and\s+)reviews?", r"view ratings?", r"show more reviews?",
    r"load more", r"view all reviews?", r"read all reviews?", r"next reviews?", r"older reviews?",
    r"drivers?", r"manuals?", r"documentation", r"support", r"downloads?",
    r"resources?", r"customer stor(?:y|ies)", r"use cases?", r"solutions?", r"demos?",
    r"hands-on labs?", r"webinars?", r"events?", r"blogs?", r"related offerings?",
    r"faqs?", r"expand all", r"collapse all", r"compatibility", r"check compatibility",
    r"previous (?:page|slide)", r"next (?:page|slide)", r"view all", r"see all", r"show all",
    r"watch (?:the )?video", r"play video", r"view video", r"transcript",
    r"read (?:the )?(?:brochure|e-?book|white\s*paper|datasheet|data sheet|spec sheet|brief|report|"
    r"case study|customer story|reference architecture|deployment guide|installation guide|user guide|"
    r"manual|infographic|pdf)",
    r"view (?:the )?(?:brochure|e-?book|white\s*paper|datasheet|data sheet|spec sheet|brief|report|"
    r"case study|customer story|reference architecture|deployment guide|installation guide|user guide|"
    r"manual|infographic|pdf)",
    r"download (?:the )?(?:brochure|e-?book|white\s*paper|datasheet|data sheet|spec sheet|brief|report|"
    r"case study|reference architecture|guide|manual|pdf)",
)

REPEATABLE_CONTROL_PATTERNS: tuple[str, ...] = (
    r"show more", r"load more", r"view more", r"see more", r"read more",
    r"show all", r"view all", r"see all", r"show more reviews?", r"view all reviews?",
    r"next (?:page|slide|reviews?|story|result|item)", r"previous (?:page|slide)",
    r"older reviews?", r"newer reviews?", r"expand all",
)

DOCUMENT_LABEL_PATTERNS: tuple[str, ...] = (
    r"brochure", r"e-?book", r"white\s*paper", r"datasheet", r"data sheet",
    r"spec(?:ification)? sheet", r"product brief", r"solution brief", r"technical brief",
    r"analyst report", r"report", r"case study", r"customer story", r"success story",
    r"reference architecture", r"validated design", r"deployment guide", r"installation guide",
    r"user guide", r"product guide", r"manual", r"documentation", r"infographic", r"pdf",
)

PAGE_ARCHETYPES: tuple[PageArchetype, ...] = (
    PageArchetype(
        "AuthenticatedAccountKnowledge",
        (r"^/myaccount/[a-z]{2}-[a-z]{2}(?:/|$)",),
        expected_topics=(
            "account overview", "account navigation", "orders/status summary", "profile settings",
            "saved items", "registered products/devices", "rewards/membership", "support links",
        ),
        high_value_controls=("My Account", "Order Status", "Profile Settings", "My Saved Items", "My Products", "Dell Rewards"),
    ),
    PageArchetype(
        "Product",
        (r"/spd/", r"/shop/povw/"),
        expected_topics=(
            "product name/model", "configuration cards", "price and savings", "processor", "operating system",
            "graphics", "memory", "storage", "tech specs", "features and design", "ratings and reviews",
            "drivers/manuals/support", "services", "software", "accessories", "offers", "ports", "dimensions",
        ),
        high_value_controls=(
            "Customisation", "Tech Specs", "Features and Design", "Ratings & Reviews",
            "Drivers, Manuals & Support", "Special Offers", "Show More Reviews", "Customise now",
        ),
    ),
    PageArchetype(
        "ProductCatalog",
        (r"/scr/", r"/sf/", r"/ar/", r"/shop/scc/sc/"),
        expected_topics=(
            "product families", "model cards", "starting prices", "ratings", "filters", "comparison",
            "solutions", "resources", "customer stories", "related services", "offers",
        ),
        high_value_controls=("View All", "Compare", "Next Page", "Previous Page", "Resources", "Reviews"),
    ),
    PageArchetype(
        "AISolutionPage",
        (r"/artificial-intelligence", r"/ai", r"nvidia-ai", r"ai-pc", r"pro-max"),
        expected_topics=(
            "AI use cases", "workloads", "PC/workstation", "servers", "storage", "networking", "software",
            "services", "security/governance", "validated architecture", "customer evidence", "FAQs", "resources",
        ),
        high_value_controls=("Explore", "Read eBook", "Watch Video", "FAQs", "Customer Stories", "Resources"),
    ),
    # Specific support subtypes must precede the generic Support archetype so that
    # knowledge-base articles, manuals/drivers, and videos receive their own
    # deterministic coverage contracts instead of collapsing into "Support".
    PageArchetype(
        "SupportArticle",
        (r"/support/kbdoc/",),
        expected_topics=(
            "article title", "summary/symptoms", "cause", "resolution/steps", "affected products",
            "article number", "article type", "publication/last modified date", "version", "related articles",
        ),
        high_value_controls=("Expand All", "Show More", "Related Articles", "Was this article helpful"),
    ),
    PageArchetype(
        "SupportManualsAndDrivers",
        (r"/support/manuals/", r"/support/product-details/", r"/support/home/[a-z]{2}-[a-z]{2}"),
        title_or_text_patterns=(r"manuals?", r"drivers?", r"downloads?", r"documentation", r"warranty", r"service tag"),
        expected_topics=(
            "product identification", "drivers and downloads", "manuals and documents", "diagnostics",
            "warranty and service", "parts and accessories", "regulatory and safety", "compatibility",
        ),
        high_value_controls=("Manuals & Documents", "Drivers & Downloads", "Warranty & Contracts", "View PDF"),
    ),
    PageArchetype(
        "SupportVideo",
        (r"/support/contents/[a-z]{2}-[a-z]{2}/videos/", r"/support/.*/videoplayer/"),
        expected_topics=("video title", "description", "transcript/captions", "product/topic", "related resources"),
        high_value_controls=("Play Video", "Transcript", "Captions"),
    ),
    PageArchetype(
        "SupportKnowledgeBase",
        (r"/support/contents/", r"/support/security/", r"/support/incidents-online/"),
        expected_topics=(
            "category overview", "self-service topics", "knowledge articles", "drivers and downloads",
            "diagnostics and tools", "contact and service options", "security advisories",
        ),
        high_value_controls=("Browse Topics", "View All Articles", "Self Support", "Support Library"),
    ),
    PageArchetype(
        "Support",
        (r"/support/",),
        expected_topics=(
            "product identification", "overview", "drivers and downloads", "diagnostics", "manuals and documents",
            "articles", "videos", "advisories", "regulatory", "parts and repairs", "compatibility",
        ),
        high_value_controls=("Documentation", "Manuals & Documents", "Drivers & Downloads", "Support Resources"),
    ),
    PageArchetype(
        "CommunityFeedbackThread",
        (r"/community/en/conversations/", r"/community/en/.*/td-p/", r"/community/en/.*/m-p/"),
        expected_topics=("thread title", "question/problem", "product/model", "responses", "accepted solution", "dates"),
    ),
    PageArchetype(
        "CommunitySpace",
        (r"/community/en/",),
        expected_topics=(
            "space/category name", "description", "discussion threads", "product areas",
            "pinned or knowledge articles", "activity", "related links",
        ),
        high_value_controls=("View All", "Next Page", "Categories", "Latest"),
    ),
    PageArchetype(
        "BlogArticle",
        (r"/blog/",),
        expected_topics=("title", "author", "publication date", "article body", "products", "solutions", "related links"),
    ),
    PageArchetype(
        "CustomerStory",
        (r"customer-stor", r"/lp/dell-customer-stories", r"case-stud", r"success-stor"),
        title_or_text_patterns=(r"customer stor", r"case study", r"success story", r"results", r"outcomes"),
        expected_topics=(
            "customer/organisation", "industry", "challenge", "solution", "Dell products used",
            "results and outcomes", "quote/testimonial", "related resources",
        ),
    ),
    PageArchetype(
        "LearnGlossary",
        (r"/dt/learn/", r"/learn/", r"glossar", r"/lp/what-is", r"/dt/what-we-do/"),
        title_or_text_patterns=(r"what is\b", r"guide to", r"learn (?:about|more)", r"glossary", r"explained", r"definition"),
        expected_topics=(
            "topic/term", "definition/overview", "how it works", "benefits", "use cases",
            "related Dell products/solutions", "further reading",
        ),
    ),
    PageArchetype(
        "LegalPolicy",
        (r"terms-and-conditions", r"privacy-policy", r"/lp/accessibility", r"social-impact",
         r"/policies", r"cookie", r"return-policy", r"warranty-terms", r"sustainab", r"esg"),
        expected_topics=(
            "policy/document title", "scope and applicability", "key terms and clauses",
            "effective/updated date", "consumer rights", "contact or governance",
        ),
    ),
    PageArchetype(
        "CompanyPage",
        (r"/dt/corporate/", r"/about", r"/newsroom", r"/press", r"/careers", r"/investor"),
        expected_topics=(
            "company/topic overview", "leadership or organisation", "commitments or programmes",
            "milestones or figures", "related links", "contact",
        ),
    ),
)


def archetype_for(url: str, title: str = "", text: str = "") -> PageArchetype | None:
    for archetype in PAGE_ARCHETYPES:
        if archetype.matches(url, title, text):
            return archetype
    return None


def _normalise_locale(locale: str) -> str:
    return normalize_locale(locale)


def localize_dell_seed(url: str, locale: str = "en-uk") -> str:
    """Localise a Dell seed without changing its route family.

    Dell marketing pages normally place the locale immediately after the host while
    Support places it later in the path.  The crawler still follows redirects and
    performs live masthead discovery, so this is only a deterministic bootstrap.
    """
    target = _normalise_locale(locale)
    if target == "en-uk":
        return url
    parsed = urlparse(url)
    path = parsed.path
    path = re.sub(r"(?i)(^|/)en-uk(?=/|$)", lambda m: f"{m.group(1)}{target}", path)
    query = parsed.query
    return urlunparse((parsed.scheme, parsed.netloc, path, parsed.params, query, parsed.fragment))


def seed_urls_for_profile(scope_name: str, locale: str = "en-uk") -> list[str]:
    scope = (scope_name or "").strip().lower()
    base = [
        "https://www.dell.com/en-uk",
        "https://www.dell.com/en-uk/lp/sitemap",
        "https://www.dell.com/sitemap.xml",
        "https://www.dell.com/en-uk/sitemap.xml",
    ]
    if scope in {"ai", "ai_workstation", "ai_workstation_bootstrap"}:
        selected = [*base, *AI_WORKSTATION_SEEDS]
    elif scope in {"catalog", "public_catalog"}:
        selected = [*base, *PUBLIC_CATALOG_SEEDS]
    elif scope in {"support", "support_knowledgebase"}:
        selected = [*base, "https://www.dell.com/support/home/en-uk", *SUPPORT_SEEDS]
    elif scope in {"community", "community_feedback"}:
        selected = [*base, *COMMUNITY_SEEDS]
    else:
        selected = list(DELL_UK_DISCOVERY_SEEDS)
    return list(dict.fromkeys(localize_dell_seed(url, locale) for url in selected))


def match_any(patterns: Iterable[str], value: str) -> bool:
    return any(re.search(pattern, value or "", re.I) for pattern in patterns)
