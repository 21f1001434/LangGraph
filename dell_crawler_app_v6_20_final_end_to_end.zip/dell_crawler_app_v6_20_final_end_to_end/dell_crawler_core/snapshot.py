from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .utils import text_hash


@dataclass
class SnapshotNode:
    ref: str
    role: str
    name: str
    line: str
    disabled: bool = False
    context: str = ""


PAGE_URL_RE = re.compile(r'Page URL:\s*(\S+)', re.I)
PAGE_TITLE_RE = re.compile(r'Page Title:\s*(.+)', re.I)
TAB_RE = re.compile(r'-\s*(\d+):\s*(\(current\)\s*)?\[([^\]]*)\]\(([^)]+)\)')

# Playwright MCP reference IDs are opaque. Earlier releases commonly emitted e26,
# while the current 0.0.78 server can emit IDs such as f10e419 and f14e32. Never
# assume an e-prefix or numeric-only suffix.
REF_TOKEN = r'([A-Za-z0-9_.:-]+)'
REF_RE = re.compile(r'-\s*([^\[]+?)\s+"([^"]*)"([^\n]*?)\[ref=' + REF_TOKEN + r'\]')
REF_FALLBACK_RE = re.compile(r'-\s*([^\n]*?)\[ref=' + REF_TOKEN + r'\]')


def parse_page_info(snapshot: str) -> dict[str, Any]:
    url_m = PAGE_URL_RE.search(snapshot or '')
    title_m = PAGE_TITLE_RE.search(snapshot or '')
    tabs = []
    for m in TAB_RE.finditer(snapshot or ''):
        tabs.append({'index': int(m.group(1)), 'current': bool(m.group(2)), 'title': m.group(3), 'url': m.group(4)})
    return {
        'url': url_m.group(1).strip() if url_m else (next((t['url'] for t in tabs if t['current']), '') if tabs else ''),
        'title': title_m.group(1).strip() if title_m else (next((t['title'] for t in tabs if t['current']), '') if tabs else ''),
        'tabs': tabs,
        'snapshot_hash': text_hash(snapshot),
    }


def _context_from_snapshot_lines(lines: list[str], index: int) -> str:
    """Return nearby stable card/section context for a control.

    Playwright refs and ordinal positions change after React updates. Product/card
    headings are much more stable, so include the nearest enclosing heading/listitem
    label in the semantic control identity.
    """
    raw = lines[index]
    indent = len(raw) - len(raw.lstrip())
    candidates: list[str] = []
    for cursor in range(index - 1, max(-1, index - 18), -1):
        line = lines[cursor]
        if not line.strip():
            continue
        line_indent = len(line) - len(line.lstrip())
        # Prefer enclosing/sibling structural labels; ignore interactive controls.
        if line_indent <= indent:
            low = line.lower()
            if any(token in low for token in ('heading ', 'listitem', 'article', 'group ', 'region ')):
                quoted = re.search(r'"([^"]{2,220})"', line)
                if quoted:
                    candidates.append(quoted.group(1).strip())
                    break
        if len(candidates) >= 1:
            break
    return candidates[0] if candidates else ""


def parse_nodes(snapshot: str) -> list[SnapshotNode]:
    nodes: list[SnapshotNode] = []
    seen: set[str] = set()
    lines = (snapshot or '').splitlines()
    for index, line in enumerate(lines):
        context = _context_from_snapshot_lines(lines, index)
        m = REF_RE.search(line)
        if m:
            role = re.sub(r'\s+', ' ', m.group(1)).strip(' -:')
            name = m.group(2).strip()
            rest = m.group(3)
            ref = m.group(4)
            nodes.append(SnapshotNode(ref=ref, role=role, name=name, line=line.strip(), disabled='disabled' in rest.lower(), context=context))
            seen.add(ref)
            continue
        f = REF_FALLBACK_RE.search(line)
        if f and f.group(2) not in seen:
            name = re.sub(r'\[[^\]]+\]', ' ', f.group(1))
            name = re.sub(r'\s+', ' ', name).strip(' -:')
            nodes.append(SnapshotNode(ref=f.group(2), role='element', name=name, line=line.strip(), disabled='disabled' in line.lower(), context=context))
            seen.add(f.group(2))
    return nodes


def normalize(text: str) -> str:
    return re.sub(r'[^a-z0-9]+', ' ', (text or '').lower()).strip()


def is_valid_ref(snapshot: str, ref: str) -> bool:
    if not ref:
        return False
    return any(node.ref == ref for node in parse_nodes(snapshot))


def _is_bad_surface(node: SnapshotNode) -> bool:
    hay = normalize(f'{node.role} {node.name} {node.line}')
    return any(x in hay for x in (
        'virtual assistant', 'transparency statement', 'chat controls',
        'contextual footer', 'legal footer', 'footer links',
    ))


def resolve_ref(
    snapshot: str,
    label: str,
    preferred_roles: tuple[str, ...] = ('button', 'link', 'menuitem', 'tab', 'combobox', 'textbox', 'element'),
    avoid_footer_chat: bool = True,
) -> SnapshotNode | None:
    target = normalize(label)
    if not target:
        return None
    words = [w for w in target.split() if len(w) > 1]
    best: tuple[int, SnapshotNode] | None = None
    for node in parse_nodes(snapshot):
        if node.disabled:
            continue
        node_name = normalize(node.name)
        hay = normalize(f'{node.role} {node.name} {node.line}')
        score = 0
        lexical_match = False
        if node_name == target:
            score += 10000
            lexical_match = True
        elif target in node_name:
            score += 6000
            lexical_match = True
        elif node_name and node_name in target and len(node_name) > 3:
            score += 3500
            lexical_match = True
        elif target in hay:
            score += 2500
            lexical_match = True
        matched_words = [w for w in words if w in hay]
        if matched_words:
            score += 220 * len(matched_words)
            lexical_match = True
        if words and all(w in hay for w in words):
            score += 1200
        if not lexical_match:
            continue
        if any(r in node.role.lower() for r in preferred_roles):
            score += 500
        # Prefer top masthead controls and open-dialog menu entries over footer links.
        box_y = None
        box_match = re.search(r'\[box=[^,]+,(-?\d+)', node.line)
        if box_match:
            try:
                box_y = int(box_match.group(1))
            except ValueError:
                box_y = None
        if box_y is not None and 0 <= box_y <= 850:
            score += 350
        if avoid_footer_chat and _is_bad_surface(node):
            score -= 5000
        if score > 0 and (best is None or score > best[0]):
            best = (score, node)
    return best[1] if best else None


def snapshot_contains(snapshot: str, patterns: list[str]) -> bool:
    low = normalize(snapshot)
    return all(normalize(p) in low for p in patterns if p)
