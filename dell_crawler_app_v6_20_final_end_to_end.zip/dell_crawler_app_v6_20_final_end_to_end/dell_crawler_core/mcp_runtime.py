from __future__ import annotations

import asyncio
import json
import logging
import os
import queue
import re
import shlex
import shutil
import signal
import socket
import subprocess
import threading
import time
from concurrent.futures import Future, TimeoutError as FutureTimeoutError
from pathlib import Path
from typing import Any

from .utils import content_to_text, ensure_dir, has_mcp_error, redact_text


class AsyncLoopThread:
    """One dedicated asyncio loop used by the single MCP owner task.

    Shutdown is cooperative: outstanding transport tasks are cancelled and
    awaited, async generators are closed, and only then is the loop stopped.
    This prevents the common ``Task was destroyed but it is pending`` warning
    after a graceful crawler stop or MCP restart.
    """

    def __init__(self) -> None:
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, name="playwright-mcp-loop", daemon=True)
        self.thread.start()

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def schedule(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    async def _shutdown(self) -> None:
        current = asyncio.current_task()
        pending = [task for task in asyncio.all_tasks(self.loop) if task is not current and not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        await self.loop.shutdown_asyncgens()
        shutdown_executor = getattr(self.loop, "shutdown_default_executor", None)
        if shutdown_executor is not None:
            try:
                await shutdown_executor(timeout=3.0)
            except TypeError:
                await shutdown_executor()
            except Exception:
                pass

    def stop(self) -> None:
        if self.loop.is_running():
            try:
                future = asyncio.run_coroutine_threadsafe(self._shutdown(), self.loop)
                future.result(timeout=12)
            except Exception:
                pass
            self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join(timeout=8)
        try:
            if not self.loop.is_closed():
                self.loop.close()
        except Exception:
            pass


class _MCPExpectedShutdownNoiseFilter(logging.Filter):
    """Hide only known MCP-SDK teardown noise while a runtime is closing.

    The filter is inactive during normal operation, so real stream failures are
    still visible. During an intentional stop/restart, the Python MCP SDK can
    log ClosedResourceError/BrokenResourceError after its receiving memory
    stream has already been closed. Those messages are expected teardown races,
    not crawler extraction failures.
    """

    def __init__(self, closing_event: threading.Event) -> None:
        super().__init__()
        self.closing_event = closing_event

    def filter(self, record: logging.LogRecord) -> bool:
        if not self.closing_event.is_set():
            return True
        message = record.getMessage()
        exc = record.exc_info[1] if record.exc_info else None
        exc_name = type(exc).__name__ if exc is not None else ""
        if message.startswith("Error parsing SSE message") and exc_name in {
            "ClosedResourceError", "BrokenResourceError"
        }:
            return False
        return True


class PlaywrightMCPRuntime:
    """Native client for the official Microsoft ``@playwright/mcp`` server.

    The server is launched in local Streamable HTTP mode. A *single persistent
    worker coroutine* owns the HTTP transport, ``ClientSession`` and every tool
    call from startup through shutdown. This prevents AnyIO/MCP cancel-scope
    errors caused by entering a transport context in one task and exiting it in
    another.

    The live tool schemas are discovered and the runtime adapts ``target`` vs
    older ``ref`` argument variants. The crawler never executes JavaScript supplied
    by page content or the LLM. Its few ``browser_evaluate`` calls are fixed,
    application-owned, read-only telemetry/extraction routines such as the DOM
    mutation observer.
    """

    def __init__(
        self,
        browser: str = "msedge",
        headless: bool = False,
        mode: str = "persistent",
        user_data_dir: str = "browser_profile/dell_mcp_profile",
        output_dir: str = "evidence/mcp",
        extra_args: str = "",
        package_version: str = "0.0.78",
        executable_path: str = "",
        start_timeout_seconds: int = 90,
        host: str = "127.0.0.1",
        port: int = 0,
    ) -> None:
        self.browser = browser
        self.headless = headless
        self.mode = mode
        self.user_data_dir = str(Path(user_data_dir).resolve())
        self.output_dir = str(ensure_dir(output_dir).resolve())
        self.extra_args = extra_args
        self.package_version = package_version
        configured_executable = str(executable_path or os.getenv("PLAYWRIGHT_MCP_EXECUTABLE_PATH", "")).strip()
        self.executable_path = configured_executable or self._detect_installed_browser_executable(browser)
        configured_start_timeout = os.getenv("PLAYWRIGHT_MCP_START_TIMEOUT_SECONDS", "").strip()
        try:
            configured_value = int(configured_start_timeout) if configured_start_timeout else int(start_timeout_seconds)
        except ValueError:
            configured_value = int(start_timeout_seconds)
        self.start_timeout_seconds = max(30, configured_value)
        self.host = host
        self.port = int(port or 0)

        self.loop_thread = AsyncLoopThread()
        self.session: Any | None = None
        self.tools: dict[str, dict[str, Any]] = {}
        self.started = False
        self.calls: list[dict[str, Any]] = []
        self.server_url = ""
        self.server_logs: list[str] = []
        self._startup_phase = "not_started"

        self._commands: queue.Queue[dict[str, Any]] = queue.Queue()
        self._worker_future: Any | None = None
        self._startup_future: Future | None = None
        self._process: subprocess.Popen[str] | None = None
        self._log_thread: threading.Thread | None = None
        self._log_stop = threading.Event()
        self._lifecycle_lock = threading.Lock()
        self.launcher_info: dict[str, Any] = {}
        self._closing = threading.Event()
        self._shutdown_filter = _MCPExpectedShutdownNoiseFilter(self._closing)
        self._mcp_stream_logger = logging.getLogger("mcp.client.streamable_http")
        self._mcp_stream_logger.addFilter(self._shutdown_filter)
        profile_name = Path(self.user_data_dir).name or "playwright_profile"
        self._profile_lease_path = Path(self.user_data_dir).parent / f".{profile_name}.dell-crawler.lock"
        self._profile_lease_acquired = False

    @staticmethod
    def _detect_installed_browser_executable(browser: str) -> str:
        """Best-effort browser-channel discovery, primarily for Windows desktops."""
        requested = str(browser or "").lower()
        candidates: list[Path] = []
        if os.name == "nt":
            roots = [
                os.getenv("PROGRAMFILES", ""),
                os.getenv("PROGRAMFILES(X86)", ""),
                os.getenv("LOCALAPPDATA", ""),
            ]
            if requested in {"chrome", "chromium"}:
                relative = [
                    Path("Google/Chrome/Application/chrome.exe"),
                    Path("Chromium/Application/chrome.exe"),
                ]
            elif requested in {"msedge", "edge"}:
                relative = [Path("Microsoft/Edge/Application/msedge.exe")]
            else:
                relative = []
            for root in roots:
                if root:
                    candidates.extend(Path(root) / rel for rel in relative)
        else:
            names = (
                ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"]
                if requested in {"chrome", "chromium"}
                else ["microsoft-edge", "microsoft-edge-stable"] if requested in {"msedge", "edge"} else []
            )
            for name in names:
                resolved = shutil.which(name)
                if resolved:
                    candidates.append(Path(resolved))
        for candidate in candidates:
            try:
                if candidate.is_file():
                    return str(candidate.resolve())
            except OSError:
                continue
        return ""

    @staticmethod
    def _free_port(host: str = "127.0.0.1") -> int:
        family = socket.AF_INET6 if ":" in host else socket.AF_INET
        with socket.socket(family, socket.SOCK_STREAM) as sock:
            sock.bind((host, 0))
            return int(sock.getsockname()[1])

    def _server_args(self, port: int | None = None) -> list[str]:
        chosen_port = int(port or getattr(self, "port", 0) or 0)
        args = [
            "-y",
            f"@playwright/mcp@{self.package_version}",
            f"--output-dir={self.output_dir}",
            "--output-mode=stdout",
            "--image-responses=omit",
            "--snapshot-mode=full",
            "--timeout-action=12000",
            "--timeout-navigation=90000",
            "--codegen=none",
            "--caps=devtools",
            "--save-session",
        ]
        if chosen_port:
            # Local HTTP avoids Python-MCP stdio initialization/cancel-scope
            # incompatibilities observed with current SDK combinations.
            args += [
                f"--host={getattr(self, 'host', '127.0.0.1')}",
                "--allowed-hosts=*",
                f"--port={chosen_port}",
                "--shared-browser-context",
            ]
        if self.mode == "extension":
            args.append("--extension")
        else:
            args += [f"--browser={self.browser}", f"--user-data-dir={self.user_data_dir}"]
            if self.executable_path:
                args.append(f"--executable-path={self.executable_path}")
        if self.headless:
            args.append("--headless")
        if self.extra_args:
            args.extend(shlex.split(self.extra_args, posix=os.name != "nt"))
        return args

    @staticmethod
    def _candidate_npx_cli_paths(npx_path: str | None, node_path: str | None) -> list[Path]:
        candidates: list[Path] = []
        for raw in (npx_path, node_path):
            if not raw:
                continue
            base = Path(raw).resolve().parent
            candidates.extend(
                [
                    base / "node_modules" / "npm" / "bin" / "npx-cli.js",
                    base.parent / "node_modules" / "npm" / "bin" / "npx-cli.js",
                ]
            )
        appdata = os.getenv("APPDATA", "").strip()
        if appdata:
            candidates.append(Path(appdata) / "npm" / "node_modules" / "npm" / "bin" / "npx-cli.js")
        unique: list[Path] = []
        seen: set[str] = set()
        for candidate in candidates:
            key = str(candidate).lower()
            if key not in seen:
                seen.add(key)
                unique.append(candidate)
        return unique

    @classmethod
    def resolve_launcher(cls, requested: str | None = None) -> dict[str, Any]:
        """Resolve an executable command that Python can launch reliably.

        On Windows, ``npx`` normally resolves to ``npx.cmd``. Passing the bare
        string ``npx`` to ``subprocess.Popen(..., shell=False)`` can raise
        ``WinError 2`` even though ``shutil.which('npx')`` succeeds. Prefer
        running npm's ``npx-cli.js`` with ``node.exe``; otherwise use
        ``cmd.exe /d /s /c`` as the safe batch-file fallback.
        """
        raw = (requested or os.getenv("PLAYWRIGHT_MCP_NPX_COMMAND", "npx")).strip().strip('"')
        expanded = os.path.expandvars(os.path.expanduser(raw))
        explicit = Path(expanded)
        found: str | None = None
        if explicit.is_file():
            found = str(explicit.resolve())
        else:
            found = shutil.which(expanded)
            if not found and os.name == "nt" and not Path(expanded).suffix:
                for suffix in (".cmd", ".exe", ".bat"):
                    found = shutil.which(expanded + suffix)
                    if found:
                        break

        node_requested = os.getenv("PLAYWRIGHT_MCP_NODE_COMMAND", "node").strip().strip('"') or "node"
        node_path = shutil.which(node_requested)
        if not node_path and Path(os.path.expandvars(node_requested)).is_file():
            node_path = str(Path(os.path.expandvars(node_requested)).resolve())

        info: dict[str, Any] = {
            "requested": raw,
            "resolved_path": found,
            "node_path": node_path,
            "strategy": "not_found",
            "argv_prefix": [],
            "npx_cli_path": None,
            "comspec": None,
            "ok": False,
        }
        if not found:
            return info

        suffix = Path(found).suffix.lower()
        if os.name == "nt" and suffix in {".cmd", ".bat"}:
            for candidate in cls._candidate_npx_cli_paths(found, node_path):
                if node_path and candidate.is_file():
                    info.update(
                        {
                            "strategy": "node_npx_cli",
                            "argv_prefix": [node_path, str(candidate.resolve())],
                            "npx_cli_path": str(candidate.resolve()),
                            "ok": True,
                        }
                    )
                    return info
            comspec = os.getenv("COMSPEC") or shutil.which("cmd.exe")
            if comspec:
                info.update(
                    {
                        "strategy": "windows_cmd_batch",
                        "argv_prefix": [comspec, "/d", "/s", "/c"],
                        "comspec": comspec,
                        "ok": True,
                    }
                )
                return info
            return info

        if suffix == ".js" and node_path:
            info.update({"strategy": "node_script", "argv_prefix": [node_path, found], "ok": True})
            return info

        info.update({"strategy": "direct_executable", "argv_prefix": [found], "ok": True})
        return info

    @classmethod
    def launcher_argv(cls, args: list[str], requested: str | None = None) -> tuple[list[str], dict[str, Any]]:
        info = cls.resolve_launcher(requested)
        if not info.get("ok"):
            raise FileNotFoundError(
                f"Could not resolve Playwright MCP launcher {info.get('requested')!r}. "
                "Install Node.js 20+ or set PLAYWRIGHT_MCP_NPX_COMMAND to the full npx.cmd path."
            )
        if info.get("strategy") == "windows_cmd_batch":
            resolved = str(info["resolved_path"])
            command_line = subprocess.list2cmdline([resolved, *args])
            # cmd.exe requires an extra outer quote when the batch path itself
            # contains spaces (for example C:\Program Files\nodejs\npx.cmd).
            if command_line.startswith('"'):
                command_line = f'"{command_line}"'
            argv = [*info["argv_prefix"], command_line]
        else:
            argv = [*info["argv_prefix"], *args]
        public = dict(info)
        public["launch_argv"] = argv
        return argv, public

    @classmethod
    def environment_preflight(cls) -> dict[str, Any]:
        launcher = cls.resolve_launcher()
        details: dict[str, Any] = {
            "npx_command": launcher.get("requested"),
            "npx_found": bool(launcher.get("resolved_path")),
            "npx_path": launcher.get("resolved_path"),
            "launcher_strategy": launcher.get("strategy"),
            "node_path": launcher.get("node_path"),
            "npx_cli_path": launcher.get("npx_cli_path"),
            "comspec": launcher.get("comspec"),
            "node_version": "",
            "npm_version": "",
            "python_mcp_available": False,
            "httpx_available": False,
            "ok": False,
            "errors": [],
        }
        for exe, key in [(launcher.get("node_path") or "node", "node_version")]:
            try:
                details[key] = subprocess.check_output([str(exe), "--version"], text=True, timeout=10).strip()
            except Exception as exc:
                details["errors"].append(f"node: {type(exc).__name__}: {exc}")
        try:
            npm_argv, _ = cls.launcher_argv(["--version"])
            details["npm_version"] = subprocess.check_output(npm_argv, text=True, timeout=20).strip()
        except Exception as exc:
            details["errors"].append(f"npx: {type(exc).__name__}: {exc}")
        try:
            import mcp  # noqa: F401
            details["python_mcp_available"] = True
        except Exception as exc:
            details["errors"].append(f"python mcp package: {type(exc).__name__}: {exc}")
        try:
            import httpx  # noqa: F401
            details["httpx_available"] = True
        except Exception as exc:
            details["errors"].append(f"httpx package: {type(exc).__name__}: {exc}")
        if not launcher.get("ok"):
            details["errors"].append(
                "npx could not be launched. Install Node.js 20+ or set PLAYWRIGHT_MCP_NPX_COMMAND to the full npx.cmd path."
            )
        node_major = 0
        try:
            node_major = int(str(details["node_version"]).lstrip("v").split(".", 1)[0])
        except Exception:
            pass
        details["node_major"] = node_major
        if node_major and node_major < 20:
            details["errors"].append(f"Node.js 20+ is required; detected {details['node_version']}.")
        details["ok"] = bool(
            launcher.get("ok")
            and node_major >= 20
            and details["python_mcp_available"]
            and details["httpx_available"]
        )
        return details

    @staticmethod
    def _error_text(exc: BaseException, phase: str) -> str:
        message = str(exc).strip()
        if not message:
            message = type(exc).__name__
        return redact_text(f"{type(exc).__name__} during {phase}: {message}")

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            import psutil
            return bool(psutil.pid_exists(pid) and psutil.Process(pid).is_running())
        except Exception:
            try:
                if os.name == "nt":
                    return False
                os.kill(pid, 0)
                return True
            except Exception:
                return False

    def _acquire_profile_lease(self) -> tuple[bool, dict[str, Any]]:
        """Acquire one process-level lease for the persistent browser profile.

        Chromium's own SingletonLock is not sufficient protection when old npm,
        node or browser descendants survive an MCP restart. This small lease
        prevents a second crawler process from opening the same profile while a
        live owner exists and automatically removes stale leases after crashes.
        """
        if self.mode == "extension":
            return True, {"mode": "extension", "lease": "not_required"}
        path = self._profile_lease_path
        path.parent.mkdir(parents=True, exist_ok=True)
        owner = {"pid": os.getpid(), "created_at": time.time(), "user_data_dir": self.user_data_dir}
        for _ in range(2):
            try:
                fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(owner, handle)
                self._profile_lease_acquired = True
                return True, {"lease_path": str(path), "owner_pid": os.getpid(), "stale_recovered": False}
            except FileExistsError:
                try:
                    existing = json.loads(path.read_text(encoding="utf-8"))
                except Exception:
                    existing = {}
                existing_pid = int(existing.get("pid") or 0)
                if existing_pid == os.getpid():
                    self._profile_lease_acquired = True
                    return True, {"lease_path": str(path), "owner_pid": existing_pid, "reused": True}
                if not self._pid_alive(existing_pid):
                    try:
                        path.unlink(missing_ok=True)
                        continue
                    except Exception:
                        pass
                return False, {
                    "lease_path": str(path),
                    "owner_pid": existing_pid,
                    "user_data_dir": self.user_data_dir,
                    "error": "Persistent browser profile is already owned by another live crawler process.",
                }
        return False, {"lease_path": str(path), "error": "Could not acquire persistent browser profile lease."}

    def _release_profile_lease(self) -> None:
        if not self._profile_lease_acquired:
            return
        try:
            payload = json.loads(self._profile_lease_path.read_text(encoding="utf-8"))
        except Exception:
            payload = {}
        if int(payload.get("pid") or 0) in {0, os.getpid()}:
            try:
                self._profile_lease_path.unlink(missing_ok=True)
            except Exception:
                pass
        self._profile_lease_acquired = False

    def start(self) -> dict[str, Any]:
        self._closing.clear()
        with self._lifecycle_lock:
            if self.started:
                return {
                    "ok": True,
                    "already_started": True,
                    "transport": "streamable_http",
                    "server_url": self.server_url,
                    "tools": sorted(self.tools),
                }
            lease_ok, lease_info = self._acquire_profile_lease()
            if not lease_ok:
                return {
                    "ok": False,
                    "status": "mcp_browser_profile_locked",
                    "error": lease_info.get("error", "Persistent browser profile is locked."),
                    "profile_lease": lease_info,
                }
            preflight = self.environment_preflight()
            if not preflight.get("ok"):
                self._release_profile_lease()
                return {
                    "ok": False,
                    "status": "mcp_preflight_failed",
                    "error": "; ".join(preflight.get("errors", [])) or "Playwright MCP preflight failed.",
                    "preflight": preflight,
                }
            if self._worker_future and not self._worker_future.done():
                return {
                    "ok": False,
                    "status": "mcp_start_in_progress",
                    "error": "A Playwright MCP startup is already in progress.",
                }
            self._startup_future = Future()
            self._worker_future = self.loop_thread.schedule(self._worker_main(self._startup_future))

        try:
            result = self._startup_future.result(timeout=self.start_timeout_seconds + 20)
            return result
        except FutureTimeoutError as exc:
            self._force_terminate_process()
            self._release_profile_lease()
            if self._worker_future:
                self._worker_future.cancel()
            return {
                "ok": False,
                "status": "mcp_start_failed",
                "error": self._error_text(exc, self._startup_phase),
                "error_type": type(exc).__name__,
                "phase": self._startup_phase,
                "preflight": preflight,
                "server_args": self._server_args(self.port or None),
                "launcher": self.launcher_info or self.resolve_launcher(),
                "server_log_tail": self.server_logs[-30:],
            }
        except Exception as exc:
            self._force_terminate_process()
            self._release_profile_lease()
            return {
                "ok": False,
                "status": "mcp_start_failed",
                "error": self._error_text(exc, self._startup_phase),
                "error_type": type(exc).__name__,
                "phase": self._startup_phase,
                "preflight": preflight,
                "server_args": self._server_args(self.port or None),
                "launcher": self.launcher_info or self.resolve_launcher(),
                "server_log_tail": self.server_logs[-30:],
            }

    async def _worker_main(self, startup: Future) -> None:
        close_reply: Future | None = None
        try:
            self._startup_phase = "allocate_port"
            if not self.port:
                self.port = self._free_port(self.host)
            self.server_url = f"http://{self.host}:{self.port}/mcp"

            self._startup_phase = "launch_server"
            launch_argv, self.launcher_info = self.launcher_argv(self._server_args(self.port))
            popen_kwargs: dict[str, Any] = {
                "stdout": subprocess.PIPE,
                "stderr": subprocess.STDOUT,
                "text": True,
                "bufsize": 1,
            }
            if os.name == "nt":
                popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            else:
                popen_kwargs["start_new_session"] = True
            self._process = subprocess.Popen(launch_argv, **popen_kwargs)
            self._start_log_pump()

            self._startup_phase = "wait_for_http_server"
            await self._wait_for_server_ready()

            self._startup_phase = "initialize_mcp_session"
            import httpx
            from mcp import ClientSession
            from mcp.client.streamable_http import streamable_http_client

            # Never send localhost MCP traffic through corporate proxy settings.
            timeout = httpx.Timeout(30.0, read=130.0, write=30.0, connect=15.0)
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                async with streamable_http_client(
                    self.server_url,
                    http_client=client,
                    # The local Playwright MCP process is explicitly terminated
                    # after the transport contexts exit. Avoid an extra DELETE
                    # request during teardown; it can race the SSE receive task in
                    # current Python MCP SDK releases.
                    terminate_on_close=False,
                ) as (read, write, get_session_id):
                    async with ClientSession(read, write) as session:
                        self.session = session
                        await asyncio.wait_for(session.initialize(), timeout=35)

                        self._startup_phase = "list_mcp_tools"
                        listed = await asyncio.wait_for(session.list_tools(), timeout=35)
                        self.tools = {}
                        for tool in listed.tools:
                            schema = getattr(tool, "inputSchema", None) or getattr(tool, "input_schema", None) or {}
                            self.tools[tool.name] = {
                                "name": tool.name,
                                "description": getattr(tool, "description", ""),
                                "schema": schema,
                            }
                        required = {
                            "browser_snapshot",
                            "browser_click",
                            "browser_navigate",
                            "browser_tabs",
                            "browser_take_screenshot",
                        }
                        missing = sorted(required - set(self.tools))
                        if missing:
                            raise RuntimeError(f"Official Playwright MCP missing required tools: {missing}")

                        self.started = True
                        self._startup_phase = "ready"
                        self._safe_set_result(
                            startup,
                            {
                                "ok": True,
                                "server": f"@playwright/mcp@{self.package_version}",
                                "transport": "streamable_http",
                                "server_url": self.server_url,
                                "session_id": get_session_id(),
                                "browser": self.browser,
                                "mode": self.mode,
                                "user_data_dir": self.user_data_dir if self.mode != "extension" else None,
                                "executable_path": self.executable_path or None,
                                "output_dir": self.output_dir,
                                "tools": sorted(self.tools),
                                "schemas": {k: self._schema_signature(k) for k in sorted(required)},
                                "launcher": self.launcher_info,
                                "server_log_tail": self.server_logs[-10:],
                            },
                        )

                        while True:
                            command_item = await asyncio.to_thread(self._commands.get)
                            kind = command_item.get("kind")
                            reply: Future = command_item["reply"]
                            if kind == "close":
                                close_reply = reply
                                break
                            if kind != "call":
                                self._safe_set_result(reply, {"ok": False, "status": "invalid_runtime_command"})
                                continue
                            result = await self._worker_call(
                                session,
                                str(command_item.get("name", "")),
                                dict(command_item.get("args") or {}),
                                str(command_item.get("intent", "")),
                            )
                            self._safe_set_result(reply, result)
        except asyncio.CancelledError:
            if not startup.done():
                self._safe_set_exception(startup, RuntimeError(f"MCP startup cancelled during {self._startup_phase}"))
            raise
        except BaseException as exc:
            if not startup.done():
                self._safe_set_exception(startup, RuntimeError(self._error_text(exc, self._startup_phase)))
            self._fail_pending_commands(exc)
        finally:
            self.started = False
            self.session = None
            self.tools = {}
            self._force_terminate_process()
            if close_reply is not None:
                self._safe_set_result(
                    close_reply,
                    {
                        "ok": True,
                        "status": "closed",
                        "transport": "streamable_http",
                        "server_url": self.server_url,
                    },
                )

    def _start_log_pump(self) -> None:
        """Drain child stdout continuously without blocking the asyncio loop.

        The previous implementation repeatedly called ``readline`` through
        ``asyncio.to_thread`` and waited for the literal text ``Listening on``.
        On Windows, npm/npx wrappers and some Playwright MCP releases can buffer
        or alter that line even while the HTTP endpoint is already accepting
        connections. The blocked reader threads then caused a false startup
        timeout. A single dedicated log thread avoids that problem.
        """
        process = self._process
        if not process or not process.stdout:
            return
        self._log_stop.clear()

        def pump() -> None:
            try:
                for line in iter(process.stdout.readline, ""):
                    if self._log_stop.is_set():
                        break
                    cleaned = redact_text(line.strip())
                    if cleaned:
                        self.server_logs.append(cleaned)
                        self.server_logs[:] = self.server_logs[-200:]
            except Exception as exc:
                self.server_logs.append(redact_text(f"log_reader_error: {type(exc).__name__}: {exc}"))

        self._log_thread = threading.Thread(
            target=pump,
            name="playwright-mcp-log-reader",
            daemon=True,
        )
        self._log_thread.start()

    def _tcp_endpoint_ready(self) -> bool:
        """Return True once the configured local HTTP port accepts a connection."""
        try:
            with socket.create_connection((self.host, self.port), timeout=0.35):
                return True
        except OSError:
            return False

    async def _wait_for_server_ready(self) -> None:
        """Wait for the actual HTTP endpoint, not a particular console message.

        Official Playwright MCP documents the standalone endpoint as
        ``http://localhost:<port>/mcp``. Console text is diagnostic only; TCP
        readiness is the source of truth. This also handles localized, buffered,
        ANSI-colored, or version-dependent startup output on Windows.
        """
        if not self._process:
            raise RuntimeError("Playwright MCP process was not created.")

        deadline = time.monotonic() + self.start_timeout_seconds
        last_progress_note = 0.0
        while time.monotonic() < deadline:
            if self._process.poll() is not None:
                logs = " | ".join(self.server_logs[-30:]) or "<no server output captured>"
                raise RuntimeError(
                    f"Playwright MCP exited with code {self._process.returncode}. Logs: {logs}"
                )

            if await asyncio.to_thread(self._tcp_endpoint_ready):
                # Give the Node HTTP router a brief moment after the socket bind
                # before the MCP initialization request is sent.
                await asyncio.sleep(0.15)
                return

            elapsed = self.start_timeout_seconds - max(0.0, deadline - time.monotonic())
            if elapsed - last_progress_note >= 15:
                last_progress_note = elapsed
                note = (
                    f"startup_wait: {int(elapsed)}s elapsed; pid={self._process.pid}; "
                    f"waiting for {self.host}:{self.port}; logs={len(self.server_logs)}"
                )
                self.server_logs.append(note)
                self.server_logs[:] = self.server_logs[-200:]
            await asyncio.sleep(0.25)

        logs = " | ".join(self.server_logs[-30:]) or "<no server output captured>"
        raise TimeoutError(
            f"Playwright MCP process stayed alive but {self.host}:{self.port} did not accept "
            f"connections within {self.start_timeout_seconds}s. Logs: {logs}. "
            "This usually means npx is still downloading the package, npm/TLS/proxy access is blocked, "
            "or the selected port/browser launch was blocked."
        )

    @staticmethod
    def _safe_set_result(future: Future, result: Any) -> None:
        if not future.done():
            future.set_result(result)

    @staticmethod
    def _safe_set_exception(future: Future, exc: BaseException) -> None:
        if not future.done():
            future.set_exception(exc)

    def _fail_pending_commands(self, exc: BaseException) -> None:
        detail = self._error_text(exc, self._startup_phase)
        while True:
            try:
                item = self._commands.get_nowait()
            except queue.Empty:
                break
            reply = item.get("reply")
            if isinstance(reply, Future):
                self._safe_set_result(reply, {"ok": False, "status": "mcp_worker_failed", "detail": detail})

    def _force_terminate_process(self) -> None:
        """Terminate the complete npm/node/browser descendant tree.

        Killing only the npx wrapper leaves Chrome/Edge alive on Windows, which
        keeps Chromium SingletonLock files open and causes the next PDF recovery
        to fail with "browser profile already in use". Process-tree termination
        is therefore required before a persistent-profile restart.
        """
        self._log_stop.set()
        process = self._process
        self._process = None
        if process and process.poll() is None:
            killed = False
            try:
                import psutil
                parent = psutil.Process(process.pid)
                descendants = parent.children(recursive=True)
                for child in reversed(descendants):
                    try:
                        child.terminate()
                    except psutil.Error:
                        pass
                try:
                    parent.terminate()
                except psutil.Error:
                    pass
                _, alive = psutil.wait_procs([*descendants, parent], timeout=6)
                for item in alive:
                    try:
                        item.kill()
                    except psutil.Error:
                        pass
                killed = True
            except Exception:
                killed = False
            if not killed:
                try:
                    if os.name == "nt":
                        subprocess.run(
                            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            timeout=12,
                            check=False,
                        )
                    else:
                        os.killpg(process.pid, signal.SIGTERM)
                        process.wait(timeout=5)
                except Exception:
                    try:
                        if os.name != "nt":
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                    except Exception:
                        pass
        log_thread = self._log_thread
        self._log_thread = None
        if log_thread and log_thread.is_alive():
            log_thread.join(timeout=1.5)

    def _schema_signature(self, name: str) -> dict[str, Any]:
        schema = self.tools.get(name, {}).get("schema", {}) or {}
        return {
            "required": schema.get("required", []),
            "properties": sorted((schema.get("properties") or {}).keys()),
        }

    def close(self) -> dict[str, Any]:
        self._closing.set()
        worker: Any | None = None
        result: dict[str, Any] = {"ok": True, "status": "already_closed"}
        try:
            with self._lifecycle_lock:
                worker = self._worker_future
                if not worker:
                    self._force_terminate_process()
                elif not worker.done():
                    reply: Future = Future()
                    self._commands.put({"kind": "close", "reply": reply})
                    result = reply.result(timeout=30)
                else:
                    result = {"ok": True, "status": "already_closed"}

            if worker is not None:
                try:
                    worker.result(timeout=15)
                except Exception:
                    # The process is local and will be terminated below. The
                    # crawler frontier remains durable even if transport cleanup
                    # itself reports an SDK-level teardown exception.
                    pass
            return result
        except Exception as exc:
            self._force_terminate_process()
            if worker and not worker.done():
                worker.cancel()
            return {
                "ok": False,
                "status": "close_failed",
                "error": self._error_text(exc, "close"),
                "error_type": type(exc).__name__,
            }
        finally:
            self.started = False
            self.loop_thread.stop()
            self._release_profile_lease()
            try:
                self._mcp_stream_logger.removeFilter(self._shutdown_filter)
            except Exception:
                pass


    def restart(self) -> dict[str, Any]:
        """Restart Playwright MCP while preserving the configured browser profile.

        ``close`` intentionally stops the owning asyncio loop. A clean restart
        therefore creates a new loop/command queue instead of trying to reuse
        cancelled AnyIO/MCP resources.
        """
        previous_url = self.server_url
        close_result = self.close()
        with self._lifecycle_lock:
            self.loop_thread = AsyncLoopThread()
            self._commands = queue.Queue()
            self._worker_future = None
            self._startup_future = None
            self._process = None
            self._log_thread = None
            self._log_stop = threading.Event()
            self._closing = threading.Event()
            self._shutdown_filter = _MCPExpectedShutdownNoiseFilter(self._closing)
            self._mcp_stream_logger = logging.getLogger("mcp.client.streamable_http")
            self._mcp_stream_logger.addFilter(self._shutdown_filter)
            self.session = None
            self.tools = {}
            self.started = False
            self.port = 0
            self.server_url = ""
            self._startup_phase = "not_started"
        started = self.start()
        return {
            **started,
            "restart": True,
            "previous_server_url": previous_url,
            "close_result": close_result,
        }

    def health_check(self) -> dict[str, Any]:
        """Cheap deterministic health check used by the self-healing controller."""
        if not self.started or not self._worker_future or self._worker_future.done():
            return {"ok": False, "status": "not_started"}
        result = self.snapshot(boxes=False, intent="Health check: capture current browser state")
        return {
            "ok": bool(result.get("ok")),
            "status": result.get("status", ""),
            "detail": str(result.get("detail") or "")[:1000],
        }

    def has_tool(self, name: str) -> bool:
        return name in self.tools

    def _adapt_args(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        schema = self.tools.get(name, {}).get("schema", {}) or {}
        props = schema.get("properties") or {}
        if not props:
            return args
        adapted = dict(args)
        if "target" in adapted and "target" not in props and "ref" in props:
            adapted["ref"] = adapted.pop("target")
        if "ref" in adapted and "ref" not in props and "target" in props:
            adapted["target"] = adapted.pop("ref")
        aliases = {
            "full_page": "fullPage",
            "text_gone": "textGone",
            "double_click": "doubleClick",
            "includeStatic": "static",
            "include_static": "static",
            "response_body": "responseBody",
            "response_headers": "responseHeaders",
        }
        for src, dst in aliases.items():
            if src in adapted and dst in props:
                adapted[dst] = adapted.pop(src)

        # Official Playwright MCP changed browser_evaluate from the older
        # ``expression`` argument to the current required ``function`` argument.
        # Read the live schema and bridge both forms so selecting ``latest`` does
        # not break the crawler after an MCP package update.
        if name == "browser_evaluate":
            if "function" in props and "function" not in adapted and "expression" in adapted:
                adapted["function"] = self._as_evaluate_function(str(adapted.pop("expression")))
            elif "expression" in props and "expression" not in adapted and "function" in adapted:
                adapted["expression"] = str(adapted.pop("function"))
        # Apply simple schema defaults before validating required fields.
        for key, spec in props.items():
            if key not in adapted and isinstance(spec, dict) and "default" in spec:
                adapted[key] = spec["default"]
        filtered = {k: v for k, v in adapted.items() if k in props and v is not None}
        required = schema.get("required", []) or []
        missing = [k for k in required if k not in filtered]
        if missing:
            raise ValueError(
                f"{name} missing required schema arguments {missing}; supplied={list(args)} schema={list(props)}"
            )
        return filtered

    def call(self, name: str, args: dict[str, Any] | None = None, intent: str = "") -> dict[str, Any]:
        safe_args = self._redact_args(args or {})
        if not self.started or not self._worker_future or self._worker_future.done():
            result = {
                "ok": False,
                "tool": name,
                "args": safe_args,
                "intent": intent,
                "status": "not_started",
                "detail": "MCP session is not started or the worker has stopped.",
            }
            self.calls.append(result)
            return result
        reply: Future = Future()
        self._commands.put({"kind": "call", "name": name, "args": args or {}, "intent": intent, "reply": reply})
        try:
            return reply.result(timeout=135)
        except Exception as exc:
            result = {
                "ok": False,
                "tool": name,
                "args": safe_args,
                "intent": intent,
                "status": "runtime_call_timeout" if isinstance(exc, FutureTimeoutError) else "runtime_call_exception",
                "detail": self._error_text(exc, f"call_tool:{name}"),
                "error_type": type(exc).__name__,
            }
            self.calls.append(result)
            return result

    async def _worker_call(self, session: Any, name: str, args: dict[str, Any], intent: str) -> dict[str, Any]:
        start = time.time()
        safe_args = self._redact_args(args)
        if name not in self.tools:
            result = {
                "ok": False,
                "tool": name,
                "args": safe_args,
                "intent": intent,
                "status": "tool_missing",
                "detail": f"Missing MCP tool: {name}",
            }
            self.calls.append(result)
            return result
        try:
            adapted = self._adapt_args(name, args)
            raw = await asyncio.wait_for(session.call_tool(name, adapted), timeout=125)
            detail = redact_text(content_to_text(raw))
            ok = not has_mcp_error(detail)
            result = {
                "ok": ok,
                "tool": name,
                "args": self._redact_args(adapted),
                "canonical_args": safe_args,
                "intent": intent,
                "status": "ok" if ok else "mcp_tool_error",
                "latency_ms": int((time.time() - start) * 1000),
                "detail": detail,
            }
        except Exception as exc:
            result = {
                "ok": False,
                "tool": name,
                "args": safe_args,
                "intent": intent,
                "status": "exception",
                "latency_ms": int((time.time() - start) * 1000),
                "detail": self._error_text(exc, f"call_tool:{name}"),
                "error_type": type(exc).__name__,
            }
        self.calls.append(result)
        return result

    @staticmethod
    def _redact_args(args: dict[str, Any]) -> dict[str, Any]:
        safe: dict[str, Any] = {}
        for key, value in args.items():
            lk = key.lower()
            if lk in {"password", "otp", "token", "cookie", "secret", "authorization"}:
                safe[key] = "<REDACTED>"
            elif lk in {"text", "value"} and isinstance(value, str) and (
                "password" in value.lower() or len(value) > 160
            ):
                safe[key] = f"<REDACTED length={len(value)}>"
            else:
                safe[key] = value
        return safe

    def snapshot(self, boxes: bool = True, depth: int | None = None, intent: str = "Capture accessibility snapshot") -> dict[str, Any]:
        args: dict[str, Any] = {"boxes": boxes}
        if depth is not None:
            args["depth"] = depth
        return self.call("browser_snapshot", args, intent)

    def find(self, text: str | None = None, regex: str | None = None, intent: str = "Find in snapshot") -> dict[str, Any]:
        args = {"text": text} if text else {"regex": regex}
        return self.call("browser_find", args, intent) if self.has_tool("browser_find") else self.snapshot(intent=intent)

    def screenshot(self, filename: str, full_page: bool = False, intent: str = "Capture screenshot") -> dict[str, Any]:
        # Playwright MCP resolves screenshot filenames relative to the server
        # process working directory, not reliably relative to --output-dir.
        # Force the relative path to point into the configured evidence folder
        # so the vision judge reads the exact file the MCP tool created.
        safe_name = Path(filename).name
        target = Path(self.output_dir) / safe_name
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            tool_filename = os.path.relpath(target, Path.cwd())
        except ValueError:  # Different Windows drives; absolute path fallback.
            tool_filename = str(target)
        return self.call(
            "browser_take_screenshot",
            {"type": "png", "scale": "css", "filename": tool_filename, "fullPage": full_page},
            intent,
        )

    def navigate(self, url: str, intent: str = "Navigate") -> dict[str, Any]:
        return self.call("browser_navigate", {"url": url}, intent)

    def click(self, target: str, element: str, intent: str = "Click element") -> dict[str, Any]:
        return self.call("browser_click", {"target": target, "element": element}, intent)

    def hover(self, target: str, element: str, intent: str = "Hover element") -> dict[str, Any]:
        return self.call("browser_hover", {"target": target, "element": element}, intent)

    def type_text(
        self,
        target: str,
        element: str,
        text: str,
        submit: bool = False,
        slowly: bool = False,
        intent: str = "Type text",
    ) -> dict[str, Any]:
        return self.call(
            "browser_type",
            {"target": target, "element": element, "text": text, "submit": submit, "slowly": slowly},
            intent,
        )

    def select_option(self, target: str, element: str, values: list[str], intent: str = "Select option") -> dict[str, Any]:
        return self.call("browser_select_option", {"target": target, "element": element, "values": values}, intent)

    def press_key(self, key: str, intent: str = "Press key") -> dict[str, Any]:
        return self.call("browser_press_key", {"key": key}, intent)

    def wait(
        self,
        seconds: float = 1.0,
        text: str | None = None,
        text_gone: str | None = None,
        intent: str = "Wait for UI",
    ) -> dict[str, Any]:
        args: dict[str, Any] = {}
        if seconds:
            args["time"] = seconds
        if text:
            args["text"] = text
        if text_gone:
            args["textGone"] = text_gone
        return self.call("browser_wait_for", args, intent)

    def tabs(
        self,
        action: str = "list",
        index: int | None = None,
        url: str | None = None,
        intent: str = "Manage tabs",
    ) -> dict[str, Any]:
        args: dict[str, Any] = {"action": action}
        if index is not None:
            args["index"] = index
        if url is not None:
            args["url"] = url
        return self.call("browser_tabs", args, intent)


    @staticmethod
    def _as_evaluate_function(expression: str) -> str:
        """Convert an application-owned JS expression to MCP's function form.

        Current official Playwright MCP expects ``function: "() => ..."``.
        Older releases accepted ``expression``.  Most crawler snippets are pure
        expressions (often ``JSON.stringify((() => {...})())``), so wrap them in
        a zero-argument function without changing their result.
        """
        code = str(expression or "").strip()
        if not code:
            return "() => null"
        if code.startswith("() =>") or code.startswith("async () =>"):
            return code
        return f"() => ({code})"

    def evaluate_readonly(self, expression: str, intent: str = "Read structured DOM evidence") -> dict[str, Any]:
        """Run fixed application-owned read-only JavaScript through live MCP schema.

        Page content and the LLM never supply executable code.  The call uses the
        current ``function`` argument while ``_adapt_args`` remains compatible with
        older Playwright MCP releases that exposed ``expression`` instead.
        """
        if not self.has_tool("browser_evaluate"):
            return {
                "ok": False,
                "tool": "browser_evaluate",
                "status": "tool_missing",
                "detail": "Official Playwright MCP browser_evaluate is unavailable.",
            }
        return self.call("browser_evaluate", {"function": self._as_evaluate_function(expression)}, intent)

    @staticmethod
    def _parse_json_detail(detail: str) -> dict[str, Any]:
        """Decode JSON returned by multiple Playwright MCP output formats."""
        raw = str(detail or "").strip()
        candidates: list[str] = []

        def add(value: str) -> None:
            value = str(value or "").strip()
            if value and value not in candidates:
                candidates.append(value)

        add(raw)
        # Current MCP commonly returns: ### Result\n"{\"key\":1}"
        for line in reversed(raw.splitlines()):
            line = line.strip()
            if not line or line.startswith("###") or line.startswith("```"):
                continue
            add(line)
            if line.startswith('"') and line.endswith('"'):
                try:
                    decoded = json.loads(line)
                    if isinstance(decoded, str):
                        add(decoded)
                except Exception:
                    pass
        # Older content renderers may expose a Python-like text='...' wrapper.
        match = re.search(r"\btext=(['\"])(.*?)\1(?:\s|$)", raw, re.S)
        if match:
            try:
                import ast
                decoded = ast.literal_eval(match.group(1) + match.group(2) + match.group(1))
                if isinstance(decoded, str):
                    add(decoded)
            except Exception:
                pass
        first, last = raw.find("{"), raw.rfind("}")
        if first >= 0 and last > first:
            add(raw[first:last + 1])

        # JSON may be encoded twice (a JSON string containing a JSON object).
        for candidate in list(candidates):
            value: Any = candidate
            for _ in range(3):
                if isinstance(value, dict):
                    return value
                if not isinstance(value, str):
                    break
                try:
                    value = json.loads(value)
                except Exception:
                    break
        return {}

    def scroll_next_viewport(self, intent: str = "Scroll Dell page for lazy content") -> dict[str, Any]:
        """Scroll by one viewport and return position/height telemetry.

        This application-owned expression performs navigation-only scrolling; it
        does not submit forms, change account state or execute page-provided code.
        """
        expression = r'''JSON.stringify((() => {
          const before = window.scrollY || document.documentElement.scrollTop || 0;
          const viewport = Math.max(320, Math.floor(window.innerHeight * 0.82));
          window.scrollBy({top: viewport, left: 0, behavior: 'instant'});
          const after = window.scrollY || document.documentElement.scrollTop || 0;
          const height = Math.max(document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0);
          return {before, after, viewport, height, atBottom: after + window.innerHeight >= height - 4};
        })())'''
        result = self.evaluate_readonly(expression, intent=intent)
        parsed = self._parse_json_detail(str(result.get("detail") or "")) if result.get("ok") else {}
        if parsed:
            result["scroll_state"] = parsed
            return result

        # ``browser_evaluate`` can be absent when devtools capability is disabled
        # or temporarily incompatible.  Scrolling is still possible through the
        # core keyboard tool, so do not trap the page in an endless self-heal loop.
        fallback = self.press_key("PageDown", intent=f"{intent} (keyboard fallback)")
        fallback["evaluate_failure"] = {
            "status": result.get("status"),
            "detail": str(result.get("detail") or "")[:1200],
        }
        if fallback.get("ok"):
            fallback["status"] = "scroll_key_fallback"
        return fallback

    def scroll_to_top(self, intent: str = "Return to top of Dell page") -> dict[str, Any]:
        expression = r'''JSON.stringify((() => { window.scrollTo({top: 0, left: 0, behavior: 'instant'}); return {scrollY: window.scrollY || 0}; })())'''
        result = self.evaluate_readonly(expression, intent=intent)
        parsed = self._parse_json_detail(str(result.get("detail") or "")) if result.get("ok") else {}
        if parsed:
            result["scroll_state"] = parsed
            return result
        fallback = self.press_key("Home", intent=f"{intent} (keyboard fallback)")
        fallback["evaluate_failure"] = {
            "status": result.get("status"),
            "detail": str(result.get("detail") or "")[:1200],
        }
        if fallback.get("ok"):
            fallback["status"] = "scroll_top_key_fallback"
        return fallback

    def install_mutation_observer(self, intent: str = "Install Dell crawler DOM mutation telemetry") -> dict[str, Any]:
        """Install a non-visual MutationObserver in the current page.

        The script is fixed application code. It records counts and short element
        descriptions only; it does not execute page-provided code or change page
        content. This improves post-click settle detection on React pages.
        """
        expression = r'''JSON.stringify((() => {
          try {
            if (window.__dellCrawlerMutationObserver) {
              window.__dellCrawlerMutationObserver.disconnect();
            }
            const state = {
              startedAt: Date.now(), lastMutationAt: Date.now(), total: 0,
              childList: 0, attributes: 0, characterData: 0,
              addedNodes: 0, removedNodes: 0, samples: []
            };
            const describe = node => {
              try {
                if (!node) return '';
                if (node.nodeType === Node.TEXT_NODE) return String(node.textContent || '').replace(/\s+/g,' ').trim().slice(0,160);
                const el = node;
                const label = String(el.getAttribute?.('aria-label') || el.innerText || el.textContent || '').replace(/\s+/g,' ').trim().slice(0,160);
                return `${String(el.tagName || '').toLowerCase()}|${label}`;
              } catch { return ''; }
            };
            const observer = new MutationObserver(records => {
              state.lastMutationAt = Date.now();
              for (const mutation of records) {
                state.total += 1;
                state[mutation.type] = (state[mutation.type] || 0) + 1;
                if (mutation.type === 'childList') {
                  state.addedNodes += mutation.addedNodes.length;
                  state.removedNodes += mutation.removedNodes.length;
                  for (const node of [...mutation.addedNodes, ...mutation.removedNodes]) {
                    const sample = describe(node);
                    if (sample && state.samples.length < 40 && !state.samples.includes(sample)) state.samples.push(sample);
                  }
                } else {
                  const sample = describe(mutation.target);
                  if (sample && state.samples.length < 40 && !state.samples.includes(sample)) state.samples.push(sample);
                }
              }
            });
            observer.observe(document.documentElement || document.body, {
              subtree: true, childList: true, attributes: true, characterData: true,
              attributeFilter: ['aria-expanded','aria-hidden','aria-disabled','hidden','class','style','src','href']
            });
            window.__dellCrawlerMutationState = state;
            window.__dellCrawlerMutationObserver = observer;
            return {ok:true, ...state};
          } catch (error) {
            return {ok:false, error:String(error)};
          }
        })())'''
        result = self.evaluate_readonly(expression, intent=intent)
        if result.get("ok"):
            result["mutation_state"] = self._parse_json_detail(str(result.get("detail") or ""))
        return result

    def read_mutation_state(self, reset: bool = False, intent: str = "Read Dell crawler DOM mutation telemetry") -> dict[str, Any]:
        reset_js = "true" if reset else "false"
        expression = rf'''JSON.stringify((() => {{
          const state = window.__dellCrawlerMutationState;
          if (!state) return {{ok:false, installed:false}};
          const result = {{ok:true, installed:true, now:Date.now(), quietForMs:Date.now()-state.lastMutationAt, ...state}};
          if ({reset_js}) {{
            state.startedAt = Date.now(); state.lastMutationAt = Date.now(); state.total = 0;
            state.childList = 0; state.attributes = 0; state.characterData = 0;
            state.addedNodes = 0; state.removedNodes = 0; state.samples = [];
          }}
          return result;
        }})())'''
        result = self.evaluate_readonly(expression, intent=intent)
        if result.get("ok"):
            result["mutation_state"] = self._parse_json_detail(str(result.get("detail") or ""))
        return result

    def wait_for_dom_quiet(
        self,
        quiet_window_ms: int = 700,
        max_wait_seconds: float = 12.0,
        poll_seconds: float = 0.2,
        intent: str = "Wait for Dell DOM mutations to settle",
    ) -> dict[str, Any]:
        """Wait until no observed DOM mutation occurs for the quiet window."""
        quiet_window_ms = max(100, int(quiet_window_ms))
        max_wait_seconds = max(0.5, float(max_wait_seconds))
        deadline = time.monotonic() + max_wait_seconds
        last: dict[str, Any] = {}
        while time.monotonic() < deadline:
            result = self.read_mutation_state(reset=False, intent=intent)
            state = result.get("mutation_state") if isinstance(result.get("mutation_state"), dict) else {}
            last = state
            if state.get("installed") and int(state.get("quietForMs") or 0) >= quiet_window_ms:
                return {"ok": True, "status": "dom_quiet", "detail": json.dumps(state), "mutation_state": state}
            if not result.get("ok") or state.get("installed") is False:
                return {"ok": False, "status": "observer_unavailable", "detail": str(result.get("detail") or ""), "mutation_state": state}
            time.sleep(max(0.05, float(poll_seconds)))
        return {"ok": True, "status": "dom_quiet_timeout", "detail": json.dumps(last), "mutation_state": last}

    def network_requests(
        self,
        filter_pattern: str = "",
        include_static: bool = False,
        include_body: bool = False,
        include_headers: bool = False,
        intent: str = "Inventory public page network requests",
    ) -> dict[str, Any]:
        """List requests observed by the current page through official Playwright MCP.

        Playwright MCP changed this schema over time. The current tool uses
        ``static`` while older builds used ``includeStatic`` and optionally
        exposed body/header switches. Live-schema filtering keeps both forms
        compatible.
        """
        if not self.has_tool("browser_network_requests"):
            return {
                "ok": False,
                "tool": "browser_network_requests",
                "status": "tool_missing",
                "detail": "Official Playwright MCP browser_network_requests is unavailable.",
            }
        args: dict[str, Any] = {
            "static": bool(include_static),
            "includeStatic": bool(include_static),
            "includeBody": bool(include_body),
            "includeHeaders": bool(include_headers),
        }
        if filter_pattern:
            args["filter"] = filter_pattern
        return self.call("browser_network_requests", args, intent)

    def network_request_detail(
        self,
        index: int,
        part: str = "",
        filename: str = "",
        intent: str = "Read one browser network request",
    ) -> dict[str, Any]:
        if not self.has_tool("browser_network_request"):
            return {
                "ok": False,
                "tool": "browser_network_request",
                "status": "tool_missing",
                "detail": "Official Playwright MCP browser_network_request is unavailable.",
            }
        args: dict[str, Any] = {"index": int(index)}
        if part:
            args["part"] = part
        if filename:
            args["filename"] = filename
        return self.call("browser_network_request", args, intent)

    def run_application_code(self, code: str, intent: str = "Run fixed application-owned Playwright code") -> dict[str, Any]:
        """Run fixed crawler code through the official Playwright code tool.

        This method is never given page text or LLM-generated JavaScript. It is
        used only for the packaged PDF APIRequestContext fallback where normal
        HTTP and page-context fetch are blocked by CORS/CDN policy.
        """
        for name in ("browser_run_code_unsafe", "browser_run_code"):
            if self.has_tool(name):
                return self.call(name, {"code": str(code)}, intent)
        return {
            "ok": False,
            "tool": "browser_run_code_unsafe",
            "status": "tool_missing",
            "detail": "Playwright MCP code tool is unavailable.",
        }

    @staticmethod
    def parse_tab_listing(detail: str) -> list[dict[str, Any]]:
        """Parse official Playwright MCP ``browser_tabs(list)`` output."""
        import re

        tabs: list[dict[str, Any]] = []
        for match in re.finditer(
            r"-\s*(\d+):\s*(\(current\)\s*)?\[([^\]]*)\]\(([^)]+)\)",
            detail or "",
        ):
            tabs.append(
                {
                    "index": int(match.group(1)),
                    "current": bool(match.group(2)),
                    "title": match.group(3),
                    "url": match.group(4),
                }
            )
        return tabs

    def tab_inventory(self, intent: str = "List browser tabs") -> list[dict[str, Any]]:
        result = self.tabs("list", intent=intent)
        if not result.get("ok"):
            return []
        return self.parse_tab_listing(str(result.get("detail") or ""))

    def select_tab(self, index: int, intent: str = "Select browser tab") -> dict[str, Any]:
        return self.tabs("select", index=index, intent=intent)

    def close_tab(self, index: int, intent: str = "Close browser tab") -> dict[str, Any]:
        return self.tabs("close", index=index, intent=intent)

    def start_trace(self, name: str = "trace") -> dict[str, Any]:
        del name  # Official 0.0.78 schema has no name field.
        if self.has_tool("browser_start_tracing"):
            return self.call("browser_start_tracing", {}, "Start Playwright trace")
        return {
            "ok": False,
            "status": "tool_missing",
            "tool": "browser_start_tracing",
            "detail": "Tracing tool is unavailable.",
        }

    def stop_trace(self) -> dict[str, Any]:
        if self.has_tool("browser_stop_tracing"):
            return self.call("browser_stop_tracing", {}, "Stop Playwright trace")
        return {
            "ok": False,
            "status": "tool_missing",
            "tool": "browser_stop_tracing",
            "detail": "Tracing tool is unavailable.",
        }

    def keep_single_dell_tab(self) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        listing = self.tabs("list", intent="List tabs before single-tab cleanup")
        events.append(listing)
        import re

        tabs: list[tuple[int, str, bool]] = []
        for match in re.finditer(r"-\s*(\d+):\s*(\(current\)\s*)?\[[^\]]*\]\(([^)]+)\)", listing.get("detail", "")):
            tabs.append((int(match.group(1)), match.group(3), bool(match.group(2))))
        for idx, url, current in sorted(tabs, reverse=True):
            if current:
                continue
            if url in {"about:blank", ""} or any(
                token in url for token in ("ntp.msn.com", "edge://newtab", "chrome://newtab")
            ):
                events.append(self.tabs("close", index=idx, intent="Close blank browser new tab"))
        return events
