from __future__ import annotations

"""Cross-page semantic classification and duplicate consolidation for v6.19."""

import json
import sqlite3
from collections import defaultdict
from typing import Any, Callable

from .knowledge_ontology import canonical_node_type
from .semantic_identity import (
    GRAPH_NODE_TYPES,
    classify_entity,
    classification_attributes,
    semantic_entity_key,
)


def _loads(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value or ""))
    except Exception:
        return {} if default is None else default


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _merge_attrs(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    out = dict(base or {})
    for key, value in (incoming or {}).items():
        if value in (None, "", [], {}):
            continue
        current = out.get(key)
        if current in (None, "", [], {}):
            out[key] = value
        elif isinstance(current, dict) and isinstance(value, dict):
            out[key] = _merge_attrs(current, value)
        elif isinstance(current, list) and isinstance(value, list):
            merged = list(current)
            for item in value:
                if item not in merged:
                    merged.append(item)
            out[key] = merged
    return out


def _row_score(row: sqlite3.Row, target_key: str) -> tuple[int, int, int]:
    attrs = _loads(row["attributes_json"], {})
    exact = 1000 if str(row["node_key"] or "") == target_key else 0
    richness = sum(int(v not in (None, "", [], {})) for v in attrs.values())
    return (exact, richness, -int(row["id"]))


def _move_alias_into_canonical(store: Any, canonical: sqlite3.Row, alias: sqlite3.Row, *, target_key: str) -> dict[str, int]:
    report = {"facts_moved": 0, "edges_moved": 0, "self_edges_removed": 0}
    canonical_id = int(canonical["id"])
    alias_id = int(alias["id"])
    if canonical_id == alias_id:
        return report

    with store.connect() as conn:
        facts = conn.execute("SELECT * FROM facts WHERE subject_id=?", (alias_id,)).fetchall()
        for fact in facts:
            before = conn.total_changes
            conn.execute(
                """
                INSERT OR IGNORE INTO facts(subject_id,predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    canonical_id, fact["predicate"], fact["value"], fact["unit"], fact["qualifiers_json"],
                    fact["source_url"], fact["confidence"], fact["observed_at"], fact["valid_from"], fact["valid_to"],
                ),
            )
            report["facts_moved"] += int(conn.total_changes > before)

        edges = conn.execute("SELECT * FROM edges WHERE source_id=? OR target_id=?", (alias_id, alias_id)).fetchall()
        for edge in edges:
            new_source = canonical_id if int(edge["source_id"]) == alias_id else int(edge["source_id"])
            new_target = canonical_id if int(edge["target_id"]) == alias_id else int(edge["target_id"])
            if new_source == new_target:
                report["self_edges_removed"] += 1
                continue
            existing = conn.execute(
                "SELECT id,attributes_json,confidence FROM edges WHERE source_id=? AND predicate=? AND target_id=? AND source_url=?",
                (new_source, edge["predicate"], new_target, edge["source_url"]),
            ).fetchone()
            if existing:
                attrs = _merge_attrs(_loads(existing["attributes_json"], {}), _loads(edge["attributes_json"], {}))
                conn.execute(
                    "UPDATE edges SET attributes_json=?,confidence=MAX(confidence,?),last_seen=MAX(last_seen,?) WHERE id=?",
                    (_json(attrs), float(edge["confidence"] or 0), edge["last_seen"], int(existing["id"])),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO edges(source_id,predicate,target_id,attributes_json,source_url,confidence,first_seen,last_seen)
                    VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (
                        new_source, edge["predicate"], new_target, edge["attributes_json"], edge["source_url"],
                        edge["confidence"], edge["first_seen"], edge["last_seen"],
                    ),
                )
                report["edges_moved"] += 1

        # Keep a durable alias so old external references remain explainable.
        conn.execute(
            """
            INSERT INTO semantic_entity_aliases(alias_key,canonical_node_key,node_type,reason,confidence,observed_at)
            VALUES(?,?,?,?,?,datetime('now'))
            ON CONFLICT(alias_key) DO UPDATE SET
                canonical_node_key=excluded.canonical_node_key,node_type=excluded.node_type,
                reason=excluded.reason,confidence=excluded.confidence,observed_at=excluded.observed_at
            """,
            (str(alias["node_key"]), target_key, str(canonical["node_type"]), "semantic_identity_duplicate_v618", 1.0),
        )
        conn.execute("DELETE FROM nodes WHERE id=?", (alias_id,))
    return report


def classify_and_consolidate(
    store: Any,
    *,
    preserve_as_evidence: Callable[[sqlite3.Row, str, str], None] | None = None,
) -> dict[str, Any]:
    """Classify every historical node and merge stable semantic duplicates.

    Products are deliberately excluded here and remain under the stronger dedicated
    order-code/part-number/PDP resolver.
    """
    report: dict[str, Any] = {
        "nodes_examined": 0,
        "nodes_reclassified": 0,
        "nodes_evidence_only_removed": 0,
        "identity_groups": 0,
        "duplicate_groups": 0,
        "nodes_merged": 0,
        "facts_moved": 0,
        "edges_moved": 0,
        "self_edges_removed": 0,
        "node_keys_rewritten": 0,
        "classification_counts": {},
    }

    with store.connect() as conn:
        rows = conn.execute("SELECT * FROM nodes WHERE node_type<>'Product' ORDER BY id").fetchall()
        source_urls = {
            str(r[0]) for r in conn.execute("SELECT canonical_url FROM sources WHERE canonical_url<>''").fetchall()
        }
        source_urls.update(str(r[0]) for r in conn.execute("SELECT url FROM sources WHERE url<>''").fetchall())

    groups: dict[str, list[sqlite3.Row]] = defaultdict(list)
    evidence_rows: list[tuple[sqlite3.Row, str]] = []
    classified_meta: dict[int, tuple[str, str, dict[str, Any]]] = {}

    for row in rows:
        report["nodes_examined"] += 1
        node_key = str(row["node_key"] or "")
        raw_type = str(row["node_type"] or "Unknown")
        name = str(row["name"] or node_key)
        attrs = _loads(row["attributes_json"], {})
        node_url = node_key[4:] if node_key.startswith("url:") else str(attrs.get("url") or attrs.get("canonical_url") or "")
        is_fetched_page = bool(node_url and node_url in source_urls)

        if is_fetched_page:
            node_type = canonical_node_type(raw_type, context="page")
            if node_type not in GRAPH_NODE_TYPES:
                node_type = "Page"
            classification_attrs = {
                "canonical_class": node_type,
                "classification_confidence": 1.0,
                "classification_reason": "historical_fetched_page",
                "classification_version": "v6.19",
            }
        else:
            entity = {"type": raw_type, "name": name, "url": node_url, "attributes": attrs}
            classification = classify_entity(entity, str(attrs.get("source_url") or ""), context="entity")
            node_type = classification.node_type or ""
            classification_attrs = classification_attributes(classification)

        if not node_type or node_type not in GRAPH_NODE_TYPES:
            evidence_rows.append((row, classification_attrs.get("classification_reason", "unclassified_historical_node")))
            continue

        stable_key = semantic_entity_key(
            node_type, name, attrs,
            url=node_url,
            source_url=str(attrs.get("source_url") or ""),
        )
        if not stable_key:
            evidence_rows.append((row, "semantic_identity_unresolved_historical_node"))
            continue

        attrs = _merge_attrs(attrs, classification_attrs)
        attrs["semantic_identity_key"] = stable_key
        classified_meta[int(row["id"])] = (node_type, stable_key, attrs)
        groups[stable_key].append(row)
        report["classification_counts"][node_type] = int(report["classification_counts"].get(node_type, 0)) + 1
        if raw_type != node_type:
            report["nodes_reclassified"] += 1

    # Preserve ambiguous/weak historical nodes outside the semantic graph.
    for row, reason in evidence_rows:
        if preserve_as_evidence:
            preserve_as_evidence(row, "historical_unclassified_node", reason)
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        report["nodes_evidence_only_removed"] += 1

    report["identity_groups"] = len(groups)
    for target_key, members in groups.items():
        # Refresh rows because earlier evidence deletions/merges can change the DB.
        live: list[sqlite3.Row] = []
        with store.connect() as conn:
            for member in members:
                row = conn.execute("SELECT * FROM nodes WHERE id=?", (int(member["id"]),)).fetchone()
                if row:
                    live.append(row)
        if not live:
            continue

        if len(live) > 1:
            report["duplicate_groups"] += 1
        canonical = max(live, key=lambda r: _row_score(r, target_key))
        canonical_id = int(canonical["id"])
        node_type, _, canonical_attrs = classified_meta[canonical_id]
        aliases: list[str] = []

        # Merge all aliases into the selected canonical row.
        for alias in live:
            if int(alias["id"]) == canonical_id:
                continue
            alias_meta = classified_meta.get(int(alias["id"]))
            if alias_meta:
                canonical_attrs = _merge_attrs(canonical_attrs, alias_meta[2])
            aliases.append(str(alias["node_key"]))
            moved = _move_alias_into_canonical(store, canonical, alias, target_key=target_key)
            for key in ("facts_moved", "edges_moved", "self_edges_removed"):
                report[key] += int(moved[key])
            report["nodes_merged"] += 1

        # Merge identity aliases and rewrite canonical key/type in-place.
        old_aliases = canonical_attrs.get("identity_aliases") if isinstance(canonical_attrs.get("identity_aliases"), list) else []
        canonical_attrs["identity_aliases"] = list(dict.fromkeys([*old_aliases, *aliases]))
        old_key = str(canonical["node_key"])
        with store.connect() as conn:
            # target key can only collide with a row in this group; aliases were deleted first.
            conn.execute(
                "UPDATE nodes SET node_key=?,node_type=?,attributes_json=? WHERE id=?",
                (target_key, node_type, _json(canonical_attrs), canonical_id),
            )
            if old_key != target_key:
                conn.execute(
                    """
                    INSERT INTO semantic_entity_aliases(alias_key,canonical_node_key,node_type,reason,confidence,observed_at)
                    VALUES(?,?,?,?,?,datetime('now'))
                    ON CONFLICT(alias_key) DO UPDATE SET canonical_node_key=excluded.canonical_node_key,
                        node_type=excluded.node_type,reason=excluded.reason,confidence=excluded.confidence,observed_at=excluded.observed_at
                    """,
                    (old_key, target_key, node_type, "canonical_key_rewrite_v618", 1.0),
                )
                report["node_keys_rewritten"] += 1

    # Remove exact duplicate/self edges left by historical graph noise.
    with store.connect() as conn:
        self_ids = [int(r[0]) for r in conn.execute("SELECT id FROM edges WHERE source_id=target_id").fetchall()]
        for eid in self_ids:
            conn.execute("DELETE FROM edges WHERE id=?", (eid,))
        report["self_edges_removed"] += len(self_ids)

    return report
