from __future__ import annotations

"""Safe database hygiene for crawler upgrades.

The crawler DB intentionally mixes durable knowledge with runtime telemetry so a
single file can resume interrupted runs.  Old runtime/browser-control history is
not knowledge and can become misleading after a major crawler upgrade.  This
module removes only objectively obsolete/runtime rows while preserving crawled
content, provenance, evidence, semantic graph data, product history, durable
AgentQ policy memory, and queue states that prevent accidental re-crawling.
"""

from pathlib import Path
from typing import Any
import os

from .kg_store import SQLiteKnowledgeGraph


EPHEMERAL_TABLES: tuple[str, ...] = (
    "interactions",
    "self_heal_events",
    "dynamic_control_progress",
    "control_progress",
    "web_state_observations",
    "action_decisions",
    "action_trajectories",
)


def _count(conn, table: str) -> int:
    try:
        return int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
    except Exception:
        return 0


def _file_size(path: Path) -> int:
    try:
        return int(path.stat().st_size)
    except OSError:
        return 0


def database_hygiene_report(store: SQLiteKnowledgeGraph) -> dict[str, Any]:
    """Report rows that are safe candidates for v6.20 cleanup."""
    with store.connect() as conn:
        report: dict[str, Any] = {
            "ephemeral_runtime_rows": {table: _count(conn, table) for table in EPHEMERAL_TABLES},
            "crawl_runs": _count(conn, "crawl_runs"),
            "orphan_semantic_aliases": int(conn.execute(
                """
                SELECT COUNT(*) FROM semantic_entity_aliases a
                WHERE NOT EXISTS (SELECT 1 FROM nodes n WHERE n.node_key=a.canonical_node_key)
                """
            ).fetchone()[0]),
            "orphan_product_identity_aliases": int(conn.execute(
                """
                SELECT COUNT(*) FROM product_identity_aliases a
                WHERE NOT EXISTS (
                    SELECT 1 FROM nodes n
                    WHERE n.node_type='Product' AND n.node_key=a.canonical_product_key
                )
                """
            ).fetchone()[0]),
            "orphan_product_enrichment_rows": int(conn.execute(
                """
                SELECT COUNT(*) FROM product_enrichment_state e
                WHERE NOT EXISTS (
                    SELECT 1 FROM nodes n
                    WHERE n.node_type='Product'
                      AND (n.id=e.product_id OR n.node_key=e.product_key)
                )
                """
            ).fetchone()[0]),
            "orphan_validation_rows": int(conn.execute(
                """
                SELECT COUNT(*) FROM extraction_validation v
                WHERE NOT EXISTS (SELECT 1 FROM sources s WHERE s.url=v.source_url OR s.canonical_url=v.source_url)
                  AND NOT EXISTS (SELECT 1 FROM crawl_queue q WHERE q.url=v.source_url)
                """
            ).fetchone()[0]),
            "dead_empty_sources": int(conn.execute(
                """
                SELECT COUNT(*) FROM sources s
                WHERE s.http_status IN (404,410)
                  AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=s.url)
                  AND NOT EXISTS (SELECT 1 FROM extraction_evidence e WHERE e.source_url=s.url)
                  AND NOT EXISTS (SELECT 1 FROM link_evidence l WHERE l.source_url=s.url)
                  AND NOT EXISTS (
                    SELECT 1 FROM nodes n
                    WHERE n.node_key=('url:' || s.url) OR n.node_key=('url:' || s.canonical_url)
                  )
                """
            ).fetchone()[0]),
            "irrelevant_skipped_queue_rows": int(conn.execute(
                """
                SELECT COUNT(*) FROM crawl_queue q
                WHERE q.status IN ('SKIPPED','SKIPPED_DUPLICATE_ASSET')
                  AND NOT EXISTS (SELECT 1 FROM sources s WHERE s.url=q.url OR s.canonical_url=q.url)
                  AND NOT EXISTS (SELECT 1 FROM link_evidence l WHERE l.target_url=q.url)
                """
            ).fetchone()[0]),
            "durable_action_policy_rows": _count(conn, "action_policy_memory"),
            "knowledge_counts": {
                "sources": _count(conn, "sources"),
                "nodes": _count(conn, "nodes"),
                "edges": _count(conn, "edges"),
                "facts": _count(conn, "facts"),
                "chunks": _count(conn, "chunks"),
                "extraction_evidence": _count(conn, "extraction_evidence"),
                "link_evidence": _count(conn, "link_evidence"),
                "product_observations": _count(conn, "product_observations"),
            },
        }
    report["database_bytes"] = _file_size(store.db_path)
    return report


def purge_irrelevant_legacy_data(
    store: SQLiteKnowledgeGraph,
    *,
    keep_crawl_runs: int = 3,
    purge_runtime_telemetry: bool = True,
    vacuum: bool = True,
) -> dict[str, Any]:
    """Remove obsolete upgrade/runtime data without deleting real knowledge.

    Safety contract:
    - durable knowledge/provenance/evidence tables are preserved;
    - ``action_policy_memory`` is preserved so learned UI policy survives;
    - DONE/DONE_INCOMPLETE/FAILED/DEFERRED/SKIPPED_PERMANENT queue rows are
      preserved because they are needed for resumability/revisit suppression;
    - a caller is expected to create a SQLite backup before this function runs.
    """
    before = database_hygiene_report(store)
    deleted: dict[str, int] = {}

    with store.connect() as conn:
        if purge_runtime_telemetry:
            for table in EPHEMERAL_TABLES:
                cur = conn.execute(f"DELETE FROM {table}")
                deleted[table] = max(0, int(cur.rowcount or 0))

        keep = max(0, int(keep_crawl_runs))
        if keep == 0:
            cur = conn.execute("DELETE FROM crawl_runs")
            deleted["crawl_runs"] = max(0, int(cur.rowcount or 0))
        else:
            cur = conn.execute(
                """
                DELETE FROM crawl_runs
                WHERE run_id NOT IN (
                    SELECT run_id FROM crawl_runs
                    ORDER BY started_at DESC, run_id DESC
                    LIMIT ?
                )
                """,
                (keep,),
            )
            deleted["crawl_runs"] = max(0, int(cur.rowcount or 0))

        cur = conn.execute(
            """
            DELETE FROM semantic_entity_aliases
            WHERE NOT EXISTS (SELECT 1 FROM nodes n WHERE n.node_key=semantic_entity_aliases.canonical_node_key)
            """
        )
        deleted["orphan_semantic_aliases"] = max(0, int(cur.rowcount or 0))

        cur = conn.execute(
            """
            DELETE FROM product_identity_aliases
            WHERE NOT EXISTS (
                SELECT 1 FROM nodes n
                WHERE n.node_type='Product' AND n.node_key=product_identity_aliases.canonical_product_key
            )
            """
        )
        deleted["orphan_product_identity_aliases"] = max(0, int(cur.rowcount or 0))

        cur = conn.execute(
            """
            DELETE FROM product_enrichment_state
            WHERE NOT EXISTS (
                SELECT 1 FROM nodes n
                WHERE n.node_type='Product'
                  AND (n.id=product_enrichment_state.product_id OR n.node_key=product_enrichment_state.product_key)
            )
            """
        )
        deleted["orphan_product_enrichment_rows"] = max(0, int(cur.rowcount or 0))

        cur = conn.execute(
            """
            DELETE FROM extraction_validation
            WHERE NOT EXISTS (SELECT 1 FROM sources s WHERE s.url=extraction_validation.source_url OR s.canonical_url=extraction_validation.source_url)
              AND NOT EXISTS (SELECT 1 FROM crawl_queue q WHERE q.url=extraction_validation.source_url)
            """
        )
        deleted["orphan_validation_rows"] = max(0, int(cur.rowcount or 0))

        # Remove empty tombstone source rows only when they carry no retained
        # content, evidence, discovery provenance, or graph identity.  The
        # SKIPPED_PERMANENT queue row is intentionally retained to avoid re-fetch.
        dead_urls = [str(r[0]) for r in conn.execute(
            """
            SELECT s.url FROM sources s
            WHERE s.http_status IN (404,410)
              AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=s.url)
              AND NOT EXISTS (SELECT 1 FROM extraction_evidence e WHERE e.source_url=s.url)
              AND NOT EXISTS (SELECT 1 FROM link_evidence l WHERE l.source_url=s.url)
              AND NOT EXISTS (
                SELECT 1 FROM nodes n
                WHERE n.node_key=('url:' || s.url) OR n.node_key=('url:' || s.canonical_url)
              )
            """
        ).fetchall()]
        if dead_urls:
            placeholders = ",".join("?" for _ in dead_urls)
            cur = conn.execute(f"DELETE FROM sources WHERE url IN ({placeholders})", dead_urls)
            deleted["dead_empty_sources"] = max(0, int(cur.rowcount or 0))
        else:
            deleted["dead_empty_sources"] = 0

        cur = conn.execute(
            """
            DELETE FROM crawl_queue
            WHERE status IN ('SKIPPED','SKIPPED_DUPLICATE_ASSET')
              AND NOT EXISTS (SELECT 1 FROM sources s WHERE s.url=crawl_queue.url OR s.canonical_url=crawl_queue.url)
              AND NOT EXISTS (SELECT 1 FROM link_evidence l WHERE l.target_url=crawl_queue.url)
            """
        )
        deleted["irrelevant_skipped_queue_rows"] = max(0, int(cur.rowcount or 0))

        # Clean free-list pages and refresh query planner statistics.  VACUUM is
        # run after this transaction because SQLite forbids VACUUM in a tx.
        conn.execute("PRAGMA optimize")

    if vacuum:
        # Checkpoint before VACUUM so a large stale WAL does not survive upgrade.
        with store.connect() as conn:
            try:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
        # Use a dedicated connection in autocommit mode for VACUUM.
        import sqlite3
        conn = sqlite3.connect(store.db_path, timeout=120, isolation_level=None)
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("VACUUM")
            conn.execute("PRAGMA optimize")
        finally:
            conn.close()

    after = database_hygiene_report(store)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk_violations = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]

    return {
        "policy": "v6.20-safe-legacy-cleanup",
        "backup_expected_before_cleanup": True,
        "deleted": deleted,
        "preserved": {
            "semantic_knowledge": True,
            "source_content_and_chunks": True,
            "extraction_and_link_evidence": True,
            "product_observations": True,
            "durable_action_policy_memory": True,
            "revisit_suppression_queue_states": [
                "DONE", "DONE_INCOMPLETE", "DONE_WITH_HTTP_FALLBACK", "FAILED", "DEFERRED", "SKIPPED_PERMANENT"
            ],
        },
        "before": before,
        "after": after,
        "bytes_reclaimed": max(0, int(before.get("database_bytes", 0)) - int(after.get("database_bytes", 0))),
        "integrity_check": integrity,
        "foreign_key_violations": fk_violations,
        "ok": integrity.casefold() == "ok" and not fk_violations,
    }
