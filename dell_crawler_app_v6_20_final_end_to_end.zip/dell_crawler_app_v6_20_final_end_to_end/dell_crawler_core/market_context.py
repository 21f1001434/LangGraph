from __future__ import annotations

"""Locale/market/currency normalization for Dell crawler evidence.

The crawler can bootstrap from one locale and later discover Dell-owned pages from
other markets.  Extraction must therefore derive market/currency from the evidence
being processed rather than assuming UK/GBP globally.
"""

from dataclasses import dataclass
import re
from typing import Any
from urllib.parse import urlparse


_LOCALE_MARKET: dict[str, tuple[str, str, str]] = {
    "en-uk": ("UK", "United Kingdom", "GBP"),
    "en-us": ("US", "United States", "USD"),
    "en-in": ("IN", "India", "INR"),
    "en-ca": ("CA", "Canada", "CAD"),
    "fr-ca": ("CA", "Canada", "CAD"),
    "en-au": ("AU", "Australia", "AUD"),
    "de-de": ("DE", "Germany", "EUR"),
    "fr-fr": ("FR", "France", "EUR"),
    "it-it": ("IT", "Italy", "EUR"),
    "es-es": ("ES", "Spain", "EUR"),
    "nl-nl": ("NL", "Netherlands", "EUR"),
    "pt-br": ("BR", "Brazil", "BRL"),
    "ja-jp": ("JP", "Japan", "JPY"),
    "ko-kr": ("KR", "South Korea", "KRW"),
    "zh-cn": ("CN", "China", "CNY"),
    "zh-tw": ("TW", "Taiwan", "TWD"),
}

# Dell occasionally uses country-first aliases in redirects/legacy links.
_LOCALE_ALIASES: dict[str, str] = {
    "uk-en": "en-uk",
    "us-en": "en-us",
    "in-en": "en-in",
    "ca-en": "en-ca",
    "ca-fr": "fr-ca",
    "au-en": "en-au",
}

_VALID_CURRENCY = frozenset({
    "GBP", "USD", "EUR", "INR", "CAD", "AUD", "BRL", "JPY", "CNY", "RMB",
    "KRW", "TWD", "CHF", "SEK", "NOK", "DKK", "PLN", "CZK", "HUF", "SGD", "MYR",
})

_SYMBOL_CURRENCY: dict[str, str] = {
    "£": "GBP",
    "€": "EUR",
    "₹": "INR",
}

_LOCALE_RE = re.compile(r"/(?:([a-z]{2})-([a-z]{2}))(?:/|$)", re.I)
_CURRENCY_CODE_RE = re.compile(r"\b(GBP|USD|EUR|INR|CAD|AUD|BRL|JPY|CNY|RMB|KRW|TWD|CHF|SEK|NOK|DKK|PLN|CZK|HUF|SGD|MYR)\b", re.I)


@dataclass(frozen=True, slots=True)
class MarketContext:
    locale: str
    market: str
    market_name: str
    currency: str

    def as_dict(self) -> dict[str, str]:
        return {
            "locale": self.locale,
            "market": self.market,
            "market_name": self.market_name,
            "currency": self.currency,
        }




def normalize_locale(value: Any, *, default: str = "en-uk") -> str:
    """Normalize Dell locale aliases without inventing a different market."""
    raw = str(value or "").strip().lower().replace("_", "-")
    raw = _LOCALE_ALIASES.get(raw, raw)
    if re.fullmatch(r"[a-z]{2}-[a-z]{2}", raw):
        return raw
    fallback = str(default or "").strip().lower().replace("_", "-")
    fallback = _LOCALE_ALIASES.get(fallback, fallback)
    return fallback if re.fullmatch(r"[a-z]{2}-[a-z]{2}", fallback) else "en-uk"


def market_for_locale(locale: str) -> str:
    return _LOCALE_MARKET.get(normalize_locale(locale), ("GLOBAL", "Global Dell", ""))[0]


def currency_for_locale(locale: str) -> str:
    return _LOCALE_MARKET.get(normalize_locale(locale), ("GLOBAL", "Global Dell", ""))[2]


def accept_language_for_locale(locale: str) -> str:
    loc = normalize_locale(locale)
    language, country = loc.split("-", 1)
    # BCP-47 uses GB rather than UK. Other configured Dell locales map directly.
    region = "GB" if country == "uk" else country.upper()
    primary = f"{language.lower()}-{region}"
    return f"{primary},{language.lower()};q=0.9"


def hreflang_aliases(locale: str) -> set[str]:
    loc = normalize_locale(locale)
    aliases = {loc, "x-default"}
    if loc == "en-uk":
        aliases.add("en-gb")
    return aliases

def normalize_currency(value: Any) -> str:
    text = str(value or "").strip().upper()
    if text == "RMB":
        return "CNY"
    return text if text in _VALID_CURRENCY else ""


def locale_from_url(url: str) -> str:
    try:
        path = urlparse(str(url or "")).path.casefold()
    except Exception:
        path = ""
    match = _LOCALE_RE.search(path)
    if not match:
        return ""
    locale = f"{match.group(1).lower()}-{match.group(2).lower()}"
    return _LOCALE_ALIASES.get(locale, locale)


def currency_from_text(text: str, *, locale: str = "") -> str:
    """Infer currency only when there is an explicit currency signal.

    ``$`` and ``¥`` are ambiguous, so locale decides their meaning. If locale is
    unavailable we intentionally return an empty value rather than inventing one.
    """
    value = str(text or "")
    code = _CURRENCY_CODE_RE.search(value)
    if code:
        return normalize_currency(code.group(1))
    for symbol, currency in _SYMBOL_CURRENCY.items():
        if symbol in value:
            return currency
    if "$" in value:
        market = _LOCALE_MARKET.get(locale, ("", "", ""))[0]
        return {"US": "USD", "CA": "CAD", "AU": "AUD", "SG": "SGD"}.get(market, "")
    if "¥" in value:
        market = _LOCALE_MARKET.get(locale, ("", "", ""))[0]
        return {"JP": "JPY", "CN": "CNY"}.get(market, "")
    return ""


def infer_market_context(
    url: str,
    *,
    explicit_currency: Any = "",
    evidence_text: str = "",
    fallback_locale: str = "",
) -> MarketContext:
    locale = locale_from_url(url)
    if not locale and str(fallback_locale or "").strip():
        locale = normalize_locale(fallback_locale)
    locale = _LOCALE_ALIASES.get(locale, locale)
    market, market_name, default_currency = _LOCALE_MARKET.get(locale, ("GLOBAL", "Global Dell", ""))
    currency = normalize_currency(explicit_currency)
    if not currency:
        currency = currency_from_text(evidence_text, locale=locale)
    if not currency:
        currency = default_currency
    return MarketContext(locale=locale or "global", market=market, market_name=market_name, currency=currency)


def price_predicate(currency: str) -> str:
    """Preserve the legacy UK predicate while using a market-neutral one elsewhere."""
    return "PRICE_GBP" if normalize_currency(currency) == "GBP" else "PRICE"


def currency_symbol_pattern() -> str:
    return r"[£$€₹¥]"
