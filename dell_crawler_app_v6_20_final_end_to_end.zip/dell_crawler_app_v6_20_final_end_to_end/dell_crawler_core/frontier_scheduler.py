from __future__ import annotations

"""Fast durable frontier classification for the Dell locale knowledge crawler.

The browser is intentionally reserved for HTML pages that need JavaScript and
interaction. Documents, structured data and visual assets use cheaper dedicated
lanes so thousands of images cannot starve the page frontier.
"""

import hashlib
import re
from pathlib import Path
from urllib.parse import parse_qs, urlparse


PAGE = "PAGE"
SITEMAP = "SITEMAP"
DOCUMENT = "DOCUMENT"
DATA = "DATA"
ASSET = "ASSET"
BINARY = "BINARY"

LANE_PRIORITY = {
    SITEMAP: 0,
    PAGE: 10,
    DOCUMENT: 20,
    DATA: 30,
    ASSET: 80,
    BINARY: 90,
}

_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff", ".svg", ".avif"}
_DOCUMENT_EXTENSIONS = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".txt", ".md", ".rst", ".csv", ".tsv", ".json", ".xml", ".yaml", ".yml", ".vtt", ".srt", ".ttml"}
_DATA_EXTENSIONS = {".json", ".xml", ".csv", ".tsv", ".vtt", ".srt", ".ttml"}
_BINARY_EXTENSIONS = {".zip", ".7z", ".rar", ".exe", ".msi", ".cab", ".iso", ".dmg", ".pkg", ".bin", ".img", ".rom", ".fw", ".deb", ".rpm", ".jar", ".war", ".tar", ".gz", ".bz2", ".xz"}


def is_dell_image_service_url(url: str) -> bool:
    parsed = urlparse(str(url or ""))
    return parsed.netloc.lower().endswith("i.dell.com") and parsed.path.lower().startswith("/is/image/")


def is_visual_asset_url(url: str) -> bool:
    parsed = urlparse(str(url or ""))
    return is_dell_image_service_url(url) or Path(parsed.path).suffix.lower() in _IMAGE_EXTENSIONS


def classify_frontier_url(url: str, relation: str = "") -> str:
    parsed = urlparse(str(url or ""))
    path = parsed.path.lower()
    suffix = Path(path).suffix.lower()
    rel = str(relation or "").lower()
    if suffix == ".xml" and "sitemap" in path:
        return SITEMAP
    if is_visual_asset_url(url):
        return ASSET
    if suffix == ".pdf" or ".pdf.external" in path or suffix in (_DOCUMENT_EXTENSIONS - _DATA_EXTENSIONS):
        return DOCUMENT
    if suffix in _DATA_EXTENSIONS or re.search(r"/(?:api|graphql|data|feeds?)(?:/|$)", path):
        return DATA
    if suffix in _BINARY_EXTENSIONS:
        return BINARY
    if any(token in rel for token in ("document", "brochure", "manual", "whitepaper", "datasheet")):
        return DOCUMENT
    return PAGE


def lane_priority(resource_class: str) -> int:
    return int(LANE_PRIORITY.get(str(resource_class or PAGE).upper(), 50))


def asset_family_key(url: str) -> str:
    """Stable identity for resized variants of the same Dell visual.

    i.dell.com uses query parameters for width/height/format transforms. Those
    variants represent the same source visual and should be vision-analysed once,
    using the best discovered resolution.
    """
    parsed = urlparse(str(url or ""))
    if is_dell_image_service_url(url):
        raw = f"{parsed.netloc.lower()}{parsed.path}"
    else:
        raw = f"{parsed.netloc.lower()}{parsed.path}?{parsed.query}"
    return "asset:" + hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def asset_resolution_score(url: str) -> int:
    parsed = urlparse(str(url or ""))
    query = parse_qs(parsed.query)

    def first_int(*names: str) -> int:
        for name in names:
            for key, values in query.items():
                if key.lstrip(";").lower() == name.lower() and values:
                    try:
                        return max(0, int(float(str(values[0]).split(",")[0])))
                    except Exception:
                        pass
        return 0

    width = first_int("wid", "width", "w")
    height = first_int("hei", "height", "h")
    # Some Scene7 URLs carry size=2560,1440.
    for key, values in query.items():
        if key.lstrip(";").lower() == "size" and values:
            try:
                a, b = re.split(r"[,x]", values[0], maxsplit=1)
                width = max(width, int(float(a)))
                height = max(height, int(float(b)))
            except Exception:
                pass
    area = width * height
    return area if area > 0 else width * 1000 + height


def semantic_control_context_key(role: str, label: str, context: str = "", action_kind: str = "") -> str:
    norm = lambda value: re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()
    payload = "|".join((norm(role), norm(label), norm(context), norm(action_kind)))
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()[:24]
