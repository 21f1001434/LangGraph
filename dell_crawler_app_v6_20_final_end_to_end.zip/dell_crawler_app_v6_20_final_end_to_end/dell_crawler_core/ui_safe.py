from __future__ import annotations

import json
from typing import Any


def arrow_safe_cell(value: Any) -> str:
    """Render arbitrary rich metadata as a deterministic Arrow-safe string."""
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple, set)):
        try:
            if isinstance(value, set):
                value = sorted(value, key=str)
            return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
        except Exception:
            return str(value)
    return str(value)


def arrow_safe_records(records: Any) -> list[dict[str, str]]:
    """Convert list-of-dicts returned by SQLite into Streamlit/PyArrow-safe rows."""
    if records is None:
        return []
    if hasattr(records, "to_dict"):
        try:
            records = records.to_dict(orient="records")
        except Exception:
            pass
    if isinstance(records, dict):
        records = [records]
    output: list[dict[str, str]] = []
    for row in records if isinstance(records, (list, tuple)) else []:
        if isinstance(row, dict):
            output.append({str(key): arrow_safe_cell(value) for key, value in row.items()})
        else:
            output.append({"value": arrow_safe_cell(row)})
    return output
