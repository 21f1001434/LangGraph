from __future__ import annotations

"""Deterministic Dell masthead taxonomy discovery.

This module turns the live Dell header menus into first-class crawl seeds.  It is
purposefully separate from ordinary page crawling because global navigation is often
implemented as hover/click menus whose child links do not exist in the initial DOM.

Only read-only navigation is exercised.  Transactional/security-sensitive entries
(e.g. payment, checkout, sign out, sign in, account mutation) are recorded in the
coverage report but never activated by this discovery pass.
"""

from dataclasses import dataclass, field
import hashlib
import re
from typing import Any
from urllib.parse import urlparse

from .snapshot import parse_nodes, parse_page_info, resolve_ref
from .market_context import normalize_locale
from .snapshot_extract import (
    canonicalize_url,
    extract_links,
    is_locale_scope,
    is_trusted_dell_url,
)
from .authenticated_session import safe_authenticated_account_url


# The labels below are the current Dell masthead families supplied in the user's
# screenshots.  Runtime discovery remains authoritative: labels not listed here are
# still collected when Dell adds them.  The manifest gives us a deterministic audit
# so a silently collapsed/missing menu cannot be mistaken for full coverage.
EXPECTED_MENU_MANIFEST: dict[str, tuple[str, ...]] = {
    "Artificial Intelligence": (),
    "IT Infrastructure": (
        "Products", "Workloads", "Industry", "Dell APEX Subscriptions",
        "Dell Automation Platform", "Payment Solutions", "Developers & DevOps",
    ),
    "Computers & Accessories": (
        "Laptops", "Desktops & All-in-Ones", "Monitors", "Gaming", "PC Accessories",
        "Electronics", "Parts, Batteries & Upgrades", "Software",
        "Video Conferencing Room Solutions", "Thin Clients", "Workstations",
    ),
    "Services": (
        "View All Services", "Professional Services", "Lifecycle Services",
        "Training & Certification", "Technology & Tools",
    ),
    "Support": (
        "Support Home", "Support Library", "Support Videos", "Support Services & Warranty",
        "Drivers & Downloads", "Manuals & Documentation", "PC Diagnostics",
        "Self-Repair & Parts", "Service Requests & Dispatch Status", "Order Support",
        "Contact Technical Support", "Community",
    ),
    "Deals": (
        "View All Deals", "Laptop Deals", "Desktop Deals", "Gaming PC Deals",
        "Business PC Deals", "Monitor Deals", "Electronics & Accessories Deals",
        "Student Deals", "Why Buy Direct from Dell", "Discounts, Offers & Coupons",
        "Financing", "Dell Rewards", "Dell Outlet (Certified Refurbished)",
    ),
    "Financing": (
        "For Home Purchases", "For Business Purchases", "Make a Payment - Home",
        "Make a Payment - Business",
    ),
    "Account / Profile": (
        "Dell Technologies", "Premier Sign In", "Partner Program Sign In",
        "Dell Financial Services", "Support", "My Account", "Order Status",
        "Profile Settings", "My Saved Items", "My Products", "Make a Payment",
        "Dell Rewards Balance", "Sign Out",
    ),
}

# Known first-level menu items that commonly open another flyout.  Unknown controls
# advertising a popup/expanded state are also explored at runtime.
KNOWN_SUBMENU_PARENTS = {
    "Products", "Workloads", "Industry", "Professional Services", "Lifecycle Services",
    "Discounts, Offers & Coupons", "Laptops", "Desktops & All-in-Ones", "Monitors",
    "Gaming", "PC Accessories", "Electronics", "Workstations",
}

_UNSAFE_LABEL_RE = re.compile(
    r"(?:\bmake a payment\b|\bpay(?:ment)? now\b|\bcheckout\b|\bcart\b|\bbasket\b|"
    r"\bsign out\b|\bsign in\b|\blog ?in\b|\bpremier sign in\b|\bpartner program sign in\b|"
    r"\bdelete\b|\bremove\b|\bedit\b|\bupdate\b|\bsave changes\b|\bcreate account\b)",
    re.I,
)

_NOISE_LABEL_RE = re.compile(
    r"(?:virtual assistant|transparency statement|cookie|privacy choices|feedback|chat)", re.I
)


def _norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()


def _safe_public_url(url: str, locale: str, *, authenticated: bool = False) -> bool:
    candidate = canonicalize_url(url, f"https://www.dell.com/{locale}")
    if not candidate or not is_trusted_dell_url(candidate):
        return False
    path = urlparse(candidate).path.lower()
    if "/myaccount/" in path:
        return bool(authenticated and safe_authenticated_account_url(candidate))
    return is_locale_scope(candidate, locale=locale, allow_cross_dell_assets=True, include_community_feedback=True)


@dataclass(slots=True)
class MastheadDiscoveryResult:
    urls: list[str] = field(default_factory=list)
    groups: dict[str, dict[str, Any]] = field(default_factory=dict)
    labels_observed: list[str] = field(default_factory=list)
    unsafe_labels_skipped: list[str] = field(default_factory=list)
    actions: int = 0
    status: str = "NOT_STARTED"
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "detail": self.detail,
            "urls": list(self.urls),
            "url_count": len(self.urls),
            "groups": self.groups,
            "labels_observed": list(self.labels_observed),
            "unsafe_labels_skipped": list(self.unsafe_labels_skipped),
            "actions": self.actions,
        }


class DellMastheadDiscovery:
    def __init__(
        self,
        runtime: Any,
        *,
        locale: str = "en-uk",
        profile_name: str = "",
        authenticated: bool = False,
        max_submenu_depth: int = 4,
        max_actions: int = 250,
        emit: Any | None = None,
    ) -> None:
        self.runtime = runtime
        self.locale = normalize_locale(locale)
        self.home = f"https://www.dell.com/{self.locale}"
        self.profile_name = (profile_name or "").strip()
        self.authenticated = bool(authenticated)
        self.max_submenu_depth = max(1, int(max_submenu_depth))
        self.max_actions = max(1, int(max_actions))
        self.emit = emit
        self.result = MastheadDiscoveryResult()
        self._url_seen: set[str] = set()
        self._label_seen: set[str] = set()
        self._state_seen: set[str] = set()

    def _event(self, event: str, **payload: Any) -> None:
        if self.emit:
            try:
                self.emit(event, **payload)
            except Exception:
                pass

    def _snapshot(self, intent: str) -> str:
        result = self.runtime.snapshot(boxes=True, intent=intent)
        return str(result.get("detail") or "") if result.get("ok") else ""

    def _state_key(self, snapshot: str) -> str:
        # Menu state identity should be stable across volatile ref IDs.
        names = sorted({_norm(node.name) for node in parse_nodes(snapshot) if node.name})
        info = parse_page_info(snapshot)
        raw = f"{canonicalize_url(str(info.get('url') or ''), self.home)}\n" + "\n".join(names)
        return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()

    def _remember_label(self, label: str) -> None:
        clean = re.sub(r"\s+", " ", label or "").strip()
        if not clean or _NOISE_LABEL_RE.search(clean):
            return
        key = _norm(clean)
        if key and key not in self._label_seen:
            self._label_seen.add(key)
            self.result.labels_observed.append(clean)

    def _collect(self, snapshot: str, group: str) -> list[str]:
        group_data = self.result.groups.setdefault(group, {
            "expected_labels": list(EXPECTED_MENU_MANIFEST.get(group, ())),
            "observed_labels": [],
            "urls": [],
            "missing_expected_labels": [],
            "status": "PENDING",
        })
        observed_group = {_norm(v) for v in group_data["observed_labels"]}
        for node in parse_nodes(snapshot):
            label = re.sub(r"\s+", " ", node.name or "").strip()
            if not label or _NOISE_LABEL_RE.search(label):
                continue
            self._remember_label(label)
            if _norm(label) not in observed_group:
                group_data["observed_labels"].append(label)
                observed_group.add(_norm(label))
            if _UNSAFE_LABEL_RE.search(label):
                if label not in self.result.unsafe_labels_skipped:
                    self.result.unsafe_labels_skipped.append(label)

        new_urls: list[str] = []
        for link in extract_links(snapshot, self.home):
            candidate = canonicalize_url(link.url, self.home)
            if not _safe_public_url(candidate, self.locale, authenticated=self.authenticated):
                continue
            if candidate not in self._url_seen:
                self._url_seen.add(candidate)
                self.result.urls.append(candidate)
                new_urls.append(candidate)
            if candidate not in group_data["urls"]:
                group_data["urls"].append(candidate)
        return new_urls

    def _candidate_submenu_nodes(self, snapshot: str, top_group: str, depth: int) -> list[Any]:
        if depth >= self.max_submenu_depth:
            return []
        nodes = []
        top_names = {_norm(x) for x in EXPECTED_MENU_MANIFEST}
        profile_norm = _norm(self.profile_name)
        seen: set[str] = set()
        for node in parse_nodes(snapshot):
            role = (node.role or "").lower()
            label = re.sub(r"\s+", " ", node.name or "").strip()
            key = _norm(label)
            if not label or not key or key in seen or node.disabled:
                continue
            if role not in {"button", "menuitem", "tab", "element"}:
                continue
            if key in top_names or (profile_norm and key == profile_norm):
                continue
            if _UNSAFE_LABEL_RE.search(label) or _NOISE_LABEL_RE.search(label):
                continue
            expected = {_norm(x) for x in EXPECTED_MENU_MANIFEST.get(top_group, ())}
            advertised_submenu = bool(re.search(r"expanded|collapsed|haspopup|submenu|flyout", node.line, re.I))
            known_parent = label in KNOWN_SUBMENU_PARENTS
            expected_control = key in expected
            if known_parent or advertised_submenu or expected_control:
                seen.add(key)
                nodes.append(node)
        return nodes

    def _activate(self, node: Any, label: str) -> bool:
        if self.result.actions >= self.max_actions:
            return False
        if _UNSAFE_LABEL_RE.search(label):
            if label not in self.result.unsafe_labels_skipped:
                self.result.unsafe_labels_skipped.append(label)
            return False
        # Hover is the least disruptive way to expose Dell flyouts.  If it does not
        # change the semantic menu state, a read-only click is attempted next.
        before = self._snapshot(f"Capture Dell masthead state before '{label}'")
        before_key = self._state_key(before)
        hover = self.runtime.hover(node.ref, label, intent=f"Open Dell masthead submenu '{label}' without navigation")
        self.result.actions += 1
        if hover.get("ok"):
            self.runtime.wait(0.25, intent="Wait for Dell masthead hover flyout")
            after = self._snapshot(f"Inspect Dell masthead hover state for '{label}'")
            if self._state_key(after) != before_key:
                return True
        if self.result.actions >= self.max_actions:
            return False
        click = self.runtime.click(node.ref, label, intent=f"Open read-only Dell masthead destination or submenu '{label}'")
        self.result.actions += 1
        if click.get("ok"):
            self.runtime.wait(0.35, intent="Wait for Dell masthead click to settle")
            return True
        return False

    def _explore_open_menu(self, group: str, depth: int = 0) -> None:
        if self.result.actions >= self.max_actions or depth > self.max_submenu_depth:
            return
        snapshot = self._snapshot(f"Capture open Dell masthead menu '{group}' depth {depth}")
        if not snapshot:
            return
        key = self._state_key(snapshot)
        if key in self._state_seen:
            return
        self._state_seen.add(key)
        self._collect(snapshot, group)

        # If a control opens a child flyout, inspect it, collect its links, then
        # restore the top-level menu before moving to the next sibling.  Navigation
        # destinations are simply queued; full extraction happens in the main crawl.
        for node in self._candidate_submenu_nodes(snapshot, group, depth):
            if self.result.actions >= self.max_actions:
                break
            label = re.sub(r"\s+", " ", node.name or "").strip()
            before_info = parse_page_info(snapshot)
            before_url = canonicalize_url(str(before_info.get("url") or self.home), self.home)
            if not self._activate(node, label):
                continue
            child = self._snapshot(f"Capture Dell submenu after '{label}'")
            self._collect(child, group)
            child_info = parse_page_info(child)
            child_url = canonicalize_url(str(child_info.get("url") or ""), self.home)
            if child_url and child_url != before_url:
                if _safe_public_url(child_url, self.locale, authenticated=self.authenticated) and child_url not in self._url_seen:
                    self._url_seen.add(child_url)
                    self.result.urls.append(child_url)
                # Return to home and reopen the group for remaining siblings.
                self.runtime.navigate(self.home, "Restore Dell home after masthead leaf navigation")
                self.runtime.wait(0.35, intent="Wait for Dell home after masthead leaf navigation")
                home_snap = self._snapshot("Restore Dell masthead after leaf navigation")
                opener = self._resolve_group_node(home_snap, group)
                if opener and self._activate(opener, group):
                    snapshot = self._snapshot(f"Reopen Dell masthead menu '{group}'")
                continue
            self._explore_open_menu(group, depth + 1)
            # Reopen group from a stable home state to avoid stale refs.
            self.runtime.navigate(self.home, "Restore Dell home between masthead submenu siblings")
            self.runtime.wait(0.3, intent="Wait for Dell home between masthead submenu siblings")
            home_snap = self._snapshot("Refresh Dell masthead before next submenu sibling")
            opener = self._resolve_group_node(home_snap, group)
            if opener:
                self._activate(opener, group)
                snapshot = self._snapshot(f"Reopen Dell masthead menu '{group}' after child")

    def _resolve_group_node(self, snapshot: str, group: str):
        if group == "Account / Profile":
            if self.profile_name:
                node = resolve_ref(snapshot, self.profile_name)
                if node:
                    return node
            for label in ("Account", "My Account", "Profile"):
                node = resolve_ref(snapshot, label)
                if node:
                    return node
            return None
        return resolve_ref(snapshot, group)

    def _audit_groups(self) -> None:
        for group, expected in EXPECTED_MENU_MANIFEST.items():
            data = self.result.groups.setdefault(group, {
                "expected_labels": list(expected), "observed_labels": [], "urls": [],
                "missing_expected_labels": [], "status": "PENDING",
            })
            group_observed = {_norm(v) for v in (data.get("observed_labels") or [])}
            missing = [label for label in expected if _norm(label) not in group_observed]
            data["missing_expected_labels"] = missing
            if group == "Account / Profile" and not self.authenticated:
                data["status"] = "AUTH_NOT_READY"
            elif missing:
                data["status"] = "PARTIAL"
            else:
                data["status"] = "COMPLETE"

    def discover(self) -> MastheadDiscoveryResult:
        nav = self.runtime.navigate(self.home, "Open Dell home for complete masthead taxonomy discovery")
        if not nav.get("ok"):
            self.result.status = "NAVIGATION_FAILED"
            self.result.detail = str(nav.get("detail") or "Could not open Dell home")
            return self.result
        self.runtime.wait(0.6, intent="Wait for Dell masthead to render")
        base = self._snapshot("Capture Dell masthead root")
        self._collect(base, "Root")

        groups = [g for g in EXPECTED_MENU_MANIFEST if g != "Account / Profile"]
        if self.authenticated:
            groups.append("Account / Profile")

        for group in groups:
            if self.result.actions >= self.max_actions:
                break
            # Always start from a fresh home snapshot so refs are current.
            self.runtime.navigate(self.home, f"Reset Dell home before masthead group '{group}'")
            self.runtime.wait(0.3, intent="Wait for Dell masthead reset")
            snapshot = self._snapshot(f"Locate Dell masthead group '{group}'")
            opener = self._resolve_group_node(snapshot, group)
            if not opener:
                self.result.groups.setdefault(group, {
                    "expected_labels": list(EXPECTED_MENU_MANIFEST.get(group, ())),
                    "observed_labels": [], "urls": [], "missing_expected_labels": [],
                    "status": "TOP_LEVEL_NOT_FOUND",
                })
                continue
            self._remember_label(group)
            # Root snapshots may expose a URL directly for top-level links.
            self._collect(snapshot, group)
            before_info = parse_page_info(snapshot)
            before_url = canonicalize_url(str(before_info.get("url") or self.home), self.home)
            if self._activate(opener, group):
                opened = self._snapshot(f"Capture Dell masthead group '{group}'")
                self._collect(opened, group)
                after_info = parse_page_info(opened)
                after_url = canonicalize_url(str(after_info.get("url") or ""), self.home)
                if after_url and after_url != before_url and _safe_public_url(after_url, self.locale, authenticated=self.authenticated):
                    if after_url not in self._url_seen:
                        self._url_seen.add(after_url)
                        self.result.urls.append(after_url)
                else:
                    self._explore_open_menu(group, 0)

        self._audit_groups()
        required_groups = [g for g in EXPECTED_MENU_MANIFEST if g != "Account / Profile" or self.authenticated]
        complete = sum(1 for g in required_groups if self.result.groups.get(g, {}).get("status") == "COMPLETE")
        partial = sum(1 for g in required_groups if self.result.groups.get(g, {}).get("status") == "PARTIAL")
        self.result.status = "COMPLETE" if complete == len(required_groups) else ("PARTIAL" if complete or partial else "INCOMPLETE")
        self.result.detail = f"{complete}/{len(required_groups)} masthead groups fully matched; {len(self.result.urls)} safe knowledge URLs discovered."
        self._event(
            "masthead_taxonomy_discovered",
            status=self.result.status,
            groups_complete=complete,
            groups_total=len(required_groups),
            urls=len(self.result.urls),
            unsafe_skipped=len(self.result.unsafe_labels_skipped),
            actions=self.result.actions,
        )
        return self.result
