from __future__ import annotations

"""Durable helpers for Dell PDF acquisition and validation.

This module deliberately separates *transport success* from *document success*.
A HTTP 200 response is not accepted as a PDF until the bytes and PDF structure are
validated. Dell/CDN access-denied HTML pages are therefore never promoted to the
completed document store or reused forever on resume.
"""

import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlparse, urlunparse

from pypdf import PdfReader


PDF_MAGIC = b"%PDF-"
HTML_MARKERS = (
    b"<!doctype html",
    b"<html",
    b"<head",
    b"access denied",
    b"request rejected",
    b"forbidden",
    b"akamai",
)




def normalize_pdf_download_url(url: str) -> str:
    """Return the real acquisition URL for Dell PDF queue aliases.

    Some Dell page extractors expose a UI marker as ``.pdf.external``.  That
    marker is useful for classification, but it is not part of the public PDF
    URL and must never be sent to the CDN.  Query parameters are preserved.
    """
    raw = str(url or "").strip()
    if not raw:
        return ""
    parsed = urlparse(raw)
    path = re.sub(r"(?i)(\.pdf)\.external$", r"\1", parsed.path or "")
    return urlunparse((parsed.scheme, parsed.netloc, path, parsed.params, parsed.query, parsed.fragment))


def short_pdf_storage_path(document_dir: str | Path, url: str) -> Path:
    """Create a deterministic, Windows-safe PDF path.

    The prior URL-derived filename could make a full OneDrive path exceed the
    traditional Windows MAX_PATH limit.  Windows then surfaced a misleading
    ``FileNotFoundError`` while opening ``.pdf.part``.  A two-level SHA-256
    layout keeps the path short while the original URL remains in SQLite.
    """
    canonical = normalize_pdf_download_url(url) or str(url or "")
    digest = hashlib.sha256(canonical.encode("utf-8", errors="ignore")).hexdigest()
    return Path(document_dir) / digest[:2] / f"{digest}.pdf"


class DocumentValidationError(RuntimeError):
    """Raised when downloaded bytes are not a structurally readable PDF."""


@dataclass(slots=True)
class PdfValidation:
    ok: bool
    reason: str = ""
    bytes: int = 0
    pages: int = 0
    magic_offset: int = -1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "reason": self.reason,
            "bytes": self.bytes,
            "pages": self.pages,
            "magic_offset": self.magic_offset,
            "metadata": self.metadata,
        }


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def pdf_magic_offset(payload: bytes, search_bytes: int = 1024) -> int:
    return payload[: max(5, int(search_bytes))].find(PDF_MAGIC)


def looks_like_html_or_block_page(payload: bytes) -> bool:
    sample = payload[:8192].lower().lstrip()
    return any(marker in sample for marker in HTML_MARKERS)


def validate_pdf_bytes(payload: bytes, *, require_eof: bool = False) -> PdfValidation:
    if not payload:
        return PdfValidation(False, "empty response", 0, 0, -1)
    offset = pdf_magic_offset(payload)
    if offset < 0:
        reason = "HTML/access-denied response" if looks_like_html_or_block_page(payload) else "missing %PDF- signature"
        return PdfValidation(False, reason, len(payload), 0, -1)
    if require_eof and b"%%EOF" not in payload[-8192:]:
        return PdfValidation(False, "missing PDF EOF marker", len(payload), 0, offset)
    return PdfValidation(True, bytes=len(payload), magic_offset=offset)


def validate_pdf_file(path: str | Path, *, parse_structure: bool = True) -> PdfValidation:
    path = Path(path)
    if not path.is_file():
        return PdfValidation(False, "file does not exist")
    size = int(path.stat().st_size)
    if size <= 0:
        return PdfValidation(False, "empty file", bytes=size)
    with path.open("rb") as handle:
        head = handle.read(8192)
    basic = validate_pdf_bytes(head)
    basic.bytes = size
    if not basic.ok or not parse_structure:
        return basic
    try:
        reader = PdfReader(str(path), strict=False)
        pages = len(reader.pages)
        if pages <= 0:
            return PdfValidation(False, "PDF has no pages", bytes=size, magic_offset=basic.magic_offset)
        metadata: dict[str, Any] = {}
        try:
            raw = reader.metadata or {}
            for key in ("/Title", "/Author", "/Subject", "/Creator", "/Producer"):
                value = raw.get(key)
                if value not in (None, ""):
                    metadata[key.lstrip("/").lower()] = str(value)
        except Exception:
            pass
        return PdfValidation(True, bytes=size, pages=pages, magic_offset=basic.magic_offset, metadata=metadata)
    except Exception as exc:
        return PdfValidation(False, f"pypdf could not open document: {type(exc).__name__}: {exc}", bytes=size, magic_offset=basic.magic_offset)



def validate_pdf_file_stable(
    path: str | Path,
    *,
    parse_structure: bool = True,
    attempts: int = 5,
    settle_seconds: float = 0.25,
) -> PdfValidation:
    """Validate a PDF after its writer has stopped changing the file.

    Browser downloads and MCP response-body saves can become visible before the
    final bytes are flushed.  Validating immediately can misclassify a healthy
    in-progress download as corrupt.  This helper waits for two consecutive
    stable sizes and retries structural parsing before rejecting the candidate.
    """
    candidate = Path(path)
    last_size = -1
    stable_polls = 0
    last = PdfValidation(False, "file does not exist")
    for _ in range(max(1, int(attempts))):
        if candidate.is_file():
            try:
                size = int(candidate.stat().st_size)
            except OSError:
                size = -1
            if size > 0 and size == last_size:
                stable_polls += 1
            else:
                stable_polls = 0
            last_size = size
            last = validate_pdf_file(candidate, parse_structure=parse_structure)
            if last.ok and (stable_polls >= 1 or not parse_structure):
                return last
        time.sleep(max(0.0, float(settle_seconds)))
    return last

def quarantine_file(path: str | Path, quarantine_dir: str | Path, reason: str = "invalid") -> Path | None:
    path = Path(path)
    if not path.exists():
        return None
    quarantine_dir = Path(quarantine_dir)
    quarantine_dir.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(f"{path.resolve()}|{path.stat().st_size}|{reason}".encode("utf-8", errors="ignore")).hexdigest()[:12]
    safe_reason = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(reason or "invalid"))[:60].strip("_") or "invalid"
    target = quarantine_dir / f"{path.name}.{_now_stamp()}.{safe_reason}.{digest}.quarantine"
    try:
        os.replace(path, target)
    except OSError:
        target.write_bytes(path.read_bytes())
        path.unlink(missing_ok=True)
    return target


def safe_header_dict(raw: dict[str, Any] | Iterable[tuple[str, Any]] | None) -> dict[str, str]:
    if not raw:
        return {}
    items = raw.items() if isinstance(raw, dict) else raw
    result: dict[str, str] = {}
    for key, value in items:
        name = str(key or "").strip()
        if not name or name.startswith(":"):
            continue
        low = name.lower()
        if low in {"host", "content-length", "connection", "transfer-encoding", "accept-encoding"}:
            continue
        result[name] = str(value or "")
    return result


def parse_mcp_network_request_indices(detail: str, target_url: str) -> list[int]:
    """Return likely request indices from Playwright MCP network-list text."""
    target = str(target_url or "")
    basename = Path(target.split("?", 1)[0]).name.lower()
    indices: list[int] = []
    for line in str(detail or "").splitlines():
        low = line.lower()
        if target.lower() not in low and (not basename or basename not in low):
            continue
        match = re.search(r"(?:^|\s|#|\[)(\d+)(?:\]|[.:)]|\s)", line)
        if match:
            value = int(match.group(1))
            if value not in indices:
                indices.append(value)
    return indices



def parse_mcp_network_request_entries(detail: str) -> list[dict[str, Any]]:
    """Parse numbered Playwright MCP network-list output into index/URL rows.

    The official MCP output format has changed across releases (markdown lists,
    bracketed indices and plain text).  This parser intentionally accepts all
    of those representations and keeps only HTTP(S) request URLs.
    """
    rows: list[dict[str, Any]] = []
    seen: set[tuple[int, str]] = set()
    for raw_line in str(detail or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        index_match = re.search(r"(?:^|\s|#|\[)(\d+)(?:\]|[.:)]|\s)", line)
        url_match = re.search(r"https?://[^\s>`\]\)\"]+", line)
        if not index_match or not url_match:
            continue
        index = int(index_match.group(1))
        url = url_match.group(0).rstrip(".,;'")
        key = (index, url)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"index": index, "url": url, "line": line})
    return rows


def pdf_url_identity(url: str) -> tuple[str, str, str]:
    """Return a forgiving Dell PDF identity: host, normalized path and basename.

    Query/fragment and the crawler-only ``.external`` suffix are ignored.  The
    basename is retained separately because Dell may redirect from ``/asset/``
    to ``/assetlink/documents/.../original/`` while serving the same file.
    """
    normalized = normalize_pdf_download_url(str(url or ""))
    parsed = urlparse(normalized)
    path = re.sub(r"/+", "/", parsed.path or "").rstrip("/").casefold()
    basename = Path(path).name.casefold()
    return parsed.netloc.casefold(), path, basename


def pdf_urls_consistent(requested_url: str, final_url: str, aliases: Iterable[str] = ()) -> bool:
    """Return whether a final PDF URL is consistent with the requested document.

    Exact normalized URLs, identical paths/basenames and any URL explicitly
    observed in the source-page DOM are accepted.  This prevents storing an
    unrelated PDF after a broad/duplicate locator click without rejecting normal
    Dell CDN redirects.
    """
    requested = pdf_url_identity(requested_url)
    final = pdf_url_identity(final_url)
    if requested == final:
        return True
    if requested[1] and requested[1] == final[1]:
        return True
    if requested[2] and requested[2] == final[2]:
        return True
    for alias in aliases:
        identity = pdf_url_identity(alias)
        if final == identity or (identity[2] and identity[2] == final[2]):
            return True
    return False

def append_jsonl(path: str | Path, record: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
