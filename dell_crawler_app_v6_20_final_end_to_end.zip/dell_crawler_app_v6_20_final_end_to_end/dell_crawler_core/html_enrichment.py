from __future__ import annotations

"""Deterministic enrichment of public Dell HTML.

This module complements the accessibility snapshot.  It extracts structured data,
hidden document endpoints, tables, FAQs, product/offer/review schema, image metadata,
video metadata, and application state that is already present in the public page HTML.
It does not submit forms or call mutation APIs.
"""

from dataclasses import dataclass
import html as html_lib
import json
import re
from typing import Any, Iterable
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup, Tag


DOCUMENT_EXTENSIONS = ("pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "csv", "txt", "xml", "json")
RESOURCE_ATTRS = (
    "href", "src", "data-src", "data-href", "data-url", "data-link", "data-download-url",
    "data-resource-url", "data-pdf", "data-file", "data-document", "data-target-url",
)
JSON_SCRIPT_TYPES = {
    "application/ld+json",
    "application/json",
    "application/manifest+json",
}


def _clean(value: Any, limit: int | None = None) -> str:
    text = re.sub(r"\s+", " ", html_lib.unescape(str(value or ""))).strip()
    return text if limit is None else text[:limit]


def _absolute(raw: str, base_url: str) -> str:
    value = html_lib.unescape((raw or "").strip())
    if not value or value.startswith(("javascript:", "mailto:", "tel:", "data:", "#")):
        return ""
    if value.startswith("//"):
        value = "https:" + value
    return urljoin(base_url, value)


def _json_load_loose(raw: str) -> Any | None:
    value = (raw or "").strip()
    if not value:
        return None
    try:
        return json.loads(value)
    except Exception:
        # A small number of public pages end JSON script content with a semicolon.
        try:
            return json.loads(value.rstrip(";\n\r\t "))
        except Exception:
            return None


def _flatten_schema(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        graph = value.get("@graph")
        if isinstance(graph, list):
            for item in graph:
                yield from _flatten_schema(item)
        for key, child in value.items():
            if key == "@graph":
                continue
            if isinstance(child, (dict, list)):
                yield from _flatten_schema(child)
    elif isinstance(value, list):
        for item in value:
            yield from _flatten_schema(item)


def _schema_types(node: dict[str, Any]) -> set[str]:
    raw = node.get("@type")
    if isinstance(raw, str):
        return {raw}
    if isinstance(raw, list):
        return {str(item) for item in raw}
    return set()


def _extract_schema_entities(documents: list[Any], source_url: str) -> dict[str, list[dict[str, Any]]]:
    output: dict[str, list[dict[str, Any]]] = {
        "products": [], "offers": [], "reviews": [], "faqs": [], "articles": [],
        "videos": [], "organisations": [], "breadcrumbs": [], "other": [],
    }
    seen: set[str] = set()
    for document in documents:
        for node in _flatten_schema(document):
            types = _schema_types(node)
            if not types:
                continue
            marker = json.dumps(node, sort_keys=True, ensure_ascii=False, default=str)
            if marker in seen:
                continue
            seen.add(marker)
            enriched = {**node, "_source_url": source_url}
            low_types = {item.lower() for item in types}
            if "product" in low_types:
                output["products"].append(enriched)
            elif "offer" in low_types or "aggregateoffer" in low_types:
                output["offers"].append(enriched)
            elif "review" in low_types or "aggregaterating" in low_types:
                output["reviews"].append(enriched)
            elif "faqpage" in low_types or "question" in low_types or "answer" in low_types:
                output["faqs"].append(enriched)
            elif low_types & {"article", "newsarticle", "blogposting", "techarticle"}:
                output["articles"].append(enriched)
            elif "videoobject" in low_types:
                output["videos"].append(enriched)
            elif low_types & {"organization", "corporation", "brand"}:
                output["organisations"].append(enriched)
            elif "breadcrumblist" in low_types:
                output["breadcrumbs"].append(enriched)
            else:
                output["other"].append(enriched)
    return output


def _extract_links(soup: BeautifulSoup, base_url: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for tag in soup.find_all(["a", "area"], href=True):
        url = _absolute(str(tag.get("href") or ""), base_url)
        if not url:
            continue
        label = _clean(" ".join(tag.stripped_strings) or tag.get("aria-label") or tag.get("title") or "", 1000)
        key = (url, label.casefold())
        if key in seen:
            continue
        seen.add(key)
        output.append(
            {
                "url": url,
                "label": label or url,
                "rel": " ".join(tag.get("rel") or []),
                "download": str(tag.get("download") or ""),
                "target": str(tag.get("target") or ""),
            }
        )
    return output


def _extract_resource_endpoints(soup: BeautifulSoup, raw_html: str, base_url: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    extension_re = re.compile(r"\.(?:" + "|".join(DOCUMENT_EXTENSIONS) + r")(?:$|[?#])", re.I)
    for tag in soup.find_all(True):
        for attr in RESOURCE_ATTRS:
            raw = str(tag.get(attr) or "").strip()
            if not raw:
                continue
            url = _absolute(raw, base_url)
            if not url or url in seen:
                continue
            semantic_label = _clean(
                " ".join(tag.stripped_strings) or tag.get("aria-label") or tag.get("title") or tag.get("alt") or "",
                1000,
            )
            looks_like_document = bool(extension_re.search(url))
            looks_like_resource = bool(
                re.search(
                    r"brochure|e-?book|white\s*paper|datasheet|brief|report|case\s*study|customer\s*story|"
                    r"reference\s*architecture|validated\s*design|guide|manual|documentation|infographic|resource",
                    f"{semantic_label} {url}",
                    re.I,
                )
            )
            if not (looks_like_document or looks_like_resource or tag.name in {"iframe", "embed", "object", "video", "source"}):
                continue
            seen.add(url)
            output.append(
                {
                    "url": url,
                    "label": semantic_label or url,
                    "tag": tag.name,
                    "attribute": attr,
                    "document_like": looks_like_document,
                }
            )

    # Recover absolute document URLs hidden in script strings.
    resource_re = re.compile(
        r"(?:https?:)?//[^\s\"'<>\\]+?\.(?:" + "|".join(DOCUMENT_EXTENSIONS) + r")(?:\?[^\s\"'<>\\]*)?",
        re.I,
    )
    for match in resource_re.finditer(raw_html or ""):
        url = _absolute(match.group(0), base_url).rstrip(".,;:)]}")
        if url and url not in seen:
            seen.add(url)
            output.append({"url": url, "label": "Embedded public resource", "tag": "script", "attribute": "text", "document_like": True})
    return output


def _extract_images(soup: BeautifulSoup, base_url: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    for tag in soup.find_all(["img", "source"]):
        candidates: list[str] = []
        for attr in ("data-src", "data-original", "data-lazy-src", "src"):
            raw = str(tag.get(attr) or "").strip()
            if raw:
                candidates.append(raw)
        for attr in ("data-srcset", "srcset"):
            raw = str(tag.get(attr) or "").strip()
            if raw:
                candidates.extend(part.strip().split()[0] for part in raw.split(",") if part.strip())
        for raw in candidates:
            url = _absolute(raw, base_url)
            if not url or url in seen:
                continue
            seen.add(url)
            output.append(
                {
                    "url": url,
                    "alt": _clean(tag.get("alt") or tag.get("aria-label") or tag.get("title") or "", 1000),
                    "width": _clean(tag.get("width") or tag.get("data-width") or "", 50),
                    "height": _clean(tag.get("height") or tag.get("data-height") or "", 50),
                    "loading": _clean(tag.get("loading") or "", 50),
                    "tag": tag.name,
                }
            )
    return output


def _extract_tables(soup: BeautifulSoup) -> list[dict[str, Any]]:
    tables: list[dict[str, Any]] = []
    for index, table in enumerate(soup.find_all("table")):
        caption_tag = table.find("caption")
        rows: list[list[str]] = []
        for row in table.find_all("tr"):
            cells = [_clean(cell.get_text(" ", strip=True), 5000) for cell in row.find_all(["th", "td"])]
            if any(cells):
                rows.append(cells)
        if rows:
            tables.append({"index": index, "caption": _clean(caption_tag.get_text(" ", strip=True) if caption_tag else "", 1000), "rows": rows})
    return tables


def _extract_definition_lists(soup: BeautifulSoup) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for dl in soup.find_all("dl"):
        current = ""
        for child in dl.find_all(["dt", "dd"], recursive=False):
            value = _clean(child.get_text(" ", strip=True), 10000)
            if child.name == "dt":
                current = value
            elif current and value:
                output.append({"term": current, "definition": value})
    return output


def _extract_faq_dom(soup: BeautifulSoup) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    seen: set[str] = set()
    question_re = re.compile(r"^(?:what|why|how|which|when|where|who|does|do|can|is|are|will|should)\b.*\?$", re.I)
    for tag in soup.find_all(["h2", "h3", "h4", "h5", "button", "summary"]):
        question = _clean(tag.get_text(" ", strip=True), 2000)
        if not question or not (question_re.search(question) or "faq" in " ".join(tag.get("class") or []).lower()):
            continue
        answer_parts: list[str] = []
        sibling = tag.find_next_sibling()
        steps = 0
        while isinstance(sibling, Tag) and steps < 8:
            if sibling.name in {"h1", "h2", "h3", "h4", "h5", "button", "summary"}:
                break
            text = _clean(sibling.get_text(" ", strip=True), 20000)
            if text:
                answer_parts.append(text)
            sibling = sibling.find_next_sibling()
            steps += 1
        answer = " ".join(answer_parts)
        key = question.casefold()
        if key not in seen:
            seen.add(key)
            output.append({"question": question, "answer": answer})
    return output


def _extract_videos(soup: BeautifulSoup, base_url: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    for tag in soup.find_all(["video", "iframe", "source"]):
        raw = str(tag.get("src") or tag.get("data-src") or "").strip()
        url = _absolute(raw, base_url)
        if not url or url in seen:
            continue
        low = url.lower()
        if tag.name != "video" and not any(token in low for token in ("brightcove", "youtube", "vimeo", ".mp4", ".m3u8")):
            continue
        seen.add(url)
        output.append(
            {
                "url": url,
                "title": _clean(tag.get("title") or tag.get("aria-label") or "", 1000),
                "poster": _absolute(str(tag.get("poster") or ""), base_url),
                "tag": tag.name,
            }
        )
    return output


def _extract_application_state(soup: BeautifulSoup) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for index, script in enumerate(soup.find_all("script")):
        script_type = str(script.get("type") or "").strip().lower()
        script_id = str(script.get("id") or "").strip()
        if script_type not in JSON_SCRIPT_TYPES and script_id not in {"__NEXT_DATA__", "__NUXT_DATA__", "__APOLLO_STATE__"}:
            continue
        raw = script.string or script.get_text("", strip=False)
        parsed = _json_load_loose(raw)
        if parsed is None:
            continue
        output.append({"index": index, "id": script_id, "type": script_type, "data": parsed})
    return output


def analyse_html_document(html_text: str, base_url: str) -> dict[str, Any]:
    soup = BeautifulSoup(html_text or "", "html.parser")
    title = _clean(soup.title.get_text(" ", strip=True) if soup.title else "", 2000)
    html_tag = soup.find("html")
    language = _clean(html_tag.get("lang") if html_tag else "", 100)

    canonical = ""
    canonical_tag = soup.find("link", rel=lambda value: value and "canonical" in value)
    if canonical_tag:
        canonical = _absolute(str(canonical_tag.get("href") or ""), base_url)

    meta: dict[str, str] = {}
    for tag in soup.find_all("meta"):
        key = _clean(tag.get("name") or tag.get("property") or tag.get("http-equiv") or "", 300)
        value = _clean(tag.get("content") or "", 20000)
        if key and value and key not in meta:
            meta[key] = value

    json_ld: list[Any] = []
    for script in soup.find_all("script", attrs={"type": re.compile(r"application/ld\+json", re.I)}):
        parsed = _json_load_loose(script.string or script.get_text("", strip=False))
        if parsed is not None:
            json_ld.append(parsed)

    state = _extract_application_state(soup)
    schema_entities = _extract_schema_entities(json_ld, base_url)
    links = _extract_links(soup, base_url)
    resources = _extract_resource_endpoints(soup, html_text, base_url)
    images = _extract_images(soup, base_url)
    tables = _extract_tables(soup)
    definitions = _extract_definition_lists(soup)
    faq_dom = _extract_faq_dom(soup)
    videos = _extract_videos(soup, base_url)
    headings = [
        {"level": tag.name, "text": _clean(tag.get_text(" ", strip=True), 5000)}
        for tag in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"])
        if _clean(tag.get_text(" ", strip=True))
    ]

    return {
        "source_url": base_url,
        "title": title,
        "language": language,
        "canonical": canonical,
        "meta": meta,
        "json_ld": json_ld,
        "schema_entities": schema_entities,
        "application_state": state,
        "links": links,
        "resources": resources,
        "images": images,
        "tables": tables,
        "definition_lists": definitions,
        "faq_dom": faq_dom,
        "videos": videos,
        "headings": headings,
        "counts": {
            "links": len(links),
            "resources": len(resources),
            "images": len(images),
            "tables": len(tables),
            "definition_pairs": len(definitions),
            "faqs": len(faq_dom) + len(schema_entities.get("faqs", [])),
            "products": len(schema_entities.get("products", [])),
            "offers": len(schema_entities.get("offers", [])),
            "reviews": len(schema_entities.get("reviews", [])),
            "videos": len(videos) + len(schema_entities.get("videos", [])),
            "application_json_scripts": len(state),
        },
    }


def _compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))


def structured_evidence_to_text(evidence: dict[str, Any]) -> str:
    """Convert deterministic HTML evidence into LLM-readable, provenance-tagged text.

    No fixed item limit is used.  The resulting text is later split into semantic chunks
    by the existing long-form extractor.
    """
    if not evidence:
        return ""
    sections: list[str] = []
    meta = evidence.get("meta") if isinstance(evidence.get("meta"), dict) else {}
    if meta:
        sections.append("===== HTML META =====\n" + "\n".join(f"{key}: {value}" for key, value in meta.items()))

    schema = evidence.get("schema_entities") if isinstance(evidence.get("schema_entities"), dict) else {}
    for key in ("products", "offers", "reviews", "faqs", "articles", "videos", "breadcrumbs", "other"):
        items = schema.get(key) if isinstance(schema.get(key), list) else []
        if items:
            sections.append(f"===== JSON-LD {key.upper()} =====\n" + "\n".join(_compact_json(item) for item in items))

    tables = evidence.get("tables") if isinstance(evidence.get("tables"), list) else []
    if tables:
        table_parts: list[str] = []
        for table in tables:
            table_parts.append(f"TABLE {table.get('index')} {table.get('caption','')}")
            table_parts.extend(" | ".join(map(str, row)) for row in table.get("rows", []))
        sections.append("===== HTML TABLES =====\n" + "\n".join(table_parts))

    definitions = evidence.get("definition_lists") if isinstance(evidence.get("definition_lists"), list) else []
    if definitions:
        sections.append("===== HTML DEFINITION LISTS =====\n" + "\n".join(
            f"{item.get('term')}: {item.get('definition')}" for item in definitions
        ))

    faqs = evidence.get("faq_dom") if isinstance(evidence.get("faq_dom"), list) else []
    if faqs:
        sections.append("===== HTML FAQ EVIDENCE =====\n" + "\n".join(
            f"Q: {item.get('question')}\nA: {item.get('answer')}" for item in faqs
        ))

    resources = evidence.get("resources") if isinstance(evidence.get("resources"), list) else []
    if resources:
        sections.append("===== EMBEDDED RESOURCES =====\n" + "\n".join(
            f"{item.get('label')} -> {item.get('url')}" for item in resources
        ))

    videos = evidence.get("videos") if isinstance(evidence.get("videos"), list) else []
    if videos:
        sections.append("===== VIDEO ENDPOINTS =====\n" + "\n".join(
            f"{item.get('title') or 'Video'} -> {item.get('url')}" for item in videos
        ))

    application_state = evidence.get("application_state") if isinstance(evidence.get("application_state"), list) else []
    if application_state:
        sections.append("===== PUBLIC APPLICATION JSON STATE =====\n" + "\n".join(
            _compact_json(item) for item in application_state
        ))

    return "\n\n".join(section for section in sections if section.strip())
