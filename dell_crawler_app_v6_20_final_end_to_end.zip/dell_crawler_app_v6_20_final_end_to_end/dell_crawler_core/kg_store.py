from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator

from .crawl_models import CrawlPage
from .frontier_scheduler import ASSET, PAGE, SITEMAP, asset_family_key, asset_resolution_score, classify_frontier_url, lane_priority
from .snapshot_extract import classify_page, canonicalize_url
from .market_context import infer_market_context, normalize_currency, price_predicate
from .utils import ensure_dir
from .product_intelligence import (
    adaptive_product_completeness,
    normalized_product_attribute,
    is_media_asset_url,
    is_product_detail_url,
    valid_product_name,
)
from .knowledge_ontology import canonical_node_type, canonical_relationship_type, canonical_fact_key
from .knowledge_validation import validate_extraction_payload
from .semantic_identity import GRAPH_NODE_TYPES, EVIDENCE_ONLY_TYPES, semantic_entity_key, classification_attributes, classify_entity


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _json(value: Any) -> str:
    return json.dumps(value if value is not None else {}, ensure_ascii=False, sort_keys=True, default=str)


def _loads(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except Exception:
        return default


def _merge_dicts(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    merged = dict(old or {})
    for key, value in (new or {}).items():
        if value is None or value == "" or value == [] or value == {}:
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge_dicts(merged[key], value)
        elif isinstance(value, list) and isinstance(merged.get(key), list):
            existing = list(merged[key])
            for item in value:
                if item not in existing:
                    existing.append(item)
            merged[key] = existing
        else:
            merged[key] = value
    return merged


def _slug(value: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-")
    return clean[:180] or hashlib.sha256((value or "").encode()).hexdigest()[:24]


_GENERIC_NODE_TYPES = {"", "Entity", "Endpoint", "Resource", "WebPage", "Unknown"}
_SEMANTIC_TYPE_RANK = {
    "Product": 100, "ProductFamily": 95, "ProductCatalog": 92, "OfferCatalog": 92,
    "Document": 90, "SupportArticle": 88, "ManualOrSupport": 88,
    "Solution": 85, "AISolutionPage": 85, "SolutionPage": 85,
    "Offer": 80, "Service": 80, "UseCase": 80, "Requirement": 80,
    "ProductReview": 80, "FAQ": 75, "VisualAsset": 70,
    "Endpoint": 10, "Resource": 8, "WebPage": 5, "Entity": 1, "Unknown": 0, "": 0,
}
_WEAK_NODE_NAME_RE = re.compile(
    r"^(?:https?://|skip to main content$|view offer$|explore options$|configure and buy$|"
    r"view product page$|learn more$|open$|resource$)", re.I
)


def _preferred_node_type(existing: str, incoming: str) -> str:
    old = str(existing or "Entity")
    new = str(incoming or "Entity")
    if old == new:
        return old
    old_rank = _SEMANTIC_TYPE_RANK.get(old, 50 if old not in _GENERIC_NODE_TYPES else 0)
    new_rank = _SEMANTIC_TYPE_RANK.get(new, 50 if new not in _GENERIC_NODE_TYPES else 0)
    return new if new_rank >= old_rank else old


def _preferred_node_name(existing: str, incoming: str, node_key: str) -> str:
    old = re.sub(r"\s+", " ", str(existing or "")).strip()
    new = re.sub(r"\s+", " ", str(incoming or "")).strip()
    old_weak = not old or old == node_key or bool(_WEAK_NODE_NAME_RE.search(old))
    new_weak = not new or new == node_key or bool(_WEAK_NODE_NAME_RE.search(new))
    if old_weak and not new_weak:
        return new
    if new_weak and not old_weak:
        return old
    # Prefer a descriptive title over a very short action label.
    if len(new) >= len(old) and not new_weak:
        return new
    return old or new or node_key




def _infer_locale_market(url: str) -> tuple[str, str, str]:
    context = infer_market_context(url)
    return context.locale, context.market, context.market_name

def _first_nonempty(mapping: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = mapping.get(key)
        if value not in (None, "", [], {}):
            return re.sub(r"\s+", " ", str(value)).strip()
    return ""


def _sanitize_product_entity(
    name: str,
    attrs: dict[str, Any],
    entity_url: str,
    explicit_key: str,
    source_url: str,
) -> tuple[str, str, str, dict[str, Any]]:
    """Normalize an extracted Product before it reaches the graph.

    The LLM/DOM may occasionally expose a card's image URL in the generic ``url``
    field.  That resource is useful evidence, but it must never become the Product
    identity.  Strong product identifiers are promoted to a stable node key; a
    media-only pseudo product is downgraded to VisualAsset instead of contaminating
    the Product population.
    """
    clean_attrs = dict(attrs or {})
    raw_url = str(
        entity_url
        or clean_attrs.get("product_url")
        or clean_attrs.get("productUrl")
        or clean_attrs.get("url")
        or ""
    ).strip()
    media_url = raw_url if is_media_asset_url(raw_url, source_url) else ""
    product_url = raw_url if is_product_detail_url(raw_url, source_url) else ""
    if not product_url and is_product_detail_url(source_url):
        product_url = source_url

    if media_url:
        clean_attrs.setdefault("image", media_url)
        clean_attrs["recovered_media_url"] = media_url
    if raw_url and not media_url and not product_url:
        clean_attrs.setdefault("unverified_product_url", raw_url)

    # Remove ambiguous URL aliases, then write back only an actual Dell detail URL.
    for key in ("url", "product_url", "productUrl"):
        if key in clean_attrs:
            clean_attrs.pop(key, None)
    if product_url:
        clean_attrs["url"] = product_url
        clean_attrs["product_url"] = product_url

    order_code = _first_nonempty(clean_attrs, "order_code", "orderCode", "sku")
    part_number = _first_nonempty(clean_attrs, "part_number", "partNumber", "mpn")
    model = _first_nonempty(clean_attrs, "model")
    commercial_signal = any(_first_nonempty(clean_attrs, key) for key in (
        "price", "current_price", "list_price", "processor", "cpu", "graphics", "gpu",
        "memory", "storage", "display", "operating_system", "os", "rating", "review_count",
    ))
    identity_signal = bool(order_code or part_number or model or product_url)

    # Media-only records are visual assets, not Products. Keep the evidence instead
    # of deleting it so provenance remains auditable.
    if media_url and not identity_signal and not commercial_signal:
        clean_attrs["quarantined_from_product"] = True
        clean_attrs["quarantine_reason"] = "media_url_without_product_identity"
        clean_attrs["url"] = media_url
        return f"url:{media_url}", "VisualAsset", name or media_url, clean_attrs

    # If the model labelled generic chrome as Product and no product evidence is
    # present, do not allow the semantic type promotion.
    if not identity_signal and not commercial_signal and not valid_product_name(name, structured=True):
        clean_attrs["quarantined_from_product"] = True
        clean_attrs["quarantine_reason"] = "insufficient_product_evidence"
        fallback_key = explicit_key if explicit_key and not explicit_key.startswith("url:http") else f"entity:{_slug(name)}"
        return fallback_key, "Entity", name, clean_attrs

    clean_attrs["product_name"] = clean_attrs.get("product_name") or name
    if order_code:
        node_key = f"product-order:{_slug(order_code)}"
    elif part_number:
        node_key = f"product-part:{_slug(part_number)}"
    elif product_url:
        node_key = f"product-url:{product_url}"
    elif model and _first_nonempty(clean_attrs, "brand"):
        brand = _first_nonempty(clean_attrs, "brand")
        node_key = f"product-model:{_slug(brand + '-' + model)}"
    else:
        # Do not invent a Dell brand for identity-poor marketplace/accessory items.
        # Without a strong ID or explicit brand, the product name is safer than a
        # potentially ambiguous model-only identity.
        node_key = f"product:{_slug(name)}"
    if explicit_key and explicit_key != node_key:
        clean_attrs.setdefault("original_extracted_node_key", explicit_key)
    return node_key, "Product", name, clean_attrs


class SQLiteKnowledgeGraph:
    """A provenance-first property graph backed by SQLite.

    It intentionally avoids heavyweight graph/vector dependencies so the package
    remains easy to install in locked-down Dell Windows environments. Nodes,
    edges, facts, source pages, document chunks, crawl queue and run checkpoints
    are stored in one portable database. SQLite FTS5 is used when available and
    automatically falls back to LIKE search otherwise.
    """

    def __init__(self, db_path: str | Path = "knowledge/dell_en_uk.db") -> None:
        self.db_path = Path(db_path)
        ensure_dir(self.db_path.parent)
        self._lock = threading.RLock()
        self._fts_available = False
        self._init_schema()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=60, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS sources (
                    url TEXT PRIMARY KEY,
                    canonical_url TEXT NOT NULL,
                    title TEXT NOT NULL DEFAULT '',
                    page_type TEXT NOT NULL DEFAULT 'WebPage',
                    content_hash TEXT NOT NULL DEFAULT '',
                    fetched_at TEXT NOT NULL,
                    http_status INTEGER,
                    screenshot_path TEXT NOT NULL DEFAULT '',
                    raw_path TEXT NOT NULL DEFAULT '',
                    mime_type TEXT NOT NULL DEFAULT 'text/html',
                    metadata_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS nodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    node_key TEXT NOT NULL UNIQUE,
                    node_type TEXT NOT NULL,
                    name TEXT NOT NULL,
                    attributes_json TEXT NOT NULL DEFAULT '{}',
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type);
                CREATE INDEX IF NOT EXISTS idx_nodes_name ON nodes(name);

                CREATE TABLE IF NOT EXISTS edges (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
                    predicate TEXT NOT NULL,
                    target_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
                    attributes_json TEXT NOT NULL DEFAULT '{}',
                    source_url TEXT NOT NULL DEFAULT '',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    UNIQUE(source_id, predicate, target_id, source_url)
                );
                CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id, predicate);
                CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id, predicate);

                CREATE TABLE IF NOT EXISTS facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subject_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
                    predicate TEXT NOT NULL,
                    value TEXT NOT NULL,
                    unit TEXT NOT NULL DEFAULT '',
                    qualifiers_json TEXT NOT NULL DEFAULT '{}',
                    source_url TEXT NOT NULL DEFAULT '',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    observed_at TEXT NOT NULL,
                    valid_from TEXT NOT NULL DEFAULT '',
                    valid_to TEXT NOT NULL DEFAULT '',
                    UNIQUE(subject_id, predicate, value, unit, source_url)
                );
                CREATE INDEX IF NOT EXISTS idx_facts_subject ON facts(subject_id, predicate);
                CREATE INDEX IF NOT EXISTS idx_facts_predicate ON facts(predicate);

                CREATE TABLE IF NOT EXISTS chunks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL REFERENCES sources(url) ON DELETE CASCADE,
                    chunk_index INTEGER NOT NULL,
                    heading TEXT NOT NULL DEFAULT '',
                    text TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    UNIQUE(source_url, chunk_index, content_hash)
                );
                CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source_url);

                CREATE TABLE IF NOT EXISTS crawl_queue (
                    url TEXT PRIMARY KEY,
                    depth INTEGER NOT NULL DEFAULT 0,
                    priority INTEGER NOT NULL DEFAULT 50,
                    parent_url TEXT NOT NULL DEFAULT '',
                    relation TEXT NOT NULL DEFAULT 'LINKS_TO',
                    resource_class TEXT NOT NULL DEFAULT 'PAGE',
                    lane_priority INTEGER NOT NULL DEFAULT 10,
                    resource_key TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT NOT NULL DEFAULT '',
                    lease_owner TEXT NOT NULL DEFAULT '',
                    lease_expires_at TEXT NOT NULL DEFAULT '',
                    last_progress_at TEXT NOT NULL DEFAULT '',
                    not_before TEXT NOT NULL DEFAULT '',
                    discovered_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_queue_status_priority ON crawl_queue(status, priority, depth, discovered_at);

                CREATE TABLE IF NOT EXISTS crawl_runs (
                    run_id TEXT PRIMARY KEY,
                    scope_name TEXT NOT NULL,
                    config_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    finished_at TEXT NOT NULL DEFAULT '',
                    stats_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS interactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL,
                    label TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT '',
                    action_kind TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    before_hash TEXT NOT NULL DEFAULT '',
                    after_hash TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL,
                    UNIQUE(source_url, label, action_kind, before_hash, after_hash)
                );

                CREATE TABLE IF NOT EXISTS self_heal_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL DEFAULT '',
                    source_url TEXT NOT NULL DEFAULT '',
                    stage TEXT NOT NULL DEFAULT '',
                    failure_class TEXT NOT NULL DEFAULT '',
                    action TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    attempt INTEGER NOT NULL DEFAULT 0,
                    before_hash TEXT NOT NULL DEFAULT '',
                    after_hash TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT '',
                    decision_json TEXT NOT NULL DEFAULT '{}',
                    result_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_self_heal_run_url ON self_heal_events(run_id, source_url, observed_at);

                CREATE TABLE IF NOT EXISTS dynamic_control_progress (
                    source_url TEXT NOT NULL,
                    control_key TEXT NOT NULL,
                    label TEXT NOT NULL DEFAULT '',
                    role TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    clicks INTEGER NOT NULL DEFAULT 0,
                    progress_events INTEGER NOT NULL DEFAULT 0,
                    no_progress_rounds INTEGER NOT NULL DEFAULT 0,
                    state_count INTEGER NOT NULL DEFAULT 0,
                    last_signature TEXT NOT NULL DEFAULT '',
                    last_detail TEXT NOT NULL DEFAULT '',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL,
                    PRIMARY KEY(source_url, control_key)
                );
                CREATE INDEX IF NOT EXISTS idx_dynamic_control_status ON dynamic_control_progress(status, observed_at);

                CREATE TABLE IF NOT EXISTS control_progress (
                    source_url TEXT NOT NULL,
                    control_key TEXT NOT NULL,
                    label TEXT NOT NULL DEFAULT '',
                    context TEXT NOT NULL DEFAULT '',
                    action_kind TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    information_gain REAL NOT NULL DEFAULT 0,
                    detail TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL,
                    PRIMARY KEY(source_url, control_key)
                );
                CREATE INDEX IF NOT EXISTS idx_control_progress_source ON control_progress(source_url, observed_at);

                CREATE TABLE IF NOT EXISTS web_state_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL,
                    page_type TEXT NOT NULL DEFAULT 'WebPage',
                    state_signature TEXT NOT NULL,
                    visible_text_hash TEXT NOT NULL DEFAULT '',
                    control_count INTEGER NOT NULL DEFAULT 0,
                    link_count INTEGER NOT NULL DEFAULT 0,
                    missing_topics_json TEXT NOT NULL DEFAULT '[]',
                    covered_topics_json TEXT NOT NULL DEFAULT '[]',
                    state_embedding_json TEXT NOT NULL DEFAULT '[]',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL,
                    UNIQUE(source_url, state_signature)
                );
                CREATE INDEX IF NOT EXISTS idx_web_state_url ON web_state_observations(source_url, observed_at);

                CREATE TABLE IF NOT EXISTS action_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL,
                    page_type TEXT NOT NULL DEFAULT 'WebPage',
                    state_signature TEXT NOT NULL DEFAULT '',
                    selected_key TEXT NOT NULL DEFAULT '',
                    selection_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_action_decision_url ON action_decisions(source_url, observed_at);

                CREATE TABLE IF NOT EXISTS action_trajectories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL DEFAULT '',
                    source_url TEXT NOT NULL,
                    page_type TEXT NOT NULL DEFAULT 'WebPage',
                    state_signature TEXT NOT NULL DEFAULT '',
                    control_key TEXT NOT NULL,
                    stable_key TEXT NOT NULL DEFAULT '',
                    label TEXT NOT NULL DEFAULT '',
                    role TEXT NOT NULL DEFAULT '',
                    occurrence INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT '',
                    reward REAL NOT NULL DEFAULT 0,
                    success INTEGER NOT NULL DEFAULT 0,
                    action_json TEXT NOT NULL DEFAULT '{}',
                    outcome_json TEXT NOT NULL DEFAULT '{}',
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_action_trajectory_policy ON action_trajectories(page_type, control_key, observed_at);

                CREATE TABLE IF NOT EXISTS action_policy_memory (
                    page_type TEXT NOT NULL,
                    control_key TEXT NOT NULL,
                    visits INTEGER NOT NULL DEFAULT 0,
                    successes INTEGER NOT NULL DEFAULT 0,
                    failures INTEGER NOT NULL DEFAULT 0,
                    total_reward REAL NOT NULL DEFAULT 0,
                    average_reward REAL NOT NULL DEFAULT 0,
                    last_reward REAL NOT NULL DEFAULT 0,
                    last_status TEXT NOT NULL DEFAULT '',
                    last_source_url TEXT NOT NULL DEFAULT '',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(page_type, control_key)
                );
                CREATE INDEX IF NOT EXISTS idx_action_policy_page_type ON action_policy_memory(page_type, average_reward DESC);

                CREATE TABLE IF NOT EXISTS product_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
                    source_url TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL,
                    observation_hash TEXT NOT NULL,
                    price TEXT NOT NULL DEFAULT '',
                    list_price TEXT NOT NULL DEFAULT '',
                    currency TEXT NOT NULL DEFAULT '',
                    model TEXT NOT NULL DEFAULT '',
                    order_code TEXT NOT NULL DEFAULT '',
                    completeness_score REAL NOT NULL DEFAULT 0,
                    fields_json TEXT NOT NULL DEFAULT '{}',
                    UNIQUE(product_id, source_url, observation_hash)
                );
                CREATE INDEX IF NOT EXISTS idx_product_observation_product ON product_observations(product_id, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_product_observation_price ON product_observations(price, observed_at DESC);

                CREATE TABLE IF NOT EXISTS product_aliases (
                    alias_product_id INTEGER PRIMARY KEY REFERENCES nodes(id) ON DELETE CASCADE,
                    canonical_product_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
                    reason TEXT NOT NULL DEFAULT '',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_product_alias_canonical ON product_aliases(canonical_product_id);

                CREATE TABLE IF NOT EXISTS semantic_entity_aliases (
                    alias_key TEXT PRIMARY KEY,
                    canonical_node_key TEXT NOT NULL,
                    node_type TEXT NOT NULL DEFAULT '',
                    reason TEXT NOT NULL DEFAULT '',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_semantic_alias_canonical
                    ON semantic_entity_aliases(canonical_node_key, node_type);

                CREATE TABLE IF NOT EXISTS product_enrichment_state (
                    product_key TEXT PRIMARY KEY,
                    product_id INTEGER NOT NULL DEFAULT 0,
                    product_url TEXT NOT NULL DEFAULT '',
                    source_url TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    no_gain_rounds INTEGER NOT NULL DEFAULT 0,
                    last_score REAL NOT NULL DEFAULT 0,
                    best_score REAL NOT NULL DEFAULT 0,
                    missing_fields_json TEXT NOT NULL DEFAULT '[]',
                    unresolved_unmapped INTEGER NOT NULL DEFAULT 0,
                    last_reason TEXT NOT NULL DEFAULT '',
                    last_queued_at TEXT NOT NULL DEFAULT '',
                    last_attempt_at TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_product_enrichment_status
                    ON product_enrichment_state(status, attempts, updated_at);
                """
            )
            # v6.16 compact semantic graph support. Discovery/evidence remains exhaustive,
            # but links and weak model observations are stored outside the semantic
            # node graph until their target is actually fetched and validated.
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS link_evidence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL,
                    target_url TEXT NOT NULL,
                    label TEXT NOT NULL DEFAULT '',
                    relation TEXT NOT NULL DEFAULT 'LINKS_TO',
                    ref TEXT NOT NULL DEFAULT '',
                    priority INTEGER NOT NULL DEFAULT 50,
                    resource_kind TEXT NOT NULL DEFAULT '',
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    UNIQUE(source_url,target_url,relation,label)
                );
                CREATE INDEX IF NOT EXISTS idx_link_evidence_target ON link_evidence(target_url,source_url);
                CREATE INDEX IF NOT EXISTS idx_link_evidence_source ON link_evidence(source_url,target_url);

                CREATE TABLE IF NOT EXISTS extraction_evidence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL,
                    evidence_kind TEXT NOT NULL DEFAULT 'unmapped',
                    evidence_hash TEXT NOT NULL,
                    payload_json TEXT NOT NULL DEFAULT '{}',
                    reason TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL,
                    UNIQUE(source_url,evidence_kind,evidence_hash)
                );
                CREATE INDEX IF NOT EXISTS idx_extraction_evidence_source ON extraction_evidence(source_url,evidence_kind);

                CREATE TABLE IF NOT EXISTS extraction_validation (
                    source_url TEXT PRIMARY KEY,
                    report_json TEXT NOT NULL DEFAULT '{}',
                    validated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS product_identity_aliases (
                    alias_key TEXT PRIMARY KEY,
                    canonical_product_key TEXT NOT NULL,
                    reason TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_product_identity_aliases_canonical
                    ON product_identity_aliases(canonical_product_key);
                """
            )

            try:
                # Use ordinary (content-bearing) FTS5 tables. A previous build
                # used contentless FTS tables (content=''), which can rank rows
                # but returns NULL for every selected column. Detect and migrate
                # that schema so existing databases remain usable.
                fts_definitions = {
                    "chunks_fts": "CREATE VIRTUAL TABLE chunks_fts USING fts5(text, heading, source_url UNINDEXED)",
                    "nodes_fts": "CREATE VIRTUAL TABLE nodes_fts USING fts5(name, node_type, attributes, node_key UNINDEXED)",
                }
                rebuilt = False
                for table_name, create_sql in fts_definitions.items():
                    row = conn.execute(
                        "SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                        (table_name,),
                    ).fetchone()
                    existing_sql = str(row["sql"] or "") if row else ""
                    if row and "content=''" in existing_sql.replace(" ", "").lower():
                        conn.execute(f"DROP TABLE {table_name}")
                        row = None
                        rebuilt = True
                    if not row:
                        conn.execute(create_sql)

                # Rebuild indexes after schema migration or if FTS tables are
                # empty while their authoritative tables contain data.
                chunk_count = int(conn.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0])
                source_chunk_count = int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])
                if rebuilt or (source_chunk_count and not chunk_count):
                    conn.execute("DELETE FROM chunks_fts")
                    conn.execute(
                        "INSERT INTO chunks_fts(text,heading,source_url) SELECT text,heading,source_url FROM chunks"
                    )

                node_count = int(conn.execute("SELECT COUNT(*) FROM nodes_fts").fetchone()[0])
                source_node_count = int(conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0])
                if rebuilt or (source_node_count and not node_count):
                    conn.execute("DELETE FROM nodes_fts")
                    conn.execute(
                        "INSERT INTO nodes_fts(name,node_type,attributes,node_key) "
                        "SELECT name,node_type,attributes_json,node_key FROM nodes"
                    )
                self._fts_available = True
            except sqlite3.OperationalError:
                self._fts_available = False

            # Forward-compatible queue lease migration for databases created by
            # earlier crawler releases. SQLite has no IF NOT EXISTS for columns.
            queue_columns = {row["name"] for row in conn.execute("PRAGMA table_info(crawl_queue)").fetchall()}
            for column, ddl in {
                "lease_owner": "TEXT NOT NULL DEFAULT ''",
                "lease_expires_at": "TEXT NOT NULL DEFAULT ''",
                "last_progress_at": "TEXT NOT NULL DEFAULT ''",
                "not_before": "TEXT NOT NULL DEFAULT ''",
                "resource_class": "TEXT NOT NULL DEFAULT 'PAGE'",
                "lane_priority": "INTEGER NOT NULL DEFAULT 10",
                "resource_key": "TEXT NOT NULL DEFAULT ''",
            }.items():
                if column not in queue_columns:
                    conn.execute(f"ALTER TABLE crawl_queue ADD COLUMN {column} {ddl}")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_queue_status_lane ON crawl_queue(status, lane_priority, priority, depth, discovered_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_queue_resource_key ON crawl_queue(resource_class, resource_key, status)")
            # JSON1 is available in supported Python SQLite builds. The view is a
            # stable, UI-friendly product projection while nodes/facts remain the
            # authoritative provenance graph.
            try:
                conn.execute("DROP VIEW IF EXISTS product_catalog_view")
                conn.execute(
                    """
                    CREATE VIEW product_catalog_view AS
                    SELECT
                        n.id AS product_id,
                        n.node_key,
                        n.name AS product_name,
                        json_extract(n.attributes_json, '$.family') AS family,
                        COALESCE(json_extract(n.attributes_json, '$.price'), json_extract(n.attributes_json, '$.current_price')) AS price,
                        json_extract(n.attributes_json, '$.list_price') AS list_price,
                        COALESCE(json_extract(n.attributes_json, '$.currency'), '') AS currency,
                        json_extract(n.attributes_json, '$.part_number') AS part_number,
                        json_extract(n.attributes_json, '$.order_code') AS order_code,
                        json_extract(n.attributes_json, '$.brand') AS brand,
                        json_extract(n.attributes_json, '$.model') AS model,
                        json_extract(n.attributes_json, '$.condition') AS condition,
                        json_extract(n.attributes_json, '$.seller') AS seller,
                        json_extract(n.attributes_json, '$.warranty') AS warranty,
                        json_extract(n.attributes_json, '$.support') AS support,
                        json_extract(n.attributes_json, '$.shipping') AS shipping,
                        json_extract(n.attributes_json, '$.promotion') AS promotion,
                        json_extract(n.attributes_json, '$.rating') AS rating,
                        json_extract(n.attributes_json, '$.review_count') AS review_count,
                        json_extract(n.attributes_json, '$.processor') AS processor,
                        json_extract(n.attributes_json, '$.graphics') AS graphics,
                        json_extract(n.attributes_json, '$.memory') AS memory,
                        json_extract(n.attributes_json, '$.storage') AS storage,
                        json_extract(n.attributes_json, '$.display') AS display,
                        json_extract(n.attributes_json, '$.operating_system') AS operating_system,
                        json_extract(n.attributes_json, '$.networking') AS networking,
                        json_extract(n.attributes_json, '$.weight') AS weight,
                        json_extract(n.attributes_json, '$.battery_life') AS battery_life,
                        json_extract(n.attributes_json, '$.completeness_score') AS completeness_score,
                        json_extract(n.attributes_json, '$.source_url') AS source_url,
                        COALESCE(json_extract(n.attributes_json, '$.product_url'), json_extract(n.attributes_json, '$.url')) AS product_url,
                        n.last_seen
                    FROM nodes n
                    LEFT JOIN product_aliases pa ON pa.alias_product_id=n.id
                    WHERE n.node_type='Product' AND pa.alias_product_id IS NULL
                      AND (
                        COALESCE(json_extract(n.attributes_json, '$.product_url'), json_extract(n.attributes_json, '$.url'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.order_code'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.part_number'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.model'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.price'), json_extract(n.attributes_json, '$.current_price'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.processor'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.graphics'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.memory'), '') <> ''
                        OR COALESCE(json_extract(n.attributes_json, '$.storage'), '') <> ''
                      )
                    """
                )
            except sqlite3.OperationalError:
                pass

    @property
    def fts_available(self) -> bool:
        return self._fts_available

    def start_run(self, run_id: str, scope_name: str, config: dict[str, Any]) -> None:
        now = _utc_now()
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO crawl_runs(run_id, scope_name, config_json, status, started_at)
                VALUES(?,?,?,?,?)
                ON CONFLICT(run_id) DO UPDATE SET
                    scope_name=excluded.scope_name, config_json=excluded.config_json,
                    status='RUNNING', started_at=excluded.started_at, finished_at=''
                """,
                (run_id, scope_name, _json(config), "RUNNING", now),
            )

    def finish_run(self, run_id: str, status: str, stats: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE crawl_runs SET status=?, finished_at=?, stats_json=? WHERE run_id=?",
                (status, _utc_now(), _json(stats), run_id),
            )

    def enqueue(
        self,
        url: str,
        depth: int = 0,
        priority: int = 50,
        parent_url: str = "",
        relation: str = "LINKS_TO",
        force: bool = False,
        resource_class: str = "",
        resource_key: str = "",
    ) -> bool:
        """Add one durable frontier item with canonical URL and asset dedupe.

        v6.13 canonicalises again at the durable queue boundary. Link extractors,
        API discovery and product revisits can arrive through different code paths;
        enforcing one identity here prevents tracking/query aliases from being
        processed as separate pages across days or application restarts.
        """
        canonical = canonicalize_url(str(url or ""))
        if canonical.startswith(("http://", "https://")):
            url = canonical
        if parent_url:
            canonical_parent = canonicalize_url(str(parent_url or ""))
            if canonical_parent.startswith(("http://", "https://")):
                parent_url = canonical_parent
        now = _utc_now()
        resource_class = (resource_class or classify_frontier_url(url, relation)).upper()
        lane = lane_priority(resource_class)
        if resource_class == ASSET and not resource_key:
            resource_key = asset_family_key(url)
        with self.connect() as conn:
            # i.dell.com commonly exposes 2-5 resized variants of the same source
            # image. Keep the best discovered variant and skip the rest so vision
            # analyses the visual once without losing semantic coverage.
            if resource_class == ASSET and resource_key and not force:
                variant = conn.execute(
                    "SELECT url,status FROM crawl_queue WHERE resource_class=? AND resource_key=? AND status NOT IN ('SKIPPED_DUPLICATE_ASSET','SKIPPED_PERMANENT') ORDER BY discovered_at ASC LIMIT 1",
                    (ASSET, resource_key),
                ).fetchone()
                if variant and variant["url"] != url:
                    old_url = str(variant["url"])
                    old_score = asset_resolution_score(old_url)
                    new_score = asset_resolution_score(url)
                    if new_score > old_score and variant["status"] not in {"DONE", "IN_PROGRESS"}:
                        conn.execute(
                            "UPDATE crawl_queue SET status='SKIPPED_DUPLICATE_ASSET', last_error='Superseded by higher-resolution visual variant', updated_at=? WHERE url=?",
                            (now, old_url),
                        )
                    else:
                        return False

            existing = conn.execute("SELECT status, priority, depth FROM crawl_queue WHERE url=?", (url,)).fetchone()
            if existing and not force:
                if existing["status"] in {"DONE", "IN_PROGRESS"}:
                    return False
                conn.execute(
                    "UPDATE crawl_queue SET priority=MIN(priority,?), depth=MIN(depth,?), parent_url=COALESCE(NULLIF(parent_url,''),?), relation=COALESCE(NULLIF(relation,''),?), resource_class=?, lane_priority=?, resource_key=CASE WHEN resource_key='' THEN ? ELSE resource_key END, updated_at=? WHERE url=?",
                    (priority, depth, parent_url, relation, resource_class, lane, resource_key, now, url),
                )
                return False
            conn.execute(
                """
                INSERT INTO crawl_queue(
                    url, depth, priority, parent_url, relation, resource_class, lane_priority, resource_key, status, attempts,
                    lease_owner, lease_expires_at, last_progress_at, not_before,
                    discovered_at, updated_at
                )
                VALUES(?,?,?,?,?,?,?,?,'PENDING',0,'','','','',?,?)
                ON CONFLICT(url) DO UPDATE SET
                    depth=excluded.depth, priority=excluded.priority, parent_url=excluded.parent_url,
                    relation=excluded.relation, resource_class=excluded.resource_class, lane_priority=excluded.lane_priority,
                    resource_key=excluded.resource_key, status='PENDING', last_error='',
                    lease_owner='', lease_expires_at='', not_before='', updated_at=excluded.updated_at
                """,
                (url, depth, priority, parent_url, relation, resource_class, lane, resource_key, now, now),
            )
            return True


    def reset_in_progress(self) -> int:
        """Recover abandoned work from a previous process.

        A single-worker application may safely recover every IN_PROGRESS row at
        startup. The lease columns additionally support supervisor recovery and
        make the state auditable.
        """
        with self.connect() as conn:
            cur = conn.execute(
                """
                UPDATE crawl_queue
                SET status='PENDING', lease_owner='', lease_expires_at='',
                    last_error=CASE WHEN last_error='' THEN 'Recovered abandoned in-progress lease' ELSE last_error END,
                    updated_at=?
                WHERE status='IN_PROGRESS'
                """,
                (_utc_now(),),
            )
            return int(cur.rowcount or 0)

    def reset_expired_in_progress(self) -> int:
        now = _utc_now()
        with self.connect() as conn:
            cur = conn.execute(
                """
                UPDATE crawl_queue
                SET status='PENDING', lease_owner='', lease_expires_at='',
                    last_error='Recovered expired worker lease', updated_at=?
                WHERE status='IN_PROGRESS'
                  AND lease_expires_at<>'' AND lease_expires_at<=?
                """,
                (now, now),
            )
            return int(cur.rowcount or 0)

    def next_pending(
        self,
        lease_owner: str = "",
        lease_seconds: int = 900,
        preferred_resource_class: str = "",
    ) -> dict[str, Any] | None:
        """Atomically claim the next due URL with a renewable worker lease.

        v6 can request one frontier lane to keep documents/data/assets making
        progress while a very large HTML frontier is still growing. XML
        sitemaps always retain first priority because they expand discovery.
        If the preferred lane is empty, the normal global lane order is used.
        """
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat(timespec="seconds")
        expires = (now_dt + timedelta(seconds=max(60, int(lease_seconds)))).isoformat(timespec="seconds")
        owner = str(lease_owner or "worker")[:200]
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            preferred = str(preferred_resource_class or "").strip().upper()
            row = None
            if preferred and preferred != SITEMAP:
                row = conn.execute(
                    """
                    SELECT * FROM crawl_queue
                    WHERE status='PENDING'
                      AND (not_before='' OR not_before<=?)
                      AND resource_class IN (?, ?)
                    ORDER BY CASE WHEN resource_class=? THEN 0 ELSE 1 END,
                             priority ASC, depth ASC, discovered_at ASC
                    LIMIT 1
                    """,
                    (now, SITEMAP, preferred, SITEMAP),
                ).fetchone()
            if row is None:
                row = conn.execute(
                    """
                    SELECT * FROM crawl_queue
                    WHERE status='PENDING'
                      AND (not_before='' OR not_before<=?)
                    ORDER BY lane_priority ASC, priority ASC, depth ASC, discovered_at ASC
                    LIMIT 1
                    """,
                    (now,),
                ).fetchone()
            if not row:
                return None
            cur = conn.execute(
                """
                UPDATE crawl_queue
                SET status='IN_PROGRESS', attempts=attempts+1, lease_owner=?,
                    lease_expires_at=?, last_progress_at=?, updated_at=?
                WHERE url=? AND status='PENDING'
                """,
                (owner, expires, now, now, row["url"]),
            )
            if int(cur.rowcount or 0) != 1:
                return None
            claimed = dict(row)
            claimed.update({
                "status": "IN_PROGRESS",
                "lease_owner": owner,
                "lease_expires_at": expires,
                "last_progress_at": now,
            })
            return claimed

    def touch_queue(self, url: str, lease_owner: str = "", lease_seconds: int = 900) -> bool:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat(timespec="seconds")
        expires = (now_dt + timedelta(seconds=max(60, int(lease_seconds)))).isoformat(timespec="seconds")
        with self.connect() as conn:
            if lease_owner:
                cur = conn.execute(
                    """
                    UPDATE crawl_queue
                    SET last_progress_at=?, lease_expires_at=?, updated_at=?
                    WHERE url=? AND status='IN_PROGRESS' AND lease_owner=?
                    """,
                    (now, expires, now, url, lease_owner),
                )
            else:
                cur = conn.execute(
                    """
                    UPDATE crawl_queue
                    SET last_progress_at=?, lease_expires_at=?, updated_at=?
                    WHERE url=? AND status='IN_PROGRESS'
                    """,
                    (now, expires, now, url),
                )
            return int(cur.rowcount or 0) == 1

    def mark_queue(self, url: str, status: str, error: str = "") -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE crawl_queue SET status=?, last_error=?, lease_owner='', lease_expires_at='', not_before='', updated_at=? WHERE url=?",
                (status, error[:4000], _utc_now(), url),
            )

    def queue_item(self, url: str) -> dict[str, Any] | None:
        lookup = canonicalize_url(str(url or "")) or str(url or "")
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM crawl_queue WHERE url=?", (lookup,)).fetchone()
            return dict(row) if row else None

    def requeue(
        self,
        url: str,
        error: str = "",
        priority_penalty: int = 5,
        delay_seconds: int = 0,
    ) -> None:
        now_dt = datetime.now(timezone.utc)
        not_before = ""
        if int(delay_seconds) > 0:
            not_before = (now_dt + timedelta(seconds=int(delay_seconds))).isoformat(timespec="seconds")
        with self.connect() as conn:
            conn.execute(
                """
                UPDATE crawl_queue
                SET status='PENDING', priority=priority+?, last_error=?,
                    lease_owner='', lease_expires_at='', not_before=?, updated_at=?
                WHERE url=?
                """,
                (max(0, int(priority_penalty)), error[:4000], not_before, now_dt.isoformat(timespec="seconds"), url),
            )

    def requeue_statuses(
        self,
        statuses: list[str] | tuple[str, ...],
        error: str = "Retrying recoverable source in resumed run",
        priority_penalty: int = 5,
    ) -> int:
        clean = [str(value).strip() for value in statuses if str(value).strip()]
        if not clean:
            return 0
        placeholders = ",".join("?" for _ in clean)
        with self.connect() as conn:
            cursor = conn.execute(
                f"""
                UPDATE crawl_queue
                SET status='PENDING', priority=priority+?, last_error=?, lease_owner='', lease_expires_at='', not_before='', updated_at=?
                WHERE status IN ({placeholders})
                """,
                (max(0, int(priority_penalty)), error[:4000], _utc_now(), *clean),
            )
            return max(0, int(cursor.rowcount or 0))

    def requeue_unfinished_dynamic_controls(
        self,
        terminal_statuses: tuple[str, ...] = (
            "STABLE_EXHAUSTED",
            "CYCLE_EXHAUSTED",
            "CONTROL_ABSENT",
            "DISABLED",
            "NAVIGATED",
            "DIRECT_ENDPOINT",
        ),
    ) -> int:
        clean = tuple(str(item) for item in terminal_statuses if str(item))
        placeholders = ",".join("?" for _ in clean)
        now = _utc_now()
        with self.connect() as conn:
            cursor = conn.execute(
                f"""
                UPDATE crawl_queue
                SET status='PENDING', lease_owner='', lease_expires_at='',
                    last_error='Retrying unfinished dynamic controls', updated_at=?
                WHERE url IN (
                    SELECT DISTINCT source_url
                    FROM dynamic_control_progress
                    WHERE status NOT IN ({placeholders})
                )
                  AND status NOT IN ('PENDING','IN_PROGRESS','SKIPPED','SKIPPED_PERMANENT')
                """,
                (now, *clean),
            )
            return max(0, int(cursor.rowcount or 0))

    def queue_counts(self) -> dict[str, int]:
        with self.connect() as conn:
            rows = conn.execute("SELECT status, COUNT(*) AS n FROM crawl_queue GROUP BY status").fetchall()
            return {row["status"]: int(row["n"]) for row in rows}

    def queue_lane_counts(self) -> dict[str, dict[str, int]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT resource_class,status,COUNT(*) AS n FROM crawl_queue GROUP BY resource_class,status"
            ).fetchall()
            result: dict[str, dict[str, int]] = {}
            for row in rows:
                result.setdefault(str(row["resource_class"] or "PAGE"), {})[str(row["status"])] = int(row["n"])
            return result

    def classify_legacy_frontier(self) -> dict[str, int]:
        """Populate v6 lane metadata on a database produced by v5.x."""
        updated = 0
        with self.connect() as conn:
            rows = conn.execute("SELECT url,relation,resource_class,resource_key FROM crawl_queue").fetchall()
            for row in rows:
                cls = classify_frontier_url(row["url"], row["relation"])
                key = asset_family_key(row["url"]) if cls == ASSET else ""
                conn.execute(
                    "UPDATE crawl_queue SET resource_class=?, lane_priority=?, resource_key=? WHERE url=?",
                    (cls, lane_priority(cls), key, row["url"]),
                )
                updated += 1
        return {"classified": updated}

    def compact_pending_asset_variants(self) -> dict[str, int]:
        """Keep the highest-resolution pending variant per visual family."""
        skipped = 0
        families = 0
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT url,resource_key,status FROM crawl_queue WHERE resource_class=? AND resource_key<>'' AND status IN ('PENDING','DEFERRED','FAILED','DONE_INCOMPLETE')",
                (ASSET,),
            ).fetchall()
            groups: dict[str, list[sqlite3.Row]] = {}
            for row in rows:
                groups.setdefault(str(row["resource_key"]), []).append(row)
            now = _utc_now()
            for key, variants in groups.items():
                if len(variants) < 2:
                    continue
                families += 1
                best = max(variants, key=lambda r: (asset_resolution_score(str(r["url"])), len(str(r["url"]))))
                for row in variants:
                    if row["url"] == best["url"]:
                        continue
                    conn.execute(
                        "UPDATE crawl_queue SET status='SKIPPED_DUPLICATE_ASSET', last_error=?, updated_at=? WHERE url=?",
                        (f"Duplicate visual variant; retained {best['url']}", now, row["url"]),
                    )
                    skipped += 1
        return {"families_compacted": families, "variants_skipped": skipped}

    def upsert_node(
        self,
        node_key: str,
        node_type: str,
        name: str,
        attributes: dict[str, Any] | None = None,
    ) -> tuple[int, bool]:
        now = _utc_now()
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id,node_type,name,attributes_json FROM nodes WHERE node_key=?", (node_key,)
            ).fetchone()
            created = existing is None
            if existing:
                attrs = _merge_dicts(_loads(existing["attributes_json"], {}), attributes or {})
                effective_type = _preferred_node_type(str(existing["node_type"] or ""), node_type or "Entity")
                effective_name = _preferred_node_name(str(existing["name"] or ""), name or node_key, node_key)
                conn.execute(
                    "UPDATE nodes SET node_type=?, name=?, attributes_json=?, last_seen=? WHERE id=?",
                    (effective_type, effective_name, _json(attrs), now, existing["id"]),
                )
                node_id = int(existing["id"])
            else:
                attrs = dict(attributes or {})
                effective_type = node_type or "Entity"
                effective_name = name or node_key
                cur = conn.execute(
                    "INSERT INTO nodes(node_key,node_type,name,attributes_json,first_seen,last_seen) VALUES(?,?,?,?,?,?)",
                    (node_key, effective_type, effective_name, _json(attrs), now, now),
                )
                node_id = int(cur.lastrowid)
            if self._fts_available:
                conn.execute("DELETE FROM nodes_fts WHERE node_key=?", (node_key,))
                conn.execute(
                    "INSERT INTO nodes_fts(name,node_type,attributes,node_key) VALUES(?,?,?,?)",
                    (effective_name, effective_type, _json(attrs), node_key),
                )
            return node_id, created

    def node_by_key(self, node_key: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM nodes WHERE node_key=?", (node_key,)).fetchone()
            return self._node_row(row) if row else None

    @staticmethod
    def _node_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": int(row["id"]),
            "node_key": row["node_key"],
            "node_type": row["node_type"],
            "name": row["name"],
            "attributes": _loads(row["attributes_json"], {}),
            "first_seen": row["first_seen"],
            "last_seen": row["last_seen"],
        }

    def upsert_edge(
        self,
        source_key: str,
        predicate: str,
        target_key: str,
        source_url: str = "",
        attributes: dict[str, Any] | None = None,
        confidence: float = 1.0,
    ) -> bool:
        source = self.node_by_key(source_key)
        target = self.node_by_key(target_key)
        if not source or not target:
            raise KeyError(f"Missing edge node: {source_key!r} -> {target_key!r}")
        raw_predicate = str(predicate or "RELATED_TO")
        predicate = canonical_relationship_type(raw_predicate)
        attributes = dict(attributes or {})
        if raw_predicate != predicate:
            attributes.setdefault("raw_relationship_type", raw_predicate)
        now = _utc_now()
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id, attributes_json FROM edges WHERE source_id=? AND predicate=? AND target_id=? AND source_url=?",
                (source["id"], predicate, target["id"], source_url),
            ).fetchone()
            if existing:
                attrs = _merge_dicts(_loads(existing["attributes_json"], {}), attributes or {})
                conn.execute(
                    "UPDATE edges SET attributes_json=?, confidence=MAX(confidence,?), last_seen=? WHERE id=?",
                    (_json(attrs), float(confidence), now, existing["id"]),
                )
                return False
            conn.execute(
                """
                INSERT INTO edges(source_id,predicate,target_id,attributes_json,source_url,confidence,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?)
                """,
                (source["id"], predicate, target["id"], _json(attributes or {}), source_url, float(confidence), now, now),
            )
            return True

    def add_fact(
        self,
        subject_key: str,
        predicate: str,
        value: str,
        source_url: str = "",
        unit: str = "",
        qualifiers: dict[str, Any] | None = None,
        confidence: float = 1.0,
        valid_from: str = "",
        valid_to: str = "",
    ) -> bool:
        subject = self.node_by_key(subject_key)
        if not subject or not str(value).strip():
            return False
        predicate = canonical_fact_key(predicate)
        now = _utc_now()
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id FROM facts WHERE subject_id=? AND predicate=? AND value=? AND unit=? AND source_url=?",
                (subject["id"], predicate, str(value), unit, source_url),
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE facts SET qualifiers_json=?, confidence=MAX(confidence,?), observed_at=?, valid_from=?, valid_to=? WHERE id=?",
                    (_json(qualifiers or {}), float(confidence), now, valid_from, valid_to, existing["id"]),
                )
                return False
            conn.execute(
                """
                INSERT INTO facts(subject_id,predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (subject["id"], predicate, str(value), unit, _json(qualifiers or {}), source_url, float(confidence), now, valid_from, valid_to),
            )
            return True


    @staticmethod
    def _normalized_price_value(value: Any) -> str:
        text = re.sub(r"\s+", "", str(value or "")).replace("£", "").replace(",", "")
        return text.strip()

    @staticmethod
    def _valid_product_value(field: str, value: Any) -> bool:
        text = re.sub(r"\s+", " ", str(value or "")).strip()
        if not text:
            return False
        lowered = text.casefold()
        suspicious = (
            '"rootkind"', '"attrs"', 'queryselector', 'schema.org', 'contenturl',
            'copyright ©', 'trademarks:', 'trademark or registered', 'privacy statement', 'site map',
            '}, {"index"', '<script', 'javascript:', '.psd?', 'fmt=', 'wid=', 'hei=',
            '\\u002b', '\"}', '{"', '"}',
        )
        if any(token in lowered for token in suspicious):
            return False
        max_lengths = {
            "price": 40, "list_price": 40, "price_ex_vat": 40, "discount": 40,
            "discount_percent": 20, "model": 160, "order_code": 180, "part_number": 180,
            "rating": 20, "review_count": 30, "currency": 10, "brand": 100,
            "processor": 400, "graphics": 350, "memory": 260, "storage": 260,
            "display": 350, "operating_system": 220, "networking": 350,
            "warranty": 700, "support": 700, "shipping": 700, "promotion": 700,
        }
        if len(text) > max_lengths.get(field, 1500):
            return False
        if field in {"price", "list_price", "price_ex_vat", "discount", "rewards"}:
            clean = re.sub(r"[^0-9.]", "", text.replace(",", ""))
            try:
                number = float(clean)
            except Exception:
                return False
            return 0 < number < 10_000_000
        if field == "discount_percent":
            try:
                return 0 <= float(re.sub(r"[^0-9.]", "", text)) <= 100
            except Exception:
                return False
        if field in {"model", "order_code", "part_number"}:
            return bool(re.search(r"[A-Z0-9]", text, re.I)) and not bool(re.search(r"[{}<>]", text))
        if field == "processor":
            return bool(re.search(
                r"(?:\bIntel(?:®)?\s+(?:Core(?:™)?\s+(?:Ultra|[3579]|i[3579]|\d)|Xeon)|"
                r"\bCore(?:™)?\s+Ultra|\bAMD(?:®)?\s+Ryzen(?:™)?\s+(?:AI\s+)?\d|"
                r"\bRyzen(?:™)?\s+(?:AI\s+)?\d|\b(?:EPYC|Threadripper|Snapdragon\s+X|Xeon)\b)",
                text, re.I,
            ))
        if field == "graphics":
            if not re.search(r"\b(?:NVIDIA|GeForce|RTX|Radeon|Intel(?:®)?\s+(?:Arc|Graphics|UHD)|GPU)\b", text, re.I):
                return False
            if re.search(r"trademark|corporation|other countries", text, re.I):
                return False
            # Reject footer keyword/trademark inventories such as
            # "NVIDIA logo, GeForce, RTX, ... CUDA, G-SYNC". They are not a
            # product's installed GPU specification.
            if text.count(",") >= 6 and not re.search(
                r"(?:RTX|GTX)\s*(?:PRO\s*)?\d{3,4}|Radeon\s+(?:RX|PRO)\s*[A-Z0-9-]+|Arc\s+[A-Z]?\d{2,4}",
                text,
                re.I,
            ):
                return False
            return True
        if field == "memory":
            return bool(re.search(r"\b\d+(?:\.\d+)?\s*(?:GB|TB)\b", text, re.I) and re.search(r"DDR|LPDDR|ECC|RAM|memory", text, re.I))
        if field == "storage":
            return bool(re.search(r"\b\d+(?:\.\d+)?\s*(?:GB|TB)\b", text, re.I) and re.search(r"SSD|NVMe|HDD|hard drive|storage", text, re.I))
        if field == "display":
            return bool(re.search(r'(?:\b\d{1,2}(?:\.\d)?\s*(?:-?in(?:ch)?(?:es)?|[”"])|OLED|QHD|UHD|4K|display|screen|touch(?:screen| panel))', text, re.I)) and not bool(re.search(r"camera|webcam", text, re.I))
        if field == "operating_system":
            return bool(re.fullmatch(
                r"(?:Windows 11(?: Home| Pro)?(?:, Copilot\+ PC)?|Windows 11 Home or Windows 11 Pro|"
                r"Ubuntu(?: Linux)?(?: [0-9.]+)?|Linux|RHEL(?: [0-9.]+)?|Red Hat Enterprise Linux(?: [0-9.]+)?)",
                text, re.I,
            ))
        if field == "rating":
            try:
                return 0 <= float(re.sub(r"[^0-9.]", "", text)) <= 5
            except Exception:
                return False
        if field == "review_count":
            return bool(re.fullmatch(r"[0-9,]+", text))
        return True

    @classmethod
    def _product_fact_score(cls, field: str, value: str, row: sqlite3.Row, product_url: str) -> float:
        if not cls._valid_product_value(field, value):
            return -1_000.0
        qualifiers = _loads(str(row["qualifiers_json"] or "{}"), {})
        extraction = str(qualifiers.get("extraction") or "").casefold()
        score = float(row["confidence"] or 0) * 3.0
        score += {
            "rendered_product_card": 8.0,
            "public_json_ld_product": 7.0,
            "product_detail_page": 7.5,
            "catalog_text_fallback": 5.0,
            "structured_json_ld": 5.0,
            "regex": 1.0,
        }.get(extraction, 2.0 if float(row["confidence"] or 0) >= 0.95 else 0.0)
        source_url = str(row["source_url"] or "")
        if product_url and source_url and source_url.split("?", 1)[0].rstrip("/") == product_url.split("?", 1)[0].rstrip("/"):
            score += 3.0
        text = re.sub(r"\s+", " ", value).strip()
        if len(text) <= 120:
            score += 1.0
        elif len(text) > 250:
            score -= 1.5
        if field in {"processor", "graphics", "memory", "storage", "display"} and re.search(r"\d", text):
            score += 0.75
        if field in {"model", "order_code", "part_number"} and re.fullmatch(r"[A-Z0-9._/-]+", text, re.I):
            score += 1.5
        return score

    @staticmethod
    def _product_completeness(attributes: dict[str, Any]) -> tuple[float, list[str]]:
        score, missing, _ = adaptive_product_completeness(attributes)
        return score, missing

    def refresh_product_projection(self, node_key: str) -> dict[str, Any]:
        """Project provenance facts into UI-friendly Product attributes.

        Facts remain authoritative and retain every observation.  The projection
        stores the latest/best normalized values directly in ``attributes_json``
        so dashboard and Neo4j exporters do not need to reconstruct price/spec
        columns independently.
        """
        node = self.node_by_key(node_key)
        if not node or node.get("node_type") != "Product":
            return {}
        attrs = dict(node.get("attributes") or {})
        attrs.setdefault("product_name", node.get("name") or "")
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT predicate,value,unit,qualifiers_json,source_url,confidence,observed_at
                FROM facts
                WHERE subject_id=?
                ORDER BY observed_at DESC, confidence DESC, id DESC
                """,
                (node["id"],),
            ).fetchall()
        product_url = str(attrs.get("product_url") or attrs.get("url") or "")
        if not product_url and str(node_key).startswith("url:"):
            product_url = str(node_key)[4:]
            attrs["product_url"] = product_url
            attrs.setdefault("url", product_url)
        candidates: dict[str, list[tuple[float, str, dict[str, Any]]]] = {}
        for row in rows:
            field = normalized_product_attribute(str(row["predicate"] or ""))
            if not field:
                continue
            value = str(row["value"] or "").strip()
            if field in {"price", "list_price", "price_ex_vat", "discount", "rewards"}:
                value = self._normalized_price_value(value)
            score = self._product_fact_score(field, value, row, product_url)
            if score < 0:
                continue
            record = {
                "value": value,
                "predicate": str(row["predicate"] or ""),
                "unit": str(row["unit"] or ""),
                "source_url": str(row["source_url"] or ""),
                "observed_at": str(row["observed_at"] or ""),
                "confidence": float(row["confidence"] or 0),
                "qualifiers": _loads(str(row["qualifiers_json"] or "{}"), {}),
                "quality_score": round(score, 4),
            }
            candidates.setdefault(field, []).append((score, record["observed_at"], record))
        selected: dict[str, dict[str, Any]] = {
            field: max(items, key=lambda item: (item[0], item[1]))[2]
            for field, items in candidates.items() if items
        }
        normalized_fields = set(selected) | {
            "price", "current_price", "list_price", "price_ex_vat", "discount", "discount_percent",
            "model", "order_code", "part_number", "processor", "graphics", "memory", "storage",
            "display", "operating_system", "networking", "rating", "review_count", "warranty",
            "support", "shipping", "promotion", "availability", "condition", "financing", "rewards",
        }
        for field in normalized_fields:
            if field in attrs and not self._valid_product_value("price" if field == "current_price" else field, attrs.get(field)):
                attrs.pop(field, None)
        for field, record in selected.items():
            attrs[field] = record["value"]
        if attrs.get("price") and not attrs.get("current_price"):
            attrs["current_price"] = attrs["price"]
        if attrs.get("current_price") and not attrs.get("price"):
            attrs["price"] = attrs["current_price"]
        if attrs.get("list_price") and attrs.get("price"):
            try:
                if float(self._normalized_price_value(attrs["list_price"])) == float(self._normalized_price_value(attrs["price"])):
                    attrs.pop("list_price", None)
            except Exception:
                pass
        if not attrs.get("currency") and attrs.get("price"):
            attrs["currency"] = infer_market_context(
                product_url or str(attrs.get("source_url") or ""),
                evidence_text=str(attrs.get("price") or ""),
            ).currency
        if not attrs.get("brand") and re.search(
            r"\b(?:Dell|XPS|Alienware|Inspiron|Precision|Latitude|OptiPlex|PowerEdge|PowerStore|PowerScale|PowerFlex|UltraSharp)\b",
            str(node.get("name") or attrs.get("product_name") or ""), re.I,
        ):
            attrs["brand"] = "Dell"
        attrs["normalized_fields"] = selected
        attrs["projection_updated_at"] = _utc_now()
        score, missing, applicable = adaptive_product_completeness(attrs)
        attrs["completeness_score"] = score
        attrs["missing_fields"] = missing
        attrs["applicable_completeness_fields"] = applicable
        self.upsert_node(node_key, "Product", str(node.get("name") or attrs.get("product_name") or node_key), attrs)
        return attrs

    def record_product_observation(
        self,
        node_key: str,
        source_url: str,
        fields: dict[str, Any],
    ) -> bool:
        node = self.node_by_key(node_key)
        if not node or node.get("node_type") != "Product":
            return False
        payload = dict(fields or {})
        observed_at = _utc_now()
        basis = _json({
            "node_key": node_key,
            "source_url": source_url,
            "price": payload.get("price") or payload.get("current_price") or "",
            "list_price": payload.get("list_price") or "",
            "order_code": payload.get("order_code") or "",
            "model": payload.get("model") or "",
            "processor": payload.get("processor") or payload.get("cpu") or "",
            "graphics": payload.get("graphics") or payload.get("gpu") or "",
            "memory": payload.get("memory") or "",
            "storage": payload.get("storage") or "",
        })
        observation_hash = hashlib.sha256(basis.encode("utf-8", errors="ignore")).hexdigest()
        with self.connect() as conn:
            cursor = conn.execute(
                """
                INSERT OR IGNORE INTO product_observations(
                    product_id,source_url,observed_at,observation_hash,price,list_price,currency,
                    model,order_code,completeness_score,fields_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    node["id"], source_url, observed_at, observation_hash,
                    self._normalized_price_value(payload.get("price") or payload.get("current_price") or ""),
                    self._normalized_price_value(payload.get("list_price") or ""),
                    str(payload.get("currency") or infer_market_context(source_url, evidence_text=str(payload.get("price") or payload.get("current_price") or "")).currency), str(payload.get("model") or ""),
                    str(payload.get("order_code") or ""), float(payload.get("completeness_score") or 0),
                    _json(payload),
                ),
            )
            return int(cursor.rowcount or 0) == 1

    def backfill_product_projection(self) -> dict[str, int]:
        with self.connect() as conn:
            keys = [str(row["node_key"]) for row in conn.execute("SELECT node_key FROM nodes WHERE node_type='Product'").fetchall()]
        refreshed = 0
        prices = 0
        core_specs = 0
        for node_key in keys:
            attrs = self.refresh_product_projection(node_key)
            if not attrs:
                continue
            refreshed += 1
            prices += int(bool(attrs.get("price") or attrs.get("current_price")))
            core_specs += int(any(attrs.get(key) for key in ("processor", "graphics", "memory", "storage", "display", "operating_system")))
        return {"products_refreshed": refreshed, "products_with_price": prices, "products_with_core_specs": core_specs}

    def product_completeness_report(self) -> dict[str, Any]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT id,node_key,name,attributes_json FROM nodes
                WHERE id IN (SELECT product_id FROM product_catalog_view)
                """
            ).fetchall()
        field_counts: dict[str, int] = {}
        incomplete: list[dict[str, Any]] = []
        with_price = 0
        with_specs = 0
        complete = 0
        for row in rows:
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            attrs.setdefault("product_name", row["name"])
            score, missing = self._product_completeness(attrs)
            if attrs.get("price") or attrs.get("current_price"):
                with_price += 1
            if any(attrs.get(key) for key in ("processor", "graphics", "memory", "storage", "display", "operating_system")):
                with_specs += 1
            if score >= 0.85:
                complete += 1
            else:
                incomplete.append({
                    "product_id": int(row["id"]), "node_key": row["node_key"], "name": row["name"],
                    "score": score, "missing_fields": missing,
                    "product_url": attrs.get("product_url") or attrs.get("url") or "",
                    "source_url": attrs.get("source_url") or "",
                })
            for field in ("price", "list_price", "model", "order_code", "processor", "graphics", "memory", "storage", "display", "operating_system", "rating", "review_count", "warranty", "shipping", "promotion"):
                field_counts[field] = field_counts.get(field, 0) + int(bool(attrs.get(field)))
        total = len(rows)
        return {
            "generated_at": _utc_now(),
            "products": total,
            "products_with_price": with_price,
            "products_with_core_specs": with_specs,
            "products_complete_85_percent": complete,
            "price_coverage_percent": round(100.0 * with_price / total, 2) if total else 0.0,
            "spec_coverage_percent": round(100.0 * with_specs / total, 2) if total else 0.0,
            "complete_coverage_percent": round(100.0 * complete / total, 2) if total else 0.0,
            "field_counts": field_counts,
            "incomplete_products": sorted(incomplete, key=lambda item: (item["score"], item["name"]))[:5000],
        }

    def schedule_product_revisit_sweep(
        self,
        *,
        min_score: float = 0.85,
        max_attempts: int = 4,
        no_gain_limit: int = 2,
        min_gain: float = 0.02,
        priority: int = 0,
        revisit_missing_price: bool = True,
        revisit_missing_specs: bool = True,
        revisit_unmapped: bool = True,
    ) -> dict[str, Any]:
        """Audit Product projections and enqueue only the records that still need enrichment.

        This is intentionally called when the normal frontier has drained. A previously
        DONE/DONE_INCOMPLETE Dell PDP can therefore be revisited in the *same run*.
        Progress is tracked per canonical Product so a page that never exposes a public
        price/spec does not loop forever.
        """
        report = {
            "products_checked": 0,
            "products_needing_revisit": 0,
            "urls_requeued": 0,
            "products_completed": 0,
            "products_exhausted": 0,
            "products_blocked_no_url": 0,
            "identity_recovery_requeues": 0,
            "detail_requeues": 0,
        }
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT id,node_key,name,attributes_json FROM nodes
                WHERE id IN (SELECT product_id FROM product_catalog_view)
                ORDER BY last_seen DESC,id DESC
                """
            ).fetchall()
            prior_rows = conn.execute("SELECT * FROM product_enrichment_state").fetchall()
        prior = {str(row["product_key"]): dict(row) for row in prior_rows}
        core_fields = {"processor", "graphics", "memory", "storage", "display", "operating_system"}
        now = _utc_now()
        queued_urls: set[str] = set()

        for row in rows:
            report["products_checked"] += 1
            node_key = str(row["node_key"] or "")
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            if not isinstance(attrs, dict):
                attrs = {}
            attrs.setdefault("product_name", str(row["name"] or ""))
            score, missing, applicable = adaptive_product_completeness(attrs)
            product_url = str(attrs.get("product_url") or attrs.get("url") or "").strip()
            if not is_product_detail_url(product_url, str(attrs.get("source_url") or "")) and node_key.startswith("url:"):
                node_url = node_key[4:]
                if is_product_detail_url(node_url):
                    product_url = node_url
            source_url = str(attrs.get("source_url") or "").strip()
            if not source_url and is_product_detail_url(product_url):
                source_url = product_url
            unresolved_unmapped = int(attrs.get("unresolved_unmapped_evidence_count") or 0)
            applicable_core = core_fields.intersection(set(applicable))
            missing_core = applicable_core.intersection(set(missing))
            has_price = bool(attrs.get("price") or attrs.get("current_price"))
            exact_pdp = is_product_detail_url(product_url, source_url)

            identity_missing = not exact_pdp
            missing_price = bool(revisit_missing_price and exact_pdp and not has_price)
            missing_specs = bool(revisit_missing_specs and missing_core)
            mapping_gap = bool(revisit_unmapped and unresolved_unmapped > 0)
            needs_revisit = bool(identity_missing or score < float(min_score) or missing_price or missing_specs or mapping_gap)

            old = prior.get(node_key, {})
            old_status = str(old.get("status") or "")
            old_attempts = int(old.get("attempts") or 0)
            old_no_gain = int(old.get("no_gain_rounds") or 0)
            old_score = float(old.get("last_score") or 0)
            old_missing = _loads(str(old.get("missing_fields_json") or "[]"), [])
            if not isinstance(old_missing, list):
                old_missing = []
            old_unmapped = int(old.get("unresolved_unmapped") or 0)

            if not needs_revisit:
                if old_status and old_status != "COMPLETE":
                    report["products_completed"] += 1
                with self.connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO product_enrichment_state(
                            product_key,product_id,product_url,source_url,status,attempts,no_gain_rounds,
                            last_score,best_score,missing_fields_json,unresolved_unmapped,last_reason,
                            last_queued_at,last_attempt_at,updated_at
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(product_key) DO UPDATE SET
                            product_id=excluded.product_id,product_url=excluded.product_url,source_url=excluded.source_url,
                            status='COMPLETE',no_gain_rounds=0,last_score=excluded.last_score,
                            best_score=MAX(product_enrichment_state.best_score,excluded.best_score),
                            missing_fields_json=excluded.missing_fields_json,unresolved_unmapped=excluded.unresolved_unmapped,
                            last_reason='complete',updated_at=excluded.updated_at
                        """,
                        (node_key,int(row["id"]),product_url,source_url,"COMPLETE",old_attempts,0,score,max(score,float(old.get("best_score") or 0)),
                         _json(missing),unresolved_unmapped,"complete",str(old.get("last_queued_at") or ""),str(old.get("last_attempt_at") or ""),now),
                    )
                continue

            report["products_needing_revisit"] += 1
            # A QUEUED state observed again after the frontier drained represents a
            # completed revisit attempt. Measure information gain before deciding
            # whether to spend another attempt.
            no_gain_rounds = old_no_gain
            if old_status == "QUEUED":
                gained = (
                    score >= old_score + float(min_gain)
                    or len(missing) < len(old_missing)
                    or unresolved_unmapped < old_unmapped
                    or ("price" in old_missing and has_price)
                )
                no_gain_rounds = 0 if gained else old_no_gain + 1

            reasons: list[str] = []
            if identity_missing: reasons.append("missing_exact_product_url")
            if missing_price: reasons.append("missing_price")
            if missing_specs: reasons.append("missing_specs:" + ",".join(sorted(missing_core)))
            if score < float(min_score): reasons.append(f"completeness={score:.4f}")
            if mapping_gap: reasons.append(f"unmapped={unresolved_unmapped}")
            reason = "; ".join(reasons)[:2000]

            if old_attempts >= max(1, int(max_attempts)) or no_gain_rounds >= max(1, int(no_gain_limit)):
                status = "EXHAUSTED_NO_GAIN" if no_gain_rounds >= max(1, int(no_gain_limit)) else "EXHAUSTED_ATTEMPTS"
                if not old_status.startswith("EXHAUSTED"):
                    report["products_exhausted"] += 1
                with self.connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO product_enrichment_state(
                            product_key,product_id,product_url,source_url,status,attempts,no_gain_rounds,last_score,best_score,
                            missing_fields_json,unresolved_unmapped,last_reason,last_queued_at,last_attempt_at,updated_at
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(product_key) DO UPDATE SET
                            product_id=excluded.product_id,product_url=excluded.product_url,source_url=excluded.source_url,
                            status=excluded.status,no_gain_rounds=excluded.no_gain_rounds,last_score=excluded.last_score,
                            best_score=MAX(product_enrichment_state.best_score,excluded.best_score),
                            missing_fields_json=excluded.missing_fields_json,unresolved_unmapped=excluded.unresolved_unmapped,
                            last_reason=excluded.last_reason,last_attempt_at=excluded.last_attempt_at,updated_at=excluded.updated_at
                        """,
                        (node_key,int(row["id"]),product_url,source_url,status,old_attempts,no_gain_rounds,score,
                         max(score,float(old.get("best_score") or 0)),_json(missing),unresolved_unmapped,reason,
                         str(old.get("last_queued_at") or ""),now,now),
                    )
                continue

            target_url = product_url if exact_pdp else source_url
            if not target_url or is_media_asset_url(target_url, source_url):
                report["products_blocked_no_url"] += 1
                with self.connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO product_enrichment_state(
                            product_key,product_id,product_url,source_url,status,attempts,no_gain_rounds,last_score,best_score,
                            missing_fields_json,unresolved_unmapped,last_reason,last_queued_at,last_attempt_at,updated_at
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(product_key) DO UPDATE SET
                            status='BLOCKED_NO_URL',product_id=excluded.product_id,product_url=excluded.product_url,
                            source_url=excluded.source_url,no_gain_rounds=excluded.no_gain_rounds,last_score=excluded.last_score,
                            best_score=MAX(product_enrichment_state.best_score,excluded.best_score),
                            missing_fields_json=excluded.missing_fields_json,unresolved_unmapped=excluded.unresolved_unmapped,
                            last_reason=excluded.last_reason,updated_at=excluded.updated_at
                        """,
                        (node_key,int(row["id"]),product_url,source_url,"BLOCKED_NO_URL",old_attempts,no_gain_rounds,score,
                         max(score,float(old.get("best_score") or 0)),_json(missing),unresolved_unmapped,reason,"",now,now),
                    )
                continue

            relation = "PRODUCT_DETAIL_ENRICHMENT" if exact_pdp else "PRODUCT_IDENTITY_RECOVERY"
            existing_queue = self.queue_item(target_url)
            if existing_queue and str(existing_queue.get("status") or "") == "SKIPPED_PERMANENT":
                if old_status != "EXHAUSTED_PERMANENT_SOURCE":
                    report["products_exhausted"] += 1
                with self.connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO product_enrichment_state(
                            product_key,product_id,product_url,source_url,status,attempts,no_gain_rounds,last_score,best_score,
                            missing_fields_json,unresolved_unmapped,last_reason,last_queued_at,last_attempt_at,updated_at
                        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(product_key) DO UPDATE SET
                            status='EXHAUSTED_PERMANENT_SOURCE',product_id=excluded.product_id,product_url=excluded.product_url,
                            source_url=excluded.source_url,last_score=excluded.last_score,
                            best_score=MAX(product_enrichment_state.best_score,excluded.best_score),
                            missing_fields_json=excluded.missing_fields_json,unresolved_unmapped=excluded.unresolved_unmapped,
                            last_reason=excluded.last_reason,updated_at=excluded.updated_at
                        """,
                        (node_key,int(row["id"]),product_url,source_url,"EXHAUSTED_PERMANENT_SOURCE",old_attempts,no_gain_rounds,score,
                         max(score,float(old.get("best_score") or 0)),_json(missing),unresolved_unmapped,
                         f"{reason}; source permanently unavailable",str(old.get("last_queued_at") or ""),now,now),
                    )
                continue
            if target_url not in queued_urls:
                self.enqueue(
                    target_url,
                    depth=1,
                    priority=max(0, int(priority)),
                    parent_url=source_url if exact_pdp else "",
                    relation=relation,
                    force=True,
                    resource_class=PAGE,
                )
                queued_urls.add(target_url)
                report["urls_requeued"] += 1
                if exact_pdp:
                    report["detail_requeues"] += 1
                else:
                    report["identity_recovery_requeues"] += 1
            with self.connect() as conn:
                conn.execute(
                    """
                    INSERT INTO product_enrichment_state(
                        product_key,product_id,product_url,source_url,status,attempts,no_gain_rounds,last_score,best_score,
                        missing_fields_json,unresolved_unmapped,last_reason,last_queued_at,last_attempt_at,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(product_key) DO UPDATE SET
                        product_id=excluded.product_id,product_url=excluded.product_url,source_url=excluded.source_url,
                        status='QUEUED',attempts=excluded.attempts,no_gain_rounds=excluded.no_gain_rounds,
                        last_score=excluded.last_score,best_score=MAX(product_enrichment_state.best_score,excluded.best_score),
                        missing_fields_json=excluded.missing_fields_json,unresolved_unmapped=excluded.unresolved_unmapped,
                        last_reason=excluded.last_reason,last_queued_at=excluded.last_queued_at,updated_at=excluded.updated_at
                    """,
                    (node_key,int(row["id"]),product_url,source_url,"QUEUED",old_attempts + 1,no_gain_rounds,score,
                     max(score,float(old.get("best_score") or 0)),_json(missing),unresolved_unmapped,reason,now,
                     str(old.get("last_attempt_at") or ""),now),
                )
        return report

    def product_enrichment_status_report(self) -> dict[str, Any]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT status,COUNT(*) AS n FROM product_enrichment_state GROUP BY status ORDER BY status"
            ).fetchall()
            samples = conn.execute(
                """
                SELECT product_key,product_url,source_url,status,attempts,no_gain_rounds,last_score,best_score,
                       missing_fields_json,unresolved_unmapped,last_reason,updated_at
                FROM product_enrichment_state
                WHERE status<>'COMPLETE'
                ORDER BY CASE status WHEN 'QUEUED' THEN 0 WHEN 'BLOCKED_NO_URL' THEN 1 ELSE 2 END,
                         last_score ASC,updated_at DESC
                LIMIT 200
                """
            ).fetchall()
        return {
            "status_counts": {str(row["status"]): int(row["n"] or 0) for row in rows},
            "pending_samples": [
                {**dict(row), "missing_fields": _loads(str(row["missing_fields_json"] or "[]"), [])}
                for row in samples
            ],
        }

    def extractor_quality_report(self) -> dict[str, Any]:
        """Return a truthful Product-node quality audit for the Streamlit UI."""
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT node_key,name,attributes_json FROM nodes WHERE node_type='Product' ORDER BY name"
            ).fetchall()
        fields = (
            "model", "part_number", "order_code", "processor", "graphics",
            "memory", "storage", "display", "operating_system", "price",
        )
        counts = {field: 0 for field in fields}
        exact_urls = 0
        contaminated: list[dict[str, Any]] = []
        retail_ready = 0
        for row in rows:
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            if not isinstance(attrs, dict):
                attrs = {}
            attrs.setdefault("product_name", str(row["name"] or ""))
            product_url = str(attrs.get("product_url") or attrs.get("url") or "")
            node_url = str(row["node_key"] or "")[4:] if str(row["node_key"] or "").startswith("url:") else ""
            suspect = product_url or node_url
            if is_media_asset_url(suspect, str(attrs.get("source_url") or "")):
                contaminated.append({
                    "node_key": str(row["node_key"] or ""),
                    "product_name": str(row["name"] or ""),
                    "url": suspect,
                })
            if is_product_detail_url(product_url):
                exact_urls += 1
            for field in fields:
                value = attrs.get(field)
                if field == "price":
                    value = attrs.get("price") or attrs.get("current_price")
                counts[field] += int(value not in (None, "", [], {}))
            score, _, _ = adaptive_product_completeness(attrs)
            if score >= 0.85 and is_product_detail_url(product_url) and bool(attrs.get("price") or attrs.get("current_price")):
                retail_ready += 1
        total = len(rows)
        return {
            "products": total,
            "media_contaminated_nodes": len(contaminated),
            "exact_dell_product_urls": exact_urls,
            "exact_dell_url_coverage_percent": round(100.0 * exact_urls / total, 2) if total else 0.0,
            "retail_ready_products": retail_ready,
            "field_counts": counts,
            "field_coverage_percent": {
                field: round(100.0 * count / total, 2) if total else 0.0
                for field, count in counts.items()
            },
            "contaminated_samples": contaminated[:100],
        }

    def upsert_source(
        self,
        url: str,
        canonical_url: str,
        title: str,
        page_type: str,
        content_hash: str,
        http_status: int | None = None,
        screenshot_path: str = "",
        raw_path: str = "",
        mime_type: str = "text/html",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO sources(url,canonical_url,title,page_type,content_hash,fetched_at,http_status,screenshot_path,raw_path,mime_type,metadata_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(url) DO UPDATE SET
                    canonical_url=excluded.canonical_url,title=excluded.title,page_type=excluded.page_type,
                    content_hash=excluded.content_hash,fetched_at=excluded.fetched_at,http_status=excluded.http_status,
                    screenshot_path=excluded.screenshot_path,raw_path=excluded.raw_path,mime_type=excluded.mime_type,
                    metadata_json=excluded.metadata_json
                """,
                (
                    url,
                    canonical_url,
                    title,
                    page_type,
                    content_hash,
                    _utc_now(),
                    http_status,
                    screenshot_path,
                    raw_path,
                    mime_type,
                    _json(metadata or {}),
                ),
            )


    def duplicate_source_for_hash(self, content_hash: str, exclude_url: str = "") -> dict[str, Any] | None:
        """Return an already stored canonical source with the same exact content.

        Exact hashes are deliberately conservative. This suppresses duplicate Dell
        aliases/templates without fuzzy-merging pages that merely look similar.
        """
        digest = str(content_hash or "").strip()
        if not digest:
            return None
        candidate = canonicalize_url(str(exclude_url or "")) if exclude_url else ""
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT url,canonical_url,title,page_type,content_hash,fetched_at,metadata_json
                FROM sources
                WHERE content_hash=? AND (?='' OR canonical_url<>?)
                ORDER BY fetched_at ASC
                LIMIT 1
                """,
                (digest, candidate, candidate),
            ).fetchone()
        return dict(row) if row else None

    def duplicate_source_for_semantic_hash(self, semantic_hash: str, exclude_url: str = "") -> dict[str, Any] | None:
        digest = str(semantic_hash or "").strip()
        if not digest:
            return None
        candidate = canonicalize_url(str(exclude_url or "")) if exclude_url else ""
        with self.connect() as conn:
            try:
                row = conn.execute(
                    """
                    SELECT url,canonical_url,title,page_type,content_hash,fetched_at,metadata_json
                    FROM sources
                    WHERE json_extract(metadata_json,'$.semantic_content_hash')=?
                      AND (?='' OR canonical_url<>?)
                    ORDER BY fetched_at ASC
                    LIMIT 1
                    """,
                    (digest, candidate, candidate),
                ).fetchone()
            except sqlite3.OperationalError:
                row = None
        return dict(row) if row else None

    def get_source_metadata(self, url: str) -> dict[str, Any]:
        """Return persisted source metadata for a URL or canonical URL."""
        candidate = str(url or "").strip()
        if not candidate:
            return {}
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT metadata_json
                FROM sources
                WHERE url=? OR canonical_url=?
                ORDER BY CASE WHEN url=? THEN 0 ELSE 1 END, fetched_at DESC
                LIMIT 1
                """,
                (candidate, candidate, candidate),
            ).fetchone()
        return _loads(str(row["metadata_json"] or "{}"), {}) if row else {}

    @staticmethod
    def _chunk_text(text: str, max_chars: int = 3500, overlap_chars: int = 300) -> list[tuple[str, str]]:
        paragraphs = [re.sub(r"\s+", " ", p).strip() for p in re.split(r"\n+", text or "") if p.strip()]
        chunks: list[tuple[str, str]] = []
        current: list[str] = []
        current_len = 0
        heading = ""
        for paragraph in paragraphs:
            if len(paragraph) < 180 and re.match(r"^[A-Z0-9][^.!?]{2,}$", paragraph):
                heading = paragraph
            if current and current_len + len(paragraph) + 1 > max_chars:
                chunk = "\n".join(current)
                chunks.append((heading, chunk))
                overlap = chunk[-overlap_chars:] if overlap_chars else ""
                current = [overlap] if overlap else []
                current_len = len(overlap)
            current.append(paragraph)
            current_len += len(paragraph) + 1
        if current:
            chunks.append((heading, "\n".join(current)))
        return chunks or [("", text[:max_chars])]

    def replace_chunks(self, source_url: str, text: str) -> int:
        chunks = self._chunk_text(text)
        with self.connect() as conn:
            conn.execute("DELETE FROM chunks WHERE source_url=?", (source_url,))
            if self._fts_available:
                conn.execute("DELETE FROM chunks_fts WHERE source_url=?", (source_url,))
            count = 0
            for index, (heading, chunk) in enumerate(chunks):
                digest = hashlib.sha256(chunk.encode("utf-8", errors="ignore")).hexdigest()
                conn.execute(
                    "INSERT OR IGNORE INTO chunks(source_url,chunk_index,heading,text,content_hash) VALUES(?,?,?,?,?)",
                    (source_url, index, heading, chunk, digest),
                )
                if self._fts_available:
                    conn.execute(
                        "INSERT INTO chunks_fts(text,heading,source_url) VALUES(?,?,?)",
                        (chunk, heading, source_url),
                    )
                count += 1
            return count

    def record_link_evidence(
        self,
        source_url: str,
        target_url: str,
        *,
        label: str = "",
        relation: str = "LINKS_TO",
        ref: str = "",
        priority: int = 50,
        resource_kind: str = "",
    ) -> bool:
        source = canonicalize_url(str(source_url or ""))
        target = canonicalize_url(str(target_url or ""), source or "https://www.dell.com")
        if not source or not target or source == target:
            return False
        predicate = canonical_relationship_type(relation or "LINKS_TO")
        now = _utc_now()
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id FROM link_evidence WHERE source_url=? AND target_url=? AND relation=? AND label=?",
                (source, target, predicate, str(label or "")[:1000]),
            ).fetchone()
            conn.execute(
                """
                INSERT INTO link_evidence(source_url,target_url,label,relation,ref,priority,resource_kind,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_url,target_url,relation,label) DO UPDATE SET
                    ref=CASE WHEN excluded.ref<>'' THEN excluded.ref ELSE link_evidence.ref END,
                    priority=MIN(link_evidence.priority,excluded.priority),
                    resource_kind=CASE WHEN excluded.resource_kind<>'' THEN excluded.resource_kind ELSE link_evidence.resource_kind END,
                    last_seen=excluded.last_seen
                """,
                (source, target, str(label or "")[:1000], predicate, str(ref or "")[:500], int(priority or 50), str(resource_kind or "")[:160], now, now),
            )
        return existing is None

    def _materialize_link_edges_for_page(self, page_url: str) -> int:
        """Create navigation edges only when both pages are real fetched nodes.

        v6.15 created a graph node for every discovered href. On large Dell pages that
        produced tens of thousands of placeholder nodes. v6.16 stores discovery in
        ``link_evidence`` and promotes a navigation edge only after the target itself
        has been fetched/ingested.
        """
        canonical = canonicalize_url(page_url)
        page_key = f"url:{canonical}"
        if not self.node_by_key(page_key):
            return 0
        created = 0
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT source_url,target_url,label,relation,ref,priority,resource_kind
                FROM link_evidence
                WHERE source_url=? OR target_url=?
                """,
                (canonical, canonical),
            ).fetchall()
        for row in rows:
            source_key = f"url:{row['source_url']}"
            target_key = f"url:{row['target_url']}"
            if not self.node_by_key(source_key) or not self.node_by_key(target_key):
                continue
            created += int(self.upsert_edge(
                source_key,
                str(row["relation"] or "LINKS_TO"),
                target_key,
                str(row["source_url"] or ""),
                {
                    "label": str(row["label"] or ""),
                    "ref": str(row["ref"] or ""),
                    "priority": int(row["priority"] or 50),
                    "resource_kind": str(row["resource_kind"] or ""),
                    "materialized_after_fetch": True,
                },
            ))
        return created

    def record_extraction_evidence(
        self,
        source_url: str,
        payload: Any,
        *,
        evidence_kind: str = "unmapped",
        reason: str = "",
    ) -> bool:
        if payload in (None, "", [], {}):
            return False
        raw = _json(payload)
        digest = hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()
        now = _utc_now()
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id FROM extraction_evidence WHERE source_url=? AND evidence_kind=? AND evidence_hash=?",
                (source_url, evidence_kind, digest),
            ).fetchone()
            conn.execute(
                """
                INSERT INTO extraction_evidence(source_url,evidence_kind,evidence_hash,payload_json,reason,observed_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(source_url,evidence_kind,evidence_hash) DO UPDATE SET
                    reason=CASE WHEN excluded.reason<>'' THEN excluded.reason ELSE extraction_evidence.reason END,
                    observed_at=excluded.observed_at
                """,
                (source_url, evidence_kind, digest, raw, str(reason or "")[:1000], now),
            )
        return existing is None

    def record_extraction_validation(self, source_url: str, report: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO extraction_validation(source_url,report_json,validated_at)
                VALUES(?,?,?)
                ON CONFLICT(source_url) DO UPDATE SET
                    report_json=excluded.report_json,validated_at=excluded.validated_at
                """,
                (source_url, _json(report or {}), _utc_now()),
            )

    @staticmethod
    def _identity_token(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())

    def resolve_product_node_key(self, proposed_key: str, attrs: dict[str, Any], name: str = "") -> str:
        """Reuse an existing Product when any strong Dell identity already matches.

        This prevents the same product becoming separate URL/order-code/part-number
        nodes depending on which evidence source was encountered first.
        """
        proposed_key = str(proposed_key or "")
        if self.node_by_key(proposed_key):
            return proposed_key
        order_code = self._identity_token(attrs.get("order_code") or attrs.get("orderCode") or attrs.get("sku"))
        part_number = self._identity_token(attrs.get("part_number") or attrs.get("partNumber") or attrs.get("mpn"))
        product_url = canonicalize_url(str(attrs.get("product_url") or attrs.get("url") or "")) if (attrs.get("product_url") or attrs.get("url")) else ""
        model = self._identity_token(attrs.get("model"))
        brand = self._identity_token(attrs.get("brand"))
        if not any((order_code, part_number, product_url, model)):
            return proposed_key
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT node_key,name,attributes_json FROM nodes WHERE node_type='Product' ORDER BY last_seen DESC LIMIT 10000"
            ).fetchall()
        best: tuple[int, str] | None = None
        for row in rows:
            other = _loads(str(row["attributes_json"] or "{}"), {})
            o_order = self._identity_token(other.get("order_code") or other.get("orderCode") or other.get("sku"))
            o_part = self._identity_token(other.get("part_number") or other.get("partNumber") or other.get("mpn"))
            o_url = canonicalize_url(str(other.get("product_url") or other.get("url") or "")) if (other.get("product_url") or other.get("url")) else ""
            o_model = self._identity_token(other.get("model"))
            o_brand = self._identity_token(other.get("brand"))
            score = 0
            if order_code and o_order and order_code == o_order:
                score = max(score, 100)
            if part_number and o_part and part_number == o_part:
                score = max(score, 95)
            if product_url and o_url and product_url == o_url:
                score = max(score, 90)
            # Model is only a fallback identity when neither observation has a
            # stronger configuration identifier. Different Dell configurations can
            # share the same chassis/model name and must not be merged.
            if (
                model and o_model and brand and o_brand and model == o_model and brand == o_brand
                and not any((order_code, part_number, product_url, o_order, o_part, o_url))
            ):
                score = max(score, 55)
            if score and (best is None or score > best[0]):
                best = (score, str(row["node_key"]))
        if best:
            canonical_key = best[1]
            if proposed_key and proposed_key != canonical_key:
                with self.connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO product_identity_aliases(alias_key,canonical_product_key,reason,observed_at)
                        VALUES(?,?,?,?)
                        ON CONFLICT(alias_key) DO UPDATE SET
                            canonical_product_key=excluded.canonical_product_key,reason=excluded.reason,observed_at=excluded.observed_at
                        """,
                        (proposed_key, canonical_key, f"strong_identity_match_score={best[0]}", _utc_now()),
                    )
            return canonical_key
        return proposed_key

    def ingest_page(self, page: CrawlPage) -> dict[str, int]:
        counts = {
            "nodes_created": 0,
            "edges_created": 0,
            "facts_created": 0,
            "chunks_created": 0,
            "link_evidence_recorded": 0,
        }
        canonical_url = canonicalize_url(page.canonical_url or page.url)
        if not canonical_url:
            canonical_url = page.canonical_url or page.url
        page.canonical_url = canonical_url
        market_context = infer_market_context(canonical_url, evidence_text=page.visible_text or "")
        locale, market_code, market_name = market_context.locale, market_context.market, market_context.market_name
        metadata = dict(page.metadata or {})
        metadata.setdefault("currency", market_context.currency)
        metadata.setdefault("locale", locale)
        metadata.setdefault("market", market_code)
        self.upsert_source(
            url=canonical_url,
            canonical_url=canonical_url,
            title=page.title,
            page_type=page.page_type,
            content_hash=page.content_hash,
            http_status=page.http_status,
            screenshot_path=page.screenshot_path,
            metadata=metadata,
        )
        page_key = f"url:{canonical_url}"
        canonical_page_type = canonical_node_type(page.page_type, context="page")
        _, created = self.upsert_node(
            page_key,
            canonical_page_type,
            page.title or canonical_url,
            {
                "url": canonical_url,
                "market": market_code,
                "locale": locale,
                "content_hash": page.content_hash,
                "page_type": page.page_type,
                "raw_node_type": page.page_type,
                "canonical_class": canonical_page_type,
                "classification_confidence": 1.0,
                "classification_reason": "fetched_page_type",
                "classification_version": "v6.19",
                "fetched_source": True,
                **metadata,
            },
        )
        counts["nodes_created"] += int(created)
        counts["chunks_created"] += self.replace_chunks(canonical_url, page.visible_text)

        market_key = f"market:{market_code.casefold()}"
        _, created = self.upsert_node(
            market_key, "Market", market_name,
            {"locale": locale, "market": market_code, "currency": market_context.currency, "canonical_class": "Market",
             "classification_confidence": 1.0, "classification_reason": "locale_market",
             "classification_version": "v6.19"},
        )
        counts["nodes_created"] += int(created)
        counts["edges_created"] += int(self.upsert_edge(page_key, "AVAILABLE_IN", market_key, canonical_url))

        # Discovery is kept exhaustively, but an href no longer becomes a graph
        # Page node just because it appeared in a menu/card. This is the central
        # v6.16 fix for the tens-of-thousands-of-placeholder-nodes problem.
        for link in page.links:
            target = canonicalize_url(link.url, canonical_url)
            if not target:
                continue
            counts["link_evidence_recorded"] += int(self.record_link_evidence(
                canonical_url,
                target,
                label=link.label,
                relation=link.relation or "LINKS_TO",
                ref=link.ref,
                priority=link.priority,
                resource_kind=link.resource_kind,
            ))

        # Materialize navigation relationships only when both endpoints have
        # actually been fetched and therefore represent validated source nodes.
        counts["edges_created"] += self._materialize_link_edges_for_page(canonical_url)
        return counts

    def ingest_extraction(self, source_url: str, extraction: dict[str, Any], association_url: str = "") -> dict[str, int]:
        source_url = canonicalize_url(source_url) or source_url
        extraction, validation_report = validate_extraction_payload(extraction, source_url)
        self.record_extraction_validation(source_url, validation_report)
        evidence_rows = 0
        for item in extraction.get("unmapped_evidence") or []:
            reason = str(item.get("reason") or item.get("field") or "unmapped") if isinstance(item, dict) else "unmapped"
            evidence_rows += int(self.record_extraction_evidence(source_url, item, evidence_kind="unmapped", reason=reason))
        counts = {
            "nodes_created": 0,
            "edges_created": 0,
            "facts_created": 0,
            "link_evidence_recorded": 0,
            "evidence_rows_created": evidence_rows,
            "validation_entities_rejected": int(validation_report.get("entities_evidence_only", 0) or 0),
            "validation_relations_rejected": int(validation_report.get("relations_rejected", 0) or 0),
        }
        page_key = f"url:{source_url}"
        association_key = f"url:{association_url}" if association_url else ""
        key_map: dict[str, str] = {"page": page_key, "source": page_key}
        product_node_keys: set[str] = set()

        page_data = extraction.get("page") if isinstance(extraction.get("page"), dict) else {}
        if page_data:
            current = self.node_by_key(page_key)
            if current:
                _, _ = self.upsert_node(
                    page_key,
                    canonical_node_type(str(page_data.get("type") or current["node_type"]), context="page"),
                    str(page_data.get("name") or page_data.get("title") or current["name"]),
                    page_data,
                )

        entities = extraction.get("entities") or []
        for index, entity in enumerate(entities):
            if not isinstance(entity, dict):
                continue
            local_key = str(entity.get("key") or f"entity_{index}")
            raw_entity_type = str(entity.get("type") or "Entity")
            entity_type = canonical_node_type(raw_entity_type, context="entity")
            name = str(entity.get("name") or local_key)
            attrs = entity.get("attributes") if isinstance(entity.get("attributes"), dict) else {}
            attrs = dict(attrs)
            if raw_entity_type != entity_type:
                attrs.setdefault("raw_entity_type", raw_entity_type)
            explicit_key = str(entity.get("node_key") or "").strip()
            entity_url = str(entity.get("url") or attrs.get("url") or "").strip()
            if entity_type == "Product":
                node_key, entity_type, name, attrs = _sanitize_product_entity(
                    name=name,
                    attrs=attrs,
                    entity_url=entity_url,
                    explicit_key=explicit_key,
                    source_url=source_url,
                )
                if entity_type == "Product":
                    node_key = self.resolve_product_node_key(node_key, attrs, name)
                else:
                    # A mislabeled media/schema fragment is evidence, not a graph node.
                    self.record_extraction_evidence(
                        source_url,
                        {"entity": entity, "sanitized_type": entity_type, "attributes": attrs},
                        evidence_kind="classified_evidence_only",
                        reason="product_sanitized_out_of_semantic_graph",
                    )
                    counts["evidence_rows_created"] += 1
                    continue
            else:
                node_key = str(attrs.get("semantic_identity_key") or "").strip()
                if not node_key:
                    node_key = semantic_entity_key(entity_type, name, attrs, url=entity_url, source_url=source_url)
                if not node_key:
                    self.record_extraction_evidence(
                        source_url,
                        {"entity": entity, "canonical_type": entity_type},
                        evidence_kind="unclassified_semantic_identity",
                        reason="semantic_identity_unresolved_at_persistence",
                    )
                    counts["evidence_rows_created"] += 1
                    continue
                if explicit_key and explicit_key != node_key:
                    attrs.setdefault("original_extracted_node_key", explicit_key)
            attrs.setdefault("canonical_class", entity_type)
            attrs.setdefault("classification_version", "v6.19")
            key_map[local_key] = node_key
            _, created = self.upsert_node(node_key, entity_type, name, {**attrs, "source_url": source_url})
            if entity_type == "Product":
                product_node_keys.add(node_key)
            counts["nodes_created"] += int(created)
            counts["edges_created"] += int(
                self.upsert_edge(page_key, "MENTIONS", node_key, source_url, {"local_key": local_key})
            )

        endpoints = extraction.get("endpoints") or []
        for index, endpoint in enumerate(endpoints):
            if not isinstance(endpoint, dict) or not endpoint.get("url"):
                continue
            url = canonicalize_url(str(endpoint["url"]), source_url)
            if not url:
                continue
            key = f"url:{url}"
            label = str(endpoint.get("label") or endpoint.get("purpose") or url)
            endpoint_relation = re.sub(
                r"[^A-Z0-9_]+", "_", str(endpoint.get("relation") or "HAS_ENDPOINT").upper()
            ).strip("_") or "HAS_ENDPOINT"
            counts["link_evidence_recorded"] += int(self.record_link_evidence(
                source_url,
                url,
                label=label,
                relation=endpoint_relation,
                ref=str(endpoint.get("ref") or ""),
                priority=int(endpoint.get("priority") or 50),
                resource_kind=str(endpoint.get("resource_kind") or endpoint.get("kind") or "Resource"),
            ))
            # Only create a semantic edge when the endpoint has actually been fetched.
            if self.node_by_key(key):
                counts["edges_created"] += int(self.upsert_edge(page_key, endpoint_relation, key, source_url))
                key_map[str(endpoint.get("key") or f"endpoint_{index}")] = key

        relations = extraction.get("relations") or []
        for relation in relations:
            if not isinstance(relation, dict):
                continue
            source_ref = str(relation.get("source_key") or relation.get("source") or "page")
            target_ref = str(relation.get("target_key") or relation.get("target") or "")
            raw_predicate = re.sub(r"[^A-Z0-9_]+", "_", str(relation.get("predicate") or "RELATED_TO").upper()).strip("_")
            predicate = canonical_relationship_type(raw_predicate)
            source_key = key_map.get(source_ref, source_ref if ":" in source_ref else "")
            target_key = key_map.get(target_ref, target_ref if ":" in target_ref else "")
            if not source_key or not target_key or not self.node_by_key(source_key) or not self.node_by_key(target_key):
                continue
            counts["edges_created"] += int(
                self.upsert_edge(
                    source_key,
                    predicate or "RELATED_TO",
                    target_key,
                    source_url,
                    {**(relation.get("attributes") if isinstance(relation.get("attributes"), dict) else {}),
                     **({"raw_relationship_type": raw_predicate} if raw_predicate != predicate else {})},
                    float(relation.get("confidence") or 0.8),
                )
            )

        facts = extraction.get("facts") or []
        for fact in facts:
            if not isinstance(fact, dict):
                continue
            subject_ref = str(fact.get("subject_key") or fact.get("subject") or "page")
            subject_key = key_map.get(subject_ref, subject_ref if ":" in subject_ref else page_key)
            predicate = re.sub(r"[^A-Z0-9_]+", "_", str(fact.get("predicate") or "HAS_FACT").upper()).strip("_")
            value = fact.get("value")
            if value is None:
                continue
            counts["facts_created"] += int(
                self.add_fact(
                    subject_key,
                    predicate or "HAS_FACT",
                    str(value),
                    source_url,
                    str(fact.get("unit") or ""),
                    fact.get("qualifiers") if isinstance(fact.get("qualifiers"), dict) else {},
                    float(fact.get("confidence") or 0.8),
                    str(fact.get("valid_from") or ""),
                    str(fact.get("valid_to") or ""),
                )
            )
            fact_subject = self.node_by_key(subject_key)
            if fact_subject and fact_subject.get("node_type") == "Product":
                product_node_keys.add(subject_key)

        # Structured helpers are ingested even when the LLM did not emit them as
        # generic entities/facts. Source-scoped keys preserve provenance and avoid
        # merging unrelated reviews/sections with similar text.
        source_token = hashlib.sha256(source_url.encode("utf-8", errors="ignore")).hexdigest()[:16]
        for item_type, items, edge_name in (
            ("UseCase", extraction.get("use_cases") or [], "SUPPORTS_USE_CASE"),
            ("Offer", extraction.get("offers") or [], "HAS_OFFER"),
        ):
            for index, item in enumerate(items):
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or item.get("title") or f"{item_type} {index+1}")
                suffix = _slug(str(item.get("coupon_code") or name))
                key = f"{_slug(item_type)}:{source_token}:{suffix}"
                _, created = self.upsert_node(key, item_type, name, {**item, "source_url": source_url})
                counts["nodes_created"] += int(created)
                counts["edges_created"] += int(self.upsert_edge(page_key, edge_name, key, source_url))
                if item_type == "Offer":
                    product_ref = str(item.get("product_key") or "")
                    product_key = key_map.get(product_ref, str(item.get("product_node_key") or ""))
                    if product_key and self.node_by_key(product_key):
                        product_node_keys.add(product_key)
                        counts["edges_created"] += int(
                            self.upsert_edge(product_key, "HAS_OFFER", key, source_url, {"volatile": True})
                        )
                        for predicate, value, unit in (
                            (price_predicate(str(item.get("currency") or infer_market_context(source_url, evidence_text=str(item.get("price") or "")).currency)), item.get("price"), str(item.get("currency") or infer_market_context(source_url, evidence_text=str(item.get("price") or "")).currency)),
                            ("LIST_PRICE", item.get("list_price"), str(item.get("currency") or infer_market_context(source_url).currency)),
                            ("PRICE_EX_VAT", item.get("price_ex_vat"), str(item.get("currency") or infer_market_context(source_url).currency)),
                            ("DISCOUNT", item.get("discount"), str(item.get("currency") or infer_market_context(source_url).currency)),
                            ("DISCOUNT_PERCENT", item.get("discount_percent"), "%"),
                            ("PROMOTION", item.get("promotion"), ""),
                            ("FINANCING", item.get("financing"), ""),
                            ("REWARD", item.get("rewards"), str(item.get("currency") or infer_market_context(source_url).currency)),
                        ):
                            if value not in (None, "", [], {}):
                                counts["facts_created"] += int(
                                    self.add_fact(product_key, predicate, str(value), source_url, unit, {"volatile": True, "offer_node": key})
                                )
                for predicate, value in (
                    ("COUPON_CODE", item.get("coupon_code")),
                    ("VALID_FROM", item.get("valid_from")),
                    ("VALID_TO", item.get("valid_to")),
                    ("ELIGIBILITY", item.get("eligibility")),
                    ("BENEFIT", item.get("benefit")),
                ):
                    if value not in (None, "", [], {}):
                        counts["facts_created"] += int(self.add_fact(key, predicate, str(value), source_url))

        for index, review in enumerate(extraction.get("reviews") or []):
            if not isinstance(review, dict):
                continue
            body = str(review.get("body") or "").strip()
            title = str(review.get("title") or f"Review {index+1}").strip()
            review_id = str(review.get("review_id") or "").strip() or hashlib.sha256(
                f"{source_url}|{title}|{body}|{review.get('rating','')}".encode("utf-8", errors="ignore")
            ).hexdigest()[:32]
            key = f"review:{review_id}"
            attrs = {**review, "source_url": source_url, "evidence_class": "customer_opinion"}
            _, created = self.upsert_node(key, "Review", title or f"Review {index+1}", attrs)
            counts["nodes_created"] += int(created)
            counts["edges_created"] += int(
                self.upsert_edge(page_key, "HAS_REVIEW", key, source_url, {"opinion_not_verified_fact": True})
            )
            if association_key and association_key != page_key and self.node_by_key(association_key):
                counts["edges_created"] += int(
                    self.upsert_edge(
                        association_key, "HAS_REVIEW", key, source_url,
                        {"opinion_not_verified_fact": True, "acquired_via_public_resource": source_url},
                    )
                )
            for predicate, value, unit in (
                ("RATING", review.get("rating"), "stars_out_of_5"),
                ("REVIEW_DATE", review.get("date"), ""),
                ("RECOMMENDS", review.get("recommend"), ""),
                ("HELPFUL_COUNT", review.get("helpful_count"), "count"),
                ("REVIEW_BODY", body, ""),
            ):
                if value not in (None, "", [], {}):
                    counts["facts_created"] += int(
                        self.add_fact(key, predicate, str(value), source_url, unit, {"customer_opinion": True})
                    )

        # Long document sections and generic recommendations are excellent retrieval
        # evidence but poor graph entities: one large manual can contain hundreds of
        # headings/recommendations. Keep them losslessly as page facts/evidence instead
        # of creating a separate node for every section/sentence.
        for index, item in enumerate(extraction.get("document_sections") or []):
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or item.get("name") or f"Section {index+1}").strip()
            detail = str(item.get("summary") or item.get("description") or item.get("text") or "").strip()
            payload_text = title if not detail else f"{title}: {detail}"
            counts["facts_created"] += int(self.add_fact(
                page_key, "SECTION_SUMMARY", payload_text, source_url,
                qualifiers={"section_index": index, "compact_semantic_graph": True},
            ))
            counts["evidence_rows_created"] += int(self.record_extraction_evidence(
                source_url, item, evidence_kind="document_section", reason="stored_as_fact_not_node"
            ))

        structured_groups = (
            ("Requirement", extraction.get("requirements") or [], "HAS_REQUIREMENT", "name", "description"),
            ("Compatibility", extraction.get("compatibility") or [], "COMPATIBLE_WITH", "compatible_with", "conditions"),
            ("FAQ", extraction.get("faqs") or [], "HAS_FAQ", "question", "answer"),
        )
        for node_type, items, edge_name, name_field, detail_field in structured_groups:
            for index, item in enumerate(items):
                if not isinstance(item, dict):
                    continue
                name = str(item.get(name_field) or item.get("name") or f"{node_type} {index+1}").strip()
                detail = str(item.get(detail_field) or "").strip()
                if not name and not detail:
                    continue
                digest = hashlib.sha256(
                    f"{source_url}|{node_type}|{name}|{detail}".encode("utf-8", errors="ignore")
                ).hexdigest()[:24]
                key = f"{_slug(node_type)}:{source_token}:{digest}"
                _, created = self.upsert_node(key, node_type, name or f"{node_type} {index+1}", {**item, "source_url": source_url})
                counts["nodes_created"] += int(created)
                counts["edges_created"] += int(self.upsert_edge(page_key, edge_name, key, source_url))
                if detail:
                    counts["facts_created"] += int(self.add_fact(key, "DETAIL", detail, source_url))

        for index, item in enumerate(extraction.get("recommendations") or []):
            if not isinstance(item, dict):
                item = {"recommendation": str(item)}
            recommendation = str(item.get("recommendation") or item.get("name") or item.get("title") or "").strip()
            reason = str(item.get("reason") or item.get("description") or "").strip()
            if recommendation:
                value = recommendation if not reason else f"{recommendation} — {reason}"
                counts["facts_created"] += int(self.add_fact(
                    page_key, "RECOMMENDATION", value, source_url,
                    qualifiers={"recommendation_index": index, "source_kind": "extracted_evidence"},
                ))
            counts["evidence_rows_created"] += int(self.record_extraction_evidence(
                source_url, item, evidence_kind="recommendation", reason="stored_as_fact_not_concept_node"
            ))

        # Persist one coherent observation per product card/detail capture.
        # This provides auditable current-price/spec snapshots and enables future
        # price-history analysis without losing older values.
        for record in extraction.get("product_records") or []:
            if not isinstance(record, dict):
                continue
            fields = record.get("attributes") if isinstance(record.get("attributes"), dict) else {}
            node_key = str(record.get("node_key") or "").strip()
            if node_key and not self.node_by_key(node_key):
                node_key = self.resolve_product_node_key(node_key, fields, str(record.get("name") or ""))
            if not node_key or not self.node_by_key(node_key):
                continue
            product_node_keys.add(node_key)
            self.record_product_observation(node_key, source_url, fields)

        # Keep Product attributes synchronized with graph facts so Streamlit,
        # GraphML and Neo4j consumers see prices/specs directly on each product.
        for node_key in sorted(product_node_keys):
            self.refresh_product_projection(node_key)
            product = self.node_by_key(node_key)
            attrs = dict((product or {}).get("attributes") or {})
            brand = str(attrs.get("brand") or "").strip()
            category = str(attrs.get("product_category") or attrs.get("category") or "").strip()
            family = str(attrs.get("family") or attrs.get("product_family") or "").strip()
            for semantic_type, value, rel in (
                ("Brand", brand, "MADE_BY"),
                ("Category", category, "IN_CATEGORY"),
                ("ProductFamily", family, "IN_FAMILY"),
            ):
                if not value:
                    continue
                semantic_key = f"{_slug(semantic_type)}:{_slug(value)}"
                _, created = self.upsert_node(semantic_key, semantic_type, value, {"source_url": source_url})
                counts["nodes_created"] += int(created)
                counts["edges_created"] += int(self.upsert_edge(node_key, rel, semantic_key, source_url))

        summary = str(extraction.get("document_summary") or page_data.get("summary") or "").strip()
        if summary:
            counts["facts_created"] += int(
                self.add_fact(page_key, "SUMMARY", summary, source_url, qualifiers={
                    "hierarchical": bool(extraction.get("document_summary")),
                    "compact_semantic_graph": True,
                })
            )

        return counts

    def review_count_for_page(self, page_url: str) -> int:
        """Count distinct ProductReview nodes associated with a page across all evidence sources."""
        page = self.node_by_key(f"url:{page_url}")
        if not page:
            return 0
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT COUNT(DISTINCT e.target_id) AS value
                FROM edges e
                JOIN nodes n ON n.id=e.target_id
                WHERE e.source_id=? AND e.predicate='HAS_REVIEW' AND n.node_type IN ('Review','ProductReview')
                """,
                (page["id"],),
            ).fetchone()
            return int(row["value"] or 0) if row else 0

    def migrate_historical_control_progress(self) -> dict[str, int]:
        """Seed v6 one-shot memory from successful v5 AgentQ trajectories.

        v5 stored durable action trajectories but did not use them as a hard
        completed-control guard on resumed runs. Reusing the legacy
        ``control_key`` is safe because the v6 no-context identity retains the
        same role|label|occurrence form. Context-aware identities remain more
        specific and are learned natively by v6.
        """
        terminal = ("DIRECT_ENDPOINT", "NAVIGATED", "SUCCESS", "EXPANDED", "RESOURCE_DISCOVERED")
        placeholders = ",".join("?" for _ in terminal)
        migrated = 0
        with self.connect() as conn:
            exists = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='action_trajectories'"
            ).fetchone()
            if not exists:
                return {"historical_controls_migrated": 0}
            rows = conn.execute(
                f"""
                SELECT source_url,control_key,label,role,status,reward,outcome_json,observed_at
                FROM action_trajectories
                WHERE success=1 AND status IN ({placeholders}) AND control_key<>''
                ORDER BY observed_at DESC
                """,
                terminal,
            ).fetchall()
            seen: set[tuple[str, str]] = set()
            for row in rows:
                identity = (str(row["source_url"]), str(row["control_key"]))
                if identity in seen:
                    continue
                seen.add(identity)
                try:
                    reward = float(row["reward"] or 0.0)
                except Exception:
                    reward = 0.0
                detail = ""
                try:
                    outcome = _loads(row["outcome_json"], {})
                    raw_detail = outcome.get("detail", "") if isinstance(outcome, dict) else ""
                    detail = _json(raw_detail) if isinstance(raw_detail, (dict, list)) else str(raw_detail or "")
                except Exception:
                    detail = ""
                cursor = conn.execute(
                    """
                    INSERT INTO control_progress(source_url,control_key,label,context,action_kind,status,information_gain,detail,observed_at)
                    VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(source_url,control_key) DO NOTHING
                    """,
                    (row["source_url"], row["control_key"], row["label"], "", str(row["role"] or ""), row["status"], reward, detail[:2000], row["observed_at"] or _utc_now()),
                )
                migrated += max(0, int(cursor.rowcount or 0))
        return {"historical_controls_migrated": migrated}

    def recent_terminal_dynamic_control_keys(self, source_url: str, max_age_hours: int = 72) -> set[str]:
        """Return repeatable controls already exhausted in a recent run."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=max(1, int(max_age_hours)))).isoformat(timespec="seconds")
        terminal = ("STABLE_EXHAUSTED", "CYCLE_EXHAUSTED", "CONTROL_ABSENT", "DISABLED", "NAVIGATED", "DIRECT_ENDPOINT")
        placeholders = ",".join("?" for _ in terminal)
        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT control_key FROM dynamic_control_progress WHERE source_url=? AND observed_at>=? AND status IN ({placeholders})",
                (source_url, cutoff, *terminal),
            ).fetchall()
            return {str(row["control_key"]) for row in rows}

    def upsert_control_progress(
        self, source_url: str, control_key: str, *, label: str = "", context: str = "",
        action_kind: str = "", status: str = "", information_gain: float = 0.0, detail: str = "",
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO control_progress(source_url,control_key,label,context,action_kind,status,information_gain,detail,observed_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_url,control_key) DO UPDATE SET
                    label=excluded.label, context=excluded.context, action_kind=excluded.action_kind,
                    status=excluded.status, information_gain=MAX(control_progress.information_gain, excluded.information_gain),
                    detail=excluded.detail, observed_at=excluded.observed_at
                """,
                (source_url, control_key, label, context, action_kind, status, float(information_gain), detail[:2000], _utc_now()),
            )

    def recent_completed_control_keys(self, source_url: str, max_age_hours: int = 72) -> set[str]:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=max(1, int(max_age_hours)))).isoformat(timespec="seconds")
        terminal = ("DIRECT_ENDPOINT", "NAVIGATED", "SUCCESS", "EXPANDED", "RESOURCE_DISCOVERED", "STABLE_EXHAUSTED", "CYCLE_EXHAUSTED", "CONTROL_ABSENT")
        placeholders = ",".join("?" for _ in terminal)
        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT control_key FROM control_progress WHERE source_url=? AND observed_at>=? AND status IN ({placeholders})",
                (source_url, cutoff, *terminal),
            ).fetchall()
            return {str(row["control_key"]) for row in rows}

    def upsert_dynamic_control(self, source_url: str, state: dict[str, Any]) -> None:
        """Persist progress for repeatable controls such as Show More Reviews.

        The row is updated after every state transition, making frontier completion
        auditable and allowing resumed runs to distinguish fully exhausted widgets
        from controls that stopped because of an external failure.
        """
        control_key = str(state.get("key") or f"{state.get('role','')}|{state.get('label','')}").strip()
        if not source_url or not control_key:
            return
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO dynamic_control_progress(
                    source_url,control_key,label,role,status,clicks,progress_events,
                    no_progress_rounds,state_count,last_signature,last_detail,metadata_json,observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_url,control_key) DO UPDATE SET
                    label=excluded.label,role=excluded.role,status=excluded.status,
                    clicks=excluded.clicks,progress_events=excluded.progress_events,
                    no_progress_rounds=excluded.no_progress_rounds,state_count=excluded.state_count,
                    last_signature=excluded.last_signature,last_detail=excluded.last_detail,
                    metadata_json=excluded.metadata_json,observed_at=excluded.observed_at
                """,
                (
                    source_url,
                    control_key,
                    str(state.get("label") or ""),
                    str(state.get("role") or ""),
                    str(state.get("status") or "PENDING"),
                    int(state.get("clicks") or 0),
                    int(state.get("progress_events") or 0),
                    int(state.get("no_progress_rounds") or 0),
                    int(state.get("state_count") or 0),
                    str(state.get("last_signature") or ""),
                    str(state.get("last_detail") or "")[:4000],
                    _json(state),
                    _utc_now(),
                ),
            )

    def dynamic_control_counts(self) -> dict[str, int]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT status,COUNT(*) AS n FROM dynamic_control_progress GROUP BY status"
            ).fetchall()
            return {str(row["status"]): int(row["n"]) for row in rows}

    def record_web_state(self, state: dict[str, Any]) -> None:
        source_url = str(state.get("source_url") or "")
        signature = str(state.get("state_signature") or "")
        if not source_url or not signature:
            return
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO web_state_observations(
                    source_url,page_type,state_signature,visible_text_hash,control_count,link_count,
                    missing_topics_json,covered_topics_json,state_embedding_json,metadata_json,observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_url,state_signature) DO UPDATE SET
                    page_type=excluded.page_type,visible_text_hash=excluded.visible_text_hash,
                    control_count=excluded.control_count,link_count=excluded.link_count,
                    missing_topics_json=excluded.missing_topics_json,
                    covered_topics_json=excluded.covered_topics_json,
                    state_embedding_json=excluded.state_embedding_json,
                    metadata_json=excluded.metadata_json,observed_at=excluded.observed_at
                """,
                (
                    source_url,
                    str(state.get("page_type") or "WebPage"),
                    signature,
                    str(state.get("visible_text_hash") or ""),
                    int(state.get("control_count") or 0),
                    int(state.get("link_count") or 0),
                    _json(state.get("missing_topics") or []),
                    _json(state.get("covered_topics") or []),
                    _json(state.get("state_embedding") or []),
                    _json(state.get("metadata") or {}),
                    _utc_now(),
                ),
            )

    def get_action_policy(self, page_type: str, control_key: str) -> dict[str, Any]:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM action_policy_memory WHERE page_type=? AND control_key=?",
                (page_type or "WebPage", control_key),
            ).fetchone()
            return {**dict(row), "metadata": _loads(row["metadata_json"], {})} if row else {}

    def action_policies_for_page_type(self, page_type: str, limit: int = 500) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM action_policy_memory WHERE page_type=? ORDER BY visits DESC, average_reward DESC LIMIT ?",
                (page_type or "WebPage", max(1, int(limit))),
            ).fetchall()
            return [{**dict(row), "metadata": _loads(row["metadata_json"], {})} for row in rows]

    def record_action_decision(
        self,
        *,
        source_url: str,
        page_type: str,
        state_signature: str,
        selection: dict[str, Any],
    ) -> None:
        selected = selection.get("selected") if isinstance(selection.get("selected"), dict) else {}
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO action_decisions(source_url,page_type,state_signature,selected_key,selection_json,observed_at)
                VALUES(?,?,?,?,?,?)
                """,
                (
                    source_url,
                    page_type or "WebPage",
                    state_signature,
                    str(selected.get("stable_key") or selected.get("control_key") or ""),
                    _json(selection),
                    _utc_now(),
                ),
            )

    def record_action_outcome(
        self,
        *,
        run_id: str,
        source_url: str,
        page_type: str,
        state_signature: str,
        action: dict[str, Any],
        outcome: dict[str, Any],
    ) -> None:
        control_key = str(action.get("control_key") or "")
        if not control_key:
            return
        reward = float(outcome.get("reward") or 0.0)
        success = 1 if bool(outcome.get("success")) else 0
        status = str(outcome.get("status") or "")
        now = _utc_now()
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO action_trajectories(
                    run_id,source_url,page_type,state_signature,control_key,stable_key,label,role,
                    occurrence,status,reward,success,action_json,outcome_json,observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    run_id,
                    source_url,
                    page_type or "WebPage",
                    state_signature,
                    control_key,
                    str(action.get("stable_key") or ""),
                    str(action.get("label") or ""),
                    str(action.get("role") or ""),
                    int(action.get("occurrence") or 0),
                    status,
                    reward,
                    success,
                    _json(action),
                    _json(outcome),
                    now,
                ),
            )
            row = conn.execute(
                "SELECT visits,successes,failures,total_reward FROM action_policy_memory WHERE page_type=? AND control_key=?",
                (page_type or "WebPage", control_key),
            ).fetchone()
            visits = int(row["visits"] if row else 0) + 1
            successes = int(row["successes"] if row else 0) + success
            failures = int(row["failures"] if row else 0) + (0 if success else 1)
            total_reward = float(row["total_reward"] if row else 0.0) + reward
            average_reward = total_reward / visits
            conn.execute(
                """
                INSERT INTO action_policy_memory(
                    page_type,control_key,visits,successes,failures,total_reward,average_reward,
                    last_reward,last_status,last_source_url,metadata_json,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(page_type,control_key) DO UPDATE SET
                    visits=excluded.visits,successes=excluded.successes,failures=excluded.failures,
                    total_reward=excluded.total_reward,average_reward=excluded.average_reward,
                    last_reward=excluded.last_reward,last_status=excluded.last_status,
                    last_source_url=excluded.last_source_url,metadata_json=excluded.metadata_json,
                    updated_at=excluded.updated_at
                """,
                (
                    page_type or "WebPage",
                    control_key,
                    visits,
                    successes,
                    failures,
                    total_reward,
                    average_reward,
                    reward,
                    status,
                    source_url,
                    _json({"last_action": action, "last_outcome": outcome}),
                    now,
                ),
            )

    def recent_action_trajectories(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM action_trajectories ORDER BY id DESC LIMIT ?",
                (max(1, int(limit)),),
            ).fetchall()
            return [
                {**dict(row), "action": _loads(row["action_json"], {}), "outcome": _loads(row["outcome_json"], {})}
                for row in rows
            ]

    def record_interaction(
        self,
        source_url: str,
        label: str,
        role: str,
        action_kind: str,
        status: str,
        before_hash: str,
        after_hash: str,
        detail: str = "",
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO interactions(source_url,label,role,action_kind,status,before_hash,after_hash,detail,observed_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                """,
                (source_url, label, role, action_kind, status, before_hash, after_hash, detail[:4000], _utc_now()),
            )

    def record_self_heal_event(
        self,
        *,
        run_id: str,
        source_url: str,
        stage: str,
        failure_class: str,
        action: str,
        status: str,
        attempt: int,
        before_hash: str = "",
        after_hash: str = "",
        detail: str = "",
        decision: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO self_heal_events(
                    run_id,source_url,stage,failure_class,action,status,attempt,
                    before_hash,after_hash,detail,decision_json,result_json,observed_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    run_id,
                    source_url,
                    stage,
                    failure_class,
                    action,
                    status,
                    int(attempt),
                    before_hash,
                    after_hash,
                    detail[:4000],
                    _json(decision or {}),
                    _json(result or {}),
                    _utc_now(),
                ),
            )

    def recent_self_heal_events(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM self_heal_events ORDER BY id DESC LIMIT ?", (max(1, int(limit)),)
            ).fetchall()
            return [
                {
                    **dict(row),
                    "decision": _loads(row["decision_json"], {}),
                    "result": _loads(row["result_json"], {}),
                }
                for row in rows
            ]

    def semantic_quality_report(self) -> dict[str, Any]:
        """Return v6.19 graph-readiness, classification, market and deduplication metrics."""
        with self.connect() as conn:
            sources = int(conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0])
            nodes = int(conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0])
            edges = int(conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0])
            facts = int(conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0])
            link_evidence = int(conn.execute("SELECT COUNT(*) FROM link_evidence").fetchone()[0])
            extraction_evidence = int(conn.execute("SELECT COUNT(*) FROM extraction_evidence").fetchone()[0])
            validations = int(conn.execute("SELECT COUNT(*) FROM extraction_validation").fetchone()[0])
            placeholder_nodes = int(conn.execute(
                """
                SELECT COUNT(*) FROM nodes n
                WHERE n.node_key LIKE 'url:%'
                  AND NOT EXISTS (
                    SELECT 1 FROM sources s
                    WHERE ('url:' || s.canonical_url)=n.node_key OR ('url:' || s.url)=n.node_key
                  )
                  AND n.node_type IN ('Page','SupportArticle','Document')
                """
            ).fetchone()[0])
            evidence_only_nodes = int(conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE node_type='Concept'"
            ).fetchone()[0])
            visual_asset_nodes = int(conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE node_type='VisualAsset'"
            ).fetchone()[0])
            summary_section_nodes = int(conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE node_type='Section' AND node_key LIKE 'document-summary:%'"
            ).fetchone()[0])
            unclassified_nodes = int(conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE node_type NOT IN (%s)" % ",".join("?" for _ in GRAPH_NODE_TYPES),
                tuple(sorted(GRAPH_NODE_TYPES)),
            ).fetchone()[0])
            classified_nodes = int(conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE node_type IN (%s)" % ",".join("?" for _ in GRAPH_NODE_TYPES),
                tuple(sorted(GRAPH_NODE_TYPES)),
            ).fetchone()[0])
            duplicate_content_groups = int(conn.execute(
                """
                SELECT COUNT(*) FROM (
                    SELECT content_hash FROM sources
                    WHERE content_hash<>''
                    GROUP BY content_hash HAVING COUNT(*)>1
                )
                """
            ).fetchone()[0])
            product_rows = conn.execute(
                "SELECT node_key,name,attributes_json FROM nodes WHERE node_type='Product'"
            ).fetchall()
        identity_seen: dict[tuple[str, str], str] = {}
        duplicate_product_identity_pairs = 0
        currency_market_mismatches = 0
        products_with_price_without_currency = 0
        for row in product_rows:
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            price_value = str(attrs.get("price") or attrs.get("current_price") or "").strip()
            currency_value = normalize_currency(attrs.get("currency"))
            identity_url = str(attrs.get("product_url") or attrs.get("url") or attrs.get("source_url") or "")
            expected_currency = infer_market_context(identity_url, evidence_text=price_value).currency
            if price_value and not currency_value:
                products_with_price_without_currency += 1
            elif price_value and expected_currency and currency_value and expected_currency != currency_value:
                currency_market_mismatches += 1
            identifiers = []
            for kind, value in (
                ("order", attrs.get("order_code") or attrs.get("orderCode") or attrs.get("sku")),
                ("part", attrs.get("part_number") or attrs.get("partNumber") or attrs.get("mpn")),
                ("url", canonicalize_url(str(attrs.get("product_url") or attrs.get("url") or "")) if (attrs.get("product_url") or attrs.get("url")) else ""),
            ):
                token = self._identity_token(value) if kind != "url" else str(value or "").casefold()
                if token:
                    identifiers.append((kind, token))
            # Model is intentionally not counted as a duplicate identity when any
            # stronger identifier is present: Dell can sell several configurations
            # under one model/chassis name. Only identity-poor products fall back to
            # brand+model matching.
            if not identifiers and attrs.get("model") and attrs.get("brand"):
                model_token = self._identity_token(f"{attrs.get('brand')}|{attrs.get('model')}")
                if model_token:
                    identifiers.append(("model_fallback", model_token))
            for identifier in identifiers:
                if identifier in identity_seen and identity_seen[identifier] != str(row["node_key"]):
                    duplicate_product_identity_pairs += 1
                else:
                    identity_seen[identifier] = str(row["node_key"])
        # Check semantic identity convergence for every non-Product graph node.
        semantic_identity_seen: dict[str, str] = {}
        duplicate_semantic_identity_pairs = 0
        with self.connect() as conn:
            semantic_rows = conn.execute(
                "SELECT node_key,node_type,name,attributes_json FROM nodes WHERE node_type<>'Product'"
            ).fetchall()
        for row in semantic_rows:
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            url = str(attrs.get("url") or attrs.get("canonical_url") or "")
            if str(row["node_key"]).startswith("url:"):
                url = str(row["node_key"])[4:]
            identity = semantic_entity_key(str(row["node_type"]), str(row["name"]), attrs, url=url, source_url=str(attrs.get("source_url") or ""))
            if not identity:
                continue
            existing_key = semantic_identity_seen.get(identity)
            if existing_key and existing_key != str(row["node_key"]):
                duplicate_semantic_identity_pairs += 1
            else:
                semantic_identity_seen[identity] = str(row["node_key"])
        classification_coverage = round(classified_nodes / max(1, nodes), 6)

        return {
            "ontology_version": "v6.19",
            "sources": sources,
            "semantic_nodes": nodes,
            "semantic_edges": edges,
            "facts": facts,
            "link_evidence_rows": link_evidence,
            "extraction_evidence_rows": extraction_evidence,
            "validated_sources": validations,
            "unfetched_placeholder_nodes": placeholder_nodes,
            "evidence_only_graph_nodes": evidence_only_nodes,
            "visual_asset_nodes": visual_asset_nodes,
            "unclassified_semantic_nodes": unclassified_nodes,
            "classified_semantic_nodes": classified_nodes,
            "node_classification_coverage": classification_coverage,
            "duplicate_semantic_identity_pairs": duplicate_semantic_identity_pairs,
            "legacy_summary_section_nodes": summary_section_nodes,
            "duplicate_content_groups": duplicate_content_groups,
            "duplicate_product_identity_pairs": duplicate_product_identity_pairs,
            "currency_market_mismatches": currency_market_mismatches,
            "products_with_price_without_currency": products_with_price_without_currency,
            "graph_node_to_source_ratio": round(nodes / max(1, sources), 4),
            "clean_for_semantic_sync": bool(
                placeholder_nodes == 0
                and evidence_only_nodes == 0
                and summary_section_nodes == 0
                and duplicate_product_identity_pairs == 0
                and duplicate_semantic_identity_pairs == 0
                and unclassified_nodes == 0
                and currency_market_mismatches == 0
                and products_with_price_without_currency == 0
                and classification_coverage == 1.0
            ),
        }

    def canonical_schema_report(self) -> dict[str, Any]:
        """Audit raw crawler schema against the bounded v6.19 ontology.

        This does not discard raw evidence. It reports how many historical types would
        collapse into the canonical graph and highlights unresolved/quarantined nodes.
        """
        with self.connect() as conn:
            node_rows = conn.execute("SELECT node_type,name,attributes_json FROM nodes").fetchall()
            edge_rows = conn.execute("SELECT predicate FROM edges").fetchall()
        raw_node_types = Counter(str(row["node_type"] or "Unknown") for row in node_rows)
        canonical_types: Counter[str] = Counter()
        unresolved = 0
        quarantined = 0
        for row in node_rows:
            attrs = _loads(str(row["attributes_json"] or "{}"), {})
            raw_type = str(row["node_type"] or "Unknown")
            context = "page" if any(attrs.get(k) for k in ("content_hash", "page_type", "discovered_from")) else "entity"
            canonical_types[canonical_node_type(raw_type, context=context)] += 1
            unresolved += int(bool(attrs.get("unresolved_reference")))
            quarantined += int(bool(attrs.get("quarantined_from_product") or attrs.get("graph_quarantined")))
        raw_rel_types = Counter(str(row["predicate"] or "RELATED_TO") for row in edge_rows)
        canonical_rel_types: Counter[str] = Counter()
        for key, count in raw_rel_types.items():
            canonical_rel_types[canonical_relationship_type(key)] += int(count)
        return {
            "ontology_version": "v6.19",
            "raw_node_type_count": len(raw_node_types),
            "canonical_node_type_count": len(canonical_types),
            "raw_relationship_type_count": len(raw_rel_types),
            "canonical_relationship_type_count": len(canonical_rel_types),
            "unresolved_placeholder_nodes": unresolved,
            "quarantined_nodes": quarantined,
            "raw_node_types": dict(raw_node_types.most_common()),
            "canonical_node_types": dict(canonical_types.most_common()),
            "raw_relationship_types": dict(raw_rel_types.most_common()),
            "canonical_relationship_types": dict(canonical_rel_types.most_common()),
        }

    def stats(self) -> dict[str, Any]:
        with self.connect() as conn:
            result = {
                "database": str(self.db_path),
                "fts_available": self._fts_available,
                "sources": int(conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0]),
                "nodes": int(conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]),
                "edges": int(conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]),
                "facts": int(conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0]),
                "chunks": int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]),
                "interactions": int(conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0]),
                "self_heal_events": int(conn.execute("SELECT COUNT(*) FROM self_heal_events").fetchone()[0]),
                "dynamic_controls": int(conn.execute("SELECT COUNT(*) FROM dynamic_control_progress").fetchone()[0]),
                "one_shot_control_progress": int(conn.execute("SELECT COUNT(*) FROM control_progress").fetchone()[0]),
                "dynamic_control_statuses": self.dynamic_control_counts(),
                "web_state_observations": int(conn.execute("SELECT COUNT(*) FROM web_state_observations").fetchone()[0]),
                "action_decisions": int(conn.execute("SELECT COUNT(*) FROM action_decisions").fetchone()[0]),
                "action_trajectories": int(conn.execute("SELECT COUNT(*) FROM action_trajectories").fetchone()[0]),
                "action_policy_entries": int(conn.execute("SELECT COUNT(*) FROM action_policy_memory").fetchone()[0]),
                "queue": self.queue_counts(),
                "queue_lanes": self.queue_lane_counts(),
            }
            try:
                product_row = conn.execute(
                    """
                    SELECT COUNT(*) AS products,
                           SUM(CASE WHEN price IS NOT NULL AND TRIM(CAST(price AS TEXT))<>'' THEN 1 ELSE 0 END) AS with_price,
                           SUM(CASE WHEN processor IS NOT NULL OR graphics IS NOT NULL OR memory IS NOT NULL OR storage IS NOT NULL OR display IS NOT NULL THEN 1 ELSE 0 END) AS with_specs,
                           SUM(CASE WHEN completeness_score>=0.85 THEN 1 ELSE 0 END) AS complete
                    FROM product_catalog_view
                    """
                ).fetchone()
                result["normalized_products"] = int(product_row["products"] or 0)
                result["normalized_products_with_price"] = int(product_row["with_price"] or 0)
                result["normalized_products_with_specs"] = int(product_row["with_specs"] or 0)
                result["normalized_products_complete"] = int(product_row["complete"] or 0)
            except sqlite3.OperationalError:
                pass
            types = conn.execute(
                "SELECT node_type, COUNT(*) n FROM nodes GROUP BY node_type ORDER BY n DESC LIMIT 30"
            ).fetchall()
            result["node_types"] = {row["node_type"]: int(row["n"]) for row in types}
            return result

    @staticmethod
    def _fts_query(text: str) -> str:
        tokens = re.findall(r"[A-Za-z0-9][A-Za-z0-9+._-]{1,}", text or "")
        tokens = [t for t in tokens if len(t) > 1][:18]
        return " OR ".join(f'"{t.replace(chr(34), "")}"' for t in tokens)

    def search(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        with self.connect() as conn:
            if self._fts_available:
                q = self._fts_query(query)
                if q:
                    try:
                        rows = conn.execute(
                            """
                            SELECT source_url, heading, text, bm25(chunks_fts) AS score
                            FROM chunks_fts WHERE chunks_fts MATCH ?
                            ORDER BY score LIMIT ?
                            """,
                            (q, limit),
                        ).fetchall()
                        for row in rows:
                            source = conn.execute(
                                "SELECT title,page_type,fetched_at FROM sources WHERE url=?", (row["source_url"],)
                            ).fetchone()
                            results.append(
                                {
                                    "kind": "chunk",
                                    "source_url": row["source_url"],
                                    "title": source["title"] if source else row["source_url"],
                                    "page_type": source["page_type"] if source else "",
                                    "heading": row["heading"],
                                    "text": row["text"],
                                    "score": float(row["score"]),
                                    "fetched_at": source["fetched_at"] if source else "",
                                }
                            )
                    except sqlite3.OperationalError:
                        pass
            tokens = [t.lower() for t in re.findall(r"[A-Za-z0-9][A-Za-z0-9+._-]*", query or "") if len(t) > 1][:8]
            if not results and tokens:
                # OR-token fallback is intentionally recall-oriented. The old
                # single pattern (e.g. %I%need%an%AI%...) required every word in
                # order and missed relevant evidence when FTS5 was unavailable.
                chunk_clauses: list[str] = []
                chunk_params: list[Any] = []
                for token in tokens:
                    pattern = f"%{token}%"
                    chunk_clauses.append(
                        "(LOWER(c.text) LIKE ? OR LOWER(c.heading) LIKE ? OR LOWER(s.title) LIKE ?)"
                    )
                    chunk_params.extend([pattern, pattern, pattern])
                rows = conn.execute(
                    f"""
                    SELECT c.source_url,c.heading,c.text,s.title,s.page_type,s.fetched_at
                    FROM chunks c JOIN sources s ON s.url=c.source_url
                    WHERE {' OR '.join(chunk_clauses)}
                    LIMIT ?
                    """,
                    (*chunk_params, limit),
                ).fetchall()
                for row in rows:
                    results.append(
                        {
                            "kind": "chunk",
                            "source_url": row["source_url"],
                            "title": row["title"],
                            "page_type": row["page_type"],
                            "heading": row["heading"],
                            "text": row["text"],
                            "score": 0.0,
                            "fetched_at": row["fetched_at"],
                        }
                    )
            # Add matching graph entities for exact product/use-case coverage.
            node_rows: list[sqlite3.Row] = []
            if tokens:
                node_clauses: list[str] = []
                node_params: list[Any] = []
                for token in tokens:
                    pattern = f"%{token}%"
                    node_clauses.append("(LOWER(name) LIKE ? OR LOWER(attributes_json) LIKE ?)")
                    node_params.extend([pattern, pattern])
                node_rows = conn.execute(
                    f"SELECT * FROM nodes WHERE {' OR '.join(node_clauses)} "
                    "ORDER BY last_seen DESC LIMIT ?",
                    (*node_params, max(5, limit // 2)),
                ).fetchall()
            for row in node_rows:
                node = self._node_row(row)
                results.append({"kind": "node", **node})
        return results[: limit + max(5, limit // 2)]

    def graph_neighborhood(self, node_keys: Iterable[str], limit: int = 80) -> list[dict[str, Any]]:
        keys = [key for key in node_keys if key]
        if not keys:
            return []
        placeholders = ",".join("?" for _ in keys)
        with self.connect() as conn:
            rows = conn.execute(
                f"""
                SELECT s.node_key source_key,s.node_type source_type,s.name source_name,
                       e.predicate,e.attributes_json,e.source_url,e.confidence,
                       t.node_key target_key,t.node_type target_type,t.name target_name,t.attributes_json target_attributes
                FROM edges e
                JOIN nodes s ON s.id=e.source_id
                JOIN nodes t ON t.id=e.target_id
                WHERE s.node_key IN ({placeholders}) OR t.node_key IN ({placeholders})
                ORDER BY e.last_seen DESC LIMIT ?
                """,
                (*keys, *keys, limit),
            ).fetchall()
            return [
                {
                    "source_key": row["source_key"],
                    "source_type": row["source_type"],
                    "source_name": row["source_name"],
                    "predicate": row["predicate"],
                    "target_key": row["target_key"],
                    "target_type": row["target_type"],
                    "target_name": row["target_name"],
                    "target_attributes": _loads(row["target_attributes"], {}),
                    "attributes": _loads(row["attributes_json"], {}),
                    "source_url": row["source_url"],
                    "confidence": float(row["confidence"]),
                }
                for row in rows
            ]

    def facts_for_nodes(self, node_keys: Iterable[str], limit: int = 120) -> list[dict[str, Any]]:
        keys = [key for key in node_keys if key]
        if not keys:
            return []
        placeholders = ",".join("?" for _ in keys)
        with self.connect() as conn:
            rows = conn.execute(
                f"""
                SELECT n.node_key,n.name,n.node_type,f.*
                FROM facts f JOIN nodes n ON n.id=f.subject_id
                WHERE n.node_key IN ({placeholders})
                ORDER BY f.confidence DESC,f.observed_at DESC LIMIT ?
                """,
                (*keys, limit),
            ).fetchall()
            return [
                {
                    "node_key": row["node_key"],
                    "name": row["name"],
                    "node_type": row["node_type"],
                    "predicate": row["predicate"],
                    "value": row["value"],
                    "unit": row["unit"],
                    "qualifiers": _loads(row["qualifiers_json"], {}),
                    "source_url": row["source_url"],
                    "confidence": float(row["confidence"]),
                    "observed_at": row["observed_at"],
                    "valid_from": row["valid_from"],
                    "valid_to": row["valid_to"],
                }
                for row in rows
            ]

    def recent_sources(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sources ORDER BY fetched_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [
                {
                    "url": row["url"],
                    "title": row["title"],
                    "page_type": row["page_type"],
                    "fetched_at": row["fetched_at"],
                    "content_hash": row["content_hash"],
                    "metadata": _loads(row["metadata_json"], {}),
                }
                for row in rows
            ]

    def export_json(self, output_path: str | Path) -> Path:
        path = Path(output_path)
        ensure_dir(path.parent)
        with self.connect() as conn:
            nodes = [self._node_row(row) for row in conn.execute("SELECT * FROM nodes ORDER BY id")]
            edges = []
            for row in conn.execute(
                """
                SELECT e.*,s.node_key source_key,t.node_key target_key
                FROM edges e JOIN nodes s ON s.id=e.source_id JOIN nodes t ON t.id=e.target_id
                ORDER BY e.id
                """
            ):
                edges.append(
                    {
                        "id": int(row["id"]),
                        "source": row["source_key"],
                        "predicate": row["predicate"],
                        "target": row["target_key"],
                        "attributes": _loads(row["attributes_json"], {}),
                        "source_url": row["source_url"],
                        "confidence": float(row["confidence"]),
                        "first_seen": row["first_seen"],
                        "last_seen": row["last_seen"],
                    }
                )
            payload = {"exported_at": _utc_now(), "stats": self.stats(), "nodes": nodes, "edges": edges}
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def export_graphml(self, output_path: str | Path) -> Path:
        from xml.sax.saxutils import escape

        path = Path(output_path)
        ensure_dir(path.parent)
        with self.connect() as conn:
            node_rows = conn.execute("SELECT * FROM nodes ORDER BY id").fetchall()
            edge_rows = conn.execute("SELECT * FROM edges ORDER BY id").fetchall()
        lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">',
            '<key id="type" for="node" attr.name="type" attr.type="string"/>',
            '<key id="name" for="node" attr.name="name" attr.type="string"/>',
            '<key id="attributes" for="node" attr.name="attributes" attr.type="string"/>',
            '<key id="predicate" for="edge" attr.name="predicate" attr.type="string"/>',
            '<key id="source_url" for="edge" attr.name="source_url" attr.type="string"/>',
            '<graph id="DellKnowledgeGraph" edgedefault="directed">',
        ]
        for row in node_rows:
            lines.append(
                f'<node id="n{row["id"]}"><data key="type">{escape(row["node_type"])}</data>'
                f'<data key="name">{escape(row["name"])}</data>'
                f'<data key="attributes">{escape(row["attributes_json"])}</data></node>'
            )
        for row in edge_rows:
            lines.append(
                f'<edge id="e{row["id"]}" source="n{row["source_id"]}" target="n{row["target_id"]}">'
                f'<data key="predicate">{escape(row["predicate"])}</data>'
                f'<data key="source_url">{escape(row["source_url"])}</data></edge>'
            )
        lines.extend(["</graph>", "</graphml>"])
        path.write_text("\n".join(lines), encoding="utf-8")
        return path
