from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Iterable
from urllib.parse import urljoin

from .dell_site_profile import DOCUMENT_LABEL_PATTERNS, REPEATABLE_CONTROL_PATTERNS


REPEATABLE_CONTROL_RE = re.compile(
    r"\b(?:" + "|".join(f"(?:{pattern})" for pattern in REPEATABLE_CONTROL_PATTERNS) + r")\b",
    re.I,
)


REVIEW_CONTROL_RE = re.compile(
    r"\b(?:ratings?\s*(?:&|and)\s*reviews?|reviews?|view ratings?|show more reviews?|more reviews?|all reviews?)\b",
    re.I,
)

DOCUMENT_CONTROL_RE = re.compile(
    r"\b(?:" + "|".join(f"(?:{pattern})" for pattern in DOCUMENT_LABEL_PATTERNS) + r")\b",
    re.I,
)


RESOURCE_URL_RE = re.compile(
    r"(?:https?:)?//[^\s\"'<>]+?\.(?:pdf|docx?|pptx?|xlsx?|csv|txt|xml|json)(?:\?[^\s\"'<>]*)?",
    re.I,
)

OVERALL_REVIEW_COUNT_RE = re.compile(
    r"(?:\(|\b)(\d[\d,]*)\)?\s*(?:verified\s+)?reviews?\b|\b(\d[\d,]*)\s+ratings?\b",
    re.I,
)
STAR_RE = re.compile(r"\b([1-5](?:\.\d)?)\s*(?:stars?|out of 5)\b", re.I)
RATING_PAREN_RE = re.compile(r"\b([1-5](?:\.\d)?)\s*\((\d[\d,]*)\)\b")


def normalize_label(label: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (label or "").lower()).strip()


def is_repeatable_control(label: str) -> bool:
    return bool(REPEATABLE_CONTROL_RE.search(label or ""))


def is_review_control(label: str) -> bool:
    return bool(REVIEW_CONTROL_RE.search(label or ""))


def is_document_control(label: str) -> bool:
    return bool(DOCUMENT_CONTROL_RE.search(label or ""))


def resource_kind(label: str, url: str = "") -> str:
    hay = f"{label} {url}".lower()
    mapping = [
        (r"brochure", "Brochure"),
        (r"e-?book", "EBook"),
        (r"white\s*paper", "Whitepaper"),
        (r"data\s*sheet|datasheet", "Datasheet"),
        (r"spec(?:ification)?\s*sheet", "SpecificationSheet"),
        (r"product\s+brief", "ProductBrief"),
        (r"solution\s+brief", "SolutionBrief"),
        (r"technical\s+brief", "TechnicalBrief"),
        (r"case\s+study", "CaseStudy"),
        (r"customer\s+story|success\s+story", "CustomerStory"),
        (r"analyst\s+report", "AnalystReport"),
        (r"reference\s+architecture", "ReferenceArchitecture"),
        (r"validated\s+design", "ValidatedDesign"),
        (r"research", "ResearchReport"),
        (r"webinar", "Webinar"),
        (r"demo|hands-on\s+lab", "DemoOrLab"),
        (r"deployment\s+guide", "DeploymentGuide"),
        (r"installation\s+guide", "InstallationGuide"),
        (r"user\s+guide", "UserGuide"),
        (r"manual", "Manual"),
        (r"infographic", "Infographic"),
        (r"transcript|caption|\.(?:vtt|srt|ttml)(?:$|\?)", "Transcript"),
        (r"\.docx?(?:$|\?)", "WordDocument"),
        (r"\.pptx?(?:$|\?)", "Presentation"),
        (r"\.xlsx?(?:$|\?)|\.csv(?:$|\?)", "Spreadsheet"),
        (r"\.(?:json|xml)(?:$|\?)", "PublicData"),
        (r"\.pdf(?:$|\?)|\bpdf\b", "PDFDocument"),
    ]
    for pattern, kind in mapping:
        if re.search(pattern, hay, re.I):
            return kind
    return "Resource"


def semantic_state_signature(
    visible_text: str,
    links: Iterable[tuple[str, str]] | Iterable[object],
    controls: Iterable[tuple[str, str]] | Iterable[object],
) -> str:
    link_rows: list[str] = []
    for item in links:
        if isinstance(item, tuple):
            link_rows.append(f"{item[0]}|{item[1]}")
        else:
            link_rows.append(f"{getattr(item, 'label', '')}|{getattr(item, 'url', '')}")
    control_rows: list[str] = []
    for item in controls:
        if isinstance(item, tuple):
            control_rows.append(f"{item[0]}|{item[1]}")
        else:
            control_rows.append(f"{getattr(item, 'role', '')}|{getattr(item, 'label', '')}")
    payload = "\n".join(
        [
            re.sub(r"\s+", " ", visible_text or "").strip(),
            *sorted(set(link_rows)),
            *sorted(set(control_rows)),
        ]
    )
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()


def extract_review_metrics(text: str) -> dict[str, int | float]:
    value = text or ""
    counts: list[int] = []
    for match in OVERALL_REVIEW_COUNT_RE.finditer(value):
        raw = match.group(1) or match.group(2) or ""
        try:
            counts.append(int(raw.replace(",", "")))
        except ValueError:
            pass
    rating = 0.0
    review_count = max(counts) if counts else 0
    for match in RATING_PAREN_RE.finditer(value):
        try:
            candidate = float(match.group(1))
            count = int(match.group(2).replace(",", ""))
        except ValueError:
            continue
        if count >= review_count:
            rating = candidate
            review_count = count
    if not rating:
        star_values: list[float] = []
        for match in STAR_RE.finditer(value):
            try:
                star_values.append(float(match.group(1)))
            except ValueError:
                pass
        if star_values:
            rating = star_values[0]
    return {
        "declared_review_count": review_count,
        "declared_rating": rating,
        "rating_mentions": len(list(STAR_RE.finditer(value))),
    }


def incremental_merge_texts(texts: Iterable[str]) -> str:
    """Preserve all newly exposed evidence without copying the whole page per click.

    Dell product/review widgets commonly return the complete page plus newly appended
    records. Sequence-based deltas retain inserted/replaced review blocks and carousel
    states while avoiding quadratic duplication of unchanged headers and footers.
    """
    clean = [str(text or "").strip() for text in texts if str(text or "").strip()]
    if not clean:
        return ""
    merged_lines = clean[0].splitlines()
    previous_lines = list(merged_lines)
    for text in clean[1:]:
        current_lines = text.splitlines()
        matcher = SequenceMatcher(a=previous_lines, b=current_lines, autojunk=False)
        additions: list[str] = []
        for tag, _a1, _a2, b1, b2 in matcher.get_opcodes():
            if tag in {"insert", "replace"}:
                additions.extend(current_lines[b1:b2])
        if additions:
            merged_lines.extend(["", "===== DYNAMICALLY REVEALED CONTENT =====", *additions])
        previous_lines = current_lines
    return "\n".join(merged_lines).strip()


def split_semantic_chunks(text: str, max_chars: int = 12000, overlap: int = 700) -> list[str]:
    """Split long HTML/PDF evidence without dropping any content.

    PDF page markers and paragraph boundaries are preferred. A small overlap helps
    preserve relationships crossing chunk boundaries. There is intentionally no
    default chunk-count cap; callers may process every returned chunk.
    """
    raw = str(text or "")
    if not raw:
        return []
    max_chars = max(2000, int(max_chars))
    overlap = max(0, min(int(overlap), max_chars // 3))
    if len(raw) <= max_chars:
        return [raw]

    parts = re.split(r"(?=\n===== PDF PAGE \d+ =====\n)|\n{2,}", raw)
    chunks: list[str] = []
    current = ""
    for part in parts:
        if not part:
            continue
        if len(part) > max_chars:
            if current:
                chunks.append(current.strip())
                current = ""
            start = 0
            while start < len(part):
                end = min(len(part), start + max_chars)
                chunks.append(part[start:end].strip())
                if end >= len(part):
                    break
                start = max(start + 1, end - overlap)
            continue
        candidate = f"{current}\n\n{part}".strip() if current else part.strip()
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current.strip())
                tail = current[-overlap:] if overlap else ""
                current = f"{tail}\n\n{part}".strip() if tail else part.strip()
            else:
                current = part.strip()
    if current:
        chunks.append(current.strip())
    return [chunk for chunk in chunks if chunk]


def discover_resource_urls_from_html(html_text: str, base_url: str) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for match in RESOURCE_URL_RE.finditer(html_text or ""):
        raw = match.group(0)
        if raw.startswith("//"):
            raw = "https:" + raw
        url = urljoin(base_url, raw)
        url = url.rstrip(".,;:)]}")
        if url in seen:
            continue
        seen.add(url)
        output.append(url)
    return output


@dataclass(slots=True)
class RepeatableControlState:
    key: str
    label: str
    role: str
    clicks: int = 0
    progress_events: int = 0
    no_progress_rounds: int = 0
    seen_signatures: set[str] = field(default_factory=set)
    status: str = "PENDING"
    last_signature: str = ""
    last_detail: str = ""

    def observe(self, signature: str, changed: bool, stable_rounds_required: int = 2) -> str:
        self.clicks += 1
        repeated = bool(signature and signature in self.seen_signatures)
        if signature:
            self.seen_signatures.add(signature)
            self.last_signature = signature
        if changed and not repeated:
            self.progress_events += 1
            self.no_progress_rounds = 0
            self.status = "PROGRESS"
        else:
            self.no_progress_rounds += 1
            self.status = "NO_PROGRESS"
        if repeated:
            self.status = "CYCLE_EXHAUSTED"
        elif self.no_progress_rounds >= max(1, int(stable_rounds_required)):
            self.status = "STABLE_EXHAUSTED"
        return self.status

    @property
    def exhausted(self) -> bool:
        return self.status in {
            "CONTROL_ABSENT",
            "DIRECT_ENDPOINT",
            "NAVIGATED",
            "CYCLE_EXHAUSTED",
            "STABLE_EXHAUSTED",
            "DISABLED",
            "FAILED",
        }

    def to_dict(self) -> dict[str, object]:
        return {
            "key": self.key,
            "label": self.label,
            "role": self.role,
            "clicks": self.clicks,
            "progress_events": self.progress_events,
            "no_progress_rounds": self.no_progress_rounds,
            "status": self.status,
            "last_signature": self.last_signature,
            "last_detail": self.last_detail,
            "state_count": len(self.seen_signatures),
        }

# ---------------------------------------------------------------------------
# Lazy-page convergence
# ---------------------------------------------------------------------------

_DYNAMIC_NOISE_RE = re.compile(
    r"^(?:"
    r"\d{1,2}:\d{2}(?::\d{2})?(?:\s*[ap]m)?|"
    r"(?:updated|refresh(?:ed)?|loaded)\s+(?:just now|\d+\s+(?:seconds?|minutes?)\s+ago)|"
    r"slide\s+\d+\s+(?:of|/)\s+\d+|"
    r"\d{1,3}%|"
    r"loading(?:\.{1,3})?|"
    r"please wait"
    r")$",
    re.I,
)


def _stable_text_lines(value: str) -> set[str]:
    """Return semantic text lines suitable for convergence checks.

    The browser snapshot can change continuously because of clocks, rotating
    banners, animated counters, chat widgets and ephemeral accessibility refs.
    Those changes must not keep a Dell page in the lazy-scroll phase forever.
    This helper intentionally keeps product names, prices, offers and technical
    facts while discarding only very small or obviously volatile UI strings.
    """
    output: set[str] = set()
    for raw in str(value or "").splitlines():
        line = re.sub(r"\s+", " ", raw).strip().casefold()
        if len(line) < 4 or len(line) > 1200:
            continue
        if _DYNAMIC_NOISE_RE.match(line):
            continue
        # Playwright references are opaque and can refresh after every React
        # render. They are never evidence and must not affect convergence.
        line = re.sub(r"\bref=[a-z0-9_.:-]+\b", "ref=<id>", line, flags=re.I)
        output.add(line)
    return output


def _stable_link_keys(links: Iterable[object]) -> set[str]:
    values: set[str] = set()
    for item in links or []:
        url = str(getattr(item, "url", "") or "").strip()
        label = normalize_label(str(getattr(item, "label", "") or ""))
        if url:
            values.add(f"{url}|{label}")
    return values


def _stable_control_keys(controls: Iterable[object]) -> set[str]:
    values: set[str] = set()
    for item in controls or []:
        role = normalize_label(str(getattr(item, "role", "") or ""))
        label = normalize_label(str(getattr(item, "label", "") or ""))
        if role or label:
            values.add(f"{role}|{label}")
    return values


@dataclass(slots=True)
class LazyScanConvergence:
    """Geometry-aware convergence detector for long JavaScript pages.

    Site-wide crawling may be unlimited, but one page must never monopolise the
    worker. Dell pages often keep mutating at the bottom because of carousels,
    offers, telemetry widgets or accessibility reference refreshes. The correct
    end condition for lazy scrolling is therefore *no additional vertical
    frontier*, not a byte-for-byte stable snapshot.
    """

    stable_rounds_required: int = 2
    fallback_round_guard: int = 80
    rounds: int = 0
    no_growth_rounds: int = 0
    bottom_geometry_stable_rounds: int = 0
    terminal_reason: str = ""
    adaptive_round_guard: int = 80
    previous_after: int | None = None
    previous_height: int | None = None
    previous_at_bottom: bool = False
    previous_text: set[str] = field(default_factory=set)
    previous_links: set[str] = field(default_factory=set)
    previous_controls: set[str] = field(default_factory=set)

    def __post_init__(self) -> None:
        self.stable_rounds_required = max(1, int(self.stable_rounds_required))
        self.fallback_round_guard = max(12, int(self.fallback_round_guard))
        self.adaptive_round_guard = self.fallback_round_guard

    def prime(self, page: object) -> None:
        self.previous_text = _stable_text_lines(str(getattr(page, "visible_text", "") or ""))
        self.previous_links = _stable_link_keys(getattr(page, "links", []) or [])
        self.previous_controls = _stable_control_keys(getattr(page, "controls", []) or [])

    def observe(self, page: object, scroll_state: dict[str, object] | None = None) -> dict[str, object]:
        state = scroll_state if isinstance(scroll_state, dict) else {}
        self.rounds += 1

        text = _stable_text_lines(str(getattr(page, "visible_text", "") or ""))
        links = _stable_link_keys(getattr(page, "links", []) or [])
        controls = _stable_control_keys(getattr(page, "controls", []) or [])

        new_text = text - self.previous_text
        new_links = links - self.previous_links
        new_controls = controls - self.previous_controls
        new_text_chars = sum(len(line) for line in new_text)

        after = int(state.get("after") or 0) if state else 0
        height = int(state.get("height") or 0) if state else 0
        viewport = int(state.get("viewport") or 0) if state else 0
        at_bottom = bool(state.get("atBottom")) if state else False

        scroll_moved = self.previous_after is None or abs(after - self.previous_after) > 4
        height_grew = self.previous_height is None or height > self.previous_height + 12
        same_bottom_geometry = bool(
            state
            and at_bottom
            and self.previous_at_bottom
            and self.previous_after is not None
            and self.previous_height is not None
            and abs(after - self.previous_after) <= 4
            and abs(height - self.previous_height) <= 12
        )

        # Text-only replacements from an auto-rotating carousel are not a new
        # vertical frontier. Substantial new text, links, controls, height, or
        # scroll movement still count as useful progress before the bottom.
        meaningful_growth = bool(
            new_links
            or new_controls
            or new_text_chars >= 160
            or height_grew
            or (scroll_moved and not at_bottom)
        )
        if meaningful_growth:
            self.no_growth_rounds = 0
        else:
            self.no_growth_rounds += 1

        if same_bottom_geometry and not (new_links or new_controls):
            self.bottom_geometry_stable_rounds += 1
        elif at_bottom and not (new_links or new_controls):
            self.bottom_geometry_stable_rounds = 1
        else:
            # Newly discovered endpoints/controls are actionable evidence. Give
            # the page another sweep even when the scroll position is unchanged.
            self.bottom_geometry_stable_rounds = 0

        if height > 0:
            effective_viewport = max(320, viewport or 720)
            estimated_sweeps = max(1, (height + effective_viewport - 1) // effective_viewport)
            # The page can grow while scrolling. This adaptive guard expands with
            # document height but still prevents a pathological page-local loop.
            self.adaptive_round_guard = max(
                20,
                min(5000, int(estimated_sweeps * 3 + 12)),
            )
        else:
            self.adaptive_round_guard = self.fallback_round_guard

        converged = False
        reason = ""
        if state and self.bottom_geometry_stable_rounds >= self.stable_rounds_required:
            # At a stable bottom there is nothing more for scrolling to reveal.
            # Dynamic controls and carousels are handled in the next extraction
            # stage, so snapshot churn must not trap the worker here.
            converged = True
            reason = "bottom_geometry_stable"
        elif not state and self.no_growth_rounds >= self.stable_rounds_required:
            converged = True
            reason = "semantic_no_growth"
        elif self.rounds >= self.adaptive_round_guard:
            converged = True
            reason = "adaptive_page_guard"

        if converged:
            self.terminal_reason = reason

        self.previous_text = text
        self.previous_links = links
        self.previous_controls = controls
        if state:
            self.previous_after = after
            self.previous_height = height
            self.previous_at_bottom = at_bottom

        return {
            "round": self.rounds,
            "converged": converged,
            "reason": reason,
            "at_bottom": at_bottom,
            "scroll_after": after,
            "document_height": height,
            "viewport": viewport,
            "scroll_moved": scroll_moved,
            "height_grew": height_grew,
            "new_text_lines": len(new_text),
            "new_text_chars": new_text_chars,
            "new_links": len(new_links),
            "new_controls": len(new_controls),
            "meaningful_growth": meaningful_growth,
            "no_growth_rounds": self.no_growth_rounds,
            "bottom_geometry_stable_rounds": self.bottom_geometry_stable_rounds,
            "adaptive_round_guard": self.adaptive_round_guard,
        }
