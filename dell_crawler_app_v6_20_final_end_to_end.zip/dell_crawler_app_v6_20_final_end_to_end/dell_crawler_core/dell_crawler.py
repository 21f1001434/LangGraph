from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import ssl
import time
import tempfile
import traceback
import urllib.robotparser
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

import certifi
import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader

try:
    from PIL import Image
except Exception:  # pragma: no cover - optional dependency is validated at runtime
    Image = None  # type: ignore

from .content_extractor import DellContentExtractor
from .authenticated_session import DellAuthenticatedSession, safe_authenticated_account_url
from .masthead_discovery import DellMastheadDiscovery
from .market_context import accept_language_for_locale, hreflang_aliases, normalize_locale
from .coverage_audit import audit_page
from .browser_pdf_viewer import (
    BrowserPDFViewerCapture,
    clean_accessibility_text,
    decode_mcp_text,
    dedupe_text_blocks,
    dedupe_visual_evidence,
    parse_pdf_page_position,
    perceptual_image_signature,
)
from .agentic_control import ActionOutcome, ActionSelection, AgentQInspiredActionModel
from .deep_content import (
    LazyScanConvergence,
    RepeatableControlState,
    discover_resource_urls_from_html,
    extract_review_metrics,
    incremental_merge_texts,
    is_document_control,
    is_repeatable_control,
    is_review_control,
    normalize_label,
    resource_kind,
    semantic_state_signature,
)
from .crawl_models import CrawlConfig, CrawlPage, CrawlStats, DiscoveredLink, SafeControl
from .kg_store import SQLiteKnowledgeGraph
from .frontier_scheduler import (
    ASSET, BINARY, DATA, DOCUMENT, PAGE, SITEMAP,
    asset_family_key, classify_frontier_url, is_visual_asset_url,
    semantic_control_context_key,
)
from .html_enrichment import analyse_html_document, structured_evidence_to_text
from .dell_site_profile import archetype_for
from .document_pipeline import (
    DocumentValidationError,
    append_jsonl,
    parse_mcp_network_request_indices,
    parse_mcp_network_request_entries,
    pdf_urls_consistent,
    normalize_pdf_download_url,
    short_pdf_storage_path,
    pdf_magic_offset,
    quarantine_file,
    safe_header_dict,
    validate_pdf_bytes,
    validate_pdf_file,
    validate_pdf_file_stable,
)
from .mcp_runtime import PlaywrightMCPRuntime
from .react_self_heal import FailureClassifier, HealAction, ReActContext, ReActSelfHealingController
from .resource_ingestion import (
    extract_resource,
    extension_for_url,
    is_binary_asset_url,
    is_caption_url,
    is_public_data_url,
    is_supported_document_url,
    public_get_candidates,
    sanitize_public_api_url,
)
from .snapshot_extract import (
    canonicalize_url,
    classify_page,
    content_hash,
    stable_text_hash,
    extract_links,
    extract_page_info,
    extract_safe_controls,
    extract_visible_text,
    is_en_uk_scope,
    is_locale_scope,
    is_pdf_url,
    is_document_url,
    is_public_resource_url,
    is_sitemap_url,
    is_trusted_dell_url,
    priority_for_url,
    seed_urls_for_scope,
)
from .utils import ensure_dir, utc_stamp


StatusCallback = Callable[[dict[str, Any]], None]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class RobotsGate:
    def __init__(self, client: httpx.Client, user_agent: str, fail_closed: bool = False) -> None:
        self.client = client
        self.user_agent = user_agent
        self.fail_closed = fail_closed
        self._cache: dict[str, urllib.robotparser.RobotFileParser | None] = {}
        self._raw: dict[str, str] = {}
        self.errors: dict[str, str] = {}

    def allowed(self, url: str) -> bool:
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if origin not in self._cache:
            robots_url = origin + "/robots.txt"
            try:
                response = self.client.get(robots_url, timeout=30, follow_redirects=True)
                response.raise_for_status()
                parser = urllib.robotparser.RobotFileParser()
                parser.set_url(robots_url)
                parser.parse(response.text.splitlines())
                self._cache[origin] = parser
                self._raw[origin] = response.text
            except Exception as exc:
                self._cache[origin] = None
                self.errors[origin] = f"{type(exc).__name__}: {exc}"
        parser = self._cache[origin]
        if parser is None:
            return not self.fail_closed
        return bool(parser.can_fetch(self.user_agent, url))

    def sitemap_urls(self, url: str) -> list[str]:
        """Return Sitemap directives declared by the origin robots.txt."""
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if origin not in self._cache:
            self.allowed(url)
        raw = self._raw.get(origin, "")
        values: list[str] = []
        seen: set[str] = set()
        for line in raw.splitlines():
            match = re.match(r"\s*Sitemap\s*:\s*(\S+)", line, re.I)
            if not match:
                continue
            candidate = canonicalize_url(match.group(1), origin)
            if candidate and candidate not in seen and is_trusted_dell_url(candidate):
                seen.add(candidate)
                values.append(candidate)
        return values


class DellEnUkKnowledgeCrawler:
    """Hybrid Dell locale crawler: deterministic Playwright MCP + HTTP/PDF ingestion.

    The browser is used for JavaScript-rendered pages and safe expandable controls.
    Direct HTTP is used for ordinary public resources and fallback representations;
    PDFs default to the live Playwright browser context. Dell AIA structures captured evidence and may select one bounded recovery
    action; URL scope, safe-control selection and tool execution remain deterministic.
    This separation protects long-running crawling from prompt injection and accidental
    purchasing/account mutations.
    """

    def __init__(
        self,
        runtime: PlaywrightMCPRuntime,
        store: SQLiteKnowledgeGraph,
        extractor: DellContentExtractor,
        config: CrawlConfig,
        output_dir: str | Path = "knowledge",
        status_callback: StatusCallback | None = None,
    ) -> None:
        self.runtime = runtime
        self.store = store
        self.extractor = extractor
        self.config = config
        self.output_dir = ensure_dir(output_dir)
        self.raw_dir = ensure_dir(self.output_dir / "raw")
        self.document_dir = ensure_dir(self.output_dir / "documents")
        self.document_quarantine_dir = ensure_dir(self.output_dir / "document_quarantine")
        # v6.5 separates recoverable transport events from terminal PDF failures.
        # A Dell CDN 403 is expected in many corporate environments and is not a
        # document failure when browser/viewer recovery subsequently succeeds.
        self.pdf_failure_log = self.output_dir / "PDF_FAILURES.jsonl"
        self.pdf_transport_log = self.output_dir / "PDF_TRANSPORT_EVENTS.jsonl"
        self.pdf_success_log = self.output_dir / "PDF_SUCCESSES.jsonl"
        self.pdf_recovery_log = self.output_dir / "PDF_RECOVERIES.jsonl"
        self.pdf_validation_log = self.output_dir / "PDF_VALIDATION_REJECTIONS.jsonl"
        self.screenshot_dir = ensure_dir(self.output_dir / "screenshots")
        self.visual_dir = ensure_dir(self.output_dir / "visual_assets")
        self.pdf_visual_dir = ensure_dir(self.output_dir / "pdf_visual_pages")
        self.browser_pdf_viewer_dir = ensure_dir(self.output_dir / "browser_pdf_viewer")
        self.dynamic_state_dir = ensure_dir(self.output_dir / "dynamic_states")
        self.status_callback = status_callback
        self.user_agent = os.getenv(
            "DELL_CRAWLER_USER_AGENT",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
        )
        self.http = httpx.Client(
            headers={
                "User-Agent": self.user_agent,
                "Accept-Language": accept_language_for_locale(str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk")),
                "Accept": "text/html,application/xhtml+xml,application/pdf;q=0.9,*/*;q=0.7",
            },
            verify=ssl.create_default_context(cafile=certifi.where()),
            timeout=httpx.Timeout(45.0, connect=25.0),
            follow_redirects=True,
        )
        self.robots = RobotsGate(self.http, self.user_agent, config.robots_fail_closed)
        self.run_id = f"DELL-{normalize_locale(str(getattr(config, 'locale', 'en-uk') or 'en-uk')).upper()}-{utc_stamp()}"
        self.stats = CrawlStats(run_id=self.run_id, started_at=_now())
        self.healer = ReActSelfHealingController(
            aia=getattr(extractor, "aia", None),
            use_llm=bool(config.react_use_llm),
            enabled=bool(config.react_enabled and config.self_heal_enabled),
            retry_base_seconds=config.retry_base_seconds,
            retry_max_seconds=config.retry_max_seconds,
        )
        self.action_model = AgentQInspiredActionModel(
            store=store,
            aia=getattr(extractor, "aia", None),
            enabled=bool(config.agentq_action_model_enabled and config.agentq_actor_critic_enabled),
            use_llm_critic=bool(config.agentq_llm_critic_enabled),
            llm_margin=float(config.agentq_llm_critic_margin),
            exploration_weight=(
                float(config.agentq_exploration_weight)
                if config.agentq_mcts_exploration_enabled else 0.0
            ),
        )
        self._runtime_info: dict[str, Any] = {}
        self._stopped = False
        self._last_coverage_checkpoint = time.monotonic()
        self._item_failures: dict[str, str] = {}
        self._browser_pdf_viewer_cache: dict[str, dict[str, Any]] = {}
        self._last_pdf_acquisition_context: dict[str, dict[str, Any]] = {}
        self._pdf_validation_rejection_keys: set[str] = set()
        self._pdf_validation_rejection_urls: set[str] = set()
        self._pdf_terminal_validation_urls: set[str] = set()
        self._authenticated_account_urls: list[str] = []
        self._auth_status: dict[str, Any] = {"status": "NOT_ATTEMPTED", "authenticated": False}
        self._masthead_seed_urls: list[str] = []
        self._masthead_status: dict[str, Any] = {"status": "NOT_ATTEMPTED", "urls": []}

    def _emit(self, event: str, **payload: Any) -> None:
        run_id = str(getattr(self, "run_id", getattr(getattr(self, "stats", None), "run_id", "")) or "")
        stats = getattr(self, "stats", None)
        message = {
            "event": event,
            "run_id": run_id,
            "timestamp": _now(),
            "stats": stats.to_dict() if stats is not None else {},
            **payload,
        }
        source_url = str(payload.get("url") or "").strip()
        if source_url and hasattr(self, "store"):
            try:
                self.store.touch_queue(
                    source_url,
                    lease_owner=run_id,
                    lease_seconds=int(getattr(self.config, "worker_lease_seconds", 900)),
                )
            except Exception:
                pass
        callback = getattr(self, "status_callback", None)
        if callback:
            try:
                callback(message)
            except Exception:
                pass

    def stop(self) -> None:
        self._stopped = True

    def _ensure_runtime(self) -> dict[str, Any]:
        if self.runtime.started:
            return self._runtime_info or {
                "ok": True,
                "already_started": True,
                "server_url": self.runtime.server_url,
                "tools": sorted(self.runtime.tools),
            }
        result = self.runtime.start()
        if not result.get("ok") and str(result.get("status") or "") == "mcp_browser_profile_locked":
            wait_step = max(1.0, float(getattr(self.config, "document_profile_lock_backoff_seconds", 15.0)))
            max_wait = max(wait_step, float(getattr(self.config, "document_profile_lock_max_wait_seconds", 180.0)))
            deadline = time.monotonic() + max_wait
            while time.monotonic() < deadline and not self._stopped:
                stats = getattr(self, "stats", None)
                if stats is not None:
                    stats.pdf_profile_lock_requeues += 1
                self._emit(
                    "mcp_browser_profile_wait",
                    wait_seconds=wait_step,
                    profile_lease=result.get("profile_lease", {}),
                )
                time.sleep(min(wait_step, max(0.0, deadline - time.monotonic())))
                result = self.runtime.start()
                if result.get("ok") or str(result.get("status") or "") != "mcp_browser_profile_locked":
                    break
        if not result.get("ok"):
            status = str(result.get("status") or "mcp_start_failed")
            detail = result.get("error") or result.get("detail") or "Official Playwright MCP did not start"
            raise RuntimeError(f"{status}: {detail}")
        self.runtime.keep_single_dell_tab()
        self._runtime_info = result
        return result

    def _ensure_mutation_observer(self, url: str) -> dict[str, Any]:
        if not self.config.dom_mutation_observer_enabled or not self.runtime.started:
            return {"ok": False, "status": "disabled"}
        result = self.runtime.install_mutation_observer(
            intent="Install fixed Dell crawler mutation telemetry for post-action settle detection"
        )
        state = result.get("mutation_state") if isinstance(result.get("mutation_state"), dict) else {}
        if result.get("ok") and state.get("ok", True):
            self._emit("mutation_observer_installed", url=url)
        return result

    def _wait_for_dom_settle(self, url: str, label: str) -> dict[str, Any]:
        if not self.config.dom_mutation_observer_enabled or not self.runtime.started:
            self.runtime.wait(0.8, intent="Wait for Dell read-only content to settle")
            return {"ok": True, "status": "fixed_wait", "mutation_state": {}}
        self.stats.mutation_settle_waits += 1
        result = self.runtime.wait_for_dom_quiet(
            quiet_window_ms=int(self.config.mutation_quiet_window_ms),
            max_wait_seconds=float(self.config.mutation_max_wait_seconds),
            intent=f"Wait for DOM changes after read-only control '{label}' to become quiet",
        )
        state = result.get("mutation_state") if isinstance(result.get("mutation_state"), dict) else {}
        mutations = int(state.get("total") or 0)
        self.stats.mutation_events_observed += mutations
        self._emit(
            "mutation_settle",
            url=url,
            label=label,
            status=result.get("status"),
            mutation_events=mutations,
            quiet_for_ms=int(state.get("quietForMs") or 0),
            samples=(state.get("samples") or [])[:12],
        )
        if not result.get("ok"):
            self.runtime.wait(0.8, intent="Mutation observer unavailable; use safe fixed settle wait")
        return result

    def _record_heal(
        self,
        context: ReActContext,
        decision: Any,
        result: dict[str, Any],
        *,
        before_hash: str = "",
        after_hash: str = "",
    ) -> None:
        self.stats.react_decisions += 1
        self.stats.heal_attempts += 1
        if decision.failure_class == "NO_PROGRESS":
            self.stats.stuck_events += 1
        if decision.action == HealAction.RESTART_MCP and result.get("ok"):
            self.stats.mcp_restarts += 1
        if result.get("ok"):
            self.stats.heal_successes += 1
        self.store.record_self_heal_event(
            run_id=self.run_id,
            source_url=context.url,
            stage=context.stage,
            failure_class=decision.failure_class,
            action=decision.action.value,
            status=str(result.get("status") or ("ok" if result.get("ok") else "failed")),
            attempt=context.attempt,
            before_hash=before_hash or context.before_hash,
            after_hash=after_hash or context.after_hash,
            detail=str(result.get("detail") or decision.rationale),
            decision=decision.to_dict(),
            result=result,
        )
        self._emit(
            "react_self_heal",
            url=context.url,
            stage=context.stage,
            failure_class=decision.failure_class,
            action=decision.action.value,
            attempt=context.attempt,
            max_attempts=context.max_attempts,
            rationale=decision.rationale,
            result_status=result.get("status"),
            result_ok=bool(result.get("ok")),
        )

    @staticmethod
    def _merge_page_evidence(base: CrawlPage, additions: list[CrawlPage]) -> CrawlPage:
        texts = [base.visible_text]
        links = list(base.links)
        assets = list(base.visual_assets)
        screenshots = list(base.screenshot_paths)
        visual_evidence = list(base.metadata.get("visual_evidence") or [])
        merged_metadata: dict[str, Any] = dict(base.metadata)
        current = base
        for page in additions:
            current = page
            texts.append(page.visible_text)
            links.extend(page.links)
            assets.extend(page.visual_assets)
            screenshots.extend(page.screenshot_paths)
            visual_evidence.extend(page.metadata.get("visual_evidence") or [])
            # Preserve stage-level audit fields such as deep-scan completion while
            # allowing the newest rendered capture to refresh page evidence.
            merged_metadata.update(page.metadata)
        combined = incremental_merge_texts(texts)
        current.visible_text = combined
        current.links = DellEnUkKnowledgeCrawler._merge_links(links)
        current.visual_assets = DellEnUkKnowledgeCrawler._dedupe_visual_items(assets)
        current.screenshot_paths = list(dict.fromkeys(path for path in screenshots if path))
        current.screenshot_path = current.screenshot_paths[0] if current.screenshot_paths else ""
        current.metadata = merged_metadata
        current.metadata["visual_assets"] = current.visual_assets
        current.metadata["visual_evidence"] = DellEnUkKnowledgeCrawler._dedupe_visual_items(visual_evidence)
        current.content_hash = content_hash(f"{current.title}\n{combined}")
        return current

    @staticmethod
    def _safe_filename(url: str, suffix: str = ".txt") -> str:
        parsed = urlparse(url)
        stem = re.sub(r"[^a-zA-Z0-9._-]+", "_", f"{parsed.netloc}{parsed.path}").strip("_")
        if not stem:
            stem = "page"
        digest = content_hash(url)[:12]
        return f"{stem[:140]}_{digest}{suffix}"

    def _write_raw(self, page: CrawlPage) -> Path:
        path = self.raw_dir / self._safe_filename(page.canonical_url)
        payload = (
            f"URL: {page.canonical_url}\nTITLE: {page.title}\nTYPE: {page.page_type}\n"
            f"FETCHED: {_now()}\nCONTENT_HASH: {page.content_hash}\n\n"
            "===== VISIBLE TEXT =====\n"
            f"{page.visible_text}\n\n===== ACCESSIBILITY SNAPSHOT =====\n{page.snapshot}"
        )
        path.write_text(payload, encoding="utf-8", errors="ignore")
        return path

    def _dynamic_state_path(self, source_url: str) -> Path:
        return self.dynamic_state_dir / self._safe_filename(source_url, ".jsonl")

    def _persist_dynamic_state(
        self,
        page: CrawlPage,
        *,
        control: SafeControl | None = None,
        iteration: int = 0,
        status: str = "OBSERVED",
    ) -> str:
        if not self.config.capture_dynamic_state_evidence:
            return ""
        path = self._dynamic_state_path(page.canonical_url)
        payload = {
            "observed_at": _now(),
            "source_url": page.canonical_url,
            "title": page.title,
            "page_type": page.page_type,
            "content_hash": page.content_hash,
            "semantic_signature": semantic_state_signature(page.visible_text, page.links, page.controls),
            "control": control.to_dict() if control is not None else {},
            "iteration": int(iteration),
            "status": status,
            "review_metrics": extract_review_metrics(page.visible_text),
            "visible_text": page.visible_text,
            "links": [item.to_dict() for item in page.links],
            "controls": [item.to_dict() for item in page.controls],
            "screenshot_paths": list(page.screenshot_paths),
        }
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")
        self.stats.dynamic_states_captured += 1
        return str(path)

    @staticmethod
    def _tab_key(tab: dict[str, Any]) -> tuple[int, str]:
        return int(tab.get("index", -1)), str(tab.get("url") or "")

    def _capture_new_tab_resources(
        self,
        before_tabs: list[dict[str, Any]],
        base_url: str,
        label: str,
    ) -> list[DiscoveredLink]:
        """Capture asynchronously opened Dell resources and restore the source page.

        Brochure/PDF controls may open a blank tab first and assign the final URL
        later. The crawler waits for the popup and for its URL to stabilise, queues
        the document as an independent durable job, closes the resource tab, then
        returns to the original Dell page to continue the remaining controls.
        """
        before_keys = {self._tab_key(item) for item in before_tabs}
        wait_seconds = 8.0 if is_document_control(label) else 2.0
        deadline = time.monotonic() + wait_seconds
        new_tabs: list[dict[str, Any]] = []
        after_tabs: list[dict[str, Any]] = []
        while time.monotonic() < deadline and not self._stopped:
            after_tabs = self.runtime.tab_inventory(
                intent=f"Observe tabs after read-only Dell control '{label}'"
            )
            new_tabs = [item for item in after_tabs if self._tab_key(item) not in before_keys]
            if new_tabs:
                break
            time.sleep(0.25)

        discovered: list[DiscoveredLink] = []
        for tab in new_tabs:
            index = int(tab.get("index", -1))
            if index < 0:
                continue
            self.runtime.select_tab(index, intent="Inspect newly opened Dell brochure/resource tab")
            candidate = canonicalize_url(str(tab.get("url") or ""), base_url)
            stable_rounds = 0
            last_candidate = candidate
            for _ in range(20):
                if self._stopped:
                    break
                self.runtime.wait(0.25, intent="Wait for Dell resource tab URL to stabilise")
                inventory = self.runtime.tab_inventory(intent="Observe final Dell resource URL")
                selected = next((item for item in inventory if item.get("current")), None)
                observed = canonicalize_url(str((selected or {}).get("url") or ""), base_url)
                if observed and observed == last_candidate and observed not in {"about:blank"}:
                    stable_rounds += 1
                else:
                    stable_rounds = 0
                if observed:
                    candidate = observed
                    last_candidate = observed
                if stable_rounds >= 2:
                    break

            snap = self.runtime.snapshot(
                boxes=False,
                intent="Capture final URL of newly opened Dell resource tab",
            )
            if snap.get("ok"):
                info = extract_page_info(str(snap.get("detail") or ""))
                candidate = canonicalize_url(info.url or candidate, base_url)

            if candidate and self._scope_allowed(candidate):
                discovered.append(
                    DiscoveredLink(
                        label=label,
                        url=candidate,
                        source="control_new_tab",
                        relation="CONTROL_OPENS_RESOURCE",
                        priority=priority_for_url(candidate, label),
                        resource_kind=resource_kind(label, candidate),
                    )
                )
            self.runtime.close_tab(index, intent="Close captured Dell resource tab after queueing it")

        restored = False
        canonical_base = canonicalize_url(base_url)
        for tab in self.runtime.tab_inventory(intent="Restore Dell source tab after resource capture"):
            candidate = canonicalize_url(str(tab.get("url") or ""), base_url)
            if candidate == canonical_base:
                result = self.runtime.select_tab(int(tab.get("index", 0)), intent="Return to Dell source tab")
                restored = bool(result.get("ok"))
                break
        if not restored:
            self.runtime.navigate(base_url, "Restore Dell source page after resource-tab capture")
            self.runtime.wait(0.8, intent="Wait after restoring Dell source page")
        return discovered

    def _prepare_authenticated_knowledge(self) -> dict[str, Any]:
        """Establish/reuse Dell SSO and discover safe read-only account pages.

        Authentication is a bounded bootstrap, not a general form automation mode.
        Only the configured email and Dell Login/Continue handoff controls are used.
        If an OTP/password prompt appears the crawler waits for corporate/manual SSO
        and never types the secret.
        """
        if not bool(getattr(self.config, "include_authenticated_account_knowledge", False)):
            self._auth_status = {"status": "DISABLED", "authenticated": False}
            return dict(self._auth_status)
        self._ensure_runtime()
        auth = DellAuthenticatedSession(
            self.runtime,
            email=str(getattr(self.config, "login_email", "") or os.getenv("DELL_LOGIN_EMAIL") or os.getenv("DELL_DEMO_EMAIL") or ""),
            profile_name=str(getattr(self.config, "profile_name", "") or os.getenv("DELL_PROFILE_NAME") or ""),
            locale=str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk"),
            auth_probe_url=str(getattr(self.config, "auth_probe_url", "") or os.getenv("DELL_AUTH_PROBE_URL") or ""),
            wait_seconds=float(getattr(self.config, "auth_wait_seconds", 90.0)),
            emit=self._emit,
        )
        result = auth.ensure_authenticated()
        self._auth_status = result.to_dict()
        if not result.authenticated:
            self.stats.warnings.append(
                "Authenticated My Account knowledge was requested but Dell SSO was not ready; "
                "the public crawl will continue and the persistent browser can be resumed after SSO completes."
            )
            self._emit("authenticated_knowledge_unavailable", **self._auth_status)
            if bool(getattr(self.config, "require_authenticated_account_knowledge", False)):
                raise RuntimeError(f"Dell authenticated knowledge required but unavailable: {result.status}: {result.detail}")
            return dict(self._auth_status)
        self._authenticated_account_urls = auth.discover_account_urls()
        self._auth_status["account_urls"] = list(self._authenticated_account_urls)
        self._emit(
            "authenticated_knowledge_ready",
            status=result.status,
            account_url_count=len(self._authenticated_account_urls),
            account_urls=self._authenticated_account_urls[:30],
        )
        return dict(self._auth_status)

    def _prepare_masthead_knowledge(self) -> dict[str, Any]:
        """Expand every Dell masthead family and queue all safe child destinations.

        This is the deterministic coverage layer for global navigation that ordinary
        link crawling can miss because Dell renders many menu children only after a
        hover/click.  Transactional/authentication controls are audited but never
        activated.  Full page extraction still occurs later through the durable
        frontier, so canonical URL/content de-duplication remains effective.
        """
        if not bool(getattr(self.config, "include_masthead_taxonomy_discovery", True)):
            self._masthead_status = {"status": "DISABLED", "urls": []}
            return dict(self._masthead_status)
        self._ensure_runtime()
        discovery = DellMastheadDiscovery(
            self.runtime,
            locale=str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk"),
            profile_name=str(getattr(self.config, "profile_name", "") or os.getenv("DELL_PROFILE_NAME") or ""),
            authenticated=bool(self._auth_status.get("authenticated")),
            max_submenu_depth=int(getattr(self.config, "masthead_max_submenu_depth", 4)),
            max_actions=int(getattr(self.config, "masthead_max_actions", 250)),
            emit=self._emit,
        )
        result = discovery.discover()
        self._masthead_status = result.to_dict()
        self._masthead_seed_urls = [url for url in result.urls if self._scope_allowed(url)]
        self._masthead_status["urls"] = list(self._masthead_seed_urls)
        self._masthead_status["url_count"] = len(self._masthead_seed_urls)
        try:
            (self.output_dir / "MASTHEAD_TAXONOMY_REPORT.json").write_text(
                json.dumps(self._masthead_status, indent=2, ensure_ascii=False, default=str),
                encoding="utf-8",
            )
        except Exception as exc:
            self.stats.warnings.append(f"Could not write masthead taxonomy report: {type(exc).__name__}: {exc}")
        self.stats.masthead_menu_urls_discovered += len(self._masthead_seed_urls)
        self.stats.masthead_unsafe_items_skipped += len(result.unsafe_labels_skipped)
        self.stats.masthead_groups_complete += sum(
            1 for value in result.groups.values() if str(value.get("status") or "") == "COMPLETE"
        )
        self.stats.masthead_groups_partial += sum(
            1 for value in result.groups.values() if str(value.get("status") or "") in {"PARTIAL", "TOP_LEVEL_NOT_FOUND"}
        )
        self._emit(
            "masthead_knowledge_ready",
            status=self._masthead_status.get("status"),
            url_count=len(self._masthead_seed_urls),
            report=str(self.output_dir / "MASTHEAD_TAXONOMY_REPORT.json"),
        )
        if bool(getattr(self.config, "require_masthead_taxonomy_coverage", False)) and str(result.status) != "COMPLETE":
            raise RuntimeError(f"Dell masthead taxonomy required but discovery was {result.status}: {result.detail}")
        return dict(self._masthead_status)

    def _scope_allowed(self, url: str) -> bool:
        canonical = canonicalize_url(url)
        if not canonical or not is_trusted_dell_url(canonical):
            return False
        if is_sitemap_url(canonical):
            return True
        if is_pdf_url(canonical):
            return True
        if is_supported_document_url(canonical):
            return bool(self.config.process_office_documents or is_caption_url(canonical) or is_public_data_url(canonical))
        if is_public_data_url(canonical):
            return bool(self.config.process_public_api_gets)
        if is_binary_asset_url(canonical):
            return bool(self.config.record_binary_asset_metadata)
        path = urlparse(canonical).path.lower()
        if "/myaccount/" in path:
            return bool(
                getattr(self.config, "include_authenticated_account_knowledge", False)
                and bool(self._auth_status.get("authenticated"))
                and safe_authenticated_account_url(canonical)
            )
        if not self.config.include_support_content and path.startswith("/support/"):
            return False
        if not self.config.include_blog_content and path.startswith(f"/{normalize_locale(str(getattr(getattr(self, 'config', None), 'locale', 'en-uk') or 'en-uk'))}/blog"):
            return False
        return is_locale_scope(
            canonical,
            locale=str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk"),
            allow_cross_dell_assets=bool(self.config.include_linked_dell_ecosystem),
            include_community_feedback=bool(self.config.include_community_feedback),
        )

    def _robots_allowed(self, url: str) -> bool:
        canonical = canonicalize_url(url)
        # Authenticated My Account pages are explicitly requested by the signed-in
        # user and are navigated through their own interactive browser session.
        # Public robots policy still governs the anonymous/public crawl, but it must
        # not silently suppress user-authorized read-only account pages after SSO.
        if (
            canonical
            and "/myaccount/" in urlparse(canonical).path.lower()
            and bool(self._auth_status.get("authenticated"))
            and safe_authenticated_account_url(canonical)
        ):
            return True
        if not self.config.respect_robots:
            return True
        return self.robots.allowed(url)

    def _seed(self) -> int:
        urls = list(self.config.start_urls or seed_urls_for_scope(self.config.scope_name, locale=self.config.locale))
        if bool(self._auth_status.get("authenticated")):
            urls.extend(self._authenticated_account_urls)
        urls.extend(self._masthead_seed_urls)
        urls = list(dict.fromkeys(urls))
        count = 0
        origins: set[str] = set()
        account_seed_set = {canonicalize_url(value) for value in self._authenticated_account_urls}
        masthead_seed_set = {canonicalize_url(value) for value in self._masthead_seed_urls}
        for index, raw in enumerate(urls):
            url = canonicalize_url(raw)
            if not self._scope_allowed(url):
                continue
            relation = "AUTH_ACCOUNT_SEED" if url in account_seed_set else ("MASTHEAD_DISCOVERED" if url in masthead_seed_set else "SEED")
            added = int(self.store.enqueue(url, depth=0, priority=min(10, index + 1), relation=relation))
            count += added
            if added and url in account_seed_set:
                self.stats.authenticated_account_pages_seeded += 1
            if added and url in masthead_seed_set:
                self.stats.masthead_menu_urls_seeded += 1
            parsed = urlparse(url)
            if parsed.scheme and parsed.netloc:
                origins.add(f"{parsed.scheme}://{parsed.netloc}")

        # Robots.txt often declares sitemap indexes that are not linked by the
        # human-readable Dell sitemap. Queue these indexes before normal pages.
        if self.config.discover_robots_sitemaps:
            for origin in sorted(origins):
                for sitemap in self.robots.sitemap_urls(origin + "/"):
                    if not is_sitemap_url(sitemap):
                        continue
                    count += int(self.store.enqueue(
                        sitemap, depth=0, priority=0, parent_url=origin + "/robots.txt", relation="ROBOTS_DECLARES_SITEMAP"
                    ))
                    self.stats.robots_sitemaps_discovered += 1
        return count

    @staticmethod
    def _merge_links(*groups: list[DiscoveredLink]) -> list[DiscoveredLink]:
        merged: dict[str, DiscoveredLink] = {}
        for group in groups:
            for link in group:
                existing = merged.get(link.url)
                if existing is None or link.priority < existing.priority:
                    merged[link.url] = link
                elif existing and not existing.label and link.label:
                    existing.label = link.label
        return sorted(merged.values(), key=lambda x: (x.priority, x.url))

    @staticmethod
    def _int_attr(value: Any) -> int:
        try:
            return int(str(value or "").strip().split(".")[0])
        except Exception:
            return 0

    @staticmethod
    def _best_image_source(tag: Any) -> str:
        for key in ("data-src", "data-original", "data-lazy-src", "src"):
            value = str(tag.get(key) or "").strip()
            if value and not value.startswith("data:"):
                return value
        srcset = str(tag.get("data-srcset") or tag.get("srcset") or "").strip()
        if srcset:
            candidates = []
            for part in srcset.split(","):
                bits = part.strip().split()
                if not bits:
                    continue
                score = 0
                if len(bits) > 1:
                    try:
                        score = int(re.sub(r"\D", "", bits[-1]) or 0)
                    except Exception:
                        score = 0
                candidates.append((score, bits[0]))
            if candidates:
                return max(candidates, key=lambda item: item[0])[1]
        return ""

    def _http_links(self, url: str) -> tuple[list[DiscoveredLink], dict[str, Any]]:
        links: list[DiscoveredLink] = []
        metadata: dict[str, Any] = {}
        try:
            response = self.http.get(url)
            content_type = response.headers.get("content-type", "")
            metadata.update(
                {
                    "http_status": response.status_code,
                    "content_type": content_type,
                    "etag": response.headers.get("etag", ""),
                    "last_modified": response.headers.get("last-modified", ""),
                    "http_final_url": str(response.url),
                }
            )
            if response.status_code >= 400 or "html" not in content_type.lower():
                return links, metadata
            soup = BeautifulSoup(response.text, "html.parser")
            canonical_tag = soup.find("link", rel=lambda value: value and "canonical" in value)
            if canonical_tag and canonical_tag.get("href"):
                metadata["html_canonical"] = canonicalize_url(str(canonical_tag.get("href")), url)
            description = soup.find("meta", attrs={"name": re.compile("description", re.I)})
            if description and description.get("content"):
                metadata["meta_description"] = str(description.get("content"))[:1000]

            structured_data: list[Any] = []
            for script in soup.find_all("script", attrs={"type": re.compile(r"application/ld\+json", re.I)}):
                raw = script.string or script.get_text(" ", strip=True)
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except Exception:
                    continue
                structured_data.append(data)
                if len(structured_data) >= 50:
                    break
            if structured_data:
                metadata["structured_data"] = structured_data

            seen: set[str] = set()
            for anchor in soup.find_all("a", href=True):
                href = canonicalize_url(str(anchor.get("href")), url)
                if not href or href in seen:
                    continue
                seen.add(href)
                label = " ".join(anchor.stripped_strings)
                label = label or str(anchor.get("aria-label") or anchor.get("title") or href)
                links.append(
                    DiscoveredLink(
                        label=re.sub(r"\s+", " ", label).strip()[:500],
                        url=href,
                        source="http_html",
                        relation="HAS_ENDPOINT",
                        priority=priority_for_url(href, label),
                        resource_kind=resource_kind(label, href),
                    )
                )

            embedded_resources: list[str] = []
            if self.config.discover_embedded_documents:
                # Dell resource launchers frequently keep brochure/PDF URLs in
                # data-* attributes, iframes, objects, embeds, or inline scripts
                # instead of ordinary anchors. Discover all of those endpoints.
                candidate_attrs = (
                    "data-href", "data-url", "data-link", "data-download-url",
                    "data-resource-url", "data-pdf", "src", "href",
                )
                for tag in soup.find_all(True):
                    for attr in candidate_attrs:
                        raw_value = str(tag.get(attr) or "").strip()
                        if not raw_value:
                            continue
                        low = raw_value.lower()
                        if not re.search(r"\.(?:pdf|docx?|pptx?|xlsx?|csv|txt|xml|json)(?:$|[?#])", low):
                            continue
                        candidate = canonicalize_url(raw_value, url)
                        if candidate and candidate not in seen:
                            seen.add(candidate)
                            label = re.sub(
                                r"\s+", " ",
                                " ".join(tag.stripped_strings)
                                or str(tag.get("aria-label") or tag.get("title") or "Embedded Dell resource"),
                            ).strip()[:500]
                            links.append(
                                DiscoveredLink(
                                    label=label or "Embedded Dell resource",
                                    url=candidate,
                                    source="http_embedded_attribute",
                                    relation="HAS_DOCUMENT",
                                    priority=priority_for_url(candidate, label),
                                    resource_kind=resource_kind(label, candidate),
                                )
                            )
                            embedded_resources.append(candidate)
                for candidate in discover_resource_urls_from_html(response.text, url):
                    canonical = canonicalize_url(candidate, url)
                    if not canonical or canonical in seen:
                        continue
                    seen.add(canonical)
                    links.append(
                        DiscoveredLink(
                            label="Dell embedded document",
                            url=canonical,
                            source="http_embedded_script",
                            relation="HAS_DOCUMENT",
                            priority=priority_for_url(canonical, "embedded document"),
                            resource_kind=resource_kind("embedded document", canonical),
                        )
                    )
                    embedded_resources.append(canonical)
            metadata["embedded_resource_urls"] = embedded_resources
            metadata["embedded_resource_count"] = len(embedded_resources)

            visual_assets: list[dict[str, Any]] = []
            visual_seen: set[str] = set()
            for tag in soup.find_all(["img", "source"]):
                raw_src = self._best_image_source(tag)
                if not raw_src:
                    continue
                source_url = canonicalize_url(raw_src, url)
                if not source_url or source_url in visual_seen or not is_trusted_dell_url(source_url):
                    continue
                visual_seen.add(source_url)
                alt = re.sub(
                    r"\s+",
                    " ",
                    str(tag.get("alt") or tag.get("aria-label") or tag.get("title") or ""),
                ).strip()
                width = self._int_attr(tag.get("width") or tag.get("data-width"))
                height = self._int_attr(tag.get("height") or tag.get("data-height"))
                low = f"{source_url} {alt}".lower()
                decorative = bool(
                    re.search(r"\b(?:logo|icon|sprite|avatar|flag|spinner|loading|pixel|tracking|chevron|arrow)\b", low)
                )
                tiny = bool(width and height and (width < 180 or height < 120))
                visual_assets.append(
                    {
                        "kind": "html_image",
                        "source_url": source_url,
                        "alt": alt,
                        "width": width,
                        "height": height,
                        "vision_candidate": not decorative and not tiny,
                    }
                )
            metadata["visual_assets"] = visual_assets
            metadata["image_count"] = len(visual_assets)
            metadata["vision_candidate_image_count"] = sum(
                1 for item in visual_assets if item.get("vision_candidate")
            )

            if self.config.enrich_html_structure:
                enrichment = analyse_html_document(response.text, str(response.url))
                metadata["html_enrichment"] = enrichment
                metadata["structured_evidence_text"] = structured_evidence_to_text(enrichment)
                metadata["structured_data"] = enrichment.get("json_ld", structured_data)
                enrichment_seen = {link.url for link in links}
                for item in [*(enrichment.get("links") or []), *(enrichment.get("resources") or [])]:
                    if not isinstance(item, dict):
                        continue
                    candidate = canonicalize_url(str(item.get("url") or ""), str(response.url))
                    if not candidate or candidate in enrichment_seen:
                        continue
                    enrichment_seen.add(candidate)
                    semantic_label = re.sub(r"\s+", " ", str(item.get("label") or candidate)).strip()[:1000]
                    kind = resource_kind(semantic_label, candidate)
                    relation = "HAS_DOCUMENT" if item in (enrichment.get("resources") or []) or kind != "Resource" else "HAS_ENDPOINT"
                    links.append(
                        DiscoveredLink(
                            label=semantic_label or candidate,
                            url=candidate,
                            source="html_structured_enrichment",
                            relation=relation,
                            priority=priority_for_url(candidate, semantic_label),
                            resource_kind=kind,
                        )
                    )
                for item in enrichment.get("images") or []:
                    if not isinstance(item, dict):
                        continue
                    candidate = canonicalize_url(str(item.get("url") or ""), str(response.url))
                    if not candidate or candidate in visual_seen or not is_trusted_dell_url(candidate):
                        continue
                    visual_seen.add(candidate)
                    alt = re.sub(r"\s+", " ", str(item.get("alt") or "")).strip()
                    width = self._int_attr(item.get("width"))
                    height = self._int_attr(item.get("height"))
                    low = f"{candidate} {alt}".lower()
                    decorative = bool(re.search(r"\b(?:logo|icon|sprite|avatar|flag|spinner|loading|pixel|tracking|chevron|arrow)\b", low))
                    tiny = bool(width and height and (width < 180 or height < 120))
                    visual_assets.append({
                        "kind": "structured_html_image",
                        "source_url": candidate,
                        "alt": alt,
                        "width": width,
                        "height": height,
                        "vision_candidate": not decorative and not tiny,
                    })
                metadata["visual_assets"] = self._dedupe_visual_items(visual_assets)
                metadata["image_count"] = len(metadata["visual_assets"])
                metadata["vision_candidate_image_count"] = sum(1 for item in metadata["visual_assets"] if item.get("vision_candidate"))
            return self._merge_links(links), metadata
        except Exception as exc:
            metadata["http_discovery_error"] = f"{type(exc).__name__}: {exc}"
            return links, metadata

    def _enqueue_links(self, page_url: str, depth: int, links: list[DiscoveredLink]) -> int:
        if not self.config.depth_allows_children(depth):
            return 0
        added = 0
        for link in links:
            if not self._scope_allowed(link.url):
                continue
            added += int(
                self.store.enqueue(
                    link.url,
                    depth=depth + 1,
                    priority=link.priority,
                    parent_url=page_url,
                    relation=link.relation,
                    resource_class=classify_frontier_url(link.url, link.relation),
                )
            )
        return added

    def _vision_should_capture(self, page_type: str, metadata: dict[str, Any]) -> bool:
        if not self.config.use_vision_extraction:
            return False
        mode = self.config.normalized_vision_mode()
        if mode == "off":
            return False
        if mode == "all":
            return True
        return bool(
            int(metadata.get("vision_candidate_image_count") or 0) > 0
            or page_type
            in {
                "Product",
                "ProductCatalog",
                "OfferCatalog",
                "AISolutionPage",
                "SolutionPage",
                "CustomerStory",
                "ManualOrSupport",
            }
        )

    @staticmethod
    def _dedupe_visual_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in items:
            if not isinstance(item, dict):
                continue
            marker = str(item.get("content_hash") or item.get("path") or item.get("source_url") or "").strip()
            if not marker or marker in seen:
                continue
            seen.add(marker)
            output.append(item)
        return output

    @staticmethod
    def _parse_mcp_json_detail(detail: str) -> dict[str, Any]:
        # Keep rendered-DOM parsing aligned with the runtime's live MCP result
        # decoder (including ### Result + double-encoded JSON responses).
        from .mcp_runtime import PlaywrightMCPRuntime
        return PlaywrightMCPRuntime._parse_json_detail(detail)

    def _capture_browser_structured_dom(self, source_url: str) -> dict[str, Any]:
        """Read structured evidence from the rendered DOM, shadow roots and same-origin frames."""
        if not self.config.capture_browser_structured_dom or not self.runtime.started:
            return {}
        expression = r'''JSON.stringify((() => {
          const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
          const abs = (value, base = location.href) => { try { return value ? new URL(value, base).href : ''; } catch { return ''; } };
          const attrs = ['href','src','data-src','data-href','data-url','data-link','data-download-url','data-resource-url','data-pdf','data-file','data-document','data-target-url','poster'];
          const output = {url: location.href, title: document.title, lang: document.documentElement.lang || '', canonical: document.querySelector('link[rel~="canonical"]')?.href || '', jsonLd: [], appJson: [], controls: [], resources: [], tables: [], definitions: [], images: [], headings: [], formOptions: [], captions: [], alternates: [], pagination: [], productCards: [], shadowRoots: 0, sameOriginFrames: 0};
          const seenRoots = new Set();
          const visit = (root, baseUrl, rootKind = 'document') => {
            if (!root || seenRoots.has(root)) return;
            seenRoots.add(root);
            const all = selector => { try { return [...root.querySelectorAll(selector)]; } catch { return []; } };
            all('script[type="application/ld+json"]').forEach(el => { const value = el.textContent || ''; if (value) output.jsonLd.push(value); });
            all('script[type="application/json"],script#__NEXT_DATA__,script#__NUXT_DATA__,script#__APOLLO_STATE__').forEach(el => output.appJson.push({id: el.id || '', type: el.type || '', text: el.textContent || '', rootKind}));
            all('button,[role="button"],[role="tab"],summary,a').forEach((el, index) => {
              const item = {index, tag: el.tagName.toLowerCase(), role: el.getAttribute('role') || '', label: clean(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title')), disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true', expanded: el.getAttribute('aria-expanded') || '', rootKind, attrs: {}};
              attrs.forEach(name => { const value = abs(el.getAttribute(name), baseUrl); if (value) item.attrs[name] = value; });
              if (item.label || Object.keys(item.attrs).length) output.controls.push(item);
            });
            all('a,button,iframe,embed,object,video,source,track').forEach((el, index) => {
              const item = {index, tag: el.tagName.toLowerCase(), label: clean(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('label')), rootKind, attrs: {}};
              attrs.forEach(name => { const value = abs(el.getAttribute(name), baseUrl); if (value) item.attrs[name] = value; });
              if (Object.keys(item.attrs).length) output.resources.push(item);
              if (el.tagName === 'TRACK') {
                const src = abs(el.getAttribute('src'), baseUrl); if (src) output.captions.push({src, kind: el.getAttribute('kind') || '', srclang: el.getAttribute('srclang') || '', label: el.getAttribute('label') || '', rootKind});
              }
            });
            all('table').forEach((table, index) => output.tables.push({index, rootKind, caption: clean(table.caption && table.caption.innerText), rows: [...table.rows].map(row => [...row.cells].map(cell => clean(cell.innerText || cell.textContent))).filter(row => row.some(Boolean))}));
            all('dl').forEach(dl => { let term = ''; [...dl.children].forEach(el => { if (el.tagName === 'DT') term = clean(el.innerText); else if (el.tagName === 'DD' && term) output.definitions.push({term, definition: clean(el.innerText), rootKind}); }); });
            all('img').forEach((img, index) => { const src = abs(img.currentSrc || img.src, baseUrl); if (src) output.images.push({index, src, alt: clean(img.alt || img.getAttribute('aria-label') || img.title), width: img.naturalWidth || img.width || 0, height: img.naturalHeight || img.height || 0, rootKind}); });
            all('[style*="background-image"]').forEach((el, index) => { const style = getComputedStyle(el).backgroundImage || ''; for (const match of style.matchAll(/url\(["']?([^"')]+)["']?\)/g)) { const src = abs(match[1], baseUrl); if (src) output.images.push({index, src, alt: clean(el.getAttribute('aria-label') || el.getAttribute('title')), width: el.clientWidth || 0, height: el.clientHeight || 0, rootKind, source: 'css-background'}); } });
            all('h1,h2,h3,h4,h5,h6').forEach(el => { const text = clean(el.innerText); if (text) output.headings.push({level: el.tagName.toLowerCase(), text, rootKind}); });

            // v6.8: capture each rendered product/configuration card as one
            // structured unit.  Previous versions captured names, prices and
            // specifications independently, which attached catalogue prices to
            // the page/Endpoint rather than the correct Product node.
            const lineText = el => String(el?.innerText || el?.textContent || '')
              .replace(/\r/g, '')
              .split('\n')
              .map(value => clean(value))
              .filter(Boolean)
              .join('\n');
            const productMarker = text => /(?:\bModel\s*:|\bOrder\s*Code\b|£\s*\d|Explore Options|Configure and buy|with other products|\b(?:Intel|AMD|NVIDIA|Windows 11|GB\s+(?:DDR|LPDDR|SSD)|TB\s+SSD)\b)/i.test(text || '');
            const productHref = el => {
              const direct = el?.matches?.('a[href*="/spd/"],a[href*="/apd/"]') ? el.href : '';
              if (direct) return direct;
              const anchor = el?.querySelector?.('a[href*="/spd/"],a[href*="/apd/"],a[href*="/product-details/"],a[href*="/productdetail/"],a[href*="/configuration/"]');
              return anchor?.href || '';
            };
            const explicitCardSelector = [
              'article', '[role="listitem"]', '[data-testid*="product" i]', '[data-product-id]',
              '[data-product-name]', '[class*="product-card" i]', '[class*="product-stack" i]',
              '[class*="ps-product" i]', '[class*="product-item" i]', '[class*="result-card" i]'
            ].join(',');
            const candidateRoots = new Set(all(explicitCardSelector));
            all('a,button,[role="button"]').forEach(control => {
              const label = clean(control.innerText || control.textContent || control.getAttribute('aria-label'));
              const href = abs(control.getAttribute('href'), baseUrl);
              if (!(/Explore Options|Configure and buy|View Product Page|with other products|View offer/i.test(label) || /\/(?:spd|apd|product-details?|productdetail|configuration)\//i.test(href))) return;
              let current = control;
              let best = null;
              for (let depth = 0; current && depth < 10; depth += 1, current = current.parentElement) {
                const text = lineText(current);
                if (text.length >= 30 && text.length <= 24000 && productMarker(text)) best = current;
                if (current.matches?.(explicitCardSelector) && best) break;
              }
              if (best) candidateRoots.add(best);
            });
            const productSeen = new Set();
            [...candidateRoots].forEach((card, index) => {
              const text = lineText(card);
              const href = productHref(card);
              if (!text || text.length < 30 || text.length > 24000 || !(href || productMarker(text))) return;
              const headings = [...card.querySelectorAll('h1,h2,h3,h4,h5,h6,[data-testid*="title" i],[class*="title" i]')]
                .map(el => clean(el.innerText || el.textContent))
                .filter(value => value && value.length <= 260);
              const links = [...card.querySelectorAll('a[href]')].map(el => ({
                label: clean(el.innerText || el.textContent || el.getAttribute('aria-label') || el.title),
                href: abs(el.getAttribute('href'), baseUrl)
              })).filter(item => item.href);
              const buttons = [...card.querySelectorAll('button,[role="button"]')].map(el => clean(el.innerText || el.textContent || el.getAttribute('aria-label'))).filter(Boolean);
              const images = [...card.querySelectorAll('img')].map(img => ({src: abs(img.currentSrc || img.src, baseUrl), alt: clean(img.alt || img.title), width: img.naturalWidth || img.width || 0, height: img.naturalHeight || img.height || 0})).filter(item => item.src);
              const dataAttributes = {};
              for (const attr of [...card.attributes]) {
                if (/^(?:data-|itemprop|itemscope|itemtype|aria-label)/i.test(attr.name)) dataAttributes[attr.name] = attr.value;
              }
              const name = headings.find(value => /Dell|XPS|Alienware|Inspiron|Precision|Latitude|PowerEdge|Laptop|Desktop|Workstation|Monitor/i.test(value)) || headings[0] || '';
              const order = text.match(/(?:Order\s*Code|SKU|Part\s*(?:Number|No\.?))\s*[:#]?\s*([A-Z0-9][A-Z0-9._\/-]{3,120})/i)?.[1] || '';
              const model = text.match(/\bModel\s*:\s*([A-Z0-9][A-Z0-9._\/-]{1,80})/i)?.[1] || '';
              const marker = [href, order, model, name, text.slice(0, 600)].join('|').toLowerCase();
              if (productSeen.has(marker)) return;
              productSeen.add(marker);
              output.productCards.push({index, rootKind, name, url: href, model, orderCode: order, text, headings, links, buttons, images, image: images[0]?.src || '', dataAttributes});
            });

            all('select').forEach((el, index) => output.formOptions.push({index, kind: 'select', label: clean(el.labels?.[0]?.innerText || el.getAttribute('aria-label') || el.name), options: [...el.options].map(option => ({label: clean(option.textContent), value: option.value, selected: option.selected, disabled: option.disabled})), rootKind}));
            all('input[type="radio"],input[type="checkbox"]').forEach((el, index) => output.formOptions.push({index, kind: el.type, label: clean(el.labels?.[0]?.innerText || el.getAttribute('aria-label') || el.name || el.value), value: el.value || '', checked: !!el.checked, disabled: !!el.disabled, rootKind}));
            all('link[rel="alternate"][hreflang]').forEach(el => { const href = abs(el.getAttribute('href'), baseUrl); if (href) output.alternates.push({href, hreflang: el.getAttribute('hreflang') || '', rootKind}); });
            all('link[rel="next"],link[rel="prev"],a[rel="next"],a[rel="prev"]').forEach(el => { const href = abs(el.getAttribute('href'), baseUrl); if (href) output.pagination.push({href, rel: el.getAttribute('rel') || '', label: clean(el.innerText || el.getAttribute('aria-label')), rootKind}); });
            all('*').forEach(el => { if (el.shadowRoot) { output.shadowRoots += 1; visit(el.shadowRoot, baseUrl, 'shadow'); } });
            all('iframe').forEach(frame => { try { const doc = frame.contentDocument; if (doc && frame.contentWindow.location.origin === location.origin) { output.sameOriginFrames += 1; visit(doc, frame.contentWindow.location.href, 'iframe'); } } catch {} });
          };
          visit(document, location.href, 'document');
          return output;
        })())'''
        result = self.runtime.evaluate_readonly(
            expression,
            intent="Read public Dell rendered DOM, shadow roots and same-origin frames for complete knowledge extraction",
        )
        if not result.get("ok"):
            return {"capture_error": str(result.get("detail") or result.get("status") or "browser_evaluate failed")[:4000]}
        parsed = self._parse_mcp_json_detail(str(result.get("detail") or ""))
        if parsed:
            parsed["source_url"] = source_url
            parsed["capture_mode"] = "official_playwright_mcp_recursive_dom_readonly"
            self.stats.shadow_dom_captures += int(parsed.get("shadowRoots") or 0)
            self.stats.iframe_dom_captures += int(parsed.get("sameOriginFrames") or 0)
        return parsed

    def _capture_network_inventory(self) -> dict[str, Any]:
        if not self.config.capture_network_inventory or not self.runtime.started:
            return {}
        result = self.runtime.network_requests(
            include_static=False,
            include_body=False,
            include_headers=False,
            intent="Inventory requests already made by the public Dell page; do not replay mutations",
        )
        if not result.get("ok"):
            return {"capture_error": str(result.get("detail") or result.get("status") or "network inventory failed")[:4000]}
        detail = str(result.get("detail") or "")
        urls = list(dict.fromkeys(re.findall(r"https?://[^\s)\]>]+", detail)))
        public_gets = [
            candidate for candidate in public_get_candidates(detail)
            if is_trusted_dell_url(candidate) and self._scope_allowed(candidate)
        ] if self.config.process_public_api_gets else []
        return {
            "detail": detail,
            "urls": urls,
            "request_count": len([line for line in detail.splitlines() if re.search(r"\b(?:GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b", line)]),
            "trusted_dell_urls": [url for url in urls if is_trusted_dell_url(url)],
            "public_get_candidates": list(dict.fromkeys(public_gets)),
        }

    @staticmethod
    def _browser_dom_to_text(evidence: dict[str, Any]) -> str:
        if not evidence or evidence.get("capture_error"):
            return ""
        sections: list[str] = []
        for key, title in (
            ("headings", "RENDERED HEADINGS"),
            ("tables", "RENDERED TABLES"),
            ("definitions", "RENDERED DEFINITIONS"),
            ("formOptions", "RENDERED CONFIGURATION OPTIONS"),
            ("jsonLd", "RENDERED JSON-LD"),
            ("appJson", "RENDERED APPLICATION JSON"),
            ("resources", "RENDERED RESOURCE ENDPOINTS"),
            ("captions", "RENDERED VIDEO CAPTIONS"),
            ("pagination", "RENDERED PAGINATION"),
            ("productCards", "RENDERED PRODUCT CARDS"),
        ):
            value = evidence.get(key)
            if value:
                sections.append(f"===== {title} =====\n" + json.dumps(value, ensure_ascii=False, default=str))
        return "\n\n".join(sections)

    def _merge_browser_dom_evidence(
        self,
        source_url: str,
        links: list[DiscoveredLink],
        metadata: dict[str, Any],
    ) -> tuple[list[DiscoveredLink], dict[str, Any]]:
        browser_dom = self._capture_browser_structured_dom(source_url)
        network_inventory = self._capture_network_inventory()
        metadata["browser_structured_dom"] = browser_dom
        metadata["network_inventory"] = network_inventory
        browser_links: list[DiscoveredLink] = []

        for group in ("controls", "resources"):
            for item in browser_dom.get(group) or []:
                if not isinstance(item, dict):
                    continue
                label = re.sub(r"\s+", " ", str(item.get("label") or "")).strip()[:1000]
                attrs = item.get("attrs") if isinstance(item.get("attrs"), dict) else {}
                for candidate_raw in attrs.values():
                    candidate = canonicalize_url(str(candidate_raw or ""), source_url)
                    if not candidate or not is_trusted_dell_url(candidate):
                        continue
                    kind = resource_kind(label, candidate)
                    browser_links.append(DiscoveredLink(
                        label=label or candidate,
                        url=candidate,
                        source="browser_rendered_dom",
                        relation="HAS_DOCUMENT" if is_public_resource_url(candidate) or kind != "Resource" else "HAS_ENDPOINT",
                        priority=priority_for_url(candidate, label),
                        resource_kind=kind,
                    ))

        # v6.8: product detail URLs captured inside a rendered card are
        # first-class frontier items.  They are prioritised because catalogue
        # cards often omit full memory/storage/warranty/configuration details.
        for item in browser_dom.get("productCards") or []:
            if not isinstance(item, dict):
                continue
            candidate = canonicalize_url(str(item.get("url") or ""), source_url)
            if not candidate or not is_trusted_dell_url(candidate):
                continue
            label = re.sub(r"\s+", " ", str(item.get("name") or "Dell product detail")).strip()[:1000]
            browser_links.append(DiscoveredLink(
                label=label or candidate,
                url=candidate,
                source="browser_rendered_product_card",
                relation="HAS_PRODUCT_DETAIL",
                priority=2,
                resource_kind="ProductDetail",
            ))

        for item in browser_dom.get("captions") or []:
            if not isinstance(item, dict):
                continue
            candidate = canonicalize_url(str(item.get("src") or ""), source_url)
            if candidate and is_trusted_dell_url(candidate):
                browser_links.append(DiscoveredLink(
                    label=str(item.get("label") or item.get("kind") or "Video transcript"),
                    url=candidate, source="browser_video_track", relation="HAS_TRANSCRIPT",
                    priority=8, resource_kind="Transcript",
                ))

        for item in browser_dom.get("pagination") or []:
            if not isinstance(item, dict):
                continue
            candidate = canonicalize_url(str(item.get("href") or ""), source_url)
            if candidate:
                browser_links.append(DiscoveredLink(
                    label=str(item.get("label") or item.get("rel") or "Pagination"),
                    url=candidate, source="browser_pagination", relation="PAGINATES_TO",
                    priority=10, resource_kind="Resource",
                ))

        for item in browser_dom.get("alternates") or []:
            if not isinstance(item, dict):
                continue
            hreflang = str(item.get("hreflang") or "").lower()
            if hreflang not in hreflang_aliases(str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk")):
                continue
            candidate = canonicalize_url(str(item.get("href") or ""), source_url)
            if candidate and self._scope_allowed(candidate):
                browser_links.append(DiscoveredLink(
                    label=f"Dell alternate {hreflang}", url=candidate, source="browser_hreflang",
                    relation="ALTERNATE_LOCALE", priority=25, resource_kind="Resource",
                ))

        # Only replay GET endpoints that passed a strict public/read-only filter.
        # Raw network inventory is retained as evidence but analytics/auth/cart URLs
        # are not added to the crawl frontier.
        for candidate in network_inventory.get("public_get_candidates") or []:
            canonical = sanitize_public_api_url(canonicalize_url(str(candidate), source_url))
            if canonical and is_trusted_dell_url(canonical):
                browser_links.append(DiscoveredLink(
                    label="Public Dell read-only data endpoint",
                    url=canonical, source="browser_public_get_inventory",
                    relation="PUBLIC_API_ENDPOINT", priority=9, resource_kind="PublicData",
                ))

        # Add rendered images that may exist only inside a shadow root or iframe.
        visual_assets = metadata.get("visual_assets") if isinstance(metadata.get("visual_assets"), list) else []
        visual_seen = {str(item.get("source_url") or "") for item in visual_assets if isinstance(item, dict)}
        for item in browser_dom.get("images") or []:
            if not isinstance(item, dict):
                continue
            candidate = canonicalize_url(str(item.get("src") or ""), source_url)
            if not candidate or candidate in visual_seen or not is_trusted_dell_url(candidate):
                continue
            visual_seen.add(candidate)
            width = int(item.get("width") or 0)
            height = int(item.get("height") or 0)
            alt = re.sub(r"\s+", " ", str(item.get("alt") or "")).strip()
            visual_assets.append({
                "kind": "rendered_dom_image", "source_url": candidate, "alt": alt,
                "width": width, "height": height,
                "vision_candidate": not (width and height and (width < 120 or height < 90)),
                "root_kind": item.get("rootKind", "document"),
            })
        metadata["visual_assets"] = visual_assets
        metadata["vision_candidate_image_count"] = sum(1 for item in visual_assets if item.get("vision_candidate"))
        return self._merge_links(links, browser_links), metadata

    def _capture_page(
        self,
        requested_url: str,
        label: str,
        screenshot: bool = False,
        allow_auto_vision: bool = True,
    ) -> CrawlPage:
        snap_result = self.runtime.snapshot(
            boxes=False,
            intent=f"{label}: capture deterministic Dell locale accessibility snapshot",
        )
        if not snap_result.get("ok"):
            raise RuntimeError(
                f"Playwright MCP snapshot failed [{snap_result.get('status','unknown')}]: "
                f"{str(snap_result.get('detail') or '')[:1800]}"
            )
        snapshot = str(snap_result.get("detail") or "")
        if not snapshot.strip():
            raise RuntimeError("Empty snapshot returned by Playwright MCP")
        info = extract_page_info(snapshot)
        final_url = canonicalize_url(info.url or requested_url, requested_url)
        title = info.title or final_url
        visible = extract_visible_text(snapshot)
        snapshot_links = extract_links(snapshot, final_url)
        http_links, metadata = self._http_links(final_url)
        links = self._merge_links(snapshot_links, http_links)
        links, metadata = self._merge_browser_dom_evidence(final_url, links, metadata)
        structured_text = str(metadata.get("structured_evidence_text") or "").strip()
        browser_structured_text = self._browser_dom_to_text(metadata.get("browser_structured_dom") or {})
        if structured_text:
            visible = f"{visible}\n\n===== PUBLIC HTML STRUCTURED EVIDENCE =====\n{structured_text}"
        if browser_structured_text:
            visible = f"{visible}\n\n===== RENDERED BROWSER STRUCTURED EVIDENCE =====\n{browser_structured_text}"
        controls = extract_safe_controls(snapshot, limit=None)
        page_type = classify_page(final_url, title, visible)
        archetype = archetype_for(final_url, title, visible)
        metadata["dell_page_archetype"] = ({
            "name": archetype.name,
            "expected_topics": list(archetype.expected_topics),
            "high_value_controls": list(archetype.high_value_controls),
        } if archetype else {})
        screenshot_paths: list[str] = []
        visual_evidence: list[dict[str, Any]] = []
        should_shoot = bool(
            screenshot
            or self.config.screenshot_every_page
            or (allow_auto_vision and self._vision_should_capture(page_type, metadata))
        )
        if should_shoot:
            label_slug = re.sub(r"[^a-zA-Z0-9._-]+", "_", label).strip("_")[:45] or "view"
            filename = self._safe_filename(
                f"{final_url}?capture={label_slug}&evidence={content_hash(label)[:10]}",
                ".png",
            )
            shot = self.runtime.screenshot(
                filename,
                full_page=bool(self.config.vision_full_page),
                intent=f"{label}: capture visual evidence without making a purchase or submitting data",
            )
            if shot.get("ok"):
                screenshot_path = str(Path(self.runtime.output_dir) / filename)
                screenshot_paths.append(screenshot_path)
                try:
                    evidence_hash = hashlib.sha256(Path(screenshot_path).read_bytes()).hexdigest()
                except Exception:
                    evidence_hash = content_hash(screenshot_path)
                visual_evidence.append(
                    {
                        "kind": "page_screenshot",
                        "path": screenshot_path,
                        "source_url": final_url,
                        "alt": f"{title} — {label}",
                        "content_hash": evidence_hash,
                        "vision_candidate": True,
                    }
                )
        metadata["visual_evidence"] = visual_evidence
        digest = content_hash(f"{title}\n{visible}")
        visual_assets = metadata.get("visual_assets") if isinstance(metadata.get("visual_assets"), list) else []
        return CrawlPage(
            url=requested_url,
            canonical_url=final_url,
            title=title,
            page_type=page_type,
            snapshot=snapshot,
            visible_text=visible,
            links=links,
            controls=controls,
            screenshot_path=(screenshot_paths[0] if screenshot_paths else ""),
            screenshot_paths=screenshot_paths,
            visual_assets=visual_assets,
            http_status=metadata.get("http_status"),
            content_hash=digest,
            metadata=metadata,
        )

    @staticmethod
    def _image_extension(url: str, content_type: str) -> str:
        path_suffix = Path(urlparse(url).path).suffix.lower()
        if path_suffix in {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}:
            return path_suffix
        low = (content_type or "").lower()
        if "jpeg" in low:
            return ".jpg"
        if "png" in low:
            return ".png"
        if "webp" in low:
            return ".webp"
        if "bmp" in low:
            return ".bmp"
        if "tiff" in low:
            return ".tiff"
        return ".img"

    def _asset_storage_path(self, source_url: str, extension: str = ".img") -> Path:
        """Content-addressed visual path that is safe on long Windows/OneDrive roots."""
        digest = hashlib.sha256(source_url.encode("utf-8", errors="ignore")).hexdigest()
        directory = ensure_dir(self.visual_dir / digest[:2])
        ext = extension if extension.startswith(".") else f".{extension}"
        return directory / f"{digest}{ext[:12]}"

    def _download_visual_assets(self, page: CrawlPage) -> None:
        if (
            not self.config.use_vision_extraction
            or self.config.normalized_vision_mode() == "off"
            or not self.config.download_visual_assets
        ):
            return
        evidence = list(page.metadata.get("visual_evidence") or [])
        stored = 0
        for asset in page.visual_assets:
            if not self.config.visual_asset_budget_allows(stored):
                break
            if not isinstance(asset, dict) or not asset.get("vision_candidate", True):
                continue
            source_url = str(asset.get("source_url") or "")
            if not source_url or not is_trusted_dell_url(source_url):
                continue
            try:
                response = self.http.get(
                    source_url,
                    headers={"Referer": page.canonical_url, "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"},
                )
                response.raise_for_status()
                content_type = response.headers.get("content-type", "")
                if not content_type.lower().startswith("image/"):
                    continue
                payload = response.content
                is_svg = "svg" in content_type.lower() or source_url.lower().split("?", 1)[0].endswith(".svg")
                if len(payload) < (256 if is_svg else max(1, int(self.config.min_visual_asset_bytes))):
                    continue
                extension = self._image_extension(source_url, content_type)
                path = self._asset_storage_path(source_url, extension)

                # Vector diagrams can carry architecture and port-layout evidence.
                # Render public SVGs to PNG before sending them to the vision model.
                if is_svg:
                    try:
                        import fitz  # PyMuPDF
                        svg_doc = fitz.open(stream=payload, filetype="svg")
                        pix = svg_doc[0].get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                        rendered = pix.tobytes("png")
                        path = self._asset_storage_path(source_url + "#rendered", ".png")
                        if not path.exists() or path.stat().st_size != len(rendered):
                            path.write_bytes(rendered)
                        payload = rendered
                        content_type = "image/png"
                    except Exception as exc:
                        page.metadata.setdefault("visual_warnings", []).append(
                            f"Could not render SVG visual {source_url}: {type(exc).__name__}: {exc}"
                        )
                        continue
                elif not path.exists() or path.stat().st_size != len(payload):
                    path.write_bytes(payload)

                width = int(asset.get("width") or 0)
                height = int(asset.get("height") or 0)
                if Image is not None:
                    try:
                        with Image.open(path) as image:
                            width, height = image.size
                            image.verify()
                    except Exception:
                        path.unlink(missing_ok=True)
                        continue
                if width and height and (width < 180 or height < 120):
                    path.unlink(missing_ok=True)
                    continue
                digest = hashlib.sha256(payload).hexdigest()
                item = {
                    **asset,
                    "kind": "html_image",
                    "path": str(path),
                    "content_hash": digest,
                    "width": width,
                    "height": height,
                    "bytes": len(payload),
                    "vision_candidate": True,
                }
                evidence.append(item)
                stored += 1
            except httpx.HTTPStatusError as exc:
                status_code = int(exc.response.status_code) if exc.response is not None else 0
                if status_code in {401, 403} and self.config.process_visual_assets_as_lane:
                    self.store.enqueue(
                        source_url, depth=0, priority=85, parent_url=page.canonical_url,
                        relation="VISUAL_ASSET_BROWSER_FALLBACK", resource_class=ASSET,
                        resource_key=asset_family_key(source_url),
                    )
                page.metadata.setdefault("visual_warnings", []).append(
                    f"Visual asset HTTP {status_code}; queued dedicated asset-lane fallback: {source_url}"
                )
            except Exception as exc:
                page.metadata.setdefault("visual_warnings", []).append(
                    f"Could not download visual asset {source_url}: {type(exc).__name__}: {exc}"
                )
        page.metadata["visual_evidence"] = self._dedupe_visual_items(evidence)
        page.metadata["visual_assets_downloaded"] = stored
        self.stats.visual_assets_stored += stored

    def _deep_scan_lazy_content(self, page: CrawlPage, depth: int = 0) -> CrawlPage:
        """Trigger lazy rendering without allowing one page to trap the crawl.

        The site frontier remains unlimited. This page-local loop stops when the
        bottom geometry is stable, when semantic evidence stops growing, or when
        an adaptive guard derived from document height is reached. Dell pages may
        continue changing at the bottom because of rotating banners, timers and
        accessibility-reference refreshes; those changes are handled later by
        safe-control extraction and must not block evidence persistence.
        """
        if not self.config.deep_scan_lazy_content or not self.runtime.started:
            return page

        convergence = LazyScanConvergence(
            stable_rounds_required=self.config.deep_scan_stable_rounds,
            fallback_round_guard=max(24, int(getattr(self.config, "deep_scan_fallback_round_guard", 80))),
        )
        convergence.prime(page)
        additions: list[CrawlPage] = []
        rounds = 0
        scroll_failures = 0
        capture_failures = 0
        local_recovery_limit = max(2, int(self.config.max_control_retries))
        terminal_reason = ""
        last_observation: dict[str, Any] = {}

        while not self._stopped:
            if self.config.max_deep_scan_rounds > 0 and rounds >= self.config.max_deep_scan_rounds:
                terminal_reason = "configured_round_limit"
                break
            if not self.config.emergency_action_budget_allows(rounds):
                page.metadata.setdefault("self_heal_warnings", []).append(
                    "Emergency deep-scan action breaker reached; page remains resumable."
                )
                terminal_reason = "emergency_action_breaker"
                break

            if self.config.scroll_sweep_enabled and hasattr(self.runtime, "scroll_next_viewport"):
                press = self.runtime.scroll_next_viewport(
                    intent="Deep extraction: sweep the next Dell viewport to trigger lazy content"
                )
                self.stats.scroll_sweeps += 1
            else:
                press = self.runtime.press_key(
                    "End", intent="Deep extraction: trigger Dell lazy-loaded knowledge content"
                )

            scroll_state = press.get("scroll_state") if isinstance(press.get("scroll_state"), dict) else {}
            if not press.get("ok"):
                scroll_failures += 1
                if not self.config.self_heal_enabled:
                    page.metadata.setdefault("self_heal_warnings", []).append(
                        "Deep-scan scroll failed while self-healing was disabled."
                    )
                    terminal_reason = "scroll_failed_no_self_heal"
                    break
                context = ReActContext(
                    url=page.canonical_url,
                    stage="deep_scan_scroll",
                    error=str(press.get("detail") or press.get("status") or "scroll failed"),
                    attempt=min(scroll_failures, local_recovery_limit),
                    max_attempts=local_recovery_limit,
                    runtime_started=self.runtime.started,
                    snapshot_excerpt=page.snapshot[:2500],
                    extra=press,
                )
                decision = self.healer.decide(context)
                result = self.healer.execute(self.runtime, decision, page.canonical_url)
                self._record_heal(context, decision, result)
                terminal = {HealAction.HTTP_FALLBACK, HealAction.SKIP_CONTROL, HealAction.DEFER_URL}
                if (not result.get("ok")) or decision.action in terminal or scroll_failures >= local_recovery_limit:
                    page.metadata.setdefault("self_heal_warnings", []).append(
                        f"Stopped lazy-page scrolling after {scroll_failures} bounded failures; "
                        "continuing to extraction with the evidence already captured."
                    )
                    terminal_reason = f"scroll_recovery_{str(decision.action.value).lower()}"
                    break
                continue

            scroll_failures = 0
            self.runtime.wait(max(0.8, self.config.delay_seconds), intent="Wait for lazy Dell content to settle")
            try:
                after = self._capture_page(
                    page.canonical_url,
                    f"deep_scan_round_{rounds+1}",
                    screenshot=False,
                    allow_auto_vision=False,
                )
            except Exception as exc:
                capture_failures += 1
                if not self.config.self_heal_enabled:
                    page.metadata.setdefault("self_heal_warnings", []).append(
                        f"Deep-scan capture failed while self-healing was disabled: {type(exc).__name__}: {exc}"
                    )
                    terminal_reason = "capture_failed_no_self_heal"
                    break
                context = ReActContext(
                    url=page.canonical_url,
                    stage="deep_scan_capture",
                    error=f"{type(exc).__name__}: {exc}",
                    attempt=min(capture_failures, local_recovery_limit),
                    max_attempts=local_recovery_limit,
                    runtime_started=self.runtime.started,
                    snapshot_excerpt=page.snapshot[:2500],
                )
                decision = self.healer.decide(context)
                result = self.healer.execute(self.runtime, decision, page.canonical_url)
                self._record_heal(context, decision, result)
                terminal = {HealAction.HTTP_FALLBACK, HealAction.SKIP_CONTROL, HealAction.DEFER_URL}
                if (not result.get("ok")) or decision.action in terminal or capture_failures >= local_recovery_limit:
                    page.metadata.setdefault("self_heal_warnings", []).append(
                        f"Stopped lazy-page capture after {capture_failures} bounded failures; "
                        "continuing to extraction with the evidence already captured."
                    )
                    terminal_reason = f"capture_recovery_{str(decision.action.value).lower()}"
                    break
                continue

            capture_failures = 0
            if after.canonical_url != page.canonical_url:
                if self._scope_allowed(after.canonical_url):
                    self.store.enqueue(
                        after.canonical_url,
                        depth=depth + 1,
                        priority=priority_for_url(after.canonical_url),
                        parent_url=page.canonical_url,
                        relation="LAZY_CONTENT_NAVIGATES_TO",
                    )
                self.runtime.navigate(page.canonical_url, "Return to Dell source page after lazy-content navigation")
                self.runtime.wait(1.0, intent="Wait after returning from lazy-content navigation")
                self._ensure_mutation_observer(page.canonical_url)
                terminal_reason = "lazy_navigation_detected"
                break

            additions.append(after)
            rounds += 1
            self.stats.deep_scan_rounds += 1
            last_observation = convergence.observe(after, scroll_state)
            self._emit(
                "deep_scan_observe",
                url=page.canonical_url,
                round=rounds,
                changed=bool(last_observation.get("meaningful_growth")),
                stable_rounds=int(last_observation.get("no_growth_rounds") or 0),
                converged=bool(last_observation.get("converged")),
                convergence_reason=str(last_observation.get("reason") or ""),
                at_bottom=bool(last_observation.get("at_bottom")),
                scroll_after=int(last_observation.get("scroll_after") or 0),
                document_height=int(last_observation.get("document_height") or 0),
                viewport=int(last_observation.get("viewport") or 0),
                bottom_stable_rounds=int(last_observation.get("bottom_geometry_stable_rounds") or 0),
                new_text_lines=int(last_observation.get("new_text_lines") or 0),
                new_text_chars=int(last_observation.get("new_text_chars") or 0),
                new_links=int(last_observation.get("new_links") or 0),
                new_controls=int(last_observation.get("new_controls") or 0),
                adaptive_round_guard=int(last_observation.get("adaptive_round_guard") or 0),
            )
            if last_observation.get("converged"):
                terminal_reason = str(last_observation.get("reason") or "converged")
                break

        try:
            if self.config.scroll_sweep_enabled and hasattr(self.runtime, "scroll_to_top"):
                self.runtime.scroll_to_top(intent="Return to top after convergence-driven viewport sweep")
            else:
                self.runtime.press_key("Home", intent="Return to top after convergence-driven deep scan")
        except Exception:
            pass

        merged = self._merge_page_evidence(page, additions) if additions else page
        merged.metadata["deep_scan_rounds"] = rounds
        merged.metadata["deep_scan_converged"] = bool(terminal_reason in {
            "bottom_geometry_stable", "semantic_no_growth", "adaptive_page_guard"
        })
        merged.metadata["deep_scan_terminal_reason"] = terminal_reason or "stopped"
        merged.metadata["deep_scan_last_observation"] = last_observation
        merged.metadata["deep_scan_at_bottom"] = bool(last_observation.get("at_bottom"))
        self._emit(
            "deep_scan_complete",
            url=page.canonical_url,
            rounds=rounds,
            terminal_reason=merged.metadata["deep_scan_terminal_reason"],
            at_bottom=merged.metadata["deep_scan_at_bottom"],
            evidence_snapshots=len(additions),
        )
        return merged

    def _click_control_with_react(
        self,
        *,
        base_url: str,
        page: CrawlPage,
        control: SafeControl,
        interaction_index: int,
        control_ordinal: int = 0,
    ) -> tuple[dict[str, Any], CrawlPage | None, str, bool]:
        current_control = control
        last_after: CrawlPage | None = None
        healed = False
        restart_count = 0
        max_attempts = max(1, int(self.config.max_control_retries))
        for attempt in range(1, max_attempts + 1):
            before_snapshot = page.snapshot if attempt == 1 else (
                last_after.snapshot if last_after is not None else page.snapshot
            )
            before_hash = content_hash(before_snapshot)
            before_tabs = self.runtime.tab_inventory(
                intent=f"Observe tabs before Dell control '{current_control.label}'"
            )
            mutation_before: dict[str, Any] = {}
            if self.config.dom_mutation_observer_enabled:
                mutation_before = self.runtime.read_mutation_state(
                    reset=True,
                    intent=f"Reset DOM mutation telemetry before '{current_control.label}'",
                )
                state = mutation_before.get("mutation_state") if isinstance(mutation_before.get("mutation_state"), dict) else {}
                if not mutation_before.get("ok") or not state.get("installed"):
                    self._ensure_mutation_observer(base_url)
                    mutation_before = self.runtime.read_mutation_state(
                        reset=True,
                        intent=f"Reset newly installed mutation telemetry before '{current_control.label}'",
                    )
            result = self.runtime.click(
                current_control.ref,
                current_control.label,
                intent=(
                    f"Read-only Dell locale knowledge crawl: open visible {current_control.role} "
                    f"'{current_control.label}' to capture every review, specification, offer, brochure, "
                    "use case and resource; never buy, sign in, submit, post, react, or contact sales"
                ),
            )
            mutation_after = self._wait_for_dom_settle(base_url, current_control.label)
            result["mutation_before"] = mutation_before.get("mutation_state", {}) if isinstance(mutation_before, dict) else {}
            result["mutation_after"] = mutation_after.get("mutation_state", {}) if isinstance(mutation_after, dict) else {}
            new_tab_links: list[DiscoveredLink] = []
            try:
                new_tab_links = self._capture_new_tab_resources(before_tabs, base_url, current_control.label)
            except Exception as exc:
                result.setdefault("warnings", []).append(
                    f"New-tab resource capture failed: {type(exc).__name__}: {exc}"
                )
            capture_error = ""
            try:
                after = self._capture_page(
                    base_url,
                    f"after_{current_control.action_kind}_{interaction_index}_attempt_{attempt}",
                    screenshot=bool(self.config.vision_interactions),
                    allow_auto_vision=bool(self.config.vision_interactions),
                )
                if new_tab_links:
                    after.links = self._merge_links(after.links, new_tab_links)
                    after.metadata.setdefault("control_opened_resources", []).extend(
                        item.to_dict() for item in new_tab_links
                    )
                last_after = after
                after_hash = content_hash(after.snapshot)
            except Exception as exc:
                after = None
                after_hash = ""
                capture_error = f"{type(exc).__name__}: {exc}"

            result["new_tab_links"] = [item.to_dict() for item in new_tab_links]
            made_progress = bool(
                result.get("ok")
                and after is not None
                and (after_hash != before_hash or new_tab_links)
            )
            if made_progress:
                if healed:
                    self.stats.controls_healed += 1
                status = "RESOURCE_DISCOVERED" if new_tab_links and after_hash == before_hash else "EXPANDED"
                return result, after, status, healed

            error = " | ".join(
                value for value in [
                    str(result.get("status") or ""),
                    str(result.get("detail") or ""),
                    capture_error,
                    "NO_CHANGE" if after_hash and after_hash == before_hash else "",
                ] if value
            )
            if not self.config.self_heal_enabled:
                return result, after, "FAILED_SELF_HEAL_DISABLED", False

            context = ReActContext(
                url=base_url,
                stage="safe_control_click",
                error=error,
                attempt=attempt,
                max_attempts=max_attempts,
                current_url=(after.canonical_url if after else base_url),
                control_label=current_control.label,
                control_role=current_control.role,
                before_hash=before_hash,
                after_hash=after_hash,
                same_state_count=attempt if after_hash == before_hash else 0,
                runtime_started=self.runtime.started,
                snapshot_excerpt=(after.snapshot if after else before_snapshot)[:2500],
                extra=result,
            )
            decision = self.healer.decide(context)
            if decision.action == HealAction.RESTART_MCP:
                restart_count += 1
                if restart_count > max(0, int(self.config.max_mcp_restarts)):
                    decision.action = HealAction.SKIP_CONTROL
                    decision.rationale = "Per-page MCP restart budget reached; continue with remaining controls."
                    decision.retry = False
            recovery = self.healer.execute(self.runtime, decision, base_url)
            self._record_heal(context, decision, recovery, before_hash=before_hash, after_hash=after_hash)
            healed = True

            if decision.action in {HealAction.SKIP_CONTROL, HealAction.DEFER_URL, HealAction.HTTP_FALLBACK}:
                return result, after, "SELF_HEAL_SKIPPED", healed
            if not recovery.get("ok"):
                continue

            snap = self.runtime.snapshot(
                boxes=False,
                intent="Self-heal observation: locate the same safe control using fresh accessibility references",
            )
            if snap.get("ok"):
                fresh = self.healer.find_fresh_control(
                    str(snap.get("detail") or ""),
                    current_control.label,
                    current_control.role,
                    occurrence=control_ordinal,
                )
                if fresh:
                    current_control = SafeControl(
                        label=str(fresh.get("label") or current_control.label),
                        ref=str(fresh.get("ref") or current_control.ref),
                        role=str(fresh.get("role") or current_control.role),
                        action_kind=str(fresh.get("action_kind") or current_control.action_kind),
                        priority=int(fresh.get("priority") or current_control.priority),
                        repeatable=is_repeatable_control(str(fresh.get("label") or current_control.label)),
                        review_control=is_review_control(str(fresh.get("label") or current_control.label)),
                        document_control=is_document_control(str(fresh.get("label") or current_control.label)),
                        resource_kind=resource_kind(str(fresh.get("label") or current_control.label)),
                        context=str(fresh.get("context") or current_control.context),
                    )
                    continue
            if decision.action == HealAction.RETRY_WITH_FRESH_REF:
                return result, after, "STALE_REF_NOT_FOUND", healed

        return {"ok": False, "status": "control_retry_exhausted"}, last_after, "RETRY_EXHAUSTED", healed

    def _expand_safe_controls(self, page: CrawlPage, depth: int) -> CrawlPage:
        """Exhaust every safe Dell knowledge control, including repeated loaders.

        One-shot tabs/panels are opened once. Repeatable controls such as
        ``+ Show More Reviews`` are clicked again after each fresh snapshot until
        the control disappears, becomes disabled, stops yielding evidence for the
        configured stable rounds, navigates to a queued endpoint, or cycles back to
        a previously observed carousel state. There is no normal click-count cap.
        """
        attempted: set[tuple[str, str, str]] = set()
        attempted_slots: set[tuple[str, str, int]] = set()
        attempted_stable: set[str] = set()
        completed_repeat_keys: set[str] = set()
        repeat_states: dict[str, RepeatableControlState] = {}
        current = page
        base_url = page.canonical_url
        try:
            attempted_stable.update(
                self.store.recent_completed_control_keys(
                    base_url, max_age_hours=int(self.config.control_progress_ttl_hours)
                )
            )
            completed_repeat_keys.update(
                self.store.recent_terminal_dynamic_control_keys(
                    base_url, max_age_hours=int(self.config.control_progress_ttl_hours)
                )
            )
        except Exception:
            pass
        collected: list[CrawlPage] = []
        interaction_count = 0
        dynamic_path = self._persist_dynamic_state(page, iteration=0, status="BASE")

        def stable_key(control: SafeControl, ordinal: int) -> str:
            if self.config.stable_control_context_identity and control.context:
                return semantic_control_context_key(control.role, control.label, control.context, control.action_kind)
            return f"{control.role}|{normalize_label(control.label)}|{ordinal}"

        def state_key(control: SafeControl, ordinal: int) -> str:
            return stable_key(control, ordinal)

        def control_present(control: SafeControl, ordinal: int, snapshot: str) -> bool:
            count = 0
            target_label = normalize_label(control.label)
            for candidate in extract_safe_controls(snapshot, limit=None):
                if candidate.role == control.role and normalize_label(candidate.label) == target_label:
                    if count == ordinal:
                        return True
                    count += 1
            return False

        while self.config.interaction_budget_allows(interaction_count):
            controls = extract_safe_controls(current.snapshot, limit=None)
            occurrence_counts: dict[tuple[str, str], int] = {}
            candidates: list[tuple[SafeControl, int, tuple[str, str, int], str, str]] = []
            present_repeat_keys: set[str] = set()
            link_by_ref = {link.ref: link for link in current.links if link.ref}

            for control in controls:
                semantic = (control.role, normalize_label(control.label))
                ordinal = occurrence_counts.get(semantic, 0)
                occurrence_counts[semantic] = ordinal + 1
                identity = (control.role, control.label.casefold(), control.ref)
                slot = (control.role, control.label.casefold(), ordinal)
                key = state_key(control, ordinal)
                direct_kind = ""

                repeatable = bool(self.config.exhaust_repeatable_controls and control.repeatable)
                if repeatable:
                    # v5 durable dynamic-control keys used role|label|occurrence.
                    # Honour those terminal records on resume so a completed
                    # Show More Reviews/carousel is not replayed for hours.
                    legacy_repeat_key = f"{control.role}|{normalize_label(control.label)}|{ordinal}"
                    if key in completed_repeat_keys or legacy_repeat_key in completed_repeat_keys:
                        self.stats.stable_control_dedupes += 1
                        continue
                    present_repeat_keys.add(key)
                    state = repeat_states.setdefault(
                        key,
                        RepeatableControlState(key=key, label=control.label, role=control.role),
                    )
                    if state.exhausted:
                        continue
                    if not self.config.repeatable_click_budget_allows(state.clicks):
                        state.status = "CLICK_BUDGET_REACHED"
                        state.last_detail = "Optional repeatable-control test budget reached."
                        continue
                elif identity in attempted or slot in attempted_slots or stable_key(control, ordinal) in attempted_stable:
                    self.stats.stable_control_dedupes += 1
                    continue

                # A normal href leading to another canonical URL is already a
                # complete endpoint; enqueue it directly. Fragment-only tabs and
                # JS links that canonicalise back to this page must still be clicked.
                linked = link_by_ref.get(control.ref)
                if control.role == "link" and linked is not None:
                    target = canonicalize_url(linked.url, base_url)
                    if target and target != base_url and self._scope_allowed(target):
                        direct_kind = "DIRECT_ENDPOINT"
                candidates.append((control, ordinal, slot, key, direct_kind))

            # Any previously active repeatable control that has disappeared is
            # successfully exhausted; this is the normal end state for Show More.
            for key, state in repeat_states.items():
                if not state.exhausted and key not in present_repeat_keys and state.clicks > 0:
                    state.status = "CONTROL_ABSENT"
                    state.last_detail = "Control disappeared after loading all available content."
                    self.stats.repeatable_controls_exhausted += 1
                    if hasattr(self.store, "upsert_dynamic_control"):
                        self.store.upsert_dynamic_control(base_url, state.to_dict())

            if not candidates:
                break
            if not self.config.emergency_action_budget_allows(interaction_count):
                current.metadata.setdefault("self_heal_warnings", []).append(
                    "Optional emergency action breaker reached; dynamic state is preserved for a resumed run."
                )
                break

            selection: ActionSelection = self.action_model.choose(current, candidates, repeat_states)
            self.stats.web_state_observations += 1
            self.stats.action_decisions += 1
            if selection.selected_index != 0:
                self.stats.actor_critic_reranks += 1
            if selection.used_llm_critic:
                self.stats.llm_critic_reranks += 1
            self._emit(
                "agentq_action_plan",
                url=base_url,
                selected=selection.selected.to_dict(),
                used_llm_critic=selection.used_llm_critic,
                critic_note=selection.critic_note,
                top_candidates=[item.to_dict() for item in selection.ranking[:8]],
            )
            control, control_ordinal, slot, key, direct_kind = candidates[selection.selected_index]
            identity = (control.role, control.label.casefold(), control.ref)
            stable_identity = stable_key(control, control_ordinal)
            repeat_state = repeat_states.get(key) if control.repeatable else None

            if direct_kind == "DIRECT_ENDPOINT":
                linked = link_by_ref[control.ref]
                self.store.enqueue(
                    linked.url,
                    depth=depth + 1,
                    priority=priority_for_url(linked.url, control.label),
                    parent_url=base_url,
                    relation="CONTROL_HAS_DIRECT_ENDPOINT",
                )
                attempted.add(identity)
                attempted_slots.add(slot)
                attempted_stable.add(stable_identity)
                if repeat_state is not None:
                    repeat_state.status = "DIRECT_ENDPOINT"
                    repeat_state.last_detail = linked.url
                    self.stats.repeatable_controls_exhausted += 1
                    if hasattr(self.store, "upsert_dynamic_control"):
                        self.store.upsert_dynamic_control(base_url, repeat_state.to_dict())
                self.store.record_interaction(
                    base_url,
                    control.label,
                    control.role,
                    control.action_kind,
                    "DIRECT_ENDPOINT",
                    current.content_hash,
                    current.content_hash,
                    linked.url,
                )
                direct_outcome = ActionOutcome(
                    reward=5.0 if control.document_control else 2.0,
                    success=True,
                    status="DIRECT_ENDPOINT",
                    new_text_lines=0,
                    new_text_chars=0,
                    new_links=1,
                    new_documents=1 if control.document_control else 0,
                    review_delta=0,
                    healed=False,
                    detail={"target_url": linked.url},
                )
                if self.config.agentq_action_memory_enabled:
                    self.action_model.learn(
                        run_id=self.run_id, page=current, selection=selection, outcome=direct_outcome
                    )
                    self.stats.action_memory_updates += 1
                try:
                    self.store.upsert_control_progress(
                        base_url, stable_identity, label=control.label, context=control.context,
                        action_kind=control.action_kind, status="DIRECT_ENDPOINT",
                        information_gain=direct_outcome.reward, detail=linked.url,
                    )
                except Exception:
                    pass
                self._emit(
                    "interaction",
                    url=base_url,
                    label=control.label,
                    status="DIRECT_ENDPOINT",
                    count=interaction_count,
                    healed=False,
                    action_reward=direct_outcome.reward,
                )
                continue

            if not control.repeatable:
                attempted.add(identity)
                attempted_slots.add(slot)
                attempted_stable.add(stable_identity)
            interaction_count += 1
            if control.repeatable:
                self.stats.repeatable_control_clicks += 1

            before_signature = semantic_state_signature(current.visible_text, current.links, current.controls)
            if repeat_state is not None and before_signature:
                repeat_state.seen_signatures.add(before_signature)
                repeat_state.last_signature = before_signature
            before_page = current
            before_hash = content_hash(current.snapshot)
            result, after, status, healed = self._click_control_with_react(
                base_url=base_url,
                page=current,
                control=control,
                interaction_index=interaction_count,
                control_ordinal=control_ordinal,
            )

            after_hash = content_hash(after.snapshot) if after is not None else ""
            navigated = bool(after is not None and after.canonical_url != base_url)
            if navigated:
                status = "NAVIGATED"
                if self._scope_allowed(after.canonical_url):
                    self.store.enqueue(
                        after.canonical_url,
                        depth=depth + 1,
                        priority=priority_for_url(after.canonical_url, control.label),
                        parent_url=base_url,
                        relation="CONTROL_NAVIGATES_TO",
                    )
                if repeat_state is not None:
                    repeat_state.clicks += 1
                    repeat_state.status = "NAVIGATED"
                    repeat_state.last_detail = after.canonical_url
                    self.stats.repeatable_controls_exhausted += 1
                self.runtime.navigate(base_url, "Return to the source Dell locale page after read-only resource navigation")
                self.runtime.wait(1.0, intent="Wait after returning to source page")
                self._ensure_mutation_observer(base_url)
                try:
                    current = self._capture_page(
                        base_url,
                        "returned_to_source",
                        screenshot=False,
                        allow_auto_vision=False,
                    )
                except Exception:
                    current = page
            elif after is not None:
                current = after
                collected.append(after)
                dynamic_path = self._persist_dynamic_state(
                    after,
                    control=control,
                    iteration=interaction_count,
                    status=status,
                ) or dynamic_path

                if repeat_state is not None:
                    after_signature = semantic_state_signature(after.visible_text, after.links, after.controls)
                    changed = bool(after_signature != before_signature or result.get("new_tab_links"))
                    repeat_status = repeat_state.observe(
                        after_signature,
                        changed=changed,
                        stable_rounds_required=self.config.repeatable_control_stable_rounds,
                    )
                    repeat_state.last_detail = str(result.get("detail") or status)[:1000]
                    if not control_present(control, control_ordinal, after.snapshot):
                        repeat_state.status = "CONTROL_ABSENT"
                        repeat_status = repeat_state.status
                    if repeat_state.exhausted:
                        self.stats.repeatable_controls_exhausted += 1
                    status = f"{status}|{repeat_status}"
            elif repeat_state is not None:
                repeat_state.clicks += 1
                repeat_state.no_progress_rounds += 1
                repeat_state.status = (
                    "FAILED" if repeat_state.no_progress_rounds >= self.config.repeatable_control_stable_rounds
                    else "NO_PROGRESS"
                )
                repeat_state.last_detail = str(result.get("detail") or status)[:1000]
                if repeat_state.exhausted:
                    self.stats.repeatable_controls_exhausted += 1

            if repeat_state is not None and hasattr(self.store, "upsert_dynamic_control"):
                self.store.upsert_dynamic_control(base_url, repeat_state.to_dict())

            action_outcome = self.action_model.evaluate_outcome(
                before_page, after, control, status, result=result, healed=healed
            )
            if self.config.agentq_action_memory_enabled:
                self.action_model.learn(
                    run_id=self.run_id, page=before_page, selection=selection, outcome=action_outcome
                )
                self.stats.action_memory_updates += 1

            if not control.repeatable and action_outcome.success and status in {"EXPANDED", "RESOURCE_DISCOVERED", "NAVIGATED"}:
                try:
                    self.store.upsert_control_progress(
                        base_url, stable_identity, label=control.label, context=control.context,
                        action_kind=control.action_kind, status=status,
                        information_gain=action_outcome.reward, detail=str(result.get("detail") or ""),
                    )
                except Exception:
                    pass

            self.store.record_interaction(
                base_url,
                control.label,
                control.role,
                control.action_kind,
                status,
                before_hash,
                after_hash,
                str(result.get("detail") or "") + (" | self-healed" if healed else ""),
            )
            self._emit(
                "interaction",
                url=base_url,
                label=control.label,
                status=status,
                count=interaction_count,
                healed=healed,
                repeatable=control.repeatable,
                repeat_click=(repeat_state.clicks if repeat_state else 0),
                action_reward=action_outcome.reward,
                action_success=action_outcome.success,
                information_gain=action_outcome.to_dict(),
            )

        merged = self._merge_page_evidence(page, collected) if collected else current
        merged.metadata["safe_interactions_attempted"] = interaction_count
        merged.metadata["safe_interaction_labels"] = [
            {"role": role, "label": label, "occurrence": occurrence}
            for role, label, occurrence in sorted(attempted_slots)
        ]
        merged.metadata["repeatable_control_progress"] = {
            key: state.to_dict() for key, state in repeat_states.items()
        }
        merged.metadata["repeatable_controls_complete"] = all(
            state.exhausted for state in repeat_states.values()
        ) if repeat_states else True
        merged.metadata["dynamic_state_evidence_path"] = dynamic_path
        merged.metadata["review_metrics"] = extract_review_metrics(merged.visible_text)
        merged.canonical_url = base_url
        return merged

    def _update_structured_stats(self, page: CrawlPage) -> None:
        enrichment = page.metadata.get("html_enrichment") if isinstance(page.metadata, dict) else {}
        if isinstance(enrichment, dict) and enrichment:
            self.stats.structured_html_documents += 1
            counts = enrichment.get("counts") if isinstance(enrichment.get("counts"), dict) else {}
            self.stats.json_ld_records += len(enrichment.get("json_ld") or [])
            self.stats.faq_records_extracted += int(counts.get("faqs") or 0)
            self.stats.video_endpoints_extracted += int(counts.get("videos") or 0)
            self.stats.product_schema_records += int(counts.get("products") or 0)
            self.stats.offer_schema_records += int(counts.get("offers") or 0)
        browser_dom = page.metadata.get("browser_structured_dom") if isinstance(page.metadata, dict) else {}
        if isinstance(browser_dom, dict) and browser_dom and not browser_dom.get("capture_error"):
            self.stats.structured_dom_captures += 1
        network = page.metadata.get("network_inventory") if isinstance(page.metadata, dict) else {}
        if isinstance(network, dict):
            self.stats.network_requests_observed += int(network.get("request_count") or 0)

    def _record_extraction_quality(self, extraction: dict[str, Any]) -> None:
        if not isinstance(extraction, dict):
            return
        notes = extraction.get("normalization_notes") if isinstance(extraction.get("normalization_notes"), list) else []
        repaired = sum(
            1 for note in notes
            if any(token in str(note).casefold() for token in ("repair", "normaliz", "non-standard", "preserved"))
        )
        self.stats.normalization_repairs += repaired
        unmapped = extraction.get("unmapped_evidence") if isinstance(extraction.get("unmapped_evidence"), list) else []
        self.stats.unmapped_evidence_preserved += len(unmapped)

    def _record_coverage_outcome(self, coverage) -> None:
        self.stats.coverage_audits += 1
        if coverage.passed:
            return
        self.stats.coverage_contract_failures += 1
        if str(getattr(coverage, "status", "recoverable")) == "terminal":
            self.stats.coverage_terminal_failures += 1
        else:
            self.stats.coverage_recoverable_gaps += 1

    def _process_html(self, queue_item: dict[str, Any]) -> dict[str, int]:
        url = queue_item["url"]
        depth = int(queue_item.get("depth") or 0)
        self._emit("page_start", url=url, depth=depth)
        nav_intent = (
            "Open an authenticated read-only Dell My Account page for user-authorized knowledge extraction"
            if "/myaccount/" in urlparse(canonicalize_url(url)).path.lower()
            else "Open a public Dell locale page for read-only knowledge extraction"
        )
        nav = self.runtime.navigate(url, nav_intent)
        if not nav.get("ok"):
            raise RuntimeError(str(nav.get("detail") or "Playwright MCP navigation failed"))
        self.runtime.wait(self.config.delay_seconds, intent="Wait for Dell locale page content to render")
        self._ensure_mutation_observer(url)
        page = self._capture_page(url, "base_page", screenshot=False, allow_auto_vision=True)
        if not self._scope_allowed(page.canonical_url):
            raise RuntimeError(f"Navigation left allowed Dell locale scope: {page.canonical_url}")
        page = self._deep_scan_lazy_content(page, depth)
        page = self._expand_safe_controls(page, depth)

        assessment = self.healer.assess_completeness(
            url=page.canonical_url,
            page_type=page.page_type,
            title=page.title,
            visible_text=page.visible_text,
            links=[link.to_dict() for link in page.links],
            controls=[control.to_dict() for control in extract_safe_controls(page.snapshot, limit=None)],
            use_llm=bool(self.config.completeness_judge),
        )
        should_repeat_deep_scan = bool(
            assessment.score < 0.65
            and "SCROLL_FOR_LAZY_CONTENT" in assessment.suggested_actions
            and not (
                page.metadata.get("deep_scan_at_bottom")
                and page.metadata.get("deep_scan_terminal_reason") == "bottom_geometry_stable"
            )
        )
        if should_repeat_deep_scan:
            page = self._deep_scan_lazy_content(page, depth)
            assessment = self.healer.assess_completeness(
                url=page.canonical_url,
                page_type=page.page_type,
                title=page.title,
                visible_text=page.visible_text,
                links=[link.to_dict() for link in page.links],
                controls=[control.to_dict() for control in extract_safe_controls(page.snapshot, limit=None)],
                use_llm=bool(self.config.completeness_judge),
            )
        page.metadata["completeness_assessment"] = assessment.to_dict()
        if assessment.score < 0.5:
            self.stats.low_completeness_pages += 1
            self._emit(
                "coverage_gap",
                url=page.canonical_url,
                score=assessment.score,
                missing_topics=assessment.missing_topics,
                suggested_actions=assessment.suggested_actions,
            )
        self._update_structured_stats(page)
        self._download_visual_assets(page)
        embedded_count = int(page.metadata.get("embedded_resource_count") or 0)
        self.stats.embedded_documents_discovered += embedded_count

        # v6.13 cross-URL content de-duplication. Dell frequently exposes the
        # same rendered knowledge through campaign aliases, locale-compatible
        # links, catalog shells, and repeated navigation routes. Preserve the
        # alias page and its links, but do not spend another LLM/vision extraction
        # pass when the exact rendered evidence has already been stored.
        duplicate_source = None
        semantic_hash = stable_text_hash(page.visible_text or "")
        page.metadata["semantic_content_hash"] = semantic_hash
        if (
            bool(getattr(self.config, "exact_content_dedupe_enabled", True))
            and len(page.visible_text or "") >= int(getattr(self.config, "duplicate_content_min_chars", 400))
        ):
            # Prefer whitespace/DOM-churn-stable exact text matching. This remains
            # conservative (no fuzzy merge), but catches aliases whose title or
            # accessibility formatting changed while the knowledge is identical.
            duplicate_source = self.store.duplicate_source_for_semantic_hash(semantic_hash, page.canonical_url)
            if duplicate_source is None:
                duplicate_source = self.store.duplicate_source_for_hash(page.content_hash, page.canonical_url)
        if duplicate_source:
            duplicate_url = str(duplicate_source.get("canonical_url") or duplicate_source.get("url") or "")
            page.metadata["duplicate_content_of"] = duplicate_url
            page.metadata["duplicate_content_hash"] = page.content_hash
            extraction = {
                "extraction_mode": "exact_duplicate_content_skipped",
                "warnings": [f"Exact rendered content already extracted from {duplicate_url}"],
                "product_records": [],
                "reviews": [],
                "endpoints": [],
                "entities": [],
                "facts": [],
                "relations": [],
                "vision_evidence": [],
                "vision_text": "",
                "chunk_count": 0,
            }
            self.stats.duplicate_content_extractions_skipped += 1
            self._emit(
                "duplicate_content_skipped",
                url=page.canonical_url,
                duplicate_of=duplicate_url,
                content_hash=page.content_hash,
            )
        else:
            extraction = self.extractor.extract(page)
            self._record_extraction_quality(extraction)
        mapping_result = page.metadata.get("product_evidence_mapping") if isinstance(page.metadata, dict) else {}
        if isinstance(mapping_result, dict):
            self.stats.product_unmapped_fields_mapped += int(mapping_result.get("unmapped_fields_mapped") or 0)
        vision_text = str(extraction.get("vision_text") or "").strip()
        if vision_text:
            page.visible_text = f"{page.visible_text}\n\n===== DELL AIA VISION EVIDENCE =====\n{vision_text}"
            page.content_hash = content_hash(f"{page.title}\n{page.visible_text}")
        vision_records = extraction.get("vision_evidence") if isinstance(extraction.get("vision_evidence"), list) else []
        page.metadata["vision_evidence_count"] = len(vision_records)
        page.metadata["vision_extraction_mode"] = extraction.get("extraction_mode", "")
        page.metadata["vision_warnings"] = [
            warning for warning in extraction.get("warnings", []) if "vision" in str(warning).lower()
        ]
        self.stats.visual_evidence_analyzed += len(vision_records)
        review_records = extraction.get("reviews") if isinstance(extraction.get("reviews"), list) else []
        self.stats.reviews_extracted += len(review_records)

        product_records = extraction.get("product_records") if isinstance(extraction.get("product_records"), list) else []
        product_price_count = 0
        product_spec_count = 0
        product_scores: list[float] = []
        for record in product_records:
            if not isinstance(record, dict):
                continue
            attrs = record.get("attributes") if isinstance(record.get("attributes"), dict) else {}
            product_price_count += int(bool(attrs.get("price") or attrs.get("current_price")))
            product_spec_count += int(any(attrs.get(key) for key in (
                "processor", "graphics", "memory", "storage", "display", "operating_system"
            )))
            try:
                product_scores.append(float(attrs.get("completeness_score") or 0))
            except Exception:
                product_scores.append(0.0)
        self.stats.product_records_extracted += len(product_records)
        self.stats.product_records_with_price += product_price_count
        self.stats.product_records_with_core_specs += product_spec_count
        page.metadata["product_records_extracted"] = len(product_records)
        page.metadata["product_records_with_price"] = product_price_count
        page.metadata["product_records_with_core_specs"] = product_spec_count
        page.metadata["product_price_coverage"] = round(product_price_count / len(product_records), 4) if product_records else 0.0
        page.metadata["product_spec_coverage"] = round(product_spec_count / len(product_records), 4) if product_records else 0.0
        page.metadata["product_best_completeness"] = round(max(product_scores, default=0.0), 4)
        if extraction.get("document_summary") or (
            isinstance(extraction.get("page"), dict) and extraction.get("page", {}).get("summary")
        ):
            if page.page_type == "Document":
                self.stats.documents_summarized += 1
        stored_review_count = self.store.review_count_for_page(page.canonical_url)
        page.metadata["reviews_extracted_local"] = len(review_records)
        page.metadata["reviews_extracted_from_related_resources"] = stored_review_count
        page.metadata["reviews_extracted"] = max(len(review_records), stored_review_count)
        page.metadata["long_form_chunk_count"] = int(extraction.get("chunk_count") or 0)
        page.metadata["document_summary_present"] = bool(extraction.get("document_summary"))

        coverage = audit_page(page, minimum_score=self.config.minimum_page_coverage)
        page.metadata["coverage_contract"] = coverage.to_dict()
        self._record_coverage_outcome(coverage)
        if not coverage.passed:
            self._emit(
                "coverage_contract_gap", url=page.canonical_url, score=coverage.score,
                missing_topics=coverage.missing_topics, gaps=coverage.gaps,
                suggested_actions=coverage.suggested_actions,
            )

        raw_path = self._write_raw(page)
        page.metadata["raw_path"] = str(raw_path)
        counts = self.store.ingest_page(page)
        if duplicate_source:
            duplicate_url = str(duplicate_source.get("canonical_url") or duplicate_source.get("url") or "")
            if duplicate_url and duplicate_url != page.canonical_url:
                alias_edge = self.store.upsert_edge(
                    f"url:{page.canonical_url}",
                    "DUPLICATE_CONTENT_OF",
                    f"url:{duplicate_url}",
                    page.canonical_url,
                )
                counts["edges_created"] = counts.get("edges_created", 0) + int(alias_edge)
        self.store.upsert_source(
            page.canonical_url,
            page.canonical_url,
            page.title,
            page.page_type,
            page.content_hash,
            page.http_status,
            page.screenshot_path,
            str(raw_path),
            "text/html",
            page.metadata,
        )
        extracted_counts = self.store.ingest_extraction(page.canonical_url, extraction)
        for key, value in extracted_counts.items():
            counts[key] = counts.get(key, 0) + value
        added = self._enqueue_links(page.canonical_url, depth, page.links)
        # Product endpoints emitted from JSON-LD or coherent card extraction are
        # also durable frontier items even when the corresponding href was hidden
        # behind a React control and absent from the accessibility link list.
        extracted_product_links: list[DiscoveredLink] = []
        for endpoint in extraction.get("endpoints") or []:
            if not isinstance(endpoint, dict):
                continue
            endpoint_url = canonicalize_url(str(endpoint.get("url") or ""), page.canonical_url)
            relation = str(endpoint.get("relation") or "")
            kind = str(endpoint.get("resource_kind") or "")
            if not endpoint_url or not (relation == "HAS_PRODUCT_DETAIL" or kind == "ProductDetail"):
                continue
            extracted_product_links.append(DiscoveredLink(
                label=str(endpoint.get("label") or "Dell product detail"),
                url=endpoint_url, source=str(endpoint.get("source") or "product_intelligence"),
                relation="HAS_PRODUCT_DETAIL", priority=int(endpoint.get("priority") or 2),
                resource_kind="ProductDetail",
            ))
        product_links_added = self._enqueue_links(page.canonical_url, depth, extracted_product_links)
        self.stats.product_detail_urls_enqueued += int(product_links_added)
        added += product_links_added
        counts["links_enqueued"] = added
        counts["product_records"] = len(product_records)
        counts["product_records_with_price"] = product_price_count
        counts["product_records_with_core_specs"] = product_spec_count

        base_score = float(
            min(assessment.score, coverage.score) if self.config.coverage_contract_enabled else assessment.score
        )
        product_score = 1.0
        if duplicate_source:
            product_score = 1.0
        elif self.config.product_detail_completion_enabled and page.page_type in {"Product", "ProductCatalog", "OfferCatalog"}:
            if not product_records:
                product_score = 0.25
            elif page.page_type in {"ProductCatalog", "OfferCatalog"}:
                price_coverage = product_price_count / len(product_records)
                spec_coverage = product_spec_count / len(product_records)
                product_score = min(1.0, 0.45 + 0.40 * price_coverage + 0.15 * spec_coverage)
                if self.config.product_require_price_on_commerce_pages and "£" in page.visible_text and product_price_count == 0:
                    product_score = min(product_score, 0.35)
            else:
                product_score = max(product_scores, default=0.0)
                if self.config.product_require_price_on_commerce_pages and "£" in page.visible_text and product_price_count == 0:
                    product_score = min(product_score, 0.45)
            if product_score < float(self.config.product_min_completeness):
                self.stats.product_completeness_failures += 1
                self._emit(
                    "product_completeness_gap", url=page.canonical_url, page_type=page.page_type,
                    products=len(product_records), products_with_price=product_price_count,
                    products_with_core_specs=product_spec_count, score=round(product_score, 4),
                )
        counts["_product_completeness_score"] = round(product_score, 4)
        counts["_completeness_score"] = float(min(base_score, product_score))
        if page.page_type == "AuthenticatedAccountKnowledge":
            self.stats.authenticated_account_pages_stored += 1
        self._emit(
            "page_done",
            url=page.canonical_url,
            title=page.title,
            page_type=page.page_type,
            links=len(page.links),
            controls=len(page.controls),
            visual_assets=len(page.metadata.get("visual_evidence") or []),
            counts=counts,
            extraction_mode=extraction.get("extraction_mode"),
            warnings=extraction.get("warnings", []),
        )
        return counts

    def _pdf_links_from_text(self, text: str, base_url: str) -> list[DiscoveredLink]:
        links: list[DiscoveredLink] = []
        seen: set[str] = set()
        for match in re.finditer(r"https?://[^\s<>()\[\]{}\"']+", text or "", re.I):
            url = canonicalize_url(match.group(0).rstrip(".,;:"), base_url)
            if not url or url in seen:
                continue
            seen.add(url)
            links.append(
                DiscoveredLink(
                    label="URL found in PDF",
                    url=url,
                    source="pdf_text",
                    relation="REFERENCES",
                    priority=priority_for_url(url),
                    resource_kind=resource_kind("URL found in PDF", url),
                )
            )
        return links

    def _render_pdf_visual_pages(
        self,
        pdf_path: Path,
        source_url: str,
        page_texts: list[str],
    ) -> tuple[list[dict[str, Any]], list[str]]:
        evidence: list[dict[str, Any]] = []
        warnings: list[str] = []
        if (
            not self.config.use_vision_extraction
            or not self.config.vision_pdf_pages
            or self.config.normalized_vision_mode() == "off"
        ):
            return evidence, warnings
        try:
            import fitz  # PyMuPDF
        except Exception as exc:
            return evidence, [f"PDF visual rendering unavailable: {type(exc).__name__}: {exc}"]

        try:
            document = fitz.open(str(pdf_path))
            scale = max(1.0, float(self.config.pdf_render_dpi) / 72.0)
            matrix = fitz.Matrix(scale, scale)
            for index in range(document.page_count):
                pdf_page = document.load_page(index)
                image_count = len(pdf_page.get_images(full=True))
                try:
                    drawing_count = len(pdf_page.get_drawings())
                except Exception:
                    drawing_count = 0
                text_len = len((page_texts[index] if index < len(page_texts) else "").strip())
                mode = self.config.normalized_vision_mode()
                # Auto mode remains exhaustive for information: all text is parsed,
                # while vision is reserved for pages that actually contain raster
                # images, vector diagrams/charts, or too little extractable text.
                should_render = bool(
                    self.config.vision_pdf_every_page
                    or mode == "all"
                    or image_count > 0
                    or drawing_count >= 8
                    or text_len < 240
                )
                if not should_render:
                    continue
                pixmap = pdf_page.get_pixmap(matrix=matrix, alpha=False)
                filename = self._safe_filename(
                    f"{source_url}?pdf_page={index+1}&dpi={self.config.pdf_render_dpi}",
                    ".png",
                )
                path = self.pdf_visual_dir / filename
                pixmap.save(str(path))
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                evidence.append(
                    {
                        "kind": "pdf_page",
                        "path": str(path),
                        "source_url": source_url,
                        "alt": f"Rendered PDF page {index+1}",
                        "page_number": index + 1,
                        "pdf_image_count": image_count,
                        "pdf_vector_drawing_count": drawing_count,
                        "extracted_text_chars": text_len,
                        "content_hash": digest,
                        "vision_candidate": True,
                    }
                )
                if (index + 1) % 5 == 0 or index + 1 == document.page_count:
                    self._emit(
                        "pdf_visual_progress",
                        url=source_url,
                        rendered_pages=index + 1,
                        total_pages=document.page_count,
                    )
            document.close()
        except Exception as exc:
            warnings.append(f"PDF visual rendering failed: {type(exc).__name__}: {exc}")
        self.stats.pdf_pages_visualized += len(evidence)
        return evidence, warnings

    def _process_sitemap(self, queue_item: dict[str, Any]) -> dict[str, int]:
        url = queue_item["url"]
        depth = int(queue_item.get("depth") or 0)
        self._emit("sitemap_start", url=url, depth=depth)
        response = self.http.get(url)
        response.raise_for_status()
        root = ET.fromstring(response.content)
        locations: list[str] = []
        for element in root.iter():
            if element.tag.lower().endswith("loc") and element.text:
                candidate = canonicalize_url(element.text.strip(), url)
                if candidate and candidate not in locations:
                    locations.append(candidate)

        links: list[DiscoveredLink] = []
        for candidate in locations:
            if not self._scope_allowed(candidate):
                continue
            links.append(
                DiscoveredLink(
                    label="Dell sitemap entry",
                    url=candidate,
                    source="xml_sitemap",
                    relation="SITEMAP_CONTAINS",
                    priority=0 if is_sitemap_url(candidate) else priority_for_url(candidate),
                )
            )
        page = CrawlPage(
            url=url,
            canonical_url=canonicalize_url(str(response.url), url),
            title=f"Dell sitemap: {urlparse(url).path}",
            page_type="Sitemap",
            snapshot="",
            visible_text="\n".join(link.url for link in links),
            links=links,
            controls=[],
            http_status=response.status_code,
            content_hash=content_hash(response.text),
            metadata={
                "mime_type": response.headers.get("content-type", "application/xml"),
                "sitemap_entries_total": len(locations),
                "sitemap_entries_in_scope": len(links),
                "last_modified": response.headers.get("last-modified", ""),
                "etag": response.headers.get("etag", ""),
            },
        )
        counts = self.store.ingest_page(page)
        counts["links_enqueued"] = self._enqueue_links(page.canonical_url, depth, links)
        self.store.upsert_source(
            page.canonical_url,
            page.canonical_url,
            page.title,
            page.page_type,
            page.content_hash,
            page.http_status,
            "",
            "",
            page.metadata["mime_type"],
            page.metadata,
        )
        self._emit(
            "sitemap_done",
            url=page.canonical_url,
            total=len(locations),
            in_scope=len(links),
            counts=counts,
        )
        return counts

    def _pdf_log_path(self, attr_name: str, filename: str) -> Path:
        """Return a durable runtime log path without ever defaulting to the code directory.

        Production crawlers configure ``output_dir`` and explicit PDF log paths.
        Lightweight tests and diagnostics sometimes construct the crawler without
        running ``__init__``; historically those code paths wrote JSONL files into
        the source/package root.  Use a temp runtime folder as the final fallback so
        verification can never mutate the shipped release.
        """
        explicit = getattr(self, attr_name, None)
        if explicit:
            return Path(explicit)
        output_dir = getattr(self, "output_dir", None)
        if output_dir:
            return Path(output_dir) / filename
        fallback = Path(tempfile.gettempdir()) / "dell_crawler_runtime"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback / filename

    def _record_pdf_transport_event(self, url: str, stage: str, error: str = "", **extra: Any) -> None:
        """Record a recoverable PDF transport event.

        Direct HTTP 401/403 responses are common for Dell document CDN URLs.
        They are diagnostics, not terminal failures, because the crawler then
        switches to the persistent Playwright browser and PDF-viewer pipeline.
        """
        self.stats.pdf_transport_events += 1
        record = {
            "timestamp": _now(),
            "run_id": self.run_id,
            "url": url,
            "stage": stage,
            "error": str(error)[:6000],
            "terminal": False,
            **extra,
        }
        append_jsonl(self._pdf_log_path("pdf_transport_log", "PDF_TRANSPORT_EVENTS.jsonl"), record)
        self._emit("pdf_transport_event", url=url, stage=stage, error=str(error)[:2000], **extra)

    def _ensure_pdf_validation_state(self) -> None:
        if not hasattr(self, "_pdf_validation_rejection_keys"):
            self._pdf_validation_rejection_keys = set()
        if not hasattr(self, "_pdf_validation_rejection_urls"):
            self._pdf_validation_rejection_urls = set()
        if not hasattr(self, "_pdf_terminal_validation_urls"):
            self._pdf_terminal_validation_urls = set()

    def _record_pdf_recovery(self, url: str, strategy: str, **extra: Any) -> None:
        self._ensure_pdf_validation_state()
        self.stats.pdf_recoveries += 1
        if url in self._pdf_validation_rejection_urls:
            self.stats.pdf_validation_recovered += 1
            extra = {**extra, "recovered_after_validation_rejection": True}
            self._pdf_validation_rejection_urls.discard(url)
        record = {
            "timestamp": _now(),
            "run_id": self.run_id,
            "url": url,
            "strategy": strategy,
            "terminal": False,
            **extra,
        }
        append_jsonl(self._pdf_log_path("pdf_recovery_log", "PDF_RECOVERIES.jsonl"), record)
        self._emit("pdf_recovered", url=url, strategy=strategy, **extra)

    def _record_pdf_success(self, url: str, strategy: str, **extra: Any) -> None:
        self._ensure_pdf_validation_state()
        self.stats.pdf_successes += 1
        if url in self._pdf_validation_rejection_urls:
            self.stats.pdf_validation_recovered += 1
            extra = {**extra, "recovered_after_validation_rejection": True}
            self._pdf_validation_rejection_urls.discard(url)
        record = {
            "timestamp": _now(),
            "run_id": self.run_id,
            "url": url,
            "strategy": strategy,
            "terminal": True,
            "status": "DONE",
            **extra,
        }
        append_jsonl(self._pdf_log_path("pdf_success_log", "PDF_SUCCESSES.jsonl"), record)
        self._emit("pdf_success", url=url, strategy=strategy, **extra)

    def _record_pdf_validation_rejection(
        self,
        url: str,
        stage: str,
        reason: str,
        *,
        path: Path | None = None,
        quarantined_path: Path | None = None,
        **extra: Any,
    ) -> None:
        """Record a recoverable candidate rejection exactly once.

        A bad HTML response, incomplete browser download, stale partial, or
        unrelated network body is evidence that one acquisition candidate was
        rejected. It is not a final PDF failure while other strategies remain.
        """
        self._ensure_pdf_validation_state()
        path_text = str(path or "")
        try:
            stat_key = f"{Path(path).resolve()}|{Path(path).stat().st_size}" if path and Path(path).exists() else path_text
        except OSError:
            stat_key = path_text
        key = hashlib.sha256(
            f"{url}|{stage}|{reason}|{stat_key}".encode("utf-8", errors="ignore")
        ).hexdigest()
        if key in self._pdf_validation_rejection_keys:
            return
        self._pdf_validation_rejection_keys.add(key)
        self._pdf_validation_rejection_urls.add(url)
        self.stats.pdf_validation_rejections += 1
        record = {
            "timestamp": _now(),
            "run_id": self.run_id,
            "url": url,
            "stage": stage,
            "reason": str(reason)[:6000],
            "terminal": False,
            "recoverable": True,
            "path": path_text,
            "quarantined_path": str(quarantined_path or ""),
            **extra,
        }
        append_jsonl(self._pdf_log_path("pdf_validation_log", "PDF_VALIDATION_REJECTIONS.jsonl"), record)
        self._emit("pdf_validation_rejected", url=url, stage=stage, reason=str(reason)[:2000], recoverable=True, **extra)

    def _record_pdf_failure(self, url: str, stage: str, error: str, **extra: Any) -> None:
        """Record only a terminal PDF failure after all recovery paths fail."""
        self._ensure_pdf_validation_state()
        self.stats.pdf_download_failures += 1
        stage_low = str(stage).casefold()
        error_low = str(error).casefold()
        is_validation = bool(
            "validation" in stage_low
            or "documentvalidationerror" in error_low
            or "invalid pdf" in error_low
            or "pdf validation" in error_low
            or "validated binary" in error_low
            or "missing %pdf" in error_low
            or "pdf has no pages" in error_low
            or "pypdf could not open" in error_low
            or "neither text nor visual evidence" in error_low
        )
        if is_validation and url not in self._pdf_terminal_validation_urls:
            self._pdf_terminal_validation_urls.add(url)
            self.stats.pdf_terminal_validation_failures += 1
            self.stats.pdf_validation_failures += 1
        record = {
            "timestamp": _now(),
            "run_id": self.run_id,
            "url": url,
            "stage": stage,
            "error": str(error)[:6000],
            "terminal": True,
            "status": "DEFERRED",
            "terminal_validation_failure": is_validation,
            **extra,
        }
        append_jsonl(self._pdf_log_path("pdf_failure_log", "PDF_FAILURES.jsonl"), record)
        self._emit("pdf_terminal_failure", url=url, stage=stage, error=str(error)[:2000], terminal_validation_failure=is_validation, **extra)

    def _quarantine_invalid_document(
        self,
        path: Path,
        reason: str,
        *,
        url: str = "",
        stage: str = "candidate_validation",
    ) -> Path | None:
        """Quarantine invalid candidate bytes without counting a terminal failure."""
        if not path.exists():
            return None
        target: Path | None = None
        if not self.config.document_invalid_quarantine:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
        else:
            target = quarantine_file(path, self.document_quarantine_dir, reason)
            if target is not None:
                self.stats.pdf_invalid_files_quarantined += 1
                self._emit("pdf_invalid_quarantined", url=url, source_path=str(path), quarantine_path=str(target), reason=reason[:1000])
        self._record_pdf_validation_rejection(
            url or "unknown",
            stage,
            reason,
            path=path,
            quarantined_path=target,
        )
        return target

    def _validated_existing_pdf(self, path: Path, url: str = "") -> bool:
        validation = validate_pdf_file(path, parse_structure=True)
        if validation.ok:
            return True
        if path.exists():
            self._quarantine_invalid_document(path, validation.reason, url=url, stage="existing_file_validation")
        return False

    @staticmethod
    def _mcp_scalar_text(result: dict[str, Any]) -> str:
        return decode_mcp_text(str(result.get("detail") or "")) if isinstance(result, dict) else ""

    def _pdf_viewer_dom_text(self) -> tuple[str, str, str]:
        """Read visible PDF-viewer text from document and open shadow roots."""
        expression = r'''JSON.stringify((() => {
          const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
          const output = {url: location.href, title: document.title || '', texts: [], labels: []};
          const seen = new Set();
          const add = (bucket, value) => {
            value = clean(value);
            if (!value || seen.has(value)) return;
            seen.add(value);
            output[bucket].push(value.slice(0, 60000));
          };
          const visited = new Set();
          const visit = root => {
            if (!root || visited.has(root)) return;
            visited.add(root);
            try { add('texts', root.innerText || root.textContent || ''); } catch {}
            let all = [];
            try { all = [...root.querySelectorAll('*')]; } catch {}
            for (const el of all) {
              try {
                add('labels', el.getAttribute('aria-label') || el.getAttribute('title') || '');
                if (['INPUT','TEXTAREA','SELECT'].includes(el.tagName)) add('labels', el.value || '');
                if (el.shadowRoot) visit(el.shadowRoot);
              } catch {}
            }
          };
          visit(document);
          output.texts = output.texts.slice(0, 40);
          output.labels = output.labels.slice(0, 400);
          return output;
        })())'''
        result = self.runtime.evaluate_readonly(
            expression,
            intent="Read text and page indicators exposed by the browser PDF viewer",
        )
        if not result.get("ok"):
            return "", "", ""
        parsed = self._parse_mcp_json_detail(str(result.get("detail") or ""))
        if not parsed:
            return "", "", ""
        url = str(parsed.get("url") or "")
        title = str(parsed.get("title") or "")
        values: list[str] = []
        for key in ("texts", "labels"):
            raw = parsed.get(key)
            if isinstance(raw, list):
                values.extend(str(item) for item in raw if str(item).strip())
        return "\n".join(dedupe_text_blocks(values)), title, url

    def _browser_page_probe(self) -> dict[str, Any]:
        """Return current browser page identity without depending on tab-list parsing."""
        expression = r'''JSON.stringify((() => ({
          url: String(location.href || ''),
          title: String(document.title || ''),
          readyState: String(document.readyState || ''),
          hasEmbed: Boolean(document.querySelector('embed[type="application/pdf"], iframe[src*=".pdf"], pdf-viewer, #viewer')),
          bodyTextChars: String(document.body?.innerText || '').length
        }))())'''
        result = self.runtime.evaluate_readonly(expression, intent="Probe current browser PDF page")
        if not result.get("ok"):
            return {"ok": False, "detail": str(result.get("detail") or "")}
        parsed = self._parse_mcp_json_detail(str(result.get("detail") or ""))
        return {"ok": True, **(parsed or {})}

    def _pdf_viewer_key(self, key: str, intent: str) -> dict[str, Any]:
        """Focus the rendered PDF viewport, then issue a navigation key.

        Chrome/Edge PDF viewers often ignore PageDown until the plugin/viewer has
        focus. The Playwright code tool clicks the viewport centre first; the
        normal keyboard tool remains the compatibility fallback.
        """
        safe_keys = {"Control+Home", "Home", "PageDown", "ArrowDown", "End"}
        chosen = key if key in safe_keys else "PageDown"
        code = f'''async (page) => {{
          const viewport = page.viewportSize() || {{ width: 1280, height: 800 }};
          try {{ await page.mouse.click(Math.floor(viewport.width / 2), Math.floor(viewport.height / 2)); }} catch {{}}
          await page.keyboard.press({json.dumps(chosen)});
          return JSON.stringify({{
            ok: true,
            url: page.url(),
            title: await page.title().catch(() => ''),
            width: viewport.width,
            height: viewport.height
          }});
        }}'''
        try:
            result = self.runtime.run_application_code(code, intent=intent)
            if result.get("ok"):
                return result
        except Exception:
            pass
        return self.runtime.press_key(chosen, intent=intent)

    def _capture_pdf_viewer_evidence(self, source_url: str, queue_url: str = "") -> dict[str, Any]:
        """Exhaust a browser-rendered PDF using accessibility text and vision.

        This is the final document fallback when Dell/CDN permits a PDF to render
        in the persistent browser but denies every binary download strategy.
        """
        capture = BrowserPDFViewerCapture(source_url=source_url, final_url=source_url)
        if not self.config.browser_pdf_viewer_extraction_enabled:
            capture.warnings.append("Browser PDF viewer extraction is disabled.")
            return capture.to_dict()

        digest = hashlib.sha256(source_url.encode("utf-8", errors="ignore")).hexdigest()
        capture_dir = ensure_dir(self.browser_pdf_viewer_dir / digest[:2] / digest)
        try:
            self._pdf_viewer_key("Control+Home", intent="Focus browser PDF viewer and move to its first page")
        except Exception:
            try:
                self._pdf_viewer_key("Home", intent="Focus browser PDF viewer and move to its first page")
            except Exception as exc:
                capture.warnings.append(f"Could not move PDF viewer to first page: {type(exc).__name__}: {exc}")
        try:
            self.runtime.wait(float(self.config.browser_pdf_viewer_wait_seconds), intent="Wait for browser PDF viewer to render")
        except Exception:
            time.sleep(max(0.1, float(self.config.browser_pdf_viewer_wait_seconds)))

        text_seen: set[str] = set()
        image_seen: set[str] = set()
        position_seen: set[int] = set()
        previous_signature = ""
        stable_rounds = 0
        page_count = 0
        hard_guard = max(1, int(self.config.browser_pdf_viewer_fallback_guard))
        configured_limit = int(self.config.browser_pdf_viewer_max_viewports)
        max_rounds = configured_limit if configured_limit > 0 else hard_guard

        for round_index in range(max_rounds):
            if self._stopped:
                capture.warnings.append("Crawler stop requested during browser PDF viewer extraction.")
                break
            if queue_url:
                try:
                    self.store.touch_queue(queue_url, self.run_id, self.config.worker_lease_seconds)
                except Exception:
                    pass

            snapshot_text = ""
            if self.config.browser_pdf_viewer_text_enabled:
                try:
                    snapshot = self.runtime.snapshot(
                        boxes=False,
                        depth=24,
                        intent="Read current browser PDF page through accessibility text",
                    )
                    snapshot_text = clean_accessibility_text(str(snapshot.get("detail") or ""))
                except Exception as exc:
                    capture.warnings.append(f"PDF viewer accessibility snapshot failed: {type(exc).__name__}: {exc}")

            dom_text = ""
            viewer_title = ""
            viewer_url = ""
            if self.config.browser_pdf_viewer_text_enabled:
                try:
                    dom_text, viewer_title, viewer_url = self._pdf_viewer_dom_text()
                except Exception as exc:
                    capture.warnings.append(f"PDF viewer DOM text read failed: {type(exc).__name__}: {exc}")
            if viewer_title and not capture.title:
                capture.title = viewer_title
            if viewer_url.startswith(("http://", "https://")):
                capture.final_url = viewer_url

            combined = "\n".join(value for value in (snapshot_text, dom_text) if value).strip()
            current_page, detected_total = parse_pdf_page_position(combined)
            if detected_total > page_count:
                page_count = detected_total
                capture.page_count = detected_total
            if current_page > 0:
                position_seen.add(current_page)

            text_hash = ""
            if combined:
                normalized = re.sub(r"\s+", " ", combined).strip()
                text_hash = hashlib.sha256(normalized.encode("utf-8", errors="ignore")).hexdigest()
                if text_hash not in text_seen:
                    text_seen.add(text_hash)
                    marker = (
                        f"===== BROWSER PDF VIEWER VIEWPORT {round_index + 1}"
                        + (f" · PAGE {current_page}" if current_page else "")
                        + (f" OF {page_count}" if page_count else "")
                        + " ====="
                    )
                    capture.text_blocks.append(f"{marker}\n{combined}")
                    capture.text_chars += len(combined)

            visual_signature = ""
            if bool(getattr(self.config, "browser_pdf_viewer_capture_screenshots", True)):
                filename = f"pdf_viewer_{digest[:18]}_{round_index + 1:05d}.png"
                try:
                    result = self.runtime.screenshot(
                        filename,
                        full_page=False,
                        intent="Capture current browser PDF viewport for Dell AIA vision",
                    )
                    runtime_path = Path(self.runtime.output_dir) / filename
                    if not runtime_path.is_file():
                        detail = decode_mcp_text(str(result.get("detail") or ""))
                        candidates = re.findall(r"(?:[A-Za-z]:\\\\[^\n\r]+?\\.png|/[^\n\r]+?\\.png)", detail)
                        runtime_path = next((Path(value) for value in candidates if Path(value).is_file()), runtime_path)
                    if runtime_path.is_file():
                        visual_signature = perceptual_image_signature(runtime_path)
                        if visual_signature not in image_seen:
                            image_seen.add(visual_signature)
                            final_path = capture_dir / f"viewport_{round_index + 1:05d}.png"
                            if runtime_path.resolve() != final_path.resolve():
                                shutil.copy2(runtime_path, final_path)
                            else:
                                final_path = runtime_path
                            content_digest = hashlib.sha256(final_path.read_bytes()).hexdigest()
                            capture.visual_evidence.append(
                                {
                                    "kind": "browser_pdf_viewport",
                                    "path": str(final_path),
                                    "source_url": source_url,
                                    "alt": f"Browser-rendered PDF viewport {round_index + 1}",
                                    "page_number": current_page or round_index + 1,
                                    "pdf_page_count": page_count,
                                    "viewport_index": round_index + 1,
                                    "content_hash": content_digest,
                                    "perceptual_hash": visual_signature,
                                    "vision_candidate": True,
                                    "capture_mode": "playwright_mcp_browser_pdf_viewer",
                                }
                            )
                except Exception as exc:
                    capture.warnings.append(f"PDF viewer screenshot failed: {type(exc).__name__}: {exc}")

            signature = "|".join(
                [
                    str(current_page),
                    str(page_count),
                    text_hash,
                    visual_signature,
                ]
            )
            if signature and signature == previous_signature:
                stable_rounds += 1
            else:
                stable_rounds = 0
                previous_signature = signature

            capture.screenshot_count = len(capture.visual_evidence)
            capture.pages_observed = sorted(position_seen)
            self._emit(
                "pdf_browser_viewer_progress",
                url=source_url,
                viewport=round_index + 1,
                current_page=current_page,
                total_pages=page_count,
                text_chars=capture.text_chars,
                screenshots=capture.screenshot_count,
                stable_rounds=stable_rounds,
            )

            reached_known_end = bool(page_count > 0 and current_page >= page_count)
            if stable_rounds >= max(1, int(self.config.browser_pdf_viewer_stable_rounds)):
                if reached_known_end or round_index > 0:
                    break

            try:
                self._pdf_viewer_key("PageDown", intent="Focus and advance browser PDF viewer to the next page")
                self.runtime.wait(
                    float(self.config.browser_pdf_viewer_wait_seconds),
                    intent="Wait for next browser PDF page to render",
                )
            except Exception as exc:
                capture.warnings.append(f"Could not advance browser PDF viewer: {type(exc).__name__}: {exc}")
                break

        capture.text_blocks = dedupe_text_blocks(capture.text_blocks)
        capture.visual_evidence = dedupe_visual_evidence(capture.visual_evidence)
        capture.screenshot_count = len(capture.visual_evidence)
        capture.pages_observed = sorted(position_seen)
        capture.page_count = max(capture.page_count, max(capture.pages_observed, default=0))
        capture.text_chars = sum(len(value) for value in capture.text_blocks)
        self.stats.pdf_browser_viewer_opens += 1
        self.stats.pdf_browser_viewer_viewports += capture.screenshot_count
        self.stats.pdf_pages_visualized += capture.screenshot_count
        self.stats.pdf_browser_viewer_text_chars += capture.text_chars

        manifest = capture_dir / "capture.json"
        capture.manifest_path = str(manifest)
        manifest.write_text(json.dumps(capture.to_dict(), indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        self._emit(
            "pdf_browser_viewer_done",
            url=source_url,
            pages_observed=len(capture.pages_observed),
            total_pages=capture.page_count,
            text_chars=capture.text_chars,
            screenshots=capture.screenshot_count,
            usable=capture.usable,
            manifest=str(manifest),
        )
        return capture.to_dict()

    def _cache_browser_pdf_viewer_capture(self, url: str, capture: dict[str, Any]) -> None:
        for key in {str(url), normalize_pdf_download_url(str(url)), canonicalize_url(str(url))}:
            if key:
                self._browser_pdf_viewer_cache[key] = capture

    def _get_browser_pdf_viewer_capture(self, url: str) -> dict[str, Any]:
        for key in (str(url), normalize_pdf_download_url(str(url)), canonicalize_url(str(url))):
            value = self._browser_pdf_viewer_cache.get(key)
            if isinstance(value, dict):
                return value
        return {}

    def _browser_fetch_resource_chunk(self, url: str, start: int, end: int) -> dict[str, Any]:
        """Legacy page-context range fetch retained for MCP compatibility tests.

        v6.2 does not depend on this CORS-constrained path for recovery; the
        browser APIRequestContext method below is the production fallback.
        """
        target = json.dumps(str(url))
        function = f"""async () => {{
          const response = await fetch({target}, {{
            method: 'GET',
            credentials: 'include',
            headers: {{
              'Accept': 'application/pdf,application/octet-stream;q=0.9,*/*;q=0.7',
              'Range': 'bytes={int(start)}-{int(end)}'
            }}
          }});
          const arrayBuffer = await response.arrayBuffer();
          const bytes = new Uint8Array(arrayBuffer);
          let binary = '';
          const stride = 0x8000;
          for (let index = 0; index < bytes.length; index += stride) {{
            binary += String.fromCharCode(...bytes.subarray(index, index + stride));
          }}
          return JSON.stringify({{
            ok: response.ok,
            status: response.status,
            url: response.url,
            contentType: response.headers.get('content-type') || '',
            contentRange: response.headers.get('content-range') || '',
            contentLength: response.headers.get('content-length') || '',
            bytes: bytes.length,
            base64: btoa(binary)
          }});
        }}"""
        result = self.runtime.evaluate_readonly(function, intent="Legacy public Dell PDF page-context range fetch")
        if not result.get("ok"):
            raise RuntimeError(f"Legacy browser PDF range call failed: {str(result.get('detail') or '')[:1800]}")
        parsed = self.runtime._parse_json_detail(str(result.get("detail") or ""))
        if not parsed:
            raise RuntimeError("Legacy browser PDF range call returned no structured result.")
        return parsed

    def _browser_api_fetch_resource_chunk(self, url: str, parent_url: str, start: int, end: int) -> dict[str, Any]:
        """Fetch a PDF byte range through the browser context's APIRequestContext.

        Unlike ``window.fetch``, Playwright's context request is not subject to
        page CORS and shares the persistent browser cookie store. The JavaScript
        is fixed packaged code; no page/LLM content is executed.
        """
        target = json.dumps(str(url))
        referer = json.dumps(str(parent_url or ""))
        accept_language = json.dumps(accept_language_for_locale(str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk")))
        single_response_max = int(
            getattr(getattr(self, "config", None), "document_browser_single_response_max_bytes", 8 * 1024 * 1024)
        )
        code = f"""async (page) => {{
          const target = {target};
          const referer = {referer};
          const start = {int(start)};
          const end = {int(end)};
          const requestHeaders = {{
            'Accept': 'application/pdf,application/octet-stream;q=0.9,*/*;q=0.7',
            'Accept-Language': {accept_language},
            'Accept-Encoding': 'identity',
            'Range': `bytes=${{start}}-${{end}}`,
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }};
          try {{ requestHeaders['User-Agent'] = await page.evaluate(() => navigator.userAgent); }} catch {{}}
          if (referer) requestHeaders['Referer'] = referer;
          const response = await page.context().request.get(target, {{
            headers: requestHeaders,
            failOnStatusCode: false,
            timeout: 90000
          }});
          const status = response.status();
          const headers = response.headers();
          const body = await response.body();
          const rangeHonored = status === 206;
          const singleResponseMax = {single_response_max};
          const returnWholeSmallBody = !rangeHonored && start === 0 && body.length <= singleResponseMax;
          const sliceStart = returnWholeSmallBody ? 0 : (rangeHonored ? 0 : Math.min(start, body.length));
          const wanted = returnWholeSmallBody ? body.length : Math.max(1, end - start + 1);
          const sliceEnd = Math.min(body.length, sliceStart + wanted);
          const piece = body.subarray(sliceStart, sliceEnd);
          return JSON.stringify({{
            ok: status >= 200 && status < 300,
            status,
            url: response.url(),
            headers,
            contentType: headers['content-type'] || '',
            contentRange: headers['content-range'] || '',
            contentLength: headers['content-length'] || '',
            totalBodyBytes: body.length,
            rangeHonored,
            requestedStart: start,
            requestedEnd: end,
            bytes: piece.length,
            base64: piece.toString('base64')
          }});
        }}"""
        result = self.runtime.run_application_code(code, intent="Fetch public Dell PDF through browser APIRequestContext")
        if not result.get("ok"):
            raise RuntimeError(f"Browser APIRequestContext call failed: {str(result.get('detail') or '')[:1800]}")
        parsed = self.runtime._parse_json_detail(str(result.get("detail") or ""))
        if not parsed:
            raise RuntimeError("Browser APIRequestContext returned no structured result.")
        return parsed

    def _find_new_pdf_in_mcp_output(self, before: dict[str, tuple[int, int]]) -> Path | None:
        root = Path(self.runtime.output_dir)
        if not root.exists():
            return None
        candidates: list[Path] = []
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            try:
                key = str(path.resolve())
                stamp = (int(path.stat().st_mtime_ns), int(path.stat().st_size))
            except OSError:
                continue
            if key in before and before[key] == stamp:
                continue
            try:
                with path.open("rb") as handle:
                    if pdf_magic_offset(handle.read(1024)) >= 0:
                        candidates.append(path)
            except OSError:
                continue
        if not candidates:
            return None
        candidates.sort(key=lambda item: item.stat().st_mtime_ns, reverse=True)
        return candidates[0]

    def _mcp_output_snapshot(self) -> dict[str, tuple[int, int]]:
        root = Path(self.runtime.output_dir)
        result: dict[str, tuple[int, int]] = {}
        if not root.exists():
            return result
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            try:
                result[str(path.resolve())] = (int(path.stat().st_mtime_ns), int(path.stat().st_size))
            except OSError:
                pass
        return result

    def _capture_pdf_network_body(self, url: str, path: Path) -> bool:
        """Try the official MCP network-request body tool after real navigation."""
        if not self.config.document_network_body_capture_enabled:
            return False
        listing = self.runtime.network_requests(
            filter_pattern=re.escape(Path(urlparse(url).path).name),
            include_static=True,
            intent="Locate navigated Dell PDF network request",
        )
        if not listing.get("ok"):
            return False
        indices = parse_mcp_network_request_indices(str(listing.get("detail") or ""), url)
        for index in indices:
            relative = f"pdf_network/{hashlib.sha256(url.encode('utf-8')).hexdigest()}.pdf"
            result = self.runtime.network_request_detail(
                index,
                part="responseBody",
                filename=relative,
                intent="Save Dell PDF response body through official MCP network tool",
            )
            if not result.get("ok"):
                continue
            candidate = Path(self.runtime.output_dir) / relative
            if not candidate.is_file():
                # Some MCP builds return the path in the text result.
                detail = str(result.get("detail") or "")
                path_match = re.search(r"(?:saved|written).*?([A-Za-z]:\\[^\r\n]+|/[^\r\n]+)", detail, re.I)
                if path_match:
                    candidate = Path(path_match.group(1).strip().strip('`"'))
            validation = validate_pdf_file(candidate, parse_structure=False)
            if validation.ok:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(candidate.read_bytes())
                self.stats.pdf_network_body_downloads += 1
                return True
        return False

    def _download_via_browser_api_chunks(self, url: str, path: Path, parent_url: str) -> tuple[str, int, dict[str, str], int]:
        path.parent.mkdir(parents=True, exist_ok=True)
        part_path = path.with_suffix(path.suffix + ".part")
        if part_path.exists():
            validation = validate_pdf_file(part_path, parse_structure=False)
            if not validation.ok:
                self._quarantine_invalid_document(part_path, f"invalid_partial_{validation.reason}", url=url, stage="browser_partial_validation")
        existing = int(part_path.stat().st_size) if part_path.exists() else 0
        chunk_size = max(65536, int(self.config.document_browser_chunk_bytes))
        first = self._browser_api_fetch_resource_chunk(url, parent_url, existing, existing + chunk_size - 1)
        status = int(first.get("status") or 0)
        if status not in {200, 206}:
            raise httpx.HTTPStatusError(
                f"Browser APIRequestContext received HTTP {status}",
                request=httpx.Request("GET", url),
                response=httpx.Response(status or 500, request=httpx.Request("GET", url)),
            )
        headers_raw = first.get("headers") if isinstance(first.get("headers"), dict) else {}
        content_type = str(first.get("contentType") or headers_raw.get("content-type") or "application/pdf")
        content_range = str(first.get("contentRange") or headers_raw.get("content-range") or "")
        content_length = int(str(first.get("contentLength") or headers_raw.get("content-length") or "0") or 0)
        total = 0
        match = re.search(r"/(\d+)$", content_range)
        if match:
            total = int(match.group(1))
        elif status == 200:
            total = max(content_length, int(first.get("totalBodyBytes") or 0))
        data = base64.b64decode(str(first.get("base64") or ""), validate=False)
        basic = validate_pdf_bytes(data) if existing == 0 else None
        if existing == 0 and (not basic or not basic.ok):
            raise DocumentValidationError(
                f"Browser APIRequestContext did not return PDF bytes: {(basic.reason if basic else 'empty response')} "
                f"content-type={content_type!r} status={status}"
            )
        mode = "ab" if existing > 0 else "wb"
        downloaded = existing
        with part_path.open(mode) as handle:
            if data:
                handle.write(data)
                downloaded += len(data)
            while total <= 0 or downloaded < total:
                if self._stopped:
                    raise KeyboardInterrupt("Crawler stop requested during browser-context PDF download")
                chunk = self._browser_api_fetch_resource_chunk(url, parent_url, downloaded, downloaded + chunk_size - 1)
                chunk_status = int(chunk.get("status") or 0)
                if chunk_status not in {200, 206}:
                    raise RuntimeError(f"Browser PDF continuation returned HTTP {chunk_status}.")
                piece = base64.b64decode(str(chunk.get("base64") or ""), validate=False)
                if not piece:
                    break
                handle.write(piece)
                downloaded += len(piece)
                self._emit("document_browser_fallback_progress", url=url, bytes_downloaded=downloaded, total_bytes=total)
                if len(piece) < chunk_size and (total <= 0 or downloaded >= total):
                    break
            handle.flush()
            os.fsync(handle.fileno())
        if total > 0 and downloaded < total:
            raise RuntimeError(f"Browser PDF download ended early: {downloaded}/{total} bytes")
        validation = validate_pdf_file(part_path, parse_structure=True)
        if not validation.ok:
            self._quarantine_invalid_document(part_path, validation.reason, url=url, stage="browser_api_structural_validation")
            raise DocumentValidationError(f"Browser PDF validation failed: {validation.reason}")
        part_path.replace(path)
        final_size = int(path.stat().st_size)
        self.stats.document_bytes_downloaded += max(0, final_size - existing)
        self.stats.document_browser_fallbacks += 1
        self.stats.pdf_browser_api_downloads += 1
        self._emit("document_browser_fallback_done", url=url, bytes=final_size, strategy="browser_api_request")
        return str(first.get("url") or url), 200, {
            "content-type": content_type or "application/pdf",
            "content-length": str(final_size),
            "x-dell-fetch-mode": "playwright_browser_api_request",
        }, final_size

    @staticmethod
    def _document_match_key(url: str, base_url: str = "") -> tuple[str, str]:
        """Return a stable host/path identity for a PDF link.

        Dell occasionally appends ``.external`` and tracking query parameters to
        the page href. Those values describe the click route, not a different
        document, so matching intentionally ignores query/fragment and removes
        the discovery-only suffix.
        """
        candidate = canonicalize_url(str(url or ""), base_url)
        candidate = normalize_pdf_download_url(candidate)
        parsed = urlparse(candidate)
        path = re.sub(r"\.external$", "", parsed.path, flags=re.I)
        return parsed.netloc.casefold(), path.rstrip("/").casefold()

    def _select_or_open_parent_page(self, parent_url: str) -> dict[str, Any]:
        """Select or open the Dell page that published a document link."""
        parent_url = canonicalize_url(str(parent_url or ""))
        if not parent_url:
            return {"ok": False, "status": "missing_parent_url"}
        self._ensure_runtime()
        tabs = self.runtime.tab_inventory(intent="Locate Dell document source page")
        selected: dict[str, Any] | None = None
        for tab in tabs:
            observed = canonicalize_url(str(tab.get("url") or ""), parent_url)
            if observed == parent_url:
                selected = tab
                break
        if selected is not None:
            result = self.runtime.select_tab(int(selected.get("index", 0)), intent="Select Dell document source page")
        else:
            result = self.runtime.tabs("new", url=parent_url, intent="Open Dell document source page")
            self.runtime.wait(0.6, intent="Wait for Dell document source page")
        probe = self._browser_page_probe()
        current = canonicalize_url(str(probe.get("url") or ""), parent_url)
        if current != parent_url:
            result = self.runtime.navigate(parent_url, intent="Navigate to Dell document source page")
            if not result.get("ok"):
                return result
        self.runtime.wait(0.8, intent="Wait for rendered Dell document links")
        return {"ok": True, "parent_url": parent_url, "tabs": tabs}

    def _browser_dom_pdf_candidates(self, parent_url: str, requested_url: str = "") -> list[dict[str, Any]]:
        """Read every rendered PDF href from DOM, open shadow roots and same-origin frames.

        No page-provided JavaScript is executed.  This is fixed application-owned
        read-only code and returns href/label/visibility evidence only.
        """
        if not getattr(self.config, "document_dom_href_first_enabled", True):
            return []
        requested_json = json.dumps(normalize_pdf_download_url(str(requested_url or "")))
        expression = f"""() => {{
          const requested = {requested_json};
          const results = [];
          const seenRoots = new Set();
          const urlAttrs = ['href','data-href','data-url','data-download-url','data-resource-url','data-pdf','data-file','data-document','data-target-url'];
          const textOf = (el) => String(el.innerText || el.textContent || el.getAttribute?.('aria-label') || el.getAttribute?.('title') || '').replace(/\\s+/g,' ').trim().slice(0,600);
          const visible = (el) => {{
            try {{
              const r = el.getBoundingClientRect();
              const s = getComputedStyle(el);
              return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity || 1) > 0;
            }} catch {{ return false; }}
          }};
          const add = (el, raw, frameUrl, rootKind, attr) => {{
            if (!raw) return;
            let absolute = '';
            try {{ absolute = new URL(String(raw), frameUrl || location.href).href; }} catch {{ return; }}
            if (!/\\.pdf(?:\\.external)?(?:$|[?#])/i.test(absolute) && !/\\bpdf\\b/i.test(String(el.type || ''))) return;
            results.push({{
              url: absolute,
              raw: String(raw),
              label: textOf(el),
              title: String(el.getAttribute?.('title') || ''),
              aria: String(el.getAttribute?.('aria-label') || ''),
              tag: String(el.tagName || '').toLowerCase(),
              role: String(el.getAttribute?.('role') || ''),
              target: String(el.getAttribute?.('target') || ''),
              download: String(el.getAttribute?.('download') || ''),
              visible: visible(el),
              frameUrl: String(frameUrl || ''),
              rootKind,
              attr,
              requested
            }});
          }};
          const walkRoot = (root, frameUrl, rootKind) => {{
            if (!root || seenRoots.has(root)) return;
            seenRoots.add(root);
            let elements = [];
            try {{ elements = Array.from(root.querySelectorAll('a,area,button,[role="link"],[data-href],[data-url],[data-download-url],[data-resource-url],[data-pdf],[data-file],[data-document],[data-target-url],embed,object')); }} catch {{}}
            for (const el of elements) {{
              for (const attr of urlAttrs) add(el, el.getAttribute?.(attr), frameUrl, rootKind, attr);
              add(el, el.getAttribute?.('src'), frameUrl, rootKind, 'src');
              if (el.shadowRoot) walkRoot(el.shadowRoot, frameUrl, 'shadow');
            }}
          }};
          const walkDocument = (doc, frameUrl, rootKind) => {{
            if (!doc) return;
            walkRoot(doc, frameUrl, rootKind);
            let frames = [];
            try {{ frames = Array.from(doc.querySelectorAll('iframe,frame')); }} catch {{}}
            for (const frame of frames) {{
              try {{
                const child = frame.contentDocument;
                if (child) walkDocument(child, frame.contentWindow?.location?.href || frame.src || frameUrl, 'same-origin-frame');
              }} catch {{}}
            }}
          }};
          walkDocument(document, location.href, 'document');
          return JSON.stringify({{ok:true, pageUrl:location.href, candidates:results}});
        }}"""
        result = self.runtime.evaluate_readonly(expression, intent="Collect and de-duplicate rendered Dell PDF hrefs")
        if not result.get("ok"):
            return []
        payload = self.runtime._parse_json_detail(str(result.get("detail") or ""))
        rows = payload.get("candidates") if isinstance(payload, dict) else []
        if not isinstance(rows, list):
            return []
        deduped: dict[str, dict[str, Any]] = {}
        requested_key = self._document_match_key(requested_url, parent_url) if requested_url else ("", "")
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            url = normalize_pdf_download_url(canonicalize_url(str(raw.get("url") or ""), parent_url))
            if not url or ".pdf" not in url.casefold():
                continue
            key = "|".join(self._document_match_key(url, parent_url))
            row = {**raw, "url": url, "match_key": key}
            existing = deduped.get(key)
            if existing is None or (bool(row.get("visible")) and not bool(existing.get("visible"))):
                deduped[key] = row
        values = list(deduped.values())
        values.sort(key=lambda row: (
            0 if self._document_match_key(str(row.get("url") or ""), parent_url) == requested_key else 1,
            0 if bool(row.get("visible")) else 1,
            0 if "/assetlink/" in str(row.get("url") or "").casefold() and "/original/" in str(row.get("url") or "").casefold() else 1,
            len(str(row.get("url") or "")),
        ))
        self.stats.pdf_dom_href_candidates += len(values)
        if len(rows) > len(values):
            self.stats.pdf_duplicate_href_groups += max(1, len(rows) - len(values))
        self._emit(
            "pdf_dom_candidates",
            url=requested_url,
            parent_url=parent_url,
            candidate_count=len(values),
            duplicate_count=max(0, len(rows) - len(values)),
            candidates=[{k: row.get(k) for k in ("url","label","visible","frameUrl","rootKind","attr")} for row in values[:50]],
        )
        return values

    def _ordered_pdf_candidate_urls(
        self,
        descriptor: dict[str, Any],
        dom_candidates: list[dict[str, Any]],
    ) -> list[str]:
        parent_url = str(descriptor.get("parent_url") or "")
        requested = normalize_pdf_download_url(str(descriptor.get("request_url") or descriptor.get("queue_url") or ""))
        raw_values = [
            requested,
            normalize_pdf_download_url(str(descriptor.get("href") or "")),
            *[normalize_pdf_download_url(str(row.get("url") or "")) for row in dom_candidates],
        ]
        seen: set[tuple[str, str]] = set()
        values: list[str] = []
        for value in raw_values:
            value = canonicalize_url(value, parent_url)
            if not value or ".pdf" not in value.casefold():
                continue
            key = self._document_match_key(value, parent_url)
            if key in seen:
                continue
            seen.add(key)
            values.append(value)
        requested_key = self._document_match_key(requested, parent_url)
        values.sort(key=lambda value: (
            0 if self._document_match_key(value, parent_url) == requested_key else 1,
            0 if "/assetlink/" in value.casefold() and "/original/" in value.casefold() else 1,
            0 if urlparse(value).netloc.casefold().endswith("delltechnologies.com") else 1,
            len(value),
        ))
        return values

    def _network_request_snapshot(self) -> dict[int, str]:
        try:
            listing = self.runtime.network_requests(
                filter_pattern="pdf",
                include_static=True,
                intent="Snapshot PDF network requests before document acquisition",
            )
        except Exception:
            return {}
        if not listing.get("ok"):
            return {}
        return {
            int(row["index"]): str(row.get("url") or "")
            for row in parse_mcp_network_request_entries(str(listing.get("detail") or ""))
        }

    def _capture_pdf_network_body_candidates(
        self,
        candidate_urls: list[str],
        path: Path,
        before_indices: set[int] | None = None,
    ) -> tuple[bool, str]:
        if not self.config.document_network_body_capture_enabled:
            return False, ""
        aliases = [normalize_pdf_download_url(value) for value in candidate_urls if value]
        listing = self.runtime.network_requests(
            filter_pattern="pdf",
            include_static=True,
            intent="Locate new Dell PDF response after browser action",
        )
        if not listing.get("ok"):
            return False, ""
        entries = parse_mcp_network_request_entries(str(listing.get("detail") or ""))
        allowed_before = before_indices or set()
        ranked: list[dict[str, Any]] = []
        for row in entries:
            index = int(row.get("index") or -1)
            url = normalize_pdf_download_url(str(row.get("url") or ""))
            if index < 0 or index in allowed_before or ".pdf" not in url.casefold():
                continue
            consistent = any(pdf_urls_consistent(alias, url, aliases) for alias in aliases)
            ranked.append({**row, "url": url, "consistent": consistent})
        ranked.sort(key=lambda row: (0 if row.get("consistent") else 1, -int(row.get("index") or 0)))
        for row in ranked:
            index = int(row["index"])
            response_url = str(row.get("url") or "")
            strict_canonical = bool(getattr(self.config, "document_require_canonical_match", False)) or str(
                getattr(self.config, "document_canonical_match_mode", "warn")
            ).casefold() == "strict"
            if not row.get("consistent") and strict_canonical:
                continue
            relative = f"pdf_network/{hashlib.sha256(response_url.encode('utf-8')).hexdigest()}.pdf"
            result = self.runtime.network_request_detail(
                index,
                part="responseBody",
                filename=relative,
                intent="Save the exact Dell PDF response body generated by the browser",
            )
            if not result.get("ok"):
                continue
            candidate = Path(self.runtime.output_dir) / relative
            if not candidate.is_file():
                detail = str(result.get("detail") or "")
                match = re.search(r"(?:saved|written).*?([A-Za-z]:\\\\[^\\r\\n]+|/[^\\r\\n]+)", detail, re.I)
                if match:
                    candidate = Path(match.group(1).strip().strip('`"'))
            validation = validate_pdf_file_stable(candidate, parse_structure=True)
            if not validation.ok:
                continue
            if not row.get("consistent"):
                self.stats.pdf_canonical_alias_accepts += 1
                self._emit(
                    "pdf_canonical_alias_accepted",
                    url=aliases[0] if aliases else response_url,
                    final_url=response_url,
                    reason="Validated browser network response retained with source-click provenance.",
                )
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(candidate, path)
            self.stats.pdf_network_body_downloads += 1
            return True, response_url
        return False, ""

    def _restore_document_source_page(self, parent_url: str) -> None:
        """Close PDF resource tabs and restore the Dell source page."""
        parent_url = canonicalize_url(str(parent_url or ""))
        if not parent_url:
            return
        try:
            tabs = self.runtime.tab_inventory(intent="Restore Dell source page after document extraction")
        except Exception:
            tabs = []
        parent_tab: dict[str, Any] | None = None
        for tab in tabs:
            observed = canonicalize_url(str(tab.get("url") or ""), parent_url)
            if observed == parent_url:
                parent_tab = tab
                break
        for tab in list(tabs):
            try:
                index = int(tab.get("index", -1))
                observed = canonicalize_url(str(tab.get("url") or ""), parent_url)
                if index >= 0 and observed != parent_url and (".pdf" in observed.casefold() or "pdf" in str(tab.get("title") or "").casefold()):
                    self.runtime.close_tab(index, intent="Close extracted Dell PDF tab")
            except Exception:
                pass
        try:
            if parent_tab is not None:
                self.runtime.select_tab(int(parent_tab.get("index", 0)), intent="Return to Dell document source page")
            else:
                current_tabs = self.runtime.tab_inventory(intent="Select a tab before restoring Dell source page")
                if current_tabs:
                    self.runtime.select_tab(int(current_tabs[0].get("index", 0)), intent="Select browser tab for Dell source restore")
                self.runtime.navigate(parent_url, intent="Restore Dell document source page")
        except Exception:
            pass

    def _click_unique_pdf_candidate(
        self,
        candidate_urls: list[str],
        label: str,
    ) -> dict[str, Any]:
        """Click exactly one visible PDF control across page frames.

        Playwright strict locators fail when Dell repeats the same link in cards,
        mobile menus or hidden templates.  This application-owned code enumerates
        every match, selects one visible target, scrolls it into view and clicks
        only that element.  A forced click is used only after a normal click times
        out, and the complete match count is returned for diagnostics.
        """
        aliases = [normalize_pdf_download_url(value) for value in candidate_urls if value]
        aliases_json = json.dumps(aliases)
        label_json = json.dumps(str(label or "Open PDF"))
        timeout_ms = int(max(5000, float(getattr(self.config, "document_click_timeout_seconds", 30.0)) * 1000))
        code = f"""async (page) => {{
          const aliases = {aliases_json}.map(v => String(v).replace(/\\.external(?=[?#]?$)/i,''));
          const wantedNames = new Set(aliases.map(v => {{ try {{ return new URL(v).pathname.split('/').pop().toLowerCase(); }} catch {{ return ''; }} }}));
          const label = {label_json};
          const matches = [];
          for (const frame of page.frames()) {{
            const locator = frame.locator('a[href],area[href],[role="link"][href],button[data-href],[data-url],[data-download-url],[data-resource-url],[data-pdf],[data-file],[data-document],[data-target-url]');
            const count = await locator.count();
            for (let i = 0; i < count; i++) {{
              const el = locator.nth(i);
              let raw = '';
              for (const attr of ['href','data-href','data-url','data-download-url','data-resource-url','data-pdf','data-file','data-document','data-target-url']) {{
                raw = raw || await el.getAttribute(attr) || '';
              }}
              if (!raw) continue;
              let absolute = '';
              try {{ absolute = new URL(raw, frame.url()).href.replace(/\\.external(?=[?#]?$)/i,''); }} catch {{ continue; }}
              const name = (() => {{ try {{ return new URL(absolute).pathname.split('/').pop().toLowerCase(); }} catch {{ return ''; }} }})();
              if (!aliases.includes(absolute) && !wantedNames.has(name)) continue;
              let isVisible = false;
              try {{ isVisible = await el.isVisible(); }} catch {{}}
              matches.push({{frame, el, raw, absolute, isVisible, index:i}});
            }}
          }}
          const chosen = matches.find(m => m.isVisible) || matches[0];
          if (!chosen) return JSON.stringify({{ok:false,status:'locator_not_found',label,matchCount:0}});
          let forced = false;
          try {{
            await chosen.el.scrollIntoViewIfNeeded({{timeout:{timeout_ms}}});
            await chosen.el.click({{timeout:{timeout_ms}}});
          }} catch (firstError) {{
            try {{
              forced = true;
              await chosen.el.click({{timeout:{timeout_ms}, force:true}});
            }} catch (secondError) {{
              return JSON.stringify({{ok:false,status:'click_failed',label,matchCount:matches.length,chosenHref:chosen.absolute,firstError:String(firstError),secondError:String(secondError)}});
            }}
          }}
          return JSON.stringify({{ok:true,status:'clicked',label,matchCount:matches.length,chosenHref:chosen.absolute,frameUrl:chosen.frame.url(),forced}});
        }}"""
        result = self.runtime.run_application_code(code, intent=f"Click one visible Dell PDF control '{label}'")
        payload = self.runtime._parse_json_detail(str(result.get("detail") or "")) if result.get("ok") else {}
        if isinstance(payload, dict) and payload.get("ok"):
            self.stats.pdf_unique_target_clicks += 1
            return payload
        return payload if isinstance(payload, dict) else {"ok": False, "status": "unparseable_click_result"}

    def _download_resource_via_browser_context_first(
        self,
        queue_item: dict[str, Any],
        path: Path,
        descriptor: dict[str, Any],
    ) -> tuple[str, int, dict[str, str], int]:
        """Primary v6.7 document acquisition: DOM hrefs + browser request context.

        This never uses the standalone httpx client.  It first restores the
        source page, gathers all rendered PDF aliases, de-duplicates them and
        fetches through Playwright's APIRequestContext, which shares the live
        browser cookies, locale and user-agent and receives the source-page
        Referer.  UI click/network/viewer recovery remains the fallback for
        resources that require a user gesture.
        """
        self._ensure_runtime()
        parent_url = str(descriptor.get("parent_url") or queue_item.get("parent_url") or "")
        queue_url = str(queue_item.get("_queue_url") or queue_item.get("url") or descriptor.get("queue_url") or "")
        requested_url = normalize_pdf_download_url(str(descriptor.get("request_url") or queue_url))
        ready = self._select_or_open_parent_page(parent_url)
        if not ready.get("ok"):
            raise RuntimeError(f"Could not restore PDF source page: {ready}")
        dom_candidates = self._browser_dom_pdf_candidates(parent_url, requested_url)
        candidate_urls = self._ordered_pdf_candidate_urls(descriptor, dom_candidates)
        if not candidate_urls:
            candidate_urls = [requested_url]
        before_network = set(self._network_request_snapshot())
        failures: list[str] = []
        acquisition_context = {
            "queue_url": queue_url,
            "requested_url": requested_url,
            "parent_url": parent_url,
            "candidate_urls": candidate_urls,
            "dom_candidates": dom_candidates,
            "strategy": "pending",
        }
        cache = getattr(self, "_last_pdf_acquisition_context", None)
        if not isinstance(cache, dict):
            cache = {}
            self._last_pdf_acquisition_context = cache
        cache[requested_url] = acquisition_context
        cache[queue_url] = acquisition_context
        self._emit(
            "pdf_browser_context_acquisition_start",
            url=queue_url,
            parent_url=parent_url,
            requested_url=requested_url,
            candidate_count=len(candidate_urls),
            candidates=candidate_urls[:50],
        )
        if getattr(self.config, "document_browser_context_request_first", False):
            for candidate in candidate_urls:
                try:
                    result = self._download_via_browser_api_chunks(candidate, path, parent_url)
                    final_url = str(result[0] or candidate)
                    canonical_consistent = pdf_urls_consistent(requested_url, final_url, candidate_urls)
                    strict_canonical = bool(getattr(self.config, "document_require_canonical_match", False)) or str(
                        getattr(self.config, "document_canonical_match_mode", "warn")
                    ).casefold() == "strict"
                    if not canonical_consistent and strict_canonical:
                        self.stats.pdf_canonical_mismatch_failures += 1
                        self._quarantine_invalid_document(path, "canonical_mismatch", url=queue_url, stage="canonical_match_validation")
                        failures.append(f"canonical_mismatch={candidate}->{final_url}")
                        continue
                    if not canonical_consistent:
                        self.stats.pdf_canonical_alias_accepts += 1
                        self._emit(
                            "pdf_canonical_alias_accepted",
                            url=queue_url,
                            requested_url=requested_url,
                            selected_url=candidate,
                            final_url=final_url,
                            reason="Validated browser-context PDF accepted with source-page provenance.",
                        )
                    acquisition_context.update({"strategy": "playwright_browser_context_href", "selected_url": candidate, "final_url": final_url, "canonical_consistent": canonical_consistent})
                    headers = dict(result[2] or {})
                    headers["x-dell-fetch-mode"] = "playwright_browser_context_href"
                    headers["x-dell-requested-url"] = requested_url
                    headers["x-dell-candidate-count"] = str(len(candidate_urls))
                    self.stats.pdf_browser_context_primary_downloads += 1
                    self._record_pdf_recovery(
                        queue_url,
                        "playwright_browser_context_href",
                        parent_url=parent_url,
                        request_url=candidate,
                        final_url=final_url,
                        candidate_urls=candidate_urls,
                        bytes=int(result[3] or 0),
                        local_path=str(path),
                    )
                    self._emit(
                        "pdf_browser_context_acquisition_done",
                        url=queue_url,
                        strategy="browser_context_href",
                        candidate=candidate,
                        final_url=final_url,
                        bytes=int(result[3] or 0),
                    )
                    return final_url, int(result[1] or 200), headers, int(result[3] or 0)
                except Exception as exc:
                    failures.append(f"browser_context[{candidate}]={type(exc).__name__}: {exc}")
                    if isinstance(exc, DocumentValidationError):
                        self._record_pdf_validation_rejection(
                            queue_url,
                            "browser_context_candidate_validation",
                            str(exc),
                            path=path.with_suffix(path.suffix + ".part"),
                            candidate_url=candidate,
                        )
                    path.unlink(missing_ok=True)
                    path.with_suffix(path.suffix + ".part").unlink(missing_ok=True)

        # Some buttons create a signed URL only after an actual user gesture.
        # Click one visible match, never a strict global locator.
        if getattr(self.config, "document_ui_click_fallback_enabled", True):
            self.stats.pdf_ui_click_fallbacks += 1
            output_before = self._mcp_output_snapshot()
            clicked = self._click_unique_pdf_candidate(candidate_urls, str(descriptor.get("label") or "Open PDF"))
            if not clicked.get("ok"):
                # Minimal/older MCP compatibility: prefer a fresh accessibility
                # ref.  The production path above already handles duplicate hrefs
                # without strict-locator errors.
                try:
                    target, fallback_label = self._fresh_pdf_click_target(descriptor)
                    fallback = self.runtime.click(
                        target,
                        fallback_label,
                        intent=f"Open Dell PDF '{fallback_label}' after unique-target fallback",
                    )
                    if fallback.get("ok"):
                        clicked = {
                            "ok": True,
                            "status": "clicked_accessibility_fallback",
                            "chosenHref": requested_url,
                            "matchCount": 1,
                        }
                    else:
                        clicked = {**clicked, "accessibilityFallback": str(fallback.get("detail") or fallback)}
                except Exception as exc:
                    clicked = {**clicked, "accessibilityFallback": f"{type(exc).__name__}: {exc}"}
            if clicked.get("ok"):
                clicked_url = normalize_pdf_download_url(str(clicked.get("chosenHref") or requested_url))
                candidate_urls = list(dict.fromkeys([clicked_url, *candidate_urls]))
                deadline = time.monotonic() + max(8.0, float(getattr(self.config, "document_click_replay_timeout_seconds", 18.0)))
                while time.monotonic() < deadline and not self._stopped:
                    downloaded = self._find_new_pdf_in_mcp_output(output_before)
                    if downloaded is not None:
                        shutil.copy2(downloaded, path)
                        validation = validate_pdf_file_stable(path, parse_structure=True)
                        if validation.ok:
                            final_url = clicked_url
                            total = int(path.stat().st_size)
                            self.stats.document_bytes_downloaded += total
                            self.stats.pdf_browser_click_downloads += 1
                            acquisition_context.update({"strategy": "playwright_unique_source_control_download", "selected_url": clicked_url, "final_url": final_url, "canonical_consistent": pdf_urls_consistent(requested_url, final_url, candidate_urls)})
                            self._restore_document_source_page(parent_url)
                            return final_url, 200, {
                                "content-type": "application/pdf",
                                "content-length": str(total),
                                "x-dell-fetch-mode": "playwright_unique_source_control_download",
                                "x-dell-candidate-count": str(len(candidate_urls)),
                            }, total
                        self._quarantine_invalid_document(path, f"unique_click_{validation.reason}", url=queue_url, stage="source_click_download_validation")
                    captured, response_url = self._capture_pdf_network_body_candidates(candidate_urls, path, before_network)
                    if captured:
                        total = int(path.stat().st_size)
                        self.stats.document_bytes_downloaded += total
                        final_response_url = response_url or clicked_url
                        acquisition_context.update({"strategy": "playwright_unique_source_control_network_body", "selected_url": clicked_url, "final_url": final_response_url, "canonical_consistent": pdf_urls_consistent(requested_url, final_response_url, candidate_urls)})
                        self._restore_document_source_page(parent_url)
                        return final_response_url, 200, {
                            "content-type": "application/pdf",
                            "content-length": str(total),
                            "x-dell-fetch-mode": "playwright_unique_source_control_network_body",
                            "x-dell-candidate-count": str(len(candidate_urls)),
                        }, total
                    probe = self._browser_page_probe()
                    observed = normalize_pdf_download_url(str(probe.get("url") or clicked_url))
                    viewer_open = bool(probe.get("hasEmbed") or ".pdf" in observed.casefold() or "pdf" in str(probe.get("title") or "").casefold())
                    if viewer_open and self.config.browser_pdf_viewer_extraction_enabled:
                        capture = self._capture_pdf_viewer_evidence(observed, queue_url=queue_url)
                        if bool(capture.get("usable")):
                            self._cache_browser_pdf_viewer_capture(requested_url, capture)
                            self._cache_browser_pdf_viewer_capture(queue_url, capture)
                            final_viewer_url = observed or clicked_url
                            acquisition_context.update({"strategy": "playwright_unique_source_control_viewer_text_vision", "selected_url": clicked_url, "final_url": final_viewer_url, "canonical_consistent": pdf_urls_consistent(requested_url, final_viewer_url, candidate_urls)})
                            self._restore_document_source_page(parent_url)
                            return final_viewer_url, 200, {
                                "content-type": "application/pdf",
                                "content-length": "0",
                                "x-dell-fetch-mode": "playwright_unique_source_control_viewer_text_vision",
                                "x-dell-browser-viewer-pages": str(capture.get("page_count") or 0),
                                "x-dell-browser-viewer-screenshots": str(capture.get("screenshot_count") or 0),
                                "x-dell-browser-viewer-text-chars": str(capture.get("text_chars") or 0),
                            }, 0
                    time.sleep(0.4)
            else:
                failures.append(f"unique_click={clicked}")

        # v6.9 fallback: only after the real source-page click/viewer path has
        # failed, try the browser APIRequestContext against the observed hrefs.
        # This keeps user-gesture acquisition primary while retaining a bounded
        # recovery path for pages whose links are directly fetchable in-session.
        if (
            not getattr(self.config, "document_browser_context_request_first", False)
            and getattr(self.config, "document_browser_context_request_fallback", True)
        ):
            for candidate in candidate_urls:
                try:
                    result = self._download_via_browser_api_chunks(candidate, path, parent_url)
                    final_url = str(result[0] or candidate)
                    canonical_consistent = pdf_urls_consistent(requested_url, final_url, candidate_urls)
                    strict_canonical = bool(getattr(self.config, "document_require_canonical_match", False)) or str(
                        getattr(self.config, "document_canonical_match_mode", "warn")
                    ).casefold() == "strict"
                    if not canonical_consistent and strict_canonical:
                        self.stats.pdf_canonical_mismatch_failures += 1
                        self._quarantine_invalid_document(
                            path,
                            "canonical_mismatch",
                            url=queue_url,
                            stage="canonical_match_validation",
                        )
                        failures.append(f"canonical_mismatch_fallback={candidate}->{final_url}")
                        continue
                    if not canonical_consistent:
                        self.stats.pdf_canonical_alias_accepts += 1
                        self._emit(
                            "pdf_canonical_alias_accepted",
                            url=queue_url,
                            requested_url=requested_url,
                            selected_url=candidate,
                            final_url=final_url,
                            reason="Validated browser-context fallback accepted with source-page provenance.",
                        )
                    acquisition_context.update({
                        "strategy": "playwright_browser_context_fallback",
                        "selected_url": candidate,
                        "final_url": final_url,
                        "canonical_consistent": canonical_consistent,
                    })
                    headers = dict(result[2] or {})
                    headers["x-dell-fetch-mode"] = "playwright_browser_context_fallback"
                    headers["x-dell-requested-url"] = requested_url
                    headers["x-dell-candidate-count"] = str(len(candidate_urls))
                    self.stats.pdf_browser_context_primary_downloads += 1
                    self._record_pdf_recovery(
                        queue_url,
                        "playwright_browser_context_fallback",
                        parent_url=parent_url,
                        request_url=candidate,
                        final_url=final_url,
                        candidate_urls=candidate_urls,
                        bytes=int(result[3] or 0),
                        local_path=str(path),
                    )
                    self._emit(
                        "pdf_browser_context_acquisition_done",
                        url=queue_url,
                        strategy="browser_context_fallback",
                        candidate=candidate,
                        final_url=final_url,
                        bytes=int(result[3] or 0),
                    )
                    return final_url, int(result[1] or 200), headers, int(result[3] or 0)
                except Exception as exc:
                    failures.append(f"browser_context_fallback[{candidate}]={type(exc).__name__}: {exc}")
                    if isinstance(exc, DocumentValidationError):
                        self._record_pdf_validation_rejection(
                            queue_url,
                            "browser_context_fallback_validation",
                            str(exc),
                            path=path.with_suffix(path.suffix + ".part"),
                            candidate_url=candidate,
                        )
                    path.unlink(missing_ok=True)
                    path.with_suffix(path.suffix + ".part").unlink(missing_ok=True)

        raise RuntimeError(
            "Browser-context PDF acquisition exhausted without a validated binary or usable viewer: "
            + "; ".join(failures[-12:])
        )

    def _document_click_descriptor(self, queue_item: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve the real Dell page control that exposes a queued PDF."""
        item = dict(queue_item or {})
        target_url = str(item.get("_queue_url") or item.get("url") or "")
        request_url = normalize_pdf_download_url(str(item.get("download_url") or target_url))
        parent_url = canonicalize_url(str(item.get("parent_url") or ""))
        relation = str(item.get("relation") or "").upper()
        if not parent_url or not target_url:
            return {}

        target_key = self._document_match_key(request_url, parent_url)
        metadata: dict[str, Any] = {}
        try:
            metadata = self.store.get_source_metadata(parent_url)
        except Exception:
            metadata = {}

        matches: list[dict[str, Any]] = []

        def visit(value: Any, source_path: str = "metadata") -> None:
            if isinstance(value, dict):
                attrs = value.get("attrs") if isinstance(value.get("attrs"), dict) else {}
                href = str(
                    value.get("href")
                    or value.get("url")
                    or attrs.get("href")
                    or ""
                ).strip()
                if href and self._document_match_key(href, parent_url) == target_key:
                    label = re.sub(
                        r"\s+",
                        " ",
                        str(
                            value.get("label")
                            or value.get("text")
                            or value.get("title")
                            or value.get("name")
                            or attrs.get("aria-label")
                            or Path(urlparse(request_url).path).name
                        ),
                    ).strip()
                    matches.append({
                        "parent_url": parent_url,
                        "queue_url": target_url,
                        "request_url": request_url,
                        "href": canonicalize_url(href, parent_url),
                        "label": label,
                        "role": str(value.get("role") or attrs.get("role") or "link"),
                        "tag": str(value.get("tag") or "a"),
                        "ref": str(value.get("ref") or ""),
                        "source": source_path,
                    })
                for key, child in value.items():
                    if key in {"snapshot", "visible_text", "raw_html", "network_requests"}:
                        continue
                    visit(child, f"{source_path}.{key}")
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    visit(child, f"{source_path}[{index}]")

        visit(metadata)
        if matches:
            # Prefer structured browser controls over generic metadata links.
            matches.sort(
                key=lambda row: (
                    0 if "browser_structured_dom" in str(row.get("source")) else 1,
                    0 if row.get("label") else 1,
                    len(str(row.get("source") or "")),
                )
            )
            return matches[0]

        # A CONTROL_* queue relation proves the resource came from a page action,
        # even when the older database snapshot did not retain the label.
        parent_parsed = urlparse(parent_url)
        parent_is_html_dell_page = bool(
            parent_parsed.scheme in {"http", "https"}
            and parent_parsed.netloc.casefold().endswith("dell.com")
            and not is_sitemap_url(parent_url)
            and not parent_parsed.path.casefold().endswith("robots.txt")
        )
        if relation.startswith("CONTROL_") or parent_is_html_dell_page:
            return {
                "parent_url": parent_url,
                "queue_url": target_url,
                "request_url": request_url,
                "href": target_url if ".pdf" in target_url.casefold() else request_url,
                "label": Path(urlparse(request_url).path).name or "Open PDF",
                "role": "link",
                "tag": "a",
                "ref": "",
                "source": "queue_relation" if relation.startswith("CONTROL_") else "parent_page_pdf_link",
            }
        return {}

    def _runtime_supports_document_click_replay(self) -> bool:
        """Return whether the current MCP runtime can replay a source-page PDF click.

        Production PlaywrightMCPRuntime exposes all of these operations. Keeping
        the capability check explicit also lets minimal/offline runtimes fall
        back to the legacy acquisition ladder instead of failing before they can
        exercise their supported PDF strategy.
        """
        required = ("click", "tab_inventory", "snapshot", "navigate")
        if not all(callable(getattr(self.runtime, name, None)) for name in required):
            return False
        return bool(
            getattr(self.runtime, "started", False)
            or callable(getattr(self.runtime, "start", None))
        )

    def _fresh_pdf_click_target(self, descriptor: dict[str, Any]) -> tuple[str, str]:
        """Find a fresh aria ref or a unique CSS selector for the PDF control."""
        parent_url = str(descriptor.get("parent_url") or "")
        request_url = str(descriptor.get("request_url") or descriptor.get("href") or "")
        href = str(descriptor.get("href") or request_url)
        label = str(descriptor.get("label") or Path(urlparse(request_url).path).name or "Open PDF")
        target_key = self._document_match_key(request_url, parent_url)

        snap = self.runtime.snapshot(
            boxes=False,
            intent=f"Locate Dell PDF control '{label}' on its source page",
        )
        if snap.get("ok"):
            detail = str(snap.get("detail") or "")
            for link in extract_links(detail, parent_url):
                if self._document_match_key(link.url, parent_url) == target_key and link.ref:
                    return link.ref, label
            for control in extract_safe_controls(detail):
                if label and normalize_label(control.label) == normalize_label(label) and control.ref:
                    return control.ref, label

        # Current Playwright MCP accepts unique CSS selectors as click targets.
        # Use the exact href observed on the Dell source page, preserving any
        # .external or tracking suffix that the browser click requires.
        css_href = href.replace("\\", "\\\\").replace('"', '\\"')
        if css_href:
            return f'a[href="{css_href}"]', label
        filename = Path(urlparse(request_url).path).name.replace('"', '\\"')
        if filename:
            return f'a[href*="{filename}"]', label
        return label, label

    def _download_resource_via_parent_click(
        self,
        queue_item: dict[str, Any],
        path: Path,
        descriptor: dict[str, Any],
    ) -> tuple[str, int, dict[str, str], int]:
        """Acquire a PDF by replaying the real source-page click.

        This is the compatibility click path for Dell brochures, whitepapers and spec
        sheets. It intentionally performs no standalone HTTP request. The browser
        retains the user gesture, source-page referrer, cookies and redirect chain
        that made the resource available when the crawler originally clicked it.
        """
        self._ensure_runtime()
        parent_url = str(descriptor.get("parent_url") or queue_item.get("parent_url") or "")
        queue_url = str(queue_item.get("_queue_url") or queue_item.get("url") or descriptor.get("queue_url") or "")
        request_url = str(descriptor.get("request_url") or normalize_pdf_download_url(queue_url))
        label = str(descriptor.get("label") or "Open PDF")
        path.parent.mkdir(parents=True, exist_ok=True)
        before_tabs: list[dict[str, Any]] = []
        source_tab: dict[str, Any] | None = None
        opened_tab_index: int | None = None
        errors: list[str] = []

        self.stats.pdf_browser_click_replays += 1
        self.stats.pdf_direct_http_skipped_for_click += 1
        self._emit(
            "pdf_click_acquisition_start",
            url=queue_url,
            request_url=request_url,
            parent_url=parent_url,
            label=label,
            descriptor_source=str(descriptor.get("source") or ""),
        )

        try:
            # Work in the persistent browser context. Reusing an existing parent
            # tab avoids losing authenticated/consented session state.
            before_tabs = self.runtime.tab_inventory(intent="Remember tabs before Dell PDF click replay")
            for tab in before_tabs:
                if canonicalize_url(str(tab.get("url") or ""), parent_url) == canonicalize_url(parent_url):
                    source_tab = tab
                    break
            if source_tab is not None:
                self.runtime.select_tab(int(source_tab.get("index", 0)), intent="Select Dell PDF source page")
            else:
                self.runtime.tabs("new", url=parent_url, intent="Open Dell PDF source page in an isolated tab")
                time.sleep(0.5)
                opened = self.runtime.tab_inventory(intent="Locate opened Dell PDF source page")
                source_tab = next((tab for tab in opened if tab.get("current")), None)
                if source_tab is not None:
                    opened_tab_index = int(source_tab.get("index", -1))

            probe = self._browser_page_probe()
            if canonicalize_url(str(probe.get("url") or "")) != canonicalize_url(parent_url):
                nav = self.runtime.navigate(parent_url, intent="Navigate to Dell page containing the PDF button")
                if not nav.get("ok"):
                    raise RuntimeError(str(nav.get("detail") or "Could not open PDF source page"))
            self.runtime.wait(1.0, intent="Wait for Dell PDF source page controls")

            click_target, click_label = self._fresh_pdf_click_target(descriptor)
            output_before = self._mcp_output_snapshot()
            tabs_before_click = self.runtime.tab_inventory(intent="Observe tabs before clicking Dell PDF control")
            before_indices = {int(tab.get("index", -1)) for tab in tabs_before_click}
            click_result = self.runtime.click(
                click_target,
                click_label,
                intent=(
                    f"Open Dell document '{click_label}' from its published source page; "
                    "read-only knowledge extraction only"
                ),
            )
            if not click_result.get("ok"):
                raise RuntimeError(
                    "Dell PDF control click failed: "
                    + str(click_result.get("detail") or click_result.get("status") or "unknown")[:1800]
                )

            deadline = time.monotonic() + max(
                5.0,
                float(getattr(self.config, "document_click_replay_timeout_seconds", 18.0)),
            )
            current_url = request_url
            selected_resource_tab: int | None = None
            while time.monotonic() < deadline and not self._stopped:
                downloaded = self._find_new_pdf_in_mcp_output(output_before)
                if downloaded is not None:
                    shutil.copy2(downloaded, path)
                    validation = validate_pdf_file_stable(path, parse_structure=True)
                    if validation.ok:
                        total = int(path.stat().st_size)
                        self.stats.document_bytes_downloaded += total
                        self.stats.document_browser_fallbacks += 1
                        self.stats.pdf_browser_click_downloads += 1
                        self._record_pdf_recovery(
                            queue_url,
                            "playwright_source_control_download",
                            bytes=total,
                            parent_url=parent_url,
                            label=click_label,
                            local_path=str(path),
                        )
                        self._emit("pdf_click_acquisition_done", url=queue_url, strategy="download", bytes=total)
                        return request_url, 200, {
                            "content-type": "application/pdf",
                            "content-length": str(total),
                            "x-dell-fetch-mode": "playwright_source_control_download",
                            "x-dell-click-parent": parent_url,
                            "x-dell-click-label": click_label,
                        }, total
                    self._quarantine_invalid_document(path, f"click_download_{validation.reason}", url=queue_url, stage="parent_click_download_validation")

                tabs_after = self.runtime.tab_inventory(intent="Observe document opened by Dell PDF control")
                new_tabs = [tab for tab in tabs_after if int(tab.get("index", -1)) not in before_indices]
                resource_tab = next((tab for tab in new_tabs if tab.get("current")), None) or (new_tabs[-1] if new_tabs else None)
                if resource_tab is not None:
                    index = int(resource_tab.get("index", -1))
                    if index >= 0 and index != selected_resource_tab:
                        self.runtime.select_tab(index, intent="Select PDF opened by Dell source-page control")
                        selected_resource_tab = index
                    observed = canonicalize_url(str(resource_tab.get("url") or ""), parent_url)
                    if observed and observed != "about:blank":
                        current_url = observed
                else:
                    current_probe = self._browser_page_probe()
                    observed = canonicalize_url(str(current_probe.get("url") or ""), parent_url)
                    if observed and observed != canonicalize_url(parent_url):
                        current_url = observed

                # The real click has already produced the request in this browser
                # context. Save that exact response body rather than issuing a new
                # URL request that may receive a CDN 403.
                for candidate in (current_url, request_url, str(descriptor.get("href") or "")):
                    if candidate and self._document_match_key(candidate, parent_url) == self._document_match_key(request_url, parent_url):
                        try:
                            if self._capture_pdf_network_body(candidate, path):
                                validation = validate_pdf_file_stable(path, parse_structure=True)
                                if validation.ok:
                                    total = int(path.stat().st_size)
                                    self.stats.document_bytes_downloaded += total
                                    self.stats.document_browser_fallbacks += 1
                                    self.stats.pdf_browser_click_downloads += 1
                                    self._record_pdf_recovery(
                                        queue_url,
                                        "playwright_source_control_network_body",
                                        bytes=total,
                                        parent_url=parent_url,
                                        label=click_label,
                                        local_path=str(path),
                                    )
                                    self._emit("pdf_click_acquisition_done", url=queue_url, strategy="network_body", bytes=total)
                                    return current_url or request_url, 200, {
                                        "content-type": "application/pdf",
                                        "content-length": str(total),
                                        "x-dell-fetch-mode": "playwright_source_control_network_body",
                                        "x-dell-click-parent": parent_url,
                                        "x-dell-click-label": click_label,
                                    }, total
                        except Exception as exc:
                            errors.append(f"network_body={type(exc).__name__}: {exc}")

                probe_after = self._browser_page_probe()
                pdf_viewer_open = bool(
                    probe_after.get("hasEmbed")
                    or ".pdf" in str(probe_after.get("url") or current_url).lower()
                    or "pdf" in str(probe_after.get("title") or "").lower()
                )
                if pdf_viewer_open and self.config.browser_pdf_viewer_extraction_enabled:
                    capture_url = str(probe_after.get("url") or current_url or request_url)
                    capture = self._capture_pdf_viewer_evidence(capture_url, queue_url=queue_url)
                    if bool(capture.get("usable")):
                        self._cache_browser_pdf_viewer_capture(request_url, capture)
                        self._cache_browser_pdf_viewer_capture(queue_url, capture)
                        self.stats.document_browser_fallbacks += 1
                        self.stats.pdf_browser_click_viewer_captures += 1
                        self._record_pdf_recovery(
                            queue_url,
                            "playwright_source_control_viewer_text_vision",
                            parent_url=parent_url,
                            label=click_label,
                            text_chars=int(capture.get("text_chars") or 0),
                            screenshots=int(capture.get("screenshot_count") or 0),
                            page_count=int(capture.get("page_count") or 0),
                            manifest=str(capture.get("manifest_path") or ""),
                        )
                        self._emit(
                            "pdf_click_acquisition_done",
                            url=queue_url,
                            strategy="viewer_text_vision",
                            text_chars=int(capture.get("text_chars") or 0),
                            screenshots=int(capture.get("screenshot_count") or 0),
                        )
                        return capture_url, 200, {
                            "content-type": "application/pdf",
                            "content-length": "0",
                            "x-dell-fetch-mode": "playwright_source_control_viewer_text_vision",
                            "x-dell-click-parent": parent_url,
                            "x-dell-click-label": click_label,
                            "x-dell-browser-viewer-pages": str(capture.get("page_count") or 0),
                            "x-dell-browser-viewer-screenshots": str(capture.get("screenshot_count") or 0),
                            "x-dell-browser-viewer-text-chars": str(capture.get("text_chars") or 0),
                        }, 0
                time.sleep(0.35)

            raise RuntimeError(
                "Dell PDF control was clicked, but no PDF download, network body, or usable browser viewer "
                "was captured. " + "; ".join(errors[-6:])
            )
        finally:
            # Close only the resource tab created by the click. Then restore the
            # exact Dell source page so the crawler can safely continue/resume.
            try:
                tabs_now = self.runtime.tab_inventory(intent="Restore source page after Dell PDF click")
                parent_key = canonicalize_url(parent_url)
                parent_tab = next(
                    (tab for tab in tabs_now if canonicalize_url(str(tab.get("url") or ""), parent_url) == parent_key),
                    None,
                )
                source_index = int(source_tab.get("index", -1)) if source_tab is not None else -1
                for tab in list(tabs_now):
                    index = int(tab.get("index", -1))
                    tab_url = canonicalize_url(str(tab.get("url") or ""), parent_url)
                    if (
                        index >= 0
                        and index != source_index
                        and tab_url != parent_key
                        and self._document_match_key(tab_url, parent_url)
                        == self._document_match_key(request_url, parent_url)
                    ):
                        try:
                            self.runtime.close_tab(index, intent="Close PDF tab after extraction")
                        except Exception:
                            pass
                if parent_tab is not None:
                    self.runtime.select_tab(int(parent_tab.get("index", 0)), intent="Return to Dell PDF source page")
                else:
                    # Some document links navigate the source tab rather than
                    # opening a popup. Reuse that tab and navigate back instead
                    # of closing the crawler's only browser page.
                    if source_index >= 0:
                        try:
                            self.runtime.select_tab(source_index, intent="Select source tab after PDF navigation")
                        except Exception:
                            pass
                    self.runtime.navigate(parent_url, intent="Restore Dell PDF source page")
            except Exception:
                pass


    def _download_resource_via_browser(
        self,
        url: str,
        path: Path,
        parent_url: str = "",
    ) -> tuple[str, int, dict[str, str], int]:
        """Recover a public PDF through the persistent Playwright browser.

        v6.5 deliberately opens an isolated blank tab first and then calls the
        official navigation tool. This removes ambiguity between a tab-creation
        request and a PDF navigation/download. Viewer extraction is attempted
        even when MCP tab-list text cannot be parsed, because current-page probes,
        screenshots and accessibility snapshots still work.
        """
        self._ensure_runtime()
        self._emit("document_browser_fallback_start", url=url, parent_url=parent_url)
        before_tabs = self.runtime.tab_inventory(intent="Remember tabs before PDF recovery")
        current_before = next((tab for tab in before_tabs if tab.get("current")), None)
        before_indices = {int(tab.get("index", -1)) for tab in before_tabs}
        output_before = self._mcp_output_snapshot()
        recovery_tab_index: int | None = None
        opened_isolated_tab = False
        navigation_attempted = False
        recovery_errors: list[str] = []

        try:
            if self.config.document_browser_navigation_probe_enabled:
                open_result = self.runtime.tabs(
                    "new",
                    intent="Open isolated tab for Dell PDF recovery",
                )
                if not open_result.get("ok"):
                    raise RuntimeError(
                        "Could not create isolated PDF recovery tab: "
                        + str(open_result.get("detail") or "")[:1800]
                    )
                opened_isolated_tab = True
                time.sleep(0.25)

                after_open = self.runtime.tab_inventory(intent="Locate isolated PDF recovery tab")
                current_after_open = next((tab for tab in after_open if tab.get("current")), None)
                new_candidates = [
                    tab for tab in after_open
                    if int(tab.get("index", -1)) not in before_indices
                ]
                chosen_tab = current_after_open or (new_candidates[-1] if new_candidates else None)
                if chosen_tab is not None:
                    recovery_tab_index = int(chosen_tab.get("index", -1))
                    if recovery_tab_index >= 0:
                        try:
                            self.runtime.select_tab(
                                recovery_tab_index,
                                intent="Select isolated Dell PDF recovery tab",
                            )
                        except Exception as exc:
                            recovery_errors.append(
                                f"select_recovery_tab={type(exc).__name__}: {exc}"
                            )

                navigation_attempted = True
                try:
                    nav_result = self.runtime.navigate(
                        url,
                        intent="Navigate isolated tab to Dell PDF",
                    )
                    if not nav_result.get("ok"):
                        recovery_errors.append(
                            "browser_navigate="
                            + str(nav_result.get("detail") or nav_result.get("status") or "failed")[:1800]
                        )
                except Exception as exc:
                    # A browser may report an aborted navigation when it converts
                    # the response into a download or built-in PDF viewer. Keep
                    # inspecting output/network/viewer evidence before declaring
                    # failure.
                    recovery_errors.append(f"browser_navigate={type(exc).__name__}: {exc}")

                try:
                    self.runtime.wait(1.5, intent="Wait for Dell PDF viewer or download to initialise")
                except Exception:
                    time.sleep(1.5)

                after_navigation = self.runtime.tab_inventory(
                    intent="Inspect Dell PDF recovery tab after navigation"
                )
                current_after_navigation = next(
                    (tab for tab in after_navigation if tab.get("current")),
                    None,
                )
                if current_after_navigation is not None:
                    recovery_tab_index = int(current_after_navigation.get("index", recovery_tab_index or -1))

                probe = self._browser_page_probe()
                self._emit(
                    "document_browser_navigation_probe",
                    url=url,
                    current_url=str(probe.get("url") or ""),
                    title=str(probe.get("title") or ""),
                    ready_state=str(probe.get("readyState") or ""),
                    has_pdf_embed=bool(probe.get("hasEmbed")),
                    tab_index=recovery_tab_index,
                )

                downloaded = self._find_new_pdf_in_mcp_output(output_before)
                if downloaded is not None:
                    try:
                        path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(downloaded, path)
                        validation = validate_pdf_file_stable(path, parse_structure=True)
                        if validation.ok:
                            total = int(path.stat().st_size)
                            self.stats.document_bytes_downloaded += total
                            self.stats.document_browser_fallbacks += 1
                            self.stats.pdf_browser_navigation_downloads += 1
                            self._record_pdf_recovery(
                                url,
                                "playwright_navigation_download",
                                bytes=total,
                                local_path=str(path),
                            )
                            return url, 200, {
                                "content-type": "application/pdf",
                                "content-length": str(total),
                                "x-dell-fetch-mode": "playwright_navigation_download",
                            }, total
                        self._quarantine_invalid_document(path, validation.reason, url=url, stage="browser_navigation_download_validation")
                    except Exception as exc:
                        recovery_errors.append(
                            f"navigation_download={type(exc).__name__}: {exc}"
                        )

                try:
                    if self._capture_pdf_network_body(url, path):
                        validation = validate_pdf_file_stable(path, parse_structure=True)
                        if validation.ok:
                            total = int(path.stat().st_size)
                            self.stats.document_bytes_downloaded += total
                            self.stats.document_browser_fallbacks += 1
                            self._record_pdf_recovery(
                                url,
                                "playwright_network_response_body",
                                bytes=total,
                                local_path=str(path),
                            )
                            return url, 200, {
                                "content-type": "application/pdf",
                                "content-length": str(total),
                                "x-dell-fetch-mode": "playwright_network_response_body",
                            }, total
                        self._quarantine_invalid_document(path, validation.reason, url=url, stage="browser_network_body_validation")
                except Exception as exc:
                    recovery_errors.append(f"network_body={type(exc).__name__}: {exc}")

            if self.config.document_browser_api_request_enabled:
                try:
                    result = self._download_via_browser_api_chunks(url, path, parent_url)
                    self._record_pdf_recovery(
                        url,
                        "playwright_browser_api_request",
                        bytes=int(result[3] or 0),
                        local_path=str(path),
                    )
                    return result
                except Exception as exc:
                    recovery_errors.append(
                        f"browser_api_request={type(exc).__name__}: {exc}"
                    )

            # Final recovery: capture the browser-rendered PDF with both text and
            # viewport images. Do this whenever navigation was attempted, even if
            # browser_tabs(list) output was empty or changed format.
            if (
                navigation_attempted
                and self.config.browser_pdf_viewer_extraction_enabled
            ):
                try:
                    capture = self._capture_pdf_viewer_evidence(url, queue_url=url)
                    if bool(capture.get("usable")):
                        self._cache_browser_pdf_viewer_capture(url, capture)
                        self.stats.document_browser_fallbacks += 1
                        self._record_pdf_recovery(
                            url,
                            "playwright_pdf_viewer_text_vision",
                            text_chars=int(capture.get("text_chars") or 0),
                            screenshots=int(capture.get("screenshot_count") or 0),
                            page_count=int(capture.get("page_count") or 0),
                            manifest=str(capture.get("manifest_path") or ""),
                        )
                        self._emit(
                            "document_browser_viewer_fallback_done",
                            url=url,
                            text_chars=int(capture.get("text_chars") or 0),
                            screenshots=int(capture.get("screenshot_count") or 0),
                            page_count=int(capture.get("page_count") or 0),
                        )
                        return str(capture.get("final_url") or url), 200, {
                            "content-type": "application/pdf",
                            "content-length": "0",
                            "x-dell-fetch-mode": "playwright_pdf_viewer_text_vision",
                            "x-dell-browser-viewer-pages": str(capture.get("page_count") or 0),
                            "x-dell-browser-viewer-screenshots": str(capture.get("screenshot_count") or 0),
                            "x-dell-browser-viewer-text-chars": str(capture.get("text_chars") or 0),
                        }, 0
                    recovery_errors.append(
                        "browser_viewer=opened but no text or screenshot evidence was captured"
                    )
                except Exception as exc:
                    recovery_errors.append(
                        f"browser_viewer={type(exc).__name__}: {exc}"
                    )

            detail = "; ".join(recovery_errors[-10:]) or (
                "No browser PDF recovery strategy was available."
            )
            raise RuntimeError(
                f"All configured browser PDF recovery strategies failed: {detail}"
            )
        finally:
            if recovery_tab_index is not None and recovery_tab_index >= 0:
                try:
                    self.runtime.close_tab(
                        recovery_tab_index,
                        intent="Close Dell PDF recovery tab",
                    )
                except Exception:
                    pass
            elif opened_isolated_tab:
                # The tab-list format can change across MCP releases. We still
                # know that this method created an isolated current tab, so close
                # the current tab without an index rather than leaking it.
                try:
                    self.runtime.tabs(
                        "close",
                        intent="Close current isolated Dell PDF recovery tab",
                    )
                except Exception:
                    pass

            if current_before is not None:
                try:
                    self.runtime.select_tab(
                        int(current_before.get("index", 0)),
                        intent="Restore Dell source tab after PDF recovery",
                    )
                except Exception:
                    pass

    def _download_resource_resumable(
        self,
        url: str,
        path: Path,
        queue_item: dict[str, Any] | None = None,
    ) -> tuple[str, int, dict[str, str], int]:
        """Download and validate one public Dell PDF with durable recovery.

        A transport-level success is never treated as a document-level success.
        Existing files, resumed partials, direct HTTP responses, and browser
        fallbacks must all pass PDF signature and structural validation before an
        atomic rename exposes the final document to the extraction pipeline.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        part_path = path.with_suffix(path.suffix + ".part")
        queue_url = str((queue_item or {}).get("_queue_url") or (queue_item or {}).get("url") or url)
        parent_url = canonicalize_url(str((queue_item or {}).get("parent_url") or ""))

        # Never reuse a historical HTML block page or truncated file simply
        # because it has a .pdf suffix. This was the main resume-loop defect in
        # v6.1: an invalid final file could survive forever and fail in PdfReader.
        if path.exists():
            if self._validated_existing_pdf(path, queue_url):
                return canonicalize_url(url), 200, {
                    "content-type": "application/pdf",
                    "content-length": str(path.stat().st_size),
                    "x-dell-fetch-mode": "validated_existing_file",
                }, int(path.stat().st_size)

        # v6.7 browser-context-first acquisition.  A Dell page may repeat the
        # same PDF link dozens of times or expose it through a shadow root/frame.
        # Read and de-duplicate those hrefs, then fetch through the live browser
        # context.  This preserves cookies, user-agent, locale and Referer and
        # avoids the standalone CDN request responsible for the production 403s.
        descriptor = self._document_click_descriptor(queue_item)
        browser_error: Exception | None = None
        if descriptor and self._runtime_supports_document_click_replay():
            try:
                return self._download_resource_via_browser_context_first(
                    dict(queue_item or {}), path, descriptor
                )
            except Exception as exc:
                # The full production runtime already performs the real source
                # click, exact network-body capture, viewer capture and browser-
                # context fallback inside the primary routine.  Only minimal or
                # older runtimes that lack the structured-result parser need the
                # compatibility parent-click path; this avoids duplicate clicks
                # and duplicate validation candidates in production.
                browser_error = exc
                legacy_runtime = not callable(getattr(self.runtime, "_parse_json_detail", None))
                if self.config.document_click_first_enabled and legacy_runtime:
                    try:
                        return self._download_resource_via_parent_click(
                            dict(queue_item or {}), path, descriptor
                        )
                    except Exception as click_exc:
                        browser_error = click_exc

        if not getattr(self.config, "document_direct_http_enabled", False):
            self.stats.pdf_direct_http_disabled_skips += 1
            try:
                # Standalone/sitemap PDFs have no parent control.  They still use
                # the browser transport/navigation/viewer ladder rather than raw
                # httpx, so browser cookies and corporate network state are kept.
                return self._download_resource_via_browser(
                    url, path, parent_url=parent_url or canonicalize_url(url)
                )
            except Exception as browser_only_exc:
                if browser_error is not None:
                    raise RuntimeError(
                        "Browser-context and browser-viewer PDF acquisition failed: "
                        f"primary={type(browser_error).__name__}: {browser_error}; "
                        f"fallback={type(browser_only_exc).__name__}: {browser_only_exc}"
                    ) from browser_only_exc
                raise

        # A partial may be resumed only if its first bytes are PDF bytes. It need
        # not yet be structurally complete.
        if part_path.exists():
            partial_validation = validate_pdf_file(part_path, parse_structure=False)
            if not partial_validation.ok:
                self._quarantine_invalid_document(part_path, f"invalid_partial_{partial_validation.reason}", url=queue_url, stage="resume_partial_validation")
        existing = int(part_path.stat().st_size) if part_path.exists() else 0

        request_headers: dict[str, str] = {
            "Accept": "application/pdf,application/octet-stream;q=0.9,*/*;q=0.7",
            "Accept-Language": accept_language_for_locale(str(getattr(getattr(self, "config", None), "locale", "en-uk") or "en-uk")),
            "Accept-Encoding": "identity",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-site",
        }
        if parent_url:
            request_headers["Referer"] = parent_url
        if self.config.document_download_resume and existing > 0:
            request_headers["Range"] = f"bytes={existing}-"

        try:
            with self.http.stream("GET", url, headers=request_headers) as response:
                if response.status_code == 416 and existing > 0:
                    validation = validate_pdf_file(part_path, parse_structure=True)
                    if not validation.ok:
                        self._quarantine_invalid_document(part_path, f"range_416_invalid_{validation.reason}", url=queue_url, stage="range_resume_validation")
                        raise DocumentValidationError(
                            f"Server returned HTTP 416 but the durable partial was not a complete PDF: {validation.reason}"
                        )
                    part_path.replace(path)
                    self.stats.pdf_direct_downloads += 1
                    return canonicalize_url(str(response.url), url), 200, {
                        **dict(response.headers),
                        "x-dell-fetch-mode": "direct_http_416_validated_partial",
                    }, int(path.stat().st_size)

                response.raise_for_status()
                append = bool(existing > 0 and response.status_code == 206)
                if existing > 0 and not append:
                    # The server ignored Range. Restart cleanly rather than append
                    # the full response to an existing partial.
                    existing = 0
                    part_path.unlink(missing_ok=True)
                mode = "ab" if append else "wb"
                total_bytes = existing
                next_progress = total_bytes + 8 * 1024 * 1024
                first_payload_checked = bool(existing > 0)

                with part_path.open(mode) as handle:
                    for chunk in response.iter_bytes(1024 * 1024):
                        if self._stopped:
                            raise KeyboardInterrupt("Crawler stop requested during document download")
                        if not chunk:
                            continue
                        if not first_payload_checked:
                            first_payload_checked = True
                            first_validation = validate_pdf_bytes(chunk)
                            if not first_validation.ok:
                                raise DocumentValidationError(
                                    "Direct HTTP returned non-PDF content: "
                                    f"{first_validation.reason}; status={response.status_code}; "
                                    f"content-type={response.headers.get('content-type', '')!r}"
                                )
                        total_bytes += len(chunk)
                        if not self.config.pdf_size_allows(total_bytes):
                            raise RuntimeError(
                                f"Document exceeds configured DELL_CRAWL_MAX_PDF_MB={self.config.max_pdf_mb}: "
                                f"{total_bytes} bytes"
                            )
                        handle.write(chunk)
                        if total_bytes >= next_progress:
                            handle.flush()
                            os.fsync(handle.fileno())
                            self.store.touch_queue(queue_url, self.run_id, self.config.worker_lease_seconds)
                            self._emit("document_download_progress", url=url, bytes_downloaded=total_bytes)
                            next_progress = total_bytes + 8 * 1024 * 1024
                    handle.flush()
                    os.fsync(handle.fileno())

                if not first_payload_checked:
                    raise DocumentValidationError("Direct HTTP response contained no PDF bytes.")
                validation = validate_pdf_file(part_path, parse_structure=True)
                if not validation.ok:
                    self._quarantine_invalid_document(part_path, f"direct_http_{validation.reason}", url=queue_url, stage="direct_http_structural_validation")
                    raise DocumentValidationError(f"Direct HTTP PDF validation failed: {validation.reason}")

                if append:
                    self.stats.pdf_download_resumes += 1
                self.stats.document_bytes_downloaded += max(0, total_bytes - existing)
                final_url = canonicalize_url(str(response.url), url)
                status_code = int(response.status_code)
                response_headers = {
                    **dict(response.headers),
                    "x-dell-fetch-mode": "direct_http",
                }
            part_path.replace(path)
            self.stats.pdf_direct_downloads += 1
            self._emit("pdf_direct_download_done", url=url, bytes=total_bytes)
            return final_url, status_code, response_headers, total_bytes

        except (httpx.HTTPStatusError, DocumentValidationError) as exc:
            status = int(exc.response.status_code) if isinstance(exc, httpx.HTTPStatusError) and exc.response is not None else 0
            self._record_pdf_transport_event(
                queue_url,
                "direct_http",
                f"{type(exc).__name__}: {exc}",
                http_status=status,
                parent_url=parent_url,
                request_url=url,
            )
            # Any 401/403 or a 200 response that is actually HTML/access-denied
            # should immediately change transport strategy. Repeating the same
            # direct request cannot make useful progress.
            should_use_browser = bool(
                self.config.document_browser_fallback_on_403
                and (status in {401, 403} or isinstance(exc, DocumentValidationError))
            )
            if should_use_browser:
                self.stats.document_http_header_retries += 1
                try:
                    result = self._download_resource_via_browser(url, path, parent_url=parent_url)
                    fetch_mode = str((result[2] or {}).get("x-dell-fetch-mode") or "")
                    if fetch_mode == "playwright_pdf_viewer_text_vision":
                        return result
                    final_validation = validate_pdf_file(path, parse_structure=True)
                    if not final_validation.ok:
                        self._quarantine_invalid_document(path, f"browser_final_{final_validation.reason}", url=queue_url, stage="browser_final_validation")
                        raise DocumentValidationError(
                            f"All browser recovery strategies produced an invalid PDF: {final_validation.reason}"
                        )
                    return result
                except Exception as browser_exc:
                    self._record_pdf_transport_event(
                        queue_url,
                        "browser_recovery",
                        f"{type(browser_exc).__name__}: {browser_exc}",
                        direct_error=f"{type(exc).__name__}: {exc}",
                        parent_url=parent_url,
                        request_url=url,
                        local_path=str(path),
                        local_path_length=len(str(path)),
                    )
                    raise
            raise
        except BaseException as exc:
            # Keep a valid-looking .part for a future resume. Invalid content is
            # quarantined by the validation branches above.
            if not isinstance(exc, KeyboardInterrupt):
                self._record_pdf_transport_event(
                    queue_url,
                    "download",
                    f"{type(exc).__name__}: {exc}",
                    parent_url=parent_url,
                    request_url=url,
                    local_path=str(path),
                    local_path_length=len(str(path)),
                )
            raise

    def _process_pdf(self, queue_item: dict[str, Any]) -> dict[str, int]:
        url = str(queue_item["url"])
        download_url = normalize_pdf_download_url(url)
        depth = int(queue_item.get("depth") or 0)
        path = short_pdf_storage_path(self.document_dir, download_url)
        path.parent.mkdir(parents=True, exist_ok=True)
        download_context = dict(queue_item)
        download_context["_queue_url"] = url
        self._emit(
            "pdf_start",
            url=url,
            download_url=download_url,
            depth=depth,
            local_path=str(path),
            local_path_length=len(str(path)),
        )

        final_url, status_code, response_headers, total_bytes = self._download_resource_resumable(
            download_url, path, download_context
        )
        fetch_mode = str(response_headers.get("x-dell-fetch-mode") or "unknown")
        acquisition_context = (
            getattr(self, "_last_pdf_acquisition_context", {}).get(download_url)
            or getattr(self, "_last_pdf_acquisition_context", {}).get(url)
            or {}
        )
        candidate_aliases = (
            acquisition_context.get("candidate_urls", [])
            if isinstance(acquisition_context, dict)
            else []
        )
        final_parsed = urlparse(str(final_url or ""))
        final_is_named_pdf = bool(
            final_parsed.scheme in {"http", "https"}
            and ".pdf" in final_parsed.path.casefold()
        )
        canonical_consistent = pdf_urls_consistent(download_url, str(final_url), candidate_aliases)
        strict_canonical = bool(getattr(self.config, "document_require_canonical_match", False)) or str(
            getattr(self.config, "document_canonical_match_mode", "warn")
        ).casefold() == "strict"
        if final_is_named_pdf and not canonical_consistent:
            if strict_canonical:
                self.stats.pdf_canonical_mismatch_failures += 1
                if path.exists():
                    self._quarantine_invalid_document(
                        path,
                        "canonical_mismatch_before_extraction",
                        url=url,
                        stage="canonical_match_before_extraction",
                    )
                raise DocumentValidationError(
                    f"Acquired PDF URL does not match requested/observed document aliases: "
                    f"requested={download_url!r} final={final_url!r}"
                )
            self.stats.pdf_canonical_alias_accepts += 1
            self._emit(
                "pdf_canonical_alias_accepted",
                url=url,
                requested_url=download_url,
                final_url=str(final_url),
                candidate_aliases=candidate_aliases[:20],
                reason="Validated browser-acquired PDF retained; redirect/signed URL differs from discovery alias.",
            )
        browser_only = fetch_mode in {
            "playwright_pdf_viewer_text_vision",
            "playwright_source_control_viewer_text_vision",
            "playwright_unique_source_control_viewer_text_vision",
        }
        browser_capture = self._get_browser_pdf_viewer_capture(download_url) if browser_only else {}

        page_texts: list[str] = []
        visible_parts: list[str] = []
        local_visual_evidence: list[dict[str, Any]] = []
        visual_warnings: list[str] = []
        page_count = 0
        title = ""
        validation_payload: dict[str, Any]
        local_path_value = ""

        if not browser_only:
            validation = validate_pdf_file(path, parse_structure=True)
            if not validation.ok:
                self._quarantine_invalid_document(path, f"pre_extract_{validation.reason}", url=url, stage="pre_extraction_validation")
                raise DocumentValidationError(f"Downloaded PDF failed pre-extraction validation: {validation.reason}")
            validation_payload = validation.to_dict()
            local_path_value = str(path)

            reader = PdfReader(str(path), strict=False)
            page_count = len(reader.pages)
            for index, pdf_page in enumerate(reader.pages):
                try:
                    text_value = pdf_page.extract_text() or ""
                except Exception as exc:
                    text_value = f"[Page {index+1} extraction failed: {type(exc).__name__}: {exc}]"
                page_texts.append(text_value)
                visible_parts.append(f"\n===== PDF BINARY TEXT PAGE {index+1} =====\n{text_value}")
                if (index + 1) % 10 == 0 or index + 1 == page_count:
                    self._emit(
                        "pdf_text_progress",
                        url=url,
                        extracted_pages=index + 1,
                        total_pages=page_count,
                    )
            try:
                title = str((reader.metadata or {}).get("/Title") or "").strip()
            except Exception:
                title = ""
            local_visual_evidence, visual_warnings = self._render_pdf_visual_pages(
                path, final_url or download_url, page_texts
            )
            self.stats.pdf_binary_files_stored += 1
        else:
            if not browser_capture or not bool(browser_capture.get("usable")):
                raise DocumentValidationError(
                    "Browser PDF viewer fallback was selected but no persisted text or screenshot evidence is available."
                )
            validation_payload = {
                "ok": True,
                "reason": "browser_viewer_evidence_only",
                "parse_structure": False,
                "binary_available": False,
            }
            text_blocks = browser_capture.get("text_blocks")
            if isinstance(text_blocks, list):
                page_texts = [str(value) for value in text_blocks if str(value).strip()]
                visible_parts.extend(page_texts)
            page_count = int(browser_capture.get("page_count") or len(page_texts) or 0)
            title = str(browser_capture.get("title") or "").strip()
            raw_visual = browser_capture.get("visual_evidence")
            if isinstance(raw_visual, list):
                local_visual_evidence = [dict(item) for item in raw_visual if isinstance(item, dict)]
            raw_warnings = browser_capture.get("warnings")
            if isinstance(raw_warnings, list):
                visual_warnings.extend(str(value) for value in raw_warnings if str(value).strip())
            self.stats.pdf_browser_only_processed += 1
            self._emit(
                "pdf_browser_only_extraction_start",
                url=url,
                pages=page_count,
                text_chars=sum(len(value) for value in page_texts),
                screenshots=len(local_visual_evidence),
            )

        browser_text_blocks = browser_capture.get("text_blocks") if isinstance(browser_capture, dict) else []
        if not browser_only and isinstance(browser_text_blocks, list):
            # Normally absent because binary recovery returns before viewer capture.
            # Kept for forward compatibility and evidence reconciliation.
            for value in browser_text_blocks:
                value = str(value or "").strip()
                if value:
                    visible_parts.append(f"\n===== BROWSER PDF VIEWER TEXT =====\n{value}")

        visual_evidence = dedupe_visual_evidence(
            local_visual_evidence
            + (
                [dict(item) for item in browser_capture.get("visual_evidence", []) if isinstance(item, dict)]
                if isinstance(browser_capture, dict)
                else []
            )
        )
        visible_text = "".join(visible_parts).strip()
        if not visible_text and not visual_evidence:
            raise DocumentValidationError("PDF extraction produced neither text nor visual evidence.")

        if not title:
            title = Path(urlparse(download_url).path).name or "Dell PDF document"
        canonical_final = canonicalize_url(str(final_url or download_url), download_url)
        if not canonical_final.startswith(("http://", "https://")):
            canonical_final = canonicalize_url(download_url)
        links = self._pdf_links_from_text(visible_text, canonical_final)

        page = CrawlPage(
            url=url,
            canonical_url=canonical_final,
            title=title,
            page_type="Document",
            snapshot="",
            visible_text=visible_text,
            links=links,
            controls=[],
            screenshot_path=(str(visual_evidence[0].get("path")) if visual_evidence else ""),
            screenshot_paths=[str(item.get("path")) for item in visual_evidence if item.get("path")],
            visual_assets=[],
            http_status=status_code,
            content_hash=content_hash(visible_text or json.dumps(visual_evidence, sort_keys=True, default=str)),
            metadata={
                "mime_type": response_headers.get("content-type", "application/pdf"),
                "pdf_pages": page_count,
                "pdf_bytes": total_bytes,
                "local_path": local_path_value,
                "last_modified": response_headers.get("last-modified", ""),
                "etag": response_headers.get("etag", ""),
                "download_strategy": fetch_mode,
                "discovered_url": url,
                "download_url": download_url,
                "pdf_validation": validation_payload,
                "binary_pdf_available": not browser_only,
                "browser_pdf_viewer_processed": browser_only,
                "browser_pdf_viewer_capture": browser_capture if browser_capture else {},
                "visual_evidence": visual_evidence,
                "visual_warnings": visual_warnings,
                "pdf_acquisition_context": acquisition_context,
                "requested_url": download_url,
                "final_url": str(final_url or download_url),
                "canonical_consistent": pdf_urls_consistent(
                    download_url,
                    str(final_url or download_url),
                    (
                        getattr(self, "_last_pdf_acquisition_context", {}).get(download_url, {}).get("candidate_urls", [])
                        if isinstance(getattr(self, "_last_pdf_acquisition_context", {}).get(download_url, {}), dict)
                        else []
                    ),
                ),
            },
        )

        extraction = self.extractor.extract(page)
        self._record_extraction_quality(extraction)
        mapping_result = page.metadata.get("product_evidence_mapping") if isinstance(page.metadata, dict) else {}
        if isinstance(mapping_result, dict):
            self.stats.product_unmapped_fields_mapped += int(mapping_result.get("unmapped_fields_mapped") or 0)
        vision_text = str(extraction.get("vision_text") or "").strip()
        if vision_text:
            page.visible_text = f"{page.visible_text}\n\n===== DELL AIA VISION EVIDENCE =====\n{vision_text}"
            page.content_hash = content_hash(page.visible_text)
        vision_records = extraction.get("vision_evidence") if isinstance(extraction.get("vision_evidence"), list) else []
        page.metadata["vision_evidence_count"] = len(vision_records)
        page.metadata["vision_extraction_mode"] = extraction.get("extraction_mode", "")
        self.stats.visual_evidence_analyzed += len(vision_records)
        page.metadata["long_form_chunk_count"] = int(extraction.get("chunk_count") or 0)
        page.metadata["document_summary_present"] = bool(extraction.get("document_summary"))
        if extraction.get("document_summary") or (
            isinstance(extraction.get("page"), dict) and extraction.get("page", {}).get("summary")
        ):
            self.stats.documents_summarized += 1

        coverage = audit_page(page, minimum_score=self.config.minimum_page_coverage)
        page.metadata["coverage_contract"] = coverage.to_dict()
        self._record_coverage_outcome(coverage)

        counts = self.store.ingest_page(page)
        self.store.upsert_source(
            page.canonical_url,
            page.canonical_url,
            page.title,
            page.page_type,
            page.content_hash,
            page.http_status,
            page.screenshot_path,
            local_path_value,
            "application/pdf",
            page.metadata,
        )
        extracted_counts = self.store.ingest_extraction(page.canonical_url, extraction)
        for key, value in extracted_counts.items():
            counts[key] = counts.get(key, 0) + value
        counts["links_enqueued"] = self._enqueue_links(page.canonical_url, depth, links)
        counts["_completeness_score"] = float(coverage.score)
        self.stats.pdfs_stored += 1
        self._emit(
            "pdf_done",
            url=page.canonical_url,
            title=title,
            pages=page_count,
            visual_pages=len(visual_evidence),
            bytes=total_bytes,
            binary_available=not browser_only,
            browser_viewer_only=browser_only,
            download_strategy=fetch_mode,
            counts=counts,
        )
        if coverage.passed:
            self._record_pdf_success(
                url,
                fetch_mode,
                canonical_url=page.canonical_url,
                title=title,
                pages=page_count,
                text_chars=len(page.visible_text or ""),
                screenshots=len(visual_evidence),
                binary_available=not browser_only,
                local_path=local_path_value,
                completeness_score=float(coverage.score),
            )
        else:
            self._emit(
                "pdf_extracted_incomplete",
                url=url,
                canonical_url=page.canonical_url,
                completeness_score=float(coverage.score),
                missing_topics=coverage.missing_topics,
                gaps=coverage.gaps,
                suggested_actions=coverage.suggested_actions,
                reason="Document evidence was persisted, but the coverage contract did not pass; queue will remain DONE_INCOMPLETE.",
            )
        return counts

    def _resource_association_url(self, queue_item: dict[str, Any]) -> str:
        """Resolve a public resource/API page back to its nearest HTML source page.

        This lets paginated review endpoints attach every review page to the original
        product, rather than only to the immediately preceding API response.
        """
        current = canonicalize_url(str(queue_item.get("parent_url") or ""))
        seen: set[str] = set()
        for _ in range(200):
            if not current or current in seen:
                return ""
            seen.add(current)
            if not is_public_resource_url(current) and not is_sitemap_url(current):
                return current if self._scope_allowed(current) else ""
            parent_item = self.store.queue_item(current)
            current = canonicalize_url(str((parent_item or {}).get("parent_url") or ""))
        return ""

    def _process_visual_asset(self, queue_item: dict[str, Any]) -> dict[str, int]:
        """Process one unique Dell visual without sending it through the HTML agent."""
        url = str(queue_item["url"])
        parent_url = str(queue_item.get("parent_url") or "")
        self._emit("asset_start", url=url, parent_url=parent_url)
        response = None
        payload = b""
        content_type = ""
        status_code = 0
        try:
            response = self.http.get(
                url,
                headers={
                    "Referer": parent_url or f"https://www.dell.com/{normalize_locale(str(getattr(getattr(self, 'config', None), 'locale', 'en-uk') or 'en-uk'))}",
                    "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
                },
            )
            status_code = int(response.status_code)
            response.raise_for_status()
            payload = response.content
            content_type = str(response.headers.get("content-type") or "")
        except httpx.HTTPStatusError as exc:
            status_code = int(exc.response.status_code) if exc.response is not None else 0
            if status_code not in {401, 403} or not self.config.asset_browser_fallback_on_403:
                raise

        visual_path: Path | None = None
        fetch_mode = "http_visual_asset"
        if payload and (content_type.lower().startswith("image/") or is_visual_asset_url(url)):
            extension = self._image_extension(url, content_type)
            visual_path = self._asset_storage_path(url, extension)
            visual_path.parent.mkdir(parents=True, exist_ok=True)
            is_svg = "svg" in content_type.lower() or urlparse(url).path.lower().endswith(".svg")
            if is_svg:
                try:
                    import fitz
                    svg_doc = fitz.open(stream=payload, filetype="svg")
                    pix = svg_doc[0].get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                    payload = pix.tobytes("png")
                    visual_path = self._asset_storage_path(url + "#rendered", ".png")
                    content_type = "image/png"
                except Exception:
                    pass
            visual_path.write_bytes(payload)
        elif status_code in {401, 403}:
            # Some i.dell.com resources require browser-origin headers/cookies.
            # Use the browser as a rendering fallback, not repeated raw-HTTP retries.
            self._ensure_runtime()
            nav = self.runtime.navigate(url, "Render a public Dell visual rejected by direct HTTP")
            if not nav.get("ok"):
                raise RuntimeError(str(nav.get("detail") or f"Browser fallback failed for {url}"))
            self.runtime.wait(0.8, intent="Wait for Dell visual to render")
            digest = hashlib.sha256(url.encode("utf-8", errors="ignore")).hexdigest()
            shot_name = f"asset_{digest[:24]}.png"
            shot = self.runtime.screenshot(shot_name, full_page=False, intent="Capture public Dell visual for vision extraction")
            visual_path = Path(self.runtime.output_dir) / shot_name
            if not visual_path.exists():
                raise RuntimeError(f"Browser visual fallback screenshot was not created: {visual_path}")
            payload = visual_path.read_bytes()
            content_type = "image/png"
            fetch_mode = "playwright_browser_visual_fallback"
            self.stats.asset_browser_fallbacks += 1

        if visual_path is None or not visual_path.exists():
            raise RuntimeError(f"No visual evidence was acquired for {url}")

        width = height = 0
        if Image is not None:
            try:
                with Image.open(visual_path) as image:
                    width, height = image.size
            except Exception:
                pass
        digest = hashlib.sha256(payload).hexdigest()
        evidence = {
            "kind": "html_image", "path": str(visual_path), "source_url": url,
            "content_hash": digest, "width": width, "height": height,
            "bytes": len(payload), "vision_candidate": True,
        }
        page = CrawlPage(
            url=url, canonical_url=url, title=Path(urlparse(url).path).name or "Dell visual asset",
            page_type="VisualAsset", snapshot="", visible_text=f"Dell visual asset from {parent_url or 'configured Dell locale'}",
            links=[], controls=[], http_status=status_code or 200, content_hash=digest, visual_assets=[evidence],
            metadata={
                "mime_type": content_type or "image/*", "local_path": str(visual_path),
                "association_url": parent_url, "fetch_mode": fetch_mode,
                "visual_evidence": [evidence], "visual_assets": [evidence],
            },
        )
        extraction = self.extractor.extract(page) if self.config.use_vision_extraction else self.extractor.deterministic_extract(page)
        self._record_extraction_quality(extraction)
        page.metadata["vision_evidence_count"] = len(extraction.get("vision_evidence") or [])
        self.stats.visual_evidence_analyzed += int(page.metadata["vision_evidence_count"])
        counts = self.store.ingest_page(page)
        self.store.upsert_source(
            url, url, page.title, page.page_type, digest, page.http_status, "", str(visual_path),
            page.metadata["mime_type"], page.metadata,
        )
        extracted_counts = self.store.ingest_extraction(url, extraction, association_url=parent_url or url)
        for key, value in extracted_counts.items():
            counts[key] = counts.get(key, 0) + value
        counts["_completeness_score"] = 1.0
        self.stats.visual_assets_stored += 1
        self._emit("asset_done", url=url, fetch_mode=fetch_mode, bytes=len(payload), vision=page.metadata["vision_evidence_count"], counts=counts)
        return counts

    def _process_generic_resource(self, queue_item: dict[str, Any]) -> dict[str, int]:
        """Download and extract public Dell documents, data, transcripts and binary metadata."""
        url = queue_item["url"]
        depth = int(queue_item.get("depth") or 0)
        self._emit("resource_start", url=url, depth=depth)
        extension = extension_for_url(url) or ".resource"
        filename = self._safe_filename(url, extension)
        path = self.document_dir / filename
        final_url, status_code, response_headers, total_bytes = self._download_resource_resumable(url, path, queue_item)
        mime_type = str(response_headers.get("content-type") or "application/octet-stream")
        extracted = extract_resource(path, final_url, mime_type)
        links: list[DiscoveredLink] = []
        seen: set[str] = set()
        for raw in extracted.embedded_urls:
            candidate = canonicalize_url(raw, final_url)
            if not candidate or candidate in seen or not self._scope_allowed(candidate):
                continue
            seen.add(candidate)
            links.append(DiscoveredLink(
                label="URL found in Dell resource", url=candidate, source="resource_text",
                relation="REFERENCES", priority=priority_for_url(candidate),
                resource_kind=resource_kind("URL found in resource", candidate),
            ))
        association_url = self._resource_association_url(queue_item)
        page = CrawlPage(
            url=url, canonical_url=final_url, title=extracted.title or Path(urlparse(final_url).path).name or final_url,
            page_type=extracted.kind, snapshot="", visible_text=extracted.text, links=links, controls=[],
            http_status=status_code, content_hash=content_hash(extracted.text),
            metadata={
                **extracted.metadata,
                "mime_type": extracted.mime_type, "resource_bytes": total_bytes, "local_path": str(path),
                "last_modified": response_headers.get("last-modified", ""), "etag": response_headers.get("etag", ""),
                "resource_warnings": extracted.warnings, "document_summary_present": False,
                "fetch_mode": "public_read_only_resource",
                "association_url": association_url,
            },
        )
        if extracted.kind == "BinaryAsset":
            extraction = self.extractor.deterministic_extract(page)
            self._record_extraction_quality(extraction)
            self.stats.binary_assets_recorded += 1
        else:
            extraction = self.extractor.extract(page)
            self._record_extraction_quality(extraction)
        resource_reviews = extraction.get("reviews") if isinstance(extraction.get("reviews"), list) else []
        page.metadata["reviews_extracted"] = len(resource_reviews)
        declared_from_data = int(page.metadata.get("declared_review_count") or 0)
        page.metadata["review_metrics"] = {
            "declared_review_count": declared_from_data,
            "declared_rating": 0.0,
            "rating_mentions": len(resource_reviews),
        }
        self.stats.reviews_extracted += len(resource_reviews)
        page.metadata["long_form_chunk_count"] = int(extraction.get("chunk_count") or 0)
        page.metadata["document_summary_present"] = bool(extraction.get("document_summary"))
        if extraction.get("document_summary") or (
            isinstance(extraction.get("page"), dict) and extraction.get("page", {}).get("summary")
        ):
            self.stats.documents_summarized += 1
        if extracted.kind == "PublicData":
            self.stats.public_api_resources_stored += 1
        elif extracted.kind in {"WordDocument", "Presentation", "Spreadsheet"}:
            self.stats.office_documents_stored += 1
        elif extracted.kind == "Transcript":
            self.stats.transcripts_stored += 1

        coverage = audit_page(page, minimum_score=self.config.minimum_page_coverage)
        page.metadata["coverage_contract"] = coverage.to_dict()
        self._record_coverage_outcome(coverage)

        counts = self.store.ingest_page(page)
        self.store.upsert_source(
            page.canonical_url, page.canonical_url, page.title, page.page_type, page.content_hash,
            page.http_status, "", str(path), page.metadata["mime_type"], page.metadata,
        )
        extracted_counts = self.store.ingest_extraction(
            page.canonical_url, extraction, association_url=association_url
        )
        for key, value in extracted_counts.items():
            counts[key] = counts.get(key, 0) + value
        counts["links_enqueued"] = self._enqueue_links(page.canonical_url, depth, links)
        counts["_completeness_score"] = float(coverage.score)
        self._emit(
            "resource_done", url=page.canonical_url, resource_kind=extracted.kind, bytes=total_bytes,
            links=len(links), coverage=coverage.to_dict(), counts=counts, warnings=extracted.warnings,
        )
        return counts

    def _process_html_http_fallback(self, queue_item: dict[str, Any], reason: str) -> dict[str, int]:
        """Ingest the public HTTP representation when browser recovery is exhausted.

        This is deliberately marked in provenance metadata. It preserves link/PDF
        discovery and image/vision extraction so one browser failure does not block
        the rest of the unlimited crawl.
        """
        url = queue_item["url"]
        depth = int(queue_item.get("depth") or 0)
        self._emit("http_fallback_start", url=url, reason=reason, depth=depth)
        response = self.http.get(url)
        response.raise_for_status()
        content_type = response.headers.get("content-type", "")
        if "html" not in content_type.lower():
            raise RuntimeError(f"HTTP fallback did not return HTML: {content_type}")
        final_url = canonicalize_url(str(response.url), url)
        if not self._scope_allowed(final_url):
            raise RuntimeError(f"HTTP fallback left allowed Dell locale scope: {final_url}")
        soup = BeautifulSoup(response.text, "html.parser")
        for tag in soup(["script", "style", "noscript", "template"]):
            tag.decompose()
        title = ""
        if soup.title:
            title = re.sub(r"\s+", " ", soup.title.get_text(" ", strip=True)).strip()
        title = title or final_url
        visible_text = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n", strip=True))
        links, metadata = self._http_links(final_url)
        structured_text = str(metadata.get("structured_evidence_text") or "").strip()
        if structured_text:
            visible_text = f"{visible_text}\n\n===== PUBLIC HTML STRUCTURED EVIDENCE =====\n{structured_text}"
        page_type = classify_page(final_url, title, visible_text)
        archetype = archetype_for(final_url, title, visible_text)
        metadata["dell_page_archetype"] = ({
            "name": archetype.name,
            "expected_topics": list(archetype.expected_topics),
            "high_value_controls": list(archetype.high_value_controls),
        } if archetype else {})
        page = CrawlPage(
            url=url,
            canonical_url=final_url,
            title=title,
            page_type=page_type,
            snapshot="",
            visible_text=visible_text,
            links=links,
            controls=[],
            http_status=response.status_code,
            content_hash=content_hash(f"{title}\n{visible_text}"),
            visual_assets=metadata.get("visual_assets") if isinstance(metadata.get("visual_assets"), list) else [],
            metadata={
                **metadata,
                "fetch_mode": "http_self_heal_fallback",
                "browser_recovery_exhausted": True,
                "fallback_reason": reason[:4000],
                "mime_type": content_type,
                "needs_browser_revisit": True,
            },
        )
        assessment = self.healer.assess_completeness(
            url=page.canonical_url,
            page_type=page.page_type,
            title=page.title,
            visible_text=page.visible_text,
            links=[link.to_dict() for link in page.links],
            controls=[],
            use_llm=bool(self.config.completeness_judge),
        )
        page.metadata["completeness_assessment"] = assessment.to_dict()
        self._update_structured_stats(page)
        self._download_visual_assets(page)
        extraction = self.extractor.extract(page)
        self._record_extraction_quality(extraction)
        mapping_result = page.metadata.get("product_evidence_mapping") if isinstance(page.metadata, dict) else {}
        if isinstance(mapping_result, dict):
            self.stats.product_unmapped_fields_mapped += int(mapping_result.get("unmapped_fields_mapped") or 0)
        vision_text = str(extraction.get("vision_text") or "").strip()
        if vision_text:
            page.visible_text = f"{page.visible_text}\n\n===== DELL AIA VISION EVIDENCE =====\n{vision_text}"
            page.content_hash = content_hash(f"{page.title}\n{page.visible_text}")
        vision_records = extraction.get("vision_evidence") if isinstance(extraction.get("vision_evidence"), list) else []
        page.metadata["vision_evidence_count"] = len(vision_records)
        page.metadata["vision_extraction_mode"] = extraction.get("extraction_mode", "")
        self.stats.visual_evidence_analyzed += len(vision_records)
        review_records = extraction.get("reviews") if isinstance(extraction.get("reviews"), list) else []
        self.stats.reviews_extracted += len(review_records)

        product_records = extraction.get("product_records") if isinstance(extraction.get("product_records"), list) else []
        product_price_count = 0
        product_spec_count = 0
        product_scores: list[float] = []
        for record in product_records:
            if not isinstance(record, dict):
                continue
            attrs = record.get("attributes") if isinstance(record.get("attributes"), dict) else {}
            product_price_count += int(bool(attrs.get("price") or attrs.get("current_price")))
            product_spec_count += int(any(attrs.get(key) for key in (
                "processor", "graphics", "memory", "storage", "display", "operating_system"
            )))
            try:
                product_scores.append(float(attrs.get("completeness_score") or 0))
            except Exception:
                product_scores.append(0.0)
        self.stats.product_records_extracted += len(product_records)
        self.stats.product_records_with_price += product_price_count
        self.stats.product_records_with_core_specs += product_spec_count
        page.metadata["product_records_extracted"] = len(product_records)
        page.metadata["product_records_with_price"] = product_price_count
        page.metadata["product_records_with_core_specs"] = product_spec_count
        page.metadata["product_price_coverage"] = round(product_price_count / len(product_records), 4) if product_records else 0.0
        page.metadata["product_spec_coverage"] = round(product_spec_count / len(product_records), 4) if product_records else 0.0
        page.metadata["product_best_completeness"] = round(max(product_scores, default=0.0), 4)
        self.stats.embedded_documents_discovered += int(page.metadata.get("embedded_resource_count") or 0)
        page.metadata["reviews_extracted"] = len(review_records)
        page.metadata["long_form_chunk_count"] = int(extraction.get("chunk_count") or 0)

        raw_path = self._write_raw(page)
        page.metadata["raw_path"] = str(raw_path)
        counts = self.store.ingest_page(page)
        self.store.upsert_source(
            page.canonical_url,
            page.canonical_url,
            page.title,
            page.page_type,
            page.content_hash,
            page.http_status,
            "",
            str(raw_path),
            "text/html",
            page.metadata,
        )
        extracted_counts = self.store.ingest_extraction(page.canonical_url, extraction)
        for key, value in extracted_counts.items():
            counts[key] = counts.get(key, 0) + value
        counts["links_enqueued"] = self._enqueue_links(page.canonical_url, depth, page.links)
        self.stats.http_fallback_pages += 1
        self._emit(
            "http_fallback_done",
            url=page.canonical_url,
            title=page.title,
            links=len(page.links),
            visual_assets=len(page.metadata.get("visual_evidence") or []),
            completeness=assessment.to_dict(),
            counts=counts,
        )
        return counts

    def _process_item_with_react(self, item: dict[str, Any]) -> tuple[dict[str, int], str]:
        url = item["url"]
        resource_class = str(item.get("resource_class") or classify_frontier_url(url, item.get("relation", ""))).upper()
        is_resource = resource_class in {DOCUMENT, DATA, BINARY} and not is_pdf_url(url)
        is_asset = resource_class == ASSET
        is_html = resource_class == PAGE
        max_attempts = max(1, int(self.config.max_page_retries))
        if is_pdf_url(url):
            # Each PDF attempt already performs DOM candidate discovery, browser-context
            # acquisition, unique-control click/network capture and viewer recovery.
            # Repeating that full transport ladder six times only wastes hours.
            max_attempts = max(1, min(max_attempts, int(self.config.document_max_attempts)))
        healed = False
        restart_count = 0
        last_error = ""
        terminal_pdf_logged = False

        def record_terminal_pdf(stage: str, attempt_value: int = 0) -> None:
            nonlocal terminal_pdf_logged
            if is_pdf_url(url) and not terminal_pdf_logged:
                self._record_pdf_failure(
                    url,
                    stage,
                    last_error or "All PDF acquisition and browser-viewer recovery strategies were exhausted.",
                    attempt=attempt_value,
                    max_attempts=max_attempts,
                    resource_class=resource_class,
                )
                terminal_pdf_logged = True

        for attempt in range(1, max_attempts + 1):
            try:
                if resource_class == SITEMAP or is_sitemap_url(url):
                    counts = self._process_sitemap(item)
                    self.stats.data_lane_processed += 1
                elif is_asset:
                    counts = self._process_visual_asset(item)
                    self.stats.asset_lane_processed += 1
                elif is_pdf_url(url) and self.config.download_pdfs:
                    counts = self._process_pdf(item)
                    self.stats.document_lane_processed += 1
                elif is_resource:
                    counts = self._process_generic_resource(item)
                    if resource_class == DATA:
                        self.stats.data_lane_processed += 1
                    elif resource_class == BINARY:
                        self.stats.binary_lane_processed += 1
                    else:
                        self.stats.document_lane_processed += 1
                else:
                    self._ensure_runtime()
                    counts = self._process_html(item)
                    self.stats.page_lane_processed += 1
                if healed:
                    self.stats.pages_healed += 1
                self._item_failures.pop(url, None)
                return counts, "DONE"
            except httpx.HTTPStatusError as exc:
                status_code = int(exc.response.status_code) if exc.response is not None else 0
                if status_code in {404, 410}:
                    self._emit(
                        "source_permanently_unavailable",
                        url=url,
                        http_status=status_code,
                        detail=str(exc)[:1000],
                    )
                    return {}, "SKIPPED_PERMANENT"
                last_error = f"{type(exc).__name__}: {exc}"
                self._item_failures[url] = last_error
                if is_pdf_url(url):
                    self._record_pdf_transport_event(url, "react_http", last_error, attempt=attempt, max_attempts=max_attempts)
                if not self.config.self_heal_enabled:
                    record_terminal_pdf("terminal_self_heal_disabled_http", attempt)
                    raise
                context = ReActContext(
                    url=url,
                    stage=("html_page" if is_html else ("visual_asset" if is_asset else ("xml_sitemap" if is_sitemap_url(url) else ("pdf_document" if is_pdf_url(url) else "public_resource")))),
                    error=last_error,
                    attempt=attempt,
                    max_attempts=max_attempts,
                    current_url=url,
                    runtime_started=self.runtime.started,
                    snapshot_excerpt="",
                    extra={"traceback": traceback.format_exc(limit=3), "http_status": status_code},
                )
                decision = self.healer.decide(context)

                if not is_html and decision.action not in {HealAction.WAIT_AND_RETRY, HealAction.DEFER_URL}:
                    if attempt >= max_attempts:
                        decision.action = HealAction.DEFER_URL
                        decision.retry = False
                        decision.rationale = "Non-browser source remained unavailable after bounded retries; preserve it as deferred."
                    else:
                        decision.action = HealAction.WAIT_AND_RETRY
                        decision.wait_seconds = min(
                            self.config.retry_max_seconds,
                            self.config.retry_base_seconds * (2 ** max(0, attempt - 1)),
                        )
                        decision.rationale = "Retry the public non-browser source with exponential backoff."

                if decision.action == HealAction.RESTART_MCP:
                    restart_count += 1
                    if restart_count > max(0, int(self.config.max_mcp_restarts)):
                        decision.action = HealAction.HTTP_FALLBACK if is_html else HealAction.DEFER_URL
                        decision.retry = False
                        decision.rationale = "Per-page MCP restart budget reached; use evidence-preserving fallback."

                recovery = self.healer.execute(self.runtime, decision, url)
                self._record_heal(context, decision, recovery)
                healed = True
                if decision.action == HealAction.RESTART_MCP and recovery.get("ok"):
                    self._runtime_info = recovery.get("restart") if isinstance(recovery.get("restart"), dict) else recovery

                if decision.action == HealAction.HTTP_FALLBACK:
                    if is_html and self.config.http_fallback_on_browser_failure:
                        counts = self._process_html_http_fallback(item, last_error)
                        self.stats.pages_healed += 1
                        return counts, "DONE_WITH_HTTP_FALLBACK"
                    record_terminal_pdf("terminal_http_fallback_deferred", attempt)
                    return {}, "DEFERRED"
                if decision.action == HealAction.DEFER_URL:
                    record_terminal_pdf("terminal_deferred", attempt)
                    return {}, "DEFERRED"
                if not recovery.get("ok") and attempt >= max_attempts:
                    break
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                self._item_failures[url] = last_error
                if is_pdf_url(url):
                    self._record_pdf_transport_event(url, "react_processing", last_error, attempt=attempt, max_attempts=max_attempts)
                if not self.config.self_heal_enabled:
                    record_terminal_pdf("terminal_self_heal_disabled_processing", attempt)
                    raise
                context = ReActContext(
                    url=url,
                    stage=("html_page" if is_html else ("visual_asset" if is_asset else ("xml_sitemap" if is_sitemap_url(url) else ("pdf_document" if is_pdf_url(url) else "public_resource")))),
                    error=last_error,
                    attempt=attempt,
                    max_attempts=max_attempts,
                    current_url=url,
                    runtime_started=self.runtime.started,
                    snapshot_excerpt="",
                    extra={"traceback": traceback.format_exc(limit=3)},
                )
                failure_class = FailureClassifier.classify(context)
                if failure_class == "MCP_BROWSER_MISSING":
                    self._emit(
                        "crawler_configuration_blocked",
                        url=url,
                        failure_class=failure_class,
                        error=last_error[:2000],
                        remediation=(
                            "Select an installed Chrome/Edge channel, or run: "
                            "npx -y @playwright/mcp@0.0.78 install-browser chrome-for-testing"
                        ),
                    )
                    return {}, "BLOCKED_CONFIGURATION"
                decision = self.healer.decide(context)

                # HTTP/PDF processing has no browser state to recapture/reload.
                if not is_html and decision.action not in {HealAction.WAIT_AND_RETRY, HealAction.DEFER_URL}:
                    if attempt >= max_attempts:
                        decision.action = HealAction.DEFER_URL
                        decision.retry = False
                        decision.rationale = "Non-browser source remained unavailable after bounded retries; preserve it as deferred."
                    else:
                        decision.action = HealAction.WAIT_AND_RETRY
                        decision.wait_seconds = min(
                            self.config.retry_max_seconds,
                            self.config.retry_base_seconds * (2 ** max(0, attempt - 1)),
                        )
                        decision.rationale = "Retry the public non-browser source with exponential backoff."

                if decision.action == HealAction.RESTART_MCP:
                    restart_count += 1
                    if restart_count > max(0, int(self.config.max_mcp_restarts)):
                        decision.action = HealAction.HTTP_FALLBACK if is_html else HealAction.DEFER_URL
                        decision.retry = False
                        decision.rationale = "Per-page MCP restart budget reached; use evidence-preserving fallback."

                recovery = self.healer.execute(self.runtime, decision, url)
                self._record_heal(context, decision, recovery)
                healed = True
                if decision.action == HealAction.RESTART_MCP and recovery.get("ok"):
                    self._runtime_info = recovery.get("restart") if isinstance(recovery.get("restart"), dict) else recovery

                if decision.action == HealAction.HTTP_FALLBACK:
                    if is_html and self.config.http_fallback_on_browser_failure:
                        counts = self._process_html_http_fallback(item, last_error)
                        self.stats.pages_healed += 1
                        return counts, "DONE_WITH_HTTP_FALLBACK"
                    record_terminal_pdf("terminal_processing_fallback_deferred", attempt)
                    return {}, "DEFERRED"
                if decision.action == HealAction.DEFER_URL:
                    record_terminal_pdf("terminal_processing_deferred", attempt)
                    return {}, "DEFERRED"
                if not recovery.get("ok") and attempt >= max_attempts:
                    break

        if is_html and self.config.http_fallback_on_browser_failure:
            counts = self._process_html_http_fallback(item, last_error or "Page retry budget exhausted")
            if healed:
                self.stats.pages_healed += 1
            return counts, "DONE_WITH_HTTP_FALLBACK"
        record_terminal_pdf("terminal_retry_budget_exhausted", max_attempts)
        return {}, "DEFERRED"

    def _frontier_report(self) -> dict[str, Any]:
        graph = self.store.stats()
        queue = graph.get("queue") if isinstance(graph.get("queue"), dict) else {}
        queue_lanes = graph.get("queue_lanes") if isinstance(graph.get("queue_lanes"), dict) else {}
        dynamic = graph.get("dynamic_control_statuses") if isinstance(graph.get("dynamic_control_statuses"), dict) else {}
        nonterminal_dynamic = {
            status: count for status, count in dynamic.items()
            if status not in {"STABLE_EXHAUSTED", "CYCLE_EXHAUSTED", "CONTROL_ABSENT", "DISABLED", "NAVIGATED", "DIRECT_ENDPOINT"}
            and int(count or 0) > 0
        }
        unresolved_queue = {
            status: int(queue.get(status, 0) or 0)
            for status in ("PENDING", "IN_PROGRESS", "FAILED", "DEFERRED", "BLOCKED_CONFIGURATION")
            if int(queue.get(status, 0) or 0) > 0
        }
        partial_terminal_queue = {
            status: int(queue.get(status, 0) or 0)
            for status in ("DONE_WITH_HTTP_FALLBACK", "DONE_INCOMPLETE")
            if int(queue.get(status, 0) or 0) > 0
        }
        clean = not unresolved_queue and not nonterminal_dynamic and not self._stopped
        return {
            "run_id": self.run_id,
            "generated_at": _now(),
            "scope": self.config.scope_name,
            "clean_public_frontier_exhaustion": clean,
            "queue": queue,
            "queue_lanes": queue_lanes,
            "unresolved_queue": unresolved_queue,
            "partial_terminal_queue": partial_terminal_queue,
            "authenticated_knowledge": dict(self._auth_status),
            "masthead_taxonomy": dict(self._masthead_status),
            "dynamic_control_statuses": dynamic,
            "nonterminal_dynamic_controls": nonterminal_dynamic,
            "robots_fetch_issues": self.robots.errors,
            "coverage_contract": {
                "enabled": bool(self.config.coverage_contract_enabled),
                "minimum_page_score": float(self.config.minimum_page_coverage),
                "audits": int(self.stats.coverage_audits),
                "failures": int(self.stats.coverage_contract_failures),
                "review_policy": "For pages declaring a review total, extracted individual review evidence must reconcile to that public total before the review check is complete.",
                "completion_rule": "DONE_INCOMPLETE and HTTP-fallback pages remain visible as partial terminal evidence and are not blindly requeued; targeted product enrichment and explicit resume flags perform bounded revisits only when needed.",
            },
            "acquisition_surfaces": [
                "robots.txt sitemap directives and recursive XML sitemap indexes",
                "ordinary links, canonical/hreflang links and rel next/previous pagination",
                "rendered accessibility tree and recursively captured open shadow DOM",
                "same-origin iframe DOM and read-only product configuration options",
                "dynamic controls, carousels, accordions and review/load-more controls",
                "public read-only GET data endpoints observed in the browser",
                "live Dell masthead taxonomy: Artificial Intelligence, IT Infrastructure, Computers & Accessories, Services, Support, Deals, Financing, nested flyouts and safe child destinations",
                "authenticated read-only My Account overview, orders, profile, saved items, products and rewards destinations exposed by the signed-in Dell session",
                "PDF, Office, text/data, transcript and binary-asset metadata resources",
                "normal images, CSS background images and rendered SVG diagrams",
            ],
            "limitations": [
                "Covers public, discoverable, in-scope Dell locale content and approved Dell resource endpoints, including live masthead/flyout discovery plus authenticated read-only My Account destinations when SSO is available.",
                "Does not bypass CAPTCHA/access controls and never enters passwords, OTPs, payment data, or executes account mutations.",
                "A clean report is evidence that all discovered/actionable frontier items are exhausted; partial terminal pages remain reported without being blindly reprocessed on every restart.",
            ],
            "graph": graph,
            "stats": self.stats.to_dict(),
        }

    def _write_frontier_checkpoint(self, force: bool = False) -> None:
        now = time.monotonic()
        item_interval = max(1, int(self.config.coverage_checkpoint_every_items))
        time_interval = max(30, int(self.config.coverage_checkpoint_seconds))
        processed = int(self.stats.pages_seen)
        due_by_items = processed > 0 and processed % item_interval == 0
        due_by_time = (now - self._last_coverage_checkpoint) >= time_interval
        if not force and not (due_by_items or due_by_time):
            return
        report = self._frontier_report()
        (self.output_dir / "FRONTIER_COVERAGE_REPORT.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
        )
        self._last_coverage_checkpoint = now
        self.stats.coverage_checkpoints_written += 1
        self._emit("coverage_checkpoint", queue=report.get("queue"), queue_lanes=report.get("queue_lanes"))

    def run(self) -> dict[str, Any]:
        requeued = 0
        if self.config.resume:
            self.store.reset_in_progress()
            if self.config.retry_recoverable_on_resume:
                retry_statuses = ["DEFERRED", "FAILED", "BLOCKED_CONFIGURATION"]
                if bool(getattr(self.config, "resume_requeue_http_fallback", False)):
                    retry_statuses.append("DONE_WITH_HTTP_FALLBACK")
                if bool(getattr(self.config, "resume_requeue_done_incomplete", False)):
                    retry_statuses.append("DONE_INCOMPLETE")
                requeued = self.store.requeue_statuses(
                    retry_statuses,
                    error="Requeued by a new resumed ReAct/self-heal run",
                    priority_penalty=5,
                )
                requeued += self.store.requeue_unfinished_dynamic_controls()

        # v6.13: authenticate once, reuse the persistent SSO session, and discover
        # read-only account destinations before seeding. Failure is non-fatal by
        # default so the exhaustive public crawl still proceeds.
        self._prepare_authenticated_knowledge()
        # v6.14: deterministically open every live Dell masthead family and its
        # safe nested flyouts. This closes the gap where JS-only global-menu links
        # were invisible to the ordinary initial snapshot.
        self._prepare_masthead_knowledge()
        legacy = self.store.classify_legacy_frontier() if self.config.frontier_lane_scheduler_enabled else {}
        compacted = self.store.compact_pending_asset_variants() if self.config.dedupe_visual_asset_variants else {}
        historical_control_memory = self.store.migrate_historical_control_progress() if self.config.resume else {}
        self.stats.duplicate_asset_variants_skipped += int(compacted.get("variants_skipped", 0) or 0)
        seeded = self._seed()
        self.store.start_run(self.run_id, self.config.scope_name, self.config.to_dict())
        self._emit(
            "crawl_start", seeded=seeded, requeued_recoverable=requeued, legacy_frontier=legacy,
            asset_compaction=compacted, historical_control_memory=historical_control_memory, config=self.config.to_dict()
        )
        self._write_frontier_checkpoint(force=True)
        processed = 0
        product_revisit_sweeps = 0
        configuration_blocked = False
        try:
            # XML sitemaps and PDFs do not require a browser. Playwright MCP starts
            # lazily on the first HTML page; ReAct can restart it without losing the
            # persistent profile or the global crawl queue.
            while self.config.page_budget_allows(processed) and not self._stopped:
                # Interleave the expensive browser lane with document/data/asset
                # lanes. This prevents a perpetually growing PAGE frontier from
                # starving brochures, APIs and visual evidence for days. Sitemaps
                # are always selected first by SQLiteKnowledgeGraph.next_pending.
                # Documents start the recovery cycle and receive three of every
                # ten non-sitemap claims. This makes brochures/PDFs progress
                # immediately after resume without starving the HTML frontier.
                lane_mix = (DOCUMENT, PAGE, PAGE, DOCUMENT, DATA, PAGE, DOCUMENT, PAGE, ASSET, PAGE)
                preferred_lane = lane_mix[processed % len(lane_mix)] if self.config.frontier_lane_scheduler_enabled else ""
                if self.config.frontier_lane_scheduler_enabled and self.config.document_recovery_first:
                    lane_counts = self.store.queue_lane_counts()
                    document_pending = int((lane_counts.get(DOCUMENT) or {}).get("PENDING", 0) or 0)
                    if document_pending > 0 and int(self.stats.pdfs_stored) < max(1, int(self.config.document_recovery_success_target)):
                        preferred_lane = DOCUMENT
                item = self.store.next_pending(
                    lease_owner=self.run_id,
                    lease_seconds=self.config.worker_lease_seconds,
                    preferred_resource_class=preferred_lane,
                )
                if not item:
                    # v6.12 closes the historical gap where incomplete Product
                    # nodes remained DONE_INCOMPLETE until the user manually
                    # restarted the crawler. Once the ordinary frontier drains,
                    # perform a bounded product-completion audit and immediately
                    # revisit missing PDP/source pages in this same run.
                    if (
                        self.config.product_revisit_enabled
                        and product_revisit_sweeps < max(1, int(self.config.product_revisit_max_sweeps))
                    ):
                        sweep = self.store.schedule_product_revisit_sweep(
                            min_score=float(self.config.product_min_completeness),
                            max_attempts=int(self.config.product_revisit_max_attempts),
                            no_gain_limit=int(self.config.product_revisit_no_gain_limit),
                            min_gain=float(self.config.product_revisit_min_gain),
                            priority=int(self.config.product_revisit_priority),
                            revisit_missing_price=bool(self.config.product_revisit_missing_price),
                            revisit_missing_specs=bool(self.config.product_revisit_missing_specs),
                            revisit_unmapped=bool(self.config.product_revisit_unmapped_evidence),
                        )
                        product_revisit_sweeps += 1
                        self.stats.product_revisit_sweeps += 1
                        self.stats.product_revisit_urls_enqueued += int(sweep.get("urls_requeued") or 0)
                        self.stats.product_revisit_products_completed += int(sweep.get("products_completed") or 0)
                        self.stats.product_revisit_products_exhausted += int(sweep.get("products_exhausted") or 0)
                        self._emit("product_revisit_sweep", sweep=product_revisit_sweeps, **sweep)
                        self._write_frontier_checkpoint(force=True)
                        if int(sweep.get("urls_requeued") or 0) > 0:
                            continue
                    break
                url = item["url"]
                self.stats.pages_seen += 1
                depth = int(item.get("depth") or 0)
                if not self.config.depth_allows_item(depth):
                    self.store.mark_queue(url, "SKIPPED", "max_depth_exceeded")
                    self.stats.pages_skipped += 1
                    processed += 1
                    continue
                if not self._scope_allowed(url):
                    self.store.mark_queue(url, "SKIPPED", "outside_en_uk_or_trusted_dell_scope")
                    self.stats.pages_skipped += 1
                    processed += 1
                    continue
                if not self._robots_allowed(url):
                    self.store.mark_queue(url, "SKIPPED", "robots_disallowed")
                    self.stats.pages_skipped += 1
                    self._emit("page_skipped", url=url, reason="robots_disallowed")
                    processed += 1
                    continue

                try:
                    counts, outcome = self._process_item_with_react(item)
                    if outcome.startswith("DONE"):
                        self._item_failures.pop(url, None)
                        final_outcome = outcome
                        completeness_score = counts.get("_completeness_score")
                        minimum_required = (
                            float(self.config.minimum_page_coverage)
                            if self.config.coverage_contract_enabled else 0.35
                        )
                        if completeness_score is not None and float(completeness_score) < minimum_required:
                            final_outcome = "DONE_INCOMPLETE"
                        self.store.mark_queue(url, final_outcome)
                        self.stats.pages_stored += 1
                        self.stats.nodes_created += int(counts.get("nodes_created", 0))
                        self.stats.edges_created += int(counts.get("edges_created", 0))
                        self.stats.facts_created += int(counts.get("facts_created", 0))
                    elif outcome == "SKIPPED_PERMANENT":
                        self.store.mark_queue(url, "SKIPPED_PERMANENT", "HTTP 404/410: public source is no longer available")
                        self.stats.pages_skipped += 1
                    elif outcome == "BLOCKED_CONFIGURATION":
                        self.store.mark_queue(
                            url,
                            "BLOCKED_CONFIGURATION",
                            "Playwright MCP browser is not installed or cannot be launched; fix local browser setup and resume.",
                        )
                        configuration_blocked = True
                        self.stats.warnings.append(
                            "Crawler stopped because Playwright MCP could not launch its configured browser. "
                            "Select installed Chrome/Edge or run install_mcp_browser.ps1, then resume."
                        )
                        self._emit(
                            "crawl_blocked_configuration",
                            url=url,
                            remediation="Run install_mcp_browser.ps1 or select an installed Chrome/Edge browser, then Start / Resume.",
                        )
                        break
                    else:
                        root_error = self._item_failures.pop(
                            url,
                            "Recovery exhausted; preserved for the next explicit resumed run",
                        )
                        self.store.mark_queue(url, "DEFERRED", root_error)
                        self.stats.deferred_pages += 1
                        self._emit("page_deferred", url=url, reason="self_heal_exhausted", error=root_error[:2000])
                except Exception as exc:
                    root_error = self._item_failures.pop(url, f"{type(exc).__name__}: {exc}")
                    self.store.mark_queue(url, "FAILED", root_error)
                    self.stats.pages_failed += 1
                    self._emit(
                        "page_failed",
                        url=url,
                        error=f"{type(exc).__name__}: {exc}",
                        traceback=traceback.format_exc(limit=4),
                    )
                processed += 1
                self.stats.llm_text_cache_hits = int(getattr(self.extractor, "text_cache_hits", 0))
                self._write_frontier_checkpoint()
                queue_counts = self.store.queue_counts()
                self.stats.queue_remaining = int(queue_counts.get("PENDING", 0))
                if self.config.delay_seconds:
                    time.sleep(min(10.0, max(0.0, self.config.delay_seconds)))

            pending = int(self.store.queue_counts().get("PENDING", 0))
            if configuration_blocked:
                self.stats.status = "BLOCKED_CONFIGURATION"
            elif self._stopped:
                self.stats.status = "STOPPED"
            elif pending and self.config.max_pages > 0 and processed >= self.config.max_pages:
                self.stats.status = "BUDGET_REACHED"
            elif self.stats.pages_failed:
                self.stats.status = "COMPLETED_WITH_ERRORS"
            elif self.stats.deferred_pages:
                self.stats.status = "COMPLETED_WITH_DEFERRED"
            else:
                self.stats.status = "COMPLETED"
        except KeyboardInterrupt:
            self.stats.status = "STOPPED"
            self.stats.warnings.append("Crawler stopped by user; queue and graph state were preserved for resume.")
        except Exception as exc:
            self.stats.status = "FAILED"
            self.stats.warnings.append(f"{type(exc).__name__}: {exc}")
            self._emit("crawl_failed", error=self.stats.warnings[-1], runtime=self._runtime_info)
        finally:
            self.stats.finished_at = _now()
            self.stats.queue_remaining = int(self.store.queue_counts().get("PENDING", 0))
            if self.robots.errors:
                self.stats.warnings.extend(
                    f"robots.txt fetch issue for {origin}: {error}" for origin, error in self.robots.errors.items()
                )
            self.store.finish_run(self.run_id, self.stats.status, self.stats.to_dict())
            self._write_frontier_checkpoint(force=True)
            frontier_report = self._frontier_report()
            if self.runtime.started or getattr(self.runtime, "_worker_future", None):
                try:
                    self.runtime.close()
                except Exception:
                    pass
            self.http.close()
            self._emit("crawl_finished", runtime=self._runtime_info, graph_stats=self.store.stats())
        return {
            "run_id": self.run_id,
            "status": self.stats.status,
            "stats": self.stats.to_dict(),
            "graph": self.store.stats(),
            "runtime": self._runtime_info,
            "database": str(self.store.db_path),
            "recent_self_heal_events": self.store.recent_self_heal_events(25),
            "frontier_report": self._frontier_report(),
            "frontier_report_path": str(self.output_dir / "FRONTIER_COVERAGE_REPORT.json"),
        }

