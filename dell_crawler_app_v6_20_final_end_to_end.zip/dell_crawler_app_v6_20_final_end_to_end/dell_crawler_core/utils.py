from __future__ import annotations

import ast
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def json_dumps(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str)


def _strip_json_comments(text: str) -> str:
    """Remove // and /* */ comments without touching content inside strings."""
    output: list[str] = []
    i = 0
    in_string = False
    quote = ""
    escaped = False
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if in_string:
            output.append(ch)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                in_string = False
            i += 1
            continue
        if ch in {'"', "'"}:
            in_string = True
            quote = ch
            output.append(ch)
            i += 1
            continue
        if ch == "/" and nxt == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue
        if ch == "/" and nxt == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            i += 2
            continue
        output.append(ch)
        i += 1
    return "".join(output)


def _balanced_json_candidates(text: str) -> list[str]:
    """Return balanced object/array candidates found in mixed model output."""
    candidates: list[str] = []
    for start, opener in enumerate(text):
        if opener not in "{[":
            continue
        stack: list[str] = []
        in_string = False
        quote = ""
        escaped = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == quote:
                    in_string = False
                continue
            if ch in {'"', "'"}:
                in_string = True
                quote = ch
                continue
            if ch in "{[":
                stack.append(ch)
            elif ch in "}]":
                if not stack:
                    break
                expected = "}" if stack[-1] == "{" else "]"
                if ch != expected:
                    break
                stack.pop()
                if not stack:
                    candidates.append(text[start : i + 1])
                    break
    return candidates


def _close_truncated_json(candidate: str) -> str:
    """Best-effort closure for a response cut off near the token limit."""
    stack: list[str] = []
    in_string = False
    quote = '"'
    escaped = False
    for ch in candidate:
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                in_string = False
            continue
        if ch in {'"', "'"}:
            in_string = True
            quote = ch
        elif ch in "{[":
            stack.append(ch)
        elif ch in "}]" and stack:
            expected = "}" if stack[-1] == "{" else "]"
            if ch == expected:
                stack.pop()
    repaired = candidate.rstrip()
    if in_string and quote == '"':
        if repaired.endswith("\\"):
            repaired += " "
        repaired += '"'
    repaired = re.sub(r",\s*$", "", repaired)
    repaired += "".join("}" if opener == "{" else "]" for opener in reversed(stack))
    return repaired


def _normalise_json_container(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return value
    if isinstance(value, list):
        dictionaries = [item for item in value if isinstance(item, dict)]
        if not dictionaries:
            return None
        if len(dictionaries) == 1:
            return dictionaries[0]
        merged: dict[str, Any] = {}
        for item in dictionaries:
            for key, child in item.items():
                if key not in merged:
                    merged[key] = child
                elif isinstance(merged[key], list):
                    merged[key].extend(child if isinstance(child, list) else [child])
                elif merged[key] != child:
                    merged[key] = [merged[key], *(child if isinstance(child, list) else [child])]
        merged.setdefault("_normalization_notes", []).append("Top-level JSON array merged into one object.")
        return merged
    return None


def _parse_json_candidate(candidate: str) -> dict[str, Any] | None:
    candidate = (candidate or "").strip().lstrip("\ufeff")
    if not candidate:
        return None
    variants = [candidate]
    cleaned = _strip_json_comments(candidate)
    cleaned = cleaned.replace("“", '"').replace("”", '"').replace("„", '"').replace("’", "'")
    cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
    cleaned = re.sub(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_-]*)(\s*:)", r'\1"\2"\3', cleaned)
    if cleaned != candidate:
        variants.append(cleaned)
    closed = _close_truncated_json(cleaned)
    if closed != cleaned:
        variants.append(closed)
    for value in variants:
        try:
            return _normalise_json_container(json.loads(value))
        except Exception:
            pass
        try:
            python_value = ast.literal_eval(value)
            parsed = _normalise_json_container(python_value)
            if parsed is not None:
                parsed.setdefault("_normalization_notes", []).append("Python-style JSON notation normalized safely.")
                return parsed
        except Exception:
            pass
    return None


def extract_json_object(text: str) -> dict[str, Any] | None:
    """Extract and safely repair a JSON object from model output.

    The parser accepts fenced JSON, explanatory text, top-level arrays, trailing
    commas, comments, single-quoted Python-style dictionaries, bare identifier
    keys and responses truncated near the token limit. It never executes code.
    """
    raw = (text or "").strip().lstrip("\ufeff")
    if not raw:
        return None
    parsed = _parse_json_candidate(raw)
    if parsed is not None:
        return parsed
    fenced_blocks = re.findall(r"```(?:json|javascript|js|python)?\s*([\s\S]*?)```", raw, re.I)
    for block in fenced_blocks:
        parsed = _parse_json_candidate(block)
        if parsed is not None:
            return parsed
    for candidate in _balanced_json_candidates(raw):
        parsed = _parse_json_candidate(candidate)
        if parsed is not None:
            return parsed
    first = min((idx for idx in (raw.find("{"), raw.find("[")) if idx >= 0), default=-1)
    if first >= 0:
        return _parse_json_candidate(raw[first:])
    return None


def content_to_text(result: Any) -> str:
    parts: list[str] = []
    content = getattr(result, 'content', None)
    if content is None and isinstance(result, dict):
        content = result.get('content')
    if not content:
        return str(result)
    for item in content:
        if isinstance(item, str):
            parts.append(item)
            continue
        text = getattr(item, 'text', None)
        if text is None and isinstance(item, dict):
            text = item.get('text')
        if text:
            parts.append(str(text))
        else:
            parts.append(str(item))
    return '\n'.join(parts)


def has_mcp_error(text: str) -> bool:
    low = (text or '').lower()
    return any(x in low for x in ('### error', 'toolerror', 'mcp error', 'traceback'))


def text_hash(text: str) -> str:
    return hashlib.sha256((text or '').encode('utf-8', errors='ignore')).hexdigest()[:20]


SECRET_PATTERNS = [
    re.compile(r'(?i)(password|passwd|otp|one[- ]time passcode|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|authorization)\s*[:=]\s*([^\s,;]+)'),
    re.compile(r'(?i)bearer\s+[A-Za-z0-9._~+/=-]{12,}'),
]


def redact_text(text: str) -> str:
    out = str(text or '')
    for pattern in SECRET_PATTERNS:
        out = pattern.sub(lambda m: f'{m.group(1)}=<REDACTED>' if m.lastindex and m.lastindex >= 1 else '<REDACTED>', out)
    return out


def compact(text: str, limit: int = 14000) -> str:
    text = str(text or '')
    if len(text) <= limit:
        return text
    side = max(1200, (limit - 120) // 2)
    return text[:side] + '\n...[truncated]...\n' + text[-side:]
