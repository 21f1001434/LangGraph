from __future__ import annotations

"""v6.19 final crawler repair: semantic convergence + market-correct commerce data."""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph, _loads, _json
from dell_crawler_core.market_context import infer_market_context, normalize_currency
from dell_crawler_core.semantic_consolidation import classify_and_consolidate
from repair_v610 import now, sqlite_backup, stamp
from repair_v617 import _preserve_node_as_evidence, merge_duplicate_products, rebuild_node_fts
from repair_v618 import repair as repair_v618


def _stamp_classification_v619(store: SQLiteKnowledgeGraph) -> int:
    changed = 0
    with store.connect() as conn:
        rows = conn.execute("SELECT id,node_type,attributes_json FROM nodes").fetchall()
        for row in rows:
            attrs = _loads(row["attributes_json"], {})
            desired = "v6.19"
            if attrs.get("classification_version") != desired:
                attrs["classification_version"] = desired
                if row["node_type"] == "Product":
                    attrs.setdefault("canonical_class", "Product")
                    attrs.setdefault("classification_confidence", 1.0)
                    attrs.setdefault("classification_reason", "product_identity_resolver")
                conn.execute("UPDATE nodes SET attributes_json=? WHERE id=?", (_json(attrs), int(row["id"])))
                changed += 1
    return changed


def _repair_market_currency(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    report = {
        "product_currency_filled": 0,
        "legacy_gbp_corrected": 0,
        "offer_market_corrected": 0,
        "price_facts_retyped": 0,
        "observations_currency_corrected": 0,
    }

    # Repair Product projection attributes. Only the historical default-GBP case is
    # auto-corrected across markets; any other explicit cross-market currency remains
    # visible to the strict audit instead of being silently overwritten.
    with store.connect() as conn:
        rows = conn.execute("SELECT id,attributes_json FROM nodes WHERE node_type='Product'").fetchall()
        for row in rows:
            attrs = _loads(row["attributes_json"], {})
            price = str(attrs.get("price") or attrs.get("current_price") or "").strip()
            if not price:
                continue
            source = str(attrs.get("product_url") or attrs.get("url") or attrs.get("source_url") or "")
            expected = infer_market_context(source, evidence_text=price).currency
            current = normalize_currency(attrs.get("currency"))
            changed = False
            if expected and not current:
                attrs["currency"] = expected
                report["product_currency_filled"] += 1
                changed = True
            elif expected and current == "GBP" and expected != "GBP":
                attrs["currency"] = expected
                report["legacy_gbp_corrected"] += 1
                changed = True
            if changed:
                conn.execute("UPDATE nodes SET attributes_json=? WHERE id=?", (_json(attrs), int(row["id"])))

    # Historical builds emitted PRICE_GBP even on non-UK pages. Convert only when
    # the source URL itself resolves to a different Dell market/currency.
    with store.connect() as conn:
        rows = conn.execute(
            "SELECT * FROM facts WHERE predicate='PRICE_GBP'"
        ).fetchall()
        for row in rows:
            context = infer_market_context(str(row["source_url"] or ""), evidence_text=str(row["value"] or ""))
            if not context.currency or context.currency == "GBP":
                continue
            conn.execute(
                """
                INSERT OR IGNORE INTO facts(subject_id,predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    row["subject_id"], "PRICE", row["value"], context.currency,
                    row["qualifiers_json"], row["source_url"], row["confidence"], row["observed_at"],
                    row["valid_from"], row["valid_to"],
                ),
            )
            conn.execute("DELETE FROM facts WHERE id=?", (int(row["id"]),))
            report["price_facts_retyped"] += 1

    with store.connect() as conn:
        rows = conn.execute("SELECT id,source_url,currency,price FROM product_observations").fetchall()
        for row in rows:
            context = infer_market_context(str(row["source_url"] or ""), evidence_text=str(row["price"] or ""))
            current = normalize_currency(row["currency"])
            if context.currency and (not current or (current == "GBP" and context.currency != "GBP")):
                conn.execute("UPDATE product_observations SET currency=? WHERE id=?", (context.currency, int(row["id"])))
                report["observations_currency_corrected"] += 1

    with store.connect() as conn:
        rows = conn.execute("SELECT id,attributes_json FROM nodes WHERE node_type='Offer'").fetchall()
        for row in rows:
            attrs = _loads(row["attributes_json"], {})
            source = str(attrs.get("source_url") or attrs.get("url") or "")
            context = infer_market_context(source, explicit_currency=attrs.get("currency"), evidence_text=str(attrs.get("price") or ""))
            changed = False
            if context.market != "GLOBAL" and str(attrs.get("market") or "").upper() in {"", "UK"} and context.market != str(attrs.get("market") or "").upper():
                attrs["market"] = context.market
                attrs["locale"] = context.locale
                report["offer_market_corrected"] += 1
                changed = True
            current = normalize_currency(attrs.get("currency"))
            url_currency = infer_market_context(source, evidence_text=str(attrs.get("price") or "")).currency
            if url_currency and (not current or (current == "GBP" and url_currency != "GBP")):
                attrs["currency"] = url_currency
                changed = True
            if changed:
                conn.execute("UPDATE nodes SET attributes_json=? WHERE id=?", (_json(attrs), int(row["id"])))

    return report


def repair(db: Path, knowledge: Path, *, force_active: bool = False, no_backup: bool = False) -> dict[str, Any]:
    backup = ""
    if not no_backup:
        target = db.with_name(f"{db.stem}.pre_v619_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    base = repair_v618(db, knowledge, force_active=force_active, no_backup=True)
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity_before = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    if integrity_before.casefold() != "ok":
        raise SystemExit(f"SQLite integrity check failed before v6.19 hardening: {integrity_before}")

    currency = _repair_market_currency(store)

    def preserve(row, kind: str, reason: str) -> None:
        _preserve_node_as_evidence(store, row, kind, reason)

    # Re-run with v6.19 semantic keys so category plurals/heading suffixes and
    # ProductFamily naming variants converge to the same canonical identity.
    semantic = classify_and_consolidate(store, preserve_as_evidence=preserve)
    products = merge_duplicate_products(store)
    stamped = _stamp_classification_v619(store)
    rebuild_node_fts(store)
    projection = store.backfill_product_projection()
    revisit = store.schedule_product_revisit_sweep(
        min_score=0.85,
        max_attempts=4,
        no_gain_limit=2,
        min_gain=0.02,
        priority=0,
        revisit_missing_price=True,
        revisit_missing_specs=True,
        revisit_unmapped=True,
    )
    quality = store.semantic_quality_report()
    extractor = store.extractor_quality_report()
    schema = store.canonical_schema_report()
    with store.connect() as conn:
        integrity_after = str(conn.execute("PRAGMA integrity_check").fetchone()[0])

    knowledge.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "migration": "v6.x -> v6.19 final market-aware classified crawler",
        "database": str(db),
        "backup": backup,
        "integrity_before": integrity_before,
        "integrity_after": integrity_after,
        "v618_base_repair": base,
        "market_currency_repair": currency,
        "semantic_reclassification_and_consolidation": semantic,
        "product_deduplication": products,
        "classification_rows_stamped": stamped,
        "product_projection": projection,
        "product_revisit_priming": revisit,
        "semantic_quality": quality,
        "extractor_quality": extractor,
        "canonical_schema": schema,
        "finished_at": now(),
    }
    path = knowledge / "SEMANTIC_KNOWLEDGE_REPAIR_V619.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade Dell crawler DB to v6.19 market-aware classified/deduplicated mapping.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(db, Path(args.knowledge).expanduser().resolve(), force_active=args.force_active, no_backup=args.no_backup)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
