# v6.16 Validated End-to-End Dell Knowledge Crawler

v6.16 fixes the crawler at the source so Neo4j does not need to clean up a noisy raw crawl after the fact.

## Core changes

- **Fetched-page graph only:** discovering an href records `link_evidence`; it no longer creates a graph node for an unfetched target. A navigation edge is materialized only after both pages have actually been fetched.
- **Strict semantic admission:** arbitrary LLM/schema.org types, weak entities, generic `Concept`/`Section` objects and broken relationship endpoints are retained in `extraction_evidence`, not promoted to semantic graph nodes.
- **Stable Product identity:** order code → part number → exact Dell PDP URL are strong identities. Brand+model is used only when neither observation has a stronger identifier, preventing configuration variants from being merged incorrectly.
- **Compact document knowledge:** document sections, summaries and recommendations are preserved as facts/chunks/evidence instead of hundreds of one-off nodes.
- **Anti-repeat extraction:** canonical URL dedupe plus stable normalized rendered-text hashing prevents repeated Dell AIA/vision work for aliases and whitespace/DOM churn while still preserving link/source provenance.
- **Bounded product revisits:** missing price, applicable specifications, exact PDP identity or unmapped product evidence can trigger targeted revisits; unchanged/no-gain products stop after the configured budget.
- **Locale correctness:** page Market/locale metadata is inferred from the real Dell URL instead of being hard-coded to UK.
- **Full Dell discovery retained:** live masthead/flyouts, sitemaps, recursive Dell links, support, services, deals, financing, AI/infrastructure, products, PDFs, visual evidence and authenticated read-only account knowledge continue through the same canonical frontier.

## Existing database upgrade

Use **Graceful Stop** first. Then run:

```powershell
python .\repair_v616.py --db knowledge\dell_en_uk.db --knowledge knowledge
python .\audit_knowledge_v616.py --db knowledge\dell_en_uk.db --require-clean
python -m streamlit run .\app.py
```

`repair_v616.py` creates a SQLite-consistent backup by default, migrates unfetched navigation placeholders and generic Concept/legacy summary nodes into dedicated evidence tables, merges only strong Product duplicates, rebuilds product projection/FTS and primes incomplete-product revisits.

## Semantic graph readiness

The Streamlit **Extracted data** tab now reports:

- fetched sources
- semantic nodes
- link evidence rows
- unfetched placeholder nodes
- evidence-only Concept nodes
- duplicate strong Product identities
- extraction-validation records
- graph/source ratio

A database is marked clean for semantic synchronization when unfetched placeholders, generic Concept nodes, legacy summary nodes and duplicate strong Product identities are all zero.

## Truthful limits

The crawler is read-only and does not bypass access controls, CAPTCHAs, MFA, permissions or unpublished server-side data. Authenticated Dell content is crawled only through the authorized persistent browser session. It never invents unavailable prices/specifications; exhausted/no-gain enrichment remains visible in audit state.
