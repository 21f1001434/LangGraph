from __future__ import annotations

import argparse
import json
from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def build_report(db: Path) -> dict:
    store = SQLiteKnowledgeGraph(db)
    return {
        "semantic_quality": store.semantic_quality_report(),
        "extractor_quality": store.extractor_quality_report(),
        "product_completeness": store.product_completeness_report(),
        "product_enrichment": store.product_enrichment_status_report(),
        "canonical_schema": store.canonical_schema_report(),
        "database_stats": store.stats(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit Dell crawler v6.18 classified/deduplicated semantic mapping and extraction quality.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--output", default="")
    parser.add_argument("--require-clean", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if args.output:
        Path(args.output).expanduser().write_text(text, encoding="utf-8")
    if args.require_clean:
        quality = report["semantic_quality"]
        if not bool(quality.get("clean_for_semantic_sync")):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
