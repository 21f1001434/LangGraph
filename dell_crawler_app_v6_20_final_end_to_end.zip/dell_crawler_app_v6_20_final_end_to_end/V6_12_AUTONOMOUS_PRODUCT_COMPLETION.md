# v6.12 Autonomous Product Completion

v6.12 turns product enrichment into a closed-loop part of the crawl instead of a one-time repair step.

## What happens automatically

When the ordinary frontier has no pending page, the worker audits every canonical Product. A Product is selected for another pass when one or more of these are true:

- it does not have an exact Dell product-detail URL;
- the exact product-detail page has not yielded a public price;
- an applicable product specification is still missing;
- recognized information remains in unresolved/unmapped evidence;
- adaptive completeness is below the configured threshold.

The same crawler process then continues rather than stopping:

```text
normal crawl drains
        ↓
canonical Product audit
        ↓
missing exact product URL? ── yes ──→ revisit source/catalog for identity recovery
        │ no
        ↓
revisit exact Dell PDP (/spd/, /apd/, supported detail routes)
        ↓
rendered DOM + structured data + tables + Dell AIA extraction
        ↓
normalize aliases and nested fields
        ↓
bind page-scoped evidence to the canonical Product
        ↓
merge facts + preserve provenance
        ↓
recalculate product projection/completeness
        ↓
complete? → COMPLETE
        │ no
        ↓
information gain? → bounded next revisit
        │ no after configured rounds
        ↓
EXHAUSTED_NO_GAIN / EXHAUSTED_ATTEMPTS
```

## Mapping recovery

Known alternative labels are normalized rather than discarded. Examples include CPU/processor, GPU/graphics, RAM/memory, SSD/NVMe/storage, screen/display, OS/operating system, list/current price, order code, part number and product URL. Nested unmapped payloads are recursively inspected. Fields that can be mapped are copied into canonical Product attributes/facts with source provenance; only genuinely unknown fields remain unresolved.

An unresolved mapping count itself is a revisit trigger, so a Product can get a fresh rendered-page/AIA extraction on a later pass. This is useful when a first pass was partial, a dynamic section was not opened, or the model returned a non-standard label.

## Missing price and specifications

An exact Product detail page with no recovered price is revisited even if other fields already make the adaptive score high. Missing applicable core specifications also trigger a revisit. The crawler does not invent values: if Dell does not publicly publish a price/specification, the Product is eventually marked exhausted after bounded attempts/no-gain rounds and the missing value remains empty with the reason visible in `product_enrichment_state`.

## Infinite-loop protection

Defaults:

- maximum enrichment revisits per Product: 4;
- stop after 2 revisit rounds with no information gain;
- maximum completion sweeps per crawler run: 8;
- permanently unavailable queue items are not revived.

These values are configurable in the Streamlit crawl controls.

## Upgrade an existing database

Gracefully stop the crawler first, then run:

```powershell
python .\repair_v612.py --db knowledge\dell_en_uk.db --knowledge knowledge
```

The repair creates a SQLite-consistent `pre_v612` backup, replays already-stored product evidence, repairs earlier media-URL Product contamination, rebuilds product projections, requeues recoverable incomplete pages, and primes the first product-completion sweep. It does not delete successful crawl data.

Then start the application:

```powershell
python -m streamlit run .\app.py
```

Use **Start / Resume**. Subsequent product completion sweeps happen automatically in the same crawler run.

A read-only status audit is available with:

```powershell
python .\audit_product_completion_v612.py --db knowledge\dell_en_uk.db
```

The Streamlit Data tab also shows QUEUED, COMPLETE, exhausted, and blocked Product completion states.
