$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$Python = "python"
if (Test-Path ".venv\Scripts\python.exe") {
    $Python = ".venv\Scripts\python.exe"
}

& $Python .\repair_v612.py --db knowledge\dell_en_uk.db --knowledge knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "v6.12 repair completed. Starting Streamlit..."
& $Python -m streamlit run .\app.py
