$ErrorActionPreference = "Stop"
python .\repair_v611.py --db knowledge\dell_en_uk.db --knowledge knowledge
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "v6.11 extractor-quality repair completed. Starting Streamlit..."
python -m streamlit run .\app.py
