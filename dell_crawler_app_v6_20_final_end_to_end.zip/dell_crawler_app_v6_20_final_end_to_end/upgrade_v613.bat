@echo off
setlocal
set PYTHON=python
if exist venv\Scripts\python.exe set PYTHON=venv\Scripts\python.exe
if exist .venv\Scripts\python.exe set PYTHON=.venv\Scripts\python.exe
%PYTHON% repair_v613.py --db knowledge\dell_en_uk.db --knowledge knowledge
if errorlevel 1 exit /b %errorlevel%
echo v6.13 repair completed. Starting Streamlit...
%PYTHON% -m streamlit run app.py
