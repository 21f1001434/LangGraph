from __future__ import annotations
import argparse, json
from pathlib import Path
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only v6.11 Product extractor quality audit")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--out", default="knowledge/EXTRACTOR_QUALITY_REPORT_V611.json")
    args = parser.parse_args()
    store = SQLiteKnowledgeGraph(Path(args.db))
    report = store.extractor_quality_report()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    print(f"\nAudit report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
