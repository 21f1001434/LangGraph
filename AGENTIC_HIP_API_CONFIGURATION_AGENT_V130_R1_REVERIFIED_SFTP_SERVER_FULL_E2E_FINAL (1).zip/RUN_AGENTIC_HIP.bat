@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   Agentic HIP API Configuration Agent - V130
echo   React/FastAPI primary production runtime
echo ============================================================

if not exist "webapp\frontend\dist\index.html" (
  echo [STARTUP] Compiled React frontend is missing. Building it now...
  where bun >nul 2>nul
  if errorlevel 1 (
    echo.
    echo ERROR: Bun is not available and the compiled frontend is missing.
    echo Install/enable Bun, reopen this terminal, then run this file again.
    echo Or use RUN_AGENTIC_HIP_DEV.bat after Bun is available.
    exit /b 2
  )
  pushd webapp\frontend
  call bun install
  if errorlevel 1 (popd & echo ERROR: bun install failed. & exit /b 2)
  call bun run build
  if errorlevel 1 (popd & echo ERROR: bun run build failed. & exit /b 2)
  popd
)

python runtime_preflight.py --production
if errorlevel 1 (
  echo.
  echo Runtime is not ready. Review the preflight output above.
  exit /b 2
)
start "Agentic HIP V130" cmd /k "python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8765
exit /b 0
