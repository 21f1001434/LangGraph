from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest

import run_agent
from canonical_payload_contract import interface_family_from_type, interface_shape_summary, lock_request_value
from configuration_workspace import normalize_interface_type
from interface_registry import BUILTIN_INTERFACES, materialize_parameters, missing_values
from input_builder_integration import _interface_key_for_answer
from sftp_server_contract import (
    CODE_PAGES,
    PARAMETER_KEYS,
    SFTP_SERVER_SSH_KEY,
    materialize_sftp_server_parameters,
)
from webapp.backend.app.excel_api_mapper import _interface_family as excel_interface_family

ROOT = Path(__file__).resolve().parent


def screenshot_example() -> dict:
    return {
        "Server Type": "Linux",
        "Server Name": "ameraicdevmp601.amer.dell.com",
        "Server Path": "/var/data/hip-receiver",
        "File Filtering Pattern": ".*\\.*",
        "Post File Transfer Action": "Delete",
        "Polling Interval": "Cron Expression",
        "Are Input Files Compressed?": "True",
        "SPA URL": "",
        "Api Name": "",
        "Server Port": "22",
        "Login Authentication Type": "Password",
        "Username": "testuser",
        "Password": "testpassword",
        "Cron Expression": "0 * * ? * *",
        "Compression Format": "ZIP",
    }


def test_v130_sftp_server_is_distinct_registered_interface_not_sftphaft_alias():
    assert "SFTP Server" in BUILTIN_INTERFACES
    row = BUILTIN_INTERFACES["SFTP Server"]
    assert row["apiInterfaceType"] == "SFTP Server"
    assert row["family"] == "SFTP_SERVER"
    assert normalize_interface_type("SFTP Server") == "SFTP Server"
    assert normalize_interface_type("SFTP") == "SFTP HAFT"
    assert interface_family_from_type("SFTP Server") == "SFTP_SERVER"
    assert interface_family_from_type("SFTP HAFT") == "FILE"
    assert _interface_key_for_answer("SFTP Server", "SFTP") == "SFTP Server"
    assert excel_interface_family("SFTP Server") == "sftp_server"
    assert excel_interface_family("SFTP HAFT") == "sftp"


def test_v130_schema_registers_exact_parameter_superset_and_code_pages():
    summary = interface_shape_summary(include_additive=True)
    fam = summary["allFamilies"]["SFTP_SERVER"]
    assert fam["sourceKeys"] == list(PARAMETER_KEYS)
    assert fam["targetKeys"] == list(PARAMETER_KEYS)
    assert "Cp037" in CODE_PAGES and "Cp33722" in CODE_PAGES and "Cp970" in CODE_PAGES
    assert len(CODE_PAGES) == len(set(CODE_PAGES))


def test_v130_dev_screenshot_linux_password_sender_payload_exact_conditions():
    payload = materialize_sftp_server_parameters(
        screenshot_example(), system_type="Dell Application", profile_usage="Sender"
    )
    assert payload["Server Type"] == "Linux"
    assert payload["Server Name"] == "ameraicdevmp601.amer.dell.com"
    assert payload["Server Path"] == "/var/data/hip-receiver"
    assert payload["Server Port"] == "22"
    assert payload["Login Authentication Type"] == "Password"
    assert payload["Username"] == "testuser"
    assert payload["Password"] == "testpassword"
    assert payload["Cron Expression"] == "0 * * ? * *"
    assert payload["Compression Format"] == "ZIP"
    assert "SSH Username" not in payload and "SSH Key" not in payload
    assert "Windows Login Authentication Type" not in payload
    assert "Is EBCDIC enabled?" not in payload and "Code Page" not in payload


def test_v130_linux_key_auth_injects_fixed_ssh_key_and_omits_password_fields():
    supplied = screenshot_example()
    supplied["Login Authentication Type"] = "Key"
    supplied.pop("Username")
    supplied.pop("Password")
    supplied["SSH Username"] = "svc_hip"
    payload = materialize_sftp_server_parameters(
        supplied, system_type="Dell Application", profile_usage="Sender"
    )
    assert payload["SSH Username"] == "svc_hip"
    assert payload["SSH Key"] == SFTP_SERVER_SSH_KEY
    assert "Username" not in payload and "Password" not in payload
    bad = dict(supplied, **{"SSH Key": "some_other_key"})
    with pytest.raises(ValueError, match="SSH Key must be the Dev-approved constant"):
        materialize_sftp_server_parameters(bad, system_type="Dell Application", profile_usage="Sender")


def test_v130_windows_dell_application_uses_windows_auth_and_no_linux_auth_fields():
    supplied = {
        "Server Type": "Windows",
        "Server Name": "win-sftp.dell.com",
        "Server Path": "D:/hip/in",
        "File Filtering Pattern": "*.xml",
        "Post File Transfer Action": "Delete",
        "Polling Interval": "Every Hour",
        "Are Input Files Compressed?": "False",
        "SPA URL": "",
        "Api Name": "",
        "Windows Login Authentication Type": "Password",
        "Windows Username": "svc_user",
        "Windows Password": "secret",
    }
    payload = materialize_sftp_server_parameters(
        supplied, system_type="Dell Application", profile_usage="Sender"
    )
    assert payload["Windows Login Authentication Type"] == "Password"
    assert payload["Windows Username"] == "svc_user"
    assert payload["Windows Password"] == "secret"
    for field in ("Server Port", "Login Authentication Type", "Username", "Password", "SSH Username", "SSH Key", "Archive File Path"):
        assert field not in payload


def test_v130_partner_server_type_is_linux_only():
    with pytest.raises(ValueError, match="Partner SFTP Server supports Server Type=Linux only"):
        materialize_sftp_server_parameters(
            {
                "Server Type": "Windows",
                "Server Name": "partner",
                "Server Path": "/x",
                "Are Input Files Compressed?": "False",
            },
            system_type="Partner",
            profile_usage="Receiver",
        )


def test_v130_partner_receiver_omits_sender_only_fields_and_applies_ebcdic():
    supplied = {
        **screenshot_example(),
        "Is EBCDIC enabled?": "True",
        "Code Page": "Cp037",
    }
    payload = materialize_sftp_server_parameters(
        supplied, system_type="Partner", profile_usage="Receiver"
    )
    for field in ("File Filtering Pattern", "Post File Transfer Action", "Polling Interval", "Cron Expression", "Rename", "Archive File Path"):
        assert field not in payload
    assert payload["Is EBCDIC enabled?"] == "True"
    assert payload["Code Page"] == "Cp037"
    assert payload["Compression Format"] == "ZIP"


def test_v130_sender_rename_archive_cron_and_compression_conditions():
    base = {
        "Server Type": "Linux", "Server Name": "s", "Server Path": "/p",
        "File Filtering Pattern": "*.xml", "Are Input Files Compressed?": "False",
        "Server Port": "22", "Login Authentication Type": "Password",
        "Username": "u", "Password": "p", "SPA URL": "", "Api Name": "",
    }
    rename = materialize_sftp_server_parameters(
        {**base, "Post File Transfer Action": "Rename", "Rename": "Random Text", "Polling Interval": "Every Hour"},
        system_type="Dell Application", profile_usage="Sender"
    )
    assert rename["Rename"] == "Random Text"
    assert "Archive File Path" not in rename and "Cron Expression" not in rename and "Compression Format" not in rename

    archive = materialize_sftp_server_parameters(
        {**base, "Post File Transfer Action": "Move To Archive", "Archive File Path": "/archive", "Polling Interval": "Cron Expression", "Cron Expression": "0 0 * ? * *", "Are Input Files Compressed?": "True", "Compression Format": "GZIP"},
        system_type="Dell Application", profile_usage="Sender"
    )
    assert archive["Archive File Path"] == "/archive"
    assert archive["Cron Expression"] == "0 0 * ? * *"
    assert archive["Compression Format"] == "GZIP"
    assert "Rename" not in archive


def test_v130_invalid_code_page_is_rejected():
    with pytest.raises(ValueError, match="INVALID_INTERFACE_VALUE: Code Page"):
        materialize_sftp_server_parameters(
            {
                "Server Type": "Linux", "Server Name": "p", "Server Path": "/p",
                "Server Port": "22", "Login Authentication Type": "Password",
                "Username": "u", "Password": "p", "Are Input Files Compressed?": "False",
                "Is EBCDIC enabled?": "True", "Code Page": "Cp99999",
            },
            system_type="Partner", profile_usage="Receiver"
        )


def test_v130_registry_missing_values_follow_context_and_mark_password_sensitive():
    definition = BUILTIN_INTERFACES["SFTP Server"]
    params = materialize_parameters(definition, "source", {
        "Server Type": "Linux", "Server Name": "s", "Server Path": "/p",
        "Are Input Files Compressed?": "False", "File Filtering Pattern": "*.xml",
        "Post File Transfer Action": "Move To Archive", "Polling Interval": "Cron Expression",
        "Server Port": "22", "Login Authentication Type": "Password", "Username": "u",
    })
    fields = {x["field"] for x in missing_values(
        definition, "source", params, "",
        system_type="Dell Application", profile_usage="Sender"
    )}
    assert "Password" in fields
    assert "Archive File Path" in fields
    assert "Cron Expression" in fields
    assert "sourceSharedProfile" in fields
    assert "Password" in definition["sourceSensitiveFields"]


def test_v130_canonical_lock_drops_unknown_and_inactive_fields():
    body = {
        "interfaceType": "SFTP Server",
        "propertyMap": {**screenshot_example(), "Invented": "NO", "SSH Username": "bad"},
        "transportProfileName": "SFTP_SERVER_SRC",
        "hipEnvironment": "DEV",
    }
    locked, meta = lock_request_value("validate_source", "payload", body, interface_family="SFTP_SERVER")
    params = locked["propertyMap"]
    assert "Invented" not in params
    assert "SSH Username" not in params
    assert params["Username"] == "testuser"
    assert params["Compression Format"] == "ZIP"
    assert "propertyMap.Invented" in meta["droppedPaths"]


def test_v130_canonical_lock_enforces_conditional_required_values():
    body = {
        "interfaceType": "SFTP Server",
        "propertyMap": {
            "Server Type": "Linux", "Server Name": "s", "Server Path": "/p",
            "Are Input Files Compressed?": "True", "Server Port": "22",
            "Login Authentication Type": "Password", "Username": "u", "Password": "p",
        },
        "transportProfileName": "SFTP_SERVER",
        "hipEnvironment": "DEV",
    }
    with pytest.raises(ValueError, match="Compression Format"):
        lock_request_value("validate_source", "payload", body, interface_family="SFTP_SERVER")


def test_v130_runner_materializer_and_lock_prune_context_for_all_tp_paths(monkeypatch):
    r = run_agent.Runner(llm_enabled=False)
    src = r.source_tp()
    old_src = deepcopy(src)
    try:
        src.clear()
        src.update({
            "interface_type": "SFTP Server",
            "system_type": "Dell Application",
            "profile_usage": "Sender",
            "profile_name": "SFTP_SERVER_SRC",
            "partner_name": "AIC - DCE",
            "interface_parameters": screenshot_example(),
        })
        assert r.tp_interface_type(src) == "SFTP Server"
        params = r.tp_parameters(src, "source")
        assert params["Server Port"] == "22"
        assert params["Password"] == "testpassword"

        validate = r.preview_step_request("validate_source")
        assert validate["payload"]["interfaceType"] == "SFTP Server"
        assert validate["payload"]["propertyMap"]["Compression Format"] == "ZIP"

        tp = r.preview_step_request("source_tp")
        iface = tp["payload"]["transportProfileDetails"][0]["interfaceDetails"][0]
        assert iface["interfaceType"] == "SFTP Server"
        assert iface["parameters"]["Cron Expression"] == "0 * * ? * *"

        monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "TEST2")
        mig = r.preview_step_request("migrate_source_tp")
        assert mig["payload"]["transportProfileInterfaceType"] == "SFTP Server"
        assert mig["payload"]["transportProfileInterfaceParameters"]["Server Name"] == "ameraicdevmp601.amer.dell.com"
    finally:
        src.clear(); src.update(old_src)


def test_v130_runner_lock_prevents_receiver_partner_from_leaking_sender_fields():
    r = run_agent.Runner(llm_enabled=False)
    tgt = r.target_tp()
    old = deepcopy(tgt)
    try:
        tgt.clear()
        tgt.update({
            "interface_type": "SFTP Server",
            "system_type": "Partner",
            "profile_usage": "Receiver",
            "profile_name": "SFTP_SERVER_TGT",
            "partner_name": "PARTNER",
            "interface_parameters": {
                "Server Type": "Linux", "Server Name": "partner.example", "Server Path": "/in",
                "Are Input Files Compressed?": "False", "Server Port": "22",
                "Login Authentication Type": "Password", "Username": "u", "Password": "p",
                "Is EBCDIC enabled?": "False",
            },
        })
        generated = r.preview_step_request("validate_target")["payload"]
        malicious = deepcopy(generated)
        malicious["propertyMap"].update({
            "File Filtering Pattern": "*.bad", "Post File Transfer Action": "Delete", "Polling Interval": "Every Hour"
        })
        locked, _ = r.lock_request_value("validate_target", "payload", malicious, fallback=generated)
        for field in ("File Filtering Pattern", "Post File Transfer Action", "Polling Interval"):
            assert field not in locked["propertyMap"]
        assert locked["propertyMap"]["Is EBCDIC enabled?"] == "False"
    finally:
        tgt.clear(); tgt.update(old)
