# V130 — Dev-supplied SFTP Server interface contract

V130 adds `SFTP Server` as a separate governed Transport Profile interface. It does **not** alias or reuse the historical `SFTP HAFT` FILE contract. V129 same-base-API Create/Edit behavior remains unchanged.

## Dev-supplied conditional contract

- Dell Application: `Server Type` may be `Linux` or `Windows`. Partner: `Linux` only.
- Linux: emit `Server Port` and `Login Authentication Type`. Password emits `Username` + `Password`; Key emits `SSH Username` + fixed `SSH Key = haft_aut_sftp_server_private_key`.
- Windows: emit `Windows Login Authentication Type=Password`, `Windows Username`, and `Windows Password`; Linux authentication fields are omitted.
- Sender only: emit `File Filtering Pattern`, `Post File Transfer Action`, and `Polling Interval`. `Rename` requires `Rename`; Linux `Move To Archive` requires `Archive File Path`; `Cron Expression` polling requires `Cron Expression`.
- `Are Input Files Compressed?=True` requires `Compression Format` in `GZIP`, `ZIP`, `TAR`.
- Partner only: emit `Is EBCDIC enabled?`; when True, require `Code Page` from the Dev-approved code-page allowlist.
- Inactive and unknown fields are pruned before the HTTP boundary. Password values remain sensitive.

## End-to-end integration

The contract is wired through the interface registry, Input Builder/guided configuration, React bootstrap catalogue, canonical payload structure lock, Excel mapper classification, Source/Target TP validate/create/edit materialization, and Migration Transport Profile materialization. The same conditional contract is reapplied after human value overrides so inactive fields cannot leak into LIVE requests.

No shared Flow Transport Profile name/reference was supplied in the Dev screenshots. V130 therefore leaves the SFTP Server shared Flow TP reference unresolved and asks for human evidence instead of borrowing an SFTP HAFT profile or inventing one.

## Retained V129 behavior

For Dev-approved operation-capable APIs, Create and Edit continue to use the same existing POST endpoint and canonical request shape. Transport Profile Edit synchronizes the existing `operation` and `transportProfileOperation`; Flow Edit changes its existing `operation`. No separate Edit endpoint or invented payload attribute is introduced.
