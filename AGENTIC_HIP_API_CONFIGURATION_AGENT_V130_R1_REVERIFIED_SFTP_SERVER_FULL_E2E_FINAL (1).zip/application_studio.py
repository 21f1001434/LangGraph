from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Any, Dict, List

from business_demo import (
    BUSINESS_DEMO_LIVE_STEPS,
    BUSINESS_DEMO_SKIP_STEPS,
    prepare_uhal_business_demo,
)
from execution_flow import STEP_DEFINITIONS
from migration_api_contract import MIGRATION_STEP_DEFINITIONS
from payload_ui_helpers import json_change_paths, safe_request_for_ui
from interface_registry import interface_keys, get_interface
from agentic_interface_orchestrator import AgenticInterfaceOrchestrator, activate_proposal


INTERFACES = ["SFTP", "SFTP Server", "FTP", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"]


def interface_options(root: Path) -> List[str]:
    """Built-in plus user-registered interfaces for the Studio."""
    return interface_keys(Path(root))


def interface_metadata(root: Path, key: str) -> Dict[str, Any]:
    return get_interface(Path(root), key)


CUSTOMER_CATALOG: Dict[str, List[Dict[str, Any]]] = {
    "SFTP": [
        {
            "customer": "U-HAUL",
            "status": "Existing · Demo ready",
            "transaction": "X12 856 Ship Notice",
            "direction": "Outbound",
            "deploymentGroup": "hip-automation",
            "template": "Approved U-HAUL baseline",
        },
        {
            "customer": "Create / clone another customer",
            "status": "Guided configuration",
            "transaction": "Choose in guided workspace",
            "direction": "Choose in guided workspace",
            "deploymentGroup": "hip-automation",
            "template": "U-HAUL can be used as template",
        },
    ],
    "SFTP Server": [
        {
            "customer": "Create / clone customer",
            "status": "Dev-approved SFTP Server conditional contract / values required",
            "transaction": "Choose in guided workspace",
            "direction": "Choose in guided workspace",
            "deploymentGroup": "hip-automation",
            "template": "SFTP Server interfaceDetails contract supplied 2026-09-14",
        }
    ],
    "FTP": [
        {
            "customer": "Create / clone customer",
            "status": "Guided configuration",
            "transaction": "Choose in guided workspace",
            "direction": "Choose in guided workspace",
            "deploymentGroup": "hip-automation",
            "template": "Same file/account model as SFTP",
        }
    ],
    "HTTPS": [
        {
            "customer": "Create / clone customer",
            "status": "Partner values required",
            "transaction": "Choose in guided workspace",
            "direction": "Choose in guided workspace",
            "deploymentGroup": "hip-automation",
            "template": "U-HAUL baseline + HTTPS TP interface change",
        }
    ],
    "HTTPS-AS2": [
        {
            "customer": "Create / clone customer",
            "status": "Dev-approved AS2 attributes / Partner values required",
            "transaction": "Choose in guided workspace",
            "direction": "Choose in guided workspace",
            "deploymentGroup": "hip-automation",
            "template": "Dev-approved HTTPS-AS2 Sender/Receiver attributes (2026-09-02)",
        }
    ],
}


def customer_options(interface: str) -> List[str]:
    rows = CUSTOMER_CATALOG.get(interface, [])
    if rows:
        return [row["customer"] for row in rows]
    return ["U-HAUL template · change interface only", "Create / clone customer"]


def customer_metadata(interface: str, customer: str) -> Dict[str, Any]:
    for row in CUSTOMER_CATALOG.get(interface, []):
        if row.get("customer") == customer:
            return dict(row)
    if customer.startswith("U-HAUL template"):
        return {
            "customer": customer,
            "status": "Agentic interface scenario",
            "transaction": "X12 856 Ship Notice baseline",
            "direction": "Outbound",
            "deploymentGroup": "hip-automation",
            "template": "Approved U-HAUL baseline + interface-specific TP change",
        }
    return {
        "customer": customer,
        "status": "Guided configuration",
        "transaction": "Choose / inherit template",
        "direction": "Choose / inherit template",
        "deploymentGroup": "hip-automation",
        "template": "Interface registry driven",
    }


def analyze_interface_scenario(
    root: Path,
    baseline_input: Dict[str, Any],
    pdf_kb: Any,
    *,
    source_interface: str,
    target_interface: str,
    source_parameters: Dict[str, Any] | None = None,
    target_parameters: Dict[str, Any] | None = None,
    source_shared_profile: str = "",
    target_shared_profile: str = "",
    deployment_group: str = "",
) -> Dict[str, Any]:
    agent = AgenticInterfaceOrchestrator(Path(root), baseline_input, pdf_kb=pdf_kb)
    return agent.propose(
        source_interface=source_interface,
        target_interface=target_interface,
        source_parameters=source_parameters,
        target_parameters=target_parameters,
        source_shared_profile=source_shared_profile,
        target_shared_profile=target_shared_profile,
        deployment_group=deployment_group,
    )


def activate_interface_scenario(root: Path, proposal: Dict[str, Any]) -> Path:
    return activate_proposal(Path(root), proposal)


def prepare_sftp_uhal_studio(root: Path) -> Dict[str, Any]:
    """Prepare U-HAUL for full live API building-block execution."""
    result = prepare_uhal_business_demo(Path(root))
    result["studioMode"] = "UHAL_FULL_LIVE_API_COVERAGE"
    result["logicalSteps"] = len(STEP_DEFINITIONS)
    result["liveSteps"] = len(BUSINESS_DEMO_LIVE_STEPS)
    result["reuseSteps"] = 0
    return result


def request_inventory(root: Path, *, include_migration: bool = False) -> Dict[str, Any]:
    """Build effective requests without sending any API call.

    The historical default remains the 18 create/configuration requests. V122
    callers such as API Testing may opt into the seven additive Migration blocks.
    """
    # Local import prevents circular import when run_agent imports other helpers.
    from run_agent import Runner

    runner = Runner(llm_enabled=False)
    ordered = runner.execution_flow.ordered_steps()
    if include_migration:
        ordered = ordered + list(MIGRATION_STEP_DEFINITIONS)
    cards: List[Dict[str, Any]] = []

    for index, key in enumerate(ordered, start=1):
        preview = runner.preview_step_request(key)
        request_kind = preview.get("requestKind") or "payload"
        generated = (
            preview.get("generatedParams")
            if request_kind == "params"
            else preview.get("generatedPayload")
        ) or {}
        effective = (
            preview.get("params")
            if request_kind == "params"
            else preview.get("payload")
        ) or {}
        generated_safe = safe_request_for_ui(generated)
        effective_safe = safe_request_for_ui(effective)
        changed_paths = json_change_paths(generated_safe, effective_safe)
        skipped = runner.execution_plan.is_skipped(key)
        applicable = preview.get("applicable") is not False
        definition = STEP_DEFINITIONS.get(key) or MIGRATION_STEP_DEFINITIONS.get(key) or {}

        cards.append(
            {
                "order": index,
                "stepKey": key,
                "label": definition.get("label") or key,
                "group": definition.get("group") or "Other",
                "method": preview.get("method") or "—",
                "url": preview.get("url") or "",
                "urlKey": preview.get("urlKey") or "",
                "tokenKind": preview.get("tokenKind") or "HIP",
                "requestKind": request_kind,
                "generated": generated_safe,
                "effective": effective_safe,
                "changedPaths": changed_paths,
                "edited": bool((preview.get("override") or {}).get("applied")),
                "decision": ("NOT APPLICABLE" if not applicable else ("LIVE API" if not skipped else "SKIP (UNEXPECTED)")),
                "applicable": applicable,
                "applicabilityReason": preview.get("applicabilityReason") or "",
                "businessMeaning": (preview.get("applicabilityReason") or _business_meaning(key, skipped)) if not applicable else _business_meaning(key, skipped),
            }
        )

    return {
        "generatedAt": dt.datetime.now().isoformat(),
        "cards": cards,
        "total": len(cards),
        "live": sum(1 for row in cards if row["decision"] == "LIVE API"),
        "reused": 0,
        "edited": sum(1 for row in cards if row["edited"]),
    }


def run_local_request_checks(root: Path) -> Dict[str, Any]:
    """Run mapper, execution-plan, MCP/PDF request checks without live HIP mutation."""
    from run_agent import Runner

    root = Path(root)
    runner = Runner(llm_enabled=False)
    mapper_issues = runner.mapper.validate()
    def _issue_value(item: Any, key: str) -> Any:
        if isinstance(item, dict):
            return item.get(key)
        return getattr(item, key, None)

    mapper_errors = [
        item for item in mapper_issues
        if str(_issue_value(item, "severity") or "").upper() == "ERROR"
    ]

    plan = runner.execution_plan.summary()
    flow = runner.execution_flow.summary()
    inventory = request_inventory(root)

    request_checks: List[Dict[str, Any]] = []

    def _next_action(step_key: str, label: str, errors: List[Dict[str, Any]]) -> str:
        fields = [str(x.get("field") or "") for x in errors if isinstance(x, dict)]
        if any("partnerIdentifierValue" in field for field in fields):
            customer_key = re.sub(r"[^a-z0-9]+", "", str(runner.input.get("customer") or "").lower())
            if customer_key == "uhaul":
                return "Use the Dev-approved dce-test-partner DUNS value 12345666 used by the U-HAUL reference, regenerate the Partner request, then run validation again."
            return "Provide the Dev-approved Partner Identifier value. Routing Sender/Receiver identity is reused only when it is valid for that customer's approved identifier type."
        if any(field.startswith("header.x-account-name") for field in fields):
            return "Check the source HIP account name in the Transport Profile. The Partner Create x-account-name header is derived from that value."
        if any("accountName" in field for field in fields):
            return "Check the source/target Transport Profile existing_account_name. Shared SFTP/FTP UAT accounts are auto-resolved when applicable."
        if any("documentTypeId" in field for field in fields):
            return "Run/resolve Source Document Type first or use the API Flow preflight so its returned ID is injected into the Mapping Rule request."
        if any("mapData" in field or "mapFileName" in field for field in fields):
            return "Upload the approved Contivo JAR (and XBM when available), then rebuild. The agent extracts map name, class, version and JAR content from the customer files."
        if any("flowDefinition" in field for field in fields):
            return "Open the request details and correct the Flow Definition fields shown below; Document Type names/versions must be used instead of embedded documentTypeId values."
        field_text = ", ".join(x for x in fields if x) or "request fields"
        return f"Correct {field_text} for {label or step_key}, then run validation again."
    for seq, card in enumerate(inventory["cards"], start=1):
        preview = runner.preview_step_request(card["stepKey"])
        if preview.get("applicable") is False:
            request_checks.append({
                "stepKey": card["stepKey"],
                "label": card["label"],
                "decision": "NOT APPLICABLE",
                "valid": True,
                "mcpValid": True,
                "pdfValid": True,
                "errors": [],
                "warnings": [preview.get("applicabilityReason") or "Not required for this flow."],
            })
            continue
        request_kind = preview.get("requestKind") or "payload"
        payload = preview.get("payload") if request_kind == "payload" else None
        params = preview.get("params") if request_kind == "params" else None
        result = runner.validate_request_contract(
            seq=seq,
            api_key=preview.get("urlKey") or card["stepKey"],
            method=preview.get("method") or "GET",
            url=preview.get("url") or "",
            extra_headers=preview.get("extraHeaders") or {},
            payload=payload,
            params=params,
        )
        errors = (
            list((result.get("deterministic") or {}).get("errors") or [])
            + list((result.get("mcpToolValidation") or {}).get("errors") or [])
        )
        warnings = (
            list((result.get("deterministic") or {}).get("warnings") or [])
            + list((result.get("mcpToolValidation") or {}).get("warnings") or [])
        )
        request_checks.append(
            {
                "stepKey": card["stepKey"],
                "label": card["label"],
                "decision": card["decision"],
                "valid": bool(result.get("valid")),
                "mcpValid": bool((result.get("mcpToolValidation") or {}).get("valid", True)),
                "pdfValid": bool((result.get("deterministic") or {}).get("valid", True)),
                "errors": errors,
                "warnings": warnings,
                "nextAction": "" if bool(result.get("valid")) else _next_action(card["stepKey"], card["label"], errors),
            }
        )

    mcp_supervisor = runner.mcp.assess_execution_readiness(
        runner.input,
        runner.ov,
    )

    blocked_requests = [item for item in request_checks if not item.get("valid")]
    output = {
        "generatedAt": dt.datetime.now().isoformat(),
        "mapper": {
            "ok": not mapper_errors,
            "errors": [item if isinstance(item, dict) else vars(item) for item in mapper_errors],
            "issues": [item if isinstance(item, dict) else vars(item) for item in mapper_issues],
        },
        "executionPlan": {
            "ok": (not bool(plan.get("confirmed"))) or bool(plan.get("active")),
            "summary": plan,
        },
        "executionFlow": {
            "ok": bool(flow.get("valid", True)),
            "summary": flow,
        },
        "requests": {
            "ok": all(item["valid"] for item in request_checks),
            "validCount": sum(1 for item in request_checks if item["valid"]),
            "total": len(request_checks),
            "blockedCount": len(blocked_requests),
            "items": request_checks,
            "blockedItems": blocked_requests,
            "nextActions": [
                {
                    "stepKey": item.get("stepKey"),
                    "label": item.get("label"),
                    "fields": sorted({str(err.get("field") or "") for err in (item.get("errors") or []) if isinstance(err, dict) and err.get("field")}),
                    "action": item.get("nextAction"),
                }
                for item in blocked_requests
            ],
        },
        "mcp": runner.mcp.status(),
        "mcpSupervisor": mcp_supervisor,
        "inventory": {
            "total": inventory["total"],
            "live": inventory["live"],
            "reused": inventory["reused"],
            "edited": inventory["edited"],
        },
    }
    output["ok"] = bool(
        output["mapper"]["ok"]
        and output["executionPlan"]["ok"]
        and output["executionFlow"]["ok"]
        and output["requests"]["ok"]
        and bool(mcp_supervisor.get("valid", True))
        and not bool(mcp_supervisor.get("liveRunBlocked"))
    )

    reports = root / "reports"
    reports.mkdir(exist_ok=True)
    (reports / "application_studio_agent_checks_latest.json").write_text(
        json.dumps(output, indent=2, default=str),
        encoding="utf-8",
    )
    return output


def _business_meaning(step_key: str, skipped: bool) -> str:
    meanings = {
        "validate_source": "Call the Source Transport Profile validation API and capture its live response.",
        "validate_target": "Call the Target Transport Profile validation API and capture its live response.",
        "validate_flow": "Call Flow name validation and capture the live response.",
        "account_source": "Call Source Account create API even if U-HAUL already exists; duplicate/existing response is test evidence.",
        "account_target": "Call Target Account create API even if U-HAUL already exists; duplicate/existing response is test evidence.",
        "partner_target": "Call Partner create API and capture the response as a reusable building-block test.",
        "system_source": "Call System create API and capture the response as a reusable building-block test.",
        "doctype_source": "Call Source Document Type create API and capture the live response.",
        "doctype_target": "Call Target Document Type create API and capture the live response.",
        "map": "Call MAC Map create API and capture the live response.",
        "rule": "Call Mapping Rule create API and capture the live response.",
        "source_tp": "Call Source Transport Profile orchestration create API.",
        "target_tp": "Call Target Transport Profile orchestration create API.",
        "flow_create": "Call Flow orchestration create API.",
        "flow_deploy": "Call Flow orchestration deploy API.",
        "flow_history": "Call Flow deployment history and capture the returned evidence, even when history is empty.",
        "source_tp_audit": "Call Source Transport Profile audit API and capture the response.",
        "target_tp_audit": "Call Target Transport Profile audit API and capture the response.",
    }
    value = meanings.get(step_key) or "Call this HIP API and capture its response."
    if skipped:
        return "UNEXPECTED SKIP — " + value
    return value

