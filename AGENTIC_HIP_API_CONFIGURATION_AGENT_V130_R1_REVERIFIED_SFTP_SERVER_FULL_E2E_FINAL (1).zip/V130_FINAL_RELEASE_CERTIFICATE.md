# V130 Final Release Certificate — Reverified R1

**Release:** V130 — SFTP Server Interface Contract  
**Revision:** R1 re-verification hardening  
**Date:** 2026-09-14  
**Base:** V129 same-base-API Create/Edit release

## Certified implementation

V130 integrates the Dev-supplied `SFTP Server` Transport Profile interface as a separate canonical interface family. Conditional Linux/Windows authentication, Sender-only transfer/polling fields, compression, Partner EBCDIC/code pages, sensitive password handling, fixed SSH key semantics, canonical shape locking, value-only edit re-pruning, Excel classification, Builder/Studio integration, TP materialization and Migration TP materialization are implemented.

The release preserves V129's rule that Create/Edit reuse the same existing base orchestration API. No separate Edit endpoint or unapproved payload field is invented.

R1 additionally corrects the Windows production launcher display/title from the stale V126 label to V130 and adds a regression test that also proves SFTP Server Edit reuses the same Transport Profile Create endpoint while preserving the SFTP Server contract.

## Fresh exact-package verification

- Complete Python collection: **619/619 PASS** in deterministic batches (includes **55/55 FastAPI backend tests**).
- V130/V129/SFTP/Create-Edit focused rerun: **59/59 PASS**.
- Package validator: **59/59 PASS**.
- Adaptive validator: **60/60 PASS**.
- Business readiness: **70/70 PASS**.
- Final release validator: **16/16 PASS**.
- TypeScript/TSX: **26 files, 0 syntax/transpile diagnostics**.
- FastAPI process startup: **PASS**; `/api/health` and `/api/bootstrap` returned successfully.
- ZIP/manifest verification is generated from the clean R1 source after testing.

## Environment boundary

A real Dell HIP DEV/LIVE mutation is not claimed from this environment because Dell OAuth/network access is unavailable. HTTP execution behavior is covered by the deterministic Runner/regression suite. The production frontend dependency-resolved Vite build requires Bun on the supported Windows host; Bun is not installed in this verification container, so the frontend was source-transpile verified here rather than dependency-installed/built.
