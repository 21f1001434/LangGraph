from pathlib import Path
from copy import deepcopy
import tempfile

from execution_flow import ExecutionFlowConfig, reset_execution_flow, save_operation_mode
from run_agent import Runner

ROOT = Path(__file__).resolve().parent


def test_v130_windows_launcher_identifies_current_release():
    text = (ROOT / "RUN_AGENTIC_HIP.bat").read_text(encoding="utf-8")
    assert "Agentic HIP API Configuration Agent - V130" in text
    assert 'start "Agentic HIP V130"' in text
    assert "Agentic HIP API Configuration Agent - V126" not in text
    assert 'start "Agentic HIP V126"' not in text


def test_v130_sftp_server_edit_reuses_create_endpoint_and_preserves_contract():
    runner = Runner(llm_enabled=False)
    src = runner.source_tp()
    old = deepcopy(src)
    try:
        src.clear()
        src.update({
            "interface_type": "SFTP Server",
            "system_type": "Dell Application",
            "profile_usage": "Sender",
            "profile_name": "SFTP_SERVER_SRC",
            "partner_name": "AIC - DCE",
            "interface_parameters": {
                "Server Type": "Linux",
                "Server Name": "sftp.dell.local",
                "Server Path": "/var/data/hip-receiver",
                "File Filtering Pattern": "*.xml",
                "Post File Transfer Action": "Delete",
                "Polling Interval": "Every Hour",
                "Are Input Files Compressed?": "False",
                "SPA URL": "",
                "Api Name": "",
                "Server Port": "22",
                "Login Authentication Type": "Key",
                "SSH Username": "svc_hip",
            },
        })
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            reset_execution_flow(root)
            runner.execution_flow = ExecutionFlowConfig(root)
            created = runner.preview_step_request("source_tp")
            save_operation_mode(root, "source_tp", "edit", source="agent")
            runner.execution_flow = ExecutionFlowConfig(root)
            edited = runner.preview_step_request("source_tp")

        assert created["method"] == edited["method"] == "POST"
        assert created["url"] == edited["url"]
        assert created["urlKey"] == edited["urlKey"] == "orch_tp_create"
        assert created["payload"]["operation"] == "Create"
        assert edited["payload"]["operation"] == "Edit"
        detail = edited["payload"]["transportProfileDetails"][0]
        assert detail["transportProfileOperation"] == "edit"
        interface = detail["interfaceDetails"][0]
        assert interface["interfaceType"] == "SFTP Server"
        assert interface["interfaceRole"] == "Primary"
        assert interface["parameters"]["SSH Key"] == "haft_aut_sftp_server_private_key"
        assert "Password" not in interface["parameters"]
    finally:
        src.clear()
        src.update(old)
