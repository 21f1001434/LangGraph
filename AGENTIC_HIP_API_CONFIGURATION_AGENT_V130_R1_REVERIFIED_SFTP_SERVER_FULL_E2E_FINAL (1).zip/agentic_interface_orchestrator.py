from __future__ import annotations

import datetime as dt
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List

from interface_registry import get_interface, materialize_parameters, missing_values

ALLOWED_INTERFACE_PATHS = {
    "objects.source_transport_profile.interface_type",
    "objects.source_transport_profile.interface_parameters",
    "objects.source_transport_profile.deployment_group",
    "objects.target_transport_profile.interface_type",
    "objects.target_transport_profile.interface_parameters",
    "objects.target_transport_profile.deployment_group",
    "objects.biz_flow.configure_source.source_transport_profile",
    "objects.biz_flow.configure_targets.target_transport_profile",
    "objects.biz_flow.configure_routing.actions.target",
    "_agentic_interface_mode",
}


def _deep_diff(before: Any, after: Any, prefix: str = "") -> List[str]:
    changed: List[str] = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after), key=str):
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in before or key not in after:
                changed.append(path)
            else:
                changed.extend(_deep_diff(before[key], after[key], path))
        return changed
    if isinstance(before, list) and isinstance(after, list):
        if before != after:
            changed.append(prefix or "<root>")
        return changed
    if before != after:
        changed.append(prefix or "<root>")
    return changed


def _is_allowed(path: str) -> bool:
    return any(
        path == allowed or path.startswith(allowed + ".") or path.startswith(allowed + "[")
        for allowed in ALLOWED_INTERFACE_PATHS
    )


class AgenticInterfaceOrchestrator:
    """Contract-aware interface planner for any registered interface.

    The public trace is a safe Observe -> Retrieve -> Plan -> Validate -> Act ->
    Critic summary. It intentionally does not expose hidden chain-of-thought.
    """

    def __init__(self, root: Path, baseline_input: Dict[str, Any], pdf_kb: Any | None = None):
        self.root = Path(root)
        self.baseline = deepcopy(baseline_input)
        self.pdf_kb = pdf_kb

    def analyze(
        self,
        *,
        source_interface: str,
        target_interface: str,
        source_parameters: Dict[str, Any] | None = None,
        target_parameters: Dict[str, Any] | None = None,
        source_shared_profile: str = "",
        target_shared_profile: str = "",
        deployment_group: str = "",
    ) -> Dict[str, Any]:
        source_def = get_interface(self.root, source_interface)
        target_def = get_interface(self.root, target_interface)
        source_params = materialize_parameters(source_def, "source", source_parameters)
        target_params = materialize_parameters(target_def, "target", target_parameters)
        source_shared = str(source_shared_profile or source_def.get("sourceSharedProfile") or "").strip()
        target_shared = str(target_shared_profile or target_def.get("targetSharedProfile") or "").strip()
        group = "hip-automation"

        objects = self.baseline.get("objects") if isinstance(self.baseline, dict) else {}
        objects = objects if isinstance(objects, dict) else {}
        source_tp = objects.get("source_transport_profile") if isinstance(objects.get("source_transport_profile"), dict) else {}
        target_tp = objects.get("target_transport_profile") if isinstance(objects.get("target_transport_profile"), dict) else {}
        questions = (
            missing_values(
                source_def, "source", source_params, source_shared,
                system_type=source_tp.get("system_type"),
                profile_usage=source_tp.get("profile_usage") or "Sender",
            )
            + missing_values(
                target_def, "target", target_params, target_shared,
                system_type=target_tp.get("system_type"),
                profile_usage=target_tp.get("profile_usage") or "Receiver",
            )
        )
        docs_required = bool(source_def.get("requiresDocumentation") or target_def.get("requiresDocumentation"))
        docs_ready = bool(self.pdf_kb and getattr(self.pdf_kb, "has_documents", lambda: False)())
        if docs_required and not docs_ready:
            questions.append({
                "field": "apiDocumentation",
                "question": "Upload the API/Transport Profile documentation for this interface.",
                "why": "This interface is contract-driven; the agent needs documentation before live execution.",
            })

        trace = [
            {"phase": "OBSERVE", "status": "OK", "summary": "Loaded the active HIP baseline and interface registry."},
            {"phase": "RETRIEVE", "status": "OK" if (not docs_required or docs_ready) else "NEEDS_INPUT", "summary": "Checked built-in/custom interface definition and available API documentation."},
            {"phase": "PLAN", "status": "OK", "summary": f"Plan Source={source_def.get('apiInterfaceType')} Target={target_def.get('apiInterfaceType')} deployment={group}."},
            {"phase": "VALIDATE", "status": "OK" if not questions else "NEEDS_INPUT", "summary": "All interface-specific values are present." if not questions else f"{len(questions)} value(s) or contract item(s) still required."},
        ]
        return {
            "ready": not questions,
            "sourceKey": source_interface,
            "targetKey": target_interface,
            "sourceDefinition": source_def,
            "targetDefinition": target_def,
            "sourceParameters": source_params,
            "targetParameters": target_params,
            "sourceSharedProfile": source_shared,
            "targetSharedProfile": target_shared,
            "deploymentGroup": group,
            "documentationRequired": docs_required,
            "documentationReady": docs_ready,
            "questions": questions,
            "trace": trace,
        }

    def propose(self, **kwargs: Any) -> Dict[str, Any]:
        analysis = self.analyze(**kwargs)
        if not analysis["ready"]:
            return {
                **analysis,
                "valid": False,
                "proposal": None,
                "critic": {
                    "status": "BLOCKED",
                    "violations": [],
                    "summary": "The agent is waiting for required interface values/documentation.",
                },
            }

        proposed = deepcopy(self.baseline)
        objects = proposed.setdefault("objects", {})
        source_tp = objects.setdefault("source_transport_profile", {})
        target_tp = objects.setdefault("target_transport_profile", {})
        biz = objects.setdefault("biz_flow", {})

        source_def = analysis["sourceDefinition"]
        target_def = analysis["targetDefinition"]
        source_tp["interface_type"] = source_def.get("apiInterfaceType") or analysis["sourceKey"]
        target_tp["interface_type"] = target_def.get("apiInterfaceType") or analysis["targetKey"]
        source_tp["deployment_group"] = analysis["deploymentGroup"]
        target_tp["deployment_group"] = analysis["deploymentGroup"]

        if str(source_def.get("apiInterfaceType") or "").upper() in {"SFTP HAFT", "FTP"}:
            source_tp.pop("interface_parameters", None)
        else:
            source_tp["interface_parameters"] = deepcopy(analysis["sourceParameters"])
        if str(target_def.get("apiInterfaceType") or "").upper() in {"SFTP HAFT", "FTP"}:
            target_tp.pop("interface_parameters", None)
        else:
            target_tp["interface_parameters"] = deepcopy(analysis["targetParameters"])

        source_cfg = biz.setdefault("configure_source", {})
        target_cfg = biz.setdefault("configure_targets", {})
        route_actions = biz.setdefault("configure_routing", {}).setdefault("actions", {})
        source_cfg["source_transport_profile"] = analysis["sourceSharedProfile"]
        target_cfg["target_transport_profile"] = analysis["targetSharedProfile"]
        route_actions["target"] = analysis["targetSharedProfile"]

        proposed["_agentic_interface_mode"] = {
            "enabled": True,
            "baseline": self.baseline.get("customer") or "active configuration",
            "sourceInterface": analysis["sourceKey"],
            "targetInterface": analysis["targetKey"],
            "deploymentGroup": analysis["deploymentGroup"],
            "createdAt": dt.datetime.now().isoformat(),
            "policy": "Only Transport Profile interface/deployment and derived Flow shared-profile bindings may change.",
        }

        changed = _deep_diff(self.baseline, proposed)
        violations = [path for path in changed if not _is_allowed(path)]
        valid = not violations
        trace = list(analysis["trace"])
        trace.extend([
            {"phase": "ACT", "status": "OK" if valid else "REJECTED", "summary": "Generated the interface-aware canonical configuration."},
            {"phase": "CRITIC", "status": "PASS" if valid else "FAIL", "summary": "Only allowed interface paths changed." if valid else f"Rejected {len(violations)} frozen-path change(s)."},
        ])
        return {
            **analysis,
            "valid": valid,
            "proposal": proposed if valid else None,
            "changedPaths": changed,
            "critic": {
                "status": "PASS" if valid else "FAIL",
                "violations": violations,
                "allowedPaths": sorted(ALLOWED_INTERFACE_PATHS),
            },
            "trace": trace,
        }


def activate_proposal(root: Path, proposal: Dict[str, Any]) -> Path:
    path = Path(root) / "input.json"
    path.write_text(json.dumps(proposal, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def impact_analysis(changed_paths: List[str]) -> Dict[str, Any]:
    affected = set()
    reasons: Dict[str, List[str]] = {}
    for path in changed_paths:
        targets: List[str] = []
        if path.startswith("objects.source_transport_profile"):
            targets.extend(["validate_source", "source_tp", "flow_create"])
        if path.startswith("objects.target_transport_profile"):
            targets.extend(["validate_target", "target_tp", "flow_create"])
        if path.startswith("objects.biz_flow.configure_source"):
            targets.append("flow_create")
        if path.startswith("objects.biz_flow.configure_targets") or path.startswith("objects.biz_flow.configure_routing"):
            targets.append("flow_create")
        for step in targets:
            affected.add(step)
            reasons.setdefault(step, []).append(path)
    return {
        "affectedSteps": sorted(affected),
        "reasons": reasons,
        "count": len(affected),
        "summary": (
            "Only interface-dependent TP validation/orchestration and Flow binding are affected."
            if affected
            else "No API request is affected."
        ),
    }


def recommend_execution_strategy(active_input: Dict[str, Any], plan_summary: Dict[str, Any]) -> Dict[str, str]:
    customer = str(active_input.get("customer") or "").upper()
    objects = active_input.get("objects") or {}
    src = str((objects.get("source_transport_profile") or {}).get("interface_type") or "").upper()
    tgt = str((objects.get("target_transport_profile") or {}).get("interface_type") or "").upper()
    creation = active_input.get("_creation_source") or {}

    if customer in {"U-HAUL", "UHAUL"}:
        return {
            "strategy": "FULL_LIVE_EXECUTION",
            "label": "Full governed LIVE execution",
            "reason": "V109 no-reuse policy executes every applicable canonical API. A same-call duplicate/existing response is recorded as that API's own evidence, but prior objects or downstream success never substitute for this run's API evidence.",
        }
    if isinstance(creation, dict) and creation.get("mode"):
        return {
            "strategy": "FULL_CONFIGURE",
            "label": "Full configure",
            "reason": "The active input is marked as a newly created/cloned configuration, so normal dependency-ordered creation is the likely path after user approval.",
        }
    if plan_summary.get("active"):
        return {
            "strategy": "CURRENT_PLAN",
            "label": "Use current plan",
            "reason": "A confirmed input-bound execution plan already exists for this configuration.",
        }
    return {
        "strategy": "PLAN_ONLY",
        "label": "Plan only",
        "reason": "The agent cannot prove whether this configuration is existing or new. Review/approve an execution plan before mutation.",
    }
