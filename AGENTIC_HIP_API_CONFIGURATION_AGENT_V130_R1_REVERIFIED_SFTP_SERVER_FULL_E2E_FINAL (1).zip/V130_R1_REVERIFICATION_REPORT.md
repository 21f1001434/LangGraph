# V130 R1 Re-verification Report

This revision was produced after re-checking the actual packaged V130 ZIP rather than relying on its embedded certificate.

The original V130 ZIP was structurally valid and its SHA-256 manifest matched exactly before tests. Re-running the code found no functional regression in the SFTP Server, Create/Edit, Migration, mapping, backend, or governed-payload paths. One stale packaging label was found: `RUN_AGENTIC_HIP.bat` still displayed V126. R1 changes only that launcher identity plus adds a regression test for the launcher and for the combined SFTP Server + same-base-API Edit invariant.

Fresh results: 619/619 Python tests PASS, package 59/59, adaptive 60/60, business readiness 70/70, final release 16/16, 26 TS/TSX files with 0 transpile diagnostics, and live local FastAPI startup/health/bootstrap PASS.
