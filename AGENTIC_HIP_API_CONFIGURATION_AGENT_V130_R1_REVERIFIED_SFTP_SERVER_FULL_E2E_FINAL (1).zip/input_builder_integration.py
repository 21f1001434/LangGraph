from __future__ import annotations

import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Tuple

from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from interface_registry import get_interface, materialize_parameters, missing_values, registry
from input_builder_core import normalize_input_json, _set_flattened_path
from runtime_payload_values import placeholder, save_runtime_payload_value

MEMORY_FILE = "input_builder_memory.json"


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _tokens(path: str) -> List[Any]:
    out: List[Any] = []
    for part in str(path or "").split("."):
        if not part:
            continue
        m = re.match(r"^([^\[]+)", part)
        if m:
            out.append(m.group(1))
        out.extend(int(x) for x in re.findall(r"\[(\d+)\]", part))
    return out


def _get(data: Any, path: str) -> Any:
    cur = data
    for tok in _tokens(path):
        if isinstance(tok, int):
            if not isinstance(cur, list) or tok >= len(cur):
                return None
            cur = cur[tok]
        else:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(tok)
    return cur


def _missing(data: Dict[str, Any], path: str) -> bool:
    value = _get(data, path)
    if isinstance(value, (dict, list)):
        return not bool(value)
    return not _clean(value)


def force_hip_automation(canonical: Dict[str, Any]) -> Dict[str, Any]:
    data, _ = with_default_deployment_group(canonical, {})
    data.setdefault("_builder_audit", {})["deployment_group"] = {
        "value": DEFAULT_DEPLOYMENT_GROUP,
        "source": "fixed_dev_rule",
        "note": "All HIP automation scenarios use hip-automation. Orchestration resolves the concrete group.",
    }
    return data


def _interface_definition_for_existing(root: Path, interface_type: str, fallback_key: str) -> Tuple[str, Dict[str, Any]]:
    """Resolve a registry key/definition from an already-approved TP interface_type."""
    value = _clean(interface_type).lower().replace("_", "-")
    if value:
        for key, definition in registry(root).items():
            aliases = {
                _clean(key).lower().replace("_", "-"),
                _clean(definition.get("displayName")).lower().replace("_", "-"),
                _clean(definition.get("apiInterfaceType")).lower().replace("_", "-"),
            }
            if value in aliases:
                return key, definition
        # Common human/API spelling aliases.
        squashed = value.replace(" ", "").replace("-", "")
        alias_map = {
            "sftpserver": "SFTP Server",
            "sftphaft": "SFTP",
            "sftp": "SFTP",
            "ftp": "FTP",
            "https": "HTTPS",
            "httpsas2": "HTTPS-AS2",
            "as2": "HTTPS-AS2",
            "nas": "NAS",
            "rabbitmq": "Rabbit MQ",
            "rabbit": "Rabbit MQ",
        }
        key = alias_map.get(squashed)
        if key:
            return key, get_interface(root, key)
    return fallback_key, get_interface(root, fallback_key)


def _dict_items(value: Any) -> List[Dict[str, Any]]:
    if isinstance(value, dict):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def apply_selected_interfaces(
    root: Path,
    canonical: Dict[str, Any],
    source_interface: str,
    target_interface: str | None = None,
    *,
    preserve_existing: bool = False,
) -> Dict[str, Any]:
    """Apply interface contracts without destroying approved JSON structure.

    ``preserve_existing=True`` is used for an uploaded canonical/approved
    input.json.  In that mode, an existing ``interface_type`` is authoritative;
    the UI's new-card default only fills missing values.  Dict and list-shaped
    transport/configure sections are both supported so multi-branch inputs are
    not collapsed to a single object.
    """
    root = Path(root)
    data = force_hip_automation(canonical)
    target_interface = target_interface or source_interface
    objects = data.setdefault("objects", {})
    biz = objects.setdefault("biz_flow", {})
    audit_rows: List[Dict[str, Any]] = []

    for side, selected_key in (("source", source_interface), ("target", target_interface)):
        tp_key = f"{side}_transport_profile"
        current_tp = objects.get(tp_key)
        if not isinstance(current_tp, (dict, list)):
            current_tp = {}
            objects[tp_key] = current_tp
        tp_items = _dict_items(current_tp)
        if not tp_items and isinstance(current_tp, dict):
            tp_items = [current_tp]

        resolved_keys: List[str] = []
        for tp in tp_items:
            existing_type = _clean(tp.get("interface_type"))
            if preserve_existing and existing_type:
                effective_key, definition = _interface_definition_for_existing(root, existing_type, selected_key)
                source_of_value = "approved input.json"
            else:
                effective_key, definition = selected_key, get_interface(root, selected_key)
                tp["interface_type"] = definition.get("apiInterfaceType") or selected_key
                source_of_value = "user_interface_selection"
            resolved_keys.append(effective_key)
            tp["deployment_group"] = DEFAULT_DEPLOYMENT_GROUP

            supplied = tp.get("interface_parameters") if isinstance(tp.get("interface_parameters"), dict) else {}
            params = materialize_parameters(definition, side, supplied)
            api_type = str(definition.get("apiInterfaceType") or tp.get("interface_type") or "").upper()
            if params or api_type not in {"SFTP", "SFTP HAFT", "FTP"}:
                tp["interface_parameters"] = params
            audit_rows.append({
                "side": side,
                "selected": selected_key,
                "effective": effective_key,
                "interface_type": tp.get("interface_type"),
                "source": source_of_value,
            })

        flow_name = "configure_source" if side == "source" else "configure_targets"
        flow_key = "source_transport_profile" if side == "source" else "target_transport_profile"
        flow_val = biz.get(flow_name)
        if not isinstance(flow_val, (dict, list)):
            flow_val = {}
            biz[flow_name] = flow_val
        flow_items = _dict_items(flow_val)
        if not flow_items and isinstance(flow_val, dict):
            flow_items = [flow_val]

        # Fill a shared-profile reference only when missing.  For a list-shaped
        # multi-branch flow, pair by index where possible; never collapse lists.
        for idx, flow_cfg in enumerate(flow_items):
            if _clean(flow_cfg.get(flow_key)):
                continue
            effective_key = resolved_keys[min(idx, len(resolved_keys) - 1)] if resolved_keys else selected_key
            definition = get_interface(root, effective_key)
            shared = _clean(definition.get(f"{side}SharedProfile"))
            if shared:
                flow_cfg[flow_key] = shared

    data.setdefault("_builder_audit", {})["interface_selection"] = {
        "source": source_interface,
        "target": target_interface,
        "preserveExistingApprovedInterface": bool(preserve_existing),
        "items": audit_rows,
        "source_of_value": "approved input.json when present; otherwise user interface selection",
    }
    return force_hip_automation(data)


def _first_nonempty(*values: Any) -> Any:
    for value in values:
        if isinstance(value, str):
            if value.strip():
                return value.strip()
        elif value not in (None, [], {}):
            return value
    return ""


def enrich_provable_values(root: Path, canonical: Dict[str, Any], source_interface: str, target_interface: str | None = None) -> Dict[str, Any]:
    """Fill values that are already provable from the uploaded configuration.

    This intentionally does *not* invent credentials or secrets.  It only
    converges duplicate/aliased values already present in input.json, routing
    conditions, Biz Flow configuration, or the Dev-approved shared UAT account
    convention used by the current SFTP/FTP automation path.
    """
    root = Path(root)
    data = deepcopy(canonical or {})
    target_interface = target_interface or source_interface
    objects = data.setdefault("objects", {})
    biz = objects.setdefault("biz_flow", {})
    audit = data.setdefault("_builder_audit", {}).setdefault("auto_resolved", [])

    def set_if_blank(path: str, value: Any, source: str, reason: str) -> None:
        if value in (None, "", [], {}) or not _missing(data, path):
            return
        _set_flattened_path(data, path, deepcopy(value))
        audit.append({"path": path, "value": value, "source": source, "reason": reason})

    direction = _clean(data.get("direction") or "Outbound").lower()
    source_cfg = biz.get("configure_source") if isinstance(biz.get("configure_source"), dict) else {}
    target_cfg = biz.get("configure_targets") if isinstance(biz.get("configure_targets"), dict) else {}
    stp = objects.get("source_transport_profile") if isinstance(objects.get("source_transport_profile"), dict) else {}
    ttp = objects.get("target_transport_profile") if isinstance(objects.get("target_transport_profile"), dict) else {}

    # Alias Biz Flow application names back into TP partner/system names when an
    # approved JSON uses one representation but not the other.
    set_if_blank(
        "objects.source_transport_profile.partner_name",
        _first_nonempty(source_cfg.get("source_application"), stp.get("system_name")),
        "biz_flow.configure_source",
        "Source application is already declared by the approved Biz Flow.",
    )
    set_if_blank(
        "objects.target_transport_profile.partner_name",
        _first_nonempty(target_cfg.get("target_application"), ttp.get("system_name")),
        "biz_flow.configure_targets",
        "Target application is already declared by the approved Biz Flow.",
    )

    # Dell Application is deterministic from direction; the external UAT system
    # in the current Dev-approved examples is the shared dce-test-partner.
    if direction == "inbound":
        set_if_blank("objects.source_transport_profile.partner_name", "dce-test-partner", "dev-approved UAT convention", "Inbound source is the external Partner system.")
        set_if_blank("objects.target_transport_profile.partner_name", "AIC - DCE", "direction rule", "Inbound target is the Dell Application.")
        set_if_blank("objects.source_transport_profile.system_type", "Partner", "direction rule", "Inbound source is external Partner.")
        set_if_blank("objects.target_transport_profile.system_type", "Dell Application", "direction rule", "Inbound target is Dell Application.")
    else:
        set_if_blank("objects.source_transport_profile.partner_name", "AIC - DCE", "direction rule", "Outbound source is the Dell Application.")
        set_if_blank("objects.target_transport_profile.partner_name", "dce-test-partner", "dev-approved UAT convention", "Outbound target is the external Partner system.")
        set_if_blank("objects.source_transport_profile.system_type", "Dell Application", "direction rule", "Outbound source is Dell Application.")
        set_if_blank("objects.target_transport_profile.system_type", "Partner", "direction rule", "Outbound target is external Partner.")

    # Copy/create the matching Biz Flow application aliases after TP convergence.
    stp = objects.get("source_transport_profile") or {}
    ttp = objects.get("target_transport_profile") or {}
    set_if_blank("objects.biz_flow.configure_source.source_application", stp.get("partner_name"), "source_transport_profile", "Reuse the already-resolved source application name.")
    set_if_blank("objects.biz_flow.configure_targets.target_application", ttp.get("partner_name"), "target_transport_profile", "Reuse the already-resolved target application name.")

    # Shared UAT SFTP/FTP accounts are Dev-approved constants already used by
    # U-HAUL and LEGRAND approved configurations.  Do not ask for them again.
    for side, interface_key, account in (
        ("source", source_interface, "haftatap10251594"),
        ("target", target_interface, "haftatap10251593"),
    ):
        try:
            definition = get_interface(root, interface_key)
            api_type = str(definition.get("apiInterfaceType") or interface_key).upper()
        except Exception:
            api_type = str(interface_key or "").upper()
        if api_type in {"SFTP", "SFTP HAFT", "FTP"}:
            set_if_blank(
                f"objects.{side}_transport_profile.existing_account_name",
                account,
                "dev-approved shared UAT account",
                f"{side.title()} file-transfer account is the approved shared HIP automation account.",
            )

    # Source subscription path has an explicit naming convention: /<TP name>.
    # This is safe because it is a pure transformation of a value already in the
    # approved configuration. Target paths are not synthesized because customer
    # conventions such as /Inbound/ASN vs /Outbound/ASN vary by interface.
    source_profile = _clean(_get(data, "objects.source_transport_profile.profile_name"))
    if source_profile:
        set_if_blank(
            "objects.source_transport_profile.subscription_folder",
            "/" + source_profile.lstrip("/"),
            "transport-profile naming convention",
            "Source subscription folder follows /<source Transport Profile name>.",
        )

    # Deliberately do not derive Partner Create identity from Sender/Receiver
    # routing evidence. The one deterministic UAT mapping supplied by the Dev
    # team is dce-test-partner -> DUNS 12345666, so it is safe to materialize
    # that identity when the approved configuration explicitly names the shared
    # partner system. This is partner-system evidence, never XML ROUTING evidence.
    external_tp = stp if direction == "inbound" else ttp
    external_app = _clean(
        (external_tp.get("partner_name") if isinstance(external_tp, dict) else "")
        or (external_tp.get("system_name") if isinstance(external_tp, dict) else "")
        or (source_cfg.get("source_application") if direction == "inbound" else target_cfg.get("target_application"))
    )
    if external_app.lower() == "dce-test-partner":
        set_if_blank(
            "partner_identifier_value",
            "12345666",
            "dev-approved dce-test-partner identity mapping",
            "DUNS 12345666 belongs to HIP partner dce-test-partner; routing Sender/Receiver values remain separate.",
        )

    # Standard interface/profile aliases used by legacy and React paths.
    stp = objects.get("source_transport_profile") or {}
    ttp = objects.get("target_transport_profile") or {}
    set_if_blank("objects.source_transport_profile.system_name", stp.get("partner_name"), "transport profile alias", "system_name and partner_name represent the same bound application.")
    set_if_blank("objects.target_transport_profile.system_name", ttp.get("partner_name"), "transport profile alias", "system_name and partner_name represent the same bound application.")

    return force_hip_automation(data)


def _add_question(out: List[Dict[str, Any]], canonical: Dict[str, Any], *, path: str, label: str, why: str,
                  answer_type: str = "text", secret: bool = False, options: List[str] | None = None,
                  required: bool = True, runtime_key: str = "") -> None:
    if required and not _missing(canonical, path):
        return
    out.append({
        "id": path.replace(".", "__").replace(" ", "_").replace("[", "_").replace("]", ""),
        "path": path,
        "label": label,
        "question": f"What should I use for {label}?",
        "why": why,
        "type": answer_type,
        "secret": secret,
        "options": options or [],
        "current": _get(canonical, path),
        "runtime_key": runtime_key,
    })


def unresolved_questions(root: Path, canonical: Dict[str, Any], source_interface: str, target_interface: str | None = None) -> List[Dict[str, Any]]:
    root = Path(root)
    target_interface = target_interface or source_interface
    data = enrich_provable_values(root, canonical, source_interface, target_interface)
    out: List[Dict[str, Any]] = []

    _add_question(out, data, path="customer", label="customer / partner business name", why="Needed for customer context, generated names and audit.")
    _add_question(out, data, path="tx_code", label="transaction code", why="Needed to validate document and flow metadata.")
    _add_question(out, data, path="tx_name", label="transaction name", why="Used in business flow descriptions and audit context.")
    _add_question(out, data, path="direction", label="flow direction", why="Business direction cannot always be proven from the payload alone.", answer_type="select", options=["Inbound", "Outbound"])
    _add_question(out, data, path="profile_name", label="business flow name", why="Required by Flow Orchestration.")

    _add_question(out, data, path="objects.source_document_type.name", label="source Document Type name", why="Required for Document Type and Flow APIs.")
    _add_question(out, data, path="objects.source_document_type.data_format_type", label="source Document Type data format", why="This must match the physical source file actually uploaded; the agent will not infer EDI from a transaction code.", answer_type="select", options=["XML", "cXML", "EDIX12", "EDIFACT", "CSV", "JSON", "FlatFile"])
    _add_question(out, data, path="objects.source_document_type.document_identifier.rows", label="source document identifier rows", why="A root/document identifier is required for the source Document Type.", answer_type="json")
    _add_question(out, data, path="objects.source_transport_profile.profile_name", label="source Transport Profile name", why="Required by Transport Profile Orchestration.")
    _add_question(out, data, path="objects.source_transport_profile.partner_name", label="source application/system name", why="Required to bind the source Transport Profile.")
    _add_question(out, data, path="objects.target_transport_profile.profile_name", label="target Transport Profile name", why="Required by Transport Profile Orchestration.")
    _add_question(out, data, path="objects.target_transport_profile.partner_name", label="target partner/system name", why="Required to bind the target Transport Profile and Flow target.")
    _add_question(out, data, path="partner_identifier_value", label="target partner identifier (DUNS/value approved by Dev contract)", why="Partner Create must not invent a partner identifier for a live customer.")

    is_translation = bool(data.get("requires_data_map")) or str(data.get("flow_type") or "").lower() == "translation"
    separate_passthrough_target = bool(data.get("passthrough_target_document_type_required")) and not is_translation
    if is_translation or separate_passthrough_target:
        why_name = "Translation flows require a target Document Type." if is_translation else "This Passthrough flow explicitly enables the separate-target exception."
        why_id = "Translation target requires a document identifier." if is_translation else "The explicitly enabled Passthrough target requires its own document identifier."
        _add_question(out, data, path="objects.target_document_type.name", label="target Document Type name", why=why_name)
        _add_question(out, data, path="objects.target_document_type.data_format_type", label="target Document Type data format", why="This must match the physical target file actually uploaded.", answer_type="select", options=["XML", "cXML", "EDIX12", "EDIFACT", "CSV", "JSON", "FlatFile"])
        _add_question(out, data, path="objects.target_document_type.document_identifier.rows", label="target document identifier rows", why=why_id, answer_type="json")
    if is_translation:
        _add_question(out, data, path="objects.data_map.map_identifier", label="Data Map identifier", why="Translation requires an approved map identifier.")
        _add_question(out, data, path="objects.data_map.map_name", label="Data Map name", why="Translation requires the map metadata.")
        _add_question(out, data, path="objects.data_map.map_data_file", label="approved mapping JAR filename", why="The agent will not invent the executable mapping artifact.")
        _add_question(out, data, path="objects.rule.name", label="Mapping Rule name", why="Translation requires the mapping rule reference.")

    for side, interface_key in (("source", source_interface), ("target", target_interface)):
        definition = get_interface(root, interface_key)
        tp_path = f"objects.{side}_transport_profile"
        tp = _get(data, tp_path) or {}
        api_type = str(definition.get("apiInterfaceType") or "").upper()
        # Account Create and Partner headers are part of the standard 18-API
        # orchestration for every interface. Never inherit a U-HAUL account for
        # a new customer simply because HTTPS/AS2 does not use an SFTP folder.
        _add_question(out, data, path=f"{tp_path}.existing_account_name", label=f"{side} HIP account name", why="The Account/Partner APIs require the customer/environment account identity; it cannot be safely inferred from payload samples.")
        if api_type in {"SFTP", "SFTP HAFT", "FTP"}:
            _add_question(out, data, path=f"{tp_path}.subscription_folder", label=f"{side} subscription/folder path", why="Production folder paths must be confirmed when artifacts do not prove them.")

        # Dev-team HTTPS-AS2 contract supplied 2026-09-02 uses certificate
        # attributes by name/value, not certificate-ID attributes. Ask only on
        # the external-partner side and never invent a certificate value.
        direction = str(data.get("direction") or "Outbound").strip().lower()
        partner_side = "source" if direction == "inbound" else "target"
        if side == partner_side and api_type == "HTTPS-AS2":
            cert_fields = ["Partner Verification Certificate"] if side == "source" else ["Encryption Certificate", "SSL Certificate"]
            for cert_field in cert_fields:
                _add_question(
                    out, data,
                    path=f"{tp_path}.interface_parameters.{cert_field}",
                    label=f"{side} {cert_field}",
                    why="Dev-approved HTTPS-AS2 interfaceDetails requires this certificate value. The agent cannot invent it; provide the approved customer/Dev value.",
                )

        params = tp.get("interface_parameters") if isinstance(tp, dict) and isinstance(tp.get("interface_parameters"), dict) else {}
        flow_path = "objects.biz_flow.configure_source" if side == "source" else "objects.biz_flow.configure_targets"
        flow_cfg = _get(data, flow_path) or {}
        shared_key = "source_transport_profile" if side == "source" else "target_transport_profile"
        shared = _clean(flow_cfg.get(shared_key)) if isinstance(flow_cfg, dict) else ""
        for item in missing_values(
            definition, side, params, shared,
            system_type=tp.get("system_type") if isinstance(tp, dict) else "",
            profile_usage=tp.get("profile_usage") if isinstance(tp, dict) else ("Sender" if side == "source" else "Receiver"),
        ):
            field = item.get("field") or ""
            if field == f"{side}Parameters":
                out.append({
                    "id": f"{side}_interface_parameters", "path": f"{tp_path}.interface_parameters",
                    "label": f"approved {side} interface parameters", "question": item.get("question"),
                    "why": item.get("why"), "type": "json", "secret": False, "options": [], "current": params,
                })
            elif field == f"{side}SharedProfile":
                out.append({
                    "id": f"{side}_shared_profile", "path": f"{flow_path}.{shared_key}",
                    "label": f"{side} shared Flow Transport Profile", "question": item.get("question"),
                    "why": item.get("why"), "type": "text", "secret": False, "options": [], "current": shared,
                })
            else:
                sensitive = field in (definition.get(f"{side}SensitiveFields") or []) or "secret" in field.lower()
                safe_key = re.sub(r"[^a-z0-9]+", "_", field.lower()).strip("_")
                out.append({
                    "id": f"{side}_param_{safe_key}", "path": f"{tp_path}.interface_parameters.{field}",
                    "label": f"{side} {field}", "question": item.get("question"), "why": item.get("why"),
                    "type": "password" if sensitive else "text", "secret": sensitive, "options": [],
                    "current": "" if sensitive else params.get(field), "runtime_key": f"builder.{side}.{safe_key}",
                })

    existing_review = set((data.get("_builder_audit") or {}).get("confirmed_reviews") or [])
    for raw in data.get("missing_fields") or []:
        if isinstance(raw, dict):
            field = _clean(raw.get("field"))
            label = _clean(raw.get("label")) or field
            why = _clean(raw.get("why")) or "The standalone input builder could not determine this value."
            version_paths = {
                "source_document_type_version": "objects.source_document_type.version",
                "target_document_type_version": "objects.target_document_type.version",
                "map_identifier_version": "objects.data_map.map_identifier_version",
                "rule_version": "objects.rule.version",
                "flow_version": "objects.biz_flow.flow_details.current_flow_version",
            }
            if field in version_paths:
                path = version_paths[field]
                if _missing(data, path):
                    out.append({
                        "id": f"builder_{field}", "path": path, "label": label,
                        "question": f"What should I use for {label}?", "why": why,
                        "type": "text", "secret": False, "options": [], "current": _get(data, path) or "",
                    })
                continue
            if field == "partner_id":
                current = _get(data, "objects.biz_flow.flow_identifiers.conditions[0].value")
                if not _clean(current):
                    out.append({
                        "id": "builder_partner_id", "path": "", "multi_paths": [
                            "objects.rule.conditions.rows[0].value",
                            "objects.biz_flow.flow_identifiers.conditions[0].value",
                            "objects.biz_flow.configure_routing.conditions.rows[0].value",
                        ],
                        "label": label, "question": f"What should I use for {label}?", "why": why,
                        "type": "text", "secret": False, "options": [], "current": current,
                    })
                continue
            if field == "isa_sender_id":
                out.append({
                    "id": "builder_isa_sender_id", "path": "",
                    "multi_paths": ["objects.target_document_type.attributes_to_configure[1].value"],
                    "label": label, "question": f"What should I use for {label}?", "why": why,
                    "type": "text", "secret": False, "options": [], "current": "",
                })
                continue
            if field == "isa_receiver_id":
                out.append({
                    "id": "builder_isa_receiver_id", "path": "",
                    "multi_paths": ["objects.target_document_type.attributes_to_configure[0].value"],
                    "label": label, "question": f"What should I use for {label}?", "why": why,
                    "type": "text", "secret": False, "options": [], "current": "",
                })
                continue
            # map/customer gaps already have path-backed questions above; avoid duplicates.
            if field in {"map_name", "map_class", "map_data_file", "customer"}:
                continue
            text = label
        else:
            text = _clean(raw)
            why = "The standalone input builder marked this as unresolved or requiring business approval."
        if text and text not in existing_review:
            out.append({
                "id": f"review_{len(out)}", "path": "", "label": text,
                "question": f"Please review/confirm: {text}", "why": why,
                "type": "confirmation", "secret": False, "options": ["Confirmed"], "current": "",
                "informational": True,
            })
    return out


def _interface_key_for_answer(value: Any, fallback: str) -> str:
    text = str(value or "").strip().upper().replace("_", "-")
    if "SFTP SERVER" in text or "SFTP-SERVER" in text:
        return "SFTP Server"
    if "AS2" in text:
        return "HTTPS-AS2"
    if text in {"HTTPS", "REST", "HTTP"} or "HTTPS" in text:
        return "HTTPS"
    if text == "NAS" or text.startswith("NAS "):
        return "NAS"
    if "RABBIT" in text:
        return "Rabbit MQ"
    if text.startswith("FTP"):
        return "FTP"
    if text.startswith("FTE"):
        return "FTE"
    if "SFTP" in text or "HAFT" in text:
        return "SFTP"
    return str(fallback or value or "SFTP")


def apply_answers(root: Path, canonical: Dict[str, Any], questions: List[Dict[str, Any]], answers: Dict[str, Any], source_interface: str, target_interface: str | None = None) -> Tuple[Dict[str, Any], List[str]]:
    data = deepcopy(canonical)
    applied: List[str] = []
    conflict_resolutions: List[Dict[str, Any]] = []
    resolved_conflict_ids: set[str] = set()
    confirmed_reviews = set((data.get("_builder_audit") or {}).get("confirmed_reviews") or [])
    for q in questions:
        qid = q.get("id")
        if qid not in answers:
            continue
        value = answers.get(qid)
        if value in (None, "", []):
            continue
        if q.get("informational"):
            label = str(q.get("label") or qid)
            confirmed_reviews.add(label)
            applied.append(label)
            continue
        path = str(q.get("path") or "")
        if q.get("secret"):
            runtime_key = str(q.get("runtime_key") or f"builder.{qid}")
            save_runtime_payload_value(Path(root), runtime_key, value)
            value = placeholder(runtime_key)
        paths = list(q.get("multi_paths") or [])
        if path:
            paths.insert(0, path)
        for target_path in paths:
            _set_flattened_path(data, target_path, value)
            if target_path == "flow_type":
                data["requires_data_map"] = str(value).strip().lower() == "translation"
            applied.append(target_path)
        if str(q.get("type") or "") == "conflict":
            conflict = q.get("conflict") if isinstance(q.get("conflict"), dict) else {}
            selected_field = str(conflict.get("selectedField") or "")
            if selected_field == "source_interface":
                source_interface = _interface_key_for_answer(value, source_interface)
            elif selected_field == "target_interface":
                target_interface = _interface_key_for_answer(value, target_interface or source_interface)
            file_values = list(conflict.get("fileValues") or [])
            selected_value = conflict.get("selectedValue")
            chosen_norm = str(value).strip().casefold()
            file_norms = {str(v).strip().casefold() for v in file_values}
            selected_norm = str(selected_value).strip().casefold()
            if chosen_norm in file_norms:
                chosen_source = "customer_file"
            elif selected_norm and chosen_norm == selected_norm:
                chosen_source = "user_selected"
            else:
                chosen_source = "custom_user_value"
            resolved_conflict_ids.add(str(qid))
            conflict_resolutions.append({
                "id": str(qid), "path": path, "chosenValue": value, "chosenSource": chosen_source,
                "fileValues": file_values, "fileSources": list(conflict.get("fileSources") or []),
                "selectedValue": selected_value, "selectedField": conflict.get("selectedField") or "",
            })

    if resolved_conflict_ids:
        data["_selection_conflicts"] = [
            c for c in (data.get("_selection_conflicts") or [])
            if not isinstance(c, dict) or str(c.get("id") or "") not in resolved_conflict_ids
        ]

    data = normalize_input_json(
        data, customer=_clean(data.get("customer")), folder_name=_clean(data.get("folder")),
        direction=_clean(data.get("direction")), flow_type=_clean(data.get("flow_type")),
    )
    data = apply_selected_interfaces(Path(root), data, source_interface, target_interface)
    audit = data.setdefault("_builder_audit", {})
    audit["confirmed_reviews"] = sorted(confirmed_reviews)
    previous_human = audit.get("human_answers") if isinstance(audit.get("human_answers"), dict) else {}
    previous_paths = [str(x) for x in (previous_human.get("paths") or [])]
    merged_paths = list(dict.fromkeys(previous_paths + [str(x) for x in applied]))
    audit["human_answers"] = {"count": len(merged_paths), "paths": merged_paths, "source": "human_confirmation", "lastAppliedPaths": list(applied)}
    if conflict_resolutions:
        previous_conflicts = audit.get("selection_conflict_resolutions") if isinstance(audit.get("selection_conflict_resolutions"), list) else []
        audit["selection_conflict_resolutions"] = previous_conflicts + conflict_resolutions
        audit["selection_conflict_policy"] = "Resolved explicitly by operator; no silent file-vs-UI precedence."
    return force_hip_automation(data), applied


def load_answer_memory(root: Path, customer: str, source_interface: str, target_interface: str) -> Dict[str, Any]:
    path = Path(root) / MEMORY_FILE
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    key = f"{_clean(customer).upper()}|{source_interface}|{target_interface}"
    value = raw.get(key) if isinstance(raw, dict) else None
    return deepcopy(value) if isinstance(value, dict) else {}


def save_answer_memory(root: Path, customer: str, source_interface: str, target_interface: str, questions: List[Dict[str, Any]], answers: Dict[str, Any]) -> None:
    safe: Dict[str, Any] = {}
    by_id = {q.get("id"): q for q in questions}
    for key, value in answers.items():
        q = by_id.get(key) or {}
        if q.get("secret") or q.get("informational") or value in (None, ""):
            continue
        safe[key] = value
    if not safe or not _clean(customer):
        return
    path = Path(root) / MEMORY_FILE
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        raw = {}
    if not isinstance(raw, dict):
        raw = {}
    key = f"{_clean(customer).upper()}|{source_interface}|{target_interface}"
    raw[key] = safe
    path.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")


# Safe canonical paths that may be populated from a user's explicit natural-language
# request.  Secrets/credentials and deployment-group fields are intentionally absent.
_USER_REQUEST_SAFE_PATHS = {
    "customer", "direction", "flow_type", "tx_standard", "tx_code", "tx_name",
    "profile_name", "partner_identifier_value", "passthrough_target_document_type_required",
    "objects.source_document_type.name", "objects.target_document_type.name",
    "objects.data_map.map_identifier", "objects.data_map.map_name", "objects.data_map.map_class",
    "objects.data_map.map_data_file", "objects.data_map.contivo_version", "objects.rule.name",
    "objects.source_transport_profile.profile_name", "objects.target_transport_profile.profile_name",
    "objects.source_transport_profile.partner_name", "objects.target_transport_profile.partner_name",
    "objects.source_transport_profile.existing_account_name", "objects.target_transport_profile.existing_account_name",
    "objects.source_transport_profile.subscription_folder", "objects.target_transport_profile.subscription_folder",
}


def _request_set(data: Dict[str, Any], audit: List[Dict[str, Any]], path: str, value: Any,
                 *, source: str = "user_request", reason: str = "explicit user instruction") -> None:
    if path not in _USER_REQUEST_SAFE_PATHS or value in (None, ""):
        return
    _set_flattened_path(data, path, deepcopy(value))
    audit.append({"path": path, "value": value, "source": source, "reason": reason})


def apply_user_request_hints(root: Path, canonical: Dict[str, Any], request_text: str,
                             *, use_aia: bool = True) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Apply explicit user instructions as an audited input.json source.

    Deterministic patterns are applied first. Dell AIA may then map additional
    explicitly-stated values, but only on a strict allow-list and only at high
    confidence.  Unknown/ambiguous values remain questions; no secrets, runtime
    IDs, credentials or deployment-group overrides are accepted here.
    """
    data = deepcopy(canonical or {})
    text = str(request_text or "").strip()
    audit_rows: List[Dict[str, Any]] = []
    questions: List[str] = []
    if not text:
        return force_hip_automation(data), {"request": "", "applied": [], "questions": []}

    lower = text.lower()

    # Flow type: explicit user statement wins over artifact heuristics.
    has_pass = bool(re.search(r"\bpass\s*-?\s*through\b|\bpassthrough\b|\bpassthru\b", lower))
    has_trans = bool(re.search(r"\btranslation\b|\bmapping\s+flow\b", lower))
    if has_pass and not has_trans:
        _request_set(data, audit_rows, "flow_type", "passthrough")
    elif has_trans and not has_pass:
        _request_set(data, audit_rows, "flow_type", "translation")

    # Explicit Passthrough exception for a separate target Document Type.
    # Negative wording must be evaluated first because "no separate target"
    # also contains the positive phrase "separate target".
    if re.search(r"(?:no|without)\s+(?:separate\s+)?target\s+document\s+type", lower):
        _request_set(data, audit_rows, "passthrough_target_document_type_required", False)
    elif re.search(r"(?:separate|new|distinct)\s+target\s+document\s+type", lower):
        _request_set(data, audit_rows, "passthrough_target_document_type_required", True)

    if re.search(r"\binbound\b", lower) and not re.search(r"\boutbound\b", lower):
        _request_set(data, audit_rows, "direction", "Inbound")
    elif re.search(r"\boutbound\b", lower) and not re.search(r"\binbound\b", lower):
        _request_set(data, audit_rows, "direction", "Outbound")

    def grab(pattern: str, flags: int = re.I) -> str:
        m = re.search(pattern, text, flags=flags)
        return (m.group(1).strip().strip('"\'').rstrip(".,;") if m else "")

    value = grab(r"(?:customer(?:\s+name)?|partner\s+customer)\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        _request_set(data, audit_rows, "customer", value)

    value = grab(r"(?:duns(?:\s*number)?|partner\s*identifier(?:\s*value)?)\s*(?:is|=|:|to)?\s*[\"']?([A-Za-z0-9_.:-]+)")
    if value:
        _request_set(data, audit_rows, "partner_identifier_value", value)

    value = grab(r"(?:transaction\s*(?:code|type)|tx\s*code)\s*(?:is|=|:|to)?\s*[\"']?([A-Za-z0-9_.-]+)")
    if value:
        _request_set(data, audit_rows, "tx_code", value)

    value = grab(r"(?:business\s*flow|flow)\s+name\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        _request_set(data, audit_rows, "profile_name", value)

    for side in ("source", "target"):
        value = grab(rf"{side}\s+(?:hip\s+)?account(?:\s+name)?\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
        if value:
            _request_set(data, audit_rows, f"objects.{side}_transport_profile.existing_account_name", value)
        value = grab(rf"{side}\s+(?:subscription\s+)?folder(?:\s+path)?\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
        if value:
            _request_set(data, audit_rows, f"objects.{side}_transport_profile.subscription_folder", value)
        value = grab(rf"{side}\s+transport\s+profile(?:\s+name)?\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
        if value:
            _request_set(data, audit_rows, f"objects.{side}_transport_profile.profile_name", value)
        value = grab(rf"{side}\s+document\s+type(?:\s+name)?\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
        if value:
            _request_set(data, audit_rows, f"objects.{side}_document_type.name", value)

    value = grab(r"(?:mapping\s+jar|map\s+jar|jar\s+file)\s*(?:is|=|:|to)?\s*[\"']?([^\n,; ]+\.jar)")
    if value:
        _request_set(data, audit_rows, "objects.data_map.map_data_file", value)
    value = grab(r"(?:map\s+name)\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        _request_set(data, audit_rows, "objects.data_map.map_name", value)
    value = grab(r"(?:map\s+identifier)\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        _request_set(data, audit_rows, "objects.data_map.map_identifier", value)
    value = grab(r"(?:mapping\s+rule|rule)\s+name\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        _request_set(data, audit_rows, "objects.rule.name", value)

    # External partner application is direction-aware.
    value = grab(r"(?:external|customer|partner)\s+(?:partner\s+)?(?:application|system)(?:\s+name)?\s*(?:is|=|:|to)?\s*[\"']?([^\n,;.]+)")
    if value:
        direction = str(data.get("direction") or "Outbound").strip().lower()
        side = "source" if direction == "inbound" else "target"
        _request_set(data, audit_rows, f"objects.{side}_transport_profile.partner_name", value)

    # Dell AIA can parse additional explicit request values, but it cannot invent
    # them. Only high-confidence, allow-listed paths are applied.
    aia_result: Dict[str, Any] = {}
    if use_aia:
        try:
            from input_builder_aia_adapter import extract_user_request_patch
            aia_result = extract_user_request_patch(text, data) or {}
            for item in aia_result.get("changes") or []:
                path = str(item.get("path") or "").strip()
                value = item.get("value")
                try:
                    confidence = float(item.get("confidence", 0) or 0)
                except Exception:
                    confidence = 0.0
                if path in _USER_REQUEST_SAFE_PATHS and confidence >= 0.90 and value not in (None, ""):
                    # Deployment group is not in the allow-list; secrets are not in it either.
                    _request_set(data, audit_rows, path, value, source="user_request+dell_aia", reason=str(item.get("reason") or "explicit request mapping"))
            questions.extend(str(x) for x in (aia_result.get("questions") or []) if str(x).strip())
        except Exception as exc:
            aia_result = {"note": f"{type(exc).__name__}: {exc}"}

    # Re-run canonical policy after request changes. This is what makes a user
    # request such as "Passthrough" remove the synthetic target/map/rule objects.
    normalized = normalize_input_json(
        data,
        customer=str(data.get("customer") or ""),
        direction=str(data.get("direction") or ""),
        flow_type=str(data.get("flow_type") or ""),
    )
    normalized = force_hip_automation(normalized)
    normalized.setdefault("_builder_audit", {})["user_request"] = {
        "request": text,
        "applied": audit_rows,
        "questions": questions,
        "aia": {k: v for k, v in aia_result.items() if k != "changes"},
        "source": "explicit_user_request",
    }
    return normalized, normalized["_builder_audit"]["user_request"]
