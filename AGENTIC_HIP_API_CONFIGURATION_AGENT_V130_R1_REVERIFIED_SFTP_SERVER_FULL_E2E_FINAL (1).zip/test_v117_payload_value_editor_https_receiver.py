from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

from payload_overrides import PayloadOverrideStore, save_override, clear_override
from run_agent import Runner, BUILD_ID
from webapp.backend.app.main import _sync_linked_identity_value, _value_leaf_diffs, _exact_same_structure

ROOT = Path(__file__).resolve().parent


def test_path_mode_edits_only_one_value_and_preserves_siblings(tmp_path: Path):
    # Seed enough workspace information for canonical interface-family detection.
    (tmp_path / "input.json").write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    save_override(
        tmp_path,
        "source_tp",
        {"transportProfileDetails.0.transportProfileName": "SFTP_CUSTOM_SRC"},
        request_kind="payload",
        mode="paths",
        note="rename source TP",
        edit_origin="USER",
    )
    base = Runner(llm_enabled=False).preview_step_request("source_tp")
    factory = {"payload": deepcopy(base["generatedPayload"])}
    effective, meta = PayloadOverrideStore(tmp_path).apply("source_tp", factory, {})
    assert meta["applied"] is True
    assert effective["payload"]["transportProfileDetails"][0]["transportProfileName"] == "SFTP_CUSTOM_SRC"
    assert effective["payload"]["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"
    assert effective["payload"]["operation"] == base["generatedPayload"]["operation"]


def test_path_mode_rejects_unknown_structure(tmp_path: Path):
    (tmp_path / "input.json").write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    with pytest.raises(ValueError, match="Unknown/non-leaf paths"):
        save_override(tmp_path, "source_tp", {"transportProfileDetails.0.NOT_APPROVED": "x"}, request_kind="payload", mode="paths", edit_origin="USER")


def test_full_editor_requires_exact_structure_and_computes_leaf_diffs():
    before = {"a": 1, "b": {"x": "old"}, "rows": [{"name": "A", "id": 1}]}
    edited = {"a": 1, "b": {"x": "new"}, "rows": [{"name": "B", "id": 1}]}
    assert _exact_same_structure(before, edited) is True
    assert _value_leaf_diffs(before, edited) == {"b.x": "new", "rows.0.name": "B"}
    assert _exact_same_structure(before, {"a": 1, "b": {"x": "new", "y": 2}, "rows": before["rows"]}) is False


def test_source_tp_identity_edit_syncs_canonical_input_and_audit_name(tmp_path: Path, monkeypatch):
    input_path = tmp_path / "input.json"
    input_path.write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    source_payload = Runner(llm_enabled=False).preview_step_request("source_tp")["generatedPayload"]
    edited = deepcopy(source_payload)
    edited["transportProfileDetails"][0]["transportProfileName"] = "SFTP_LEGRAND_NEW_SRC"
    sync = _sync_linked_identity_value(tmp_path, "source_tp", edited)
    assert sync and sync[0]["after"] == "SFTP_LEGRAND_NEW_SRC"
    canonical = json.loads(input_path.read_text(encoding="utf-8"))
    assert canonical["objects"]["source_transport_profile"]["profile_name"] == "SFTP_LEGRAND_NEW_SRC"


def test_target_tp_identity_edit_syncs_canonical_input(tmp_path: Path):
    input_path = tmp_path / "input.json"
    input_path.write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    target_payload = Runner(llm_enabled=False).preview_step_request("target_tp")["generatedPayload"]
    edited = deepcopy(target_payload)
    edited["transportProfileDetails"][0]["transportProfileName"] = "SFTP_LEGRAND_NEW_TGT"
    sync = _sync_linked_identity_value(tmp_path, "target_tp", edited)
    assert sync and sync[0]["after"] == "SFTP_LEGRAND_NEW_TGT"
    canonical = json.loads(input_path.read_text(encoding="utf-8"))
    assert canonical["objects"]["target_transport_profile"]["profile_name"] == "SFTP_LEGRAND_NEW_TGT"


def test_https_receiver_candidate_omits_plain_ssl_certificate_fields():
    original = (ROOT / "input.json").read_text(encoding="utf-8")
    try:
        data = json.loads(original)
        target = data["objects"]["target_transport_profile"]
        target["interface_type"] = "HTTPS"
        target["interface_parameters"] = {
            "Protocol": "REST",
            "Partner URL": "https://partner.example/api",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "https://gateway.example/api",
            "SSL Certificate": "SHOULD_BE_IGNORED",
            "Are Input Files Compressed?": "False",
            "SSL Certificate CN - Expiry": "SHOULD_BE_IGNORED",
            "Receiver Grant Type": "client_credentials",
            "Receiver Token Endpoint": "https://partner.example/oauth/token",
            "Receiver Client Id": "partner-client",
            "Receiver Client Secret": "{{runtime_payload.target.receiver_client_secret}}",
            "SSL Certificate Id": "SHOULD_BE_IGNORED",
        }
        (ROOT / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
        runner = Runner(llm_enabled=False)
        payload = runner.preview_step_request("target_tp")["payload"]
        params = payload["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
        for field in ("SSL Certificate", "SSL Certificate CN - Expiry", "SSL Certificate Id"):
            assert field not in params
        assert params["Receiver Client Id"] == "partner-client"
        assert params["Receiver Client Secret"] == "{{runtime_payload.target.receiver_client_secret}}"
        assert params["Partner URL"] == "https://partner.example/api"
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")


def test_v117_build_identity():
    assert any(tag in BUILD_ID.lower() for tag in ("v118", "v119", "v120", "v121", "v122", "v129", "v130"))
    assert "payload-value-editor" in BUILD_ID



def test_agent_or_system_saved_override_has_no_live_authority(tmp_path: Path):
    (tmp_path / "input.json").write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    base = Runner(llm_enabled=False).preview_step_request("source_tp")
    save_override(
        tmp_path,
        "source_tp",
        {"transportProfileDetails.0.transportProfileName": "AGENT_TRIED_TO_CHANGE_ME"},
        request_kind="payload",
        mode="paths",
        note="agent suggestion",
        edit_origin="AGENT",
    )
    store = PayloadOverrideStore(tmp_path)
    effective, meta = store.apply("source_tp", {"payload": deepcopy(base["generatedPayload"])}, {})
    assert effective["payload"]["transportProfileDetails"][0]["transportProfileName"] == base["generatedPayload"]["transportProfileDetails"][0]["transportProfileName"]
    assert meta["persistedOverrideIgnored"] is True
    assert meta["ignoredReason"] == "PAYLOAD_VALUE_EDIT_USER_ONLY"
    assert meta["agentEditAllowed"] is False


def test_human_user_saved_override_is_live_eligible(tmp_path: Path):
    (tmp_path / "input.json").write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    base = Runner(llm_enabled=False).preview_step_request("source_tp")
    save_override(
        tmp_path,
        "source_tp",
        {"transportProfileDetails.0.transportProfileName": "USER_CHOSEN_SOURCE_TP"},
        request_kind="payload",
        mode="paths",
        note="human user edit",
        edit_origin="USER",
    )
    store = PayloadOverrideStore(tmp_path)
    effective, meta = store.apply("source_tp", {"payload": deepcopy(base["generatedPayload"])}, {})
    assert effective["payload"]["transportProfileDetails"][0]["transportProfileName"] == "USER_CHOSEN_SOURCE_TP"
    assert meta["applied"] is True
    assert meta["editOrigin"] == "USER"
    assert meta["agentEditAllowed"] is False


def _without_interface_details(payload: dict) -> dict:
    value = deepcopy(payload)
    detail = value["transportProfileDetails"][0]
    detail["interfaceDetails"] = "<INTERFACE_DETAILS_ONLY_VARIATION>"
    return value


def test_transport_profile_outer_attributes_are_identical_for_file_and_https():
    original = (ROOT / "input.json").read_text(encoding="utf-8")
    try:
        baseline = Runner(llm_enabled=False).preview_step_request("target_tp")["generatedPayload"]
        data = json.loads(original)
        target = data["objects"]["target_transport_profile"]
        target["interface_type"] = "HTTPS"
        target["interface_parameters"] = {
            "Protocol": "REST",
            "Partner URL": "https://partner.example/api",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "https://gateway.example/api",
            "Are Input Files Compressed?": "False",
            "Receiver Grant Type": "client_credentials",
            "Receiver Token Endpoint": "https://partner.example/oauth/token",
            "Receiver Client Id": "client",
            "Receiver Client Secret": "secret",
        }
        (ROOT / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
        https_payload = Runner(llm_enabled=False).preview_step_request("target_tp")["generatedPayload"]
        assert _without_interface_details(https_payload) == _without_interface_details(baseline)
        assert baseline["transportProfileDetails"][0]["interfaceDetails"] != https_payload["transportProfileDetails"][0]["interfaceDetails"]
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")


def _request_with_headers(headers: dict[str, str]):
    from starlette.requests import Request
    raw = [(k.lower().encode(), v.encode()) for k, v in headers.items()]
    return Request({"type": "http", "method": "PUT", "path": "/", "headers": raw, "query_string": b"", "server": ("test", 80), "client": ("test", 1), "scheme": "http"})


def test_payload_edit_endpoint_requires_explicit_human_action_header():
    from fastapi import HTTPException
    from webapp.backend.app.main import _require_human_payload_edit_action
    with pytest.raises(HTTPException) as exc:
        _require_human_payload_edit_action(_request_with_headers({"X-HIP-Actor": "Human User"}))
    assert exc.value.status_code == 403


def test_payload_edit_endpoint_rejects_agent_identity_even_with_header():
    from fastapi import HTTPException
    from webapp.backend.app.main import _require_human_payload_edit_action
    with pytest.raises(HTTPException) as exc:
        _require_human_payload_edit_action(_request_with_headers({"X-HIP-Actor": "AutoGen Agent", "X-HIP-User-Action": "payload-value-edit-v1"}))
    assert exc.value.status_code == 403


def test_payload_edit_endpoint_accepts_explicit_human_action():
    from webapp.backend.app.main import _require_human_payload_edit_action
    actor = _require_human_payload_edit_action(_request_with_headers({"X-HIP-Actor": "Human User", "X-HIP-User-Action": "payload-value-edit-v1"}))
    assert actor == "Human User"


def test_human_user_can_edit_non_transport_api_value_too(tmp_path: Path):
    """Human edit authority is generic across applicable canonical APIs, not TP-only."""
    (tmp_path / "input.json").write_text((ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8")
    base = Runner(llm_enabled=False).preview_step_request("account_source")
    generated = deepcopy(base["generatedPayload"])
    # Pick an existing scalar leaf without adding/removing any field.
    editable_key = next(k for k, v in generated.items() if isinstance(v, str))
    edited_value = "USER_EDITED_VALUE"
    save_override(
        tmp_path,
        "account_source",
        {editable_key: edited_value},
        request_kind="payload",
        mode="paths",
        note="human generic value edit",
        edit_origin="USER",
    )
    effective, meta = PayloadOverrideStore(tmp_path).apply(
        "account_source", {"payload": generated}, {}
    )
    assert meta["applied"] is True
    assert effective["payload"][editable_key] == edited_value
    assert meta["agentEditAllowed"] is False


def test_agent_interface_only_mode_does_not_limit_human_payload_editor_runtime():
    """Regression: agent proposal restrictions must not be re-used to block HUMAN edits."""
    text = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert "INTERFACE_ONLY_PAYLOAD_EDIT_BLOCKED" not in text
    # The runtime MCP critic for persisted HUMAN overrides must explicitly disable
    # the agent-only interface restriction.
    assert "interface_only=False" in text


def test_transport_profile_outer_schema_is_invariant_for_every_builtin_interface():
    """SFTP/FTP/HTTPS/HTTPS-AS2 differ only inside interfaceDetails."""
    original = (ROOT / "input.json").read_text(encoding="utf-8")
    try:
        base_data = json.loads(original)
        snapshots = {"source": {}, "target": {}}
        for interface_type in ("SFTP HAFT", "FTP", "HTTPS", "HTTPS-AS2"):
            data = deepcopy(base_data)
            for side, object_key in (("source", "source_transport_profile"), ("target", "target_transport_profile")):
                tp = data["objects"][object_key]
                tp["interface_type"] = interface_type
                if interface_type == "HTTPS":
                    tp["interface_parameters"] = {
                        "Protocol": "REST",
                        "Partner URL": "https://partner.example/api",
                        "HIP URL": "https://hip.example/api",
                        "Proxy URI": "dce-common-sv1",
                        "Request Method": "POST",
                        "Request Format": "Request Body",
                        "Sender Authentication Type": "OAuth2",
                        "Receiver Authentication Type": "OAuth2",
                        "Gateway URL": "https://gateway.example/api",
                        "Are Input Files Compressed?": "False",
                        "Sender Grant Type": "client_credentials",
                        "Receiver Grant Type": "client_credentials",
                        "Receiver Token Endpoint": "https://partner.example/oauth/token",
                        "Receiver Client Id": "client",
                        "Receiver Client Secret": "secret",
                    }
                elif interface_type == "HTTPS-AS2":
                    tp["interface_parameters"] = {
                        "Request Method": "POST",
                        "Interface Environment": "UAT",
                        "Partner URL": "https://partner.example/as2",
                        "Partner Identifier": "PARTNER-AS2",
                        "Dell Identifier": "DELL-AS2",
                    }
                else:
                    tp.pop("interface_parameters", None)
            (ROOT / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
            runner = Runner(llm_enabled=False)
            for side, step in (("source", "source_tp"), ("target", "target_tp")):
                payload = runner.preview_step_request(step)["generatedPayload"]
                snapshots[side][interface_type] = payload

        for side in ("source", "target"):
            baseline = _without_interface_details(snapshots[side]["SFTP HAFT"])
            for interface_type, payload in snapshots[side].items():
                assert _without_interface_details(payload) == baseline, (side, interface_type)
            # And the interface section itself really varies.
            assert snapshots[side]["SFTP HAFT"]["transportProfileDetails"][0]["interfaceDetails"] != snapshots[side]["HTTPS"]["transportProfileDetails"][0]["interfaceDetails"]
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")


def test_generic_interface_materializer_supports_side_specific_ignored_fields():
    from interface_registry import get_interface, materialize_parameters
    definition = get_interface(ROOT, "HTTPS")
    result = materialize_parameters(definition, "target", {
        "Partner URL": "https://partner.example/api",
        "SSL Certificate": "IGNORE-ME",
        "SSL Certificate CN - Expiry": "IGNORE-ME",
        "SSL Certificate Id": "IGNORE-ME",
    })
    assert result["Partner URL"] == "https://partner.example/api"
    assert "SSL Certificate" not in result
    assert "SSL Certificate CN - Expiry" not in result
    assert "SSL Certificate Id" not in result
