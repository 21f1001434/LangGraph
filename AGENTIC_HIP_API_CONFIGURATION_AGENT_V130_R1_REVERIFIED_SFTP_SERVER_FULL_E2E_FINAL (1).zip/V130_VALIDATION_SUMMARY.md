# V130 Validation Summary — Reverified R1

Release: **V130 — SFTP Server Interface Contract**  
Revision: **R1**  
Date: **2026-09-14**

## Implemented scope

- `SFTP Server` is a distinct governed Transport Profile interface, separate from `SFTP HAFT`.
- Dell Application supports Linux/Windows; Partner supports Linux only.
- Linux Password/Key and Windows Password authentication fields are conditionally emitted.
- SSH Key mode always uses `haft_aut_sftp_server_private_key`.
- Sender-only filtering/post-transfer/polling rules are enforced.
- Rename, archive path and Cron Expression are emitted only under the Dev-supplied triggering conditions.
- Compression supports GZIP/ZIP/TAR and only emits `Compression Format` when compression is enabled.
- Partner-only EBCDIC and the Dev-approved Code Page allowlist are enforced.
- Inactive/unknown SFTP Server fields are pruned again at the governed HTTP boundary after human overrides.
- Input Builder, guided Studio, interface registry/bootstrap, canonical payload lock, Excel interface classification, TP validate/create/edit and Migration TP paths all use the same contract.
- No SFTP HAFT shared Flow TP is borrowed for SFTP Server; missing shared profile evidence remains HITL/NEEDS_INPUT.
- V129 same-base-API Create/Edit behavior is retained.
- R1 fixes the production Windows launcher title so it reports V130, not V126.

## Fresh verification executed from the exact R1 source

- Complete pytest collection: **619/619 PASS**.
- FastAPI backend tests included in that collection: **55/55 PASS**.
- Focused LIVE/Create-Edit/SFTP regression rerun: **59/59 PASS**.
- Package validator: **59/59 PASS**.
- Adaptive validator: **60/60 PASS**.
- Business readiness: **70/70 PASS**.
- Final release validator: **16/16 PASS**.
- TypeScript/TSX source-transpile: **26 files, 0 diagnostics**.
- FastAPI real process startup: **PASS**.
- `/api/health`: **PASS**.
- `/api/bootstrap`: **PASS**.
- SFTP Server + Edit combined invariant: same POST method + same `orch_tp_create` endpoint, `operation=Edit`, `transportProfileOperation=edit`, `interfaceType=SFTP Server`, `interfaceRole=Primary`, and fixed SSH key preserved.

## Important boundary

Real Dell HIP DEV/LIVE mutation cannot be certified here without Dell OAuth/network access. Frontend dependency installation/build cannot be freshly executed in this container because Bun is unavailable; TypeScript/TSX source transpilation is clean, and the Windows setup/launcher performs `bun install` + `bun run build` before production startup.
