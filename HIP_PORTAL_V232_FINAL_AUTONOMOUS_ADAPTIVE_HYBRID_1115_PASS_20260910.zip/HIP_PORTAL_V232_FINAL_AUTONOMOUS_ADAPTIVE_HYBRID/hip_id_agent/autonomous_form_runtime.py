from __future__ import annotations

"""Goal-driven adaptive form execution for HIP Portal.

This module deliberately separates *what the mission wants* from *how the current
portal happens to render it*.  State-graph nodes carry the canonical business
contract from input.json.  Every cycle re-observes the current live form,
optionally asks Dell AIA's semantic form planner for advisory bindings, executes
through the shared BrowserSession broker (AutoWebGLM -> PyAutoGUI MCP ->
Playwright MCP -> Python Playwright), verifies exact state, and learns only from
successful live interactions.

No CSS selector, Angular id, DOM index, viewport coordinate, or screenshot pixel
position is persisted as long-term knowledge.
"""

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Sequence, Tuple

from playwright.async_api import Page

from .dds_control_driver import assert_active_surface
from .llm_form_planner import LLMFormPlanner
from .safe_io import safe_write_json
from .security import mask_sensitive_data, mask_sensitive_string
from .stateful_form_runtime import (
    capture_stateful_controls,
    execute_phase_state_graph,
    resolve_stateful_control_diagnostics,
)
from .upload_assets import attempt_upload_for_control


def _norm(value: Any) -> str:
    return " ".join(str(value or "").lower().replace("_", " ").replace("-", " ").split())


def autonomous_phase_enabled(config: Any, phase: str) -> bool:
    """Return whether the shared goal runtime owns completion for this phase.

    V231 enables all seven form phases by default.  The all-phases flag is the
    authoritative switch; individual flags exist for controlled rollback/UAT.
    """
    cfg = getattr(config, "autonomous_form", None) if config is not None else None
    if cfg is None or not bool(getattr(cfg, "enabled", True)):
        return False
    if bool(getattr(cfg, "apply_to_all_form_phases", True)):
        return True
    p = _norm(phase).replace(" ", "_")
    if p == "data_map":
        return bool(getattr(cfg, "apply_to_data_map", True))
    if "document_type" in p:
        return bool(getattr(cfg, "apply_to_document_types", True))
    if p == "rule":
        return bool(getattr(cfg, "apply_to_rules", True))
    if "transport_profile" in p:
        return bool(getattr(cfg, "apply_to_transport_profiles", True))
    if p == "biz_flow":
        return bool(getattr(cfg, "apply_to_biz_flow", True))
    return False


def _section_matches_local(expected: Optional[str], actual: Any) -> bool:
    if not expected:
        return True
    e = _norm(expected)
    a = _norm(actual)
    return bool(e and a and (e == a or e in a or a in e))


def _graph_goal_values(graph: Dict[str, Any], section: Optional[str] = None) -> Dict[str, Any]:
    return {
        str(n.get("field_key") or ""): n.get("expected_value")
        for n in (graph.get("nodes") or [])
        if isinstance(n, dict)
        and n.get("expected_value") not in (None, "", [])
        and _section_matches_local(section, n.get("section"))
    }



def _clone_graph(graph: Dict[str, Any], nodes: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    out = copy.deepcopy(graph)
    selected = [copy.deepcopy(n) for n in nodes if isinstance(n, dict)]
    ids = {str(n.get("node_id") or "") for n in selected}
    out["nodes"] = selected
    out["dependency_edges"] = [
        copy.deepcopy(e)
        for e in (graph.get("dependency_edges") or [])
        if isinstance(e, dict)
        and str(e.get("from") or "") in ids
        and str(e.get("to") or "") in ids
    ]
    return out


def _expected_input_values(graph: Dict[str, Any]) -> Dict[str, Any]:
    return {
        str(n.get("field_key") or ""): n.get("expected_value")
        for n in (graph.get("nodes") or [])
        if isinstance(n, dict) and n.get("expected_value") not in (None, "", [])
    }


def _control_fingerprint(controls: Sequence[Dict[str, Any]]) -> str:
    """Value-free current-form shape fingerprint used only for progress detection."""
    rows = []
    for c in controls:
        if not isinstance(c, dict):
            continue
        rows.append({
            "section": _norm(c.get("section")),
            "label": _norm(c.get("label") or c.get("placeholder") or c.get("name")),
            "role": _norm(c.get("role") or c.get("type") or c.get("tag")),
            "framework_key": _norm(c.get("framework_key") or c.get("form_control_name")),
            "required": bool(c.get("required")),
            "disabled": bool(c.get("disabled")),
            "readonly": bool(c.get("readonly")),
        })
    raw = json.dumps(rows, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:20]


def _binding_summary(controls: Sequence[Dict[str, Any]], graph: Dict[str, Any], section: Optional[str] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for node in graph.get("nodes") or []:
        if not isinstance(node, dict) or node.get("expected_value") in (None, "", []):
            continue
        if not _section_matches_local(section, node.get("section")):
            continue
        diag = resolve_stateful_control_diagnostics(controls, node)
        control = diag.get("control") if isinstance(diag.get("control"), dict) else {}
        out.append(mask_sensitive_data({
            "field": node.get("field_key"),
            "action": node.get("action"),
            "required": bool(node.get("required", True)),
            "bound": bool(diag.get("resolved")),
            "reason": diag.get("reason"),
            "best_score": diag.get("best_score"),
            "margin": diag.get("score_margin"),
            "live_label": control.get("label"),
            "live_role": control.get("role") or control.get("type"),
            "live_section": control.get("section"),
            # Current-generation selectors are evidence, never memory.
            "selector_current_generation": control.get("selector") if diag.get("resolved") else "",
        }))
    return out


def _apply_advisory_plan_hints(
    graph: Dict[str, Any],
    controls: Sequence[Dict[str, Any]],
    plan: Dict[str, Any],
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Augment semantic aliases using only controls that exist in this DOM generation.

    The LLM cannot create a selector or input key.  A hint is accepted only when
    the key exists in the mission graph and the selector exactly matches one live
    captured control.  Only semantic attributes are copied into the graph; the
    selector itself is deliberately not persisted into the node.
    """
    out = copy.deepcopy(graph)
    controls_by_selector = {
        str(c.get("selector") or ""): c
        for c in controls
        if isinstance(c, dict) and str(c.get("selector") or "")
    }
    nodes_by_key = {
        str(n.get("field_key") or ""): n
        for n in (out.get("nodes") or [])
        if isinstance(n, dict)
    }
    accepted: List[Dict[str, Any]] = []
    steps = plan.get("field_steps") if isinstance(plan, dict) and isinstance(plan.get("field_steps"), list) else []
    for step in steps:
        if not isinstance(step, dict):
            continue
        key = str(step.get("key") or "").strip()
        node = nodes_by_key.get(key)
        if node is None:
            continue
        selector = str(step.get("selector") or "").strip()
        control = controls_by_selector.get(selector)
        if control is None:
            # Conservative label-hint fallback: accept only one exact normalized label.
            hint = _norm(step.get("label_hint"))
            matches = [
                c for c in controls
                if isinstance(c, dict)
                and hint
                and _norm(c.get("label") or c.get("placeholder") or c.get("name")) == hint
            ]
            control = matches[0] if len(matches) == 1 else None
        if control is None:
            continue
        loc = node.setdefault("semantic_locator", {})
        for target, value in (
            ("labels", control.get("label")),
            ("names", control.get("name") or control.get("framework_key") or control.get("form_control_name")),
            ("placeholders", control.get("placeholder")),
            ("roles", control.get("role")),
            ("section_aliases", control.get("section")),
        ):
            if value in (None, ""):
                continue
            bucket = loc.setdefault(target, [])
            if str(value) not in [str(x) for x in bucket]:
                bucket.append(str(value))
        node.setdefault("adaptive_binding_evidence", []).append({
            "source": "live_control_plus_dell_aia_advisory",
            "label": control.get("label"),
            "role": control.get("role") or control.get("type"),
            "section": control.get("section"),
            "confidence": step.get("confidence"),
            "reason": step.get("reason"),
        })
        accepted.append({
            "field": key,
            "live_label": control.get("label"),
            "live_role": control.get("role") or control.get("type"),
            "confidence": step.get("confidence"),
        })
    return out, mask_sensitive_data(accepted)


def _uncovered_required_controls(controls: Sequence[Dict[str, Any]], graph: Dict[str, Any], section: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return required writable live controls with neither a mapped goal nor a current value.

    This is the anti-fabrication gate. If Dell adds a required field that is not
    represented by input.json, the agent may discover it but must not invent a
    value. A required control already populated by the portal itself is treated as
    satisfied unless the mission graph explicitly owns that field.
    """
    bound_selectors: set[str] = set()
    for node in graph.get("nodes") or []:
        if not isinstance(node, dict) or node.get("expected_value") in (None, "", []):
            continue
        if not _section_matches_local(section, node.get("section")):
            continue
        diag = resolve_stateful_control_diagnostics(controls, node)
        control = diag.get("control") if isinstance(diag.get("control"), dict) else None
        if diag.get("resolved") and control is not None and control.get("selector"):
            bound_selectors.add(str(control.get("selector")))

    uncovered: List[Dict[str, Any]] = []
    for c in controls:
        if not isinstance(c, dict) or not bool(c.get("required")):
            continue
        if c.get("disabled") or c.get("readonly"):
            continue
        selector = str(c.get("selector") or "")
        if selector and selector in bound_selectors:
            continue
        value = str(c.get("value") or "").strip()
        selected = [str(x).strip() for x in (c.get("selected_values") or []) if str(x).strip()]
        role = _norm(c.get("role") or c.get("type"))
        if value or selected or (role in {"switch", "checkbox", "radio"} and bool(c.get("checked"))):
            continue
        uncovered.append(mask_sensitive_data({
            "label": c.get("label") or c.get("placeholder") or c.get("name"),
            "role": c.get("role") or c.get("type") or c.get("tag"),
            "section": c.get("section"),
            "framework_key": c.get("framework_key") or c.get("form_control_name"),
            "reason": "required live control has no mapped mission value and no portal-provided value",
        }))
    return uncovered


async def _observe_autowebglm(page: Page, *, phase: str, cycle: int, goal: str) -> Dict[str, Any]:
    """Capture AutoWebGLM's live simplified-HTML observation without inventing actions."""
    session = getattr(page, "_hip_browser_session", None)
    bridge = getattr(session, "autowebglm_bridge", None) if session is not None else None
    if bridge is None or not hasattr(bridge, "build_observation"):
        return {"available": False, "reason": "AutoWebGLM bridge unavailable"}
    try:
        observation = await bridge.build_observation(
            page=page,
            task=f"Autonomously complete HIP phase {phase}. Cycle {cycle}. Goal: {goal}. Observe the current live form; do not invent a final mutation.",
            history=getattr(session, "action_events", [])[-30:] if session is not None else [],
        )
        # Keep only bounded, masked evidence in the phase audit.
        return mask_sensitive_data({
            "available": bool(observation.get("available")),
            "schema_version": observation.get("schema_version"),
            "position": observation.get("position"),
            "tabs": observation.get("tabs"),
            "simplified_html": str(observation.get("simplified_html") or "")[:12000],
        })
    except Exception as exc:
        return {"available": False, "reason": mask_sensitive_string(str(exc))[:500]}


async def execute_autonomous_phase_goal(
    *,
    page: Page,
    graph: Dict[str, Any],
    phase: str,
    input_data: Dict[str, Any],
    config: Any = None,
    output_dir: Optional[Path] = None,
    prior_attempts: Optional[Sequence[Dict[str, Any]]] = None,
    max_cycles: int = 4,
    repair: bool = True,
    strict_live_execution: bool = True,
    section: Optional[str] = None,
    executor: Optional[Callable[..., Awaitable[Dict[str, Any]]]] = None,
) -> Dict[str, Any]:
    """Autonomously achieve one HIP form goal with bounded adaptive cycles.

    The routine has no phase-specific selector/coordinate list.  It uses the
    canonical input graph as the goal and the *current* form as the truth.
    Required file nodes are uploaded only after non-file dependencies have had a
    chance to reveal them.  On changed labels/wrappers, Dell AIA form planning may
    add current-live semantic aliases; exact state verification remains deterministic.
    """
    max_cycles = max(1, min(int(max_cycles or 1), 12))
    autonomous_cfg = getattr(config, "autonomous_form", None) if config is not None else None
    no_progress_limit = max(1, min(int(getattr(autonomous_cfg, "no_progress_cycle_limit", 2) or 2), 6))
    use_autowebglm_observation = bool(getattr(autonomous_cfg, "use_autowebglm_live_observation", True))
    use_binding_advisor = bool(getattr(autonomous_cfg, "use_dell_aia_binding_advisor_on_ambiguity", True))
    working_graph = copy.deepcopy(graph)
    all_prior: List[Dict[str, Any]] = [dict(x) for x in (prior_attempts or []) if isinstance(x, dict)]
    cycles: List[Dict[str, Any]] = []
    last_shape = ""
    no_progress = 0
    goal_values = _graph_goal_values(working_graph, section)
    goal_summary = ", ".join(f"{k}={v}" for k, v in goal_values.items() if "file" not in k)[:1600]

    async def _execute_graph(current_graph: Dict[str, Any], prior: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        if executor is None:
            return await execute_phase_state_graph(
                page, current_graph, phase=phase, section=section,
                max_retries=2, repair=repair, prior_attempts=prior,
                strict_live_execution=strict_live_execution,
            )
        # Dedicated executors (Document Type) keep their richer transaction model.
        # File upload is owned by this autonomous runtime; do not send upload_file
        # nodes to a dedicated executor that does not implement that action.
        exec_graph = current_graph
        if any(str(n.get("action") or "") == "upload_file" for n in (current_graph.get("nodes") or []) if isinstance(n, dict)):
            exec_graph = _clone_graph(
                current_graph,
                [n for n in (current_graph.get("nodes") or []) if isinstance(n, dict) and str(n.get("action") or "") != "upload_file"],
            )
        # Pass only parameters they declare so the shared runtime stays generic.
        import inspect
        params = inspect.signature(executor).parameters
        kwargs: Dict[str, Any] = {}
        candidates = {
            "phase": phase, "section": section, "max_retries": 2, "repair": repair,
            "prior_attempts": prior, "strict_live_execution": strict_live_execution,
        }
        for key, value in candidates.items():
            if key in params and (key != "section" or value is not None):
                kwargs[key] = value
        return await executor(page, exec_graph, **kwargs)

    for cycle in range(1, max_cycles + 1):
        gate = await assert_active_surface(page, phase)
        controls_before = await capture_stateful_controls(page, phase)
        shape_before = _control_fingerprint(controls_before)
        cycle_audit: Dict[str, Any] = {
            "cycle": cycle,
            "section": section or "",
            "surface_gate": gate,
            "control_count_before": len(controls_before),
            "shape_before": shape_before,
            "bindings_before": _binding_summary(controls_before, working_graph, section),
            "autowebglm_observation": (
                await _observe_autowebglm(page, phase=phase, cycle=cycle, goal=goal_summary)
                if use_autowebglm_observation else
                {"available": False, "reason": "disabled by autonomous_form.use_autowebglm_live_observation"}
            ),
            "adaptive_hints": [],
            "file_attempts": [],
        }
        if gate.get("fatal"):
            cycle_audit["status"] = "surface_lost"
            cycles.append(cycle_audit)
            break

        unresolved_required = [
            row for row in cycle_audit["bindings_before"]
            if row.get("required") and not row.get("bound") and row.get("action") != "upload_file"
        ]
        # Use Dell AIA/AutoGen semantic planning only when deterministic live
        # bindings are insufficient. This is advisory and cannot authorize actions.
        if unresolved_required and config is not None and use_binding_advisor:
            try:
                planner = LLMFormPlanner.from_env(getattr(config, "aia", None))
                if planner is not None:
                    plan_result = planner.plan_fill(
                        phase=phase,
                        controls=list(controls_before),
                        input_values=goal_values,
                        before_state={"control_count": len(controls_before)},
                        failures=unresolved_required,
                    )
                    if plan_result.used and isinstance(plan_result.plan, dict):
                        working_graph, hints = _apply_advisory_plan_hints(
                            working_graph, controls_before, plan_result.plan
                        )
                        cycle_audit["adaptive_hints"] = hints
                        cycle_audit["llm_form_plan_status"] = plan_result.status
                    else:
                        cycle_audit["llm_form_plan_status"] = plan_result.status
            except Exception as exc:
                cycle_audit["llm_form_plan_status"] = f"unavailable: {mask_sensitive_string(str(exc))[:500]}"

        non_file_nodes = [
            n for n in (working_graph.get("nodes") or [])
            if isinstance(n, dict) and str(n.get("action") or "") != "upload_file"
            and _section_matches_local(section, n.get("section"))
        ]
        non_file_graph = _clone_graph(working_graph, non_file_nodes)
        try:
            if non_file_nodes:
                non_file_result = await _execute_graph(non_file_graph, all_prior)
            else:
                non_file_result = {"pass": True, "attempts": [], "execution_stage_audit": {}}
            cycle_audit["non_file_execution"] = non_file_result
            all_prior.extend(
                dict(a, autonomous_cycle=cycle, execution_stage="autonomous_non_file")
                for a in (non_file_result.get("attempts") or []) if isinstance(a, dict)
            )
        except Exception as exc:
            non_file_result = {"pass": False, "error": mask_sensitive_string(str(exc))}
            cycle_audit["non_file_execution"] = non_file_result

        # Re-observe because parent selections can mount/replace file controls.
        controls_after_fields = await capture_stateful_controls(page, phase)
        for node in working_graph.get("nodes") or []:
            if not isinstance(node, dict) or str(node.get("action") or "") != "upload_file":
                continue
            if not _section_matches_local(section, node.get("section")):
                continue
            expected = node.get("expected_value")
            if expected in (None, "", []):
                continue
            # Reuse a successful upload from this mission if already proven.
            already = next((
                a for a in all_prior
                if _norm(a.get("field")) == _norm(node.get("field_key"))
                and bool(a.get("success", a.get("filled")))
                and not ((a.get("validation") or {}).get("blocking"))
            ), None)
            if already is not None:
                continue
            diag = resolve_stateful_control_diagnostics(controls_after_fields, node)
            control = diag.get("control") if isinstance(diag.get("control"), dict) else None
            if control is None:
                attempt = {
                    "field": node.get("field_key"), "success": False, "filled": False,
                    "reason": f"file control not uniquely bound: {diag.get('reason')}",
                    "binding_diagnostics": diag,
                }
            else:
                attempt = await attempt_upload_for_control(
                    page, control, input_data, phase=phase,
                    field_key=str(node.get("field_key") or ""), desired_value=str(expected),
                )
            attempt = dict(attempt, autonomous_cycle=cycle, execution_stage="autonomous_file")
            cycle_audit["file_attempts"].append(attempt)
            all_prior.append(attempt)

        # Full graph is the authoritative goal check. It can repair any field
        # that changed during upload/rerender and requires exact read-back.
        try:
            full_result = await _execute_graph(working_graph, all_prior)
        except Exception as exc:
            full_result = {"pass": False, "error": mask_sensitive_string(str(exc)), "attempts": []}
        cycle_audit["full_goal_execution"] = full_result
        controls_after = await capture_stateful_controls(page, phase)
        shape_after = _control_fingerprint(controls_after)
        cycle_audit["shape_after"] = shape_after
        cycle_audit["control_count_after"] = len(controls_after)
        cycle_audit["bindings_after"] = _binding_summary(controls_after, working_graph, section)
        uncovered_required = _uncovered_required_controls(controls_after, working_graph, section)
        cycle_audit["uncovered_required_controls"] = uncovered_required

        stage = full_result.get("execution_stage_audit") if isinstance(full_result.get("execution_stage_audit"), dict) else {}
        file_failures = [
            a for a in cycle_audit.get("file_attempts", [])
            if isinstance(a, dict) and not bool(a.get("success", a.get("filled")))
        ]
        success = bool(
            full_result.get("pass")
            and not file_failures
            and not uncovered_required
            # V232 fail-closed proof: in strict live execution a missing stage flag
            # is NOT success.  This prevents pass=True from a partial/dedicated
            # executor being mistaken for a proven physical form transaction.
            and (not strict_live_execution or stage.get("exact_execution_verified") is True)
            and (not strict_live_execution or stage.get("authoritative_execution_verified") is True)
        )
        cycle_audit["status"] = "goal_achieved" if success else "retry_required"
        cycles.append(mask_sensitive_data(cycle_audit))

        if output_dir is not None:
            output_dir.mkdir(parents=True, exist_ok=True)
            safe_write_json(output_dir / "autonomous_form_runtime_progress.json", {
                "phase": phase, "cycle": cycle, "status": cycle_audit["status"], "cycles": cycles,
            })

        if success:
            result = {
                "schema_version": "hip.autonomous-form-runtime.v1",
                "phase": phase,
                "section": section or "",
                "status": "pass",
                "pass": True,
                "goal_driven": True,
                "adaptive": True,
                "autowebglm_used_for_live_observation": any(
                    bool((c.get("autowebglm_observation") or {}).get("available")) for c in cycles
                ),
                "fixed_selectors_required": False,
                "fixed_coordinates_required": False,
                "cycles": cycles,
                "final_execution": full_result,
                "prior_attempts": all_prior,
            }
            if output_dir is not None:
                safe_write_json(output_dir / "autonomous_form_runtime.json", result)
            return mask_sensitive_data(result)

        # Bounded anti-stagnation. A newly mounted/replaced control shape or a new
        # successful transaction is progress; an identical shape with no success is not.
        successful_now = sum(
            1 for a in (full_result.get("attempts") or [])
            if isinstance(a, dict) and a.get("success") is True
        )
        progressed = bool(shape_after != shape_before or shape_after != last_shape or successful_now)
        if progressed:
            no_progress = 0
        else:
            no_progress += 1
        last_shape = shape_after
        if no_progress >= no_progress_limit:
            break

    needs_input = [
        item
        for cycle in cycles[-1:]
        for item in (cycle.get("uncovered_required_controls") or [])
        if isinstance(item, dict)
    ]
    result = {
        "schema_version": "hip.autonomous-form-runtime.v1",
        "phase": phase,
        "section": section or "",
        "status": "needs_input" if needs_input else "failed_closed",
        "pass": False,
        "goal_driven": True,
        "adaptive": True,
        "fixed_selectors_required": False,
        "fixed_coordinates_required": False,
        "cycles": cycles,
        "reason": (
            "live portal exposed required control(s) with no trustworthy mission value"
            if needs_input else
            "goal not proven before bounded adaptive/no-progress guard"
        ),
        "needs_input": needs_input,
        "no_progress_cycle_limit": no_progress_limit,
        "prior_attempts": all_prior,
    }
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        safe_write_json(output_dir / "autonomous_form_runtime.json", result)
    return mask_sensitive_data(result)
