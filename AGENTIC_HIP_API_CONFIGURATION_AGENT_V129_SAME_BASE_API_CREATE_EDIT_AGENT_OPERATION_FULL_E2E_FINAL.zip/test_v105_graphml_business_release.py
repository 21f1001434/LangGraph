from pathlib import Path

from knowledge_graph import HipKnowledgeGraph


def test_graphml_export_tolerates_none_and_nested_values(tmp_path: Path):
    store = HipKnowledgeGraph(tmp_path)
    store.upsert_node(
        "node:1",
        "DocumentType",
        "Example",
        {
            "optional": None,
            "nested": {"a": 1, "b": None},
            "items": ["x", None, 2],
        },
    )
    store.upsert_node("node:2", "Rule", "Example Rule", {"enabled": True})
    store.upsert_edge("node:1", "DEPENDS_ON", "node:2", {"comment": None})

    output = store.export_graphml(tmp_path / "kg.graphml")
    assert output.exists()
    text = output.read_text(encoding="utf-8")
    assert "graphml" in text.lower()
    assert "NoneType" not in text
