from __future__ import annotations

import json
from pathlib import Path

import pytest

from api_contract_policy import POLICY_NAME, immutable_flow_graph
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from payload_overrides import PayloadOverrideStore, save_override
from run_agent import Runner
from scratch_flow import component_request, new_component


def test_v100_all_deployment_group_spellings_are_forced_to_hip_automation():
    inp = {
        "objects": {
            "source_transport_profile": {"deployment-group": "wrong", "deploymentGroupName": "wrong"},
            "target_transport_profile": {"deploymentgroupname": "wrong", "deployment_group": "wrong"},
        }
    }
    cfg = {"deployment-group": "wrong", "deploymentgroupname": "wrong", "sourceDeploymentGroup": "wrong"}
    out, config = with_default_deployment_group(inp, cfg)
    assert DEFAULT_DEPLOYMENT_GROUP == "hip-automation"
    src = out["objects"]["source_transport_profile"]
    tgt = out["objects"]["target_transport_profile"]
    assert src["deployment-group"] == src["deploymentGroupName"] == "hip-automation"
    assert tgt["deploymentgroupname"] == tgt["deployment_group"] == "hip-automation"
    assert config["deployment-group"] == config["deploymentgroupname"] == config["sourceDeploymentGroup"] == "hip-automation"


def test_v117_persisted_value_edit_is_applied_but_structure_stays_locked(tmp_path: Path):
    save_override(tmp_path, "account_source", {"description": "SHOULD_NOT_REACH_LIVE"}, request_kind="payload", mode="merge", edit_origin="USER")
    store = PayloadOverrideStore(tmp_path)
    base = {"payload": {"accountName": "A", "description": "CANONICAL"}}
    effective, meta = store.apply("account_source", base, {})
    assert effective["payload"]["accountName"] == "A"
    assert effective["payload"]["description"] == "SHOULD_NOT_REACH_LIVE"
    assert meta["applied"] is True
    assert meta["stepKey"] == "account_source"


def test_v100_flow_block_request_override_is_rejected_before_request_generation():
    runner = Runner(llm_enabled=False)
    component = new_component("account_source", request_override={"description": "MUTATED"})
    with pytest.raises(ValueError, match="IMMUTABLE_DEVELOPER_APPROVED_18_API_CONTRACT"):
        component_request(runner, component)


def test_v100_flow_graph_sanitizer_removes_api_overrides_but_keeps_edge_mappings():
    graph = {
        "nodes": [{"id": "n1", "api_key": "account_source", "request_override": {"description": "x"}, "override_mode": "replace"}],
        "edges": [{"id": "e1", "source": "n1", "target": "n2", "mappings": [{"from": "output.id", "to": "payload.id"}]}],
    }
    clean = immutable_flow_graph(graph)
    assert clean["nodes"][0]["request_override"] == {}
    assert clean["nodes"][0]["override_mode"] == "merge"
    assert clean["edges"][0]["mappings"] == graph["edges"][0]["mappings"]


def test_v117_runner_applies_schema_locked_persisted_value_edits(tmp_path: Path, monkeypatch):
    text = Path("run_agent.py").read_text(encoding="utf-8")
    assert "Payload Value Editor" in text
    assert "self.payload_overrides.apply" in text
    assert "lock_live_request_fingerprint" in text


def test_v100_existing_map_policy_is_execute_and_no_preseeded_id():
    text = Path("test_v99_hip_automation_map_reuse.py").read_text(encoding="utf-8")
    assert "Map identifier should be unique in an Environment" in text
    assert 'assert verdict["outcome"] == "EXISTING"' in text
    assert 'runtime_state["map_id"] is None' in text
