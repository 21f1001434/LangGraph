# V128 — Identity, Version and Migration Execution Hardening

Release date: 2026-09-09

V128 is a hardening release built on V127. It preserves the V127 evidence-accurate Excel mapping and V126 human-controlled Migration execution plan while closing execution-boundary gaps found during independent source validation.

## Implemented corrections

### 1. Partner Create identity is separate from routing identity

Sender/Receiver values extracted from XML, Rule conditions or Flow routing (for example `UHI1001` and `DELLCO01`) are routing evidence only. They are never promoted to `partnerIdentifierValue` for Partner Create.

The Dev-approved shared UAT mapping remains explicit and narrow:

- HIP partner system: `dce-test-partner`
- Partner identifier type: `DUNS Number`
- Partner identifier value: `12345666`

The fallback is keyed by the configured partner system, not by customer name and not by routing values.

### 2. No fabricated object versions

Missing API object versions remain blank through ingestion, canonical mapping and request construction. The runner no longer manufactures `1` or `1.0` for:

- Source/Target Document Type version
- Data Map identifier version
- Mapping Rule version
- Business Flow version
- dependent Rule/TP/Flow references
- Migration request references

Raw/manual configuration now surfaces these as HUMAN/HITL questions when they are not present in deterministic evidence.

### 3. Migration execution consent is human-controlled

Migration is OFF unless the saved `execution_flow.json` explicitly enables it. A stale `HIP_FORCE_MIGRATION_IN_FULL_LIVE` environment variable cannot force Migration ON. Environment configuration may still be used as a defensive disable/kill switch where supported, but execution consent comes from the saved human plan.

### 4. Migration participates in end-to-end success

When Migration is enabled, all applicable Migration steps are required for final business success. A failed required Migration step can no longer coexist with an overall successful end-to-end verdict.

### 5. Executable 25-API integration coverage

`production_full_25_integration_test.py` executes the actual `Runner.run()` path with deterministic mocked HIP responses and verifies:

- 18 base logical API steps
- 7 Migration logical API steps
- 25 unique HTTP-bound logical steps
- Migration enabled from the saved execution plan
- `success=true`
- `businessSuccess=true`
- no unresolved required steps

The latest deterministic result is stored in `examples/PRODUCTION_MOCK_25_API_INTEGRATION.json`.

## Files changed or added in V128

Core implementation:

- `run_agent.py`
- `uhal_mapper.py`
- `input_builder_core.py`
- `input_builder_integration.py`
- `LIVE_ONLY_RELEASE_MANIFEST.json`
- `README_START_HERE.md`

Regression/integration coverage:

- `test_v128_identity_version_migration_execution_hardening.py`
- `production_full_25_integration_test.py`
- V125/V127 and historical builder tests updated where their old assertions depended on unsafe default/version or routing-identity behavior.

## Validation boundary

V128 validates the complete local execution path to the governed HTTP boundary. The 25-step integration uses mocked HIP responses and therefore does not claim that a real Dell HIP DEV/TEST environment accepted the requests. Real LIVE/DEV execution still requires the user's Dell network, OAuth credentials, correct API routes and current HIP platform availability.
