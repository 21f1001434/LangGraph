from __future__ import annotations

import re as _re_agt
import json as _json_agt

import json
import re
import tempfile
import zipfile
import xml.etree.ElementTree as _ET_agt
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Union
from hip_naming import normalize_input_flow_name

# Extracted from hip_mcp_full_configuration_agent_v80_019 / app.py.
# Streamlit, Profile Runner execution, MCP, browser automation and LLM dependencies
# are intentionally NOT required by this standalone module.

HIP_AUTOMATION_GROUP = "hip-automation"

HIP_INTERFACE_TYPES = [
    "SFTP HAFT", "SFTP Server", "FTP", "HTTPS", "HTTPS-AS2",
    "AS2", "IBM MQ", "Rabbit MQ", "Kafka", "NAS", "S3",
]
HIP_INTERFACE_TYPE_DEFAULT = "SFTP HAFT"

_DELL_IDENTITY_ALIASES = [
    "DELL", "AIC - DCE", "AIC-DCE", "AIC – DCE", "DCE",
    "DELL APPLICATION", "DELL_ORDERS", "DCE-TEST", "DELL TECHNOLOGIES",
]

_RECV_CANON_MAP = {
    "reciever": "Receiver", "receiver": "Receiver", "reciver": "Receiver",
    "recevier": "Receiver", "sender": "Sender", "sendor": "Sender",
}

AGT_TX_CATALOGUE = {
    ("X12","850"):       {"name":"Purchase Order",        "format":"EDIX12"},
    ("EDIFACT","ORDERS"):{"name":"Purchase Order",        "format":"EDIFACT"},
    ("X12","855"):       {"name":"Order Acknowledgment",  "format":"EDIX12"},
    ("EDIFACT","ORDRSP"):{"name":"Order Response",        "format":"EDIFACT"},
    ("X12","856"):       {"name":"Advance Ship Notice",   "format":"EDIX12"},
    ("EDIFACT","DESADV"):{"name":"Dispatch Advice",       "format":"EDIFACT"},
    ("X12","810"):       {"name":"Invoice",               "format":"EDIX12"},
    ("EDIFACT","INVOIC"):{"name":"Invoice",               "format":"EDIFACT"},
    ("X12","820"):       {"name":"Payment/Remittance",    "format":"EDIX12"},
    ("EDIFACT","REMADV"):{"name":"Remittance Advice",     "format":"EDIFACT"},
    ("X12","997"):       {"name":"Functional Ack",        "format":"EDIX12"},
    ("EDIFACT","CONTRL"):{"name":"Syntax/App Ack",        "format":"EDIFACT"},
    ("EDIFACT","APERAK"):{"name":"Application Ack",       "format":"EDIFACT"},
    ("CSV","CSV_PO"):    {"name":"CSV Purchase Order",    "format":"CSV"},
}

EDI_ATTR_EXPRESSIONS = {
    "Receiver":                     {"X12":"ISA*08",      "EDIFACT":"UNB*03"},
    "Sender":                       {"X12":"ISA*06",      "EDIFACT":"UNB*02"},
    "Transaction Type":             {"X12":"ST*01",       "EDIFACT":"UNH*02:0"},
    "Business Identifier":          {"X12":"BAK*03",      "EDIFACT":"BGM*02"},
    "Alternate Business Identifier":{"X12":"REF*02",      "EDIFACT":"RFF*02"},
}

XML_ATTR_XPATHS = {
    "DellPOA": {
        "Receiver":"/DellPOA/PurchaseOrderHeader/PartnerInformation/To/PartnerName",
        "Sender":"/DellPOA/PurchaseOrderHeader/PartnerInformation/From/PartnerName",
        "Business Identifier":"/DellPOA/PurchaseOrder/PurchaseOrderNumber",
        "Alternate Business Identifier":"/DellPOA/PurchaseOrder/DellPurchaseId",
        "PartnerIdentifier":"/DellPOA/PurchaseOrderHeader/PartnerInformation/To/PartnerIdentifier",
        "VendorNumber":"/DellPOA/PurchaseOrder/InternalVendorNumber",
    },
    "DELLPOA": {
        "Receiver":"/DellPOA/PurchaseOrderHeader/PartnerInformation/To/PartnerName",
        "Sender":"/DellPOA/PurchaseOrderHeader/PartnerInformation/From/PartnerName",
        "Business Identifier":"/DellPOA/PurchaseOrder/PurchaseOrderNumber",
        "Alternate Business Identifier":"/DellPOA/PurchaseOrder/DellPurchaseId",
        "PartnerIdentifier":"/DellPOA/PurchaseOrderHeader/PartnerInformation/To/PartnerIdentifier",
    },
    "PurchaseOrder": {
        "Sender":"/PurchaseOrder/Header/PartnerInformation/From/PartnerName",
        "Receiver":"STATIC: DELL",
        "Business Identifier":"/PurchaseOrder/Header/PurchaseOrderNumber",
        "Alternate Business Identifier":"/PurchaseOrder/Header/CustomerReference",
    },
    "OrderAcknowledgement": {
        "Sender":"STATIC: DELL",
        "Receiver":"/OrderAcknowledgement/Header/PartnerInformation/To/PartnerName",
        "Business Identifier":"/OrderAcknowledgement/Header/OrderNumber",
    },
    "ShipmentNotice": {
        "Sender":"STATIC: DELL",
        "Receiver":"/ShipmentNotice/Header/PartnerInformation/To/PartnerName",
        "Business Identifier":"/ShipmentNotice/Header/ShipmentNumber",
    },
    "Invoice": {
        "Sender":"STATIC: DELL",
        "Receiver":"/Invoice/Header/PartnerInformation/To/PartnerName",
        "Business Identifier":"/Invoice/Header/InvoiceNumber",
    },
    "_default": {
        "Sender":"/<Root>/Header/PartnerInformation/From/PartnerName",
        "Receiver":"/<Root>/Header/PartnerInformation/To/PartnerName",
        "Business Identifier":"/<Root>/Header/BusinessIdentifier",
    },
}

def _agt_get_xpaths(xml_root: str, is_outbound: bool) -> Dict[str, str]:
    return XML_ATTR_XPATHS.get(xml_root, XML_ATTR_XPATHS["_default"])

def get_kb():
    # Compatibility shim: the extracted deterministic builder only referenced the KB
    # object but did not consume it in the function body.
    return SimpleNamespace(payload={})

def _parse_config_manual_xlsx(xlsx_bytes: bytes) -> Dict[str, Any]:
    """
    Parse a HIP Configuration Manual Excel file (as raw bytes) and return
    a fully structured input.json dict.

    Sheet structure expected:
      - Data Map Configuration
      - Document Types Configuration
      - Rules Configuration
      - TransportProfile
      - Biz Flows

    Returns the objects dict ready to embed in input.json.
    """
    import io as _io_xl
    try:
        from openpyxl import load_workbook as _lwb
    except ImportError:
        return {"_error": "openpyxl not installed"}

    try:
        wb = _lwb(_io_xl.BytesIO(xlsx_bytes), read_only=True, data_only=True)
    except Exception as e:
        return {"_error": f"Cannot open workbook: {e}"}

    # ── v79.115: USER-FILLED PACKAGE manual support ─────────────────────────
    # Layout (AS2_AMAZON_JAPAN / FTE_COMPUTACENTER real packages): branch-row
    # tables — 'Data Maps' (Branch|Map Identifier|Version|Status|Map Name|Map
    # Class|Contivo Version), 'Target Doc Types', 'Rules', 'Source Doc Type';
    # 'Transport Profiles' long-format (Profile Group|Field|Final Value) with
    # one Source group + one group per target branch; 'Business Flow' with
    # JSON Section|Value rows + a Process Steps table.
    _USER_PKG_SHEETS = {"Data Maps", "Source Doc Type", "Target Doc Types",
                        "Rules", "Transport Profiles"}
    if _USER_PKG_SHEETS.issubset(set(wb.sheetnames)):
        def _hdr_key(h: str) -> str:
            h = str(h or "").strip()
            special = {"Map Identifier": "map_identifier", "Version": "version",
                       "Map Name": "map_name", "Map Class": "map_class",
                       "Contivo Version": "contivo_version", "Name": "name",
                       "Transaction Type": "transaction_type",
                       "Data Format": "data_format_type", "Validation Type": "validation_type",
                       "Rule Name": "name", "Doc Type Version": "document_type_name_version",
                       "Rule Type": "rule_type", "Rule Scope": "rule_scope",
                       "Status": "status", "Branch": "branch"}
            return special.get(h, h.lower().replace(" ", "_"))

        def _branch_table(ws, header_first_cell="Branch") -> List[Dict[str, str]]:
            rows = list(ws.iter_rows(values_only=True))
            out: List[Dict[str, str]] = []
            hdr: Optional[List[str]] = None
            for r in rows:
                cells = [str(x).strip() if x is not None else "" for x in (r or [])]
                if not hdr:
                    if cells and cells[0] == header_first_cell:
                        hdr = [_hdr_key(x) for x in cells]
                    continue
                if not cells or not cells[0]:
                    break  # blank row ends the table
                rec = {hdr[i]: cells[i] for i in range(min(len(hdr), len(cells))) if hdr[i]}
                # version on data maps means map_identifier_version
                out.append(rec)
            return out

        objects: Dict[str, Any] = {}
        _dms = _branch_table(wb["Data Maps"])
        for _d in _dms:
            if "version" in _d:
                _d["map_identifier_version"] = _d.pop("version")
        if _dms:
            objects["data_map"] = _dms if len(_dms) > 1 else _dms[0]
        _sdts = _branch_table(wb["Source Doc Type"])
        if _sdts:
            objects["source_document_type"] = _sdts[0] if len(_sdts) == 1 else _sdts
        _tdts = _branch_table(wb["Target Doc Types"])
        if _tdts:
            objects["target_document_type"] = _tdts if len(_tdts) > 1 else _tdts[0]
        _rls = _branch_table(wb["Rules"])
        if _rls:
            objects["rule"] = _rls if len(_rls) > 1 else _rls[0]
        # Transport Profiles: long format grouped by Profile Group
        _tp_groups: Dict[str, Dict[str, str]] = {}
        _tp_order: List[str] = []
        for r in wb["Transport Profiles"].iter_rows(values_only=True):
            cells = [str(x).strip() if x is not None else "" for x in (r or [])]
            if len(cells) < 3 or not cells[0] or cells[0] in ("Profile Group",):
                continue
            g, fld, val = cells[0], cells[1], cells[2]
            if not fld or fld == "Field":
                continue
            if g not in _tp_groups:
                _tp_groups[g] = {}
                _tp_order.append(g)
            _tp_groups[g][_hdr_key(fld) if " " in fld else fld] = val
        if "Source" in _tp_groups:
            objects["source_transport_profile"] = _tp_groups["Source"]
        _tgts = [_tp_groups[g] for g in _tp_order if g != "Source"]
        for _gi, _g in enumerate(_tgts):
            _g.setdefault("branch", _tp_order[_tp_order.index("Source") + 1 + _gi]
                          if "Source" in _tp_order else str(_gi + 1))
        if _tgts:
            objects["target_transport_profile"] = _tgts if len(_tgts) > 1 else _tgts[0]
        # Business Flow: Section|Value (JSON) + Process Steps table
        if "Business Flow" in wb.sheetnames:
            _bf: Dict[str, Any] = {}
            _steps: List[Dict[str, str]] = []
            _mode = "kv"
            for r in wb["Business Flow"].iter_rows(values_only=True):
                cells = [str(x).strip() if x is not None else "" for x in (r or [])]
                c1 = cells[0] if cells else ""
                if c1 == "Process Steps":
                    _mode = "steps"
                    continue
                if c1 in ("Configure Routing",):
                    _mode = "routing"
                    continue
                if c1 in ("", "Section", "Step Number", "Routing Section",
                          "Business Flow Details"):
                    continue
                if _mode == "kv" and len(cells) >= 2:
                    _v = cells[1]
                    try:
                        _bf[c1] = json.loads(_v) if _v.startswith(("{", "[")) else _v
                    except Exception:
                        _bf[c1] = _v
                elif _mode == "steps" and c1.isdigit() and len(cells) >= 4:
                    _steps.append({"branch": cells[1], "step_type": cells[2],
                                   "step_name": cells[3]})
                elif _mode == "routing" and len(cells) >= 2:
                    _rv = cells[1]
                    try:
                        _bf.setdefault("configure_routing", {})[c1] = (
                            json.loads(_rv) if _rv.startswith(("{", "[")) else _rv)
                    except Exception:
                        _bf.setdefault("configure_routing", {})[c1] = _rv
            if _steps:
                _bf["process_steps"] = _steps
            if _bf:
                objects["biz_flow"] = _bf
        objects["_parsed_from"] = "user_filled_package_manual"
        return objects

    # ── v79.108: AGENT-GENERATED workbook support (round-trip) ──────────────
    # _agt_build_config_manual_xlsx writes key/value sheets with RAW json keys
    # in column A — named "Source Doc Type", "Input File Data Map 2",
    # "Datamanpass 1", "Target Transport Profile 2", "Rule Configuration", etc.
    # If those sheets are present, parse THIS format (numbered sheets become
    # lists) so input.json → Excel → user edits → input.json round-trips.
    # Old Dell-style manuals (Data Map Configuration / TransportProfile / …)
    # fall through to the original parser below.
    _GEN_SHEET_MAP = [
        (r"^Source Doc Type( \d+)?$",            "source_document_type"),
        (r"^Target Doc Type( \d+)?$",            "target_document_type"),
        (r"^Input File Data Map( \d+)?$",        "data_map"),
        (r"^Output File Data Map( \d+)?$",       "output_file_data_map"),
        (r"^Datamanpass( \d+)?$",                "datamanpass"),
        (r"^Rule Configuration( \d+)?$",         "rule"),
        (r"^Source Transport Profile( \d+)?$",   "source_transport_profile"),
        (r"^Target Transport Profile( \d+)?$",   "target_transport_profile"),
        (r"^Biz Flow( \d+)?$",                   "biz_flow"),
    ]
    _gen_hits = [sn for sn in wb.sheetnames
                 for pat, _k in _GEN_SHEET_MAP if re.match(pat, sn)]
    if _gen_hits:
        def _kv_sheet_to_dict(ws) -> Dict[str, str]:
            d: Dict[str, str] = {}
            for row in ws.iter_rows(min_row=2, max_col=2, values_only=True):
                k = str(row[0]).strip() if row and row[0] is not None else ""
                v = str(row[1]).strip() if row and len(row) > 1 and row[1] is not None else ""
                if k and not k.lower().startswith(("field", "—", "section")):
                    d[k] = v
            return d

        def _cellrows(ws, ncols: int) -> List[List[str]]:
            out = []
            for row in ws.iter_rows(min_row=1, max_col=ncols, values_only=True):
                out.append([str(c).strip() if c is not None else "" for c in row])
            return out

        def _gen_rule_sheet(ws) -> Dict[str, Any]:
            """v79.111: Rule sheet → flat fields + conditions.rows[] + actions{}.
            Mirrors _add_rule_sheet: flat kv rows, then a 'Conditions' section
            with table header (# | Condition Type | Operator | Value | Attribute
            Name) and numbered rows."""
            rows = _cellrows(ws, 5)
            rule: Dict[str, Any] = {}
            cond_rows: List[Dict[str, str]] = []
            mode = "flat"
            for r in rows[1:]:  # skip Field|Value header
                c1 = r[0]
                if c1 == "Conditions":
                    mode = "conds"
                    continue
                if mode == "flat":
                    if c1 and c1 not in ("#",):
                        rule[c1] = r[1]
                else:
                    if c1 == "#":  # table header row
                        continue
                    if c1 and c1.isdigit():
                        cond_rows.append({"condition_type": r[1], "operator": r[2],
                                          "value": r[3], "attribute_name": r[4]})
            rule["conditions"] = {
                "execute_actions_when": rule.get("execute_actions_when", ""),
                "rows": cond_rows,
            }
            rule["actions"] = {
                "action_name": rule.get("action_name", ""),
                "action_type": rule.get("action_type", ""),
                "mapping_identifier_name_version": rule.get("mapping_identifier_name_version", ""),
            }
            return rule

        _BF_SECTS = {
            "Flow Details": ("flow_details",),
            "Configure Source": ("configure_source",),
            "Configure Targets": ("configure_targets",),
            "Configure Routing — Rule": ("configure_routing", "rule"),
            "Configure Routing — Actions": ("configure_routing", "actions"),
        }

        def _gen_bizflow_sheet(ws) -> Dict[str, Any]:
            """v79.111: Biz Flow sheet → flow_details / configure_source /
            configure_targets / configure_routing{rule,actions} /
            flow_identifiers{operator,conditions[]} / process_steps[]. Mirrors
            _add_biz_flow_sheet's sections + the two tables."""
            rows = _cellrows(ws, 5)
            bf: Dict[str, Any] = {}
            cur_path: Optional[Tuple[str, ...]] = None
            mode = "kv"
            fi_conds: List[Dict[str, str]] = []
            steps: List[Dict[str, str]] = []
            for r in rows[1:]:
                c1 = r[0]
                if c1 in _BF_SECTS:
                    cur_path, mode = _BF_SECTS[c1], "kv"
                    continue
                if c1 == "Flow Identifiers":
                    cur_path, mode = ("flow_identifiers",), "fi"
                    continue
                if c1 == "Process Steps":
                    cur_path, mode = None, "steps"
                    continue
                if c1 == "#":
                    continue  # table headers
                if mode == "kv" and cur_path and c1:
                    d = bf
                    for p in cur_path:
                        d = d.setdefault(p, {})
                    d[c1] = r[1]
                elif mode == "fi" and c1:
                    if c1 == "Flow Identifier Operator":
                        bf.setdefault("flow_identifiers", {})["operator"] = r[1]
                    elif c1.isdigit():
                        fi_conds.append({"document_type_name_version": r[1],
                                         "attribute_name": r[2], "operator": r[3],
                                         "value": r[4]})
                elif mode == "steps" and c1 and c1.isdigit():
                    steps.append({"step_type": r[1], "rule_version": r[2],
                                  "target_doc": r[3]})
            if fi_conds:
                bf.setdefault("flow_identifiers", {})["conditions"] = fi_conds
            if steps:
                bf["process_steps"] = steps
            return bf

        _collected: Dict[str, List[Tuple[int, Dict[str, str]]]] = {}
        for sn in wb.sheetnames:
            for pat, okey in _GEN_SHEET_MAP:
                m = re.match(pat, sn)
                if m:
                    idx = int(m.group(1).strip()) if m.group(1) else 1
                    if okey == "rule":
                        _parsed_sheet = _gen_rule_sheet(wb[sn])
                    elif okey == "biz_flow":
                        _parsed_sheet = _gen_bizflow_sheet(wb[sn])
                    else:
                        _parsed_sheet = _kv_sheet_to_dict(wb[sn])
                    _collected.setdefault(okey, []).append((idx, _parsed_sheet))
                    break
        objects: Dict[str, Any] = {}
        for okey, items in _collected.items():
            items.sort(key=lambda t: t[0])
            dicts = [d for _i, d in items if d]
            if not dicts:
                continue
            objects[okey] = dicts if len(dicts) > 1 else dicts[0]
        objects["_parsed_from"] = "agent_generated_manual"
        return objects

    def _rows(ws) -> List[List[str]]:
        """Return all rows as flat lists of stripped strings."""
        out = []
        for row in ws.iter_rows(values_only=True):
            r = [str(c).strip() if c is not None else "" for c in row]
            if any(r):
                out.append(r)
        return out

    def _val(rows: List[List[str]], *keywords, col: int = -1) -> str:
        """Find the last column value on the first row whose first non-empty
        cell matches any keyword (case-insensitive).

        v79.76: A trailing tab in a keyword (e.g. "Name\t", "Version\t",
        "Type\t", "Target\t") now means EXACT first-cell match — i.e. the
        first non-empty cell must EQUAL that word (ignoring the tab). Previously
        this was a substring check for "name\t", which never matched because
        cells don't contain tabs (tabs separate cells). This is why routing
        rule Name/Version/Type/Target came back empty.
        """
        norm_kws = []  # (keyword_lower, exact_match_bool)
        for k in keywords:
            kl = k.lower()
            if kl.endswith("\t"):
                norm_kws.append((kl[:-1].strip(), True))   # exact
            else:
                norm_kws.append((kl, False))               # substring
        for row in rows:
            first = next((c for c in row if c), "").lower().strip()
            matched = False
            for kw, exact in norm_kws:
                if exact:
                    if first == kw:
                        matched = True
                        break
                else:
                    if kw in first:
                        matched = True
                        break
            if matched:
                if col == -1:
                    vals = [c for c in row if c]
                    return vals[-1] if len(vals) > 1 else ""
                else:
                    return row[col] if col < len(row) else ""
        return ""

    # v79.77: Values that are actually column labels / data-type names, not real
    # data. When a field row has no value in the Value column, the last non-empty
    # cell is the Data-Type label (e.g. "Selection", "Alpha-Numeric"). Treat
    # these as blank so we don't mistake a label for a configured value.
    _LABEL_NOISE = {
        "selection", "alpha-numeric", "apha-numeric", "alphanumeric",
        "checkbox / toggle", "checkbox/toggle", "checkbox", "toggle",
        "upload file", "radio button", "radio button(yes/no)", "read only",
        "default", "numeric", "alpha", "mandatory field", "optional field",
        "default value field", "check box", "n\\a", "na", "n/a", "nature of field",
        "data type", "field length", "description", "value",
    }

    def _val_clean(rows: List[List[str]], *keywords, col: int = -1) -> str:
        """_val but returns '' if the matched value is just a column/data-type
        label or template-instruction noise (not a real configured value)."""
        v = _val(rows, *keywords, col=col)
        vs = v.strip().lower()
        if vs in _LABEL_NOISE:
            return ""
        if "mention na" in vs or "add more row" in vs or "if no expression" in vs:
            return ""
        return v

    def _canon_attr_name(v: str) -> str:
        """v79.78: Canonicalize HIP attribute names to their correct spelling on
        extraction. The Configuration Manual frequently misspells "Receiver" as
        "Reciever" (and a few other common variants). HIP's actual attribute set
        is fixed — Receiver, Sender, Transaction Type, Business Identifier,
        Alternate Business Identifier — so we map known misspellings to the
        canonical form. Unknown values pass through unchanged (only the trailing
        whitespace is trimmed)."""
        if not v:
            return v
        raw = v.strip()
        key = raw.lower().replace("-", " ").replace("_", " ")
        key = " ".join(key.split())  # collapse internal whitespace
        canon = {
            "reciever": "Receiver",
            "receiver": "Receiver",
            "reciver": "Receiver",
            "receiver": "Receiver",
            "sender": "Sender",
            "sendor": "Sender",
            "transaction type": "Transaction Type",
            "transactiontype": "Transaction Type",
            "txn type": "Transaction Type",
            "business identifier": "Business Identifier",
            "business id": "Business Identifier",
            "alternate business identifier": "Alternate Business Identifier",
            "alternate business id": "Alternate Business Identifier",
            "alt business identifier": "Alternate Business Identifier",
        }
        return canon.get(key, raw)

    def _block(rows: List[List[str]], start_kw: str, end_kw: str = "") -> List[List[str]]:
        """Return rows between start_kw and end_kw markers.

        v79.76: Match the marker against the WHOLE row (any cell), not just the
        first non-empty cell. The Configuration Manual uses two-column markers
        like ['TAB', 'Configure Target(s)'] and ['Section', 'Flow Identifiers'],
        where the keyword lives in the SECOND cell. Matching only the first cell
        ('TAB'/'Section') caused Configure Targets, Flow Identifiers and
        Configure Routing to come back empty.
        """
        collecting = False
        out = []
        sk = start_kw.lower()
        ek = end_kw.lower()
        for row in rows:
            joined = "\t".join(row).lower()
            if not collecting:
                if sk in joined:
                    collecting = True
                continue
            # collecting == True
            if ek and ek in joined:
                break
            out.append(row)
        return out

    def _marker_row(row: List[str], label: str) -> bool:
        """v79.76: True if this row is a structural MARKER row for `label` —
        i.e. its first non-empty cell is a structural keyword (Section / TAB)
        and the NEXT cell starts with `label`, OR the first cell itself starts
        with `label`. This avoids matching the word inside a description cell
        (e.g. 'regardless of conditions') which broke nested block slicing."""
        cells = [c for c in row if c]
        if not cells:
            return False
        first = cells[0].strip().lower()
        lab = label.lower()
        if first in ("section", "tab"):
            second = cells[1].strip().lower() if len(cells) > 1 else ""
            return second.startswith(lab)
        return first.startswith(lab)

    def _section_block(rows: List[List[str]], start_label: str,
                       end_label: str = "") -> List[List[str]]:
        """v79.76: Like _block but boundaries match only true Section/TAB MARKER
        rows (via _marker_row), not any cell containing the word. Used for the
        Conditions / Actions sub-blocks inside Configure Routing, whose words
        also appear inside neighbouring description text."""
        collecting = False
        out = []
        for row in rows:
            if not collecting:
                if _marker_row(row, start_label):
                    collecting = True
                continue
            if end_label and _marker_row(row, end_label):
                break
            out.append(row)
        return out

    result: Dict[str, Any] = {}

    # ── Data Map Configuration ─────────────────────────────────────────────────
    try:
        ws = wb["Data Map Configuration"]
        rows = _rows(ws)
        result["data_map"] = {
            "map_identifier":         _val(rows, "Map Identifier"),
            "map_identifier_version": _val(rows, "Map Identifier Version"),
            "status":                 _val(rows, "Status"),
            "map_name":               _val(rows, "Map Name"),
            "map_class":              _val(rows, "Map Class"),
            "contivo_version":        _val(rows, "Contivo Version"),
            "map_data_file":          _val(rows, "Upload Map File"),
        }
    except Exception as e:
        result["data_map"] = {"_parse_error": str(e)}

    # ── Document Types Configuration ───────────────────────────────────────────
    def _parse_doc_type(rows, marker_kw):
        """Parse one document type block from the sheet."""
        block = _block(rows, marker_kw, "Output File" if "Inbound" in marker_kw else "")
        if not block:
            block = rows  # fallback to all rows
        # v79.77: Use _val_clean for fields whose Value column is often empty in
        # the manual — otherwise the last cell is the Data-Type label (e.g.
        # "Selection", "Alpha-Numeric") and gets mistaken for a real value
        # (this is why target validation_type wrongly came back "Selection").
        dt: Dict[str, Any] = {
            "name":             _val_clean(block, "Name\t"),
            "transaction_type": _val_clean(block, "Transaction Type"),
            "version":          _val_clean(block, "Version"),
            "data_format_type": _val_clean(block, "Data Format Type"),
            "status":           _val_clean(block, "Status"),
            "description":      _val_clean(block, "Description"),
            "validation_type":  _val_clean(block, "Validation Type"),
            "document_identifier": {
                "operation": _val_clean(block, "Operation"),
            },
            "document_identifier_rows": [],
            "attributes_to_configure":  [],
        }
        # Clean up name — sometimes carries the label
        if dt["name"].lower().startswith("name"):
            dt["name"] = ""

        # ── Document identifier rows ─────────────────────────────────────────
        # v79.77: The TRANSACTION_ROOT_ELEMENT row itself only carries the label
        # plus a template instruction "(Mention NA if no expression ...)". The
        # ACTUAL value (e.g. "cXML") lives on the following "Value (Mandatory
        # Field)" row. So: find the TRE marker, then scan the next few rows for a
        # "Value" row and take ITS value (skip the ROW# header). Never take the
        # instruction text as the value.
        _instr_markers = ("mention na", "add more row", "if no expression")
        for _i, row in enumerate(block):
            joined = "\t".join(row)
            if "TRANSACTION_ROOT_ELEMENT" not in joined:
                continue
            # Skip the Attributes table row (it lists TRE among derived-from cols)
            if any("Derived From (Mandatory" in c or "Attribute Name" in c for c in row):
                continue
            _value = ""
            for _j in range(_i + 1, min(_i + 5, len(block))):
                _r = block[_j]
                _first = next((c for c in _r if c), "").strip().lower()
                if _first.startswith("section") or _first.startswith("derived from (selection)"):
                    break  # reached next block
                if _first.startswith("value"):
                    _vals = [c for c in _r if c]
                    if len(_vals) >= 2:
                        _cand = _vals[-1].strip()
                        if _cand.lower() not in _instr_markers and not any(
                                m in _cand.lower() for m in _instr_markers):
                            _value = _cand
                    break
            # Only record a row if we found a real (non-instruction, non-NA) value
            if _value and _value.upper() not in ("NA", "N/A", "N\\A"):
                dt["document_identifier_rows"].append({
                    "derived_from": "TRANSACTION_ROOT_ELEMENT",
                    "value": _value,
                })

        # ── Attributes to configure ──────────────────────────────────────────
        # Find the row with "Attribute Name" header
        attr_start = None
        for i, row in enumerate(block):
            if any("Attribute Name" in c for c in row):
                attr_start = i
                break

        if attr_start is not None:
            # Read the transposed table: each column after col 1 is one attribute
            attr_header_row   = block[attr_start]      # e.g. row labels
            derived_from_row  = block[attr_start + 1] if attr_start + 1 < len(block) else []
            usage_row         = block[attr_start + 2] if attr_start + 2 < len(block) else []
            # expression row is several rows down — find "Expression Value"
            expr_row = []
            for row in block[attr_start:]:
                if any("Expression" in c and "Value" in c for c in row):
                    expr_row = row
                    break

            # Columns 1..N are the attributes
            for col in range(1, max(len(attr_header_row), len(derived_from_row))):
                attr_name = attr_header_row[col] if col < len(attr_header_row) else ""
                derived   = derived_from_row[col] if col < len(derived_from_row) else ""
                usage     = usage_row[col]     if col < len(usage_row)         else ""
                expr      = expr_row[col]      if col < len(expr_row)          else ""

                if attr_name and attr_name not in ("ELEMENT_IN_PAYLOAD", "FILENAME", "PAYLOAD_CONTAINS"):
                    dt["attributes_to_configure"].append({
                        "attribute_name": _canon_attr_name(attr_name),  # v79.78
                        "derived_from":   derived,
                        "usage":          usage,
                        "expression":     expr,
                    })

        return dt

    try:
        ws = wb["Document Types Configuration"]
        rows = _rows(ws)
        result["source_document_type"] = _parse_doc_type(rows, "Inbound")
        result["target_document_type"]  = _parse_doc_type(rows, "Output File")
    except Exception as e:
        result["source_document_type"] = {"_parse_error": str(e)}
        result["target_document_type"]  = {"_parse_error": str(e)}

    # ── Rules Configuration ────────────────────────────────────────────────────
    try:
        ws = wb["Rules Configuration"]
        rows = _rows(ws)
        conditions = []
        # Parse condition rows — look for repeating Condition Type / Operator / Value / Attribute
        cond_rows = _block(rows, "Section\tCondition", "Section\tActions")
        i = 0
        cur_cond: Dict[str, str] = {}
        for row in cond_rows:
            joined = "\t".join(row)
            if "Condition Type" in joined:
                if cur_cond:
                    conditions.append(cur_cond)
                    cur_cond = {}
                vals = [c for c in row if c]
                cur_cond["condition_type"] = vals[-1] if len(vals) > 1 else ""
            elif "Operator" in joined and "Execute" not in joined:
                vals = [c for c in row if c]
                cur_cond["operator"] = vals[-1] if len(vals) > 1 else ""
            elif row[0].lower() == "value" or (row and "Value" == next((c for c in row if c), "")):
                vals = [c for c in row if c]
                cur_cond["value"] = vals[-1] if len(vals) > 1 else ""
            elif "Attribute Name" in joined:
                vals = [c for c in row if c]
                cur_cond["attribute_name_unit"] = vals[-1] if len(vals) > 1 else ""
        if cur_cond:
            conditions.append(cur_cond)

        action_rows = _block(rows, "Section\tActions")
        result["rule"] = {
            "name":                       _val(rows, "Name\t"),
            "version":                    _val(rows, "Version\t"),
            "document_type_name_version": _val(rows, "Document type name"),
            "rule_type":                  _val(rows, "Rule Type"),
            "rule_scope":                 _val(rows, "Rule Scope"),
            "status":                     _val(rows, "Status"),
            "description":                _val(rows, "Description"),
            "conditions": {
                "execute_actions_when": _val(rows, "Execute Actions"),
                "rows": conditions,
            },
            "actions": {
                "action_name":                    _val(action_rows, "Name\t"),
                "action_type":                    _val(action_rows, "Type\t"),
                "mapping_identifier_name_version": _val(action_rows, "Mapping Identifier"),
            },
        }
    except Exception as e:
        result["rule"] = {"_parse_error": str(e)}

    # ── Transport Profile ──────────────────────────────────────────────────────
    def _parse_tp(rows, src_marker, system_type):
        # v79.77: For the SOURCE profile, stop at "Create Target". For the TARGET
        # profile, take everything to the end of the sheet — the Document(s)
        # Supported → Document Type row sits AFTER the SFTP-Server section, so
        # the old "stop at SFTP Server" boundary cut it off (target document_type
        # came back blank).
        if "Source" in src_marker:
            block = _block(rows, src_marker, "Create Target")
        else:
            block = _block(rows, src_marker)
        if not block:
            block = rows

        use_existing_folder = _val(block, "Use Exisitng Folder", "Use Existing Folder")
        tp: Dict[str, Any] = {
            "system_type":              system_type,
            "partner_name":             _val(block, "Partner Name"),
            "profile_name":             _val(block, "Profile Name"),
            "profile_usage":            _val(block, "Profile Usage"),
            "deployment_group":         _val(block, "Deployment Group"),
            "interface_type":           _val(block, "InterfaceType"),
            "interface_environment":    _val(block, "InterfaceEnvironment"),
            "existing_account":         _val(block, "Existing Account\t"),
            "existing_account_name":    _val(block, "Existing Account Name"),
            "use_existing_folder":      use_existing_folder,
            "post_transfer_action":     _val(block, "Post Transfer Action"),
            "is_compression_required":  _val(block, "Is Compression Required"),
            "document_type":            _val(block, "Document Type\t"),
        }
        # v79.77: ALWAYS capture subscription_folder + file_filtering_platform.
        # The manual lists these under "Existing Account - Yes" even when
        # use_existing_folder == "yes" (e.g. /tovan/XML/, /Test_ATEA, .*\*.).
        # The old code only captured them when use_existing_folder == "no", so
        # they were missing for this (and every existing-folder=yes) flow.
        # _val returns the FIRST matching row, which is the populated one under
        # "Existing Account - Yes" (the later "- No" rows are blank templates).
        _sub = _val(block, "Subscription Folder")
        _ff  = _val(block, "File Filtering Platform", "File Filtering Pattern")
        # Skip values that are just the field label / description noise
        def _clean(v):
            return "" if v.strip().lower() in ("folder assigned for subscriptions",
                                               "platform used for file filtering") else v
        tp["subscription_folder"]    = _clean(_sub)
        tp["file_filtering_platform"] = _clean(_ff)
        _existing = _val(block, "Existing Folders", "Existing Folder")
        if _existing and _existing.strip().lower() not in ("reuse already available folder",):
            tp["existing_folder"] = _existing

        return tp

    try:
        ws = wb["TransportProfile"]
        rows = _rows(ws)
        result["source_transport_profile"] = _parse_tp(rows, "Create Source", "Dell Application")
        result["target_transport_profile"]  = _parse_tp(rows, "Create Target", "Partner")
    except Exception as e:
        result["source_transport_profile"] = {"_parse_error": str(e)}
        result["target_transport_profile"]  = {"_parse_error": str(e)}

    # ── Biz Flows ──────────────────────────────────────────────────────────────
    try:
        ws = wb["Biz Flows"]
        rows = _rows(ws)

        # Flow identifiers
        fi_block = _block(rows, "Flow Identifiers", "EDI Acknowledgement")
        fi_operator = _val(fi_block, "Flow Identifier Operator")
        fi_conditions = []
        attr_block = _block(fi_block, "Attributes to Configure")
        # Parse pairs: doc_type, attr_name, operator, value
        cur: Dict[str, str] = {}
        for row in attr_block:
            joined = "\t".join(row)
            if "Document Type Name" in joined:
                if cur:
                    fi_conditions.append(cur)
                    cur = {}
                vals = [c for c in row if c]
                cur["document_type_name_version"] = vals[-1] if len(vals) > 1 else ""
            elif "Attribute Name" in joined:
                vals = [c for c in row if c]
                cur["attribute_name"] = _canon_attr_name(vals[-1] if len(vals) > 1 else "")  # v79.78
            elif "Operator" in joined and "Execute" not in joined and "Flow" not in joined:
                vals = [c for c in row if c]
                cur["operator"] = vals[-1] if len(vals) > 1 else ""
            elif "Value" in next((c for c in row if c), "") and "Environment" not in joined:
                vals = [c for c in row if c]
                cur["value"] = vals[-1] if len(vals) > 1 else ""
        if cur:
            fi_conditions.append(cur)

        # Configure targets block
        tgt_block = _block(rows, "Configure Target")
        proc_block = _block(tgt_block, "Process Steps", "Configure Routing")

        # v79.32: Multi-step parsing. Loop over every "Step Type" marker
        # in the process steps block. Each step extracts its own sub-config
        # (Mapping Configuration for Mapping Transformer, Enricher Configuration
        # for Enricher, etc.). Previously only the first step was captured.
        import re as _re_step
        process_steps: List[Dict[str, Any]] = []
        if proc_block:
            # Find all "Step Type" row indices to delimit each step's block
            _step_starts: List[int] = []
            for _i, _r in enumerate(proc_block):
                _first = next((c for c in _r if c), "").strip().lower()
                if _first == "step type" or _first.startswith("step type"):
                    _step_starts.append(_i)
            _step_starts.append(len(proc_block))  # sentinel for last slice

            for _step_idx, _start_i in enumerate(_step_starts[:-1]):
                _end_i = _step_starts[_step_idx + 1]
                _step_rows = proc_block[_start_i:_end_i]
                _s_type = _val(_step_rows, "Step Type")
                _s_name = _val(_step_rows, "Step Name")
                if not _s_type:
                    continue

                _cfg: Dict[str, Any] = {}
                _sl = _s_type.strip().lower()
                if "mapping" in _sl and "transformer" in _sl:
                    _cfg = {
                        "source_document_type":        _val(_step_rows, "Source Document Type"),
                        "action":                       _val(_step_rows, "Action"),
                        "target_document_type_version": _val(_step_rows, "Target Document Type"),
                        "rule_version":                 _val(_step_rows, "Rule"),
                        "add_rule_if_not_listed":       _val(_step_rows, "Add Rule"),
                    }
                elif "enricher" in _sl:
                    # Parse file_name_parts (each part = derived_from + value rows)
                    _fnp: List[Dict[str, Any]] = []
                    # Pass 1: collect derived_from per part
                    for _row in _step_rows:
                        _joined = "\t".join(_row).lower()
                        if "file name part" in _joined and "derived" in _joined:
                            _vals = [c for c in _row if c]
                            _m = _re_step.search(r"part\s*(\d+)", _joined)
                            if _m and len(_vals) >= 2:
                                _fnp.append({
                                    "part_number":  int(_m.group(1)),
                                    "derived_from": _vals[-1],
                                    "value":        "",
                                })
                    # Pass 2: fill values per part
                    for _row in _step_rows:
                        _joined = "\t".join(_row).lower()
                        # Match "File Name Part N — Value" but skip "Derived" rows
                        if ("file name part" in _joined
                                and "value" in _joined
                                and "derived" not in _joined):
                            _vals = [c for c in _row if c]
                            _m = _re_step.search(r"part\s*(\d+)", _joined)
                            if _m and len(_vals) >= 2:
                                _pn = int(_m.group(1))
                                for _p in _fnp:
                                    if _p["part_number"] == _pn:
                                        _p["value"] = _vals[-1]
                                        break
                    _cfg = {
                        "document_type_version":   _val(_step_rows, "Document Type"),
                        "action":                  _val(_step_rows, "Action"),
                        "target_file_name_config": _val(_step_rows, "Target File Name"),
                        "file_separator":          _val(_step_rows, "File Separator"),
                        "file_extension":          _val(_step_rows, "File Extension"),
                        "file_name_parts":         _fnp,
                    }
                # Other step types (Splitter, Router, Validator, etc.) get an
                # empty config — fill on demand when those flows appear.

                process_steps.append({
                    "step_number":   _step_idx + 1,
                    "step_type":     _s_type,
                    "step_name":     _s_name,
                    "configuration": _cfg,
                })

        # Configure routing
        # v79.76: Use _section_block for precise Conditions/Actions boundaries
        # (the words appear inside neighbouring descriptions, so the generic
        # _block over-matched and returned empty condition rows).
        routing_block = _block(rows, "Configure Routing")
        route_cond_rows = _section_block(routing_block, "Conditions", "Actions")
        route_action_block = _section_block(routing_block, "Actions")
        route_conditions = []
        cur_rc: Dict[str, str] = {}

        def _flush_rc():
            # Commit the current condition if it has any real content
            if cur_rc and any(v for v in cur_rc.values()):
                route_conditions.append(dict(cur_rc))

        for row in route_cond_rows:
            cells = [c for c in row if c]
            first = (cells[0].strip().lower() if cells else "")
            val = cells[-1] if len(cells) > 1 else ""
            if first.startswith("condition type"):
                # Start of a new condition block
                _flush_rc()
                cur_rc = {"condition_type": val}
            elif first.startswith("operator"):
                cur_rc["operator"] = val
            elif first.rstrip(":*").strip() == "value":
                cur_rc["value"] = val
            elif first.startswith("attribute name"):
                # v79.76: In the routing-conditions layout, Attribute Name is the
                # LAST field of each condition (order: Condition Type → Operator
                # → Value → Attribute Name). So set it, then flush + reset.
                cur_rc["attribute_name"] = _canon_attr_name(val)  # v79.78
                _flush_rc()
                cur_rc = {}
        _flush_rc()

        result["biz_flow"] = {
            "flow_details": {
                "current_flow_version": _val(rows, "Current Flow version"),
                "business_flow_name":   _val(rows, "Business Flow Name"),
                "flow_description":     _val(rows, "Flow Description"),
            },
            "configure_source": {
                "source_type":                _val(rows, "Source Type"),
                "source_application":         _val(rows, "Source Application"),
                "source_transport_profile":   _val(rows, "Source Transport Profile"),
                "document_type_name_version": _val(rows, "Document Type Name (Version)"),
            },
            "flow_identifiers": {
                "operator":   fi_operator,
                "conditions": fi_conditions,
            },
            "configure_targets": {
                "target_type":                _val(tgt_block, "Target Type"),
                "target_application":         _val(tgt_block, "Target Application"),
                "target_transport_profile":   _val(tgt_block, "Target Transport Profile"),
                "document_type_name_version": _val(tgt_block, "Document Type Name (Version)"),
            },
            "process_steps": process_steps,
            "configure_routing": {
                "rule": {
                    "name":                      _val(routing_block, "Name\t"),
                    "version":                   _val(routing_block, "Version\t"),
                    "document_type_name_version":_val(routing_block, "Document Type Name"),
                    "rule_type":                 _val(routing_block, "Rule Type"),
                    "rule_scope":                _val(routing_block, "Rule Scope"),
                    "status":                    _val(routing_block, "Status"),
                    "execute_always":            _val(routing_block, "Execute Always"),
                    "description":               _val(routing_block, "Description"),
                },
                "conditions": {
                    "execute_actions_when": _val(routing_block, "Execute Action"),
                    "rows": route_conditions,
                },
                "actions": {
                    "name":   _val(route_action_block, "Name\t"),
                    "type":   _val(route_action_block, "Type\t"),
                    "target": _val(route_action_block, "Target\t"),
                },
            },
        }
    except Exception as e:
        result["biz_flow"] = {"_parse_error": str(e)}

    wb.close()
    return result

def _coerce_section_dict(v: Any) -> Dict[str, Any]:
    """v79.90: Coerce an objects.* section to a dict. A section can legitimately
    be a LIST when a flow has multiple senders/receivers (one sender → 3
    receivers, etc.). Returns the first dict element of a list, or {} otherwise.
    Use this anywhere a section is accessed with .get() to avoid the runtime
    'list object has no attribute get' crash on multi-TP flows."""
    if isinstance(v, dict):
        return v
    if isinstance(v, list):
        for it in v:
            if isinstance(it, dict):
                return it
    return {}

def _looks_like_dell(value: str) -> bool:
    """True if a sender/receiver/system value identifies the Dell side."""
    if not value:
        return False
    v = str(value).strip().upper()
    return any(alias in v for alias in _DELL_IDENTITY_ALIASES)

def _detect_direction(objects: Dict[str, Any], flow_name: str = "") -> Dict[str, str]:
    """v79.81: Auto-detect flow direction from extracted Sender/Receiver evidence.

    Returns a dict: {direction, direction_source, direction_confidence}.
      • Inbound  → sender is Customer/Partner, receiver is Dell.
      • Outbound → sender is Dell, receiver is Customer/Partner.

    Priority (per spec direction_logic.auto_detection_rules):
      1. Sender=customer/partner & Receiver=Dell           → Inbound  (high)
      2. Sender=Dell & Receiver=customer/partner           → Outbound (high)
      3. Source/Target transport-profile system_type hints → (high/medium)
      4. Folder/file tokens IN/OUT/IB/OB                    → supporting (medium)
      5. Ambiguous                                         → no default (low)
    """
    stp = _coerce_section_dict(objects.get("source_transport_profile"))
    ttp = _coerce_section_dict(objects.get("target_transport_profile"))
    sdt_attrs = _coerce_section_dict(objects.get("source_document_type")).get("attributes_to_configure", []) or []

    # Pull Sender / Receiver attribute expressions/values if present
    def _attr(attrs, name):
        for a in attrs:
            if str(a.get("attribute_name", "")).strip().lower() == name:
                return str(a.get("expression", "") or a.get("value", "") or "")
        return ""

    # 1/2 — strongest signal: the transport-profile system_type pair.
    src_sys = str(stp.get("system_type", "") or "").strip()
    tgt_sys = str(ttp.get("system_type", "") or "").strip()
    src_is_dell = _looks_like_dell(src_sys) or src_sys.lower() == "dell application"
    tgt_is_dell = _looks_like_dell(tgt_sys) or tgt_sys.lower() == "dell application"
    src_is_partner = src_sys.lower() == "partner"
    tgt_is_partner = tgt_sys.lower() == "partner"

    if src_is_partner and tgt_is_dell:
        return {"direction": "Inbound", "direction_source": "transport system_type (Partner→Dell)", "direction_confidence": "high"}
    if src_is_dell and tgt_is_partner:
        return {"direction": "Outbound", "direction_source": "transport system_type (Dell→Partner)", "direction_confidence": "high"}

    # 3 — sender/receiver values from doc-type attributes or TP partner names.
    sender_val = _attr(sdt_attrs, "sender") or str(stp.get("partner_name", "") or "")
    receiver_val = _attr(sdt_attrs, "receiver") or str(ttp.get("partner_name", "") or "")
    sender_dell = _looks_like_dell(sender_val)
    receiver_dell = _looks_like_dell(receiver_val)
    if sender_dell and not receiver_dell:
        return {"direction": "Outbound", "direction_source": "sender/receiver evidence (sender=Dell)", "direction_confidence": "high"}
    if receiver_dell and not sender_dell:
        return {"direction": "Inbound", "direction_source": "sender/receiver evidence (receiver=Dell)", "direction_confidence": "high"}

    # 4 — folder/file naming tokens (supporting evidence only).
    up = (flow_name or "").upper()
    if any(tok in up for tok in ("_OB", "_OUT", "OUTBOUND", "_OB_")):
        return {"direction": "Outbound", "direction_source": "flow-name token (OB/OUT)", "direction_confidence": "medium"}
    if any(tok in up for tok in ("_IB", "_IN", "INBOUND", "_IN_")):
        return {"direction": "Inbound", "direction_source": "flow-name token (IB/IN)", "direction_confidence": "medium"}

    # 5 — ambiguous: no confident default; ask the human.
    return {"direction": "", "direction_source": "ambiguous — needs human confirmation", "direction_confidence": "low"}

def _apply_direction_to_objects(objects: Dict[str, Any], direction: str) -> None:
    """v79.81: Force source_type / target_type and transport system_type to
    match the chosen direction, and stamp the NEW shared deployment groups.

    Mutates `objects` in place. Per spec input_json_direction_mapping:
      Inbound : source_type=Partner,          target_type=Dell Application
      Outbound: source_type=Dell Application,  target_type=Partner
    All automation interfaces → hip-automation (fixed Dev-team rule).
    """
    d = (direction or "").strip().lower()
    # v79.109: LIST-SAFE — sections can be lists after the numbered-sheet
    # parser (multiple TPs / branches). Apply direction, profile_usage, and
    # deployment groups to EVERY item, preserving the original list shape.
    def _items_of(v) -> List[Dict[str, Any]]:
        if isinstance(v, list):
            return [x for x in v if isinstance(x, dict)]
        return [v] if isinstance(v, dict) else []

    stp_raw = objects.setdefault("source_transport_profile", {})
    ttp_raw = objects.setdefault("target_transport_profile", {})
    stp_items = _items_of(stp_raw)
    ttp_items = _items_of(ttp_raw)
    bf_raw = objects.setdefault("biz_flow", {})
    bf = _coerce_section_dict(bf_raw) if not isinstance(bf_raw, dict) else bf_raw
    cs = bf.setdefault("configure_source", {}) if isinstance(bf, dict) else {}
    ct = bf.setdefault("configure_targets", {}) if isinstance(bf, dict) else {}
    cs_items = _items_of(cs)
    ct_items = _items_of(ct)

    if d == "inbound":
        src_type, tgt_type = "Partner", "Dell Application"
    elif d == "outbound":
        src_type, tgt_type = "Dell Application", "Partner"
    else:
        src_type = tgt_type = None  # ambiguous — leave as-extracted

    if src_type:
        for _it in stp_items:
            _it["system_type"] = src_type
        for _it in cs_items:
            _it["source_type"] = src_type
    if tgt_type:
        for _it in ttp_items:
            _it["system_type"] = tgt_type
        for _it in ct_items:
            _it["target_type"] = tgt_type

    # Profile usage + the NEW shared deployment groups (always, per spec) —
    # applied to every source/target item (multi-branch flows included).
    for _it in stp_items:
        _it["profile_usage"] = "Sender"
        _it["deployment_group"] = HIP_AUTOMATION_GROUP
    for _it in ttp_items:
        _it["profile_usage"] = "Receiver"
        _it["deployment_group"] = HIP_AUTOMATION_GROUP

def _doc_type_name_version(dt) -> str:
    """Format an evidence-backed Document Type as ``NAME(version)``.

    V127 accuracy rule: a Document Type version is never fabricated.  When the
    source only proves a name, this helper returns an empty reference so the
    readiness/HITL layer asks the user for the missing version instead of
    silently manufacturing ``1``/``1.0``.
    """
    if isinstance(dt, list):
        dt = dt[0] if dt else {}
    if not isinstance(dt, dict):
        return ""
    nm = str(dt.get("name", "") or "").strip()
    v = str(dt.get("version", "") or "").strip()
    if not nm or not v:
        return ""
    if "(" in nm and nm.endswith(")"):
        return nm  # already NAME(version) from explicit evidence
    return f"{nm}({v})"

def _bf_party_type_for_partner(partner_name: str) -> str:
    """v79.158: verified across ALL customer configs — the biz_flow
    source_type/target_type for a side is 'Dell Application' when that side's
    transport-profile partner is 'AIC - DCE', otherwise 'Partner'. The application
    is the partner_name itself. Dash-robust: 'AIC – DCE' (en-dash), 'AIC-DCE',
    'AIC  DCE' all normalise to the Dell Application AIC - DCE."""
    norm = " ".join(str(partner_name).replace("\u2013", "-").replace("\u2014", "-")
                     .replace("-", " - ").split()).upper()
    return "Dell Application" if norm == "AIC - DCE" else "Partner"

def _derive_missing_biz_flow_and_transport_fields(objects: Dict[str, Any]) -> Dict[str, Any]:
    """v79.158 BUGFIX: the user-package manual parser does not emit
    biz_flow.configure_source / configure_targets, and a manual may leave the
    transport-profile document_type blank. When the agent regenerates input.json
    from such a manual it drops exactly those fields (the values a human had
    completed in the 'old file'). This fills ONLY the missing/blank ones, derived
    from the document types + transport profiles using the verified pattern
    (partner 'AIC - DCE' => Dell Application, else Partner; application =
    partner_name; passthrough reuses the source document type on the target side).
    Existing non-empty values are never overwritten."""
    def _first(x): return (x[0] if x else {}) if isinstance(x, list) else (x or {})
    src_nv = _doc_type_name_version(objects.get("source_document_type"))
    tgt_nv = _doc_type_name_version(objects.get("target_document_type")) or src_nv  # passthrough
    # 1. transport-profile document_type (fill blanks on every profile, incl. lists)
    def _fill_doc(tp, nv):
        if isinstance(tp, dict) and nv and not str(tp.get("document_type", "")).strip():
            tp["document_type"] = nv
    for key, nv in (("source_transport_profile", src_nv), ("target_transport_profile", tgt_nv)):
        tp = objects.get(key)
        if isinstance(tp, list):
            for t in tp: _fill_doc(t, nv)
        else:
            _fill_doc(tp, nv)
    # 2. biz_flow.configure_source / configure_targets
    bf = objects.get("biz_flow")
    if isinstance(bf, dict):
        s_tp = _first(objects.get("source_transport_profile"))
        t_tp = _first(objects.get("target_transport_profile"))
        if not bf.get("configure_source") and isinstance(s_tp, dict) and s_tp.get("profile_name"):
            bf["configure_source"] = {
                "source_type": _bf_party_type_for_partner(s_tp.get("partner_name", "")),
                "source_application": s_tp.get("partner_name", ""),
                "source_transport_profile": s_tp.get("profile_name", ""),
                "document_type_name_version": src_nv,
            }
        if not bf.get("configure_targets") and isinstance(t_tp, dict) and t_tp.get("profile_name"):
            bf["configure_targets"] = {
                "target_type": _bf_party_type_for_partner(t_tp.get("partner_name", "")),
                "target_application": t_tp.get("partner_name", ""),
                "target_transport_profile": t_tp.get("profile_name", ""),
                "document_type_name_version": tgt_nv,
            }
    return objects

def _deep_fill_from_human_feedback(objects: Dict[str, Any], customer_name: str,
                                   folder_name: str = "") -> Dict[str, Any]:
    """v79.158 BUGFIX: 'fill the human feedback from the old file which was in the
    folder'. If the customer already has a hand-completed input.json under
    customers/opentext_hip_sftp/<name>/, fill any field that is MISSING or BLANK in
    the freshly-parsed objects from that old file. Human-completed values are
    preserved; intentional non-empty values in the fresh parse are NOT overwritten."""
    base = Path("customers/opentext_hip_sftp")
    old = None
    for cand in (customer_name, folder_name, (folder_name or "").upper().replace(" ", "_")):
        if not cand: continue
        p = base / cand / "input.json"
        if p.exists():
            try:
                old = json.loads(p.read_text(encoding="utf-8")).get("objects", {})
                break
            except Exception:
                old = None
    if not isinstance(old, dict) or not old:
        return objects

    def _is_blank(v):
        return v is None or (isinstance(v, str) and not v.strip()) or v == {} or v == []

    def _merge(new, ref):
        if isinstance(ref, dict) and isinstance(new, dict):
            for k, rv in ref.items():
                if k.startswith("_"): continue
                if k not in new or _is_blank(new.get(k)):
                    new[k] = rv
                else:
                    new[k] = _merge(new[k], rv)
            return new
        if isinstance(new, dict) and not new and isinstance(ref, (dict, list, str)):
            return ref
        return new

    for okey, oval in old.items():
        if okey.startswith("_"): continue
        if okey not in objects or _is_blank(objects.get(okey)):
            objects[okey] = oval
        else:
            objects[okey] = _merge(objects[okey], oval)
    return objects

def _normalize_deep_extract_to_configure_schema(objects: Dict[str, Any]) -> Dict[str, Any]:
    """v79.158: the deep-extraction builder (_agt_build_full_config) emits a flat
    schema — biz_flow.source / biz_flow.target with transport_profile +
    doc_type_version, transport-profile 'supported_doc_type' and 'system_name'.
    The InputBuilder editor + the customer-folder input.json use
    configure_source / configure_targets + transport 'document_type' +
    'partner_name'. This maps the former onto the latter WITHOUT overwriting any
    value that already uses the canonical keys, so both builder paths converge."""
    def _first(x): return (x[0] if x else {}) if isinstance(x, list) else (x or {})
    # transport profiles: supported_doc_type -> document_type, system_name -> partner_name
    for key in ("source_transport_profile", "target_transport_profile"):
        tp = objects.get(key)
        for t in (tp if isinstance(tp, list) else [tp]):
            if not isinstance(t, dict):
                continue
            if not str(t.get("document_type", "")).strip():
                sd = str(t.get("supported_doc_type", "") or "").strip()
                doc_key = "source_document_type" if key == "source_transport_profile" else "target_document_type"
                evidence_ref = _doc_type_name_version(objects.get(doc_key))
                # A pre-combined supported_doc_type is explicit evidence.  A
                # bare name is not enough to invent a version.
                if evidence_ref:
                    t["document_type"] = evidence_ref
                elif sd and "(" in sd and sd.endswith(")"):
                    t["document_type"] = sd
            if not str(t.get("partner_name", "")).strip() and str(t.get("system_name", "")).strip():
                t["partner_name"] = t["system_name"]
    bf = objects.get("biz_flow")
    if isinstance(bf, dict):
        src = _first(bf.get("source"))
        tgt = _first(bf.get("target"))
        if not bf.get("configure_source") and isinstance(src, dict) and src:
            bf["configure_source"] = {
                "source_type": src.get("source_type") or _bf_party_type_for_partner(src.get("source_application", "")),
                "source_application": src.get("source_application", ""),
                "source_transport_profile": src.get("transport_profile", "") or src.get("source_transport_profile", ""),
                "document_type_name_version": src.get("doc_type_version", "") or src.get("document_type_name_version", ""),
            }
        if not bf.get("configure_targets") and isinstance(tgt, dict) and tgt:
            bf["configure_targets"] = {
                "target_type": tgt.get("target_type") or _bf_party_type_for_partner(tgt.get("target_application", "")),
                "target_application": tgt.get("target_application", ""),
                "target_transport_profile": tgt.get("transport_profile", "") or tgt.get("target_transport_profile", ""),
                "document_type_name_version": tgt.get("doc_type_version", "") or tgt.get("document_type_name_version", ""),
            }
        # flow_details normalisation (deep-extract uses flat flow_name/flow_description)
        if not bf.get("flow_details") and (bf.get("flow_name") or bf.get("flow_description")):
            bf["flow_details"] = {"business_flow_name": bf.get("flow_name", ""),
                                  "flow_description": bf.get("flow_description", ""),
                                  "current_flow_version": bf.get("current_flow_version", "")}
    return objects


def _normalize_profile_runner_v2_schema(objects: Dict[str, Any]) -> Dict[str, Any]:
    """Converge legacy deep-extraction keys to the uploaded Profile Runner v2 shape."""
    if not isinstance(objects, dict):
        return objects

    # Document type rows: Profile Runner v2 uses attribute_name.
    for key in ("source_document_type", "target_document_type"):
        vals = objects.get(key)
        for doc in (vals if isinstance(vals, list) else [vals]):
            if not isinstance(doc, dict):
                continue
            doc.setdefault("status", "Enable" if str(doc.get("name", "")).strip() else "")
            if "operation" not in doc and isinstance(doc.get("document_identifier"), dict):
                doc["operation"] = doc["document_identifier"].get("operation", "")
            for row in doc.get("attributes_to_configure", []) or []:
                if isinstance(row, dict) and "attribute_name" not in row and "name" in row:
                    row["attribute_name"] = row.pop("name")

    # Mapping rule: normalize names exactly to Profile Runner Ready schema.
    rules = objects.get("rule")
    for rule in (rules if isinstance(rules, list) else [rules]):
        if not isinstance(rule, dict):
            continue
        if "document_type_name_version" not in rule and rule.get("document_type_version"):
            rule["document_type_name_version"] = rule.pop("document_type_version")
        if str(rule.get("name", "")).strip().upper() not in ("", "NA"):
            rule.setdefault("status", "Enable")
            rule.setdefault("description", rule.get("name", ""))
        conds = rule.get("conditions")
        if isinstance(conds, dict):
            if "execute_actions_when" not in conds and conds.get("execute_when"):
                conds["execute_actions_when"] = conds.pop("execute_when")
            for row in conds.get("rows", []) or []:
                if not isinstance(row, dict):
                    continue
                if "attribute_name_unit" not in row:
                    if row.get("attribute_name") is not None:
                        row["attribute_name_unit"] = row.pop("attribute_name")
                    elif row.get("attribute") is not None:
                        row["attribute_name_unit"] = row.pop("attribute")
                row.setdefault("condition_type", "Attributes")
        acts = rule.get("actions")
        if isinstance(acts, dict):
            if "mapping_identifier_name_version" not in acts and acts.get("mapping_id_version"):
                acts["mapping_identifier_name_version"] = acts.pop("mapping_id_version")

    # Transport profile presentation/API keys.
    for key in ("source_transport_profile", "target_transport_profile"):
        vals = objects.get(key)
        for tp in (vals if isinstance(vals, list) else [vals]):
            if not isinstance(tp, dict):
                continue
            if "interface_environment" not in tp and tp.get("interface_env"):
                tp["interface_environment"] = tp.pop("interface_env")
            if "partner_name" not in tp and tp.get("system_name"):
                tp["partner_name"] = tp.get("system_name")

    bf = objects.get("biz_flow")
    if isinstance(bf, dict):
        # Process-step config -> configuration and canonical field names.
        for step in bf.get("process_steps", []) or []:
            if not isinstance(step, dict):
                continue
            if "configuration" not in step and isinstance(step.get("config"), dict):
                step["configuration"] = step.pop("config")
            c = step.get("configuration")
            if isinstance(c, dict):
                if "source_document_type" not in c and c.get("source_doc_type") is not None:
                    c["source_document_type"] = c.pop("source_doc_type")
                if "target_document_type_version" not in c and c.get("target_doc_type"):
                    t = str(c.pop("target_doc_type") or "").strip()
                    # Never turn a bare Document Type name into NAME(1.0).
                    c["target_document_type_version"] = t if "(" in t and t.endswith(")") else ""
                if "document_type_version" not in c and c.get("doc_type_version"):
                    c["document_type_version"] = c.pop("doc_type_version")
                if "add_rule_if_not_listed" not in c and step.get("step_type") == "Mapping Transformer":
                    c["add_rule_if_not_listed"] = "Not Enabled"
                if c.get("action") == "Enricher":
                    c["action"] = "Enrich"
                if "file_name_parts" not in c and isinstance(c.get("file_name_sections"), list):
                    c["file_name_parts"] = c.pop("file_name_sections")

        # Canonical routing: {rule, conditions, actions}.
        cr = bf.get("configure_routing")
        if isinstance(cr, dict) and "rule" not in cr and cr.get("rule_name"):
            rule_name = cr.get("rule_name", "")
            doc_nv = cr.get("doc_type_version", "")
            target = ""
            ct = bf.get("configure_targets")
            if isinstance(ct, dict):
                target = ct.get("target_transport_profile", "")
            elif isinstance(ct, list) and ct and isinstance(ct[0], dict):
                target = ct[0].get("target_transport_profile", "")
            conds = cr.get("conditions") if isinstance(cr.get("conditions"), dict) else {}
            if "execute_actions_when" not in conds and conds.get("execute_when"):
                conds["execute_actions_when"] = conds.pop("execute_when")
            for row in conds.get("rows", []) or []:
                if isinstance(row, dict):
                    row.setdefault("condition_type", "Attributes")
            old_actions = cr.get("actions") if isinstance(cr.get("actions"), dict) else {}
            bf["configure_routing"] = {
                "rule": {
                    "name": rule_name,
                    "version": cr.get("version", ""),
                    "document_type_name_version": doc_nv,
                    "rule_type": cr.get("rule_type", "Target Routing"),
                    "rule_scope": cr.get("rule_scope", "LOCAL"),
                    "status": "Enabled",
                    "execute_always": "Not Enabled",
                    "description": rule_name,
                },
                "conditions": conds,
                "actions": {
                    "name": old_actions.get("action_name", ""),
                    "type": old_actions.get("action_type", "Route Document"),
                    "target": target,
                },
            }

        # Remove legacy duplicate navigation keys after configure_* has been established.
        if bf.get("configure_source"):
            bf.pop("source", None)
        if bf.get("configure_targets"):
            bf.pop("target", None)
        if bf.get("flow_details"):
            bf.pop("flow_name", None)
            bf.pop("flow_description", None)
    return objects


def _normalize_receiver_spelling_in_objects(objects: Dict[str, Any]) -> Dict[str, Any]:
    """§12: canonicalize Sender/Receiver attribute-name spelling across every place the API
    reads it — source/target document-type attributes, rule condition rows, biz_flow
    flow_identifiers conditions, and configure_routing condition rows. Only the attribute_name
    key is touched; nothing else is changed."""
    def _fix(name: Any) -> Any:
        if not isinstance(name, str):
            return name
        key = " ".join(name.strip().lower().replace("-", " ").replace("_", " ").split())
        return _RECV_CANON_MAP.get(key, name)

    def _fix_rows(rows):
        if isinstance(rows, list):
            for r in rows:
                if isinstance(r, dict):
                    if "attribute_name" in r:
                        r["attribute_name"] = _fix(r.get("attribute_name"))
                    if "attribute_name_unit" in r:
                        r["attribute_name_unit"] = _fix(r.get("attribute_name_unit"))

    if not isinstance(objects, dict):
        return objects
    for dk in ("source_document_type", "target_document_type"):
        for d in (objects.get(dk) if isinstance(objects.get(dk), list) else [objects.get(dk)]):
            if isinstance(d, dict):
                _fix_rows(d.get("attributes_to_configure"))
    rule = objects.get("rule")
    for r in (rule if isinstance(rule, list) else [rule]):
        if isinstance(r, dict):
            conds = r.get("conditions")
            _fix_rows(conds.get("rows") if isinstance(conds, dict) else conds)
    bf = objects.get("biz_flow")
    if isinstance(bf, dict):
        fi = bf.get("flow_identifiers")
        if isinstance(fi, dict):
            c = fi.get("conditions")
            _fix_rows(c.get("rows") if isinstance(c, dict) else c)
        cr = bf.get("configure_routing")
        for routing in (cr if isinstance(cr, list) else [cr]):
            if isinstance(routing, dict):
                c = routing.get("conditions")
                _fix_rows(c.get("rows") if isinstance(c, dict) else c)
    return objects

def _blank_passthrough_target_document_type() -> Dict[str, Any]:
    """Canonical representation for the default Passthrough policy.

    Passthrough has one business document representation.  The target transport
    reuses the source Document Type; a second Target Document Type API is not
    created unless the user explicitly enables the exception flag.
    """
    return {
        "name": "", "transaction_type": "", "version": "", "data_format_type": "",
        "status": "", "description": "", "validation_type": "",
        "document_identifier": {"operation": "", "rows": []},
        "attributes_to_configure": [],
        "_passthrough": True,
        "_note": "Passthrough flow — no separate Target Document Type; target reuses Source Document Type.",
    }


def _infer_flow_type(objects: Dict[str, Any], explicit: str = "", requires_data_map: Any = None) -> str:
    """Determine Translation vs Passthrough without losing incomplete Translation flows.

    Priority: explicit user/input choice -> explicit requires_data_map -> any real
    mapping artifact/rule evidence -> Passthrough.  A partial map is still
    Translation so the agent asks for the missing JAR/rule instead of silently
    converting the flow to Passthrough.
    """
    raw = str(explicit or "").strip().lower().replace("-", "")
    if raw in {"translation", "mapping"}:
        return "translation"
    if raw in {"passthrough", "passthru", "passthroughflow", "pass through".replace(" ", "")}:
        return "passthrough"
    if requires_data_map is True:
        return "translation"
    if requires_data_map is False:
        return "passthrough"
    dm = objects.get("data_map") if isinstance(objects, dict) and isinstance(objects.get("data_map"), dict) else {}
    rule = objects.get("rule") if isinstance(objects, dict) and isinstance(objects.get("rule"), dict) else {}
    mapping_evidence = any(str(dm.get(k, "") or "").strip() for k in (
        "map_identifier", "map_name", "map_class", "map_data_file", "contivo_version"
    ))
    real_rule = str(rule.get("name", "") or "").strip().upper() not in {"", "NA", "N/A", "NOT APPLICABLE"}
    return "translation" if (mapping_evidence or real_rule) else "passthrough"


def _normalize_passthrough_objects(objects: Dict[str, Any], *, keep_target_document_type: bool = False) -> Dict[str, Any]:
    """Apply the strict Passthrough contract.

    Default Passthrough = one Document Type, no Data Map, no Mapping Rule and no
    Mapping Transformer.  A separate Target Document Type is retained only when
    the canonical top-level exception flag explicitly requests it.  Non-mapping
    process steps that were explicitly supplied (for example a customer-specific
    Enricher) are preserved; auto-generated Mapping Transformer steps are removed.
    """
    if not isinstance(objects, dict):
        return objects
    src_nv = _doc_type_name_version(objects.get("source_document_type"))

    objects["data_map"] = {
        "map_identifier": "", "map_identifier_version": "", "status": "",
        "map_name": "", "map_class": "", "contivo_version": "", "map_data_file": "",
        "_passthrough": True, "_note": "Passthrough flow — no data map required",
    }
    objects["rule"] = {
        "name": "NA", "version": "NA", "document_type_name_version": "NA",
        "rule_type": "NA", "rule_scope": "NA", "status": "NA", "description": "NA",
        "_passthrough": True, "_note": "Passthrough flow — no Mapping Rule required; routing is part of the Flow.",
    }
    if not keep_target_document_type:
        objects["target_document_type"] = _blank_passthrough_target_document_type()

    bf = objects.setdefault("biz_flow", {})
    if isinstance(bf, dict):
        steps = bf.get("process_steps") if isinstance(bf.get("process_steps"), list) else []
        bf["process_steps"] = [
            step for step in steps
            if isinstance(step, dict) and str(step.get("step_type") or step.get("type") or "").strip().lower()
            not in {"mapping transformer", "mappingtransformer", "mapping"}
        ]
        bf.setdefault("configure_routing", {})
        # Target side reuses the source Document Type unless the explicit exception is enabled.
        if src_nv and not keep_target_document_type:
            ct = bf.get("configure_targets")
            if isinstance(ct, dict):
                ct["document_type_name_version"] = src_nv
            elif isinstance(ct, list):
                for item in ct:
                    if isinstance(item, dict):
                        item["document_type_name_version"] = src_nv
            legacy_target = bf.get("target")
            if isinstance(legacy_target, dict):
                legacy_target["doc_type_version"] = src_nv

    # Both transport profiles reference the single Source Document Type by default.
    for key in ("source_transport_profile", "target_transport_profile"):
        tp = objects.get(key)
        for t in (tp if isinstance(tp, list) else [tp]):
            if isinstance(t, dict) and src_nv:
                if key == "target_transport_profile" and keep_target_document_type:
                    if not str(t.get("document_type", "")).strip():
                        t["document_type"] = _doc_type_name_version(objects.get("target_document_type")) or src_nv
                else:
                    t["document_type"] = src_nv
    return objects

def _normalize_translation_objects(objects: Dict[str, Any]) -> Dict[str, Any]:
    """§11: translation must follow the U-HAUL input(5).json schema — data_map, both document
    types, and a mapping rule are required; source TP doc = source doc, target TP doc = target
    doc; process_steps include Mapping Transformer (and Enricher when file-name generation
    exists); configure_routing present. Never overwrites a non-empty value."""
    if not isinstance(objects, dict):
        return objects
    src_nv = _doc_type_name_version(objects.get("source_document_type"))
    # Translation must have its own target Document Type.  Do not silently
    # reuse the source type; leaving this blank lets the unresolved-question/
    # contract layer block and ask the user for the real target definition.
    tgt_nv = _doc_type_name_version(objects.get("target_document_type"))
    # Translation source/target document references are distinct.  Correct any
    # earlier generic source fallback on the target side.  If target is still
    # unresolved, leave the reference blank so validation asks for it.
    for key, nv in (("source_transport_profile", src_nv), ("target_transport_profile", tgt_nv)):
        tp = objects.get(key)
        for t in (tp if isinstance(tp, list) else [tp]):
            if not isinstance(t, dict):
                continue
            if key == "target_transport_profile":
                t["document_type"] = nv or ""
            elif nv and not str(t.get("document_type", "")).strip():
                t["document_type"] = nv
    bf = objects.setdefault("biz_flow", {})
    if isinstance(bf, dict):
        ct = bf.get("configure_targets")
        if isinstance(ct, dict):
            ct["document_type_name_version"] = tgt_nv or ""
        elif isinstance(ct, list):
            for item in ct:
                if isinstance(item, dict):
                    item["document_type_name_version"] = tgt_nv or ""
        legacy_target = bf.get("target")
        if isinstance(legacy_target, dict):
            legacy_target["doc_type_version"] = tgt_nv or ""
        steps = bf.get("process_steps")
        have = {str(s.get("step_type", "")).strip() for s in steps if isinstance(s, dict)} if isinstance(steps, list) else set()
        if not isinstance(steps, list) or not have:
            steps = []
        if "Mapping Transformer" not in have:
            steps.append({"step_type": "Mapping Transformer"})
        if "Enricher" not in have:
            steps.append({"step_type": "Enricher"})
        bf["process_steps"] = steps
        bf.setdefault("configure_routing", {})
    return objects

def _input_builder_finalize_objects(objects: Dict[str, Any], customer_name: str = "",
                                    folder_name: str = "", direction: str = "",
                                    flow_type: str = "",
                                    requires_data_map: Any = None,
                                    passthrough_target_document_type_required: bool = False) -> Dict[str, Any]:
    """v79.158: single InputBuilder chokepoint for the SFTP-HAFT process. Runs for
    EVERY mode (Configuration Manual, ZIP/deep-extract, Folder, Existing Template,
    Single upload) so the produced input.json always has biz_flow
    configure_source / configure_targets and transport document_type — for
    translation flows (UHAUL-POASN, LEGRAND_NEDERLAND) and passthrough
    (ATEA_NORWAY) alike. Order: normalise deep-extract schema -> fill from the
    hand-completed old file in the folder -> derive any remaining gaps."""
    objects = _normalize_deep_extract_to_configure_schema(objects)
    objects = _deep_fill_from_human_feedback(objects, customer_name, folder_name)
    # derive transport document_type + biz_flow.configure_source/configure_targets (blanks only)
    objects = _derive_missing_biz_flow_and_transport_fields(objects)
    # v79.174 (§5/§6): direction — use the explicit choice when given, else auto-detect; then
    # overlay system_type + the shared deployment groups onto the already-derived objects.
    _dir = (direction or "").strip()
    if not _dir:
        _dir = (_detect_direction(objects, folder_name) or {}).get("direction", "")
    _apply_direction_to_objects(objects, _dir)
    # Flow applicability is a canonical rule shared by every intake mode.
    # Explicit user/input choice wins.  Otherwise any real mapping artifact or
    # mapping rule keeps an incomplete flow in Translation so the agent asks for
    # missing values rather than incorrectly downgrading it to Passthrough.
    _ft = _infer_flow_type(objects, flow_type, requires_data_map)
    if _ft == "translation":
        objects = _normalize_translation_objects(objects)
    else:
        objects = _normalize_passthrough_objects(
            objects,
            keep_target_document_type=bool(passthrough_target_document_type_required),
        )
    # Converge deep-extraction output to the same v2/Profile Runner Ready schema
    # used by the uploaded LEGRAND/ATEA manuals.
    objects = _normalize_profile_runner_v2_schema(objects)
    # v79.174 (§12): canonical Sender/Receiver spelling for API/Profile-Runner safety.
    objects = _normalize_receiver_spelling_in_objects(objects)
    return objects


def _profile_runner_value(value: Any, path: str = "") -> Any:
    """Coerce only schema-safe scalar types from Full_JSON_Flattened.

    The Profile Runner Ready workbooks intentionally store most values as text
    (including versions and transaction codes), so only top-level booleans are
    converted. Everything else is preserved exactly for API compatibility.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return value
    text = str(value)
    if path in {"requires_data_map", "human_confirmed_direction"}:
        if text.strip().lower() in {"true", "yes", "1"}:
            return True
        if text.strip().lower() in {"false", "no", "0"}:
            return False
    return text


def _path_tokens(path: str) -> List[Union[str, int]]:
    tokens: List[Union[str, int]] = []
    for part in str(path or "").split("."):
        if not part:
            continue
        m = re.match(r"^([^\[]+)", part)
        if m:
            tokens.append(m.group(1))
        for n in re.findall(r"\[(\d+)\]", part):
            tokens.append(int(n))
    return tokens


def _set_flattened_path(root: Dict[str, Any], path: str, value: Any) -> None:
    tokens = _path_tokens(path)
    if not tokens:
        return
    cur: Any = root
    parent: Any = None
    parent_key: Any = None
    for i, tok in enumerate(tokens):
        last = i == len(tokens) - 1
        nxt = tokens[i + 1] if not last else None
        if isinstance(tok, str):
            if not isinstance(cur, dict):
                replacement: Dict[str, Any] = {}
                if isinstance(parent, list) and isinstance(parent_key, int):
                    parent[parent_key] = replacement
                elif isinstance(parent, dict):
                    parent[parent_key] = replacement
                cur = replacement
            if last:
                cur[tok] = value
                return
            if tok not in cur or not isinstance(cur[tok], (dict, list)):
                cur[tok] = [] if isinstance(nxt, int) else {}
            parent, parent_key, cur = cur, tok, cur[tok]
        else:
            if not isinstance(cur, list):
                replacement = []
                if isinstance(parent, dict):
                    parent[parent_key] = replacement
                elif isinstance(parent, list) and isinstance(parent_key, int):
                    parent[parent_key] = replacement
                cur = replacement
            while len(cur) <= tok:
                cur.append(None)
            if last:
                cur[tok] = value
                return
            if cur[tok] is None or not isinstance(cur[tok], (dict, list)):
                cur[tok] = [] if isinstance(nxt, int) else {}
            parent, parent_key, cur = cur, tok, cur[tok]


def _parse_profile_runner_ready_xlsx(xlsx_bytes: bytes) -> Optional[Dict[str, Any]]:
    """Parse the v2 Profile Runner Ready workbook produced by this agent.

    The workbook's Full_JSON_Flattened sheet is deliberately lossless: column A
    is a dotted/indexed JSON path and column B is the final value. Reconstructing
    from this sheet avoids fragile assumptions about presentation-oriented rows
    in the individual review sheets.
    """
    import io as _io_prr
    try:
        from openpyxl import load_workbook as _lwb_prr
    except ImportError:
        return None
    try:
        wb = _lwb_prr(_io_prr.BytesIO(xlsx_bytes), read_only=True, data_only=True)
    except Exception:
        return None
    if "Full_JSON_Flattened" not in wb.sheetnames:
        return None
    ws = wb["Full_JSON_Flattened"]
    found_header = False
    cfg: Dict[str, Any] = {}
    rows_seen = 0
    for row in ws.iter_rows(values_only=True):
        pth = row[0] if len(row) > 0 else None
        val = row[1] if len(row) > 1 else None
        if str(pth or "").strip() == "Field Path":
            found_header = True
            continue
        if not found_header:
            continue
        pth = str(pth or "").strip()
        if not pth:
            continue
        _set_flattened_path(cfg, pth, _profile_runner_value(val, pth))
        rows_seen += 1
    if not rows_seen or not isinstance(cfg.get("objects"), dict):
        return None
    cfg.setdefault("_source", "Profile Runner Ready Configuration Manual — Full_JSON_Flattened")
    return cfg


def _config_manual_to_input_json(
    xlsx_bytes: bytes,
    folder_name: str = "",
) -> Dict[str, Any]:
    """
    Top-level entry: parse a Configuration Manual Excel and return the
    complete input.json dict (with profile_name, customer, objects, etc.)
    """
    # First-class support for the generated Profile Runner Ready workbook.
    # This is lossless and must be checked before the legacy/manual parsers.
    _prr = _parse_profile_runner_ready_xlsx(xlsx_bytes)
    if isinstance(_prr, dict):
        return _prr

    objects = _parse_config_manual_xlsx(xlsx_bytes)
    if "_error" in objects:
        return {"_error": objects["_error"]}

    # Derive customer and profile from flow name
    flow_name = (_coerce_section_dict(objects.get("biz_flow"))
                        .get("flow_details", {})
                        .get("business_flow_name", "")) if isinstance(
                            _coerce_section_dict(objects.get("biz_flow")).get("flow_details"), dict) else ""
    if not flow_name:
        _bf_fd = _coerce_section_dict(_coerce_section_dict(objects.get("biz_flow")).get("flow_details"))
        flow_name = _bf_fd.get("business_flow_name", "")
    customer = _coerce_section_dict(objects.get("source_transport_profile")).get("profile_name", "")
    # e.g. SFTP_TECHDATA_UK_PC_SRC_IB → TECHDATA_UK
    import re as _re_cm
    m = _re_cm.search(r'SFTP_(.+?)_(?:PC_|ANS_|SRC_|TGT_)', customer)
    customer_name = m.group(1) if m else (folder_name or "CUSTOMER")

    # v79.76: Passthrough detection. A flow is a PASSTHROUGH (no Contivo map)
    # when the Data Map section is empty / all-"NA", OR the flow name contains
    # PASS/PASSTHROUGH. Translation flows have a real map_identifier + map_name.
    # v79.109: LIST-SAFE — data_map can be a LIST (numbered sheets). Read one
    # representative for passthrough detection; the list itself is preserved.
    _dm = _coerce_section_dict(objects.get("data_map"))
    def _is_na(v):
        return (not v) or str(v).strip().upper() in ("NA", "N/A", "N\\A", "NONE", "")
    _map_id = _dm.get("map_identifier", "")
    _map_name = _dm.get("map_name", "")
    _flow_upper = flow_name.upper()
    _looks_passthrough = ("PASSTHROUGH" in _flow_upper or "_PASS_" in _flow_upper
                          or "_PASS" in _flow_upper)
    _has_real_map = (not _is_na(_map_id)) and (not _is_na(_map_name))
    _requires_data_map = _has_real_map and not _looks_passthrough
    _flow_type = "passthrough" if not _requires_data_map else "translation"

    # v79.76: For passthrough, normalise the data_map to clean empty values
    # (don't carry the "Checkbox / Toggle" label or stray "NA" noise).
    if not _requires_data_map and not isinstance(objects.get("data_map"), list):
        objects["data_map"] = {
            "map_identifier": "", "map_identifier_version": "",
            "status": "", "map_name": "", "map_class": "",
            "contivo_version": "", "map_data_file": "",
            "_note": "Passthrough flow — no Contivo data map required",
        }

    # v79.77: Derive tx_standard from the SOURCE document's data_format_type
    # instead of hardcoding "X12". The source format here is XML/cXML, not X12 —
    # tx_code stays the business transaction code (e.g. 850), but tx_standard
    # should reflect the actual file format. Map common formats; default to X12
    # only when the format is genuinely an EDI/X12 file.
    _src_fmt = (_coerce_section_dict(objects.get("source_document_type"))
                .get("data_format_type", "") or "").strip().upper()
    _fmt_to_standard = {
        "XML": "XML", "CXML": "cXML", "JSON": "JSON",
        "EDI": "X12", "X12": "X12", "EDIFACT": "EDIFACT",
        "FLATFILE": "FlatFile", "FLAT FILE": "FlatFile", "CSV": "CSV",
        "TXT": "FlatFile", "IDOC": "IDOC",
    }
    _tx_standard = _fmt_to_standard.get(_src_fmt, _src_fmt or "X12")

    # v79.81: Auto-detect direction from Sender/Receiver evidence (instead of
    # only the "_OB" token), then force source_type/target_type + the NEW
    # shared deployment groups to match. The detected direction can be
    # overridden by the human via the Inbound/Outbound button in the UI, which
    # re-runs _apply_direction_to_objects with the chosen value.
    _dir_info = _detect_direction(objects, flow_name)
    _direction = _dir_info["direction"] or ("Outbound" if "_OB" in flow_name else "Inbound")
    _apply_direction_to_objects(objects, _direction)

    # v79.158 BUGFIX (customer-reported): (1) fill any field the regeneration
    # dropped from the hand-completed "old file" in the customer folder, then
    # (2) derive transport document_type + biz_flow configure_source/configure_targets
    # for anything still missing (verified pattern; applies to passthrough too).
    objects = _deep_fill_from_human_feedback(objects, customer_name, folder_name)
    objects = _derive_missing_biz_flow_and_transport_fields(objects)

    return {
        "profile_name":      flow_name,
        "customer":          customer_name,
        "tx_standard":       _tx_standard,
        "tx_code":           _coerce_section_dict(objects.get("source_document_type")).get("transaction_type", ""),
        "source_format":     _src_fmt or "",
        "direction":         _direction,
        "direction_source":  _dir_info["direction_source"],
        "direction_confidence": _dir_info["direction_confidence"],
        "human_confirmed_direction": False,
        "requires_data_map": _requires_data_map,
        "flow_type":         _flow_type,
        "_source":           "Configuration Manual Excel — auto-parsed",
        "objects":           objects,
    }



    """Extract customer name, TX type/direction from a folder name.

    Folder naming patterns observed:
      'DOUGLAS_STEWART'              → customer=DOUGLAS_STEWART
      'U-HAUL - POACK'               → customer=UHAUL, tx_code=855, dir=Outbound
      'ATEA Sweden CO'               → customer=ATEA_SWEDEN_CO
      'WINONA HELATH (Remitra)'      → customer=WINONA_HEALTH (spelling fixed)
      'BLUMM USA INC'                → customer=BLUMM_USA
      'WILLMOTT DIXON (SFTP Outbound - BHC_B2BXML)' → customer=WILLMOTT_DIXON, B2BXML Outbound
    """
    import re as _r

    result: Dict[str, Any] = {
        "customer": "",
        "tx_standard": "",
        "tx_code": "",
        "direction": "",
    }

    # ── Detect TX type from folder name ────────────────────────────────────────
    fu = folder.upper()
    for pattern, std, code, direction in _FOLDER_TX_HINTS:
        if _r.search(pattern, fu):
            result.update({"tx_standard": std, "tx_code": code, "direction": direction})
            break

    # ── Detect direction from folder name keywords ─────────────────────────────
    if "OUTBOUND" in fu or " OB" in fu or "OB " in fu or fu.endswith(" OB"):
        result["direction"] = "Outbound"
    elif "INBOUND" in fu or " IB" in fu or "IB " in fu or fu.endswith(" IB"):
        result["direction"] = "Inbound"

    # ── Extract clean customer name ────────────────────────────────────────────
    # Remove TX-type tokens, direction tokens, platform names in parens
    clean = folder
    # Remove parenthetical suffixes: "(Remitra)", "(IBM Sterling)", "(SFTP Outbound - BHC_B2BXML)"
    clean = _r.sub(r'\s*\([^)]*\)', '', clean)
    # Remove " - POACK", " - POASN" etc.
    clean = _r.sub(r'\s*[-–]\s*(POACK|POASN|POMOD|POLIV|INVOICE|820|855|856|860|997|ASN|OB|IB)\b.*', '', clean, flags=_r.IGNORECASE)
    # Normalise: spaces/hyphens → underscore, strip multiple underscores
    clean = _r.sub(r'[\s\-]+', '_', clean.strip())
    clean = _r.sub(r'_+', '_', clean).strip('_').upper()

    # Common name fixes
    name_fixes = {
        "WINONA_HELATH": "WINONA_HEALTH",   # spelling in source
        "BLUUMUSA": "BLUMM_USA",
        "U_HAUL": "UHAUL",
        "U-HAUL": "UHAUL",
        "WILLMOTT_DIXON": "WILLMOTT_DIXON",
    }
    for wrong, right in name_fixes.items():
        clean = clean.replace(wrong, right)

    result["customer"] = clean
    return result

def _agt_detect_format(content: str, filename: str) -> str:
    ext = Path(filename).suffix.lower()
    c = content.strip()
    if c.startswith("ISA*") or (c.startswith("ISA") and "*" in c[:10]): return "X12 EDI"
    if c.startswith("UNB"): return "EDIFACT"
    if c.startswith("<?xml") or (c.startswith("<") and ">" in c[:60]): return "XML"
    if ext in (".jar",".xbm",".class"): return "Binary"
    if ext == ".xlsx": return "Excel"
    if ext in (".csv",) or (ext==".txt" and ","  in c[:200]): return "CSV"
    if c.startswith("{") or c.startswith("["): return "JSON"
    return "Text"

def _agt_from_foldername(folder: str) -> Dict[str, str]:
    """Parse a transaction folder name into structured hints.

    Folder names follow conventions like:
        ATEA_NORWAY_IN_PASSTHROUGH       → customer=ATEA_NORWAY, direction=IN, type=PASSTHROUGH
        LEGRAND_NEDERLAND_PO_OUT_850     → customer=LEGRAND_NEDERLAND, direction=OUT, tx_code=850
        UHAUL_POASN                       → customer=UHAUL, tx_code=POASN, direction=auto
        DELL_PO_INBOUND_XML_DESADV        → customer=DELL, direction=IN, tx_code=DESADV

    Returns a dict with shape:
        {customer, tx_standard, tx_code, direction, doc_type_hint, flow_type}

    Defaults the customer to the folder name itself if no parsing succeeds, so
    downstream code never has to handle a missing 'customer' key.
    """
    name = (folder or "").strip()
    out: Dict[str, str] = {
        "customer": name,
        "tx_standard": "",
        "tx_code": "",
        "direction": "",
        "doc_type_hint": "",
        "flow_type": "",
    }
    if not name:
        return out

    upper = name.upper()
    parts = [p for p in upper.replace("-", "_").replace(" ", "_").split("_") if p]

    # ── Direction (IN / OUT / INBOUND / OUTBOUND / SRC / TGT / IB / OB) ──
    dir_map = {
        "IN": "INBOUND", "INBOUND": "INBOUND", "IB": "INBOUND",
        "SRC": "INBOUND", "SOURCE": "INBOUND", "RECV": "INBOUND",
        "OUT": "OUTBOUND", "OUTBOUND": "OUTBOUND", "OB": "OUTBOUND",
        "TGT": "OUTBOUND", "TARGET": "OUTBOUND", "SEND": "OUTBOUND",
    }
    direction_idx = -1
    for i, p in enumerate(parts):
        if p in dir_map:
            out["direction"] = dir_map[p]
            direction_idx = i
            break

    # ── Flow type (PASSTHROUGH / TRANSLATION / MAPPING) ──────────────────
    flow_keywords = {
        "PASSTHROUGH": "PASSTHROUGH", "PASS": "PASSTHROUGH",
        "TRANSLATION": "TRANSLATION", "TRANSLATE": "TRANSLATION",
        "MAPPING": "TRANSLATION", "MAP": "TRANSLATION",
        "ENRICHMENT": "ENRICHMENT", "ENRICH": "ENRICHMENT",
    }
    for p in parts:
        if p in flow_keywords:
            out["flow_type"] = flow_keywords[p]
            break

    # ── Transaction code (EDI numeric or document keyword) ───────────────
    # Numeric EDI codes
    for p in parts:
        if p.isdigit() and 3 <= len(p) <= 4:
            out["tx_code"] = p
            out["tx_standard"] = "X12"
            break

    # Document-type keywords (common HIP transaction types)
    doc_keywords = [
        "POASN", "ASN", "POACK", "POAR", "POMOD", "PO", "ORDER", "ORDERS",
        "ORDRSP", "INVOICE", "INVOIC", "REMADV", "DESADV", "SHIPMENT",
        "RECADV", "OSTRPT", "OSTENQ", "CATALOG", "PRICAT",
    ]
    for p in parts:
        if p in doc_keywords:
            if not out["tx_code"]:
                out["tx_code"] = p
            out["doc_type_hint"] = p
            # If no EDI standard set and we see an EDIFACT-style keyword
            if not out["tx_standard"] and p in ("ORDRSP", "INVOIC", "DESADV",
                                                  "REMADV", "RECADV", "OSTRPT",
                                                  "OSTENQ", "PRICAT"):
                out["tx_standard"] = "EDIFACT"
            break

    # ── XML / EDI / X12 hint ─────────────────────────────────────────────
    if not out["tx_standard"]:
        if "XML" in upper:
            out["tx_standard"] = "XML"
        elif "EDI" in parts or "X12" in upper:
            out["tx_standard"] = "X12"
        elif "EDIFACT" in upper:
            out["tx_standard"] = "EDIFACT"

    # ── Customer = everything BEFORE direction/keyword markers ───────────
    # Cut off at the first direction or flow marker found
    cutoff = len(parts)
    if direction_idx >= 0:
        cutoff = min(cutoff, direction_idx)
    for i, p in enumerate(parts):
        if (p in flow_keywords or p in doc_keywords or
                (p.isdigit() and 3 <= len(p) <= 4) or
                p in ("XML", "EDI", "X12", "EDIFACT")):
            cutoff = min(cutoff, i)
            break

    if cutoff > 0:
        customer_parts = parts[:cutoff]
        # Preserve original case if possible
        original_parts = [p for p in name.replace("-", "_").replace(" ", "_").split("_") if p]
        if len(original_parts) == len(parts):
            customer_parts = original_parts[:cutoff]
        out["customer"] = "_".join(customer_parts) or name

    return out

def _agt_from_filename(fname: str) -> Dict[str, str]:
    stem = Path(fname).stem; ext = Path(fname).suffix.lower(); info: Dict[str,str] = {}
    if ext==".jar" and stem.startswith("Transform_"):
        info.update({"map_class":stem,"map_name":stem[len("Transform_"):],"map_data_file":fname,"artifact_type":"contivo_jar"})
        for code in ["850","855","856","810","820","997","ORDERS","ORDRSP","DESADV","INVOIC","REMADV"]:
            if code in stem.upper(): info["tx_code_hint"]=code; break
    elif ext==".xbm":
        info.update({"map_name":stem,"artifact_type":"contivo_xbm"})
    elif ext==".xlsx" and "configuration" in stem.lower():
        parts=stem.replace("Configuration_Manual_","").replace("-","_").split("_")
        if parts: info["customer"]=parts[0]
        if len(parts)>1: info["flow_hint"]="_".join(parts[1:])
        info["artifact_type"]="config_manual"
    elif ext in (".edi",".x12"):
        info["artifact_type"]="edi_payload"
    elif ext==".xml":
        info["artifact_type"]="xml_payload"
        parts=stem.split("_")
        if parts: info["partner_hint"]=parts[0]
        for kw in ("POAR","POACK","POMOD","POA","855","856","850","810"):
            if kw in stem.upper(): info["doc_type_hint"]=kw; break
    return info

def _agt_parse_edi(content: str) -> Dict[str,str]:
    result:Dict[str,str]={}; segs={}
    for raw in content.split("~"):
        raw=raw.strip()
        if raw: parts=raw.split("*"); segs.setdefault(parts[0].strip(),parts[1:])
    isa=segs.get("ISA",[])
    if len(isa)>=9:
        result.update({"isa_sender_qualifier":isa[4].strip() if len(isa)>4 else "","isa_sender_id":isa[5].strip() if len(isa)>5 else "","isa_receiver_qualifier":isa[6].strip() if len(isa)>6 else "","isa_receiver_id":isa[7].strip() if len(isa)>7 else "","isa_version":isa[11].strip() if len(isa)>11 else "00401","isa_test_indicator":isa[14].strip() if len(isa)>14 else "T","isa_component_sep":isa[15].strip() if len(isa)>15 else ">"})
    gs=segs.get("GS",[]); result.update({"gs_functional_id":gs[0].strip() if gs else "","gs_sender":gs[1].strip() if len(gs)>1 else "","gs_receiver":gs[2].strip() if len(gs)>2 else "","gs_version":gs[7].strip() if len(gs)>7 else "004010"}) if gs else None
    st_seg=segs.get("ST",[]); result["tx_set_code"]=st_seg[0].strip() if st_seg else ""
    bak=segs.get("BAK",[]); result["po_number"]=bak[2].strip() if len(bak)>2 else ""
    for raw in content.split("~"):
        raw=raw.strip()
        if raw.startswith("REF*"):
            p=raw.split("*")
            if len(p)>=3:
                if p[1].strip()=="IA": result["ref_ia"]=p[2].strip()
                if p[1].strip()=="CO": result["ref_co"]=p[2].strip()
                result.setdefault("ref_value",p[2].strip())
    return result

def _agt_parse_xml(content: str) -> Dict[str,str]:
    """v79.51: Generic XML extraction — handles DellPOA, PurchaseOrderCollection,
    PurchaseOrder, cXML, and unknown roots. Always extracts buyer, seller,
    PO number, currency, country from wherever they appear."""
    result:Dict[str,str]={}
    try:
        # Detect encoding — some payloads are iso-8859-1
        raw = content.encode("utf-8") if isinstance(content, str) else content
        # Strip BOM if present
        if raw[:3] == b"\xef\xbb\xbf": raw = raw[3:]  # v79.53: correct UTF-8 BOM bytes
        # Try to parse; if UTF-8 fails try latin-1 round-trip
        try:
            root = _ET_agt.fromstring(raw)
        except Exception:
            try:
                root = _ET_agt.fromstring(content.encode("latin-1"))
            except Exception:
                root = _ET_agt.fromstring(content.strip())

        result["root_element"] = root.tag

        def _f(*paths):
            for p in paths:
                el = root.find(p)
                if el is not None and el.text and el.text.strip():
                    return el.text.strip()
                # Also search recursively
                el = root.find(".//" + p.lstrip("/").split("/")[0])
                if el is not None:
                    el2 = root.find(p)
                    if el2 is not None and el2.text:
                        return el2.text.strip()
            return ""

        def _fa(*paths):
            """Find first non-empty text recursively."""
            for p in paths:
                # Try absolute path
                el = root.find(p) if not p.startswith(".//") else root.find(p)
                if el is not None and el.text and el.text.strip():
                    return el.text.strip()
            return ""

        rt = root.tag

        # ── DellPOA (O2C Dell outbound) ──────────────────────────────────────
        if "DellPOA" in rt or "DellPOA" in content[:200]:
            result.update({
                "partner_id":    _fa(".//PartnerInformation/To/PartnerIdentifier", ".//PartnerInformation/To/PartnerName"),
                "sender_id":     _fa(".//PartnerInformation/From/PartnerName"),
                "receiver_name": _fa(".//PartnerInformation/To/PartnerName"),
                "po_number":     _fa(".//PurchaseOrderNumber"),
                "dell_po_id":    _fa(".//DellPurchaseId"),
                "vendor_number": _fa(".//InternalVendorNumber"),
                "doc_type":      "DellPOA",
            })

        # ── PurchaseOrderCollection (Coupa/CIN inbound P2P) ─────────────────
        elif rt == "PurchaseOrderCollection":
            result.update({
                "buyer_name":    root.findtext(".//BuyerParty/CompanyName", "").strip(),
                "buyer_company": root.findtext(".//BuyerParty/Company", "").strip(),
                "seller_name":   root.findtext(".//SellerParty/SupplierName", "").strip(),
                "receiver_name": root.findtext(".//BuyerParty/CompanyName", "").strip(),
                "sender_id":     root.findtext(".//SellerParty/SupplierName", "").strip(),
                "po_number":     root.findtext(".//PurchaseOrderNo", "").strip(),
                "currency":      root.findtext(".//Currency", "").strip(),
                "vat_no":        root.findtext(".//BuyerParty/VatNo", "").strip(),
                "buyer_email":   root.findtext(".//BuyerParty/Email", "").strip(),
                "buyer_address": root.findtext(".//BuyerParty/CompanyAddress1", "").strip(),
                "payment_terms": root.findtext(".//PaymentTermName", "").strip(),
                "total_amount":  root.findtext(".//TotalAmount", "").strip(),
                "doc_type":      "PurchaseOrderCollection",
                # Derive country from VAT number prefix (NL → Netherlands, etc.)
                "country":       (root.findtext(".//BuyerParty/VatNo", "") or "")[:2].upper(),
            })
            # partner_id = buyer company code for ISA-style routing
            result["partner_id"] = result.get("buyer_company", "")

        # ── PurchaseOrder (Dell CIP target / xCBL) ───────────────────────────
        elif rt == "PurchaseOrder":
            result.update({
                "buyer_name":    root.findtext(".//NameAddress/Name1", "").strip(),
                "receiver_name": root.findtext(".//NameAddress/Name1", "").strip(),
                "buyer_address": root.findtext(".//NameAddress/Address1", "").strip(),
                "po_number":     root.findtext(".//RefNum", "").strip(),
                "sender_id":     "DELL",
                "partner_id":    root.findtext(".//NameAddress/Name1", "").strip(),
                "doc_type":      "PurchaseOrder",
            })

        # ── cXML (Ariba) ─────────────────────────────────────────────────────
        elif rt == "cXML":
            result.update({
                "receiver_name": root.findtext(".//To/Credential/Identity", "").strip(),
                "sender_id":     root.findtext(".//From/Credential/Identity", "").strip(),
                "partner_id":    root.findtext(".//To/Credential/Identity", "").strip(),
                "po_number":     (root.find(".//OrderRequestHeader") or root).get("orderID", ""),
                "doc_type":      "cXML",
            })

        # ── Generic fallback ─────────────────────────────────────────────────
        else:
            # Try common field names across any XML.  Routing identifiers are
            # evidence for Rule/Flow conditions only; they are deliberately
            # kept separate from Partner Create's Dev-approved DUNS/value.
            routing = root.find(".//ROUTING")
            if routing is not None:
                destination = str(
                    routing.get("destination_value")
                    or routing.get("destinationValue")
                    or routing.get("receiver_value")
                    or routing.get("receiverValue")
                    or ""
                ).strip()
                source_value = str(
                    routing.get("source_value")
                    or routing.get("sourceValue")
                    or routing.get("sender_value")
                    or routing.get("senderValue")
                    or ""
                ).strip()
                if destination:
                    result["partner_id"] = destination
                    result.setdefault("receiver_name", destination)
                    result["routing_destination_value"] = destination
                if source_value:
                    result["sender_id"] = source_value
                    result["routing_source_value"] = source_value
                document_name = str(routing.get("document_name") or routing.get("documentName") or "").strip()
                if document_name:
                    # Keep as evidence only.  Do not infer HIP Document Type
                    # name/version from a business payload label.
                    result["routing_document_name"] = document_name

            for try_buyer in (".//BuyerName", ".//CompanyName", ".//Name1", ".//CustomerName", ".//buyer"):
                v = root.findtext(try_buyer, "").strip()
                if v: result["receiver_name"] = v; result["buyer_name"] = v; break
            for try_seller in (".//SellerName", ".//SupplierName", ".//VendorName", ".//seller"):
                v = root.findtext(try_seller, "").strip()
                if v: result["sender_id"] = v; result["seller_name"] = v; break
            for try_po in (".//PurchaseOrderNo", ".//PONumber", ".//OrderNumber", ".//RefNum"):
                v = root.findtext(try_po, "").strip()
                if v: result["po_number"] = v; break
            result["doc_type"] = rt

    except Exception as e:
        result["parse_error"] = str(e)
    return result


def _agt_canonical_data_format(fmt: str) -> str:
    """Convert a sniffed file format into the HIP Document Type format value.

    Physical file evidence is authoritative for Document Type format.  A business
    transaction code such as 850 must never turn an uploaded XML file into EDIX12.
    """
    raw = str(fmt or "").strip().upper()
    return {
        "XML": "XML",
        "CXML": "cXML",
        "X12 EDI": "EDIX12",
        "X12": "EDIX12",
        "EDI": "EDIX12",
        "EDIX12": "EDIX12",
        "EDIFACT": "EDIFACT",
        "CSV": "CSV",
        "JSON": "JSON",
        "TEXT": "FlatFile",
        "TXT": "FlatFile",
        "FLATFILE": "FlatFile",
        "FLAT FILE": "FlatFile",
    }.get(raw, "")


def _agt_filename_tokens(filename: str) -> List[str]:
    stem = Path(str(filename or "")).stem.upper()
    return [x for x in re.split(r"[^A-Z0-9]+", stem) if x]


def _agt_payload_role_scores(filename: str, learned_role_tokens: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Score a payload filename as source/target/comparison evidence.

    Literal SRC/SOURCE and TGT/TARGET markers have the strongest weight.  Learned
    tokens from previously paired input.json + customer-file examples are only a
    tie-breaker; they never override an explicit marker.
    """
    toks = set(_agt_filename_tokens(filename))
    upper = str(filename or "").upper()
    src = 0
    tgt = 0
    comparison = 0
    reasons: List[str] = []

    hard_src = {"SRC": 12, "SOURCE": 12, "INPUT": 7, "REQUEST": 4}
    hard_tgt = {"TGT": 12, "TARGET": 12, "OUTPUT": 7, "EXPECTED": 7, "RESULT": 4, "RESPONSE": 4}
    for tok, weight in hard_src.items():
        if tok in toks:
            src += weight; reasons.append(f"source marker {tok}")
    for tok, weight in hard_tgt.items():
        if tok in toks:
            tgt += weight; reasons.append(f"target marker {tok}")
    if "COMPARE" in toks or "COMPARISON" in toks:
        comparison += 12
        tgt += 2
        reasons.append("comparison/output validation marker")

    learned = learned_role_tokens or {}
    src_learned = {str(x).upper() for x in (learned.get("source_tokens") or [])}
    tgt_learned = {str(x).upper() for x in (learned.get("target_tokens") or [])}
    for tok in toks:
        if tok in src_learned and tok not in hard_src:
            src += 6; reasons.append(f"learned source token {tok}")
        if tok in tgt_learned and tok not in hard_tgt:
            tgt += 6; reasons.append(f"learned target token {tok}")

    # Prefixes without separators are still common in customer payload names.
    if re.match(r"^(SRC|SOURCE)[_-]?", upper):
        src += 12
    if re.match(r"^(TGT|TARGET)[_-]?", upper):
        tgt += 12
    return {"source": src, "target": tgt, "comparison": comparison, "reasons": reasons}


def _agt_build_payload_role_evidence(file_contents: Dict[str, str], learned_role_tokens: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Inspect uploaded payloads and identify physical source/target files.

    This deliberately separates *business transaction semantics* (e.g. 850) from
    *physical payload format* (XML/X12/EDIFACT/etc.).  If role evidence is
    ambiguous we report it instead of fabricating EDI from the transaction code.
    """
    payloads: List[Dict[str, Any]] = []
    for fname, content in file_contents.items():
        fmt = _agt_detect_format(content, fname)
        canonical = _agt_canonical_data_format(fmt)
        if not canonical:
            continue
        scores = _agt_payload_role_scores(fname, learned_role_tokens)
        parsed: Dict[str, Any] = {}
        if fmt == "XML":
            parsed = _agt_parse_xml(content)
        elif fmt == "X12 EDI":
            parsed = _agt_parse_edi(content)
        elif fmt == "EDIFACT":
            parsed = {"standard": "EDIFACT"}
        payloads.append({
            "filename": fname,
            "sniffed_format": fmt,
            "data_format_type": canonical,
            "source_score": scores["source"],
            "target_score": scores["target"],
            "comparison_score": scores["comparison"],
            "reasons": scores["reasons"],
            "root_element": parsed.get("root_element", ""),
            "parsed": parsed,
        })

    non_comparison = [p for p in payloads if p.get("comparison_score", 0) < 10]
    source = None
    target = None
    source_candidates = sorted(non_comparison, key=lambda x: (x.get("source_score", 0), -x.get("target_score", 0)), reverse=True)
    target_candidates = sorted(non_comparison, key=lambda x: (x.get("target_score", 0), -x.get("source_score", 0)), reverse=True)
    if source_candidates and source_candidates[0].get("source_score", 0) >= 6:
        source = source_candidates[0]
    if target_candidates and target_candidates[0].get("target_score", 0) >= 6:
        target = target_candidates[0]
    if source is target:
        target = None

    # Fill the opposite side only when the remaining candidate is unambiguous.
    if source and not target:
        remaining = [p for p in non_comparison if p is not source]
        if len(remaining) == 1:
            target = remaining[0]
    if target and not source:
        remaining = [p for p in non_comparison if p is not target]
        if len(remaining) == 1:
            source = remaining[0]
    if not source and len(non_comparison) == 1:
        source = non_comparison[0]

    distinct_formats = sorted({p.get("data_format_type") for p in non_comparison if p.get("data_format_type")})
    source_format = source.get("data_format_type", "") if source else (distinct_formats[0] if len(distinct_formats) == 1 else "")
    target_format = target.get("data_format_type", "") if target else (distinct_formats[0] if len(distinct_formats) == 1 and len(non_comparison) > 1 else "")

    ambiguous = bool(non_comparison) and not source_format
    warnings: List[str] = []
    if ambiguous:
        warnings.append("Could not prove which uploaded payload is the source. Source Document Type format is left unresolved instead of being inferred from the transaction code.")
    if len(non_comparison) > 1 and not target_format:
        warnings.append("Could not prove which uploaded payload is the target. Target Document Type format is left unresolved until the user confirms it.")

    def _public(entry: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not entry:
            return {}
        return {k: entry.get(k) for k in ("filename", "sniffed_format", "data_format_type", "root_element", "source_score", "target_score", "reasons")}

    return {
        "payload_count": len(payloads),
        "payloads": [_public(p) for p in payloads],
        "source": _public(source),
        "target": _public(target),
        "source_format": source_format,
        "target_format": target_format,
        "source_root": (source or {}).get("root_element", ""),
        "target_root": (target or {}).get("root_element", ""),
        "all_payload_formats": distinct_formats,
        "ambiguous": ambiguous,
        "warnings": warnings,
    }

def _agt_detect_tx(content: str, fmt: str, fn_info: Dict) -> Dict[str,str]:
    result={"standard":"","code":"","name":"","direction":"","flow":""}
    code_hint=fn_info.get("tx_code_hint","")
    if code_hint:
        for (std,code),tx in AGT_TX_CATALOGUE.items():
            if code_hint==code: result.update({"standard":std,"code":code,"name":tx["name"]}); break
    if fmt=="X12 EDI":
        edi=_agt_parse_edi(content); tx_code=edi.get("tx_set_code","")
        if tx_code: result["code"]=tx_code; result["standard"]="X12"
        for (std,code),tx in AGT_TX_CATALOGUE.items():
            if std=="X12" and code==tx_code: result["name"]=tx["name"]; break
        result["direction"]="Inbound"
    elif fmt=="EDIFACT":
        for code in ["ORDERS","ORDRSP","DESADV","INVOIC","REMADV","CONTRL","APERAK"]:
            if code in content[:500]: result["code"]=code; result["standard"]="EDIFACT"; break
        result["direction"]="Inbound"
    elif fmt=="XML":
        xml=_agt_parse_xml(content); root=str(xml.get("root_element","") or "").split("}")[-1]
        # Transaction semantics come from the actual XML root.  Do not use the
        # generic word "Order" to turn every PurchaseOrder into an 855.
        root_key = re.sub(r"[^a-z0-9]", "", root.lower())
        xml_tx = {
            "purchaseordercollection": ("850", "Purchase Order"),
            "purchaseorder": ("850", "Purchase Order"),
            "dellpoa": ("855", "Order Acknowledgment"),
            "orderacknowledgement": ("855", "Order Acknowledgment"),
            "orderacknowledgment": ("855", "Order Acknowledgment"),
            "poacknowledgment": ("855", "Order Acknowledgment"),
            "shipmentnotice": ("856", "Advance Ship Notice"),
            "advanceshipnotice": ("856", "Advance Ship Notice"),
            "invoice": ("810", "Invoice"),
        }
        if root_key in xml_tx:
            code, name = xml_tx[root_key]
            result.update({"standard":"XML", "code":code, "name":name})
        else:
            # Conservative keyword fallback for well-known roots only.
            for hint, code, name in [("asn","856","Advance Ship Notice"),("shipment","856","Advance Ship Notice"),("invoice","810","Invoice"),("ack","855","Order Acknowledgment")]:
                if hint in root_key:
                    result.update({"standard":"XML", "code":code, "name":name}); break
        result["direction"]="Outbound"
    elif fmt=="CSV":
        result.update({"standard":"CSV","code":"CSV_PO","name":"CSV Purchase Order","direction":"Inbound"})
    if result["standard"] and result["code"] and result["direction"]:
        result["flow"]=f"XML → {result['standard']} {result['code']}" if result["direction"]=="Outbound" else f"{result['standard']} {result['code']} → XML"
    return result

def _agt_analyze_all_files(file_contents: Dict[str,str], learned_role_tokens: Optional[Dict[str, Any]] = None) -> Dict[str,Any]:
    analysis: Dict[str, Any] = {
        "files": [], "cfg": {}, "edi_data": {}, "xml_data": {},
        "source_edi_data": {}, "target_edi_data": {},
        "source_xml_data": {}, "target_xml_data": {},
        "customer": "", "flow_hint": "", "partner": "",
        "map_name": "", "map_class": "", "map_data_file": "",
        "detected_tx": {}, "src_payloads": [], "tgt_payloads": [],
        "has_jar": False, "has_xml": False, "has_edi": False,
    }
    cfg = analysis["cfg"]
    details: Dict[str, Dict[str, Any]] = {}

    for fname, content in file_contents.items():
        fmt = _agt_detect_format(content, fname)
        fn_info = _agt_from_filename(fname)
        tx_info = _agt_detect_tx(content, fmt, fn_info)
        parsed: Dict[str, Any] = {}
        if fmt == "X12 EDI":
            analysis["has_edi"] = True
            parsed = _agt_parse_edi(content)
        elif fmt == "XML":
            analysis["has_xml"] = True
            parsed = _agt_parse_xml(content)
        elif fn_info.get("artifact_type") == "contivo_jar":
            analysis["has_jar"] = True

        for k in ("map_name", "map_class", "map_data_file", "customer"):
            if fn_info.get(k) and not analysis.get(k):
                analysis[k] = fn_info[k]
        if fn_info.get("partner_hint") and not analysis.get("partner"):
            analysis["partner"] = fn_info["partner_hint"]

        details[fname] = {"fmt": fmt, "fn": fn_info, "tx": tx_info, "parsed": parsed}
        analysis["files"].append({
            "filename": fname, "format": fmt,
            "data_format_type": _agt_canonical_data_format(fmt),
            "role": fn_info.get("artifact_type", "file"),
            "fn_fields": fn_info, "tx": tx_info,
        })

    roles = _agt_build_payload_role_evidence(file_contents, learned_role_tokens)
    analysis["payload_roles"] = roles
    src_name = (roles.get("source") or {}).get("filename")
    tgt_name = (roles.get("target") or {}).get("filename")
    src_detail = details.get(src_name or "", {})
    tgt_detail = details.get(tgt_name or "", {})

    # Prefer transaction semantics from the physical source payload; then target;
    # finally fall back to the first payload that contained a usable transaction.
    tx_candidates = []
    if src_detail.get("tx"):
        tx_candidates.append(src_detail["tx"])
    if tgt_detail.get("tx"):
        tx_candidates.append(tgt_detail["tx"])
    tx_candidates.extend(d.get("tx") or {} for d in details.values())
    for tx_info in tx_candidates:
        if tx_info.get("code"):
            analysis["detected_tx"] = deepcopy(tx_info)
            break

    # Source/target parsed evidence is kept separately so an XML source is never
    # overwritten by a later target/output XML in upload order.
    if src_detail.get("fmt") == "XML":
        analysis["source_xml_data"] = deepcopy(src_detail.get("parsed") or {})
        analysis["xml_data"] = deepcopy(src_detail.get("parsed") or {})
    if tgt_detail.get("fmt") == "XML":
        analysis["target_xml_data"] = deepcopy(tgt_detail.get("parsed") or {})
        if not analysis["xml_data"]:
            analysis["xml_data"] = deepcopy(tgt_detail.get("parsed") or {})
    if src_detail.get("fmt") == "X12 EDI":
        analysis["source_edi_data"] = deepcopy(src_detail.get("parsed") or {})
        analysis["edi_data"] = deepcopy(src_detail.get("parsed") or {})
    if tgt_detail.get("fmt") == "X12 EDI":
        analysis["target_edi_data"] = deepcopy(tgt_detail.get("parsed") or {})
        if not analysis["edi_data"]:
            analysis["edi_data"] = deepcopy(tgt_detail.get("parsed") or {})

    # Fallback parsed evidence only when role classification could not identify a
    # side.  This is used for business identifiers, not for source format.
    if not analysis["xml_data"]:
        for d in details.values():
            if d.get("fmt") == "XML":
                analysis["xml_data"] = deepcopy(d.get("parsed") or {})
                break
    if not analysis["edi_data"]:
        for d in details.values():
            if d.get("fmt") == "X12 EDI":
                analysis["edi_data"] = deepcopy(d.get("parsed") or {})
                break

    source_xml = analysis.get("source_xml_data") or {}
    target_xml = analysis.get("target_xml_data") or {}
    source_edi = analysis.get("source_edi_data") or {}
    target_edi = analysis.get("target_edi_data") or {}
    any_xml = analysis.get("xml_data") or {}
    any_edi = analysis.get("edi_data") or {}

    cfg["source_payload_file"] = src_name or ""
    cfg["target_payload_file"] = tgt_name or ""
    cfg["source_data_format_type"] = roles.get("source_format") or ""
    cfg["target_data_format_type"] = roles.get("target_format") or ""
    cfg["source_xml_root"] = source_xml.get("root_element", "")
    cfg["target_xml_root"] = target_xml.get("root_element", "")
    cfg["xml_root"] = cfg["source_xml_root"] or any_xml.get("root_element", "")

    # Business/routing metadata prefers source evidence, then target, then any
    # parsed sample.  Physical source/target formats remain separately tracked.
    xml_business = source_xml or target_xml or any_xml
    for k in ("root_element", "partner_id", "sender_id", "receiver_name", "po_number", "dell_po_id", "vendor_number", "buyer_name", "seller_name", "country", "currency"):
        if xml_business.get(k) not in (None, ""):
            cfg.setdefault(k, xml_business.get(k))

    edi_business = source_edi or target_edi or any_edi
    for k, alias in [
        ("isa_sender_id", "isa_sender_id"), ("isa_receiver_id", "isa_receiver_id"),
        ("isa_sender_qual", "isa_sender_qualifier"), ("isa_receiver_qual", "isa_receiver_qualifier"),
        ("isa_version", "isa_version"), ("isa_test_ind", "isa_test_indicator"),
        ("gs_sender", "gs_sender"), ("gs_receiver", "gs_receiver"), ("gs_version", "gs_version"),
        ("tx_set_code", "tx_set_code"), ("po_number", "po_number"),
        ("ref_value", "ref_value"), ("ref_ia", "ref_ia"), ("ref_co", "ref_co"),
    ]:
        if edi_business.get(alias) not in (None, ""):
            cfg.setdefault(k, edi_business.get(alias))

    field_mappings = [
        {"path": "objects.source_document_type.data_format_type", "value": roles.get("source_format") or "", "sourceFile": src_name or "", "rule": "physical source payload content sniff", "confidence": "high" if src_name else ("medium" if roles.get("source_format") else "unresolved")},
        {"path": "objects.target_document_type.data_format_type", "value": roles.get("target_format") or "", "sourceFile": tgt_name or "", "rule": "physical target payload content sniff", "confidence": "high" if tgt_name else ("medium" if roles.get("target_format") else "unresolved")},
        {"path": "objects.source_document_type.document_identifier.rows", "value": roles.get("source_root") or "", "sourceFile": src_name or "", "rule": "source XML root", "confidence": "high" if roles.get("source_root") else "n/a"},
        {"path": "objects.target_document_type.document_identifier.rows", "value": roles.get("target_root") or "", "sourceFile": tgt_name or "", "rule": "target XML root", "confidence": "high" if roles.get("target_root") else "n/a"},
    ]
    for item in analysis.get("files") or []:
        if not isinstance(item, dict):
            continue
        fn = item.get("fn_fields") if isinstance(item.get("fn_fields"), dict) else {}
        filename = item.get("filename") or ""
        if fn.get("map_data_file"):
            field_mappings.append({"path": "objects.data_map.map_data_file", "value": fn.get("map_data_file"), "sourceFile": filename, "rule": "Contivo JAR filename", "confidence": "high"})
        if fn.get("map_class"):
            field_mappings.append({"path": "objects.data_map.map_class", "value": fn.get("map_class"), "sourceFile": filename, "rule": "Transform_*.jar class/name convention", "confidence": "high"})
        if fn.get("map_name"):
            field_mappings.append({"path": "objects.data_map.map_name", "value": fn.get("map_name"), "sourceFile": filename, "rule": "Contivo artifact logical/filename convention", "confidence": "high"})
    if cfg.get("partner_id"):
        # Payload ROUTING identity is evidence for Rule/Flow routing only. It is
        # intentionally not evidence for Partner Create DUNS/value.
        field_mappings.append({"path": "objects.biz_flow.flow_identifiers.conditions", "value": cfg.get("partner_id"), "sourceFile": src_name or tgt_name or "", "rule": "routing partner identity extracted from payload; never Partner Create identity", "confidence": "high"})
    if cfg.get("po_number"):
        field_mappings.append({"path": "business_identifier", "value": cfg.get("po_number"), "sourceFile": src_name or tgt_name or "", "rule": "purchase-order/business identifier extracted from payload", "confidence": "high"})
    if analysis.get("detected_tx", {}).get("code"):
        field_mappings.append({"path": "tx_code", "value": analysis.get("detected_tx", {}).get("code"), "sourceFile": src_name or tgt_name or "", "rule": "transaction semantics detected from physical payload", "confidence": "high"})

    analysis["_file_mapping"] = {
        "source": roles.get("source") or {},
        "target": roles.get("target") or {},
        "payloads": roles.get("payloads") or [],
        "warnings": roles.get("warnings") or [],
        "fieldMappings": field_mappings,
    }
    return analysis

def _agt_build_full_config(analysis:Dict, state:Dict, llm_data:Dict) -> Dict[str,Any]:
    cfg=analysis["cfg"]; tx=analysis.get("detected_tx",{}); kb=get_kb().payload

    def _evidence_version(*keys: str) -> str:
        """Return only a version actually present in deterministic input evidence.

        Dell-AIA/LLM output is deliberately excluded: versions that govern API
        references or Migration must be customer/Dev evidence or HUMAN input,
        never an agent/historical default.
        """
        for source in (state, analysis, cfg):
            if not isinstance(source, dict):
                continue
            for key in keys:
                raw = source.get(key)
                value = str(raw or "").strip()
                if not value or value.lower() in {"none", "null", "n/a", "na", "unknown"}:
                    continue
                # Accept a combined NAME(version) evidence value, but retain
                # only the version token for the API Document Type version.
                if "(" in value and value.endswith(")"):
                    inner = value.rsplit("(", 1)[1][:-1].strip()
                    if inner:
                        return inner
                return value
        return ""
    std=tx.get("standard","X12"); code=tx.get("code","855"); tx_name=tx.get("name","Order Acknowledgment"); direction=tx.get("direction","Outbound"); is_ob=direction=="Outbound"
    def _looks_like_isa_id(val: str) -> bool:
        """Return True if val looks like an ISA trading-partner ID, not a human customer name.
        ISA IDs: all-uppercase alphanumeric, no spaces, typically 6-15 chars, not sentence-cased."""
        import re as _re_c
        if not val or len(val) < 3: return False
        # Has spaces = likely a real name like "DOUGLAS STEWART"
        if " " in val: return False
        # All digits = likely an ID
        if val.isdigit(): return True
        # Mix of digits and uppercase with no lowercase = ISA-style ID
        if _re_c.match(r'^[A-Z0-9_-]{4,20}$', val): return True
        return False

    def _clean_customer(val: str) -> str:
        """Return a usable customer name; explicit standalone overrides are authoritative."""
        if not val: return ""
        if analysis.get("_force_customer") and val == analysis.get("customer"):
            return val
        return "" if _looks_like_isa_id(val) else val

    # v79.51: Prefer buyer_name/seller_name extracted from XML over receiver_name
    # which may be an ISA-style ID (not human-readable)
    _xml_data = analysis.get("xml_data", {})
    _buyer_name  = _xml_data.get("buyer_name", "")
    _seller_name = _xml_data.get("seller_name", "")
    _country_raw = _xml_data.get("country", "")
    customer = (
        _clean_customer(analysis.get("customer", "")) or
        _clean_customer(llm_data.get("customer", "")) or
        _clean_customer(_buyer_name) or
        _clean_customer(cfg.get("receiver_name", "")) or
        ""  # left blank so user fills it in HITL step
    )
    partner_id = (
        cfg.get("partner_id") or llm_data.get("partner_id") or
        cfg.get("isa_receiver_id", "") or ""
    )
    sender_id = (
        _seller_name or cfg.get("sender_id") or
        cfg.get("isa_sender_id", "") or "DELL ASN"
    )
    # Propagate buyer metadata into cfg so naming/routing picks it up
    if _buyer_name and not cfg.get("buyer_name"):
        cfg["buyer_name"] = _buyer_name
    if _seller_name and not cfg.get("seller_name"):
        cfg["seller_name"] = _seller_name
    if _country_raw and not cfg.get("country"):
        cfg["country"] = _country_raw
    if _xml_data.get("po_number") and not cfg.get("po_number"):
        cfg["po_number"] = _xml_data["po_number"]
    if _xml_data.get("currency") and not cfg.get("currency"):
        cfg["currency"] = _xml_data["currency"]
    map_name=analysis.get("map_name") or llm_data.get("map_name",""); map_class=analysis.get("map_class") or (f"Transform_{map_name}" if map_name else ""); map_data_file=analysis.get("map_data_file","")

    # ── Derive DellApp label from context ──────────────────────────────────────
    # Per naming convention: PRM=Premier, ANS=ANS, BHC=BHC, RTL=Retail, 3PP=Harmony
    # Heuristic: detect from folder/customer name or default to PRM
    _cust_upper = (customer or "").upper()
    if "ANS" in _cust_upper:          dell_app = "ANS"
    elif "BHC" in _cust_upper:        dell_app = "BHC"
    elif "RETAIL" in _cust_upper:     dell_app = "RTL"
    elif "HARMONY" in _cust_upper:    dell_app = "3PP"
    else:                             dell_app = "PRM"     # default = Premier

    # Detect transport protocol from interface type hint
    _iface = str(analysis.get("cfg", {}).get("interface_type","") or "").upper()
    tp_protocol = "HTTPS" if "HTTPS" in _iface else ("AS2" if "AS2" in _iface else "SFTP")

    # ── Format labels per naming convention ───────────────────────────────────
    # FileType: EDF (EDI flat file), XML, CSV
    # Format:   EDIFACT, ANSI (for X12), CXML, B2BXML, xCBL, etc.
    _std_upper = (std or "").upper()
    if _std_upper == "X12":
        file_type_src = "EDF" if not is_ob else "XML"
        format_label  = "ANSI"
    elif _std_upper == "EDIFACT":
        file_type_src = "EDF" if not is_ob else "XML"
        format_label  = "EDIFACT"
    elif _std_upper == "CXML":
        file_type_src = "XML"; format_label = "CXML"
    elif _std_upper == "B2BXML":
        file_type_src = "XML"; format_label = "B2BXML"
    elif _std_upper == "CSV":
        file_type_src = "CSV"; format_label = "CSV"
    else:
        file_type_src = "XML"; format_label = _std_upper or "XML"

    # ── requires_data_map — read early so naming block can use it ─────────────
    # Priority: state dict → analysis dict → has_jar flag → default True
    requires_data_map = (
        state.get("requires_data_map")
        if state.get("requires_data_map") is not None
        else analysis.get("requires_data_map",
             analysis.get("has_jar", True))
    )

    # Physical Document Type formats come from the uploaded source/target files.
    # Never infer EDIX12 merely because the business transaction code is 850/855.
    _roles = analysis.get("payload_roles") or {}
    _source_evidence_fmt = str(_roles.get("source_format") or cfg.get("source_data_format_type") or "").strip()
    _target_evidence_fmt = str(_roles.get("target_format") or cfg.get("target_data_format_type") or "").strip()
    _legacy_src_fmt = "XML" if is_ob else ("EDIX12" if std == "X12" else "EDIFACT")
    _legacy_tgt_fmt = ("EDIX12" if std == "X12" else "EDIFACT") if is_ob else "XML"
    src_fmt = _source_evidence_fmt or _legacy_src_fmt
    tgt_fmt = _target_evidence_fmt or (_legacy_tgt_fmt if requires_data_map else src_fmt)
    if not requires_data_map:
        tgt_fmt = src_fmt
    edi_std_key = "EDIFACT" if "EDIFACT" in {src_fmt.upper(), tgt_fmt.upper()} else "X12"
    flow_dir="OB" if is_ob else "IB"

    # ══════════════════════════════════════════════════════════════════════════
    # OFFICIAL HIP NAMING CONVENTION  (Naming_Convention_1_1.xlsx)
    # ══════════════════════════════════════════════════════════════════════════
    #
    #  Partner Account Name : {customer}_PC          ← used in TP, BizFlow, FLOWROUTE
    #  Map Identifier       : {MapCode}_{customer}   ← NO _PC suffix
    #  Rule / Action        : {MapCode}_{customer}_RULE / _ROUTE
    #  Doc Type IB          : {FileType}_{Format}_{TxType}_{Version}_{customer}_{DellApp}_IB
    #  Doc Type OB          : {FileType}_{Format}_{TxType}_{Version}_{customer}_{DellApp}_OB
    #  Doc Type P (passthru): {Format}_{TxType}_{Version}_{customer}_{DellApp}_P
    #    DellApp in DocType : PRM / ANS / BHC / RTL / 3PP
    #  TP Source            : {Protocol}_{customer}_PC_SRC_IB   ← always _IB
    #  TP Target OB flow    : {Protocol}_{customer}_PC_TGT_OB
    #  TP Target IB flow    : {Protocol}_{customer}_PC_TGT_IB
    #  Biz Flow             : {customer}_PC_{TxType}_{DellAppFull}_{MAPPING|PASSTHROUGH}_{DIR}
    #    DellApp in Flow    : PREMIER / ANS / BHC / RETAIL / HARMONY  (full word)
    #  FLOWROUTE            : FLOWROUTE_{customer}_PC_{TxType}_{DellAppFull}_{DocAbbrev}_{DIR}
    #  FLOWACTION           : FLOWACTION_{customer}_PC_{TxType}_{DellAppFull}_{DocAbbrev}_{DIR}_ROUTE

    _partner_acct = f"{customer}_PC"   # BizLink account name includes _PC
    _da_doc  = dell_app   # PRM/ANS/BHC/RTL/3PP — used in Doc Type names
    _da_flow = {"PRM":"PREMIER","ANS":"ANS","BHC":"BHC","RTL":"RETAIL","3PP":"HARMONY"}.get(dell_app, dell_app)
    _doc_abbrev = {
        "855":"XMLPOAR","856":"XMLASN","850":"XMLPO","860":"XMLPOMOD",
        "997":"XMLACK","820":"XMLPAY","810":"XMLINV",
        "ORDERS":"XMLPO","CATALOG":"XMLCATALOG","832":"XMLPSC",
        "WELCOME":"XMLWELCOME","CATALOG_CSV":"CSV",
    }.get(code, f"XML{code}")

    # 2. Map Identifier (partner WITHOUT _PC)
    map_id = f"{map_name}_{customer}" if map_name and customer else map_name or "MAP_ID"

    # 3. Document Type names
    _ver = "10"
    if requires_data_map:
        src_doc_name = f"XML_{format_label}_{code}_{_ver}_{customer}_{_da_doc}_IB"
        tgt_doc_name = f"XML_{format_label}_{code}_{_ver}_{customer}_{_da_doc}_OB"
    else:  # pass-through: no FileType prefix
        src_doc_name = f"{format_label}_{code}_{_ver}_{customer}_{_da_doc}_P"
        tgt_doc_name = src_doc_name

    # V127: Document Type *API version* is a separate, evidence-backed value.
    # The ``_ver`` token above belongs to the naming convention and must never
    # be mistaken for the API Document Type version.
    source_doc_version = _evidence_version(
        "source_document_type_version", "source_doc_version", "source_version",
        "document_type_version",
    )
    target_doc_version = _evidence_version(
        "target_document_type_version", "target_doc_version", "target_version",
    )
    if not requires_data_map:
        # Passthrough reuses the single source Document Type.  Reusing an
        # explicitly proven source version is valid; inventing one is not.
        target_doc_version = source_doc_version

    map_version = _evidence_version("map_identifier_version", "map_version", "data_map_version")
    rule_version = _evidence_version("rule_version", "mapping_rule_version")
    flow_version = _evidence_version("flow_version", "current_flow_version", "business_flow_version")

    source_doc_ref = f"{src_doc_name}({source_doc_version})" if src_doc_name and source_doc_version else ""
    target_doc_ref = f"{tgt_doc_name}({target_doc_version})" if tgt_doc_name and target_doc_version else ""

    # 5+6. Rule Name and Action (partner WITHOUT _PC)
    rule_name    = f"{map_id}_RULE"
    rule_action  = f"{map_id}_ROUTE"

    # 7. Transport Profiles — SRC always _IB; TGT matches flow direction
    src_tp_name = f"{tp_protocol}_{_partner_acct}_SRC_IB"
    tgt_tp_name = f"{tp_protocol}_{_partner_acct}_TGT_{flow_dir}"

    # 8. Biz Flow — {PartnerAcct}_{TxType}_{DellAppFull}_{MAPPING|PASSTHROUGH}_{DIR}
    _flow_type = "MAPPING" if requires_data_map else "PASSTHROUGH"
    flow_name  = f"{_partner_acct}_{code}_{_da_flow}_{_flow_type}_{flow_dir}"

    # 9+10. FLOWROUTE / FLOWACTION — use partner WITH _PC, DellApp FULL WORD
    routing_rule   = f"FLOWROUTE_{_partner_acct}_{code}_{_da_flow}_{_doc_abbrev}_{flow_dir}"
    routing_action = f"FLOWACTION_{_partner_acct}_{code}_{_da_flow}_{_doc_abbrev}_{flow_dir}_ROUTE"



    source_xml_root = str(cfg.get("source_xml_root") or (_roles.get("source") or {}).get("root_element") or cfg.get("xml_root") or "").strip()
    target_xml_root = str(cfg.get("target_xml_root") or (_roles.get("target") or {}).get("root_element") or "").strip()
    xml_root = source_xml_root or target_xml_root or ""
    edi_expr = EDI_ATTR_EXPRESSIONS

    def _xml_doc_parts(root_name: str, *, source_side: bool) -> tuple:
        root_name = str(root_name or "").strip()
        if not root_name:
            return [], [], {}
        # Existing XPath knowledge is only used where it actually matches the
        # detected XML root.  Unknown XML stays root-driven instead of borrowing
        # EDI expressions from the transaction code.
        xp = _agt_get_xpaths(root_name, is_ob)
        receiver_xpath = xp.get("Receiver", f"/{root_name}/Receiver")
        sender_xpath = xp.get("Sender", f"/{root_name}/Sender")
        partnerid_xpath = xp.get("PartnerIdentifier", receiver_xpath)
        biz_id_xpath = xp.get("Business Identifier", f"/{root_name}/BusinessIdentifier")
        alt_id_xpath = xp.get("Alternate Business Identifier", f"/{root_name}/AlternateBusinessIdentifier")
        sender_is_static = str(sender_xpath).startswith("STATIC")
        receiver_is_static = str(receiver_xpath).startswith("STATIC")
        rows = [{"derived_from": "TRANSACTION_ROOT_ELEMENT", "value": root_name, "note": "Root element detected from uploaded XML source/target file"}]
        attrs = [
            {"name": "Transaction Type", "derived_from": "TRANSACTION_ROOT_ELEMENT", "expression": None, "value": root_name, "note": "Physical XML root from uploaded file"},
        ]
        if source_side:
            attrs = [
                {"name": "Sender", "derived_from": "TRANSACTION_ROOT_ELEMENT" if sender_is_static else "ELEMENT_IN_PAYLOAD", "expression": None if sender_is_static else sender_xpath, "value": "DELL" if sender_is_static else cfg.get("sender_id", "")},
                {"name": "Receiver", "derived_from": "TRANSACTION_ROOT_ELEMENT" if receiver_is_static else "ELEMENT_IN_PAYLOAD", "expression": None if receiver_is_static else (receiver_xpath or partnerid_xpath), "value": cfg.get("receiver_name", partner_id)},
                {"name": "Transaction Type", "derived_from": "TRANSACTION_ROOT_ELEMENT", "expression": None, "value": root_name, "note": "Physical XML root from uploaded source file"},
                {"name": "Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": biz_id_xpath, "value": cfg.get("po_number", "")},
                {"name": "Alternate Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": alt_id_xpath, "value": cfg.get("dell_po_id", "")},
            ]
            if partner_id and not receiver_is_static:
                rows.append({"derived_from": "ELEMENT_IN_PAYLOAD", "expression": receiver_xpath or partnerid_xpath, "value": partner_id})
        return rows, attrs, {}

    def _edi_doc_parts(fmt_name: str, *, source_side: bool) -> tuple:
        std_key = "EDIFACT" if str(fmt_name).upper() == "EDIFACT" else "X12"
        rows = [
            {"derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Transaction Type"][std_key], "value": code},
            {"derived_from": "PAYLOAD_CONTAINS", "expression": edi_expr["Alternate Business Identifier"][std_key], "value": cfg.get("ref_ia", cfg.get("ref_value", ""))},
        ]
        attrs = [
            {"name": "Receiver", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Receiver"][std_key], "value": cfg.get("isa_receiver_id", "")},
            {"name": "Sender", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Sender"][std_key], "value": cfg.get("isa_sender_id", "")},
            {"name": "Transaction Type", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Transaction Type"][std_key], "value": code},
        ]
        if source_side:
            attrs.extend([
                {"name": "Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Business Identifier"][std_key], "value": cfg.get("po_number", "")},
                {"name": "Alternate Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "expression": edi_expr["Alternate Business Identifier"][std_key], "value": cfg.get("ref_value", "")},
            ])
        delimiters = {"data_element_separator": "*", "segment_separator": "~"} if std_key == "X12" else {}
        return rows, attrs, delimiters

    def _generic_doc_parts(fmt_name: str, *, source_side: bool) -> tuple:
        # CSV/JSON/flat-file inputs require customer-specific identifier logic.
        # Leave the identifier unresolved so the HITL stage asks instead of
        # fabricating an EDI expression.
        return [], [], {}

    if str(src_fmt).upper() in {"XML", "CXML"}:
        src_doc_id_rows, src_attrs, _ = _xml_doc_parts(source_xml_root or xml_root, source_side=True)
    elif str(src_fmt).upper() in {"EDIX12", "X12", "EDI", "EDIFACT"}:
        src_doc_id_rows, src_attrs, _ = _edi_doc_parts(src_fmt, source_side=True)
    else:
        src_doc_id_rows, src_attrs, _ = _generic_doc_parts(src_fmt, source_side=True)

    if str(tgt_fmt).upper() in {"XML", "CXML"}:
        tgt_doc_id_rows, tgt_attrs, tgt_del = _xml_doc_parts(target_xml_root or (source_xml_root if not requires_data_map else ""), source_side=False)
    elif str(tgt_fmt).upper() in {"EDIX12", "X12", "EDI", "EDIFACT"}:
        tgt_doc_id_rows, tgt_attrs, tgt_del = _edi_doc_parts(tgt_fmt, source_side=False)
    else:
        tgt_doc_id_rows, tgt_attrs, tgt_del = _generic_doc_parts(tgt_fmt, source_side=False)

    # ISA/GS details only apply when an actual uploaded X12 payload is on the
    # target side.  They are not inferred from transaction code alone.
    if str(tgt_fmt).upper() in {"EDIX12", "X12", "EDI"}:
        isa_gs={"note":"Values from uploaded target EDI file","ISA01":"00","ISA02":" ","ISA03":"00","ISA04":" ","ISA05":cfg.get("isa_sender_qual","14"),"ISA06":cfg.get("isa_sender_id",""),"ISA07":cfg.get("isa_receiver_qual","ZZ"),"ISA08":cfg.get("isa_receiver_id",""),"ISA11":"U","ISA12":cfg.get("isa_version","00401"),"ISA13":"000001-999999","ISA14":"0","ISA15":cfg.get("isa_test_ind","T"),"ISA16":">","GS01":"PR","GS02":cfg.get("gs_sender",""),"GS03":cfg.get("gs_receiver",""),"GS06":"000001-999999","GS07":"X","GS08":cfg.get("gs_version","004010")}
    else:
        isa_gs = {}
    missing=[]
    # ── Data Map fields — only required when translation (JAR) is involved ─────
    # requires_data_map already set above the naming block
    if requires_data_map:
        if not map_name: missing.append({"field":"map_name","label":"Map Name / JAR file","why":"Required for Data Map — upload Transform_XXX.jar"})
        if not map_class: missing.append({"field":"map_class","label":"Map Class (Transform_XXX)","why":"Java class name inside the JAR"})
        if not map_data_file: missing.append({"field":"map_data_file","label":"JAR File","why":"The .jar file must be uploaded to HIP"})
    if not source_doc_version:
        missing.append({"field":"source_document_type_version","label":"Source Document Type Version","why":"Required by the Document Type API and dependent TP/Flow references; V127 never defaults this to 1/1.0"})
    if requires_data_map and not target_doc_version:
        missing.append({"field":"target_document_type_version","label":"Target Document Type Version","why":"Required by the target Document Type API and dependent TP/Flow references; never fabricated"})
    if requires_data_map and not map_version:
        missing.append({"field":"map_identifier_version","label":"Data Map Version","why":"Required by Mapping Rule/Migration references; no 1/1.0 default is allowed"})
    if requires_data_map and not rule_version:
        missing.append({"field":"rule_version","label":"Mapping Rule Version","why":"Required by Flow/Migration references; no 1/1.0 default is allowed"})
    if not flow_version:
        missing.append({"field":"flow_version","label":"Business Flow Version","why":"Required by Flow Migration; no config default may manufacture Migration evidence"})
    if not partner_id: missing.append({"field":"partner_id","label":"Routing Partner Identity","why":"Used only in Rule/Flow Sender/Receiver routing conditions; not Partner Create DUNS/value"})
    if not customer: missing.append({"field":"customer","label":"Customer / Partner Name","why":"Used in all naming patterns"})
    if str(tgt_fmt).upper() in {"EDIX12", "X12", "EDI"}:
        if not cfg.get("isa_sender_id"): missing.append({"field":"isa_sender_id","label":"ISA06 — Sender ID","why":"From the uploaded target EDI file ISA segment"})
        if not cfg.get("isa_receiver_id"): missing.append({"field":"isa_receiver_id","label":"ISA08 — Receiver ID","why":"From the uploaded target EDI file ISA segment"})
    completeness=max(0,round(100*(1-len(missing)/max(1,len(missing)+8))))
    # Accuracy: only flag Transaction Type as a violation when it is outbound (XML src).
    # For inbound EDI, Transaction Type correctly uses ELEMENT_IN_PAYLOAD (ST*01 / UNH segment).
    _tx_type_via_payload = any(
        a.get("derived_from")=="ELEMENT_IN_PAYLOAD" and a.get("name")=="Transaction Type"
        for a in src_attrs
    )
    _is_xml_src = src_fmt == "XML"  # outbound: XML→EDI; inbound: EDI→XML (EDI is src, not XML)
    accuracy = 75 if (_tx_type_via_payload and _is_xml_src) else 100

    # ── Data Map object — empty/disabled when no translation ──────────────────
    if requires_data_map:
        data_map_obj = {
            "map_identifier":         map_id,
            "map_identifier_version": map_version,
            "map_name":               map_name,
            "map_class":              map_class,
            "map_data_file":          map_data_file,
            "contivo_version":        cfg.get("contivo_version", "") or "6.7",
            "status":                 "Enable",
        }
    else:
        data_map_obj = {
            "map_identifier":         "N/A — No translation required",
            "map_identifier_version": "",
            "map_name":               "",
            "map_class":              "",
            "map_data_file":          "",
            "contivo_version":        "",
            "status":                 "Not Applicable",
            "_note":                  "This transaction does not use Contivo mapping (no JAR). "
                                      "Data Map step is skipped in HIP.",
        }

    # ── Biz Flow process steps — remove Mapping Transformer when no JAR ───────
    enricher_step = {
        "step_number": 1 if not requires_data_map else 2,
        "step_type": "Enricher", "step_name": "Enricher-1",
        "config": {
            "action": "Enricher", "target_file_name_config": "Yes",
            "file_separator": "-",
            "file_extension": ".edi" if is_ob else ".xml",
            "file_name_sections": [{"part_number": 1, "derived_from": "Source File Name"}],
        },
    }
    if requires_data_map:
        biz_flow_steps = [
            {"step_number":1,"step_type":"Mapping Transformer","step_name":"Mapping-1",
             "config":{"source_doc_type":"Disabled(All/Other)","action":"Mapping",
                       "target_doc_type":target_doc_ref,"rule_version":(f"{rule_name}({rule_version})" if rule_name and rule_version else "")}},
            enricher_step,
        ]
    else:
        # Strict default Passthrough path: direct routing only.  Customer-specific
        # Enricher steps can still be supplied explicitly by a Configuration
        # Manual/user request and are preserved by the canonical normalizer.
        biz_flow_steps = []

    # ── Passthrough: adjust source/target doc types and remove unneeded objects ──
    # "If passthrough: same src & target file format, no JAR, no data map, no rule,
    #  only 1 document type + 2 transport profiles." — Harish, Dell Team
    if not requires_data_map:
        # Default Passthrough has ONE Document Type.  Do not fabricate a target
        # Document Type from the source sample; target TP/Flow reuse the source
        # Document Type.  A separate target is an explicit exception handled by
        # the canonical flag passthrough_target_document_type_required.
        tgt_doc_id_rows = []
        tgt_attrs = []
        tgt_del = {}
        isa_gs = {}
        rule_obj = {
            "name": "NA", "version": "NA", "rule_type": "NA", "rule_scope": "NA",
            "_passthrough": True,
            "_note": "No Mapping Rule required for passthrough flows — routing only.",
        }
    else:
        rule_obj = {
            "name": rule_name, "version": rule_version,
            "document_type_version": source_doc_ref,
            "rule_type": "Mapping", "rule_scope": "GLOBAL",
            "conditions": {"execute_when": "One or more conditions are satisfied",
                "rows": [{"attribute": "Receiver", "operator": "Equals", "value": partner_id},
                         {"attribute": "Sender",   "operator": "Equals", "value": sender_id}]},
            "actions": {"action_name": rule_action, "action_type": "Route Document",
                        "mapping_id_version": (f"{map_id}({map_version})" if map_id and map_version else "")},
        }

    # Direction-aware party placement. Dell Application is always AIC - DCE.
    # The external Partner application is intentionally left unresolved unless
    # the files/configuration prove it; the integrated UI will ask the user
    # rather than silently inventing dce-test-partner for a new customer.
    if is_ob:
        src_system_type, src_system_name = "Dell Application", "AIC - DCE"
        tgt_system_type, tgt_system_name = "Partner", ""
    else:
        src_system_type, src_system_name = "Partner", ""
        tgt_system_type, tgt_system_name = "Dell Application", "AIC - DCE"

    return {
        "customer": customer, "partner_id": partner_id, "sender_id": sender_id,
        "transaction": tx, "flow_direction": direction, "flow_name": flow_name,
        "requires_data_map": requires_data_map,
        "data_map": data_map_obj,
        "source_document_type": {"name":src_doc_name,"transaction_type":code,"data_format_type":src_fmt,"version":source_doc_version,"description":src_doc_name,"validation_type":"Structure","document_identifier":{"operation":"One or more conditions are satisfied","rows":src_doc_id_rows},"attributes_to_configure":src_attrs},
        "target_document_type": ({"name":tgt_doc_name,"transaction_type":code,"data_format_type":tgt_fmt,"version":target_doc_version,"description":tgt_doc_name,"validation_type":"Structure","document_identifier":{"operation":"One or more conditions are satisfied","rows":tgt_doc_id_rows},"attributes_to_configure":tgt_attrs,**({"edi_delimiters":tgt_del} if tgt_del else {})} if requires_data_map else _blank_passthrough_target_document_type()),
        "rule": rule_obj,
        "source_transport_profile": {"system_type":src_system_type,"system_name":src_system_name,"partner_name":src_system_name,"profile_name":src_tp_name,"profile_usage":"Sender","deployment_group":HIP_AUTOMATION_GROUP,"interface_type":"SFTP HAFT","interface_env":"UAT","existing_account":"Yes","post_transfer_action":"Move To Archive","supported_doc_type":src_doc_name,"document_type":source_doc_ref},
        "target_transport_profile": {"system_type":tgt_system_type,"system_name":tgt_system_name,"partner_name":tgt_system_name,"profile_name":tgt_tp_name,"profile_usage":"Receiver","deployment_group":HIP_AUTOMATION_GROUP,"interface_type":"SFTP HAFT","interface_env":"UAT","existing_account":"Yes","post_transfer_action":"Move To Archive","supported_doc_type":tgt_doc_name if requires_data_map else src_doc_name,"document_type":target_doc_ref},
        "biz_flow": {"flow_name":flow_name,"flow_description":f"{'Outbound' if is_ob else 'Inbound'} {format_label} {code} {_flow_type.lower()} flow for {customer} — Dell {dell_app}","current_flow_version":flow_version,"source":{"source_type":src_system_type,"source_application":src_system_name,"transport_profile":src_tp_name,"doc_type_version":source_doc_ref},"flow_identifiers":{"operator":"One or more conditions are satisfied","conditions":[{"doc_type":source_doc_ref,"attribute":"Receiver","operator":"Equals","value":partner_id},{"doc_type":source_doc_ref,"attribute":"Sender","operator":"Equals","value":sender_id}]},"target":{"target_type":tgt_system_type,"target_application":tgt_system_name,"transport_profile":tgt_tp_name,"doc_type_version":target_doc_ref},"process_steps":biz_flow_steps,"configure_routing":{"rule_name":routing_rule,"doc_type_version":source_doc_ref,"rule_type":"Target Routing","rule_scope":"LOCAL","conditions":{"execute_when":"One or more conditions are satisfied","rows":[{"attribute":"Receiver","operator":"Equals","value":partner_id},{"attribute":"Sender","operator":"Equals","value":sender_id}]},"actions":{"action_name":routing_action,"action_type":"Route Document","mapping_id":(f"{map_id}({map_version})" if requires_data_map and map_id and map_version else "")}}},
        "isa_gs_config": isa_gs,
        "missing_fields": missing, "completeness": completeness, "accuracy": accuracy,
        "_raw_cfg": cfg,
    }



def _canonicalize_rule_attribute_keys(objects: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize legacy raw-builder rows from `attribute` to `attribute_name`."""
    for key in ("rule",):
        vals = objects.get(key)
        vals = vals if isinstance(vals, list) else [vals]
        for item in vals:
            if not isinstance(item, dict):
                continue
            conds = item.get("conditions")
            rows = conds.get("rows", []) if isinstance(conds, dict) else []
            for row in rows:
                if isinstance(row, dict) and "attribute_name" not in row and "attribute" in row:
                    row["attribute_name"] = row.pop("attribute")
    bf = objects.get("biz_flow")
    if isinstance(bf, dict):
        fi = bf.get("flow_identifiers")
        if isinstance(fi, dict):
            for row in fi.get("conditions", []) or []:
                if isinstance(row, dict):
                    if "attribute_name" not in row and "attribute" in row:
                        row["attribute_name"] = row.pop("attribute")
                    if "document_type_name_version" not in row and "doc_type" in row:
                        row["document_type_name_version"] = row.pop("doc_type")
        cr = bf.get("configure_routing")
        if isinstance(cr, dict):
            conds = cr.get("conditions")
            rows = conds.get("rows", []) if isinstance(conds, dict) else []
            for row in rows:
                if isinstance(row, dict) and "attribute_name" not in row and "attribute" in row:
                    row["attribute_name"] = row.pop("attribute")
    return objects


def normalize_input_json(data: Dict[str, Any], *, customer: str = "", folder_name: str = "",
                         direction: str = "", flow_type: str = "") -> Dict[str, Any]:
    """Normalize/finalize an already-created HIP input.json payload."""
    cfg = deepcopy(data or {})
    objects = cfg.get("objects") if isinstance(cfg.get("objects"), dict) else {}
    if not objects:
        candidate_keys = (
            "data_map", "source_document_type", "target_document_type", "rule",
            "source_transport_profile", "target_transport_profile", "biz_flow",
        )
        objects = {k: deepcopy(cfg[k]) for k in candidate_keys if k in cfg}
    objects = _canonicalize_rule_attribute_keys(objects)
    chosen_customer = customer or str(cfg.get("customer", "") or "")
    chosen_direction = direction or str(cfg.get("direction", "") or "")
    chosen_flow_type = flow_type or str(cfg.get("flow_type", "") or "")
    explicit_requires_map = cfg.get("requires_data_map") if "requires_data_map" in cfg else None
    keep_passthrough_target = bool(
        cfg.get("passthrough_target_document_type_required")
        or cfg.get("passthrough_separate_target_document_type")
    )
    # If flow_type is omitted but requires_data_map is explicit, preserve that
    # business choice through the object finalizer.
    if not chosen_flow_type and explicit_requires_map is not None:
        chosen_flow_type = "translation" if bool(explicit_requires_map) else "passthrough"
    cfg["objects"] = _input_builder_finalize_objects(
        objects, chosen_customer, folder_name, chosen_direction, chosen_flow_type,
        requires_data_map=explicit_requires_map,
        passthrough_target_document_type_required=keep_passthrough_target,
    )
    if chosen_customer:
        cfg["customer"] = chosen_customer
    d = _detect_direction(cfg["objects"], cfg.get("profile_name", "") or folder_name)
    if chosen_direction:
        cfg["direction"] = chosen_direction.title()
        cfg["direction_source"] = "explicit standalone builder option"
        cfg["direction_confidence"] = "high"
    elif d.get("direction"):
        cfg["direction"] = d["direction"]
        cfg["direction_source"] = d["direction_source"]
        cfg["direction_confidence"] = d["direction_confidence"]
    cfg["flow_type"] = _infer_flow_type(
        cfg["objects"], chosen_flow_type, explicit_requires_map
    )
    cfg["requires_data_map"] = cfg["flow_type"] == "translation"
    cfg["passthrough_target_document_type_required"] = bool(
        keep_passthrough_target if cfg["flow_type"] == "passthrough" else False
    )
    # V110: HIP Flow Create enforces a hard 40-character naming contract.
    # Normalize invalid names while building canonical input, before any LIVE
    # request is materialized. This is transparent canonicalization, not a
    # post-error API payload mutation.
    cfg = normalize_input_flow_name(cfg)
    return cfg


def build_from_config_manual(source: Union[str, Path, bytes], *, folder_name: str = "",
                             customer: str = "", direction: str = "",
                             flow_type: str = "") -> Dict[str, Any]:
    """Build a complete canonical input.json from a HIP Configuration Manual workbook."""
    if isinstance(source, (str, Path)):
        raw = Path(source).read_bytes()
        folder_name = folder_name or Path(source).parent.name
    else:
        raw = source
    cfg = _config_manual_to_input_json(raw, folder_name=folder_name)
    if "_error" in cfg:
        return cfg
    return normalize_input_json(cfg, customer=customer, folder_name=folder_name,
                                direction=direction, flow_type=flow_type)


def _is_blank_value(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, (list, dict)):
        return len(value) == 0
    return False


def _deep_fill_generated(primary: Any, secondary: Any, *, path: str = "", audit: Optional[List[Dict[str, Any]]] = None) -> Any:
    """Fill blanks in one generated canonical config from a second evidence source.

    This is used for Configuration Manual + customer-file onboarding.  The
    selected primary source keeps its explicit values; the secondary source may
    only fill blanks.  Conflicting non-blank values are retained for review in
    the audit rather than silently replacing one another.
    """
    audit = audit if audit is not None else []
    if isinstance(primary, dict) and isinstance(secondary, dict):
        out = deepcopy(primary)
        for key, value in secondary.items():
            child = f"{path}.{key}" if path else str(key)
            if key not in out or _is_blank_value(out.get(key)):
                if not _is_blank_value(value):
                    out[key] = deepcopy(value)
                    audit.append({"path": child, "action": "filled", "source": "secondary"})
            elif isinstance(out.get(key), dict) and isinstance(value, dict):
                out[key] = _deep_fill_generated(out[key], value, path=child, audit=audit)
            elif isinstance(out.get(key), list) and isinstance(value, list):
                if not out[key] and value:
                    out[key] = deepcopy(value)
                    audit.append({"path": child, "action": "filled", "source": "secondary"})
                elif out[key] and value and out[key] != value:
                    audit.append({"path": child, "action": "conflict-retained-primary"})
            elif out.get(key) != value and not _is_blank_value(value):
                # Metadata/audit keys are intentionally not noisy conflicts.
                if not str(key).startswith("_"):
                    audit.append({"path": child, "action": "conflict-retained-primary", "primary": out.get(key), "secondary": value})
        return out
    return deepcopy(secondary) if _is_blank_value(primary) and not _is_blank_value(secondary) else deepcopy(primary)


def combine_configuration_manual_with_artifacts(
    manual_config: Dict[str, Any],
    artifact_config: Dict[str, Any],
    *,
    manifest: Optional[List[str]] = None,
    customer: str = "",
    direction: str = "",
    flow_type: str = "",
    manual_primary: bool = True,
) -> Dict[str, Any]:
    """Create one canonical input.json from Configuration Manual + customer files.

    The user-selected primary source is authoritative for explicit values, while
    the other source fills blanks.  Mapping artifacts still control automatic
    Translation detection when the user did not explicitly select a flow type.
    """
    manual = normalize_input_json(manual_config, customer=customer, direction=direction, flow_type=flow_type)
    artifacts = normalize_input_json(artifact_config, customer=customer, direction=direction, flow_type=flow_type)
    audit_rows: List[Dict[str, Any]] = []
    primary, secondary = (manual, artifacts) if manual_primary else (artifacts, manual)
    merged = _deep_fill_generated(primary, secondary, audit=audit_rows)

    # Explicit user choice wins. Otherwise mapping artifacts are stronger flow-
    # applicability evidence than a partially filled manual.
    if flow_type:
        merged["flow_type"] = flow_type.lower()
        merged["requires_data_map"] = flow_type.lower() == "translation"
    elif str(artifacts.get("flow_type") or "").lower() == "translation" or bool(artifacts.get("requires_data_map")):
        merged["flow_type"] = "translation"
        merged["requires_data_map"] = True

    # Reuse the same concrete JAR/XBM/XML consistency checks used by the
    # existing-input.json path.  Here the merged generated config is the base.
    merged = combine_existing_input_with_artifact_evidence(
        merged, artifacts, manifest=manifest or [], customer=customer,
        direction=direction, flow_type=flow_type or str(merged.get("flow_type") or ""),
    )
    merged["_source"] = "Configuration Manual + customer artifacts"
    merged.setdefault("_builder_audit", {})["configuration_manual_merge"] = {
        "manualPrimary": bool(manual_primary),
        "filledOrConflictingPaths": audit_rows,
        "source": "configuration_manual + deterministic customer artifacts",
    }
    return normalize_input_json(
        merged, customer=customer or str(merged.get("customer") or ""),
        direction=direction or str(merged.get("direction") or ""),
        flow_type=flow_type or str(merged.get("flow_type") or ""),
    )


def build_from_config_manual_and_raw_files(
    manual_source: Union[str, Path, bytes],
    raw_paths: List[Union[str, Path]],
    *, customer: str = "", direction: str = "", flow_type: str = "",
    folder_name: str = "", use_dell_aia: Optional[bool] = None,
    manual_primary: bool = True, mapping_knowledge: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Generate canonical input.json from a Configuration Manual plus customer files."""
    if not raw_paths:
        return build_from_config_manual(
            manual_source, folder_name=folder_name, customer=customer,
            direction=direction, flow_type=flow_type,
        )
    manual = build_from_config_manual(
        manual_source, folder_name=folder_name, customer=customer,
        direction=direction, flow_type=flow_type,
    )
    if manual.get("_error"):
        return manual
    artifacts = build_from_raw_files(
        raw_paths, customer=customer, direction=direction, flow_type=flow_type,
        folder_name=folder_name, use_dell_aia=use_dell_aia, mapping_knowledge=mapping_knowledge,
    )
    return combine_configuration_manual_with_artifacts(
        manual, artifacts, manifest=[Path(p).name for p in raw_paths],
        customer=customer, direction=direction, flow_type=flow_type,
        manual_primary=manual_primary,
    )


def _read_raw_file(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in (".jar", ".zip", ".war", ".ear", ".xbm", ".class"):
        return ""
    raw = path.read_bytes()
    # Respect an XML declaration such as ISO-8859-1. Decoding every XML as
    # UTF-8 can corrupt customer data before the deterministic parser sees it.
    if ext == ".xml":
        head = raw[:240].decode("ascii", errors="ignore")
        m = re.search(r"encoding\s*=\s*[\"']([^\"']+)[\"']", head, flags=re.IGNORECASE)
        if m:
            try:
                return raw.decode(m.group(1), errors="strict")
            except Exception:
                pass
    try:
        return raw.decode("utf-8", errors="strict")
    except Exception:
        return raw.decode("latin-1", errors="replace")


def _merge_llm_hints_into_analysis(analysis: Dict[str, Any], hints: Dict[str, Any]) -> Dict[str, Any]:
    """Merge Dell AIA suggestions into blanks only; deterministic evidence wins."""
    if not isinstance(hints, dict):
        return analysis
    def fill(key: str, value: Any) -> None:
        if value not in (None, "") and not str(analysis.get(key, "") or "").strip():
            analysis[key] = value
    fill("customer", hints.get("customer"))
    fill("partner", hints.get("partner_id"))
    fill("map_name", hints.get("map_name"))
    cfg = analysis.setdefault("cfg", {})
    for k in ("buyer_name", "seller_name", "country", "currency", "po_number"):
        v = hints.get(k)
        if v not in (None, "") and not str(cfg.get(k, "") or "").strip():
            cfg[k] = v
    tx = analysis.setdefault("detected_tx", {})
    if hints.get("tx_code") and not str(tx.get("code", "") or "").strip():
        tx["code"] = str(hints["tx_code"])
    if hints.get("direction") in ("Inbound", "Outbound") and not str(tx.get("direction", "") or "").strip():
        tx["direction"] = hints["direction"]
    return analysis



def _extract_contivo_artifact_metadata(paths: List[Path]) -> Dict[str, Any]:
    """Deterministically inspect XBM/JAR artifacts, matching the original app."""
    import gzip
    out: Dict[str, Any] = {"xbm": {}, "jar": {}}
    for p in paths:
        ext = p.suffix.lower()
        if ext == ".xbm":
            meta = {"logical_name": "", "contivo_version": "", "src_root_in_map": "", "tgt_root_in_map": ""}
            try:
                raw = p.read_bytes()
                if raw[:2] == b"\x1f\x8b":
                    try: raw = gzip.decompress(raw)
                    except Exception: pass
                txt = raw.decode("utf-8", errors="replace")
                m = re.search(r'analystVersionLastSaved\s*=\s*"([^"]+)"', txt)
                if m: meta["contivo_version"] = m.group(1)
                m = re.search(r'<transformMap\b[^>]*\blogicalName\s*=\s*"([^"]+)"', txt)
                if m: meta["logical_name"] = m.group(1)
                ms = re.search(r'<sources\b[^>]*>(.*?)</sources>', txt, re.S)
                if ms:
                    mr = re.search(r'<schemaRoot\b[^>]*\blogicalName\s*=\s*"([^"]+)"', ms.group(1))
                    if mr: meta["src_root_in_map"] = mr.group(1)
                mt = re.search(r'<targets\b[^>]*>(.*?)</targets>', txt, re.S)
                if mt:
                    mr = re.search(r'<schemaRoot\b[^>]*\blogicalName\s*=\s*"([^"]+)"', mt.group(1))
                    if mr: meta["tgt_root_in_map"] = mr.group(1)
            except Exception as exc:
                meta["error"] = f"{type(exc).__name__}: {exc}"
            out["xbm"][p.name] = meta
        elif ext == ".jar":
            meta = {"file": p.name, "transform_classes": []}
            try:
                with zipfile.ZipFile(p) as zf:
                    classes = []
                    for name in zf.namelist():
                        base = Path(name).name
                        if base.startswith("Transform_") and base.endswith(".class"):
                            classes.append(base[:-6])
                    meta["transform_classes"] = sorted(set(classes))
            except Exception as exc:
                meta["error"] = f"{type(exc).__name__}: {exc}"
            out["jar"][p.name] = meta
    return out


def _apply_contivo_metadata(analysis: Dict[str, Any], meta: Dict[str, Any]) -> None:
    xbm = meta.get("xbm", {}) if isinstance(meta, dict) else {}
    for item in xbm.values():
        if not isinstance(item, dict): continue
        if item.get("logical_name") and not analysis.get("map_name"):
            analysis["map_name"] = item["logical_name"]
        if item.get("logical_name") and not analysis.get("map_class"):
            analysis["map_class"] = "Transform_" + item["logical_name"]
        if item.get("contivo_version"):
            analysis.setdefault("cfg", {}).setdefault("contivo_version", item["contivo_version"])
        if item.get("src_root_in_map"):
            analysis.setdefault("cfg", {}).setdefault("src_root_in_map", item["src_root_in_map"])
        if item.get("tgt_root_in_map"):
            analysis.setdefault("cfg", {}).setdefault("tgt_root_in_map", item["tgt_root_in_map"])
    jars = meta.get("jar", {}) if isinstance(meta, dict) else {}
    for filename, item in jars.items():
        analysis["has_jar"] = True
        analysis.setdefault("map_data_file", filename)
        classes = item.get("transform_classes", []) if isinstance(item, dict) else []
        if classes and not analysis.get("map_class"):
            analysis["map_class"] = classes[0]
        if classes and not analysis.get("map_name") and classes[0].startswith("Transform_"):
            analysis["map_name"] = classes[0][len("Transform_"):]


def _meaningful_artifact_folder_hint(value: Any) -> str:
    """Reject runtime/temp folder names as customer identity hints.

    React workspaces use random ids and Streamlit uses temporary directories.
    Those implementation names must never become the customer in generated
    input.json when the user supplied customer files without input.json.
    """
    text = str(value or "").strip()
    low = text.lower()
    if not text:
        return ""
    generic = {"input_files", "uploads", "uploaded_zip", "files", "artifacts", "customer_files", "customer-files"}
    if low in generic or low.startswith(("hip_input_builder_", "tmp", "temp")):
        return ""
    if re.fullmatch(r"[0-9a-f]{10,32}", low):
        return ""
    return text


def build_from_raw_files(paths: List[Union[str, Path]], *, customer: str = "",
                         direction: str = "", flow_type: str = "",
                         requires_data_map: Optional[bool] = None,
                         folder_name: str = "", use_dell_aia: Optional[bool] = None,
                         mapping_knowledge: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build canonical input.json from raw customer artifacts.

    Architecture mirrors the original full HIP app: deterministic parsing is
    authoritative, then Dell AIA gpt-oss-120b fills only unresolved metadata.
    Set use_dell_aia=False for deterministic-only/offline operation.
    """
    pths = [Path(p) for p in paths]
    if not pths:
        raise ValueError("No input files supplied")
    file_contents = {p.name: _read_raw_file(p) for p in pths if p.is_file()}
    analysis = _agt_analyze_all_files(file_contents, learned_role_tokens=(mapping_knowledge or {}).get("role_tokens") if isinstance(mapping_knowledge, dict) else None)
    _artifact_meta = _extract_contivo_artifact_metadata(pths)
    _apply_contivo_metadata(analysis, _artifact_meta)
    analysis["artifact_metadata"] = _artifact_meta
    # Surface binary mapping evidence in the same file→input.json trace used by
    # the React UI.  Previously JAR/XBM data could influence the generated map
    # while the evidence panel only showed source/target XML format rows.
    _fm = analysis.setdefault("_file_mapping", {})
    _fm_rows = _fm.setdefault("fieldMappings", []) if isinstance(_fm, dict) else []
    for _fname, _meta in ((_artifact_meta.get("xbm") or {}).items() if isinstance(_artifact_meta, dict) else []):
        if not isinstance(_meta, dict):
            continue
        if _meta.get("logical_name"):
            _fm_rows.append({"path": "objects.data_map.map_name", "value": _meta.get("logical_name"), "sourceFile": _fname, "rule": "XBM transformMap logicalName", "confidence": "high"})
        if _meta.get("contivo_version"):
            _fm_rows.append({"path": "objects.data_map.contivo_version", "value": _meta.get("contivo_version"), "sourceFile": _fname, "rule": "XBM analystVersionLastSaved", "confidence": "high"})
        if _meta.get("src_root_in_map"):
            _fm_rows.append({"path": "objects.source_document_type.document_identifier.rows", "value": _meta.get("src_root_in_map"), "sourceFile": _fname, "rule": "XBM source schema root", "confidence": "high"})
        if _meta.get("tgt_root_in_map"):
            _fm_rows.append({"path": "objects.target_document_type.document_identifier.rows", "value": _meta.get("tgt_root_in_map"), "sourceFile": _fname, "rule": "XBM target schema root", "confidence": "high"})
    for _fname, _meta in ((_artifact_meta.get("jar") or {}).items() if isinstance(_artifact_meta, dict) else []):
        if not isinstance(_meta, dict):
            continue
        _fm_rows.append({"path": "objects.data_map.map_data_file", "value": _fname, "sourceFile": _fname, "rule": "uploaded Contivo JAR", "confidence": "high"})
        _classes = _meta.get("transform_classes") or []
        if _classes:
            _fm_rows.append({"path": "objects.data_map.map_class", "value": _classes[0], "sourceFile": _fname, "rule": "Transform_*.class inside JAR", "confidence": "high"})
    # Preserve the raw customer-file facts before UI hints can override them.
    # V77 uses these exact evidence rows to detect an explicit UI-vs-file conflict
    # and asks the operator to choose instead of silently applying precedence.
    _detected_tx = analysis.get("detected_tx") if isinstance(analysis.get("detected_tx"), dict) else {}
    _src_evidence_file = str((analysis.get("_file_mapping") or {}).get("source", {}).get("filename") or (pths[0].name if pths else "customer file"))
    if analysis.get("customer"):
        _fm_rows.append({"path": "customer", "value": analysis.get("customer"), "sourceFile": _src_evidence_file, "rule": "customer/partner identity detected from customer artifact", "confidence": "medium"})
    if _detected_tx.get("direction"):
        _fm_rows.append({"path": "direction", "value": str(_detected_tx.get("direction")).title(), "sourceFile": _src_evidence_file, "rule": "business direction detected from physical payload semantics", "confidence": "high"})
    if _detected_tx.get("name"):
        _fm_rows.append({"path": "tx_name", "value": _detected_tx.get("name"), "sourceFile": _src_evidence_file, "rule": "transaction name detected from payload semantics", "confidence": "high"})
    if (_artifact_meta.get("xbm") or _artifact_meta.get("jar")):
        _fm_rows.append({"path": "flow_type", "value": "translation", "sourceFile": next(iter((_artifact_meta.get("xbm") or _artifact_meta.get("jar") or {"mapping artifact": {}}).keys())), "rule": "XBM/JAR mapping artifact proves translation", "confidence": "high"})

    folder_name = _meaningful_artifact_folder_hint(folder_name or pths[0].parent.name)
    hints = _agt_from_foldername(folder_name)
    if customer:
        analysis["customer"] = customer
        analysis["_force_customer"] = True
    elif not analysis.get("customer"):
        analysis["customer"] = hints.get("customer", "")
    if direction:
        analysis.setdefault("detected_tx", {})["direction"] = direction.title()
    elif hints.get("direction") and not analysis.get("detected_tx", {}).get("direction"):
        analysis.setdefault("detected_tx", {})["direction"] = hints["direction"].title()

    llm_hints: Dict[str, Any] = {}
    llm_error = ""
    llm_used = False
    llm_invoked = False
    try:
        from input_builder_aia_adapter import diagnostics as _aia_diag, extract_builder_hints as _aia_extract, get_mode as _aia_mode
        _diag = _aia_diag()
        _enabled = (_aia_mode() != "off") if use_dell_aia is None else bool(use_dell_aia)
        if _enabled:
            llm_invoked = True
            llm_hints = _aia_extract(analysis, file_contents) or {}
            llm_used = bool(llm_hints)
            analysis = _merge_llm_hints_into_analysis(analysis, llm_hints)
    except Exception as exc:
        _diag = {"provider": "Dell AIA", "model": "gpt-oss-120b", "mode": "unavailable", "ready": False}
        llm_error = f"{type(exc).__name__}: {exc}"

    if requires_data_map is None:
        if flow_type:
            # Explicit user selection always wins over artifact heuristics.
            requires_data_map = flow_type.lower() == "translation"
        else:
            # Any real mapping artifact keeps the flow in Translation.  A lone
            # XBM means Translation with a missing-JAR blocker, not Passthrough.
            has_xbm = bool((_artifact_meta.get("xbm") or {}))
            has_jar = bool((_artifact_meta.get("jar") or {})) or bool(analysis.get("has_jar"))
            requires_data_map = bool(has_xbm or has_jar)
    state = {"requires_data_map": bool(requires_data_map)}
    legacy = _agt_build_full_config(analysis, state, llm_hints)
    object_keys = (
        "data_map", "source_document_type", "target_document_type", "rule",
        "source_transport_profile", "target_transport_profile", "biz_flow",
    )
    objects = {k: deepcopy(legacy.get(k)) for k in object_keys if k in legacy}
    objects = _canonicalize_rule_attribute_keys(objects)
    cfg = {
        "profile_name": legacy.get("flow_name", ""),
        "customer": customer or legacy.get("customer", "") or hints.get("customer", ""),
        "folder": folder_name,
        "tx_standard": ({"EDIX12":"X12","EDIFACT":"EDIFACT","XML":"XML","CXML":"cXML","CSV":"CSV","JSON":"JSON","FLATFILE":"FlatFile"}.get(str((analysis.get("payload_roles") or {}).get("source_format") or "").upper()) or legacy.get("transaction", {}).get("standard", "")),
        "tx_code": legacy.get("transaction", {}).get("code", ""),
        "tx_name": legacy.get("transaction", {}).get("name", ""),
        "direction": direction.title() if direction else legacy.get("flow_direction", ""),
        "flow_type": (flow_type.lower() if flow_type else ("translation" if requires_data_map else "passthrough")),
        "requires_data_map": bool(requires_data_map),
        "objects": objects,
        "missing_fields": legacy.get("missing_fields", []),
        "completeness": legacy.get("completeness"),
        "accuracy": legacy.get("accuracy"),
        "source_format": str((analysis.get("payload_roles") or {}).get("source_format") or ""),
        "_file_mapping": deepcopy(analysis.get("_file_mapping") or {}),
        "_source": "raw customer artifacts — deterministic + Dell AIA gap-fill",
        "_agent": {
            "provider": _diag.get("provider", "Dell AIA"),
            "base_url": _diag.get("base_url", ""),
            "model": _diag.get("model", "gpt-oss-120b"),
            "mode": _diag.get("mode", ""),
            "ready": bool(_diag.get("ready", False)),
            "llm_requested": bool((_diag.get("mode") != "off") if use_dell_aia is None else use_dell_aia),
            "llm_invoked": llm_invoked,
            "llm_used": llm_used,
            "llm_error": llm_error,
        },
    }
    out = normalize_input_json(cfg, customer=cfg["customer"], folder_name=folder_name,
                               direction=cfg["direction"], flow_type=cfg["flow_type"])
    # normalize_input_json deep-copies and preserves metadata, but ensure agent audit exists.
    out.setdefault("_agent", cfg["_agent"])
    return out



def _canonical_input_json_candidate(value: Any) -> Tuple[int, Optional[Dict[str, Any]]]:
    """Recognize an already-built HIP input/config JSON by structure.

    This deliberately ignores filenames.  Customer packages commonly contain
    names such as ``*_dev_approved.json`` and sometimes wrap the canonical value
    under ``input``/``configuration``.  A normal business payload JSON must not
    become authoritative merely because it is JSON, so at least three HIP object
    sections are required.
    """
    if not isinstance(value, dict):
        return 0, None

    candidates: List[Tuple[str, Dict[str, Any]]] = [("root", value)]
    for wrapper in ("input", "configuration", "config"):
        inner = value.get(wrapper)
        if isinstance(inner, dict):
            candidates.append((wrapper, inner))

    object_keys = {
        "data_map", "source_document_type", "target_document_type", "rule",
        "source_transport_profile", "target_transport_profile", "biz_flow",
    }

    def _section_present(section: Any) -> bool:
        if isinstance(section, dict):
            return True
        if isinstance(section, list):
            return any(isinstance(item, dict) for item in section)
        return False

    best_score = 0
    best: Optional[Dict[str, Any]] = None
    for wrapper, candidate in candidates:
        objects = candidate.get("objects") if isinstance(candidate.get("objects"), dict) else candidate
        if not isinstance(objects, dict):
            continue
        present = sum(1 for key in object_keys if _section_present(objects.get(key)))
        if present < 3:
            continue
        score = present * 10
        for key in ("profile_name", "customer", "tx_code", "direction", "flow_type", "requires_data_map"):
            if key in candidate:
                score += 2
        if wrapper != "root":
            score += 3
        if score > best_score:
            best_score, best = score, deepcopy(candidate)
    return best_score, best


def _canonical_input_json_file_score(path: Path) -> Tuple[int, Optional[Dict[str, Any]]]:
    if not path.is_file() or path.suffix.lower() != ".json":
        return 0, None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return 0, None
    score, candidate = _canonical_input_json_candidate(value)
    if not candidate:
        return 0, None
    low = path.name.lower()
    if low == "input.json":
        score += 100
    if any(token in low for token in ("dev_approved", "approved", "input", "configuration", "profile")):
        score += 15
    return score, candidate


def build_from_zip(source: Union[str, Path, bytes], *, customer: str = "",
                   direction: str = "", flow_type: str = "",
                   prefer_config_manual: bool = False,
                   use_dell_aia: Optional[bool] = None,
                   mapping_knowledge: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build input.json from a ZIP.

    Default is canonical-config-first/raw-first, matching the agent report: an
    embedded Configuration Manual is optional validation, not source of truth.
    The user can explicitly set prefer_config_manual=True to parse it instead.
    """
    if isinstance(source, (str, Path)):
        raw = Path(source).read_bytes()
        archive_name = Path(source).stem
    else:
        raw = source
        archive_name = "uploaded_zip"
    with tempfile.TemporaryDirectory(prefix="hip_input_builder_") as td:
        root = Path(td)
        with zipfile.ZipFile(__import__('io').BytesIO(raw)) as zf:
            for member in zf.infolist():
                target = (root / member.filename).resolve()
                if root.resolve() not in target.parents and target != root.resolve():
                    raise ValueError(f"Unsafe ZIP member: {member.filename}")
            zf.extractall(root)
        files = [p for p in root.rglob("*") if p.is_file()]
        manuals = [p for p in files if p.suffix.lower() in (".xlsx", ".xlsm") and
                   ("config" in p.name.lower() or "manual" in p.name.lower())]
        raw_files = [p for p in files if p.suffix.lower() in {".xml", ".edi", ".x12", ".csv", ".txt", ".json", ".jar", ".xbm"}]

        # An approved/canonical HIP JSON inside a ZIP is configuration, not a raw
        # business payload.  Detect it by schema and keep it authoritative; all
        # other files become supporting evidence that may only fill blanks.
        approved_path: Optional[Path] = None
        approved_input: Optional[Dict[str, Any]] = None
        approved_score = 0
        for candidate in [p for p in files if p.suffix.lower() == ".json"]:
            score, value = _canonical_input_json_file_score(candidate)
            if score > approved_score:
                approved_path, approved_input, approved_score = candidate, value, score
        if approved_input is not None:
            approved_customer = str(approved_input.get("customer") or customer or "")
            approved_direction = str(approved_input.get("direction") or direction or "")
            approved_flow_type = str(approved_input.get("flow_type") or "").strip().lower()
            if not approved_flow_type and "requires_data_map" in approved_input:
                approved_flow_type = "translation" if bool(approved_input.get("requires_data_map")) else "passthrough"
            if not approved_flow_type:
                approved_flow_type = str(flow_type or "").strip().lower()
            supporting = [
                p for p in raw_files
                if approved_path is None or p.resolve() != approved_path.resolve()
            ]
            if supporting:
                evidence = build_from_raw_files(
                    supporting, customer=approved_customer, direction=approved_direction,
                    flow_type=approved_flow_type, folder_name=archive_name,
                    use_dell_aia=use_dell_aia, mapping_knowledge=mapping_knowledge,
                )
                result = combine_existing_input_with_artifact_evidence(
                    approved_input, evidence, manifest=[p.name for p in supporting],
                    customer=approved_customer, direction=approved_direction,
                    flow_type=approved_flow_type,
                )
            else:
                result = normalize_input_json(
                    approved_input, customer=approved_customer,
                    direction=approved_direction, flow_type=approved_flow_type,
                )
            result.setdefault("_builder_audit", {})["authoritative_json"] = {
                "filename": approved_path.name if approved_path else "embedded HIP JSON",
                "source": "canonical HIP JSON inside ZIP",
                "inputJsonAuthoritative": True,
                "note": "Supporting files only fill blanks or validate evidence; approved JSON business values are preserved.",
            }
            return result

        if manuals and raw_files:
            return build_from_config_manual_and_raw_files(
                manuals[0], raw_files, folder_name=manuals[0].parent.name or archive_name,
                customer=customer, direction=direction, flow_type=flow_type,
                use_dell_aia=use_dell_aia, manual_primary=bool(prefer_config_manual),
                mapping_knowledge=mapping_knowledge,
            )
        if manuals and not raw_files:
            return build_from_config_manual(manuals[0], folder_name=manuals[0].parent.name or archive_name,
                                            customer=customer, direction=direction, flow_type=flow_type)
        return build_from_raw_files(raw_files, customer=customer, direction=direction,
                                    flow_type=flow_type, folder_name=archive_name,
                                    use_dell_aia=use_dell_aia, mapping_knowledge=mapping_knowledge)

def save_input_json(config: Dict[str, Any], output_path: Union[str, Path]) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def _builder_path_get(data: Any, path: str) -> Any:
    cur = data
    # Dotted dict paths are sufficient for the high-confidence artifact checks.
    for part in str(path or '').split('.'):
        if not part:
            continue
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def combine_existing_input_with_artifact_evidence(
    input_data: Dict[str, Any],
    evidence: Dict[str, Any],
    *,
    manifest: Optional[List[str]] = None,
    customer: str = '',
    direction: str = '',
    flow_type: str = '',
) -> Dict[str, Any]:
    """Use an existing input.json as authoritative config while ingesting supporting files.

    Supporting artifacts are used to fill only blank high-confidence fields and to
    validate concrete mapping evidence (JAR/XBM) against the JSON. They never
    silently overwrite an explicit business value supplied in input.json.
    """
    explicit_input_flow = str(input_data.get("flow_type") or "").strip().lower() if isinstance(input_data, dict) else ""
    explicit_input_requires = input_data.get("requires_data_map") if isinstance(input_data, dict) and "requires_data_map" in input_data else None
    raw_input_target = deepcopy(((input_data.get("objects") or {}).get("target_document_type"))) if isinstance(input_data, dict) and isinstance(input_data.get("objects"), dict) else None
    base = normalize_input_json(input_data, customer=customer, direction=direction, flow_type=flow_type)
    ev = deepcopy(evidence or {})
    files = [Path(str(x)).name for x in (manifest or []) if str(x).strip()]
    lower_files = {x.lower() for x in files}
    audit: Dict[str, Any] = {
        'mode': 'existing_input_json_plus_supporting_artifacts',
        'inputJsonAuthoritative': True,
        'fileCount': len(files),
        'files': files,
        'matched': [],
        'enriched': [],
        'warnings': [],
        'blockers': [],
    }

    # Fill only fields that are genuinely blank in the authoritative JSON.
    fill_paths = [
        'customer', 'tx_standard', 'tx_code', 'tx_name', 'direction', 'profile_name',
        'objects.data_map.map_identifier', 'objects.data_map.map_name',
        'objects.data_map.map_class', 'objects.data_map.map_data_file',
        'objects.data_map.contivo_version',
        'objects.source_document_type.name',
        'objects.source_document_type.transaction_type',
        'objects.source_document_type.document_identifier',
        'objects.source_document_type.attributes_to_configure',
        'objects.target_document_type.name',
        'objects.target_document_type.transaction_type',
        'objects.target_document_type.document_identifier',
        'objects.target_document_type.attributes_to_configure',
        'objects.source_document_type.data_format_type',
        'objects.target_document_type.data_format_type',
        'objects.rule.name', 'objects.rule.conditions', 'objects.rule.actions',
        'objects.source_transport_profile.system_type',
        'objects.source_transport_profile.partner_name',
        'objects.source_transport_profile.profile_name',
        'objects.source_transport_profile.existing_account_name',
        'objects.source_transport_profile.subscription_folder',
        'objects.source_transport_profile.document_type',
        'objects.target_transport_profile.system_type',
        'objects.target_transport_profile.partner_name',
        'objects.target_transport_profile.profile_name',
        'objects.target_transport_profile.existing_account_name',
        'objects.target_transport_profile.subscription_folder',
        'objects.target_transport_profile.document_type',
        'objects.biz_flow.flow_details',
        'objects.biz_flow.configure_source',
        'objects.biz_flow.flow_identifiers',
        'objects.biz_flow.configure_targets',
        'objects.biz_flow.process_steps',
        'objects.biz_flow.configure_routing',
        'partner_identifier_value',
        'source_format',
    ]
    for path in fill_paths:
        current = _builder_path_get(base, path)
        candidate = _builder_path_get(ev, path)
        if current in (None, '', [], {}) and candidate not in (None, '', [], {}):
            _set_flattened_path(base, path, deepcopy(candidate))
            audit['enriched'].append({'path': path, 'value': candidate, 'source': 'supporting_artifact'})

    # If the uploaded input.json did not explicitly choose a flow type, mapping
    # artifacts are allowed to teach the canonical config that this is a
    # Translation flow.  Explicit input.json/user choices still win.
    evidence_translation = str(ev.get("flow_type") or "").strip().lower() == "translation" or bool(ev.get("requires_data_map"))
    no_explicit_flow = not flow_type and not explicit_input_flow and explicit_input_requires is None
    if no_explicit_flow and evidence_translation:
        base["flow_type"] = "translation"
        base["requires_data_map"] = True
        # Preserve a target Document Type that the uploaded input contained but
        # an earlier provisional Passthrough normalization may have blanked.
        if isinstance(raw_input_target, dict) and str(raw_input_target.get("name") or "").strip():
            base.setdefault("objects", {})["target_document_type"] = raw_input_target
        base = normalize_input_json(
            base, customer=customer or str(base.get("customer") or ""),
            direction=direction or str(base.get("direction") or ""), flow_type="translation",
        )
        audit['enriched'].append({'path': 'flow_type', 'value': 'translation', 'source': 'mapping_artifact_evidence'})

    def cmp(path: str, *, severity: str = 'warning') -> None:
        left = _builder_path_get(base, path)
        right = _builder_path_get(ev, path)
        if left in (None, '', [], {}) or right in (None, '', [], {}):
            return
        if str(left).strip().lower() == str(right).strip().lower():
            audit['matched'].append({'path': path, 'value': left})
        else:
            item = {'path': path, 'inputJson': left, 'artifactEvidence': right,
                    'message': f"input.json value {left!r} differs from supporting-artifact evidence {right!r}."}
            audit['blockers' if severity == 'blocker' else 'warnings'].append(item)

    # Carry the physical file→input.json mapping trace forward so the UI and
    # reference learner can explain exactly which uploaded file populated which
    # canonical field.
    if isinstance(ev.get('_file_mapping'), dict):
        base['_file_mapping'] = deepcopy(ev.get('_file_mapping'))

    # Concrete map artifacts are strong evidence; business direction/transaction
    # differences are review warnings because sample sets can contain both sides.
    cmp('objects.data_map.map_name', severity='blocker')
    cmp('objects.data_map.map_class', severity='warning')
    # Physical source/target format mismatches are strong evidence errors.  An
    # XML source file cannot legitimately produce an EDIX12 source Document Type.
    cmp('objects.source_document_type.data_format_type', severity='blocker')
    if bool(base.get('requires_data_map')) or str(base.get('flow_type') or '').lower() == 'translation':
        cmp('objects.target_document_type.data_format_type', severity='blocker')
    cmp('direction', severity='warning')
    cmp('flow_type', severity='warning')
    cmp('tx_code', severity='warning')

    requires_map = bool(base.get('requires_data_map')) or str(base.get('flow_type') or '').lower() == 'translation'
    map_obj = (base.get('objects') or {}).get('data_map') if isinstance(base.get('objects'), dict) else {}
    map_obj = map_obj if isinstance(map_obj, dict) else {}
    map_file = str(map_obj.get('map_data_file') or '').strip()
    if requires_map:
        jars = [x for x in files if x.lower().endswith('.jar')]
        xbms = [x for x in files if x.lower().endswith('.xbm')]
        # Cross-platform upload hardening: if the authoritative input.json and
        # parsed evidence both leave map_data_file blank, but the current upload
        # manifest contains exactly one JAR, that filename is deterministic
        # evidence and can safely fill the blank. This never overwrites an
        # explicit input.json value and avoids relying on machine-specific paths.
        if not map_file and len(jars) == 1:
            map_file = jars[0]
            _set_flattened_path(base, 'objects.data_map.map_data_file', map_file)
            audit['enriched'].append({
                'path': 'objects.data_map.map_data_file',
                'value': map_file,
                'source': 'supporting_artifact_manifest',
            })
        if not jars:
            audit['blockers'].append({'path': 'objects.data_map.map_data_file', 'message': 'Translation flow requires the approved mapping JAR in the supporting files.'})
        if map_file and map_file.lower() not in lower_files:
            audit['blockers'].append({'path': 'objects.data_map.map_data_file', 'message': f"input.json references mapping JAR {map_file!r}, but that file was not uploaded."})
        if not xbms:
            audit['warnings'].append({'path': 'supporting_artifacts.xbm', 'message': 'No XBM was uploaded. Live map creation can still use the approved JAR, but XBM cross-validation is unavailable.'})

    xmls = [x for x in files if x.lower().endswith('.xml')]
    if not xmls:
        audit['warnings'].append({'path': 'supporting_artifacts.xml', 'message': 'No XML sample was uploaded, so document/root cross-validation is limited.'})

    base['_artifact_validation'] = audit
    base.setdefault('_builder_audit', {})['supporting_artifacts'] = {
        'fileCount': len(files),
        'mode': 'input_json_plus_artifacts',
        'matchedCount': len(audit['matched']),
        'enrichedCount': len(audit['enriched']),
        'warningCount': len(audit['warnings']),
        'blockerCount': len(audit['blockers']),
        'source': 'input_json + uploaded supporting artifacts',
    }
    base['_source'] = 'existing input.json + supporting customer artifacts'
    return base
