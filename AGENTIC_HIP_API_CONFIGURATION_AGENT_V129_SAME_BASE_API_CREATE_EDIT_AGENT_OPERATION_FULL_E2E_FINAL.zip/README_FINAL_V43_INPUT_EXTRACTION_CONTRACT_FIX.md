# V43 - Input Extraction + API Contract Blocker Fix

This release fixes the React Input Builder and 18-API validation behavior reported with the Legrand approved configuration.

## Fixed

- Approved HIP JSON is auto-detected by structure, not only by the literal filename `input.json`.
- Files such as `LEGRAND_NEDERLAND_dev_approved.json` stay authoritative even when the UI is left on **Customer files only**.
- Approved JSON direction/transaction values are preserved over fresh-card convenience defaults.
- Supporting customer XML/EDI/XBM/JAR files fill only blanks and provide evidence; they do not overwrite approved business values.
- XBM/JAR extraction now exposes Data Map name, class, JAR, Contivo version, and source/target schema roots in the file-to-input mapping evidence.
- Repeated partner identity is resolved from approved Sender/Receiver routing conditions instead of being asked again.
- Shared SFTP/FTP UAT accounts and provable subscription paths are resolved where applicable.
- Runner and mapper use the same partner-identifier derivation so Partner Create validation does not disagree with Input Builder.
- 18-API validation now returns `blockedItems`, exact errors, and a concrete `nextAction` for every blocked request.
- React validation UI renders each blocked API, exact field/message, next action, **Open API Testing Area**, and **Re-run validation** controls.

## Verification performed

- Legrand approved-JSON regression: PASS; 0 unresolved questions.
- Customer XBM/JAR map extraction regression: PASS.
- Local API contract validation on the packaged reference configuration: 18/18 PASS, 0 blocked.
- Relevant existing Python regression tests: PASS.
- Changed TSX files: TypeScript syntax transpilation PASS.

The container used to prepare this package did not contain the frontend npm dependencies (`node_modules`), so a full Vite build could not be executed locally without downloading dependencies. The package retains the normal frontend install/build commands for the target machine.
