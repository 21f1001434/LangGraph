# V71 — Canonical 18-API Payload Structure Lock

## Rule

The **developer-tested U-HAUL request structure is the immutable structural contract for all 18 HIP APIs**.

For U-HAUL, Legrand, or any later customer:

- JSON attribute/key names do **not** change.
- Nested object structure does **not** change.
- Canonical array positions/cardinality do **not** change.
- A step cannot switch between request `payload` and query `params`.
- `flowDefinition` keeps the same inner JSON attributes even though it is transported as a string.
- **Only customer-specific values change.**

This is a structure reference only. **U-HAUL business values are never copied into another customer.** If a new customer value cannot be extracted/derived/proven, it stays missing/neutral and the normal validation/intake workflow asks for the value instead of borrowing a U-HAUL value.

## Where the lock is enforced

The same canonical request projection is used by:

1. Build/18-API request preview.
2. API Testing Area.
3. Persisted `payload_overrides.json` edits.
4. API Flow Game block payload edits.
5. API Flow Game connection mappings.
6. Individual Flow Game LIVE blocks.
7. Execute single-customer and multi-customer runs.
8. Skipped/pre-existing audit payloads.
9. Final effective request construction immediately before LIVE.

This removes the previous class of defect where API Testing could create successfully while Flow Game/Execute sent a differently shaped customer payload.

## Legacy customer workspaces

When an older `payload_overrides.json` contains Legrand/customer-specific fields that are not part of the canonical 18-API request structure, V71 automatically migrates the file:

- valid canonical customer values are preserved;
- non-canonical fields are removed;
- removed paths are recorded under `structureLockMigration` for audit;
- no U-HAUL values are injected.

New edits are stricter: an operator cannot save a newly invented/renamed JSON attribute. The UI reports `CANONICAL_PAYLOAD_STRUCTURE_LOCK` and asks the operator to edit an existing field's value instead.

## `workType`

The previous developer rule remains unchanged: `workType` is HIP-owned internal metadata. It is omitted/stripped and is not allowed to become a customer payload attribute.

## Frozen catalog

The machine-readable structural catalog is:

`schemas/uhal_canonical_18_request_shapes.json`

It contains exactly 18 step structures and is consumed by `canonical_payload_contract.py`.

## Verification intent

V71 regression coverage verifies that:

- all 18 packaged U-HAUL requests still match the frozen structure exactly;
- a Legrand-like workspace produces the same 18 JSON structures while retaining Legrand values;
- unknown top-level, nested and parameter attributes cannot reach an effective request;
- old bad overrides are migrated safely;
- replace-mode edits cannot accidentally delete canonical attributes;
- Flow Game edits and nested `flowDefinition` edits cannot introduce fields;
- HIP-owned `workType` remains stripped.
