# V105 — Dev Feedback: Mapping Rule Contract + Audit Polling

This release applies the 2026-08-28 HIP developer feedback to the production execution path.

## Mapping Rule
- `documentTypeId` is omitted from the Rule body.
- `actions[].params.mapId` is omitted.
- The developer-approved structure is immutable; the agent cannot add these fields back.

## Transport Profile completion
- Source/Target TP create requests are followed by the TP Audit API.
- Poll interval: 60 seconds by default.
- Terminal status: SUCCESS or FAILURE.
- Timeout: 3600 seconds. A non-terminal TP after one hour is reported as stuck/error.
- Flow Create is dependency-gated on successful Source and Target TP audits.

## Flow deployment completion
- After Flow Deploy, deployment Audit/History is polled every 60 seconds.
- The run finishes Flow deployment only after terminal SUCCESS/FAILURE.
- One-hour non-terminal timeout is reported as stuck/error.

## Flow Create 400/name collision
- The original customer flow name is tried first.
- On the developer-observed Flow Create 400/name collision, V105 derives a different name from the customer base name, validates it, retries Flow Create, and uses the same effective name for deploy/history/reporting.
- The approved API schema is not mutated; only the flow-name value changes as explicitly requested by the developer.

## Retained controls
- Default deployment group: `hip-automation`.
- Existing approved U-HAUL MAP ID 1670 may be reused on an existing-map response.
- No MAP edit/update API is introduced.
- Customer MAP business values continue to originate from customer input files/canonical input.

## Final validation
- Python regression: **401/401 PASS** (353 top-level + 48 FastAPI backend tests).
- Business-readiness workflow: **69/69 PASS**.
- Final Release validator: **16/16 PASS**.
- Package validator: **58/58 PASS**.
- Adaptive package validator: **60/60 PASS**.
- Required self-checks: **45/45 PASS**.
- Phase validators: **12/12, 19/19, 31/31, 26/26, 28/28, 38/38 PASS**.
- TypeScript/TSX syntax: **24 files, 0 syntax diagnostics**.
- Real FastAPI/Uvicorn startup: `/api/health` and `/api/bootstrap` return HTTP 200; bootstrap exposes Phase 6, 18 API blocks and `hip-automation`.

Packaging validation is non-mutating. Credentialed Dell HIP/AIA LIVE execution must run on the authorized Dell network and its actual responses are captured by the application's evidence/reporting layer.
