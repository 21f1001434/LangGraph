@echo off
rem Phase 6 compatibility alias. Installs/builds the React/FastAPI Studio.
call "%~dp0SETUP_AGENTIC_HIP.bat"
exit /b %errorlevel%
