from pathlib import Path

import pytest

import connection_check
from uhal_mapper import UhalInputMapper


def test_mapper_reads_legacy_nested_partner_identifier(tmp_path: Path):
    input_data = {
        "profile_name": "FLOW",
        "objects": {
            "source_document_type": {"name": "SRC", "version": "1.0", "api_transaction_type": "INBOUND"},
            "source_transport_profile": {"system_type": "Dell Application", "system_name": "AIC - DCE", "profile_name": "SRC_TP", "existing_account_name": "src"},
            "target_transport_profile": {"system_type": "Partner", "partner_name": "PARTNER", "profile_name": "TGT_TP", "existing_account_name": "tgt"},
            "biz_flow": {
                "configure_source": {"source_transport_profile": "SRC_TP"},
                "configure_targets": {"target_transport_profile": "TGT_TP"},
                "flow_identifiers": {"conditions": [{"attribute_name": "Receiver", "operator": "Equals", "value": "X"}]},
            },
        },
    }
    config = {"partnerCreate": {"partnerIdentifierValue": "REAL-DUNS"}}
    mapper = UhalInputMapper(input_data, config, tmp_path)
    assert mapper.normalized()["partnerIdentifierValue"] == "REAL-DUNS"
    assert not [x for x in mapper.validate() if x.field == "partnerIdentifierValue"]


def test_secure_connection_status_does_not_depend_on_payload_readiness():
    components = {
        "dellAia": {"status": "OK"},
        "mcp": {"status": "OK"},
        "hipOAuth": {"status": "OK"},
        "accountOAuth": {"status": "OK"},
        "partnerOAuth": {"status": "OK"},
        "systemOAuth": {"status": "OK"},
    }
    mandatory = ["dellAia", "mcp", "hipOAuth", "accountOAuth", "partnerOAuth", "systemOAuth"]
    assert connection_check._secure_connections_ok(components, mandatory) is True
    # A missing DUNS belongs to configuration readiness and must not alter this result.
    configuration_readiness = {"ready": False, "errors": ["partnerIdentifierValue missing"]}
    assert configuration_readiness["ready"] is False
    assert connection_check._secure_connections_ok(components, mandatory) is True


def test_runner_reads_service_credentials_from_legacy_test_py(monkeypatch, tmp_path: Path):
    import run_agent

    test_py = tmp_path / "Test.py"
    test_py.write_text(
        "HIP_TOKEN_URL='https://example.test/oauth/token'\n"
        "HIP_CLIENT_ID='hip-id'\n"
        "HIP_CLIENT_SECRET='hip-secret'\n"
        "ACCOUNT_TOKEN_URL='https://example.test/oauth/token'\n"
        "ACCOUNT_CLIENT_ID='account-id'\n"
        "ACCOUNT_CLIENT_SECRET='account-secret'\n"
        "PARTNER_TOKEN_URL='https://example.test/oauth/token'\n"
        "PARTNER_CLIENT_ID='partner-id'\n"
        "PARTNER_CLIENT_SECRET='partner-secret'\n"
        "SYSTEM_TOKEN_URL='https://example.test/oauth/token'\n"
        "SYSTEM_CLIENT_ID='system-id'\n"
        "SYSTEM_CLIENT_SECRET='system-secret'\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(run_agent, "find_test_py", lambda: test_py)
    for key in [
        "HIP_TOKEN_URL", "HIP_CLIENT_ID", "HIP_CLIENT_SECRET",
        "ACCOUNT_TOKEN_URL", "ACCOUNT_CLIENT_ID", "ACCOUNT_CLIENT_SECRET",
        "PARTNER_TOKEN_URL", "PARTNER_CLIENT_ID", "PARTNER_CLIENT_SECRET",
        "SYSTEM_TOKEN_URL", "SYSTEM_CLIENT_ID", "SYSTEM_CLIENT_SECRET",
    ]:
        monkeypatch.delenv(key, raising=False)

    runner = run_agent.Runner(llm_enabled=False)
    assert runner.account_client_id == "account-id"
    assert runner.account_client_secret == "account-secret"
    assert runner.partner_client_id == "partner-id"
    assert runner.partner_client_secret == "partner-secret"
    assert runner.system_client_id == "system-id"
    assert runner.system_client_secret == "system-secret"
