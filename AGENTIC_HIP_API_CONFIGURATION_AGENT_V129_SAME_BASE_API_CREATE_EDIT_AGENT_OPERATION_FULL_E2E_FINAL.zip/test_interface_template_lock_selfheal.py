from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import psutil

import run_agent
from configuration_workspace import clone_uhaul_template
from runtime_payload_values import placeholder, save_runtime_payload_values, clear_runtime_payload_values
from production_guard import (
    clear_stale_live_run,
    inspect_live_run,
    runtime_lock_path,
    terminate_live_run,
)

ROOT = Path(__file__).resolve().parent


def _check_interface_payloads() -> dict:
    runner = run_agent.Runner(llm_enabled=False)

    save_runtime_payload_values(ROOT, {"target": {"receiver_client_secret": "TEST_ONLY_NOT_REAL_SECRET"}}, merge=False)
    https_receiver = {
        "profile_usage": "Receiver",
        "interface_type": "HTTPS",
        "interface_parameters": {
            "Protocol": "REST",
            "Partner URL": "https://partner.example",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "URL will be shared later after API Publish is successful.",
            "SSL Certificate": "sample.crt",
            "Are Input Files Compressed?": "False",
            "SSL Certificate CN - Expiry": "Sample CA - 2030-09-28",
            "Receiver Grant Type": "client_credentials",
            "Receiver Token Endpoint": "https://partner.example/oauth/token",
            "Receiver Client Id": "sample-client-id",
            "Receiver Client Secret": placeholder("target.receiver_client_secret"),
            "SSL Certificate Id": "sample-cert-id",
        },
    }
    receiver_params = runner.tp_parameters(https_receiver)
    assert receiver_params["Protocol"] == "REST"
    assert receiver_params["Partner URL"] == "https://partner.example"
    assert receiver_params["Receiver Authentication Type"] == "OAuth2"
    assert receiver_params["Receiver Grant Type"] == "client_credentials"
    # UI request inspection must never expose the actual secret.
    assert receiver_params["Receiver Client Secret"] == placeholder("target.receiver_client_secret")
    assert "Existing Account Name" not in receiver_params

    # The actual secret is injected only immediately before a live HTTP send.
    live_runner = run_agent.Runner(llm_enabled=False)
    live_resolved = live_runner._resolve_runtime_payload_values(receiver_params)
    assert live_resolved["Receiver Client Secret"] == "TEST_ONLY_NOT_REAL_SECRET"

    https_sender = {
        "profile_usage": "Sender",
        "interface_type": "HTTPS",
        "interface_parameters": {
            "Protocol": "REST",
            "HIP URL": "URL will be shared later after API Publish is successful.",
            "Proxy URI": "dce-common-sv1",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Sender Authentication Type": "OAuth2",
            "Are Input Files Compressed?": "False",
            "Sender Grant Type": "client_credentials",
        },
    }
    sender_params = runner.tp_parameters(https_sender)
    assert sender_params["Proxy URI"] == "dce-common-sv1"
    assert sender_params["Sender Authentication Type"] == "OAuth2"

    sftp = {
        "profile_usage": "Sender",
        "interface_type": "SFTP",
        "interface_environment": "UAT",
        "existing_account": "Yes",
        "existing_account_name": "acct",
        "subscription_folder": "/folder",
    }
    ftp = dict(sftp)
    ftp["interface_type"] = "FTP"
    sftp_params = runner.tp_parameters(sftp)
    ftp_params = runner.tp_parameters(ftp)
    assert runner.tp_interface_type(sftp) == "SFTP HAFT"
    assert runner.tp_interface_type(ftp) == "FTP"
    assert sftp_params["Existing Account Name"] == "acct"
    assert ftp_params["Existing Account Name"] == "acct"
    assert sftp_params["Subscription Folder"] == ftp_params["Subscription Folder"]

    as2 = {
        "profile_usage": "Receiver",
        "interface_type": "HTTPS-AS2",
        "interface_parameters": {
            "Partner AS2 URL": "https://partner.example/as2",
            "Partner AS2 ID": "PARTNER_AS2",
            "Dell AS2 ID": "HIP_AS2",
            "Signing Algorithm": "SHA256",
            "Encryption Algorithm": "AES256",
            "Approved AS2 Field": "MUST_NOT_APPEAR",
        },
    }
    as2_params = runner.tp_parameters(as2)
    assert as2_params["Partner URL"] == "https://partner.example/as2"
    assert as2_params["Partner Identifier"] == "PARTNER_AS2"
    assert as2_params["Dell Identifier"] == "HIP_AS2"
    assert as2_params["Signing Algorithm"] == "SHA256"
    assert as2_params["Encryption Algorithm"] == "AES256"
    assert "Approved AS2 Field" not in as2_params

    clear_runtime_payload_values(ROOT)
    return {
        "httpsReceiverFields": sorted(receiver_params),
        "httpsSenderFields": sorted(sender_params),
        "secretHiddenInUiPreview": True,
        "secretResolvedOnlyBeforeLiveSend": True,
        "sftpAndFtpShareFileModel": True,
        "httpsAs2UsesFixedDeveloperApprovedShape": True,
    }


def _check_template_clone() -> dict:
    template = json.loads(
        (ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8")
    )

    cloned = clone_uhaul_template(
        template,
        customer="ACME",
        changes={
            "target_partner": "ACME-PARTNER",
            "source_interface_type": "HTTPS",
            "target_interface_type": "HTTPS",
            "source_flow_tp": "da-sender-https-dce-common",
            "target_flow_tp": "pt-receiver-https-dce-common",
            "source_interface_parameters": {
                "Protocol": "REST",
                "Proxy URI": "dce-common-sv1",
            },
            "target_interface_parameters": {
                "Protocol": "REST",
                "Partner URL": "https://partner.example",
            },
        },
    )

    src = cloned["objects"]["source_transport_profile"]
    tgt = cloned["objects"]["target_transport_profile"]
    flow_src = cloned["objects"]["biz_flow"]["configure_source"]
    flow_tgt = cloned["objects"]["biz_flow"]["configure_targets"]

    assert cloned["customer"] == "ACME"
    business_copy = dict(cloned)
    business_copy.pop("_creation_source", None)
    assert "U-HAUL" not in json.dumps(business_copy)
    assert src["interface_type"] == "HTTPS"
    assert tgt["interface_type"] == "HTTPS"
    assert src["existing_account_name"] == ""
    assert tgt["existing_account_name"] == ""
    assert src["subscription_folder"] == ""
    assert tgt["subscription_folder"] == ""
    assert flow_src["source_transport_profile"] == "da-sender-https-dce-common"
    assert flow_tgt["target_transport_profile"] == "pt-receiver-https-dce-common"
    assert tgt["partner_name"] == "ACME-PARTNER"

    return {
        "customerRenamed": True,
        "uhaulSpecificStringsRemoved": True,
        "haftValuesDoNotLeakIntoHttpsClone": True,
    }


def _check_lock_self_heal_and_kill() -> dict:
    path = runtime_lock_path(ROOT)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.unlink(missing_ok=True)

    # Dead PID => stale and auto-clearable.
    path.write_text(
        json.dumps({
            "pid": 99999999,
            "host": "test",
            "createdEpoch": time.time() - 60,
            "createdAt": "test",
        }),
        encoding="utf-8",
    )
    state = inspect_live_run(ROOT)
    assert state["stale"] is True
    cleared = clear_stale_live_run(ROOT)
    assert cleared["cleared"] is True
    assert not path.exists()

    # Genuine run_agent.py process => kill button can terminate it safely.
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "run_agent.py"
        script.write_text("import time\ntime.sleep(120)\n", encoding="utf-8")
        proc = subprocess.Popen([sys.executable, str(script)])
        try:
            child = psutil.Process(proc.pid)
            path.write_text(
                json.dumps({
                    "ownerId": "test-owner",
                    "pid": proc.pid,
                    "host": "test",
                    "processCreateTime": child.create_time(),
                    "createdEpoch": time.time(),
                    "createdAt": "test",
                }),
                encoding="utf-8",
            )
            active = inspect_live_run(ROOT)
            assert active["active"] is True, active
            stopped = terminate_live_run(ROOT, timeout_seconds=2)
            assert stopped["stopped"] is True, stopped
            proc.wait(timeout=8)
            assert not path.exists()
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait(timeout=5)
            path.unlink(missing_ok=True)

    return {
        "staleLockAutoClear": True,
        "verifiedRunAgentKill": True,
        "lockOutsideOneDriveProject": str(path).startswith(tempfile.gettempdir()),
    }


def test_interface_payloads() -> None:
    assert _check_interface_payloads()


def test_template_clone() -> None:
    assert _check_template_clone()


def test_lock_self_heal_and_kill() -> None:
    assert _check_lock_self_heal_and_kill()


def main() -> None:
    output = {
        "status": "PASS",
        "buildId": "2026-08-10-template-interface-selfheal-v4",
        "interfacePayloads": _check_interface_payloads(),
        "templateClone": _check_template_clone(),
        "liveRunGuard": _check_lock_self_heal_and_kill(),
    }
    path = ROOT / "examples" / "INTERFACE_TEMPLATE_LOCK_SELFHEAL_TEST.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
