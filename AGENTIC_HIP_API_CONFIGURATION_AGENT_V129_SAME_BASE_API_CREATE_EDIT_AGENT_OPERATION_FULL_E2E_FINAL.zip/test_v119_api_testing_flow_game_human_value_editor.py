from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_shared_value_only_editor_exists_and_locks_attribute_structure():
    editor = (ROOT / 'webapp/frontend/src/components/HumanPayloadValueEditor.tsx').read_text(encoding='utf-8')
    assert 'VALUE ONLY · HUMAN USER' in editor
    assert 'Attribute to change' in editor
    assert 'Locked attribute path' in editor
    assert 'New human-entered value' in editor
    assert 'Save selected value' in editor
    assert 'Restore selected' in editor
    assert 'Restore all for API' in editor
    assert 'writePath' in editor
    assert 'attribute path is selectable but never editable' in editor.lower()


def test_api_testing_area_uses_shared_structure_locked_field_and_whole_payload_editor():
    page = (ROOT / 'webapp/frontend/src/pages/ApiTestingPage.tsx').read_text(encoding='utf-8')
    assert 'HumanPayloadValueEditor' in page
    assert 'Only you can edit approved values before LIVE' in page
    assert 'onSave={saveValueEdit}' in page
    assert 'onRestoreAll={restoreAllValues}' in page
    editor = (ROOT / 'webapp/frontend/src/components/HumanPayloadValueEditor.tsx').read_text(encoding='utf-8')
    assert 'Whole payload' in editor
    assert 'payload-json-editor' in editor
    assert 'server rejects any key/nesting/array-structure change' in editor


def test_flow_game_selected_api_block_can_persist_human_value_only_edits():
    flow = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    inspector = (ROOT / 'webapp/frontend/src/components/NodeInspector.tsx').read_text(encoding='utf-8')
    assert 'saveFlowValueEdit' in flow
    assert 'restoreFlowValueEdits' in flow
    assert "api.savePayloadOverride(active.id,node.data.apiKey,edited,requestKind,'paths')" in flow
    assert 'onSaveValueEdit={saveFlowValueEdit}' in flow
    assert 'Human Payload Value Editor' in inspector
    assert 'HumanPayloadValueEditor' in inspector
    assert 'Immutable API policy' in inspector
    assert 'Generated/effective request' in inspector


def test_flow_game_keeps_generated_baseline_separate_from_effective_request():
    flow = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    assert 'r.generatedParams??r.params' in flow
    assert 'r.generatedPayload??r.payload' in flow
    assert 'generatedRequest:generated' in flow


def test_same_human_only_backend_gate_is_used_by_all_surfaces():
    api = (ROOT / 'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    backend = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    assert "'X-HIP-User-Action':'payload-value-edit-v1'" in api
    assert 'Payload value editing is HUMAN USER ONLY' in backend
    assert 'AI/agent identities are not authorized to edit payload values.' in backend


def test_legacy_surfaces_follow_same_value_only_policy():
    testing = (ROOT / 'api_testing_area_ui.py').read_text(encoding='utf-8')
    scratch = (ROOT / 'scratch_flow_ui.py').read_text(encoding='utf-8')
    assert 'Human value editor' in testing
    assert 'Save selected value' in testing
    assert 'Full JSON' not in testing
    assert 'edit_origin="USER"' in testing
    assert 'Human-user value-only editor' in scratch
    assert 'STRUCTURE LOCKED' in scratch
    assert 'Advanced Full JSON Editor' not in scratch
