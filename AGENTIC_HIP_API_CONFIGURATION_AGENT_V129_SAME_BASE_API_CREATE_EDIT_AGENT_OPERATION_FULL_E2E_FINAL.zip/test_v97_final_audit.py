from pathlib import Path

import run_agent
from business_demo import prepare_uhal_business_demo

ROOT = Path(__file__).resolve().parent


def test_v97_parallel_final_gate_uses_strict_live_environment():
    text = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    marker = "V97 final audit: the safety gate must use the exact same strict"
    assert marker in text
    region = text[text.index(marker):text.index(marker)+1200]
    assert 'HIP_LIVE_API_EXECUTION="1"' in region
    assert 'HIP_STRICT_LIVE_PIPELINE="1"' in region
    assert 'HIP_LIVE_AUTO_COMPLETE="1"' in region
    assert 'HIP_FULL_API_COVERAGE_MODE="0"' in region


def test_v97_strict_preflight_requires_all_service_credentials_even_when_plan_skips(monkeypatch):
    prepare_uhal_business_demo(ROOT)
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_plan, "is_skipped", lambda _key: True)
    report = runner.production_preflight()
    profiles = report["credentialProfiles"]
    assert runner.strict_live_pipeline_mode is True
    assert profiles["hipConfig"]["required"] is True
    assert profiles["account"]["required"] is True
    assert profiles["partner"]["required"] is True
    assert profiles["system"]["required"] is True


def test_v97_strict_uhal_duns_gate_ignores_legacy_partner_skip(monkeypatch):
    prepare_uhal_business_demo(ROOT)
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_plan, "is_skipped", lambda _key: True)
    original = runner.preview_step_request
    def preview(step_key):
        if step_key == "partner_target":
            return {"payload": {"partnerIdentifier": "DUNS Number", "partnerIdentifierValue": "WRONG"}}
        return original(step_key)
    monkeypatch.setattr(runner, "preview_step_request", preview)
    report = runner.production_preflight()
    duns_errors = [row for row in report.get("errors", []) if row.get("check") == "uhaul-approved-duns"]
    assert duns_errors
    assert "12345666" in duns_errors[0]["message"]


def test_v97_release_docs_and_build_id_match_strict_runtime():
    start = (ROOT / "README_START_HERE.md").read_text(encoding="utf-8")
    env = (ROOT / ".env.example").read_text(encoding="utf-8")
    manifest = (ROOT / "LIVE_ONLY_RELEASE_MANIFEST.json").read_text(encoding="utf-8")
    assert "Current release:** V129" in start
    assert "README_FINAL_V96_STRICT_FULL_LIVE_PIPELINE.md" in start
    assert "README_FINAL_V129_SAME_BASE_API_CREATE_EDIT_AGENT_OPERATION.md" in start
    assert "README_FINAL_V128_IDENTITY_VERSION_MIGRATION_EXECUTION_HARDENING.md" in start
    assert "README_FINAL_V127_EXCEL_DOCUMENT_EVIDENCE_ACCURACY.md" in start
    assert "README_FINAL_V126_USER_CONTROLLED_MIGRATION_EXECUTION_FLOW.md" in start
    assert "ACCOUNT/PARTNER/SYSTEM OAuth profiles are REQUIRED" in env
    assert "Skip plans are ignored for strict 18/18 evidence coverage" in env
    build_id = run_agent.BUILD_ID.lower()
    for marker in ("v129", "strict-live", "no-reuse", "payload-value-editor", "structure-locked-agent-read-only", "same-base-api-create-edit"):
        assert marker in build_id
    assert run_agent.BUILD_ID in manifest
    assert '"release": "V129"' in manifest
