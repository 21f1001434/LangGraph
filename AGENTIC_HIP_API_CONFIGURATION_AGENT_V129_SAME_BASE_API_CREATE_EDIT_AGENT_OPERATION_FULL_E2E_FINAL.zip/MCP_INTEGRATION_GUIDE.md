# MCP Integration Guide — v11

Build: `2026-08-11-partner-payload-values-v12`

The HIP Application Studio now treats MCP as a first-class **agent control plane**, not only as a payload validator. MCP checkpoints are used before, during and after API execution wherever deterministic tool boundaries improve correctness.

## What MCP controls

The 18 tools cover:

- input/schema discovery and canonical mapping;
- interface registry and interface planning;
- API/PDF contract lookup;
- generated request validation;
- user payload-edit critique and secret policy;
- execution-plan/dependency/timing validation;
- end-to-end readiness supervision;
- semantic response interpretation;
- runtime ID resolution;
- user/Dev change proposals and approved application;
- Knowledge Graph and AgentQ memory access.

See `MCP_TOOL_CATALOG_V11.md` for every tool.

## Stable SDK mode

The package requires:

```text
mcp>=1.28,<2
```

The stdio server uses:

```python
from mcp.server.fastmcp import FastMCP
```

and runs from `uhal_mcp_server.py`.

## Install

```powershell
python -m pip install -r requirements.txt
```

## Runtime modes

### Recommended / demo-safe

```env
MCP_ENABLED=true
MCP_REQUIRED=false
MCP_VALIDATE_EACH_REQUEST=true
```

When the SDK transport is available, the bridge uses the MCP protocol. If it is unavailable, the identical registered tool functions run locally and reports record `local-function-fallback`.

### Strict MCP protocol

```env
MCP_ENABLED=true
MCP_REQUIRED=true
MCP_VALIDATE_EACH_REQUEST=true
```

In strict mode the runner refuses live execution when MCP transport/tool invocation is unavailable.

## MCP server

External stdio configuration is included in `mcp_server_config.example.json`.

Start directly:

```powershell
python uhal_mcp_server.py
```

## CLI diagnostics

```powershell
python run_agent.py --mcp-status
python run_agent.py --mcp-self-test
python run_agent.py --mcp-contract flow_create
```

These commands do not require a live HIP API run.

## Execution checkpoints

### Before execution

`assess_execution_readiness` and `validate_execution_policy` check the active input, interface registry, execute/skip decisions, dependency order, timing, payload edits and live-run health.

### Before every generated/edited request

`validate_api_request` checks the API contract. If a user edited the request, `validate_payload_override` also runs. Unsafe raw secret literals are blocked from persisted overrides; secure `{{runtime_payload...}}` placeholders are allowed and resolved only for the live API payload.

### After every response

`interpret_api_response` applies business semantics. A 200/201 response that contains `success=false`, `error=true`, `failedStep` or an error message is not promoted to success. Deployment history and audit responses receive endpoint-specific checks.

`resolve_response_ids` then extracts runtime IDs used by downstream Rule/Flow calls.

## Evidence and secrets

MCP evidence is included in validation/report objects. Authorization headers, OAuth tokens and real client secrets are never intentionally passed through the MCP tools. Payload/report serialization is redacted and Transport Profile client secrets remain environment references until immediately before a live HTTP call.
