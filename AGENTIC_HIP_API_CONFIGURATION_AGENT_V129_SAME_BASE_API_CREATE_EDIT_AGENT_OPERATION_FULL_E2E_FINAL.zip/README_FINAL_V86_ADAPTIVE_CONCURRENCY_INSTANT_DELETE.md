# V86 — Adaptive Concurrency + Instant Delete

V86 extends the complete HIP API Agent Studio without changing the locked 18 developer-approved HIP request schemas.

## 1. Delete reflects immediately

Configuration Library, Execution Queue, and saved Pipeline deletes use optimistic UI updates. After the user confirms Delete, the item is removed from the screen immediately. The backend delete runs next. If the backend rejects/fails the deletion, the UI restores the item and clearly reports that the delete was rolled back.

The immutable developer-approved U-HAUL reference still cannot be deleted.

## 2. Adaptive same-customer concurrency

Repeated same-customer runs with 3–8 instances can use Adaptive Concurrency (recommended). The backend owns this behavior; it is not only a frontend setting.

- Starts at concurrency 2 even when 3–8 workers were requested.
- Runs a wave and evaluates PASS/WARNING versus BLOCKED/FAIL/CANCELLED.
- If healthy, cautiously increases concurrency by one for the next wave.
- If a higher wave blocks/fails, immediately reduces to the last proven stable concurrency for remaining instances.
- Records peak stable workers, recommended next concurrency, reduction reason, adaptive wave history, and blocker diagnostic.
- The UI automatically sets the next worker count to the learned recommendation when the batch finishes.
- The final HTML report contains the same adaptive recommendation and reduction reason.

This directly handles the observed pattern where 2-way U-HAUL execution was more successful than 3- or 8-way execution.

## 3. Parallel modes remain separated

### Safe Capacity Test
Default/recommended for same-customer limit testing. Non-mutating: locked 18-contract validation plus production/OAuth/connectivity preflight, with zero LIVE configuration mutations.

### Advanced LIVE Stress
Explicit advanced mode. Uses isolated mutable resource-name values per worker, revalidates the locked payload structure, and never changes the approved API schema/keys/nesting.

### Pipeline Execution
Business execution path. All stages are validated and production-preflighted before the first LIVE mutation, then execute in the saved order. Stops on the first runtime failure.

## 4. Blocker diagnostics

Every blocked/failed instance can expose the first failing API/gate, HTTP status, HIP response/evidence, request ID when available, reason, and recommended next action. Adaptive concurrency reductions reuse this evidence so the user can see why the limit was reduced.

## Validation

- Application/root tests: 288/288 PASS
- FastAPI/backend tests: 48/48 PASS
- Total automated tests: 336/336 PASS
- V77–V86 focused regression: 50/50 PASS
- Required self-checks: 43/43 PASS
- Package validation: 57/57 PASS
- Adaptive package validation: 60/60 PASS
- Frontend TypeScript/TSX syntax transpilation: 24/24 PASS
- Python compilation: PASS

A fresh Vite production bundle was not generated in the sandbox because project `node_modules` are intentionally not packaged. Source-level TS/TSX transpilation passed for every frontend source file.
