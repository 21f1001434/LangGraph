from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional



@dataclass
class MappingIssue:
    severity: str
    field: str
    message: str
    suggestion: str = ""


class UhalInputMapper:
    """Normalize the active HIP canonical input and expose API field lineage.

    The historical class name is retained for compatibility with existing imports,
    but validation is customer/interface agnostic.
    """

    def __init__(self, input_data: Dict[str, Any], config: Dict[str, Any], root: Path):
        self.input = input_data or {}
        self.root = Path(root)
        self.config = config or {}
        self.objects = self.input.get("objects") or {}

    @staticmethod
    def _get(data: Dict[str, Any], *path: str, default: Any = None) -> Any:
        current: Any = data
        for key in path:
            if not isinstance(current, dict):
                return default
            current = current.get(key)
        return default if current in (None, "") else current

    @staticmethod
    def version_string(value: Any) -> str:
        # Evidence-accurate version conversion: blank/missing stays blank.
        # Numeric evidence is normalized only after it actually exists.
        if value in (None, ""):
            return ""
        raw = str(value).strip()
        if not raw or raw.lower() in {"none", "null", "n/a", "na", "unknown"}:
            return ""
        try:
            return f"{float(raw):.1f}"
        except Exception:
            return raw

    @property
    def source_doc(self) -> Dict[str, Any]:
        return self.objects.get("source_document_type") or {}

    @property
    def target_doc(self) -> Dict[str, Any]:
        return self.objects.get("target_document_type") or {}

    @property
    def data_map(self) -> Dict[str, Any]:
        return self.objects.get("data_map") or {}

    @property
    def rule(self) -> Dict[str, Any]:
        return self.objects.get("rule") or {}

    @property
    def source_tp(self) -> Dict[str, Any]:
        return self.objects.get("source_transport_profile") or {}

    @property
    def target_tp(self) -> Dict[str, Any]:
        return self.objects.get("target_transport_profile") or {}

    @property
    def biz_flow(self) -> Dict[str, Any]:
        return self.objects.get("biz_flow") or {}

    def is_translation(self) -> bool:
        raw = str(self.input.get("flow_type") or "").strip().lower()
        if raw:
            return raw == "translation"
        return bool(self.input.get("requires_data_map"))

    def has_separate_passthrough_target(self) -> bool:
        return (not self.is_translation()) and bool(
            self.input.get("passthrough_target_document_type_required")
            or self.input.get("passthrough_separate_target_document_type")
        )

    def effective_target_doc(self) -> Dict[str, Any]:
        if self.is_translation() or self.has_separate_passthrough_target():
            if str(self.target_doc.get("name") or "").strip():
                return self.target_doc
        return self.source_doc

    def normalized(self) -> Dict[str, Any]:
        flow_details = self.biz_flow.get("flow_details") or {}
        source_cfg = self.biz_flow.get("configure_source") or {}
        target_cfg = self.biz_flow.get("configure_targets") or {}
        target_doc = self.effective_target_doc()

        source_type = str(self.source_tp.get("system_type") or source_cfg.get("source_type") or "").strip()
        target_type = str(self.target_tp.get("system_type") or target_cfg.get("target_type") or "").strip()
        source_app = self.source_tp.get("partner_name") or self.source_tp.get("system_name") or source_cfg.get("source_application")
        target_app = self.target_tp.get("partner_name") or self.target_tp.get("system_name") or target_cfg.get("target_application")

        def is_dell(value: str) -> bool:
            norm = str(value or "").strip().lower()
            return norm in {"dell application", "dell"}

        def is_partner(value: str) -> bool:
            return str(value or "").strip().lower() == "partner"

        dell_system = source_app if is_dell(source_type) else (target_app if is_dell(target_type) else "")
        external_partner = source_app if is_partner(source_type) else (target_app if is_partner(target_type) else "")

        # Partner Create DUNS/value is independent from Rule/Flow routing IDs.
        # Do not promote input.partner_id (XML ROUTING destination/source identity)
        # into the Partner Create contract.
        partner_identifier_value = (
            self.input.get("partner_identifier_value")
            or self.config.get("partner_identifier_value")
            or self._get(self.config, "partnerCreate", "partnerIdentifierValue")
        )
        # Dev-approved shared UAT Partner identity: DUNS 12345666 belongs to
        # dce-test-partner. This fallback is keyed by the actual partner system,
        # not by customer/routing identity.
        if not str(partner_identifier_value or "").strip() and str(external_partner or "").strip().lower() == "dce-test-partner":
            partner_identifier_value = "12345666"
        return {
            "customer": self.input.get("customer") or "",
            "direction": self.input.get("direction") or "",
            "transactionStandard": self.input.get("tx_standard") or "",
            "transactionCode": self.input.get("tx_code") or "",
            "transactionName": self.input.get("tx_name") or "",
            "flowName": self.input.get("profile_name") or flow_details.get("business_flow_name"),
            "flowDescription": flow_details.get("flow_description") or self.input.get("profile_name") or "HIP generated business flow",
            # Canonical Flow version comes from the configuration object itself.
            # config_overrides.flowVersion is a historical package default and is
            # intentionally excluded from evidence-backed customer configuration.
            "flowVersion": self.version_string(flow_details.get("current_flow_version") or self.input.get("flow_version")),
            "environment": self.config.get("hipEnvironment") or "DEV",
            "requester": self.config.get("requestedBy") or "",
            "sourceDocumentType": self.source_doc.get("name"),
            "sourceDocumentVersion": self.version_string(self.source_doc.get("version")),
            "targetDocumentType": target_doc.get("name"),
            "targetDocumentVersion": self.version_string(target_doc.get("version")),
            "mapName": self.data_map.get("map_name"),
            "mapIdentifier": self.data_map.get("map_identifier"),
            "mapVersion": self.version_string(self.data_map.get("map_identifier_version")),
            "mappingRuleName": self.rule.get("name"),
            "mappingRuleVersion": self.version_string(self.rule.get("version")),
            "sourceType": source_type,
            "targetType": target_type,
            "sourceApplication": source_app,
            "targetApplication": target_app,
            # Compatibility aliases retained for older report/UI code.
            "sourceSystem": source_app,
            "targetPartner": target_app,
            # Entity-role values used by System/Partner APIs regardless of direction.
            "dellSystem": dell_system,
            "externalPartner": external_partner,
            # Keep mapper/preflight resolution identical to the live Runner.
            # Older approved configurations may store this under partnerCreate.
            "partnerIdentifierValue": partner_identifier_value,
            "sourceTpCreateName": self.source_tp.get("profile_name"),
            "targetTpCreateName": self.target_tp.get("profile_name"),
            "sourceTpFlowName": source_cfg.get("source_transport_profile") or self.config.get("source_transport_profile_name") or self.source_tp.get("profile_name"),
            "targetTpFlowName": target_cfg.get("target_transport_profile") or self.config.get("target_transport_profile_name") or self.target_tp.get("profile_name"),
            "sourceHaftAccount": self.config.get("source_haft_account") or self.source_tp.get("existing_account_name"),
            "targetHaftAccount": self.config.get("target_haft_account") or self.target_tp.get("existing_account_name"),
            "sourceDeploymentGroup": "hip-automation",
            "targetDeploymentGroup": "hip-automation",
        }

    def conditions(self) -> List[Dict[str, Any]]:
        flow_conditions = ((self.biz_flow.get("flow_identifiers") or {}).get("conditions") or [])
        if flow_conditions:
            return [
                {
                    "attributeName": row.get("attribute_name"),
                    "operator": row.get("operator"),
                    "value": row.get("value"),
                }
                for row in flow_conditions
                if isinstance(row, dict)
            ]
        rule_rows = ((self.rule.get("conditions") or {}).get("rows") or [])
        return [
            {
                "attributeName": row.get("attribute_name_unit") or row.get("attribute_name"),
                "operator": row.get("operator"),
                "value": row.get("value"),
            }
            for row in rule_rows
            if isinstance(row, dict)
        ]

    def validate(self) -> List[MappingIssue]:
        n = self.normalized()
        issues: List[MappingIssue] = []
        translation = self.is_translation()

        required = {
            "flowName": n.get("flowName"),
            "flowVersion": n.get("flowVersion"),
            "sourceDocumentType": n.get("sourceDocumentType"),
            "sourceDocumentVersion": n.get("sourceDocumentVersion"),
            "sourceApplication": n.get("sourceApplication"),
            "targetApplication": n.get("targetApplication"),
            "dellSystem": n.get("dellSystem"),
            "externalPartner": n.get("externalPartner"),
            "partnerIdentifierValue": n.get("partnerIdentifierValue"),
            "sourceTpCreateName": n.get("sourceTpCreateName"),
            "targetTpCreateName": n.get("targetTpCreateName"),
            "sourceTpFlowName": n.get("sourceTpFlowName"),
            "targetTpFlowName": n.get("targetTpFlowName"),
            # Account Create/Partner headers are part of the standard 18-API
            # solution even when the transport itself is HTTPS/AS2.
            "sourceAccount": n.get("sourceHaftAccount"),
            "targetAccount": n.get("targetHaftAccount"),
        }
        if translation:
            required.update({
                "targetDocumentType": n.get("targetDocumentType"),
                "targetDocumentVersion": n.get("targetDocumentVersion"),
                "mapIdentifier": n.get("mapIdentifier"),
                "mapVersion": n.get("mapVersion"),
                "mappingRuleName": n.get("mappingRuleName"),
                "mappingRuleVersion": n.get("mappingRuleVersion"),
            })
        for field, value in required.items():
            if value in (None, "", [], {}):
                issues.append(MappingIssue("ERROR", field, f"Required HIP configuration value '{field}' is missing."))

        if str(self.source_doc.get("api_transaction_type") or "INBOUND").upper() != "INBOUND":
            issues.append(MappingIssue("ERROR", "source_document_type.api_transaction_type", "Source Document Type must use INBOUND.", "INBOUND"))
        if (translation or self.has_separate_passthrough_target()) and self.target_doc and str(self.target_doc.get("api_transaction_type") or "OUTBOUND").upper() != "OUTBOUND":
            issues.append(MappingIssue("ERROR", "target_document_type.api_transaction_type", "Target Document Type must use OUTBOUND when a separate target is configured.", "OUTBOUND"))

        if not self.conditions():
            issues.append(MappingIssue("ERROR", "flowIdentifiers", "At least one routing / flow-identifier condition is required."))

        if translation:
            input_dir = self.root / "input_files"
            jar_name = str(self.data_map.get("map_data_file") or "").strip()
            if not jar_name:
                issues.append(MappingIssue("ERROR", "data_map.map_data_file", "Translation flow requires an approved mapping JAR filename."))
            else:
                jar_path = input_dir / jar_name
                if not jar_path.exists() or jar_path.stat().st_size == 0:
                    issues.append(MappingIssue("ERROR", f"file:{jar_name}", f"Approved mapping JAR is missing or empty: {jar_path}"))

            # Map Create sends input/output schemas. Resolve them by canonical
            # Document Type rather than by customer-specific filenames.
            def matching_sample(doc: Dict[str, Any]) -> bool:
                if not input_dir.exists():
                    return False
                fmt = str(doc.get("data_format_type") or "").upper()
                allowed = {".xml"} if "XML" in fmt else ({".edi", ".x12", ".txt"} if any(x in fmt for x in ("X12", "EDI", "EDIFACT")) else {".xml", ".edi", ".x12", ".txt", ".csv"})
                roots = [str(row.get("value")) for row in ((doc.get("document_identifier") or {}).get("rows") or []) if isinstance(row, dict) and row.get("value")]
                for path in input_dir.iterdir():
                    if not path.is_file() or path.suffix.lower() not in allowed or path.stat().st_size == 0:
                        continue
                    if not roots:
                        return True
                    try:
                        text = path.read_text(encoding="utf-8", errors="replace")[:250000]
                    except Exception:
                        continue
                    if any(root in text for root in roots):
                        return True
                return False

            if not matching_sample(self.source_doc):
                issues.append(MappingIssue("ERROR", "file:source_sample", "Translation flow needs a non-empty source sample matching the source Document Type."))
            if not matching_sample(self.target_doc):
                issues.append(MappingIssue("ERROR", "file:target_sample", "Translation flow needs a non-empty target sample matching the target Document Type."))

        # Fixed Dev-team automation alias: never accept/re-introduce a custom
        # sender/receiver deployment value in generated orchestration payloads.
        if n.get("sourceDeploymentGroup") != "hip-automation" or n.get("targetDeploymentGroup") != "hip-automation":
            issues.append(MappingIssue("ERROR", "deploymentGroup", "All automated interfaces must use hip-automation.", "hip-automation"))

        return issues

    def validate_or_raise(self) -> None:
        errors = [issue for issue in self.validate() if issue.severity == "ERROR"]
        if errors:
            raise ValueError("HIP input mapping is invalid:\n" + "\n".join(f"- {x.field}: {x.message}" for x in errors))

    def lineage(self) -> Dict[str, List[Dict[str, Any]]]:
        n = self.normalized()
        return {
            "account_source": [
                {"payloadField": "accountName", "inputPath": "config.source_haft_account", "value": n["sourceHaftAccount"]},
                {"payloadField": "domains[0]", "inputPath": "confirmed Dev rule", "value": "dce.com"},
            ],
            "account_target": [
                {"payloadField": "accountName", "inputPath": "config.target_haft_account", "value": n["targetHaftAccount"]},
                {"payloadField": "domains[0]", "inputPath": "confirmed Dev rule", "value": "dce.com"},
            ],
            "partner": [
                {"payloadField": "name", "inputPath": "objects.target_transport_profile.partner_name", "value": n["targetPartner"]},
                {"payloadField": "header.x-account-name", "inputPath": "config.source_haft_account", "value": n["sourceHaftAccount"]},
                {"payloadField": "primaryDomain", "inputPath": "confirmed Dev rule", "value": "Supply Chain"},
            ],
            "system": [
                {"payloadField": "systemName", "inputPath": "objects.source_transport_profile.partner_name", "value": n["sourceSystem"]},
                {"payloadField": "path.domainId", "inputPath": "config.system_domain_id", "value": self.config.get("system_domain_id") or self.config.get("domainId")},
            ],
            "document_type_source": [
                {"payloadField": "name", "inputPath": "objects.source_document_type.name", "value": n["sourceDocumentType"]},
                {"payloadField": "transactionType", "inputPath": "objects.source_document_type.api_transaction_type", "value": "INBOUND"},
                {"payloadField": "documentIdentifier", "inputPath": "objects.source_document_type.api_document_identifier", "value": self.source_doc.get("api_document_identifier")},
                {"payloadField": "attributes", "inputPath": "objects.source_document_type.attributes_to_configure", "value": self.source_doc.get("attributes_to_configure")},
            ],
            "document_type_target": [
                {"payloadField": "name", "inputPath": "objects.target_document_type.name", "value": n["targetDocumentType"]},
                {"payloadField": "transactionType", "inputPath": "objects.target_document_type.api_transaction_type", "value": "OUTBOUND"},
                {"payloadField": "documentIdentifier", "inputPath": "objects.target_document_type.api_document_identifier", "value": self.target_doc.get("api_document_identifier")},
                {"payloadField": "attributes", "inputPath": "objects.target_document_type.attributes_to_configure", "value": self.target_doc.get("attributes_to_configure")},
            ],
            "map": [
                {"payloadField": "mapName", "inputPath": "objects.data_map.map_name", "value": n["mapName"]},
                {"payloadField": "mapIdentifier", "inputPath": "objects.data_map.map_identifier", "value": n["mapIdentifier"]},
                {"payloadField": "mapData", "inputPath": "objects.data_map.map_data_file", "value": self.data_map.get("map_data_file")},
            ],
            "rule": [
                {"payloadField": "name", "inputPath": "objects.rule.name", "value": n["mappingRuleName"]},
                {"payloadField": "ruleConditions", "inputPath": "objects.rule.conditions.rows", "value": self.conditions()},
            ],
            "source_tp": [
                {"payloadField": "systemName", "inputPath": "objects.source_transport_profile.partner_name", "value": n["sourceSystem"]},
                {"payloadField": "transportProfileName", "inputPath": "objects.source_transport_profile.profile_name", "value": n["sourceTpCreateName"]},
                {"payloadField": "deploymentGroupName", "inputPath": "config.source_deployment_group_name", "value": n["sourceDeploymentGroup"]},
                {"payloadField": "Existing Account Name", "inputPath": "config.source_haft_account", "value": n["sourceHaftAccount"]},
            ],
            "target_tp": [
                {"payloadField": "systemName", "inputPath": "objects.target_transport_profile.partner_name", "value": n["targetPartner"]},
                {"payloadField": "transportProfileName", "inputPath": "objects.target_transport_profile.profile_name", "value": n["targetTpCreateName"]},
                {"payloadField": "deploymentGroupName", "inputPath": "config.target_deployment_group_name", "value": n["targetDeploymentGroup"]},
                {"payloadField": "Existing Account Name", "inputPath": "config.target_haft_account", "value": n["targetHaftAccount"]},
            ],
            "flow_create": [
                {"payloadField": "flowName", "inputPath": "profile_name", "value": n["flowName"]},
                {"payloadField": "flowDefinition.sourceDetails", "inputPath": "objects.biz_flow.configure_source", "value": self.biz_flow.get("configure_source")},
                {"payloadField": "flowDefinition.flowIdentifiers", "inputPath": "objects.biz_flow.flow_identifiers", "value": self.conditions()},
                {"payloadField": "flowDefinition.targetDetails.targets[0].processSteps[0].configuration.defaultConfig.ruleRefs.ruleDetails.name", "inputPath": "objects.rule.name", "value": n["mappingRuleName"]},
                {"payloadField": "flowDefinition.targetDetails.targets[0].processSteps[0].configuration.defaultConfig.ruleRefs.ruleDetails.version", "inputPath": "objects.rule.version", "value": n["mappingRuleVersion"]},
                {"payloadField": "flowDefinition.targetDetails", "inputPath": "objects.biz_flow.configure_targets", "value": self.biz_flow.get("configure_targets")},
            ],
            "flow_deploy": [
                {"payloadField": "flowName", "inputPath": "profile_name", "value": n["flowName"]},
                {"payloadField": "flowVersion", "inputPath": "objects.biz_flow.flow_details.current_flow_version", "value": n["flowVersion"]},
            ],
        }

    def execution_manifest(self) -> Dict[str, Any]:
        n = self.normalized()
        return {
            "businessContext": n,
            "conditions": self.conditions(),
            "validationIssues": [asdict(x) for x in self.validate()],
            "lineage": self.lineage(),
            "sequence": [
                {"key": "tp_validate_source", "dependsOn": []},
                {"key": "tp_validate_target", "dependsOn": []},
                {"key": "flow_validate", "dependsOn": []},
                {"key": "account_source", "dependsOn": []},
                {"key": "account_target", "dependsOn": []},
                {"key": "partner", "dependsOn": ["account_source"]},
                {"key": "system", "dependsOn": []},
                {"key": "document_type_source", "dependsOn": []},
                {"key": "document_type_target", "dependsOn": []},
                {"key": "map", "dependsOn": ["document_type_source", "document_type_target"]},
                {"key": "rule", "dependsOn": ["document_type_source", "map"]},
                {"key": "source_tp", "dependsOn": ["system", "account_source", "document_type_source"]},
                {"key": "target_tp", "dependsOn": ["partner", "account_target", "document_type_target"]},
                {"key": "source_tp_audit", "dependsOn": ["source_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
                {"key": "target_tp_audit", "dependsOn": ["target_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
                {"key": "flow_create", "dependsOn": ["document_type_source", "document_type_target", "map", "rule", "source_tp_audit", "target_tp_audit"]},
                {"key": "flow_deploy", "dependsOn": ["flow_create"]},
                {"key": "flow_history", "dependsOn": ["flow_deploy"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
            ],
        }

    def write_manifest(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.execution_manifest(), indent=2, default=str), encoding="utf-8")
        return path
