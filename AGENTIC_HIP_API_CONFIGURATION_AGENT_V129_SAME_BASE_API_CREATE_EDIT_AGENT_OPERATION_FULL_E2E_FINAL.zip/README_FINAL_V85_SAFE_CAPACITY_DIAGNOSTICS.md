# V85 — Safe Capacity Testing + API Blocker Diagnostics

## Purpose
V85 separates **same-customer limit testing** from **real LIVE business execution** and makes every blocked parallel instance explain exactly why it did not pass.

## Same-customer parallel execution
### Safe Capacity Test — default
- Non-mutating.
- Runs the selected immutable validated snapshots concurrently (2–8 workers).
- Revalidates the locked 18 HIP API request contracts in each worker.
- Runs production readiness/preflight in each worker.
- Makes **zero LIVE HIP configuration mutations**.
- Intended to test Studio worker/concurrency/readiness behavior safely before a mutating run.
- Stop Batch and Stop Instance controls remain available.

### Advanced LIVE Stress
- Explicit opt-in and double confirmation in the UI.
- Intended only when actual mutating concurrency is required.
- Each worker gets a unique stress namespace for mutable configuration resource-name **values** (flow, map/rule names, document type names, transport profile names, routing action/rule names).
- API keys, nesting, request kinds and the developer-approved 18 schemas are not changed.
- Shared foundation identities such as customer, DUNS, partner/account/system identities are preserved.
- The generated stress-isolated `input.json` is revalidated against all 18 locked contracts before any LIVE API mutation.
- If stress isolation does not validate, that worker is blocked before LIVE.

## Blocker diagnostics
Every FAIL/BLOCKED parallel result can expose:
- first failing API or pre-LIVE gate
- API group/stage
- HTTP status when available
- runner/business classification
- reason
- HIP response / technical evidence (redacted)
- request/correlation ID when available
- recommended next action

The Execution Center shows **View cause** on affected workers/results, and the downloaded HTML parallel report includes the same diagnostic evidence.

## Pipeline Execution
Pipeline Execution remains the business workflow:
1. Build/save an ordered pipeline.
2. Validate every stage.
3. Backend preflights all stages before the first LIVE mutation.
4. Execute sequentially in saved order.
5. Stop on the first non-passing stage; later stages become SKIPPED.

## Existing safeguards preserved
- U-HAUL is DEV APPROVED / TEST READY / 18/18 and immutable.
- U-HAUL can be cloned but not edited in place.
- Build Configuration supports Create New, Clone Existing and Edit Existing with confirmation.
- File-vs-user conflicts remain a server-side hard gate.
- Global customer dropdown remains active across Studio pages.
- Windows runtime/path/report persistence hardening remains in place.
- Developer-approved API payload schemas remain locked; only allowed values can change.

## Validation
- Application tests: 284/284 PASS
- FastAPI/backend tests: 48/48 PASS
- Total automated tests: 332/332 PASS
- Phase 6 checks: 38/38 PASS
- Final release checks: 16/16 PASS
- Package validation: 57/57 PASS
- Required self-checks: 43/43 PASS
- Adaptive package checks: 60/60 PASS
- Frontend TypeScript/TSX transpilation: 24/24 PASS

A fresh Vite production bundle was not regenerated in the sandbox because frontend package dependencies are not installed in the release workspace. Source-level TS/TSX transpilation passed for every frontend source file.
