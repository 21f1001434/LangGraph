# V81 — Windows Runtime + Global Customer Selector

## What was fixed

### 1. U-HAUL no longer fails because the source folder is on OneDrive/Desktop

The V80 runtime was stored under `webapp/runtime` beside the source code. On managed Windows machines, OneDrive/Controlled Folder Access can allow reading the package while rejecting writes such as:

`PermissionError: [WinError 5] Access is denied ... webapp\\runtime\\configurations\\...\\input_files`

V81 treats the extracted ZIP/source tree as read-only. Mutable application state is now resolved in this order:

1. `HIP_STUDIO_RUNTIME_ROOT` when explicitly configured.
2. Windows: `%LOCALAPPDATA%\\HIP API Agent Studio\\runtime`.
3. User-local runtime on non-Windows platforms.
4. OS temp directory fallback if the preferred location cannot pass an actual write/delete probe.

The application performs a best-effort migration from an older `webapp/runtime` but never depends on that folder being writable.

### 2. Developer-approved U-HAUL remains DEV APPROVED / TEST READY

The packaged U-HAUL Outbound 856 Translation reference is read from the package and synchronized into the writable local runtime for normal Studio endpoints. It remains immutable and reports 18/18 developer-approved API contracts. Runtime credentials/connectivity remain a separate preflight concern.

An installation/runtime load error is no longer sent to the business-value **Fix now** modal. That modal remains only for editable customer configurations that actually need a business/configuration decision.

### 3. Global Active Customer dropdown

The top-right Active Customer element is now a real global `<select>` control.

- U-HAUL is automatically selected on a fresh start when no previous customer choice exists.
- The user's last active configuration is remembered in browser local storage.
- Switching the dropdown updates the active configuration used by Home/Library/Build/API Testing/Flow Game/Execute/Reports/System without returning to the Configuration Library.
- Each option includes customer, direction/transaction/flow and status such as `DEV APPROVED`, `VALIDATED`, or `NEEDS ATTENTION`.
- The adjacent arrow opens the selected configuration in the Configuration Library.

## Payload contract safety

V81 does not change the existing canonical API payload locking. The 18 developer-approved request structures remain fixed; customer-specific configuration changes values only. U-HAUL remains immutable.

## Validation

- Application/root automated tests: **264/264 PASS**
- FastAPI webapp tests: **48/48 PASS**
- Total automated tests: **312/312 PASS**
- Focused V77–V81/U-HAUL/runtime tests: **26/26 PASS**
- Windows runtime materialization smoke test: **PASS**
  - U-HAUL status `DEV_APPROVED`
  - `18/18`
  - local runtime `input_files` created
  - `/api/parallel/sources` U-HAUL `validated=true`
  - no reference load error
- Phase 6 package checks: **38/38 PASS**
- Required final self-checks: **43/43 PASS**
- Adaptive package checks: **60/60 PASS**
- Python compilation: **PASS**
- Frontend TS/TSX transpilation: **24/24 PASS**

The current build environment does not have Bun, so the Phase 6 checker reports Bun availability only as an advisory. The frontend source transpilation passed and the project still contains the standard setup/build instructions for a machine with dependencies available.
