from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse

from production_guard import redact_sensitive
from run_agent import AIAJudge


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
TEXT_EXTENSIONS = {".txt", ".log", ".md", ".xml", ".csv", ".yaml", ".yml"}


def _safe_name(name: str) -> str:
    base = Path(name or "upload").name
    return re.sub(r"[^A-Za-z0-9._-]+", "_", base)[:180] or "upload"


def _tokens(text: str) -> set[str]:
    return {x for x in re.findall(r"[A-Za-z0-9_.:/-]{3,}", (text or "").lower()) if x not in {"the", "and", "for", "with", "this", "that"}}


def _header_map(headers: Any) -> Dict[str, str]:
    return {
        str(h.get("name") or ""): str(h.get("value") or "")
        for h in (headers or []) if isinstance(h, dict)
    }


def _redact_name_value_pairs(items: Any) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for raw in items or []:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        name = str(item.get("name") or "")
        normalized = re.sub(r"[^a-z0-9]+", "", name.lower())
        if any(token in normalized for token in ("authorization", "cookie", "token", "secret", "password", "apikey")):
            item["value"] = "<REDACTED>"
        else:
            item = redact_sensitive(item)
        out.append(item)
    return out


def _redact_har_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    # Start with generic key/string redaction, then handle HAR's name/value arrays
    # where the sensitive semantic is carried by the `name` field rather than the key.
    safe = redact_sensitive(payload)
    entries = (((safe or {}).get("log") or {}).get("entries") or []) if isinstance(safe, dict) else []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        request = entry.get("request") or {}
        response = entry.get("response") or {}
        if isinstance(request, dict):
            request["headers"] = _redact_name_value_pairs(request.get("headers"))
            request["queryString"] = _redact_name_value_pairs(request.get("queryString"))
            request["cookies"] = _redact_name_value_pairs(request.get("cookies"))
        if isinstance(response, dict):
            response["headers"] = _redact_name_value_pairs(response.get("headers"))
            response["cookies"] = _redact_name_value_pairs(response.get("cookies"))
    return safe

def _har_text(payload: Dict[str, Any]) -> str:
    entries = (((payload or {}).get("log") or {}).get("entries") or [])
    rows: List[str] = []
    for index, entry in enumerate(entries[:1000], start=1):
        req = entry.get("request") or {}
        resp = entry.get("response") or {}
        post = (req.get("postData") or {}).get("text") or ""
        content = (resp.get("content") or {}).get("text") or ""
        query = {
            str(item.get("name") or ""): str(item.get("value") or "")
            for item in (req.get("queryString") or []) if isinstance(item, dict)
        }
        row = {
            "entry": index,
            "startedDateTime": entry.get("startedDateTime"),
            "method": req.get("method"),
            "url": req.get("url"),
            "query": query,
            "status": resp.get("status"),
            "statusText": resp.get("statusText"),
            "requestHeaders": _header_map(req.get("headers")),
            "responseHeaders": _header_map(resp.get("headers")),
            "requestBody": post[:10000],
            "responseBody": content[:10000],
            "timeMs": entry.get("time"),
        }
        rows.append(json.dumps(redact_sensitive(row), ensure_ascii=False, default=str))
    return "\n".join(rows)


class LearnAssistant:
    """Persistent local API/payload learning workspace backed by Dell AIA."""

    def __init__(self, root: Path, pdf_kb: Any = None):
        self.root = Path(root)
        self.pdf_kb = pdf_kb
        self.base = self.root / "knowledge" / "learn"
        self.uploads = self.base / "uploads"
        self.records = self.base / "records"
        for directory in (self.uploads, self.records):
            directory.mkdir(parents=True, exist_ok=True)
        config_path = self.root / "config_overrides.json"
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except Exception:
            config = {}
        self.aia = AIAJudge(config, enabled=True)

    def _record_path(self, digest: str) -> Path:
        return self.records / f"{digest}.json"

    def list_records(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for path in sorted(self.records.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                out.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                continue
        return out

    def ingest(self, filename: str, data: bytes, mime_type: str = "", question: str = "") -> Dict[str, Any]:
        name = _safe_name(filename)
        ext = Path(name).suffix.lower()
        digest = hashlib.sha256(data).hexdigest()[:20]
        stored = self.uploads / f"{digest}_{name}"
        record: Dict[str, Any] = {
            "id": digest,
            "filename": name,
            "mimeType": mime_type or "",
            "storedPath": str(stored),
            "storedRedacted": False,
            "learnedAt": dt.datetime.now().isoformat(),
            "kind": "binary",
            "text": "",
            "vision": {},
            "warnings": [],
        }

        # Persist text/network evidence in redacted form. This prevents a HAR,
        # JSON payload, or log containing bearer tokens/cookies/client secrets
        # from surviving on disk even though the semantic index is redacted.
        if ext in {".har", ".json"}:
            record["kind"] = "network_log" if ext == ".har" else "json"
            try:
                obj = json.loads(data.decode("utf-8", errors="replace"))
                is_har = isinstance(obj, dict) and isinstance(obj.get("log"), dict) and "entries" in (obj.get("log") or {})
                safe_obj = _redact_har_payload(obj) if is_har else redact_sensitive(obj)
                stored.write_text(
                    json.dumps(safe_obj, indent=2, ensure_ascii=False, default=str),
                    encoding="utf-8",
                )
                record["storedRedacted"] = True
                text = _har_text(safe_obj) if is_har else json.dumps(safe_obj, indent=2, ensure_ascii=False, default=str)
                record["kind"] = "network_log" if is_har else "json"
                record["text"] = text[:250000]
                record["summary"] = (
                    "Network/API log learned; authorization, tokens, cookies and secret fields were redacted before local persistence."
                    if record["kind"] == "network_log"
                    else "JSON payload/evidence learned and secret fields were redacted before local persistence."
                )
            except Exception as exc:
                safe_text = str(redact_sensitive(data.decode("utf-8", errors="replace")))
                stored.write_text(safe_text, encoding="utf-8")
                record["storedRedacted"] = True
                record["warnings"].append(f"JSON parse warning: {exc}")
                record["text"] = safe_text[:250000]
                record["summary"] = "Text content learned and persisted in redacted form; JSON parsing was not possible."
        elif ext in TEXT_EXTENSIONS or (mime_type or "").startswith("text/"):
            record["kind"] = "text"
            safe_text = str(redact_sensitive(data.decode("utf-8", errors="replace")))
            stored.write_text(safe_text, encoding="utf-8")
            record["storedRedacted"] = True
            record["text"] = safe_text[:250000]
            record["summary"] = "Text/API evidence learned and persisted with sensitive values redacted."
        else:
            # Binary image/PDF evidence cannot be structurally redacted without
            # altering the source. Keep it local as supplied and clearly mark
            # that distinction in the record.
            stored.write_bytes(data)
            if ext == ".pdf" and self.pdf_kb is not None:
                result = self.pdf_kb.ingest_bytes(name, data)
                text_path = Path(result.text_path)
                text = text_path.read_text(encoding="utf-8", errors="ignore") if text_path.exists() else ""
                record.update({
                    "kind": "api_pdf",
                    "text": redact_sensitive(text)[:200000],
                    "summary": f"API PDF learned: {result.pages} pages; detected APIs: {', '.join(result.detected_apis) or 'none auto-detected'}",
                    "warnings": list(result.warnings or []),
                })
            elif ext in IMAGE_EXTENSIONS or (mime_type or "").startswith("image/"):
                record["kind"] = "image"
                try:
                    vision = self.aia.analyze_frontend_image(
                        data, filename=name, mime_type=mime_type or "image/png", question=question
                    )
                    record["vision"] = vision
                    record["summary"] = vision.get("analysis", "")[:4000]
                except Exception as exc:
                    record["warnings"].append(f"Dell AIA vision analysis unavailable: {exc}")
                    record["summary"] = "Image saved. Vision analysis can be retried after Dell AIA credentials/model access are available."
            else:
                record["warnings"].append("Unsupported binary format for semantic learning. File was saved as local evidence.")
                record["summary"] = "File saved as evidence."

        self._record_path(digest).write_text(
            json.dumps(redact_sensitive(record), indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )
        return record

    def _runtime_context(self) -> List[Dict[str, Any]]:
        context: List[Dict[str, Any]] = []
        for path in (
            self.root / "input.json",
            self.root / "config_overrides.json",
            self.root / "reports" / "uhal_end_to_end_status_latest.json",
            self.root / "reports" / "api_testing_area_latest.json",
        ):
            if not path.exists():
                continue
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            context.append({"source": path.name, "content": redact_sensitive(value)})
        return context

    def relevant_evidence(self, question: str, max_chars: int = 26000) -> List[Dict[str, Any]]:
        q = _tokens(question)
        ranked: List[tuple[int, Dict[str, Any]]] = []
        for record in self.list_records():
            corpus = " ".join([
                str(record.get("filename") or ""), str(record.get("summary") or ""),
                str(record.get("text") or "")[:50000], json.dumps(record.get("vision") or {}, default=str)[:12000],
            ])
            score = len(q & _tokens(corpus))
            ranked.append((score, record))
        ranked.sort(key=lambda x: (x[0], x[1].get("learnedAt", "")), reverse=True)
        evidence: List[Dict[str, Any]] = []
        size = 0
        for score, record in ranked[:12]:
            compact = {
                "filename": record.get("filename"), "kind": record.get("kind"),
                "summary": record.get("summary"), "vision": record.get("vision"),
                "text": str(record.get("text") or "")[:9000], "relevanceScore": score,
            }
            blob = json.dumps(compact, default=str)
            if size + len(blob) > max_chars:
                continue
            size += len(blob)
            evidence.append(compact)
        return evidence

    def ask(self, question: str) -> Dict[str, Any]:
        evidence = self.relevant_evidence(question)
        runtime = self._runtime_context()
        system = (
            "You are Learn, the HIP API and payload learning assistant. Use only the supplied evidence. "
            "Correlate frontend screenshots, network logs, payloads, responses, API documentation and current configuration. "
            "Clearly separate observed facts from inferences. Never invent IDs, endpoints, credentials, payload fields or Dev approvals. "
            "When discussing a failed response, say whether it is PASS/EXISTING, PASS/WORKED, or BLOCKED and why. "
            "Return JSON with keys answer, evidenceUsed, frontendBackendRelationship, payloadFindings, verdict, confidence, nextChecks."
        )
        user = json.dumps({
            "question": question,
            "learnedEvidence": evidence,
            "currentRuntimeEvidence": runtime,
        }, indent=2, ensure_ascii=False, default=str)[:50000]
        result = self.aia.complete_json(system, user, temperature=0)
        if not isinstance(result.get("evidenceUsed"), list):
            result["evidenceUsed"] = []
        if not isinstance(result.get("nextChecks"), list):
            result["nextChecks"] = []
        return result
