from __future__ import annotations

import datetime as dt
import html
import json
import re
import time
import uuid
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from business_demo import agent_response_verdict
from api_contract_policy import assert_no_request_override
from execution_flow import DEFAULT_ORDER, STEP_DEFINITIONS
from migration_api_contract import MIGRATION_STEP_DEFINITIONS

ALL_STEP_DEFINITIONS = {**STEP_DEFINITIONS, **MIGRATION_STEP_DEFINITIONS}
from payload_overrides import canonical_step_key
from production_guard import redact_sensitive
from report_insights import verdict_allows_progress

SCRATCH_FLOW_FILENAME = "scratch_flow.json"
SCRATCH_REPORT_JSON = "scratch_flow_report_latest.json"
SCRATCH_REPORT_HTML = "scratch_flow_report_latest.html"

# Friendly aliases accepted in input.json / user-authored flow files.
STEP_ALIASES = {
    "document_type": "doctype_source",
    "documenttype": "doctype_source",
    "doctype": "doctype_source",
    "source_document_type": "doctype_source",
    "target_document_type": "doctype_target",
    "data_map": "map",
    "mac_map": "map",
    "mapping_rule": "rule",
    "source_transport_profile": "source_tp",
    "target_transport_profile": "target_tp",
    "transport_profile_source": "source_tp",
    "transport_profile_target": "target_tp",
    "flow": "flow_create",
    "flow_create": "flow_create",
    "flow_deploy": "flow_deploy",
}

TOKEN_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}|\$\{\s*([A-Za-z0-9_.-]+)\s*\}")


def _now() -> str:
    return dt.datetime.now().isoformat()


def _instance_id(step_key: str) -> str:
    prefix = re.sub(r"[^a-z0-9]+", "_", str(step_key).lower()).strip("_") or "step"
    return f"{prefix}_{uuid.uuid4().hex[:8]}"




# Machine-readable markers embedded in the drag/drop labels. The visible label
# stays friendly, while these suffixes let Python safely distinguish a palette
# template from a concrete component instance after a drag operation.
DRAG_TEMPLATE_RE = re.compile(r"\[HIP_TEMPLATE:([A-Za-z0-9_.-]+)\]\s*$")
DRAG_INSTANCE_RE = re.compile(r"\[HIP_INSTANCE:([A-Za-z0-9_.-]+)\]\s*$")


def _group_icon(group: str) -> str:
    return {
        "Validation": "🔎",
        "Foundation": "🏗️",
        "Configuration": "🧱",
        "Orchestration": "🔗",
        "Verification": "✅",
        "Migration": "🚚",
    }.get(str(group or ""), "🧩")


def drag_palette_item(step_key: str) -> str:
    """Return one reusable human-readable palette item for the drag/drop UI."""
    key = normalize_step_key(step_key)
    meta = ALL_STEP_DEFINITIONS.get(key) or {}
    group = str(meta.get("group") or "Other")
    label = str(meta.get("label") or key)
    return f"{_group_icon(group)} {label}  ·  {group}  [HIP_TEMPLATE:{key}]"


def drag_canvas_item(component: Dict[str, Any], order: int = 0) -> str:
    """Return one drag/drop item for an existing concrete Scratch component."""
    key = normalize_step_key(component.get("stepKey"))
    meta = ALL_STEP_DEFINITIONS.get(key) or {}
    group = str(meta.get("group") or "Other")
    label = str(component.get("label") or meta.get("label") or key)
    instance_id = str(component.get("instanceId") or "").strip()
    state = "●" if component.get("enabled", True) else "○"
    prefix = f"{order}. " if order else ""
    return f"{prefix}{state} {_group_icon(group)} {label}  ·  {key}  [HIP_INSTANCE:{instance_id}]"


def parse_drag_item(value: Any) -> Tuple[str, str]:
    """Return (kind, key) for a drag/drop label; kind is template/instance/unknown."""
    text = str(value or "")
    match = DRAG_TEMPLATE_RE.search(text)
    if match:
        return "template", normalize_step_key(match.group(1))
    match = DRAG_INSTANCE_RE.search(text)
    if match:
        return "instance", match.group(1)
    return "unknown", ""


def reconcile_drag_canvas(flow: Dict[str, Any], canvas_items: Iterable[Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Apply a visual drag/drop canvas back to the persisted Scratch flow.

    Existing instance markers are reordered in the exact canvas order. A palette
    template marker creates a *new* independent component every time it is dropped.
    Existing instances that no longer appear on the canvas are treated as removed
    (for example, when the user drags a block back to the palette).
    """
    normalized = normalize_flow(flow)
    existing = {str(row.get("instanceId")): row for row in normalized.get("components") or []}
    original_ids = [str(row.get("instanceId")) for row in normalized.get("components") or []]
    next_components: List[Dict[str, Any]] = []
    seen_instances: set[str] = set()
    added: List[str] = []
    ignored: List[str] = []

    for raw in canvas_items or []:
        kind, value = parse_drag_item(raw)
        if kind == "instance":
            if value in existing and value not in seen_instances:
                next_components.append(deepcopy(existing[value]))
                seen_instances.add(value)
            elif value:
                ignored.append(value)
            continue
        if kind == "template":
            if value in ALL_STEP_DEFINITIONS:
                row = new_component(value, source="drag-drop")
                next_components.append(row)
                added.append(str(row.get("instanceId")))
            else:
                ignored.append(value)
            continue
        if str(raw or "").strip():
            ignored.append(str(raw))

    removed = [instance_id for instance_id in original_ids if instance_id not in seen_instances]
    normalized["components"] = next_components
    normalized["source"] = "drag-drop"
    new_ids = [str(row.get("instanceId")) for row in next_components]
    changed = bool(added or removed or new_ids != original_ids)
    return normalized, {
        "changed": changed,
        "addedInstanceIds": added,
        "removedInstanceIds": removed,
        "ignored": ignored,
        "componentCount": len(next_components),
    }


def normalize_step_key(value: Any) -> str:
    key = canonical_step_key(str(value or "").strip())
    alias_key = re.sub(r"[^a-z0-9_]+", "_", key.lower()).strip("_")
    return STEP_ALIASES.get(alias_key, key)


def new_component(
    step_key: str,
    *,
    label: str = "",
    enabled: bool = True,
    wait_after_seconds: float = 0.0,
    stop_on_blocked: bool = True,
    request_kind: str = "",
    override_mode: str = "merge",
    request_override: Optional[Dict[str, Any]] = None,
    source: str = "manual",
    source_path: str = "",
    instance_id: str = "",
) -> Dict[str, Any]:
    key = normalize_step_key(step_key)
    if key not in ALL_STEP_DEFINITIONS:
        raise ValueError(f"Unknown scratch-flow component: {step_key}")
    meta = ALL_STEP_DEFINITIONS[key]
    return {
        "instanceId": instance_id or _instance_id(key),
        "stepKey": key,
        "label": label or str(meta.get("label") or key),
        "enabled": bool(enabled),
        "waitAfterSeconds": max(0.0, min(float(wait_after_seconds or 0.0), 3600.0)),
        "stopOnBlocked": bool(stop_on_blocked),
        "requestKind": request_kind if request_kind in {"payload", "params"} else "",
        # Request overrides may remain in imported historical flow metadata for
        # audit/backward compatibility, but V100 rejects them before request
        # generation/LIVE execution.
        "overrideMode": override_mode if override_mode in {"merge", "replace"} else "merge",
        "requestOverride": deepcopy(request_override) if isinstance(request_override, dict) else {},
        "source": str(source or "manual"),
        "sourcePath": str(source_path or ""),
    }


def default_scratch_flow() -> Dict[str, Any]:
    return {
        "version": 2,
        "name": "Scratch Flow",
        "savedAt": None,
        "source": "default-standard-flow",
        "components": [new_component(key, source="standard") for key in DEFAULT_ORDER],
    }


def normalize_flow(value: Any) -> Dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    explicit_collection = isinstance(raw.get("components"), list) or isinstance(raw.get("steps"), list)
    rows = raw.get("components")
    if not isinstance(rows, list):
        rows = raw.get("steps") if isinstance(raw.get("steps"), list) else []

    components: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = normalize_step_key(row.get("stepKey") or row.get("component") or row.get("api") or row.get("type"))
        if key not in ALL_STEP_DEFINITIONS:
            continue
        raw_id = str(row.get("instanceId") or row.get("id") or "").strip()
        instance_id = raw_id if raw_id and raw_id not in seen else _instance_id(key)
        seen.add(instance_id)
        override = row.get("requestOverride")
        if not isinstance(override, dict):
            for candidate in ("payload", "params", "request", "value"):
                if isinstance(row.get(candidate), dict):
                    override = row[candidate]
                    break
        components.append(new_component(
            key,
            label=str(row.get("label") or ""),
            enabled=row.get("enabled", True),
            wait_after_seconds=row.get("waitAfterSeconds", row.get("wait", 0.0)),
            stop_on_blocked=row.get("stopOnBlocked", row.get("stop_on_blocked", True)),
            request_kind=str(row.get("requestKind") or ("params" if isinstance(row.get("params"), dict) else "")),
            override_mode=str(row.get("overrideMode") or row.get("mode") or "merge"),
            request_override=override if isinstance(override, dict) else {},
            source=str(row.get("source") or "manual"),
            source_path=str(row.get("sourcePath") or row.get("source_path") or ""),
            instance_id=instance_id,
        ))

    if not components and not explicit_collection:
        return default_scratch_flow()
    return {
        "version": 2,
        "name": str(raw.get("name") or "Scratch Flow"),
        "savedAt": raw.get("savedAt"),
        "source": str(raw.get("source") or "manual"),
        "components": components,
    }


def load_scratch_flow(root: Path) -> Dict[str, Any]:
    path = Path(root) / SCRATCH_FLOW_FILENAME
    if not path.exists():
        return default_scratch_flow()
    try:
        return normalize_flow(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return default_scratch_flow()


def save_scratch_flow(root: Path, flow: Dict[str, Any]) -> Dict[str, Any]:
    root = Path(root)
    normalized = normalize_flow(flow)
    normalized["savedAt"] = _now()
    (root / SCRATCH_FLOW_FILENAME).write_text(
        json.dumps(normalized, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    return normalized


def reset_scratch_flow(root: Path) -> Dict[str, Any]:
    flow = default_scratch_flow()
    flow["savedAt"] = _now()
    return save_scratch_flow(root, flow)


def _explicit_flow_rows(input_data: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
    for key in ("api_flow", "apiFlow", "scratch_flow", "scratchFlow", "flow_components", "flowComponents"):
        value = input_data.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]
        if isinstance(value, dict):
            rows = value.get("components") or value.get("steps")
            if isinstance(rows, list):
                return [x for x in rows if isinstance(x, dict)]
    return None


def _expand_explicit_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for row in rows:
        repeat_raw = row.get("repeat", 1)
        try:
            repeat = max(1, min(int(repeat_raw), 100))
        except Exception:
            repeat = 1
        payloads = row.get("payloads") if isinstance(row.get("payloads"), list) else []
        params_list = row.get("paramsList") if isinstance(row.get("paramsList"), list) else []
        labels = row.get("labels") if isinstance(row.get("labels"), list) else []
        for index in range(repeat):
            item = deepcopy(row)
            item.pop("repeat", None)
            item.pop("payloads", None)
            item.pop("paramsList", None)
            item.pop("labels", None)
            if index < len(payloads) and isinstance(payloads[index], dict):
                item["payload"] = payloads[index]
                item["requestKind"] = "payload"
            elif index < len(params_list) and isinstance(params_list[index], dict):
                item["params"] = params_list[index]
                item["requestKind"] = "params"
            if index < len(labels) and labels[index]:
                item["label"] = labels[index]
            elif repeat > 1:
                base_label = str(item.get("label") or item.get("stepKey") or item.get("component") or "Component")
                item["label"] = f"{base_label} #{index + 1}"
            item["instanceId"] = ""
            out.append(item)
    return out


def _looks_like_api_payload(value: Dict[str, Any]) -> bool:
    api_keys = {
        "name", "dataFormatType", "transactionType", "hipEnvironment", "documentIdentifier",
        "accountName", "systemName", "mapIdentifier", "ruleName", "flowDetails",
        "transportProfileDetails", "payload",
    }
    return bool(api_keys.intersection(value.keys()))


def _document_type_payload_from_object(doc: Dict[str, Any], runner: Any) -> Dict[str, Any]:
    # If input.json already contains the Dev/API-shaped request, preserve it.
    if _looks_like_api_payload(doc) and ("dataFormatType" in doc or "documentIdentifier" in doc):
        return deepcopy(doc)
    kind = "target" if str(doc.get("api_transaction_type") or doc.get("transactionType") or "").upper() == "OUTBOUND" else "source"
    return runner.doc_payload(doc, kind)


def infer_flow_from_input(input_data: Dict[str, Any], runner: Any = None) -> Tuple[Dict[str, Any], List[str]]:
    """Build a Scratch Flow from input.json.

    Exact user-authored flow arrays (`api_flow`/`scratch_flow`) take precedence.
    Otherwise the normal safe order is used and repeated object collections are
    expanded when present. This means input.json can drive the canvas without
    forcing the fixed one-instance-per-step execution_flow.json model.
    """
    warnings: List[str] = []
    explicit = _explicit_flow_rows(input_data)
    if explicit is not None:
        rows = _expand_explicit_rows(explicit)
        flow = normalize_flow({"name": "Flow from input.json", "source": "input.json:explicit", "components": rows})
        if not flow.get("components"):
            warnings.append("input.json contained an explicit flow section, but no known HIP component names were found.")
        return flow, warnings

    flow = default_scratch_flow()
    flow["name"] = "Flow inferred from input.json"
    flow["source"] = "input.json:inferred"
    objects = input_data.get("objects") if isinstance(input_data.get("objects"), dict) else {}

    # Optional repeated collections. Document Types receive first-class support
    # because that is the most common repeated create operation and is explicitly
    # requested by the API-testing workflow.
    repeated_doc_values: List[Dict[str, Any]] = []
    repeated_doc_path = ""
    for key in ("document_types", "documentTypes", "document_type", "documentType", "additional_document_types", "additionalDocumentTypes"):
        value = objects.get(key)
        if isinstance(value, list):
            repeated_doc_values = [x for x in value if isinstance(x, dict)]
            repeated_doc_path = f"objects.{key}"
            break

    if repeated_doc_values:
        if runner is None:
            warnings.append(
                f"Found {len(repeated_doc_values)} repeated document types at {repeated_doc_path}. "
                "A Runner was not supplied, so they were added as merge objects; review their payload before live execution."
            )
        extras: List[Dict[str, Any]] = []
        for index, doc in enumerate(repeated_doc_values, start=1):
            payload = _document_type_payload_from_object(doc, runner) if runner is not None else deepcopy(doc)
            extras.append(new_component(
                "doctype_source",
                label=f"Document Type #{index} · {doc.get('name') or 'unnamed'}",
                request_kind="payload",
                override_mode="replace" if runner is not None else "merge",
                request_override=payload,
                source="input.json",
                source_path=f"{repeated_doc_path}[{index - 1}]",
            ))
        # A plural/repeated document-type collection is treated as authoritative: it
        # replaces the fixed Source/Target pair on the Scratch canvas instead of
        # silently creating N+2 Document Types.
        positions = [i for i, row in enumerate(flow["components"]) if row["stepKey"] in {"doctype_source", "doctype_target"}]
        insert_at = min(positions) if positions else len(flow["components"])
        flow["components"] = [row for row in flow["components"] if row["stepKey"] not in {"doctype_source", "doctype_target"}]
        flow["components"][insert_at:insert_at] = extras
        warnings.append(
            f"Used {len(extras)} Document Type components from {repeated_doc_path} instead of the fixed Source/Target pair. "
            "If a later Map/Rule should use one of those returned IDs, reference it explicitly with {{steps.<instanceId>.<field>}} in that component payload."
        )

    # Generic extra API components can also be declared inside objects.api_components.
    generic = objects.get("api_components") or objects.get("apiComponents")
    if isinstance(generic, list):
        for row in _expand_explicit_rows([x for x in generic if isinstance(x, dict)]):
            key = normalize_step_key(row.get("stepKey") or row.get("component") or row.get("type"))
            if key not in ALL_STEP_DEFINITIONS:
                warnings.append(f"Ignored unknown input.json API component: {row.get('stepKey') or row.get('component') or row.get('type')}")
                continue
            override = row.get("payload") if isinstance(row.get("payload"), dict) else row.get("params") if isinstance(row.get("params"), dict) else row.get("request")
            flow["components"].append(new_component(
                key,
                label=str(row.get("label") or ""),
                request_kind=str(row.get("requestKind") or ("params" if isinstance(row.get("params"), dict) else "")),
                override_mode=str(row.get("overrideMode") or row.get("mode") or "merge"),
                request_override=override if isinstance(override, dict) else {},
                source="input.json",
                source_path="objects.api_components",
            ))

    flow["savedAt"] = None
    return flow, warnings


def _lookup(context: Dict[str, Any], path: str) -> Any:
    node: Any = context
    for part in str(path).split("."):
        if isinstance(node, dict) and part in node:
            node = node[part]
        else:
            return None
    return node


def resolve_templates(value: Any, context: Dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {k: resolve_templates(v, context) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_templates(v, context) for v in value]
    if not isinstance(value, str):
        return value

    full = TOKEN_PATTERN.fullmatch(value.strip())
    if full:
        key = full.group(1) or full.group(2)
        resolved = _lookup(context, key)
        return deepcopy(resolved) if resolved is not None else value

    def repl(match: re.Match[str]) -> str:
        key = match.group(1) or match.group(2)
        resolved = _lookup(context, key)
        return match.group(0) if resolved is None else str(resolved)

    return TOKEN_PATTERN.sub(repl, value)


def deep_merge(base: Any, patch: Any) -> Any:
    if isinstance(base, dict) and isinstance(patch, dict):
        out = deepcopy(base)
        for key, value in patch.items():
            out[key] = deep_merge(out[key], value) if key in out else deepcopy(value)
        return out
    return deepcopy(patch)


def component_request(runner: Any, component: Dict[str, Any], step_outputs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    component = new_component(
        component.get("stepKey"),
        label=component.get("label", ""),
        enabled=component.get("enabled", True),
        wait_after_seconds=component.get("waitAfterSeconds", 0),
        stop_on_blocked=component.get("stopOnBlocked", True),
        request_kind=component.get("requestKind", ""),
        override_mode=component.get("overrideMode", "merge"),
        request_override=component.get("requestOverride") or {},
        source=component.get("source", "manual"),
        source_path=component.get("sourcePath", ""),
        instance_id=component.get("instanceId", ""),
    )
    request = runner.preview_step_request(component["stepKey"])
    # Preserve NOT_APPLICABLE as a first-class non-mutating state. Do not
    # synthesize a neutral canonical payload for a block that does not belong to
    # the active business flow (for example Data Map/Rule in Passthrough).
    if request.get("applicable") is False:
        request["scratchComponent"] = deepcopy(component)
        return request
    request_kind = component.get("requestKind") or request.get("requestKind") or "payload"
    base = deepcopy(request.get("params") if request_kind == "params" else request.get("payload"))
    if not isinstance(base, dict):
        base = {}
    context = runner.payload_override_context()
    context["steps"] = deepcopy(step_outputs or {})
    # V100 immutable API contract: no per-block payload/parameter mutation is
    # permitted. Runtime connection mappings are applied separately by the
    # execution engine and remain allowed because they only propagate approved
    # dependency outputs into existing canonical attributes.
    assert_no_request_override(component.get("requestOverride") or {}, context=f"Flow block {component['stepKey']}")
    override = {}
    effective = deepcopy(base)

    # V71/V100: API attributes are canonical and request overrides are disabled.
    # rename, remove or re-nest API attributes relative to the U-HAUL-tested
    # 18-request contract. Missing fields in replace mode fall back to the
    # generated customer request; unknown attributes are rejected before LIVE.
    effective, structure_meta = runner.lock_request_value(
        component["stepKey"],
        request_kind,
        effective,
        fallback=base,
        strict_unknown=True,
    )
    request["requestKind"] = request_kind
    request["canonicalStructure"] = structure_meta
    if request_kind == "params":
        request["params"] = effective
        request["payload"] = None
    else:
        request["payload"] = effective
        request["params"] = None
    request["scratchComponent"] = deepcopy(component)
    return request


def _step_output(result: Any, verdict: Dict[str, Any]) -> Dict[str, Any]:
    extracted = deepcopy(getattr(result, "extracted", {}) or {})
    output = deepcopy(extracted)
    output.update({
        "httpStatus": getattr(result, "status_code", None),
        "classification": getattr(result, "classification", ""),
        "verdict": verdict.get("verdict"),
        "outcome": verdict.get("outcome"),
    })
    # Common aliases make placeholders easy to discover.
    for candidate in ("documentTypeId", "mapId", "ruleId", "flowId", "id"):
        if candidate in extracted:
            output[candidate] = extracted[candidate]
    return output


def execute_scratch_flow(root: Path, runner: Any, flow: Optional[Dict[str, Any]] = None, *, progress_callback: Any = None) -> Dict[str, Any]:
    root = Path(root)
    flow = normalize_flow(flow or load_scratch_flow(root))
    components = [row for row in flow.get("components", []) if row.get("enabled", True)]
    rows: List[Dict[str, Any]] = []
    step_outputs: Dict[str, Any] = {}
    blocked = False

    for index, component in enumerate(components, start=1):
        if callable(progress_callback):
            progress_callback(index, len(components), component)
        request = component_request(runner, component, step_outputs)
        result = runner.call(
            index,
            str(request.get("group") or ALL_STEP_DEFINITIONS[component["stepKey"]].get("group") or "Scratch Flow"),
            str(component.get("label") or request.get("api") or component["stepKey"]),
            f"scratch_{component.get('instanceId')}",
            str(request.get("method") or "POST"),
            str(request.get("urlKey") or ""),
            str(request.get("scopeKey") or ""),
            payload=request.get("payload"),
            params=request.get("params"),
            token_kind=str(request.get("tokenKind") or "HIP"),
            scope_override=request.get("scopeOverride"),
            suffix=str(request.get("suffix") or ""),
            extra_headers=request.get("extraHeaders") or {},
        )
        result.extracted = dict(result.extracted or {})
        result.extracted["logicalStepKey"] = component["stepKey"]
        result.extracted["scratchInstanceId"] = component["instanceId"]
        result.extracted["scratchFlow"] = True
        runner.capture_runtime_state(component["stepKey"], result)
        raw = asdict(result)
        verdict = agent_response_verdict(raw)
        step_outputs[component["instanceId"]] = _step_output(result, verdict)
        safe_raw = redact_sensitive(raw)
        rows.append({
            "order": index,
            "instanceId": component["instanceId"],
            "stepKey": component["stepKey"],
            "label": component["label"],
            "source": component.get("source"),
            "sourcePath": component.get("sourcePath"),
            "request": redact_sensitive({
                "method": request.get("method"),
                "url": request.get("url"),
                "requestKind": request.get("requestKind"),
                "payload": request.get("payload"),
                "params": request.get("params"),
            }),
            "result": safe_raw,
            "agentVerdict": verdict,
        })
        blocked = not verdict_allows_progress(verdict)
        if blocked and component.get("stopOnBlocked", True):
            break
        wait = float(component.get("waitAfterSeconds") or 0.0)
        # Scratch is live-only, so configured pacing is always honored after
        # an executed component.
        if wait > 0:
            time.sleep(wait)

    report = {
        "generatedAt": _now(),
        "flowName": flow.get("name") or "Scratch Flow",
        "source": flow.get("source"),
        "componentCount": len(components),
        "executedCount": len(rows),
        "passCount": sum(1 for row in rows if (row.get("agentVerdict") or {}).get("verdict") == "PASS"),
        "blockedCount": sum(1 for row in rows if not verdict_allows_progress(row.get("agentVerdict") or {})),
        "completed": len(rows) == len(components) and all(verdict_allows_progress(row.get("agentVerdict") or {}) for row in rows),
        "runtime": redact_sensitive(dict(getattr(runner, "runtime_state", {}) or {})),
        "steps": rows,
    }
    reports = root / "reports"
    reports.mkdir(exist_ok=True)
    (reports / SCRATCH_REPORT_JSON).write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    (reports / SCRATCH_REPORT_HTML).write_text(render_scratch_report_html(report), encoding="utf-8")
    return report


def render_scratch_report_html(report: Dict[str, Any]) -> str:
    cards = []
    for row in report.get("steps") or []:
        verdict = row.get("agentVerdict") or {}
        result = row.get("result") or {}
        passed = verdict.get("verdict") == "PASS"
        cls = "pass" if passed else "blocked"
        icon = "✓" if passed else "⛔"
        request = row.get("request") or {}
        response = result.get("response_preview") or result.get("error") or ""
        cards.append(f"""
        <section class="card {cls}">
          <div class="top"><span class="badge">{icon} {html.escape(str(verdict.get('verdict') or 'BLOCKED'))}</span><span>{html.escape(str(verdict.get('outcome') or ''))}</span></div>
          <h2>{row.get('order')} · {html.escape(str(row.get('label') or row.get('stepKey')))}</h2>
          <p><b>Component:</b> <code>{html.escape(str(row.get('instanceId') or ''))}</code> · <b>HTTP:</b> {html.escape(str(result.get('status_code') if result.get('status_code') is not None else '—'))}</p>
          <p><b>Agent analysis:</b> {html.escape(str(verdict.get('reason') or 'No explanation available.'))}</p>
          <p><b>Next action:</b> {html.escape(str(verdict.get('nextAction') or 'Review evidence.'))}</p>
          <details><summary>Request</summary><pre>{html.escape(json.dumps(request, indent=2, default=str))}</pre></details>
          <details><summary>Response</summary><pre>{html.escape(str(response))}</pre></details>
        </section>
        """)
    status = "PASS" if report.get("completed") else "BLOCKED / PARTIAL"
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>HIP Scratch Flow Report</title>
<style>body{{font-family:Arial,sans-serif;background:#f4f7fa;color:#14293d;margin:0;padding:28px}}.wrap{{max-width:1200px;margin:auto}}.hero{{background:#0b5cab;color:#fff;padding:24px;border-radius:18px}}.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}}.metric,.card{{background:#fff;border:1px solid #dce6ef;border-radius:16px;padding:16px}}.card{{margin:12px 0;border-left:6px solid #148447}}.card.blocked{{border-left-color:#b42318}}.top{{display:flex;gap:10px;align-items:center;font-size:.85rem}}.badge{{font-weight:800}}pre{{white-space:pre-wrap;word-break:break-word;background:#f7f9fb;padding:12px;border-radius:10px}}code{{word-break:break-all}}@media(max-width:700px){{.grid{{grid-template-columns:1fr 1fr}}}}</style></head><body><div class="wrap"><div class="hero"><h1>HIP Scratch Flow · {html.escape(str(report.get('flowName') or 'Scratch Flow'))}</h1><p>Overall: <b>{status}</b> · Source: {html.escape(str(report.get('source') or 'manual'))}</p></div><div class="grid"><div class="metric"><b>Components</b><br>{report.get('componentCount',0)}</div><div class="metric"><b>Executed</b><br>{report.get('executedCount',0)}</div><div class="metric"><b>PASS</b><br>{report.get('passCount',0)}</div><div class="metric"><b>BLOCKED</b><br>{report.get('blockedCount',0)}</div></div>{''.join(cards)}</div></body></html>"""
