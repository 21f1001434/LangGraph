# V129 Validation Summary

Release: **V129 — Same Base API Create/Edit + Governed Agent Operation Control**

## Clean-source verification

The final candidate was rebuilt from the verified V128 ZIP and only intentional V129 source/test/release files were overlaid. Verification was then run on disposable copies of this clean candidate.

| Verification | Result |
|---|---:|
| Root Python tests — group 1 | 60/60 PASS |
| Root Python tests — group 2 | 226/226 PASS |
| Root Python tests — group 3 | 123/123 PASS |
| Root Python tests — group 4 | 139/139 PASS |
| **Root Python total** | **548/548 PASS** |
| FastAPI backend tests | **55/55 PASS** |
| Package validator | **59/59 PASS** |
| Adaptive validator | **60/60 PASS** |
| Business readiness | **70/70 PASS** |
| Final release validator | **16/16 PASS** |
| TypeScript/TSX syntax/transpile parse | **26 files, 0 diagnostics** |
| Deterministic Runner Create path | **18/18 logical APIs PASS** |
| Deterministic Runner Edit path | **18/18 logical APIs PASS** |
| Deterministic Runner Migration path | **25/25 logical APIs PASS (18 base + 7 Migration)** |

## Create/Edit contract verified

For `source_tp`, `target_tp`, and `flow_create`:

- Create and Edit use the same existing POST API endpoint.
- Source/Target TP endpoint remains `/api/transport-profiles/orchestration/create`.
- Flow endpoint remains `/api/flows/orchestration/create`.
- TP Edit changes the existing outer `operation` and nested `transportProfileOperation` together.
- Flow Edit changes only the existing `operation` field.
- Method, URL, headers, request kind, keys, nesting and array cardinality remain unchanged.
- A mixed TP state such as outer Edit + nested create is rejected before HTTP.
- APIs that do not expose a Dev-approved Create/Edit operation field are not given invented fields.
- The agent can change only the governed operation selector through MCP/backend; arbitrary payload edits remain human-only.

## Interface requirement verified

HTTPS-AS2 Receiver/Target retains required:

`"SSL Certificate": "dellroot_ca_6_able.crt"`

The value can be changed by a human through the existing value editor while the field/schema remains locked.

## Retained hardening

- Document Type Name and Version remain independent evidence-backed values.
- Missing Document Type/Map/Rule/Flow versions remain blank and are surfaced as HITL/preflight blockers rather than fabricated as `1`/`1.0`.
- Routing Sender/Receiver identity is not promoted into Partner Create DUNS.
- Migration remains human ON/OFF controlled and contributes to final business success when enabled.

## Explicit verification boundary

No real Dell HIP DEV/LIVE mutation was executed because the required Dell OAuth/network context is not available in this environment. The 18/18 and 25/25 execution results use deterministic mocked HIP HTTP responses while exercising the real Runner orchestration/materialization path.

A fresh `npm install` could not complete in this isolated environment, so a dependency-resolved Vite production build is **not** claimed. The installed TypeScript compiler successfully parsed/transpiled all 26 TS/TSX source files with zero diagnostics. On the target Windows environment, run the normal `bun install`/`npm install` followed by the production build.
