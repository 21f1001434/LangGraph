# V77 — Evidence vs User Selection Conflict Gate

V77 extends the V75 engineer-blueprint input automation with an explicit human decision gate whenever deterministic customer evidence conflicts with a value the operator actually selected in Build Configuration.

## Rule

Untouched UI defaults are hints and do not create conflicts. If an operator explicitly changes a value and deterministic customer-file/manual/approved-JSON evidence contains a different value, the build is placed in `NEEDS_INPUT` and cannot proceed to 18-API validation until the conflict is resolved.

The UI shows three choices side by side:

1. **Customer File Evidence** — includes value, file/source, and confidence.
2. **Your Selected Value** — the explicit value chosen in Build Configuration.
3. **Other Approved Value** — free-form human-approved value.

The selected decision is written to canonical `input.json`, the conflict is removed, and `_builder_audit.selection_conflict_resolutions` records the file value, selected value, chosen value, and whether the chosen source was `customer_file`, `user_selected`, or `custom_user_value`.

The resolved canonical value is then used by the fixed 18 HIP API payloads, API Testing Area, API Flow Game, and Execute.

## Protected fields

The gate supports explicit conflicts for customer/partner name, direction, transaction code/name, flow type, source interface, and target interface when deterministic evidence exists. Interface aliases such as `SFTP` and `SFTP HAFT` are normalized so they do not create false conflicts.

## Safety

- No silent precedence when explicit user choice differs from evidence.
- Approved JSON remains authoritative for ordinary missing-field handling, but an explicit conflicting UI selection is surfaced for human confirmation.
- Fixed 18-API request schemas and interface-specific FILE/HTTPS/HTTPS-AS2 payload locks remain unchanged.
- U-HAUL remains Translation-only and repeated same-customer parallel execution remains supported.
