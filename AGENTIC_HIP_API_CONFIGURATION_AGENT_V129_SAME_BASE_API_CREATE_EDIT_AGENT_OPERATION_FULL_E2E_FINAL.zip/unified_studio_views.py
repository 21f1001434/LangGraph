from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import streamlit as st

from agentic_interface_orchestrator import impact_analysis
from application_studio import (
    analyze_interface_scenario,
    activate_interface_scenario,
    interface_metadata,
    interface_options,
    request_inventory,
    run_local_request_checks,
)
from api_execution_plan import clear_execution_plan
from execution_flow import STEP_DEFINITIONS
from payload_ui_helpers import safe_request_for_ui


def _json_obj(text: str) -> Dict[str, Any]:
    try:
        value = json.loads(str(text or "{}"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _load(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _set_full_coverage(root: Path) -> None:
    config_path = root / "config_overrides.json"
    config = _load(config_path, {})
    config["fullApiCoverageMode"] = True
    config["continueAfterApiFailure"] = True
    config["businessReportIncludePayloads"] = True
    config["applicationStudioMode"] = "FULL_LIVE_API_COVERAGE"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    clear_execution_plan(root, root / "input.json")


def render_agentic_interface_studio(root: Path, mcp: Any, pdf_kb: Any) -> None:
    """Render Agentic Interface Studio inside the single Streamlit application."""
    root = Path(root)
    st.markdown("## 🤖 Agentic Interface Studio")
    st.caption(
        "Choose any registered interface. The agent observes the approved baseline, "
        "retrieves the interface contract, asks only for missing values, generates the "
        "Transport Profile/Flow changes, runs MCP validation and a critic, then prepares "
        "the same full live API execution pipeline."
    )

    baseline = _load(root / "dev_approved" / "UHAL_input_dev_approved.json", _load(root / "input.json", {}))
    keys = interface_options(root)
    if not keys:
        st.error("No interface definitions are available.")
        return

    c1, c2 = st.columns(2)
    source_key = c1.selectbox("Source interface", keys, index=keys.index("SFTP") if "SFTP" in keys else 0, key="unified_agent_src")
    target_key = c2.selectbox("Target interface", keys, index=keys.index("SFTP") if "SFTP" in keys else 0, key="unified_agent_tgt")

    source_def = interface_metadata(root, source_key)
    target_def = interface_metadata(root, target_key)
    m1, m2, m3 = st.columns(3)
    m1.metric("Source API interface", source_def.get("apiInterfaceType") or source_key)
    m2.metric("Target API interface", target_def.get("apiInterfaceType") or target_key)
    m3.metric("Deployment", source_def.get("deploymentGroup") or target_def.get("deploymentGroup") or "hip-automation")

    def defaults(definition: Dict[str, Any], side: str) -> Dict[str, Any]:
        value = (definition.get("parameterDefaults") or {}).get(side) or {}
        return value if isinstance(value, dict) else {}

    with st.expander("Interface values", expanded=True):
        p1, p2 = st.columns(2)
        with p1:
            st.markdown("**Source interface parameters**")
            source_params_text = st.text_area(
                "Source parameters JSON",
                value=json.dumps(defaults(source_def, "source"), indent=2),
                height=240,
                key=f"unified_src_params_{source_key}",
            )
            source_shared = st.text_input(
                "Source shared Flow profile",
                value=str(source_def.get("sourceSharedProfile") or ""),
                key=f"unified_src_shared_{source_key}",
            )
        with p2:
            st.markdown("**Target interface parameters**")
            target_params_text = st.text_area(
                "Target parameters JSON",
                value=json.dumps(defaults(target_def, "target"), indent=2),
                height=240,
                key=f"unified_tgt_params_{target_key}",
            )
            target_shared = st.text_input(
                "Target shared Flow profile",
                value=str(target_def.get("targetSharedProfile") or ""),
                key=f"unified_tgt_shared_{target_key}",
            )
        deployment_group = "hip-automation"
        st.text_input(
            "Deployment group · fixed by Dev team for automation",
            value=deployment_group, disabled=True, key="unified_interface_deployment_locked",
        )

    if st.button("Observe → Plan → Validate → Critic", type="primary", width="stretch", key="unified_agent_plan"):
        proposal = analyze_interface_scenario(
            root,
            baseline,
            pdf_kb,
            source_interface=source_key,
            target_interface=target_key,
            source_parameters=_json_obj(source_params_text),
            target_parameters=_json_obj(target_params_text),
            source_shared_profile=source_shared,
            target_shared_profile=target_shared,
            deployment_group=deployment_group,
        )
        proposal["mcpPlan"] = mcp.plan_interface_configuration(
            baseline_input=baseline,
            source_interface=source_key,
            target_interface=target_key,
            source_parameters=_json_obj(source_params_text),
            target_parameters=_json_obj(target_params_text),
            source_shared_profile=source_shared,
            target_shared_profile=target_shared,
            deployment_group=deployment_group,
        )
        st.session_state["unified_interface_proposal"] = proposal

    proposal = st.session_state.get("unified_interface_proposal")
    if proposal:
        st.markdown("### Agent trace")
        trace_cols = st.columns(max(1, len(proposal.get("trace") or [])))
        for col, item in zip(trace_cols, proposal.get("trace") or []):
            with col:
                st.markdown(f"**{item.get('phase')}**")
                st.caption(f"{item.get('status')} · {item.get('summary')}")

        questions = proposal.get("questions") or []
        if questions:
            st.warning("The agent is waiting for required interface values/documentation.")
            for item in questions:
                st.markdown(f"- **{item.get('question')}** — {item.get('why')}")

        critic = proposal.get("critic") or {}
        if critic.get("status") == "PASS":
            st.success("Critic PASS — only approved interface/deployment/derived Flow bindings changed.")
        elif critic.get("status") == "BLOCKED":
            st.info("Critic is waiting for the required values above.")
        else:
            st.error("Critic rejected the proposal.")
            st.json(critic)

        if proposal.get("changedPaths"):
            impact = impact_analysis(proposal.get("changedPaths") or [])
            with st.expander("Impact analysis"):
                st.json(impact)

        with st.expander("MCP interface-plan evidence"):
            st.json(proposal.get("mcpPlan") or {})

        if proposal.get("valid") and proposal.get("proposal"):
            if st.button("Activate this interface plan in Application Studio", type="primary", width="stretch", key="unified_activate_interface"):
                activate_interface_scenario(root, proposal["proposal"])
                _set_full_coverage(root)
                st.session_state["unified_interface_activated"] = True
                st.success("Interface plan activated. Full API Coverage mode is enabled; no API will be skipped by an existing-object plan.")
                st.rerun()

    if st.session_state.get("unified_interface_activated"):
        st.markdown("### Generated live API building blocks")
        try:
            inventory = request_inventory(root)
            rows = []
            for card in inventory.get("cards") or []:
                rows.append({
                    "#": card.get("order"),
                    "API": card.get("label"),
                    "Method": card.get("method"),
                    "Decision": card.get("decision"),
                    "Edited": "Yes" if card.get("edited") else "No",
                })
            st.dataframe(rows, width="stretch", hide_index=True)
            selected = st.selectbox("Inspect generated request", [c.get("label") for c in inventory.get("cards") or []], key="unified_interface_request")
            card = next((c for c in inventory.get("cards") or [] if c.get("label") == selected), None)
            if card:
                tabs = st.tabs(["Effective request", "Generated baseline", "Endpoint"])
                with tabs[0]:
                    st.json(safe_request_for_ui(card.get("effective") or {}))
                with tabs[1]:
                    st.json(safe_request_for_ui(card.get("generated") or {}))
                with tabs[2]:
                    st.code(f"{card.get('method')} {card.get('url')}")
        except Exception as exc:
            st.warning(f"Request inventory is not ready yet: {exc}")


def render_advanced_tools(root: Path, mcp: Any) -> None:
    """Compact advanced tools embedded in the same Application Studio."""
    root = Path(root)
    st.markdown("## 🛠️ Payload, MCP & execution tools")
    st.caption("These are project-team controls embedded in the same Studio; no separate Streamlit page is required.")

    t1, t2, t3 = st.tabs(["Payload inventory", "MCP tools", "Execution state"])
    with t1:
        try:
            inventory = request_inventory(root)
            st.metric("Generated logical API requests", inventory.get("total", 0))
            for card in inventory.get("cards") or []:
                with st.expander(f"{card.get('order')} · {card.get('label')} · {card.get('method')} · {card.get('decision')}"):
                    st.code(f"{card.get('method')} {card.get('url')}")
                    st.markdown("**Effective request**")
                    st.json(safe_request_for_ui(card.get("effective") or {}))
        except Exception as exc:
            st.error(str(exc))

    with t2:
        st.json(mcp.status())
        if st.button("Run MCP readiness checks", width="stretch", key="unified_mcp_readiness"):
            input_data = _load(root / "input.json", {})
            config_data = _load(root / "config_overrides.json", {})
            st.session_state["unified_mcp_result"] = {
                "input": mcp.validate_uhal_input(input_data, config_data),
                "policy": mcp.validate_execution_policy(),
                "readiness": mcp.assess_execution_readiness(input_data, config_data),
            }
        if st.session_state.get("unified_mcp_result"):
            st.json(st.session_state["unified_mcp_result"])

    with t3:
        checks = run_local_request_checks(root)
        st.json({
            "ok": checks.get("ok"),
            "mapper": checks.get("mapper"),
            "executionPlan": checks.get("executionPlan"),
            "executionFlow": checks.get("executionFlow"),
            "mcpReadiness": checks.get("mcpReadiness"),
        })
