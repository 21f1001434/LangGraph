# V57 - API Flow Game validated customer payload selector

## What changed

- API Flow Game now has a **Customer Payload** selector populated from the same validated customer source library used by Parallel Runs.
- Packaged **U-HAUL** is selectable directly in the Flow Game, alongside Legrand and other validated customer configurations.
- U-HAUL remains immutable as the packaged approved reference. The first Flow Game selection creates a private managed editable mirror and subsequent selections reuse it so payload overrides and reports persist.
- Switching customers reloads the matching template/graph and automatically loads that customer's effective API requests, validation state, payload overrides, and applicability status.
- Switching from Legrand to U-HAUL (or back) clears stale preflight, trace, selection and execution state so payloads cannot bleed between customers.
- Managed U-HAUL Flow Game mirrors are hidden from the normal Configuration Library and from the Parallel Runs source list, preventing duplicate U-HAUL cards.
- U-HAUL mirror preserves approved DUNS `12345666`, XML/XBM/JAR customer evidence and the existing final pre-LIVE safety gates.
- Individual block Agent Check / LIVE execution and whole-flow LIVE execution continue to run against the currently selected customer's isolated workspace.

## Validation

- `pytest`: 210/210 passed
- `validate_package.py`: 57/57 passed
- `validate_adaptive_package.py`: 60/60 passed
- `FINAL_RELEASE_VALIDATION.py`: 16/16 passed
- Phase 1-6 checker suites: all passed
- TypeScript/TSX syntax transpilation: 22 files, 0 diagnostics

A full Vite build was not run in the packaging container because frontend dependencies are not installed there. On the target machine run `bun install` and `bun run build` as usual.
