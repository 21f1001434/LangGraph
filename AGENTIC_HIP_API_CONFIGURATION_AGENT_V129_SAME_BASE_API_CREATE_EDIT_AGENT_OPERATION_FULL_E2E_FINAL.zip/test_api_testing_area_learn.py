from __future__ import annotations

import json
import tempfile
from pathlib import Path

from business_demo import agent_response_verdict
from learn_assistant import LearnAssistant, _har_text
from run_agent import AIAJudge


def test_existing_is_pass():
    v = agent_response_verdict({
        "api": "Create System",
        "status_code": 409,
        "business_success": False,
        "response_preview": "AIC-DCE is already exists. Please Update",
    })
    assert v["verdict"] == "PASS"
    assert v["outcome"] == "EXISTING"


def test_missing_dependency_is_blocked():
    v = agent_response_verdict({
        "api": "Source TP orchestration create ONLY",
        "status_code": 400,
        "business_success": False,
        "response_preview": "not able to find system AIC-DCE",
    })
    assert v["verdict"] == "BLOCKED"


def test_text_model_never_used_for_vision(monkeypatch):
    monkeypatch.setenv("MODEL_NAME", "gpt-oss-120b")
    monkeypatch.delenv("HIP_VISION_MODEL", raising=False)
    judge = AIAJudge({}, enabled=True)
    candidates = [x.lower() for x in judge.vision_candidates()]
    assert "gpt-oss-120b" not in candidates
    assert "gemma-3-27b-it" in candidates
    assert "pixtral-12b-2409" in candidates


def test_har_redacts_authorization_and_secret():
    har = {
        "log": {"entries": [{
            "request": {
                "method": "POST", "url": "https://example/api",
                "headers": [{"name": "Authorization", "value": "Bearer abc123"}],
                "postData": {"text": '{"client_secret":"supersecret","name":"ok"}'},
            },
            "response": {"status": 400, "content": {"text": "not able to find"}},
        }]}
    }
    text = _har_text(har)
    assert "Bearer abc123" not in text
    assert "supersecret" not in text
    assert "<REDACTED>" in text


def main():
    test_existing_is_pass()
    test_missing_dependency_is_blocked()
    print(json.dumps({"status": "PASS", "apiResponseVerdict": True, "visionRouting": True, "learnHarRedaction": True}, indent=2))


if __name__ == "__main__":
    main()


def test_learn_persists_har_in_redacted_form(tmp_path: Path):
    har = {
        "log": {"entries": [{
            "request": {
                "method": "POST",
                "url": "https://example/api?x=1",
                "headers": [
                    {"name": "Authorization", "value": "Bearer TOPSECRET"},
                    {"name": "Cookie", "value": "SESSION=VERYSECRET"},
                ],
                "postData": {"text": '{"client_secret":"CLIENTSECRET","name":"ok"}'},
            },
            "response": {
                "status": 400,
                "headers": [{"name": "Set-Cookie", "value": "server=SECRETCOOKIE"}],
                "content": {"text": '{"refresh_token":"REFRESHSECRET","message":"bad"}'},
            },
        }]}
    }
    assistant = LearnAssistant(tmp_path)
    record = assistant.ingest("network.har", json.dumps(har).encode("utf-8"), "application/json")
    stored = Path(record["storedPath"]).read_text(encoding="utf-8")
    record_text = Path(tmp_path / "knowledge" / "learn" / "records" / f"{record['id']}.json").read_text(encoding="utf-8")
    for secret in ("TOPSECRET", "VERYSECRET", "CLIENTSECRET", "SECRETCOOKIE", "REFRESHSECRET"):
        assert secret not in stored
        assert secret not in record_text
    assert record["storedRedacted"] is True
    assert "<REDACTED>" in stored
