# V119 — Universal Human Value Editor in Build Configuration, API Testing, and API Flow Game

## Release intent

V119 extends the V118 human-user-only payload value editor to every primary configuration/testing surface:

- Build Configuration
- API Testing Area
- API Flow Game / selected API block inspector

The editing authority is unchanged: the AI/AutoGen/Dell-AIA agent may inspect, explain, validate and recommend values, but cannot save or apply payload value edits. Only an explicit human-user action may persist an edit before LIVE execution.

## Value-only editing contract

For any applicable API, the user selects an existing API attribute/path and changes only the value at that path. The editor does not expose attribute-name editing or full-request raw JSON replacement.

The following remain immutable:

- API method and URL
- request kind
- protected headers
- attribute/key names
- object nesting
- array structure/cardinality
- developer-approved request structure

Scalar values (string, number, boolean and null) are editable through governed controls. Sensitive-looking values use masked inputs in the modern editor.

## Build Configuration

Build Configuration retains the V118 editor: select an API, select an existing attribute, compare generated/current values, save the human-entered value, restore one value, or restore all edits for that API.

## API Testing Area

The React API Testing Area now uses the same shared `HumanPayloadValueEditor` component and the same backend human-edit endpoint as Build Configuration. The former raw JSON mutation path is removed.

Saving or restoring an edit refreshes the effective request and configuration before further validation/testing.

The legacy Streamlit API Testing surface is also constrained to existing scalar value edits and no longer exposes a full-request JSON editor.

## API Flow Game

Selecting an API block and opening its Payload tab now exposes the same human value-only editor. The block keeps the generated baseline separately from the effective request so the operator can see exactly what changed.

Save and restore use the same governed backend path. Preflight, individual checks, and LIVE execution consume the effective governed request without turning runtime results into a new generated baseline.

The legacy Scratch/API Flow surface is also value-only; its advanced full-JSON override editor has been removed.

## Governance and agent boundary

All three modern surfaces use the existing backend override governance. A persisted edit must be an explicit human value edit; agent-originated/ad-hoc override attempts remain blocked. The agent cannot provide a changed request and silently persist it through these UIs.

Approved U-HAUL reference configurations remain immutable references; users edit a clone/editable configuration rather than modifying the approved reference itself.

## Transport Profile contract retained

V119 does not change the Transport Profile architecture introduced in V117/V118. SFTP HAFT (including U-HAUL/LEGRAND), FTP, HTTPS, HTTPS-AS2 and future Dev-approved interfaces retain the same outer Source/Target Transport Profile structure. Interface-specific differences remain confined to:

`transportProfileDetails[0].interfaceDetails`

Human edits to existing TP values are allowed; switching an interface does not authorize outer-schema mutation.

## Plain HTTPS Receiver boundary

The plain HTTPS Receiver Dev-validation candidate remains pending Dev/API-team contract confirmation. V119 does not convert that candidate into a LIVE-approved contract and does not change the separate HTTPS-AS2 certificate/encryption/verification contract.

## Validation

Final V119 source validation:

- Full pytest inventory: **502/502 PASS**
- Package validator: **59/59 PASS**
- Adaptive package validator: **60/60 PASS**
- Business readiness: **70/70 PASS**
- Final release validator: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1: **12/12 PASS**
- Phase 2: **19/19 PASS**
- Phase 3: **31/31 PASS**
- Phase 4: **26/26 PASS**
- Phase 5: **28/28 PASS**
- Phase 6: **38/38 PASS**

The self-check reports Bun availability as an advisory environment item because Bun is not installed in the validation container; it is not a required-check failure. The modified TypeScript/TSX files passed isolated TypeScript syntax transpilation during implementation validation.
