from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import run_agent
from api_execution_plan import clear_execution_plan
from execution_flow import ExecutionFlowConfig, save_execution_flow
from migration_api_contract import MIGRATION_ORDER
from production_integration_test import FakeResponse, fake_response

ROOT = Path(__file__).resolve().parent


def migration_aware_fake_response(method: str, url: str, payload, params) -> FakeResponse:
    if "/api/migration/orchestration/" in url:
        return FakeResponse(
            url,
            200,
            {
                "success": True,
                "status": "COMPLETED",
                "message": "Offline deterministic Migration integration success",
            },
        )
    return fake_response(method, url, payload, params)


def _all_rows(flow: ExecutionFlowConfig):
    return [
        {
            "stepKey": row["stepKey"],
            "order": row["order"],
            "waitAfterSeconds": 0,
        }
        for row in flow.summary()["liveSteps"]
    ]


def main() -> None:
    plan_path = ROOT / "api_execution_plan.json"
    flow_path = ROOT / "execution_flow.json"
    original_plan = plan_path.read_bytes() if plan_path.exists() else None
    original_flow = flow_path.read_bytes() if flow_path.exists() else None
    old_target = os.environ.get("HIP_MIGRATION_TARGET_ENVIRONMENT")
    old_force = os.environ.get("HIP_FORCE_MIGRATION_IN_FULL_LIVE")
    try:
        clear_execution_plan(ROOT, ROOT / "input.json")
        flow = ExecutionFlowConfig(ROOT)
        save_execution_flow(ROOT, _all_rows(flow), migration_enabled=True)
        os.environ["HIP_MIGRATION_TARGET_ENVIRONMENT"] = "TEST2"
        # A stale force variable must be irrelevant; execution consent comes from
        # execution_flow.json only.
        os.environ["HIP_FORCE_MIGRATION_IN_FULL_LIVE"] = "false"
        _run_full_25()
    finally:
        if original_plan is None:
            plan_path.unlink(missing_ok=True)
        else:
            plan_path.write_bytes(original_plan)
        if original_flow is None:
            flow_path.unlink(missing_ok=True)
        else:
            flow_path.write_bytes(original_flow)
        if old_target is None:
            os.environ.pop("HIP_MIGRATION_TARGET_ENVIRONMENT", None)
        else:
            os.environ["HIP_MIGRATION_TARGET_ENVIRONMENT"] = old_target
        if old_force is None:
            os.environ.pop("HIP_FORCE_MIGRATION_IN_FULL_LIVE", None)
        else:
            os.environ["HIP_FORCE_MIGRATION_IN_FULL_LIVE"] = old_force


def _run_full_25() -> None:
    runner = run_agent.Runner(llm_enabled=False)
    runner.ov["tpProcessingWaitSeconds"] = 0
    runner.ov["flowProcessingWaitSeconds"] = 0
    runner.runtime_state.update({
        "source_document_type_id": None,
        "target_document_type_id": None,
        "map_id": None,
        "rule_id": None,
        "flow_id": None,
    })
    for key in (
        "source_document_type_id", "target_document_type_id", "map_id", "rule_id", "existing_flow_id"
    ):
        runner.ov[key] = None

    runner.get_token = lambda token_kind, scope: "offline-token"
    runner.judge.judge = lambda result: {}
    runner.judge.available = lambda: False

    def mocked_request(method, url, token_kind, scope, extra_headers, payload, params):
        return migration_aware_fake_response(method, url, payload, params)

    runner._request_with_retry = mocked_request

    with patch("run_agent.time.sleep", return_value=None), patch.object(
        runner.adaptive, "record_api_result", return_value=None
    ), patch.object(
        runner.adaptive, "record_mapping_graph", return_value={"status": "mocked"}
    ):
        results = runner.run()

    http_steps = [
        str((row.extracted or {}).get("logicalStepKey") or "")
        for row in results
        if row.status_code is not None
    ]
    assert runner.final_state["migrationExecutionEnabled"] is True, runner.final_state
    assert runner.final_state["success"] is True, runner.final_state
    assert runner.final_state["businessSuccess"] is True, runner.final_state
    assert runner.final_state["expectedApplicableApiCount"] == 25, runner.final_state
    assert runner.final_state["calledApplicableApiCount"] == 25, runner.final_state
    assert len(set(http_steps)) == 25, http_steps
    assert all(step in http_steps for step in MIGRATION_ORDER), http_steps
    assert not runner.final_state["unresolvedRequiredSteps"], runner.final_state

    output = {
        "status": "PASS",
        "logicalApiSteps": len(set(http_steps)),
        "baseApiSteps": 18,
        "migrationApiSteps": 7,
        "endToEndSuccess": runner.final_state["success"],
        "businessSuccess": runner.final_state["businessSuccess"],
        "migrationExecutionEnabled": runner.final_state["migrationExecutionEnabled"],
        "expectedApplicableApiCount": runner.final_state["expectedApplicableApiCount"],
        "calledApplicableApiCount": runner.final_state["calledApplicableApiCount"],
        "unresolvedRequiredSteps": runner.final_state["unresolvedRequiredSteps"],
    }
    path = ROOT / "examples" / "PRODUCTION_MOCK_25_API_INTEGRATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
