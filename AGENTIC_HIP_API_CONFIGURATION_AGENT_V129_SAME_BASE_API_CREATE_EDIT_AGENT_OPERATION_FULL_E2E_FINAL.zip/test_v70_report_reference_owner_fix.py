import json
import shutil
from pathlib import Path

from customer_intake_report import write_customer_intake_report, REPORT_HTML, REPORT_JSON

ROOT = Path(__file__).resolve().parent

def test_dce_test_partner_owns_duns_not_uhal(tmp_path: Path):
    shutil.copy2(ROOT / "input.json", tmp_path / "input.json")
    (tmp_path / "input_files").mkdir()
    model = write_customer_intake_report(tmp_path, {
        "workspace": str(tmp_path), "customer": "U-HAUL", "source_interface": "SFTP",
        "target_interface": "SFTP", "direction": "Outbound", "transaction_code": "856",
        "transaction_name": "Ship Notice", "flow_type": "Translation", "questions": []
    }, ROOT)
    row = next(r for r in model["rows"] if r["path"] == "partner_identifier_value")
    assert row["referenceOwner"] == "dce-test-partner"
    assert row["uhalValue"] == "dce-test-partner — DUNS 12345666"
    assert model["uhalReference"]["partnerReference"]["name"] == "dce-test-partner"
    assert model["uhalReference"]["partnerReference"]["identifierValue"] == "12345666"
    html = (tmp_path / "reports" / REPORT_HTML).read_text(encoding="utf-8")
    assert "dce-test-partner — DUNS 12345666" in html
    assert "This DUNS belongs to the HIP partner object, not to U-HAUL" in json.dumps(model, ensure_ascii=False)
    assert "U-HAUL DUNS" not in html
