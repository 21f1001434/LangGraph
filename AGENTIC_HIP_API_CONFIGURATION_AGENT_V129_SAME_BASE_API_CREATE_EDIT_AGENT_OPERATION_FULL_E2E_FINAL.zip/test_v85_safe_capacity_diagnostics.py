from pathlib import Path
from webapp.backend.app.parallel_manager import _attention_diagnostics

ROOT = Path(__file__).resolve().parent

def test_v85_diagnostics_still_extract_first_real_live_blocker():
    report = {"results": [
        {"sequence": 1, "api": "Account Validate", "final_status": "PASS", "status_code": 200},
        {"sequence": 2, "group": "Partner", "api": "Partner Create", "final_status": "BLOCKED", "status_code": 409, "agent_reason": "Concurrent create conflict", "agent_next_action": "Reuse the existing partner or retry.", "response_preview": '{"message":"already in progress"}'},
    ]}
    rows = _attention_diagnostics(report)
    assert rows[0]["api"] == "Partner Create"
    assert rows[0]["httpStatus"] == 409
    assert "Concurrent create conflict" in rows[0]["reason"]

def test_v89_removed_capacity_and_stress_are_not_exposed():
    page=(ROOT/'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    api=(ROOT/'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    for word in ('Safe Capacity Test','Advanced LIVE Stress','CAPACITY_SAFE','LIVE_STRESS','ADAPTIVE_LIVE'):
        assert word not in page and word not in api
    assert 'RUN LIVE EXECUTION' in page
    assert 'View cause' in page
