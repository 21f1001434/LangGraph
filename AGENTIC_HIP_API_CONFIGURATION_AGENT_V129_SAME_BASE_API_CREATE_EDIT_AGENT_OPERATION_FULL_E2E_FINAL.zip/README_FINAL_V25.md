# HIP Application Studio — Final V25 OAuth Hardened

This release contains the complete V24 full solution plus a hardened HIP OAuth runtime path.

## V25 fix

`Runner.get_token()` no longer assumes the full `Runner.__init__()` path has executed. Lightweight connection diagnostics/tests can acquire a HIP token without raising `AttributeError: hip_token_user_agent`. The default Postman-compatible User-Agent remains `PostmanRuntime/7.49.0`, with `HIP_TOKEN_USER_AGENT` still supported as an override during normal initialization. Token bookkeeping is also initialized safely for lightweight runners.

## Regression coverage

V25 includes dedicated tests for:

- JSON OAuth token success from a lightweight Runner.
- Redirect handling with a single logical authentication POST.
- User-Agent fallback and token source bookkeeping.

All previous Input Builder, 18-API, Scratch/Game, hip-automation, Learn, interactive graph, payload editing, and live-only functionality remains included.
