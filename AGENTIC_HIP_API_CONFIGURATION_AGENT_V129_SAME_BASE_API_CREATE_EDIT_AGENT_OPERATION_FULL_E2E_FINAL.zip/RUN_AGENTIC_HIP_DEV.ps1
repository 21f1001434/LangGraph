$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) { throw 'Bun is required. Run SETUP_AGENTIC_HIP.ps1 first.' }

$backendArgs = 'webapp.backend.app.main:app --host 127.0.0.1 --port 8765'
if ($env:HIP_BACKEND_HOT_RELOAD -eq '1') {
    Write-Host 'Backend SAFE hot reload enabled: watching webapp/backend/app only.'
    $backendArgs += ' --reload --reload-dir webapp/backend/app'
} else {
    Write-Host 'Backend hot reload disabled for startup stability. Bun/Vite frontend HMR remains enabled.'
    Write-Host 'Set HIP_BACKEND_HOT_RELOAD=1 before launch to opt into scoped backend hot reload.'
}

Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot'; python -m uvicorn $backendArgs"
Start-Sleep -Seconds 2
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot/webapp/frontend'; bun run dev"
Start-Sleep -Seconds 2
Start-Process 'http://127.0.0.1:5173'
