$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
python --version
python -m pip install -r requirements.txt
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) { throw 'Bun was not found on PATH. Install Bun, reopen PowerShell, then run this script again.' }
Push-Location webapp/frontend
bun install
bun run build
Pop-Location
python .\runtime_preflight.py --production
& "$PSScriptRoot/RUN_AGENTIC_HIP.ps1"
