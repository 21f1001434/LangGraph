from pathlib import Path

BUILDER = Path('webapp/frontend/src/pages/BuilderPage.tsx')


def text() -> str:
    return BUILDER.read_text(encoding='utf-8')


def test_v124_imports_usememo_from_react():
    src = text()
    assert "import { useEffect, useMemo, useState } from 'react';" in src


def test_v124_catalog_has_explicit_api_catalog_item_type():
    src = text()
    assert "ApiCatalogItem" in src
    assert "useMemo<ApiCatalogItem[]>" in src


def test_v124_catalog_find_callback_is_not_implicit_any():
    src = text()
    assert "catalog.find((row:ApiCatalogItem)=>row.key===stepKey)" in src


def test_v124_catalog_map_callback_is_not_implicit_any():
    src = text()
    assert "catalog.map((row:ApiCatalogItem)=>" in src


def test_v124_user_value_only_governance_is_unchanged():
    src = text()
    assert "VALUE ONLY · HUMAN USER" in src
    assert "The AI/AutoGen/Dell-AIA agent has no save/edit authority." in src
    assert "Save selected value + revalidate" in src
