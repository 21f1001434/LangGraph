# Exact Postman OAuth Implementation

The token request is now fixed to one request shape only:

```http
POST https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token
Authorization: Basic base64(client_id:client_secret)
Content-Type: application/x-www-form-urlencoded
Accept: */*

grant_type=client_credentials
```

- Scope is omitted when blank.
- JSON and form-body credential variants are not attempted.
- Direct network mode is the default and disables Python's inherited
  `HTTP_PROXY` / `HTTPS_PROXY` settings.
- Auto mode tries direct first and then the Windows/environment proxy.
- Redirects are followed by default, matching Postman's generated cURL
  `--location` option.
- A manually generated token remains available only as an optional temporary
  fallback.

Run:

```powershell
python -m pip install -r requirements.txt
python test_exact_postman_oauth.py
python -m streamlit run adaptive_uhal_app.py --server.port 8503
```
