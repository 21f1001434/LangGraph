# V110 Final Validation — U-HAUL + LEGRAND Supplied LIVE Runs

## Release

- Release: **V110**
- Build: `2026-08-31-agentic-hip-v110-business-final-strict-live-no-reuse-immutable-api-governed-skills-uhal-legrand-live-run-fixes`
- Scope: fixes derived directly from the newly supplied U-HAUL and LEGRAND LIVE run screenshots, plus complete non-mutating package regression.

## U-HAUL LIVE findings and fixes

### 1. Mapping Rule existing response omitted `ruleId`
The canonical Rule POST was executed and HIP returned that the same Rule/version already exists in DEV, but `data` was null and no `ruleId` was returned. Flow Orchestration needs `ruleRefs.ruleDetails.id`, so V109 repeatedly re-ran Rule Create and remained `LIVE_ID_UNRESOLVED`.

**V110 fix:** after the canonical Rule POST has itself returned success/existing, perform a separate **GET-only current-environment identity lookup**. Resolution requires exact Rule name + version + environment and accepts exactly one positive Rule ID. The lookup never reads a packaged/history ID and never alters/retries the Rule POST body.

Default read candidates:
- `/api/rule/details?ruleName=...&environment=DEV&ruleVersion=...`
- `/api/rule/summary`

Optional controlled overrides:
- `HIP_RULE_DETAILS_API_URL`
- `HIP_RULE_SUMMARY_API_URL`

Read endpoint vetting requires HTTPS and a Dell-owned host. Missing/ambiguous identity becomes terminal `LIVE_RULE_ID_UNRESOLVED`, preventing repeated Rule POSTs.

### 2. Source TP audit incorrectly followed newer failed EDIT history
The supplied source TP audit contained failed `edit` records above a successful historical `create` record. The canonical pipeline calls TP orchestration **CREATE ONLY**.

**V110 fix:** when `operation` is present, TP audit verification selects CREATE records first and evaluates the newest CREATE record. Unrelated failed EDIT history can no longer turn a successful TP create/existing verification into a retry warning/failure.

## LEGRAND LIVE findings and fixes

### 3. Flow Create rejected a 43-character generated name
Supplied value:

`LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` (43 characters)

HIP Flow Create requires 1–40 characters and restricted characters.

**V110 canonical value:**

`LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 characters)

This transformation occurs during canonical input construction, before any LIVE request is materialized. It is transparent in `_flow_name_normalization`; it is not a post-HTTP retry mutation. Production preflight independently validates the 40-character policy. If a backend still returns the deterministic flow-name validation 400, V110 classifies it `FLOW_NAME_INVALID` and does not repeat it during auto-completion.

## Immutable/developer-approved API protections retained

- Rule POST: no `documentTypeId`.
- Rule POST: no `flowDefinitionId`.
- Rule action params: no `mapId`.
- Map remains referenced by identifier/version.
- Every applicable canonical API executes; no packaged historical ID causes an API to be skipped.
- Runtime request fingerprint prevents changed retry bodies/queries.
- No post-response Flow renaming.
- Account/Partner/System missing upstream PCF routes remain truthful `API_UPSTREAM_ROUTE_UNAVAILABLE` external failures; approved request payloads are not mutated to hide them.

## Validation results

- V110 focused supplied-live-run fixes: **7/7 PASS**
- Compatibility regression set: **45/45 PASS**
- Top-level application regression: **432/432 PASS**
- FastAPI/backend: **48/48 PASS**
- Combined Python: **480/480 PASS**
- Package validation: **58/58 PASS**
- Adaptive package: **60/60 PASS**
- Business readiness: **69/69 PASS**
- Final release: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1: **12/12 PASS**
- Phase 2: **19/19 PASS**
- Phase 3: **31/31 PASS**
- Phase 4: **26/26 PASS**
- Phase 5: **28/28 PASS**
- Phase 6: **38/38 PASS**
- React TypeScript/TSX syntax: **24 files, 0 syntax errors**
- Controlled 18-step end-to-end simulation: **PASS**, `endToEndSuccess=true`, no blocked steps
- FastAPI real startup smoke: `/api/health` HTTP 200; `/api/bootstrap` HTTP 200; 18 API blocks exposed

## Live boundary

No authenticated Dell mutation was executed from this build sandbox. External Dell route availability and tenant data remain live-environment dependencies. In particular, the Account/Partner/System PCF route 404 shown in both supplied runs requires Dell platform restoration or a replacement endpoint; V110 correctly does not fabricate success for it.
