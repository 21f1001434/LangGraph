from pathlib import Path

from report_insights import analyze_api_response
from webapp.backend.app.parallel_manager import _live_batch_counts

ROOT = Path(__file__).resolve().parent


def test_pre_existing_response_is_pass_existing():
    result = analyze_api_response({
        "status_code": 500,
        "response_preview": '{"message":"Partner is pre-existing and already configured"}',
        "classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD",
        "business_success": False,
    })
    assert result["verdict"] == "PASS"
    assert result["outcome"] == "EXISTING"


def test_live_batch_counts_update_before_batch_completion():
    summary = _live_batch_counts([
        {"jobId": "a", "status": "PASS"},
        {"jobId": "b", "status": "WARNING"},
    ])
    assert summary["completedCount"] == 2
    assert summary["passCount"] == 1
    assert summary["warningCount"] == 1
    assert summary["failCount"] == 0
    assert summary["overallVerdict"] == "WARNING"


def test_ui_uses_execute_and_live_result_progress():
    sidebar = (ROOT / "webapp/frontend/src/components/Sidebar.tsx").read_text(encoding="utf-8")
    parallel = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    flow = (ROOT / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    assert "label:'Execute'" in sidebar
    assert "live-result-progress" in parallel
    assert "updating live" in parallel
    assert "completedCount" in parallel
    assert "message&&<Panel" in flow
    assert "window.setTimeout(()=>setMessage(''),3200)" in flow


def test_runner_existing_resolution_uses_shared_agent_judge():
    runner = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert 'analyze_api_response(r).get("outcome")' in runner
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert '_final_status_from_runner' in manager and 'int(hard_agent_failures or 0) == 0' in manager
