# V63 — Full-width sidebar active-state fix

## Change
The expanded desktop/mobile sidebar now stretches every navigation row to the full available width. The active/hover background therefore fills the complete navigation row rather than stopping at the text/icon content width.

## CSS hardening
- `.nav-group`: `width: 100%; min-width: 0`
- `.nav-item`: `width: 100%; align-self: stretch; box-sizing: border-box`
- Existing compact/collapsed mode still overrides `.nav-item` to `46px`, preserving the icon-only design.
- Mobile drawer continues to restore `.nav-item { width: 100% }`.

No routing, click targets, page functionality, LIVE controls, API payload logic, or execution behavior were changed.
