from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Mapping


def load_approved_work_type_catalog(code_root: Path) -> Dict[str, Dict[str, Any]]:
    """Deprecated compatibility API. HIP derives the complete workType object."""
    return {}


def resolve_work_type(key: str, configured: Mapping[str, Any] | None, catalog: Mapping[str, Mapping[str, Any]] | None) -> Dict[str, Any]:
    """Deprecated compatibility API. Never derive or return a workType payload."""
    return {}


def hydrate_work_types(config: Mapping[str, Any] | None, code_root: Path) -> Dict[str, Any]:
    """Strip legacy workTypes so old configs cannot leak them into requests/templates."""
    output = deepcopy(dict(config or {}))
    output.pop("workTypes", None)
    return output
