from __future__ import annotations

import json
from pathlib import Path

from webapp.backend.app import main
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.storage import JsonStore


def test_api_testing_preview_uses_latest_contract_validation(monkeypatch, tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir()
    record = {
        "id": "cfg",
        "workspace": str(ws),
        "validation": {
            "ok": False,
            "requests": {
                "validCount": 16,
                "total": 18,
                "blockedCount": 2,
                "items": [
                    {"stepKey": "rule", "valid": False, "errors": [{"field": "ruleName", "message": "required"}]},
                    {"stepKey": "map", "valid": True, "errors": []},
                ],
                "blockedItems": [{"stepKey": "rule", "valid": False, "errors": [{"field": "ruleName", "message": "required"}]}],
            },
        },
    }
    monkeypatch.setattr(main.STORE, "get_configuration", lambda cid: record)
    monkeypatch.setattr(main, "preview_api_requests", lambda workspace: {"items": [
        {"stepKey": "rule", "applicable": True, "payload": {"ruleName": ""}},
        {"stepKey": "map", "applicable": True, "payload": {"mapName": "MAP"}},
        {"stepKey": "target_tp", "applicable": False, "payload": {}},
    ]})
    result = main.configuration_api_requests("cfg")
    states = {row["stepKey"]: row["contractStatus"] for row in result["items"]}
    assert states == {"rule": "BLOCKED", "map": "READY", "target_tp": "NOT_APPLICABLE"}
    assert result["contractSummary"]["validCount"] == 16
    assert result["contractSummary"]["blockedCount"] == 2
    assert result["items"][0]["contractValidation"]["errors"][0]["field"] == "ruleName"


def test_parallel_instances_work_for_any_validated_customer(tmp_path: Path):
    ws = tmp_path / "legrand"
    for name in ("payloads", "reports"):
        (ws / name).mkdir(parents=True, exist_ok=True)
    (ws / "input.json").write_text(json.dumps({
        "customer": "LEGRAND",
        "direction": "Inbound",
        "tx_code": "850",
        "flow_type": "translation",
        "profile_name": "LEGRAND_850",
    }), encoding="utf-8")
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    validation = {"ok": True, "requests": {"ok": True, "validCount": 18, "total": 18}}
    rows = manager.create_demo_instances({"id": "cfg", "workspace": str(ws), "customer": "LEGRAND", "name": "Legrand"}, validation, 3)
    assert len(rows) == 3
    assert [row["demoInstance"] for row in rows] == [1, 2, 3]
    assert all("LEGRAND Parallel Instance" in row["label"] for row in rows)
    assert all(row["ready"] if "ready" in row else row["validationOk"] for row in manager.list_queue())
    # Compatibility API instances must reindex exactly like the active React path.
    assert manager.delete_job(rows[1]["jobId"]) is True
    remaining = sorted(manager.list_queue(), key=lambda row: int(row.get("demoInstance") or 0))
    assert [(row["demoInstance"], row["demoInstanceCount"]) for row in remaining] == [(1, 2), (2, 2)]
    assert [row["label"] for row in remaining] == [
        "LEGRAND Parallel Instance 1/2",
        "LEGRAND Parallel Instance 2/2",
    ]


def test_react_has_truthful_contract_states_and_global_activity_feedback():
    root = Path(__file__).resolve().parent
    testing = (root / "webapp/frontend/src/pages/ApiTestingPage.tsx").read_text(encoding="utf-8")
    parallel = (root / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    app = (root / "webapp/frontend/src/App.tsx").read_text(encoding="utf-8")
    client = (root / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    assert "contractStatus" in testing
    assert "selectedStatus!=='READY'" in testing
    assert "Run this API LIVE" in testing
    assert "createParallelInstances" in parallel
    assert "Creating…" in parallel
    assert "hip:api-activity" in client
    assert "global-api-activity" in app
