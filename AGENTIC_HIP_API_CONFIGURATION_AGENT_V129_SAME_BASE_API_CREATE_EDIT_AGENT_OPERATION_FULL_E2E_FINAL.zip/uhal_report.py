from __future__ import annotations

import csv
import datetime as dt
import html
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List

from report_insights import analyze_api_response, reconcile_execution_analyses, format_duration_ms, format_duration_seconds

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def _status(result: Any) -> str:
    return str(analyze_api_response(result).get("verdict") or "WARNING").upper()


def _json_load(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _business_values(runner: Any) -> Dict[str, Any]:
    input_data = getattr(runner, "input", {}) or {}
    ov = getattr(runner, "ov", {}) or {}
    objects = input_data.get("objects") or {}
    source_doc = objects.get("source_document_type") or {}
    target_doc = objects.get("target_document_type") or {}
    data_map = objects.get("data_map") or {}
    rule = objects.get("rule") or {}
    source_tp = objects.get("source_transport_profile") or {}
    target_tp = objects.get("target_transport_profile") or {}
    biz = objects.get("biz_flow") or {}

    return {
        "customer": input_data.get("customer", "U-HAUL"),
        "direction": input_data.get("direction", "Outbound"),
        "flow_name": input_data.get("profile_name", "U-HAUL_PC_856_ANS_MAPPING_OB"),
        "source_system": source_tp.get("partner_name", "AIC - DCE"),
        "target_partner": target_tp.get("partner_name", "dce-test-partner"),
        "source_document_type": source_doc.get("name"),
        "target_document_type": target_doc.get("name"),
        "map_identifier": data_map.get("map_identifier"),
        "map_name": data_map.get("map_name"),
        "rule_name": rule.get("name"),
        "source_tp_create_name": source_tp.get("profile_name"),
        "target_tp_create_name": target_tp.get("profile_name"),
        "source_tp_flow_name": ov.get("source_transport_profile_name", "da-sender-sftphaft-dce-common"),
        "target_tp_flow_name": ov.get("target_transport_profile_name", "pt-receiver-sftphaft-dce-common"),
        "source_account": ov.get("source_haft_account", "haftatap10251594"),
        "target_account": ov.get("target_haft_account", "haftatap10251593"),
        "deployment_group": ov.get("source_deployment_group_name", "hip-automation"),
        "receiver_condition": "Receiver Equals uhaul",
        "sender_condition": "Sender Contains DELL",
    }


def write_final_business_report(results: List[Any], runner: Any) -> Path:
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    html_path = REPORTS / f"UHAL_final_end_to_end_report_{ts}.html"
    json_path = REPORTS / f"UHAL_final_end_to_end_report_{ts}.json"
    csv_path = REPORTS / f"UHAL_final_end_to_end_status_{ts}.csv"
    teams_path = REPORTS / f"UHAL_final_teams_update_{ts}.txt"

    values = _business_values(runner)
    rows = []
    raw_rows = [asdict(r) for r in results]
    reconciled = reconcile_execution_analyses(raw_rows)
    for d, analysis in zip(raw_rows, reconciled):
        d["agent_analysis"] = analysis
        d["agent_verdict"] = str(analysis.get("verdict") or "WARNING").upper()
        d["agent_reason"] = str(analysis.get("reason") or "")
        d["agent_next_action"] = str(analysis.get("nextAction") or "")
        d["final_status"] = d["agent_verdict"]
        rows.append(d)

    counts: Dict[str, int] = {key: 0 for key in ("PASS", "WARNING", "FAIL", "BLOCKED", "SKIPPED")}
    for row in rows:
        counts[row["final_status"]] = counts.get(row["final_status"], 0) + 1
    overall_verdict = "FAIL" if counts.get("FAIL") else ("BLOCKED" if counts.get("BLOCKED") else ("WARNING" if counts.get("WARNING") else "PASS"))
    total_api_seconds = sum(float(row.get("elapsed_ms") or 0) for row in rows) / 1000.0
    timing_events = list(getattr(runner, "execution_timing_events", []) or [])
    total_execution_seconds = sum(float(item.get("totalStepSeconds") or 0) for item in timing_events) or total_api_seconds

    dependencies = [
        ("1", "Preflight", "Input files and credentials", "None"),
        ("2", "Validate TP interfaces and flow name", "Preflight", "Validation evidence"),
        ("3", "Accounts, Partner, System", "Preflight", "Foundation objects"),
        ("4", "Source and Target Document Types", "Preflight", "Document names and source numeric ID"),
        ("5", "MAC Map", "Document Types", "Map ID / map identifier"),
        ("6", "Mapping Rule", "Source Document Type + Map", "Rule ID / rule name"),
        ("7", "Source and Target TP Orchestration", "System/Partner + Accounts + Document Types", "Resolved TP names"),
        ("8", "Flow Orchestration Create", "Document Types + Map + Rule + both TPs", "Flow version / work order"),
        ("9", "Flow Orchestration Deploy", "Flow Create", "Deployment status"),
        ("10", "Flow and TP audits/history", "Create/deploy attempts", "Final verification"),
    ]

    dev_inputs = [
        ("Shared HIP OAuth", "HIP_TOKEN_URL, HIP_CLIENT_ID, HIP_CLIENT_SECRET, optional HIP_SCOPE", "One token is reused for all HIP APIs including MAC Map"),
        ("Workflow OAuth", "WORKFLOW_TOKEN_URL, WORKFLOW_CLIENT_ID, WORKFLOW_CLIENT_SECRET", "Only if direct workflow chain is enabled"),
        ("Requester header", getattr(runner, "requester", ""), "x-requester-id"),
        ("Partner account header", values["source_account"], "x-account-name"),
    ]

    credential_status = [
        (
            "HIP Config OAuth",
            "CONFIGURED" if (
                getattr(runner, "hip_token_url", None)
                and getattr(runner, "hip_client_id", None)
                and getattr(runner, "hip_client_secret", None)
            ) else "MISSING",
            "Used for Config Service APIs and shared with MAC Map; secret values are never printed.",
        ),
        (
            "MAC Map OAuth",
            "SHARED",
            "Reuses HIP Config OAuth; no separate MAC Map credential.",
        ),
        (
            "Account OAuth",
            "NOT REQUIRED" if (
                runner.execution_plan.is_skipped("account_source")
                and runner.execution_plan.is_skipped("account_target")
            ) else (
                "CONFIGURED" if runner.account_client_id and runner.account_client_secret else "MISSING"
            ),
            "Dedicated Account credential when Account API executes.",
        ),
        (
            "Partner OAuth",
            "NOT REQUIRED" if runner.execution_plan.is_skipped("partner_target") else (
                "CONFIGURED" if runner.partner_client_id and runner.partner_client_secret else "MISSING"
            ),
            "Dedicated Partner credential when Partner API executes.",
        ),
        (
            "System OAuth",
            "NOT REQUIRED" if runner.execution_plan.is_skipped("system_source") else (
                "CONFIGURED" if runner.system_client_id and runner.system_client_secret else "MISSING"
            ),
            "Dedicated System credential when System API executes.",
        ),
        (
            "Dell AIA",
            "CONFIGURED" if runner.judge.available() else "MISSING",
            f"Model: {runner.judge.model}; Base URL: {runner.judge.base_url}",
        ),
    ]

    document_type_contract = [
        (
            "version",
            "String, for example 1.0",
            "Matches the Dev-team POST payload even though the generic schema displayed a numeric example.",
        ),
        (
            "statusDisabled",
            "Boolean",
            "Included in the Dev-team payload.",
        ),
        (
            "documentIdentifier",
            "operator + attributeList",
            "Each identifier item uses derivedFrom and optional expression/value.",
        ),
        (
            "lastModifiedBy",
            "Empty string",
            "Explicitly included in the Dev-team payload.",
        ),
        (
            "filemask",
            "Omitted",
            "Not present in the Dev-team POST example.",
        ),
        (
            "ediDelimiters",
            "Omitted for XML",
            "Not present in the Dev-team POST example and not needed for this XML flow.",
        ),
        (
            "transactionType",
            "INBOUND / OUTBOUND",
            "This is the API direction enum, not the X12 transaction code 856.",
        ),
    ]

    source_to_payload = [
        ("input.json", "Customer, direction, document types, map, rule, TP folders, conditions and flow metadata"),
        ("config_overrides.json", "IDs, work types, deployment group, account names and v3 contract switches"),
        ("input_files/*.jar", "MAC Map mapData encoded as Base64"),
        ("input_files/*.xbm", "crossReferenceMapList when enabled"),
        ("input_files/*.xml", "Map input/output schemas and U-HAUL examples"),
        ("Test.py / environment", "OAuth client credentials and token URLs; never written to reports"),
    ]

    pdf_documents = (
        runner.pdf_kb.list_documents()
        if hasattr(runner, "pdf_kb")
        else []
    )
    pdf_contracts = (
        runner.pdf_kb.load_pdf_contracts()
        if hasattr(runner, "pdf_kb")
        else {}
    )
    contract_validation_rows = []
    for row in rows:
        validation = (
            (row.get("extracted") or {})
            .get("contractValidation")
        )
        if not validation:
            continue
        deterministic = validation.get("deterministic") or {}
        aia_validation = (
            validation.get("dellAiaPdfValidation") or {}
        )
        contract_validation_rows.append({
            "sequence": row.get("sequence"),
            "api": f"{row.get('group')} - {row.get('api')}",
            "valid": validation.get("valid"),
            "deterministicErrors": len(
                deterministic.get("errors") or []
            ),
            "pdfAiaPerformed": aia_validation.get(
                "performed", False
            ),
            "pdfAiaValid": aia_validation.get("valid", True),
            "warnings": (
                (deterministic.get("warnings") or [])
                + (aia_validation.get("warnings") or [])
            ),
        })

    mcp_status = (
        runner.mcp.status()
        if hasattr(runner, "mcp")
        else {"enabled": False, "active": False}
    )
    mcp_input_validation = (
        getattr(runner, "mcp_input_validation", {}) or {}
    )
    mcp_validation_rows = []
    for row in rows:
        validation = (
            (row.get("extracted") or {})
            .get("contractValidation")
            or {}
        )
        mcp_validation = validation.get("mcpToolValidation") or {}
        if not mcp_validation:
            continue
        mcp_validation_rows.append({
            "sequence": row.get("sequence"),
            "api": f"{row.get('group')} - {row.get('api')}",
            "valid": mcp_validation.get("valid", True),
            "mcpUsed": mcp_validation.get("mcpUsed", False),
            "transport": mcp_validation.get("mcpTransport"),
            "errors": mcp_validation.get("errors") or [],
            "warnings": (
                mcp_validation.get("warnings") or []
            ) + ([mcp_validation.get("warning")]
                 if mcp_validation.get("warning") else []),
        })

    mapping_manifest = (
        runner.mapper.execution_manifest()
        if hasattr(runner, "mapper")
        else {}
    )
    end_to_end_state = getattr(runner, "final_state", {}) or {}
    live_api_evidence = _json_load(ROOT / "reports" / "live_api_evidence_manifest_latest.json", {})
    mapping_lineage_rows = []
    for api_key, fields in (mapping_manifest.get("lineage") or {}).items():
        for item in fields:
            mapping_lineage_rows.append({
                "api": api_key,
                "payloadField": item.get("payloadField"),
                "inputPath": item.get("inputPath"),
                "value": item.get("value"),
            })

    adaptive_status = (
        runner.adaptive.status()
        if hasattr(runner, "adaptive")
        else {}
    )
    adaptive_analysis_path = ROOT / "reports" / "adaptive_input_analysis_latest.json"
    adaptive_analysis = _json_load(adaptive_analysis_path, {}) if adaptive_analysis_path.exists() else {}
    change_proposal_path = ROOT / "reports" / "change_proposal_latest.json"
    change_proposal = _json_load(change_proposal_path, {}) if change_proposal_path.exists() else {}
    react_interface_path = ROOT / "reports" / "react_interface_latest.json"
    react_interface = _json_load(react_interface_path, {}) if react_interface_path.exists() else {}

    report_data = {
        "generated_at": dt.datetime.now().isoformat(),
        "summary": counts,
        "agent_summary": {
            "overallVerdict": overall_verdict,
            "counts": counts,
            "totalApiTime": format_duration_seconds(total_api_seconds),
            "totalExecutionTime": format_duration_seconds(total_execution_seconds),
            "reason": (
                "All final API responses were interpreted as successful." if overall_verdict == "PASS" else
                "The LIVE run completed. One or more prerequisite objects were already present/reused or otherwise need verification; no terminal failure was proven." if overall_verdict == "WARNING" else
                "One or more final API responses failed or the run was blocked."
            ),
        },
        "business_values": values,
        "dependency_sequence": dependencies,
        "dev_inputs": dev_inputs,
        "source_to_payload": source_to_payload,
        "credential_status": credential_status,
        "document_type_contract": document_type_contract,
        "pdf_documents": pdf_documents,
        "pdf_contracts": pdf_contracts,
        "contract_validation": contract_validation_rows,
        "mcp_status": mcp_status,
        "mcp_input_validation": mcp_input_validation,
        "mcp_request_validation": mcp_validation_rows,
        "mapping_manifest": mapping_manifest,
        "mapping_lineage": mapping_lineage_rows,
        "end_to_end_state": end_to_end_state,
        "live_api_evidence": live_api_evidence,
        "api_execution_plan": (
            runner.execution_plan.summary()
            if hasattr(runner, "execution_plan")
            else {}
        ),
        "payload_overrides": (
            runner.payload_overrides.summary()
            if hasattr(runner, "payload_overrides")
            else {}
        ),
        "execution_flow": (
            runner.execution_flow.summary()
            if hasattr(runner, "execution_flow")
            else {}
        ),
        "execution_timing": getattr(runner, "execution_timing_events", []),
        "adaptive_status": adaptive_status,
        "adaptive_input_analysis": adaptive_analysis,
        "latest_change_proposal": change_proposal,
        "react_interface_agent": react_interface,
        "results": rows,
    }
    json_path.write_text(json.dumps(report_data, indent=2, default=str), encoding="utf-8")

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        fields = [
            "sequence", "group", "api", "attempt", "method", "url",
            "status_code", "classification", "business_success",
            "final_status", "agent_verdict", "agent_reason", "agent_next_action",
            "elapsed_ms", "payload_file", "request_preview", "response_preview", "error",
            "issue", "action_required",
        ]
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    def table(headers: List[str], table_rows: Iterable[Iterable[Any]]) -> str:
        body = ""
        for row in table_rows:
            body += "<tr>" + "".join(
                f"<td>{html.escape(str(v if v is not None else ''))}</td>"
                for v in row
            ) + "</tr>"
        return (
            "<table><thead><tr>"
            + "".join(f"<th>{html.escape(h)}</th>" for h in headers)
            + "</tr></thead><tbody>"
            + body
            + "</tbody></table>"
        )

    def short_text(value: Any, limit: int = 220) -> str:
        text = " ".join(str(value or "").split())
        return text if len(text) <= limit else text[: limit - 1] + "…"

    attention_rows = []
    result_rows = []
    evidence_cards = []
    for row in rows:
        analysis = row.get("agent_analysis") or {}
        verdict = str(analysis.get("verdict") or row.get("final_status") or "WARNING").upper()
        reason = str(analysis.get("reason") or row.get("issue") or "No explanation available.")
        next_action = str(analysis.get("nextAction") or row.get("action_required") or "No action required.")
        if verdict in {"WARNING", "FAIL", "BLOCKED"}:
            attention_rows.append(
                f"<div class='attention-item'><b>#{html.escape(str(row.get('sequence')))} {html.escape(str(row.get('api')))} "
                f"<span class='badge {verdict}'>{html.escape(verdict)}</span></b>"
                f"<p>{html.escape(short_text(reason, 300))}</p><p><b>Next:</b> {html.escape(short_text(next_action, 260))}</p></div>"
            )
        result_rows.append(f"""
<tr>
<td>{html.escape(str(row.get('sequence') or ''))}</td>
<td><b>{html.escape(str(row.get('group') or ''))} — {html.escape(str(row.get('api') or ''))}</b><small>{html.escape(str(row.get('attempt') or ''))}</small></td>
<td>{html.escape(str(row.get('status_code') if row.get('status_code') is not None else '—'))}</td>
<td><span class="badge {html.escape(verdict)}">{html.escape(verdict)}</span><small>{html.escape(str(analysis.get('outcome') or ''))}</small></td>
<td>{html.escape(format_duration_ms(row.get('elapsed_ms') or 0))}</td>
<td class="reason">{html.escape(short_text(reason, 360))}</td>
<td><details><summary>Evidence</summary><p><b>Next action:</b> {html.escape(next_action)}</p><p><code>{html.escape(str(row.get('method') or ''))} {html.escape(str(row.get('url') or ''))}</code></p><details><summary>Full request payload</summary><p><code>{html.escape(str(row.get('payload_file') or ''))}</code></p><pre>{html.escape(str(row.get('request_preview') or ''))}</pre></details><details><summary>Full response / error</summary><pre>{html.escape(str(row.get('response_preview') or row.get('error') or ''))}</pre></details><details><summary>Extracted IDs / metadata</summary><pre>{html.escape(json.dumps(row.get('extracted') or {}, indent=2, default=str))}</pre></details></details></td>
</tr>""")

    flow_text = f"""
{values.get('customer') or 'Customer'} · {values.get('direction') or ''}
{values['source_system']} → {values['source_tp_flow_name']} → {values['source_document_type']}
→ {values['rule_name']} / {values['map_identifier']} → {values['target_document_type']}
→ {values['target_tp_flow_name']} → {values['target_partner']}
"""

    css = """
:root{--navy:#071f3d;--blue:#0b5cab;--green:#138a4b;--red:#b42318;--amber:#9a6508;--ink:#162033;--muted:#667085;--line:#d8e2ee;--bg:#f4f7fb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif;line-height:1.45}.hero{padding:28px 34px;background:linear-gradient(135deg,#061a35,#075aa3);color:#fff}.hero h1{margin:0;font-size:28px}.hero p{margin:6px 0;color:#dcecff}.wrap{padding:20px 32px 50px;max-width:1450px;margin:auto}.metrics{display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:10px;margin-top:-34px}.metric,.panel{background:rgba(255,255,255,.88);border:1px solid rgba(216,226,238,.9);border-radius:14px;box-shadow:0 10px 28px rgba(16,35,60,.07);backdrop-filter:blur(16px) saturate(1.08);-webkit-backdrop-filter:blur(16px) saturate(1.08)}.metric{padding:14px}.metric .n{font-size:23px;font-weight:850}.metric .l{text-transform:uppercase;font-size:9px;letter-spacing:.07em;color:var(--muted)}.panel{padding:16px;margin:14px 0}.panel h2{margin:0 0 8px;font-size:17px}.verdict-panel{border-left:6px solid var(--green);background:rgba(246,255,251,.9)!important;color:#16382c}.verdict-panel p{color:#34594a}.verdict-panel.WARNING{background:rgba(255,250,235,.92)!important;color:#4f3b12}.verdict-panel.WARNING p{color:#6c5727}.verdict-panel.FAIL,.verdict-panel.BLOCKED{background:rgba(255,244,243,.92)!important;color:#5c211d}.verdict-panel.FAIL p,.verdict-panel.BLOCKED p{color:#79403b}.verdict-panel.WARNING{border-left-color:var(--amber)}.verdict-panel.FAIL,.verdict-panel.BLOCKED{border-left-color:var(--red)}.badge{display:inline-block;color:#fff;border-radius:999px;padding:5px 9px;font-size:10px;font-weight:850}.PASS{background:var(--green)}.WARNING{background:var(--amber)}.FAIL,.BLOCKED{background:var(--red)}.SKIPPED{background:#687d8e}.flow{background:#eef6fc;color:#21435f;border-radius:10px;padding:12px;font:11px/1.55 Consolas,monospace;white-space:pre-wrap}.attention-list{display:grid;gap:8px}.attention-item{border:1px solid #ead9aa;border-radius:11px;padding:10px;background:#fffdf5}.attention-item p{margin:4px 0;font-size:11px;color:#506476}table{width:100%;border-collapse:separate;border-spacing:0;background:#fff;border:1px solid var(--line);border-radius:12px;overflow:hidden}th,td{border-bottom:1px solid #e8eef3;padding:9px;text-align:left;vertical-align:top;font-size:10.5px}th{background:#eaf2f8;text-transform:uppercase;font-size:8.5px;color:#607486;letter-spacing:.04em}tr:last-child td{border-bottom:0}td small{display:block;color:var(--muted);margin-top:3px}.reason{max-width:420px;color:#40576a}details{margin:5px 0}summary{cursor:pointer;color:var(--blue);font-weight:800}pre{white-space:pre-wrap;word-break:break-word;background:#091525;color:#dbeafe;border-radius:10px;padding:12px;font-size:10px;max-height:440px;overflow:auto}.technical>summary{font-size:12px;padding:7px 0}.technical-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.technical-box{border:1px solid var(--line);border-radius:10px;padding:10px;background:#f9fbfd}.technical-box h3{font-size:11px;margin:0 0 6px}.muted{color:var(--muted);font-size:10px}@media(max-width:900px){.wrap{padding:16px}.hero{padding:24px 18px}.metrics{grid-template-columns:repeat(2,1fr);margin-top:-20px}.technical-grid{grid-template-columns:1fr}table{display:block;overflow:auto}}
"""

    metric_values = [
        ("Steps", len(rows)), ("Pass", counts.get("PASS", 0)), ("Warning", counts.get("WARNING", 0)),
        ("Fail", counts.get("FAIL", 0)), ("Blocked", counts.get("BLOCKED", 0)), ("Elapsed", format_duration_seconds(total_execution_seconds)),
    ]
    metric_html = "".join(f"<div class='metric'><div class='n'>{html.escape(str(n))}</div><div class='l'>{html.escape(label)}</div></div>" for label, n in metric_values)
    overall_reason = (
        "All final API responses were interpreted as successful." if overall_verdict == "PASS" else
        "The LIVE run completed with reusable existing objects and/or review-only warnings. Verify the referenced objects, but this is not a terminal execution failure." if overall_verdict == "WARNING" else
        "One or more final responses failed or the run was blocked; review the attention items before retrying."
    )

    html_doc = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(str(values.get('customer') or 'Customer'))} HIP Final Report</title><style>{css}</style></head><body>
<header class="hero"><small>Agentic HIP API Configuration Agent · Final LIVE Report</small><h1>{html.escape(str(values.get('customer') or 'Customer'))} · {html.escape(str(values.get('direction') or ''))}</h1><p>Agent-read response verdicts with compact business summary. Complete requests/responses remain available as expandable audit evidence.</p><p>Generated {html.escape(dt.datetime.now().isoformat())}</p></header>
<main class="wrap"><section class="metrics">{metric_html}</section>
<section class="panel verdict-panel {html.escape(overall_verdict)}"><h2>Agent final verdict · <span class="badge {html.escape(overall_verdict)}">{html.escape(overall_verdict)}</span></h2><p>{html.escape(overall_reason)}</p><p class="muted">Verdict uses HTTP status, final response body, runner business classification and the available Dell AIA/owner diagnosis. A 2xx response alone is not automatically PASS.</p></section>
{(f'<section class="panel"><h2>Needs attention</h2><div class="attention-list">{"".join(attention_rows)}</div></section>' if attention_rows else '')}
<section class="panel"><h2>Strict LIVE API coverage</h2><p><b>{html.escape(str(live_api_evidence.get('calledApplicableApiCount', 0)))}/{html.escape(str(live_api_evidence.get('expectedApplicableApiCount', 0)))}</b> applicable APIs returned live HTTP evidence. Coverage complete: <b>{html.escape(str(live_api_evidence.get('coverageComplete', False)))}</b>.</p><p class="muted">No existing-object API is accepted from a skip assumption in strict mode. Request and response evidence files are recorded per attempt.</p></section>
<section class="panel"><h2>Business flow</h2><div class="flow">{html.escape(flow_text)}</div></section>
<section class="panel"><h2>API result summary</h2><table><thead><tr><th>#</th><th>API</th><th>HTTP</th><th>Agent verdict</th><th>Time</th><th>Agent conclusion</th><th>Audit evidence</th></tr></thead><tbody>{''.join(result_rows)}</tbody></table></section>
<details class="panel technical"><summary>Technical appendix · validation, mappings, execution plan and runtime evidence</summary><div class="technical-grid">
<div class="technical-box"><h3>End-to-end state</h3><pre>{html.escape(json.dumps(end_to_end_state, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>LIVE API evidence manifest</h3><pre>{html.escape(json.dumps(live_api_evidence, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>API execution plan</h3><pre>{html.escape(json.dumps(runner.execution_plan.summary() if hasattr(runner, 'execution_plan') else {}, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>Payload overrides</h3><pre>{html.escape(json.dumps(runner.payload_overrides.summary() if hasattr(runner, 'payload_overrides') else {}, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>Execution flow</h3><pre>{html.escape(json.dumps(runner.execution_flow.summary() if hasattr(runner, 'execution_flow') else {}, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>Contract validation</h3><pre>{html.escape(json.dumps(contract_validation_rows, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>MCP validation</h3><pre>{html.escape(json.dumps(mcp_validation_rows, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>Mapping lineage</h3><pre>{html.escape(json.dumps(mapping_lineage_rows, indent=2, default=str))}</pre></div>
<div class="technical-box"><h3>Credential readiness</h3>{table(['Area','Status','Details'], credential_status)}</div>
</div></details>
</main></body></html>"""
    html_path.write_text(html_doc, encoding="utf-8")

    teams = [
        "U-HAUL HIP End-to-End Run\n",
        f"Generated: {dt.datetime.now().isoformat()}\n",
        f"Total steps: {len(rows)}\n",
    ]
    for key in ("PASS", "WARNING", "FAIL", "BLOCKED", "SKIPPED"):
        teams.append(f"{key}: {counts.get(key, 0)}\n")
    teams.append("\nBusiness flow:\n")
    teams.append(
        f"{values['source_system']} → {values['source_tp_flow_name']} → "
        f"{values['source_document_type']} → {values['rule_name']} / "
        f"{values['map_identifier']} → {values['target_document_type']} → "
        f"{values['target_tp_flow_name']} → {values['target_partner']}\n"
    )
    teams.append(f"\nAgent final verdict: {overall_verdict}\n")
    if counts.get("FAIL") or counts.get("BLOCKED") or counts.get("WARNING"):
        teams.append("Attention items:\n")
        for row in rows:
            if row.get("final_status") in {"WARNING", "FAIL", "BLOCKED"}:
                teams.append(f"- #{row.get('sequence')} {row.get('api')}: {(row.get('agent_analysis') or {}).get('reason')}\n")
    else:
        teams.append("All final API responses were interpreted as successful.\n")
    teams_path.write_text("".join(teams), encoding="utf-8")

    return html_path
