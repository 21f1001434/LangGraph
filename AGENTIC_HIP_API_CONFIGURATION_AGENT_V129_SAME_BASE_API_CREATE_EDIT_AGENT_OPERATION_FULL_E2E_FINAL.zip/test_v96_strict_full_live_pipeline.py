from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import run_agent
from business_demo import prepare_uhal_business_demo

ROOT = Path(__file__).resolve().parent


def _ok_result(seq, group, api, attempt, method, url_key, token_kind="HIP"):
    extracted = {}
    if api == "Create source document type":
        extracted["documentTypeId"] = 92001
    elif api == "Create target document type":
        extracted["documentTypeId"] = 92002
    elif api == "Create/resolve MAC Map":
        extracted["mapId"] = 1670
    elif api == "Create mapping rule":
        extracted["ruleId"] = 33001
    elif api == "Flow orchestration create ONLY":
        extracted.update({"flowId": 44001, "flowVersion": "1.0"})
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}",
        token_kind, "", 200, "PASS_SUCCESS", True, 1,
        "", "{}", '{"success":true}', extracted, "WORKING", "", "WORKING", "", "",
    )


def test_v96_react_live_backend_forces_strict_whole_pipeline():
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    ui = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    assert 'HIP_STRICT_LIVE_PIPELINE="1"' in manager
    assert 'HIP_LIVE_API_EXECUTION="1"' in manager
    assert 'HIP_LIVE_AUTO_COMPLETE="1"' in manager
    assert 'HIP_FULL_API_COVERAGE_MODE="0"' in manager
    assert "strict whole pipeline" in ui.lower()
    assert "Every applicable HIP API must return live HTTP evidence" in ui


def test_v96_strict_mode_ignores_persisted_skip_plan_and_calls_all_18(monkeypatch):
    prepare_uhal_business_demo(ROOT)
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "2")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    monkeypatch.setattr(runner.execution_plan, "is_skipped", lambda _key: True)
    calls = []

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        calls.append(api)
        return _ok_result(seq, group, api, attempt, method, url_key, str(kwargs.get("token_kind") or "HIP"))

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None):
        results = runner.run()

    logical_http = {
        str((r.extracted or {}).get("logicalStepKey") or "")
        for r in results if r.status_code is not None
    }
    assert runner.strict_live_pipeline_mode is True
    assert runner.full_api_coverage_mode is False
    assert len(logical_http) == 18, logical_http
    assert len(calls) == 18, calls
    assert not [r for r in results if r.classification == "SKIPPED_BY_USER_EXISTING_OBJECT"]
    assert runner.final_state["coverageComplete"] is True
    assert runner.final_state["success"] is True
    assert runner.final_state["coverageMissingSteps"] == []
    assert runner.final_state["strictNonPassingLiveSteps"] == []


def test_v96_strict_mode_repairs_missing_dependency_then_captures_all_18(monkeypatch):
    prepare_uhal_business_demo(ROOT)
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "3")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "3")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    calls = {}

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        calls[api] = calls.get(api, 0) + 1
        if api == "Create source account" and calls[api] == 1:
            return run_agent.Result(
                seq, group, api, attempt, method, f"https://mock/{url_key}",
                str(kwargs.get("token_kind") or "HIP"), "", None,
                "EXECUTION_ERROR", False, None, "", "{}", "", {},
                "API_BACKEND_OR_ERROR_HANDLING", "", "API_BACKEND_OR_ERROR_HANDLING",
                "temporary OAuth/network failure", "retry", "temporary OAuth/network failure",
            )
        return _ok_result(seq, group, api, attempt, method, url_key, str(kwargs.get("token_kind") or "HIP"))

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None):
        results = runner.run()

    logical_http = {
        str((r.extracted or {}).get("logicalStepKey") or "")
        for r in results if r.status_code is not None
    }
    assert calls["Create source account"] >= 2
    assert len(logical_http) == 18, logical_http
    assert runner.final_state["coverageComplete"] is True
    assert runner.final_state["unresolvedRequiredSteps"] == []
    assert runner.final_state["strictNonPassingLiveSteps"] == []
    assert runner.final_state["success"] is True
    assert runner.final_state["autoCompletionRounds"]


def test_v96_live_response_evidence_is_persisted(monkeypatch, tmp_path):
    evidence = run_agent.save_response_evidence(
        7, "Validation", "Validate flow name", "live",
        method="POST", url="https://example.test/validate", status_code=200,
        elapsed_ms=12, classification="PASS_SUCCESS", business_success=True,
        response={"valid": True},
    )
    assert evidence
    path = ROOT / evidence
    assert path.exists()
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["httpStatus"] == 200
    assert payload["businessSuccess"] is True
    assert payload["response"] == {"valid": True}
    path.unlink(missing_ok=True)


def test_v96_build_id():
    assert "strict" in run_agent.BUILD_ID and "live" in run_agent.BUILD_ID
