from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_windows_runtime_defaults_to_local_appdata(tmp_path: Path):
    from webapp.backend.app.runtime_paths import resolve_runtime_root

    local = tmp_path / "LocalAppData"
    resolved = resolve_runtime_root(
        ROOT,
        environ={"LOCALAPPDATA": str(local)},
        platform_name="windows",
        temp_root=tmp_path / "temp",
    )
    assert resolved == (local / "HIP API Agent Studio" / "runtime-v82").resolve()
    assert ROOT not in resolved.parents


def test_explicit_runtime_override_is_supported(tmp_path: Path):
    from webapp.backend.app.runtime_paths import resolve_runtime_root

    explicit = tmp_path / "runtime-override"
    resolved = resolve_runtime_root(
        ROOT,
        environ={"HIP_STUDIO_RUNTIME_ROOT": str(explicit)},
        platform_name="windows",
        temp_root=tmp_path / "temp",
    )
    assert resolved == explicit.resolve()


def test_backend_materializes_approved_uhal_in_writable_runtime(tmp_path: Path):
    runtime = tmp_path / "runtime"
    code = r'''
from pathlib import Path
from fastapi.testclient import TestClient
from webapp.backend.app.main import app, RUNTIME_ROOT
c = TestClient(app)
rows = c.get('/api/configurations').json()
uhal = next(row for row in rows if row.get('approved_reference'))
assert uhal['status'] == 'DEV_APPROVED'
assert uhal['validation']['requests']['validCount'] == 18
assert Path(uhal['workspace']).is_relative_to(Path(RUNTIME_ROOT))
assert (Path(uhal['workspace']) / 'input_files').is_dir()
ref = next(row for row in c.get('/api/parallel/sources').json() if row.get('sourceId') == 'reference:uhal')
assert ref['validated'] is True
assert ref['status'] == 'DEV_APPROVED'
assert ref['validCount'] == 18 and ref['totalContracts'] == 18
assert not ref.get('error')
'''
    env = dict(os.environ)
    env["HIP_STUDIO_RUNTIME_ROOT"] = str(runtime)
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), str(ROOT / "webapp" / "backend"), env.get("PYTHONPATH", "")])
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, text=True, capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr


def test_global_customer_control_is_a_real_dropdown():
    source = (ROOT / "webapp" / "frontend" / "src" / "components" / "AppTopbar.tsx").read_text(encoding="utf-8")
    assert 'id="global-active-customer"' in source
    assert "configs.map" in source
    assert "onSelectCustomer(next)" in source
    assert "DEV APPROVED" in source


def test_app_defaults_to_approved_uhal_and_passes_global_selector_data():
    source = (ROOT / "webapp" / "frontend" / "src" / "App.tsx").read_text(encoding="utf-8")
    assert "c.find(x=>x.approved_reference||x.managed_reference_source==='reference:uhal')" in source
    assert "configs={configs}" in source
    assert "onSelectCustomer={updateActive}" in source


def test_approved_reference_load_error_is_not_sent_to_guided_business_fix_modal():
    source = (ROOT / "webapp" / "frontend" / "src" / "pages" / "ParallelPage.tsx").read_text(encoding="utf-8")
    assert "source?.approvedReference&&!source.validated" in source
    assert "setRepairSource(source)" in source  # editable customer path still exists
    assert "RELOAD REQUIRED" in source
