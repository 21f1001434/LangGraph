# V67 - Flow Game Animated Connections

- Keeps every API Flow Game connection directional with arrowheads.
- Adds clearly visible travelling dash animation to idle/ready connections.
- Speeds up and glows the connection while either connected block is RUNNING/AWAITING_APPROVAL/RESUMED.
- Completed/reused paths stay animated in green; blocked paths stop and turn red.
- Animation is visual only and does not alter execution ordering, mappings, validation, dragging, zoom, or payloads.
- Respects `prefers-reduced-motion` accessibility settings.
