# V126 — Human-controlled Migration API trigger and execution flow

## What changed

V126 makes LIVE execution planning an explicit human-controlled configuration. The seven published Migration logical blocks remain visible/editable at all times, but Migration is **OFF by default** and is executed only when the human turns it ON and saves the execution plan. A populated `targetEnvironment` is payload data and does not grant execution consent.

The human can reorder all 25 registered blocks (18 base + 7 Migration). The backend rejects a saved order that violates a hard dependency. After a human saves or resets the plan, the displayed order becomes the authoritative `EXACT_SEQUENTIAL` order used by LIVE execution. The internal dependency-ready API parallel scheduler is disabled for a saved human plan; customer-level parallel configurations remain independent.

## Governance

- Agent/AutoGen/Dell-AIA: inspect, explain, recommend and validate only.
- Human user: may toggle Migration and save/reset the order.
- Required human action header: `X-HIP-User-Action: execution-flow-edit-v1`.
- API method, endpoint, protected headers and payload structure remain governed by the existing contract.
- Migration OFF: base APIs execute; Migration blocks stay visible/editable but are excluded from LIVE.
- Migration ON: applicable Migration blocks must pass preflight before LIVE starts.

## Persistence

`execution_flow.json` is preserved across configuration clone, export and import. Saving/resetting the plan revalidates the configuration and refreshes matching queued/not-yet-running parallel job snapshots. Running/completed jobs are not mutated.

## UI

Build Configuration includes **STEP 5 · HUMAN EXECUTION CONTROL** with:

- Migration ON/OFF toggle
- all 25 registered API blocks
- move up/down controls
- per-step wait-after seconds
- dependency display
- Reset safe default
- Save execution plan + revalidate

## Startup behavior retained

The V125 Patch 1 startup fix remains included. `RUN_AGENTIC_HIP.bat`/PowerShell build the React frontend when `dist/index.html` is missing. A manually started backend without a compiled frontend returns a diagnostic root page headed **Frontend not built yet** instead of `{"detail":"Not Found"}`.
