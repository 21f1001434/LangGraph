from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_build_configuration_has_universal_api_value_editor():
    source = (ROOT / 'webapp/frontend/src/pages/BuilderPage.tsx').read_text(encoding='utf-8')
    assert 'Edit values for any HIP API' in source
    assert 'API to edit' in source
    assert 'Attribute to change' in source
    assert 'Locked attribute path' in source
    assert 'New human-entered value' in source
    assert 'Save selected value + revalidate' in source
    assert 'Restore selected value' in source
    assert 'Restore all values for this API' in source
    assert 'catalog.map' in source
    assert 'all_api_catalog' in source
    assert "api.savePayloadOverride(active.id,stepKey,edited,requestKind,'paths')" in source


def test_builder_editor_exposes_field_and_structure_locked_whole_payload_value_views():
    source = (ROOT / 'webapp/frontend/src/pages/BuilderPage.tsx').read_text(encoding='utf-8')
    backend = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    assert 'Attribute to change' in source
    assert 'The attribute name/path itself is locked.' in source
    assert 'Whole payload' in source
    assert 'payload-json-editor' in source
    assert 'Save whole payload + revalidate' in source
    assert 'writePayloadPath(effective,fieldPath,parsedDraft())' in source
    assert '_exact_same_structure(generated, edited)' in backend
    assert 'CANONICAL_PAYLOAD_STRUCTURE_LOCK' in backend


def test_human_only_policy_is_visible_and_api_client_marks_explicit_user_action():
    builder = (ROOT / 'webapp/frontend/src/pages/BuilderPage.tsx').read_text(encoding='utf-8')
    client = (ROOT / 'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    assert 'VALUE ONLY · HUMAN USER' in builder
    assert 'AI/AutoGen/Dell-AIA agent has no save/edit authority' in builder
    assert "'X-HIP-User-Action':'payload-value-edit-v1'" in client
    assert "'X-HIP-Actor':'Human User'" in client
    assert 'Human user-edited existing API value (value-only editor)' in client


def test_builder_validation_wording_does_not_claim_agent_saved_user_value():
    source = (ROOT / 'webapp/frontend/src/pages/BuilderPage.tsx').read_text(encoding='utf-8')
    modal = (ROOT / 'webapp/frontend/src/components/ConfigurationFixModal.tsx').read_text(encoding='utf-8')
    assert 'Your human-entered correction was saved and the agent revalidated' in source
    assert 'Your explicit human action saves it; the agent only re-checks' in modal
    assert 'The agent will save it' not in modal


def test_v118_build_identity():
    source = (ROOT / 'run_agent.py').read_text(encoding='utf-8')
    assert any(tag in source for tag in ('v118-build-configuration-universal-human-payload-value-editor', 'v119-universal-human-value-editor', 'v120-dev-approved-as2-interface-schema-universal-human-payload-value-editor', 'v121-dev-approved-as2-receiver-ssl-certificate-required-universal-human-payload-value-editor', 'v122-nas-rabbitmq-migration-apis-dev-supplied-universal-human-payload-value-editor'))
    assert 'structure-locked-agent-read-only' in source
