from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_builder_has_explicit_create_clone_edit_modes_and_edit_confirmation():
    source = (ROOT / "webapp" / "frontend" / "src" / "pages" / "BuilderPage.tsx").read_text(encoding="utf-8")
    assert "Create New" in source
    assert "Clone Existing" in source
    assert "Edit Existing" in source
    assert "Yes, edit this configuration" in source
    assert "Selecting a customer globally never edits it automatically" in source
    assert "The developer-approved U-HAUL reference cannot be edited" in source
    assert "Create independent copy" in source
    assert "setMode('create')" in source
    assert "setMode('edit')" in source


def test_app_passes_full_configuration_library_into_builder():
    source = (ROOT / "webapp" / "frontend" / "src" / "App.tsx").read_text(encoding="utf-8")
    assert "<BuilderPage bootstrap={bootstrap} active={active} configurations={configs}" in source


def test_sidebar_text_has_overflow_protection_for_brand_and_navigation():
    css = (ROOT / "webapp" / "frontend" / "src" / "styles.css").read_text(encoding="utf-8")
    assert ".sidebar,.sidebar *{min-width:0}" in css
    assert ".sidebar{overflow-x:hidden}" in css
    assert ".brand-copy strong" in css and "white-space:normal" in css
    assert ".nav-item span" in css and "overflow-wrap:anywhere" in css
    assert "-webkit-line-clamp:2" in css


def test_create_clone_edit_backend_operations_and_uhal_edit_protection(tmp_path: Path):
    runtime = tmp_path / "runtime"
    code = r'''
from fastapi.testclient import TestClient
from webapp.backend.app.main import app
c = TestClient(app)

# Create new
created_resp = c.post('/api/configurations', json={'name':'V83 New','customer':'V83 CUSTOMER','direction':'Outbound','transaction_code':'856','flow_type':'Translation','source_interface':'SFTP','target_interface':'SFTP','input_mode':'files'})
assert created_resp.status_code == 200, created_resp.text
created = created_resp.json()

# Explicit edit of an ordinary saved configuration
edited_resp = c.patch(f"/api/configurations/{created['id']}", json={'transaction_name':'Ship Notice V83'})
assert edited_resp.status_code == 200, edited_resp.text
edited = edited_resp.json()
assert edited['transaction_name'] == 'Ship Notice V83'
assert edited['status'] == 'CONFIGURATION_CHANGED'

# Clone existing into an independent workspace
clone_resp = c.post(f"/api/configurations/{created['id']}/clone", json={'name':'V83 Clone'})
assert clone_resp.status_code == 200, clone_resp.text
clone = clone_resp.json()
assert clone['id'] != created['id']
assert clone['cloned_from_configuration'] == created['id']
assert clone['name'] == 'V83 Clone'

# U-HAUL remains immutable, but can be cloned
rows = c.get('/api/configurations').json()
uhal = next(row for row in rows if row.get('approved_reference'))
blocked = c.patch(f"/api/configurations/{uhal['id']}", json={'customer':'MUTATED'})
assert blocked.status_code in (400, 409), blocked.text
uhal_clone = c.post(f"/api/configurations/{uhal['id']}/clone", json={'name':'V83 UHAL Copy'})
assert uhal_clone.status_code == 200, uhal_clone.text
copy = uhal_clone.json()
assert copy['id'] != uhal['id']
assert copy.get('cloned_from_approved_reference') is True
'''
    env = dict(os.environ)
    env["HIP_STUDIO_RUNTIME_ROOT"] = str(runtime)
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), str(ROOT / "webapp" / "backend"), env.get("PYTHONPATH", "")])
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, text=True, capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr
