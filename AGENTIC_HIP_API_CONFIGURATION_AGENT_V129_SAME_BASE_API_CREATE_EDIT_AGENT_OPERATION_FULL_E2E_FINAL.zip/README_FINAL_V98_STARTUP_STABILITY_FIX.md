# V98 — Windows / OneDrive Startup Stability Fix

## Issue reproduced from the latest screenshots

The FastAPI application reached `Application startup complete`, but the DEV Uvicorn command used `--reload` without a `--reload-dir`. On Windows this makes WatchFiles observe the whole repository. When the extracted project is inside OneDrive, sync/timestamp activity can make WatchFiles report dozens of `.py` files as changed, repeatedly stop/start the Uvicorn worker, and finally show a multiprocessing traceback ending in `KeyboardInterrupt` when the loop is interrupted.

## Fix

1. Normal production launcher remains non-reloading.
2. DEV launchers now default to a stable non-reloading backend. Bun/Vite frontend HMR remains enabled.
3. Backend hot reload is opt-in with `HIP_BACKEND_HOT_RELOAD=1`. When enabled, reload scope is restricted to `webapp/backend/app`.
4. Batch child processes inherit the already-correct working directory instead of repeating a path-sensitive `cd` command.
5. Regression tests prevent a broad unscoped `--reload` from returning.

## Recommended Windows commands

Normal run:

```bat
RUN_AGENTIC_HIP.bat
```

Development with stable backend + frontend HMR:

```bat
RUN_AGENTIC_HIP_DEV.bat
```

Optional scoped backend hot reload:

```bat
set HIP_BACKEND_HOT_RELOAD=1
RUN_AGENTIC_HIP_DEV.bat
```

Do not manually start Uvicorn with a bare `--reload` from the repository root when the project is in OneDrive.
