from pathlib import Path
ROOT=Path(__file__).resolve().parent

def test_v86_instant_delete_feedback_is_preserved_and_strengthened_in_v90():
    parallel=(ROOT/'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    workspace=(ROOT/'webapp/frontend/src/pages/WorkspacePage.tsx').read_text(encoding='utf-8')
    assert 'deletedJobIdsRef' in parallel
    assert 'Delete failed and was rolled back immediately' in parallel
    assert 'onConfigs(rows);' in workspace and 'await api.deleteConfiguration' in workspace

def test_v90_autogen_four_agent_scheduler_replaces_old_two_agent_limit():
    parallel=(ROOT/'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    models=(ROOT/'webapp/backend/app/models.py').read_text(encoding='utf-8')
    assert 'RUN LIVE EXECUTION' in parallel
    assert 'Parallel agents' in parallel and 'AutoGen AgentChat 0.7.5' in parallel
    assert 'Math.min(4' in parallel
    assert 'workers: int = Field(default=4, ge=1, le=50)' in models
    assert 'adaptive_concurrency' not in models
