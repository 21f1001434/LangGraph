# V125 — Human Edit Propagation + Migration LIVE + Whole Payload Edit + Excel Mapper Hardening

## Scope

V125 is built on the coherent V124 Patch 2 source tree. It fixes four production issues and integrates the relevant behavior from the supplied `INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V7_UHAL_HEALTH_PAYLOAD_ACCURACY_FULL_E2E_FINAL` reference package.

The historical HIP create/configuration catalog remains **18 reusable base API blocks**. The Dev-published Migration catalog remains **7 additive logical blocks**. V125 composes the seven Migration blocks into LIVE execution only when Migration is explicitly requested by a human-supplied `targetEnvironment`, so historical 18-API flows remain backward compatible while an activated migration run executes the applicable **18 + 7** sequence.

## 1. Human edits now reach the actual execution snapshot

A Build Configuration/API Testing/API Flow Game value edit still uses the governed human-only value persistence endpoint. V125 additionally synchronizes linked canonical identities and refreshes matching queued execution snapshots that have not started yet.

For Source/Target Transport Profile orchestration, editing:

`transportProfileDetails[0].transportProfileName`

promotes the human-approved name into the canonical Source/Target TP configuration. Validate, orchestration, audit/history, dependent requests, and a queued READY snapshot therefore use the same edited TP name.

Queue policy:

- `READY`, `NEEDS_REVALIDATION`, or `STALE` jobs for the edited configuration are refreshed from the current workspace.
- If revalidation passes, the refreshed job remains `READY`.
- If the edit creates a blocker, the refreshed job becomes `NEEDS_REVALIDATION`.
- `RUNNING` and completed jobs are immutable and are never rewritten.

This specifically closes the stale Legrand TP-name behavior where the editor displayed the new value but an older queued snapshot still executed the previous name.

## 2. Migration APIs execute in LIVE when activated

The seven Dev-published logical Migration blocks are:

1. Source Document Type
2. Target Document Type
3. Data Map
4. Rule
5. Source Transport Profile
6. Target Transport Profile
7. Flow

They use the five published Migration endpoint families already integrated in V122.

Activation is explicit: Migration becomes part of full LIVE when an effective Migration payload contains a non-empty human-supplied `targetEnvironment` (or the explicit process-level force option is used). V125 then performs Migration preflight before the first mutation and executes the applicable Migration steps after their base-object dependencies.

Dependency examples:

- Source Document Type migration depends on Source Document Type.
- Target Document Type migration depends on Target Document Type.
- Data Map migration depends on Data Map.
- Rule migration depends on Rule.
- Source/Target TP migration waits for the corresponding TP audit evidence.
- Flow migration waits for Flow deployment history evidence.

If Migration has not been activated, the seven blocks remain visible/editable/testable but do not make a normal non-migration 18-API run fail merely because `targetEnvironment` is blank.

## 3. Create/Edit uses the same existing contract

V125 adds user controls **Set CREATE operation** and **Set EDIT operation** in Whole Payload view.

The controls walk the existing request and change only existing operation-value leaves whose current value is already `create`/`Create` or `edit`/`Edit`. Case style is preserved.

Examples in the supplied/current TP contracts include:

- top-level `operation`
- `transportProfileDetails[0].transportProfileOperation`

No `operation` attribute is invented. If an API contract does not currently contain a create/edit operation leaf, the UI reports that Edit mode is unavailable for that contract. This preserves the immutable-attribute rule until the Dev team supplies/confirms the exact operation path for that API.

## 4. Whole Payload edit, still value-only

Build Configuration → Step 4 now opens **Whole payload** by default and retains **Field view** as an optional precise editor.

The shared editor used by API Testing Area and API Flow Game provides the same two views.

Whole Payload allows a human to edit multiple existing values in the complete JSON request. The backend rejects:

- added attributes;
- removed attributes;
- renamed attributes;
- nesting changes;
- array-cardinality changes.

Method, URL, protected headers, and request kind remain outside the editable payload. The agent/AutoGen/Dell-AIA path still has no save authority.

## 5. Migration environment synchronization

All seven Dev-published Migration request contracts already contain `sourceEnvironment` and `targetEnvironment`. When a human edits either environment in one Migration request, V125 synchronizes that existing value across the other applicable Migration requests using USER-origin overrides. It does not add a field that is absent from a contract.

## 6. Excel → API Mapper hardening from supplied V7 reference

The supplied reference package was used as the basis for these mapper behaviors:

- `LENS TP Name` is retained as customer/reference evidence and is not used as executable TP identity.
- Explicit DEV Transport Profile / TP identity columns are preferred for Source/Target TP name.
- HIP Account mapping uses the explicit HIP-account headers rather than a broad generic `Account` match.
- `SFTP`, `SFTP HAFT`, and `SFTP-HAFT` normalize safely to the approved API label `SFTP HAFT` when the active canonical interface family proves the equivalence.
- Document Type Name and Document Type Version stay separate; `NAME(1.0)` can be split deterministically into the two existing leaves.
- For SFTP/FILE requests, `Subscription Folder` and `Existing Account Name` participate in readiness when those leaves exist in the selected contract.
- `Post Transfer Action` uses the supplied V7 contract value `Move To Archive`.
- Identical duplicate TP evidence rows are consolidated. Conflicting duplicate TP identities are blocked for human review rather than silently picking one.
- Workbook-only fields that are not present in the active canonical request remain evidence/unmapped columns and do not become new payload attributes.

The existing V123 governance remains: analysis itself does not mutate the canonical configuration; agent mapping prepares values; an explicit human approval/save is required before persistence and LIVE.

## 7. Contract invariants retained

V125 retains all prior approved behavior, including:

- 18 historical reusable base API blocks;
- 7 additive Migration blocks;
- NAS and Rabbit MQ interface contracts;
- HTTPS-AS2 Sender/Receiver schema and required Receiver `SSL Certificate`;
- invariant outer TP structure with interface-specific values under `transportProfileDetails[0].interfaceDetails`;
- human-only value editing;
- strict LIVE/no-reuse behavior;
- same-call EXISTING evidence handling;
- deployment group `hip-automation`;
- parallel execution and reports;
- API Testing and Flow Game editing;
- V123 Intelligent Excel → API Mapper.

## Validation

Final V125 source validation:

- complete repository regression: **556/556 PASS** (four isolated shards: 137 + 121 + 135 + 163);
- V125 focused hardening tests: **8/8 PASS**;
- package validator: **59/59 PASS**;
- adaptive validator: **60/60 PASS**;
- business readiness: **70/70 PASS**;
- final release validator: **16/16 PASS**;
- Phase 1–6: **12/12, 19/19, 31/31, 26/26, 28/28, 38/38 PASS**;
- Python compileall: **PASS**;
- frontend TS/TSX syntax transpilation: **26/26 files, 0 diagnostics**;
- required self-check: **44/45**, with the only failed item being the environment advisory that Bun is not installed in the validation container.

Because Bun is not installed in this container, a literal `bun run build` is not claimed here. On the target Windows workstation, execute the normal production frontend build after extraction.

## Windows run

Use a fresh extraction directory.

```powershell
python -m pip install -r requirements.txt
cd webapp\frontend
bun install
bun run build
cd ..\..
RUN_AGENTIC_HIP.bat
```

Alternatively run `SETUP_AGENTIC_HIP.bat` for the normal setup/start path.
