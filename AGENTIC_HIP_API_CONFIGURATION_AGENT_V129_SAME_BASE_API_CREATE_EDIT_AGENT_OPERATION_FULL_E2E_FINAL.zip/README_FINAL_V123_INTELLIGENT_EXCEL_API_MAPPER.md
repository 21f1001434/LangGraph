# V123 — Intelligent Excel → API Mapper + Agent Value Mapping + Account Readiness + User-Gated Trigger

## Purpose

V123 adds a reusable intelligent intake process for team-maintained Excel/CSV inventories. The first concrete use case is Transport Profile creation, but the implementation is API-agnostic: it analyzes the active Studio configuration's **actual generated canonical requests** and can therefore map a workbook to any applicable current or future API block without introducing a second payload schema.

The workflow is:

1. Open/build the customer configuration that represents the canonical API baseline.
2. Open **Excel → API Mapper**.
3. Upload `.xlsx`, `.xlsm`, or `.csv`.
4. Choose `AUTO` or a specific API contract.
5. The parser detects the worksheet/header and reads each populated row.
6. Deterministic matching + optional Dell AIA role agents map workbook columns only to exact existing API request leaves and prepare the corresponding VALUE changes.
7. Every Excel row/account receives one of:
   - **GOOD_TO_TRIGGER**
   - **NEEDS_INPUT**
   - **DO_NOT_TRIGGER**
8. Review source column → source value → canonical path → canonical API value → confidence/method.
9. Only a **GOOD_TO_TRIGGER** row can be explicitly approved/staged by the user; this persists the agent-prepared value changes.
10. The existing Agent Preflight must pass.
11. Only then is **Run API LIVE** enabled.

No workbook analysis call mutates HIP or the local canonical configuration.

## Intelligence / agent design

The feature uses the same Dell AIA integration already present in the application through `run_agent.AIAJudge`; its configured/default text model is `gpt-oss-120b`.

Two schema-locked value-mapping roles are used when Dell AIA is enabled and available:

- **Excel Schema Analyst** — classifies workbook column semantics and likely account/record identity fields.
- **HIP API Contract Mapping Agent** — proposes semantic column-to-path mappings using only the exact API keys and exact target paths supplied by the deterministic contract extractor.

LLM mapping/value suggestions are allowed only inside the existing schema. A suggestion is discarded unless:

- its workbook header exactly exists in the parsed sheet;
- its API key exactly exists in the active applicable catalog;
- its target path exactly exists in that API's generated/effective request;
- its confidence is at least the governed threshold.

If Dell AIA is unavailable or disabled, the same page continues with deterministic semantic matching.

## Immutable API attributes

The existing V117–V122 governance is unchanged.

The mapper/agent **cannot change API attributes or structure**. It cannot:

- add an API attribute;
- remove an API attribute;
- rename a key;
- change request nesting or array cardinality;
- change HTTP method/endpoint/protected headers;
- persist an agent-prepared value without explicit user Stage approval;
- trigger LIVE automatically.

Workbook columns are evidence. They are not a new API schema.

For example, the supplied Transport Profile workbook contains useful connectivity columns such as SFTP server/port/authentication. If the selected current Dev-approved SFTP payload does not contain those attributes, they are shown under **Workbook columns intentionally not mapped** rather than being manufactured into the request.

## Transport Profile behavior

For Source/Target TP orchestration, the mapper can resolve values such as:

- Source/Target System
- Transport Profile Name / DEV Transport Profile Name / LENS TP Name
- Source/Target Interface Type / Transport Type / Delivery Type
- Document Type Name / Dell Biz Doc
- HIP Account / Existing Account Name
- interface-specific parameter columns only when that parameter exists in the selected canonical interface contract

The outer TP orchestration structure remains invariant. Interface differences remain inside:

`transportProfileDetails[0].interfaceDetails`

The V120/V121 HTTPS-AS2 contract, V122 NAS/Rabbit MQ contracts, and existing SFTP/FTP/HTTPS contracts remain the source of truth.

### Safe interface normalization

Team sheets often contain an abbreviated interface label such as `SFTP` while the active HIP contract contains the exact Dev-approved value `SFTP HAFT`.

V123 canonicalizes an interface label only when the workbook value and the active generated request are provably the same interface family. The evidence table shows the workbook source value and the canonical API value. A genuinely different interface value is not converted; it is preserved and contract validation blocks it.

## Account / row readiness logic

Readiness is calculated row-by-row, so one workbook may contain accounts that are good while other accounts need input.

A row cannot become `GOOD_TO_TRIGGER` merely because the active configuration already contains a usable object identity. At least one critical identity value for the selected API must be mapped/confirmed from that workbook row.

The mapper evaluates:

- safe mapped-column count;
- critical canonical fields for the selected API;
- whether the object identity came from the workbook row versus only the active baseline;
- scalar type coercion safety;
- canonical structure lock errors;
- mapping confidence;
- existing contract status as an execution warning;
- API applicability.

`GOOD_TO_TRIGGER` is a governed local mapping/readiness decision. It is **not** a substitute for the existing Agent Preflight or LIVE connectivity/authentication checks.

## AUTO API selection

`AUTO` evaluates all applicable API blocks for each Excel row and ranks the best candidate. It also shows up to five alternate API candidates with their mapping count, readiness, and score.

This allows the same workbook intake engine to be reused for:

- Account
- Partner
- System
- Document Type
- Data Map
- Rule
- Source/Target Transport Profile
- Validate/Audit APIs
- Flow Create/Deploy/History
- the seven V122 Migration blocks
- future APIs whose generated canonical requests are exposed through the Studio catalog

No API-specific UI fork is required.

## Agent values → user approval → preflight → LIVE gate

The agent prepares the mapping and value changes; the existing schema-locked value persistence endpoint is invoked only after the user clicks Approve & Stage. This preserves explicit user authority while allowing the agent to do the mapping/value work.

Execution sequence is intentionally strict:

`Analyze + agent value mapping → GOOD_TO_TRIGGER → User Approve & Stage → Agent Preflight PASS → explicit LIVE confirmation → Execute`

Approved U-HAUL reference configurations stay read-only. Clone/Create from the reference before staging mapped values.

## New files / primary changes

- `webapp/backend/app/excel_api_mapper.py`
- `webapp/backend/app/main.py`
  - `POST /api/configurations/{cid}/intelligent-mapper/analyze`
- `webapp/frontend/src/pages/ExcelApiMapperPage.tsx`
- `webapp/frontend/src/lib/api.ts`
- `webapp/frontend/src/types.ts`
- `webapp/frontend/src/components/Sidebar.tsx`
- `webapp/frontend/src/components/AppTopbar.tsx`
- `webapp/frontend/src/App.tsx`
- `webapp/frontend/src/styles.css`
- `webapp/backend/tests/test_webapp_phase7_excel_mapper.py`

## Workbook limits

- `.xlsx` / `.xlsm` Open XML
- `.csv`
- up to 20 MB
- up to 500 populated data rows per analysis
- up to 160 columns
- legacy `.xls` must be saved as `.xlsx` or CSV

The backend reads Open XML directly and does not rewrite the uploaded workbook.

## Validation performed

- New V123 mapper regression suite: **7/7 PASS** (after final attribute-immutability/value-mapping policy test)
- Existing full repository regression inventory before the final focused normalization addition: **536/536 PASS**
- Final focused mapper suite after interface normalization and policy hardening: **7/7 PASS**
- Modified backend modules: Python compile PASS
- Modified Mapper TypeScript page/API/types: strict isolated type-check with local dependency stubs PASS
- Modified TS/TSX source: TypeScript syntax transpilation PASS

The packaging container does not contain frontend `node_modules`/Bun, so the complete Vite production bundle is not generated here. This is consistent with prior releases. On the target Windows machine use the existing build path:

```bat
BUILD_AGENTIC_HIP_FRONTEND.bat
```

or the normal setup path, which performs Bun install/build before production use.

No authenticated Dell HIP mutation was executed while validating this release.
