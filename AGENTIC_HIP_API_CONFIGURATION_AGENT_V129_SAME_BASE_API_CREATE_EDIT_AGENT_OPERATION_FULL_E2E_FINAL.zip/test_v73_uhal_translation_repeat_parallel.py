from __future__ import annotations

import json
from pathlib import Path

from webapp.backend.app import main as main_module
from webapp.backend.app.models import ParallelSourcesQueueCreate
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.storage import JsonStore
from webapp.backend.app.templates import generated_template_from_configuration

ROOT = Path(__file__).resolve().parent


def _uhal_input() -> dict:
    return json.loads((ROOT / "input.json").read_text(encoding="utf-8"))


def test_v73_approved_uhal_template_is_translation_only():
    rows = main_module._builtin_template_catalog()
    uhal = [row for row in rows if "UHAUL" in "".join(ch for ch in str(row.get("name") or "").upper() if ch.isalnum())]
    assert len(uhal) == 1
    row = uhal[0]
    assert row["id"] == "builtin-uhal-outbound-856-translation-approved"
    assert row["flow_type"] == "Translation"
    assert row["direction"] == "Outbound"
    assert row["transaction_code"] == "856"
    assert len(row["nodes"]) == 18
    assert row["default_values"]["flow_type"] == "translation"
    assert "Passthrough" not in row["name"]


def test_v73_stale_uhal_passthrough_input_cannot_generate_passthrough_template():
    data = _uhal_input()
    data["requires_data_map"] = False
    data["flow_type"] = "passthrough"
    template = generated_template_from_configuration("old-uhal", data)
    assert template["flow_type"] == "Translation"
    assert template["default_values"]["flow_type"] == "translation"
    assert len(template["nodes"]) == 18


def test_v73_template_catalog_hides_old_uhal_passthrough_and_other_uhal_copies(tmp_path, monkeypatch):
    store = JsonStore(tmp_path / "runtime")
    store.save_template({
        "name":"U-HAUL Outbound 856 Passthrough",
        "description":"stale",
        "direction":"Outbound","transaction_code":"856","flow_type":"Passthrough",
        "nodes":[],"edges":[],"variables":[],"default_values":{"customer":"U-HAUL"},"tags":["U-HAUL"],
    }, template_id="stale-uhal-pass")
    store.save_template({
        "name":"U-HAUL custom Translation",
        "description":"duplicate",
        "direction":"Outbound","transaction_code":"856","flow_type":"Translation",
        "nodes":[],"edges":[],"variables":[],"default_values":{"customer":"U-HAUL"},"tags":["U-HAUL"],
    }, template_id="duplicate-uhal-translation")
    store.save_template({
        "name":"OTHER Inbound 850 Passthrough",
        "description":"valid other-customer pass",
        "direction":"Inbound","transaction_code":"850","flow_type":"Passthrough",
        "nodes":[],"edges":[],"variables":[],"default_values":{"customer":"OTHER"},"tags":["OTHER"],
    }, template_id="other-pass")
    monkeypatch.setattr(main_module, "STORE", store)
    rows = main_module._template_catalog()
    named = [r for r in rows if "UHAUL" in "".join(ch for ch in str(r.get("name") or "").upper() if ch.isalnum())]
    assert len(named) == 1
    assert named[0]["flow_type"] == "Translation"
    assert any(r.get("id") == "other-pass" and r.get("flow_type") == "Passthrough" for r in rows)


def test_v73_parallel_queue_preserves_duplicate_source_ids_for_same_customer(tmp_path, monkeypatch):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    monkeypatch.setattr(main_module, "STORE", store)
    monkeypatch.setattr(main_module, "PARALLEL", manager)
    payload = ParallelSourcesQueueCreate(source_ids=["reference:uhal", "reference:uhal", "reference:uhal"])
    result = main_module.parallel_queue_sources(payload)
    assert result["created"] == 3
    assert result["errors"] == []
    ids = [row["jobId"] for row in result["items"]]
    assert len(ids) == len(set(ids)) == 3
    assert all(row["customer"] == "U-HAUL" for row in result["items"])
    assert all(row["flowType"] == "Translation" for row in result["items"])
    assert [row.get("demoInstance") for row in result["items"]] == [1, 2, 3]
    assert all(row.get("demoInstanceCount") == 3 for row in result["items"])
    assert [f"Instance {i}/3" in row.get("label", "") for i, row in enumerate(result["items"], 1)] == [True, True, True]
    # Every run is a separate immutable snapshot even though the customer is the same.
    workspaces = [row["workspace"] for row in result["items"]]
    assert len(workspaces) == len(set(workspaces)) == 3


def test_v73_frontend_same_customer_parallel_and_uhal_guard_are_present():
    parallel = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    flow = (ROOT / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    assert "REPEAT CUSTOMER" in parallel
    assert "Array.from({length:demoCount},()=>source.sourceId)" in parallel
    assert "setRunMode('multiple')" in parallel
    assert "DEV APPROVED · TEST READY" in parallel
    assert "U-HAUL Passthrough is not an approved flow" in flow
    assert "builtin-uhal-outbound-856-translation-approved" in flow


def test_v73_execute_source_list_exposes_uhal_only_once(monkeypatch, tmp_path):
    store = JsonStore(tmp_path / "runtime")
    # Create a stale duplicate U-HAUL configuration that would have appeared in old releases.
    stale = store.create_configuration({"name":"U-HAUL stale passthrough","customer":"U-HAUL","direction":"Outbound","transaction_code":"856","flow_type":"Passthrough"})
    workspace = Path(stale["workspace"])
    data = _uhal_input(); data["requires_data_map"] = False; data["flow_type"] = "passthrough"
    (workspace / "input.json").write_text(json.dumps(data), encoding="utf-8")
    monkeypatch.setattr(main_module, "STORE", store)
    monkeypatch.setattr(main_module, "PARALLEL", ParallelManager(store))
    rows = main_module.parallel_sources()
    uhal = [r for r in rows if "".join(ch for ch in r.get("customer", "").upper() if ch.isalnum()) == "UHAUL"]
    assert len(uhal) == 1
    assert uhal[0]["sourceId"] == "reference:uhal"
    assert uhal[0]["flowType"] == "Translation"
