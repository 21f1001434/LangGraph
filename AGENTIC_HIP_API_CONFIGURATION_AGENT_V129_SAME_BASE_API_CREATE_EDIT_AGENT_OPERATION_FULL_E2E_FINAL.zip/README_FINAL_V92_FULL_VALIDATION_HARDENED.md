# HIP API Agent Studio V92 — Full Validation Hardened

V92 is the fresh-validation hardening release built from V91 (Microsoft AutoGen AgentChat 0.7.5). It keeps the approved HIP API request structures unchanged and fixes inconsistencies discovered only when the complete package was revalidated as a fresh install.

## What was corrected during final validation

1. **Current validator alignment** — Phase 2 was still looking for retired Parallel LIVE UI wording. It now validates the current `RUN LIVE EXECUTION` / AutoGen AgentChat 0.7.5 workflow.
2. **Deployment-group consistency** — active runtime builders, input generation, U-HAUL approved reference data, previews, transport-profile defaults, validators and release policy now use one consistent final deployment-group value. Historical README/manifests remain historical documentation only.
3. **Reference ownership wording** — the active U-HAUL reference correctly describes the partner/DUNS ownership used by the approved test configuration.
4. **Pipeline event correctness** — duplicate pipeline `job.completed` publication was removed.
5. **Release-label consistency** — current Execution Center and runtime-preflight messages now identify V92 rather than stale V91 text.
6. **Regression coverage** — `test_v92_full_validation_hardening.py` locks these fixes while preserving AutoGen AgentChat 0.7.5 and the four-agent concurrency ceiling.

## AutoGen implementation

Production parallel customer/instance execution uses the modern Microsoft AutoGen AgentChat API, pinned to:

- `autogen-agentchat==0.7.5`
- `autogen-core==0.7.5`
- `autogen-ext[openai]==0.7.5`

Each active customer/instance receives a fresh `AssistantAgent`. A maximum of four AgentChat agents are scheduled concurrently; larger selections drain through the same worker pool without scheduling a fifth concurrent agent. Inside each customer execution, dependency-ready HIP API calls may execute concurrently where the governed execution graph allows it.

Production AutoGen is **fail-closed**: missing/mismatched AgentChat packages do not silently fall back to the legacy `pyautogen` API.

## Payload safety

The V91 → V92 structural comparison passed for:

- `input.json`
- `config_overrides.json`
- developer-approved U-HAUL input/config reference files
- HIP configuration-service contract schema
- developer-approved transport-interface shape schema

Every compared JSON key/type path is identical. V92 changes policy/reference **values and validation behavior**, not the approved API request schema.

Canonical payload guards remain enabled: unknown keys, wrong nesting, interface-shape drift and prohibited `workType` reintroduction remain rejected before LIVE execution.

## Fresh validation result

- Application tests: **301 passed, 0 failed**
- FastAPI/backend tests: **48 passed, 0 failed**
- Total automated tests: **349 passed, 0 failed**
- Phase 1: **12/12**
- Phase 2: **19/19**
- Phase 3: **30/30**
- Phase 4: **26/26**
- Phase 5: **28/28**
- Phase 6: **38/38**
- Final release validation: **16/16**
- Package validation: **57/57**
- Adaptive/package validation: **60/60**
- Required final self-checks: **43/43**
- Frontend TS/TSX independent transpilation: **24/24**
- Python compilation: **PASS**
- FastAPI smoke endpoints `/api/health`, `/api/bootstrap`, `/api/system/status`, `/api/parallel/sources`: **HTTP 200**
- V91 → V92 JSON/API structural comparison: **PASS**

## Environment prerequisites that cannot be certified in this sandbox

The validation container does not have the external AutoGen 0.7.5 distributions or Bun installed, and its network cannot fetch those packages. Therefore `runtime_preflight.py --json` correctly fails closed on those missing production prerequisites. The exact package versions are pinned in `requirements.txt`, and `SETUP_AGENTIC_HIP.bat` installs Python requirements, requires Bun, builds the frontend and runs production preflight before launch.

This container also has no authorized Dell HIP credential/network session, so a real external LIVE HIP mutation was **not** executed as part of this validation. The LIVE scheduler, payload guards, AutoGen tool invocation, delete/stop behavior, pipeline preflight, request generation and response handling are covered by the automated tests; external HIP availability, credentials, throttling and server-side business responses must still be confirmed in the target Dell environment.

## Windows first run

Use a fresh extracted folder. Run:

```bat
SETUP_AGENTIC_HIP.bat
```

The setup must complete successfully before treating the machine as production-ready. After launch, use a hard browser refresh (`Ctrl+F5`) once if an older Studio build was previously open.

For detailed machine-readable evidence see `V92_VALIDATION_RESULT.json`.

- Backward-compatible `demo-instances` creation now uses the same instance-group IDs as the React queue path, so deleting any repeated instance immediately renumbers the remaining `1/N` labels without refresh.
