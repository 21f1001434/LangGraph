# Engineer Input JSON Analysis — V74

## Executive verdict

**GO — use it as an Input Extraction Blueprint, not as the final customer `input.json`.**

The engineer-provided JSON is valuable because it documents, field by field, where a value should come from: customer payloads, XBM, JAR, package/folder naming, controlled dropdowns, Partner/HAFT/Application/Environment configuration, or deterministic naming conventions. This is exactly the missing orchestration layer between raw customer artifacts and the canonical HIP `input.json`.

## What is strong and directly reusable

- Transaction standard/code rules: XML root/transaction mapping, X12 ST01, EDIFACT UNH.
- Direction and Flow Type as controlled user selections when evidence cannot prove them.
- `requires_data_map` from XBM/JAR evidence.
- Data Map extraction from XBM/JAR.
- Source/Target Document Type intent and document-identifier rules.
- Sender/Receiver/Transaction/Business-Identifier extraction from XML/X12/EDIFACT.
- Mapping Rule/BizFlow conditions from those document attributes.
- Transport Profile names and object names from canonical naming conventions.
- BizFlow source/target/process/routing linkage from the objects already built.

## What must NOT be copied literally

1. **Legrand values/XPaths are examples, not defaults.** They must never be copied into another customer's input.
2. **Map Class:** use the actual `Transform_*.class` found inside the JAR when available; do not blindly use the JAR filename.
3. **Contivo version:** read from XBM/approved configuration. A controlled environment default is acceptable only when explicitly configured; it is not a customer-file fact.
4. **Target folder:** customer conventions vary. Do not universally derive it from TP name. Extract it from approved HAFT/manual/configuration evidence or ask the user.
5. **Environment/Partner/HAFT/Application configuration:** these are external configuration sources. If the app does not have approved evidence, ask rather than guess.
6. **Routing target:** route to the approved target Flow/Transport Profile, not to a Document Type.
7. **Complex Document Type/routing JSON:** the app should build it from deterministic parsers and existing rules; users should not be forced to paste free-form JSON unless the existing contract validator truly requires it.

## V74 implementation

The screenshots were converted into `schemas/engineer_input_extraction_blueprint.json` with **66 field-source rules**. The runtime module `input_extraction_blueprint.py`:

- preserves approved JSON precedence;
- applies only safe alias/structural derivations;
- never copies example customer values;
- records per-field provenance under `_input_extraction_blueprint`;
- adds only targeted scalar questions when generated customer evidence cannot prove a required value;
- skips HAFT account/folder questions for non-file interfaces;
- updates Build Configuration evidence and the plain-language customer intake report.

## Resulting input automation sequence

1. Detect approved HIP JSON; if present, keep it authoritative.
2. Parse Configuration Manual when present.
3. Parse XML/cXML/X12/EDIFACT/JSON/customer payload evidence.
4. Inspect XBM and JAR deterministically.
5. Apply approved interface contract and naming rules.
6. Apply the engineer extraction blueprint to fill safe aliases and create provenance.
7. Ask only unresolved scalar/customer/environment values.
8. Save canonical `input.json`.
9. Generate customer intake HTML explaining extracted/derived/user-required values.
10. Map to the fixed 18 HIP API payload structures and run non-mutating validation.

## Final assessment

The engineer JSON **does help materially** and should remain in the product as a maintained extraction contract. It should not replace the canonical input schema or the 18 API payload schemas. It is the logic layer that tells the agent how to obtain the values that populate those fixed schemas.
