@echo off
setlocal
cd /d "%~dp0"
call RUN_AGENTIC_HIP.bat
exit /b %errorlevel%
