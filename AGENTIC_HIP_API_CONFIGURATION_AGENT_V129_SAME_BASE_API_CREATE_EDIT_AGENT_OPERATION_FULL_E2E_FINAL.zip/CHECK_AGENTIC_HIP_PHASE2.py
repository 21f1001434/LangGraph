from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"name": name, "ok": bool(ok), "detail": detail})

manifest = json.loads((ROOT / "AGENTIC_HIP_PHASE2_MANIFEST.json").read_text(encoding="utf-8"))
check("Phase 2 manifest", manifest.get("phase") == 2 and manifest.get("release") == "V34")
main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
app = (ROOT / "webapp/frontend/src/App.tsx").read_text(encoding="utf-8")
builder = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
parallel = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
learn = (ROOT / "webapp/frontend/src/pages/LearnPage.tsx").read_text(encoding="utf-8")
reports = (ROOT / "webapp/frontend/src/pages/ReportsPage.tsx").read_text(encoding="utf-8")
worker = (ROOT / "webapp/backend/app/legacy_worker.py").read_text(encoding="utf-8")

check("React Phase 2 pages replace placeholders", all(x in app for x in ["ParallelPage", "LearnPage", "ReportsPage"]) and "PlaceholderPage" not in app)
check("Input Builder evidence is visible", "How customer files mapped into input.json" in builder and "FILE TRUTH" in builder)
check("18 API agent validation is visible", "Map to 18 APIs + agent validate" in builder)
check("Mapping learner is visible", "Mapping learner" in builder and "Teach from this validated pair" in builder)
check("Parallel LIVE UI is visible", "RUN LIVE EXECUTION" in parallel and "AutoGen AgentChat 0.7.5" in parallel)
check("U-HAUL / same-customer instance UI is visible", "REPEAT CUSTOMER" in parallel and "Create repeated execution instances" in parallel and "Create multiple immutable snapshots of one validated customer" in parallel)
check("Per-step timing UI is visible", "step timings" in parallel and "API" in parallel and "wait" in parallel)
check("Learn UI is real", "Learn from selected files" in learn and "Ask Learn" in learn)
check("Reports UI is real", "Runtime evidence" in reports and "Select a report" in reports)
check("Backend validation route", '/api/configurations/{cid}/validate' in main and 'MODE == "validate"' in worker)
check("Backend mapping learner route", "/api/mapping-learning" in main)
check("Backend parallel WebSocket", "/ws/parallel/{batch_id}" in main)
check("Backend Learn routes", "/learn/files" in main and "/learn/ask" in main)
check("Backend Reports routes", '/reports/{report_name}' in main)
check("LIVE-only manifest", manifest.get("liveOnlyExecution") is True)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
check("Current deployment group is hip-automation", DEFAULT_DEPLOYMENT_GROUP == "hip-automation")

try:
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    meta = transaction_metadata()
    check("Exactly 18 reusable API blocks", len(api_catalog()) == 18 and all(x.get("reusable") for x in api_catalog()))
    check("Direction remains editable", meta.get("editable_direction") is True and meta.get("default_direction") == "Outbound")
except Exception as exc:
    check("Python Phase 2 imports", False, str(exc))

failed = [x for x in checks if not x["ok"]]
summary = {"status": "PASS" if not failed else "FAIL", "passed": len(checks)-len(failed), "failed": len(failed), "checks": checks}
print(json.dumps(summary, indent=2))
raise SystemExit(1 if failed else 0)
