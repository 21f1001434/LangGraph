# V121 — Dev-Approved HTTPS-AS2 Receiver SSL Certificate Required

## Final Dev correction

Dev approved the V120 HTTPS-AS2 interface contract with one minor correction: the Receiver/Target `interfaceDetails.parameters` must include `SSL Certificate`. The supplied review confirms the reviewed DEV value `dellroot_ca_6_able.crt`. V121 uses this as the Dev default for HTTPS-AS2 Receiver; an explicit human value edit can replace it for another approved context.

## Final Receiver schema

`Interface Environment`, `Request Method`, `Partner URL`, `Partner Identifier`, `Dell Identifier`, `Signing Algorithm`, `Encryption Algorithm`, `Encryption Certificate`, **`SSL Certificate`**, `Enable AS2 Message Compression`, `Asynchronous MDN Required`, `Are Input Files Compressed?`, `Is EBCDIC enabled?`, `Compression Format`.

`SSL Certificate` is required. `Compression Format` remains conditional and is omitted only when `Are Input Files Compressed? = False`. Sender rules are unchanged.

## Governance unchanged

Build Configuration, API Testing Area and API Flow Game still provide human-only value editing. The human can change the value of the existing `SSL Certificate` attribute when appropriate, but cannot rename/add/remove attributes or alter payload structure. AI/AutoGen/Dell-AIA can inspect/explain/validate only and cannot persist edits.

The outer Transport Profile contract remains invariant across SFTP HAFT, FTP, HTTPS and HTTPS-AS2; only `transportProfileDetails[0].interfaceDetails` varies.

## Evidence

- `V121_AS2_TARGET_TP_VALIDATE_DEV_APPROVED.json`
- `V121_HTTPS_AS2_INTERFACE_CONTRACT_DEV_APPROVED.json`
- `V121_AS2_TARGET_TP_ORCHESTRATION_DEV_APPROVED.json`
- `V121_AS2_SSL_CERTIFICATE_RUNTIME_PROOF.json`
- `V121_FINAL_PACKAGE_VALIDATION.md`
