$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$distIndex = Join-Path $PSScriptRoot 'webapp\frontend\dist\index.html'
if (-not (Test-Path $distIndex)) {
    Write-Host '[STARTUP] Compiled React frontend is missing. Building it now...'
    if (-not (Get-Command bun -ErrorAction SilentlyContinue)) {
        throw 'Bun is not available and the compiled frontend is missing. Install/enable Bun, reopen PowerShell, then run again.'
    }
    Push-Location (Join-Path $PSScriptRoot 'webapp\frontend')
    try {
        bun install
        if ($LASTEXITCODE -ne 0) { throw 'bun install failed.' }
        bun run build
        if ($LASTEXITCODE -ne 0) { throw 'bun run build failed.' }
    }
    finally { Pop-Location }
}

python .\runtime_preflight.py --production
if ($LASTEXITCODE -ne 0) { throw 'Runtime preflight failed. Review the output above.' }
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot'; python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765"
Start-Sleep -Seconds 2
Start-Process 'http://127.0.0.1:8765'
