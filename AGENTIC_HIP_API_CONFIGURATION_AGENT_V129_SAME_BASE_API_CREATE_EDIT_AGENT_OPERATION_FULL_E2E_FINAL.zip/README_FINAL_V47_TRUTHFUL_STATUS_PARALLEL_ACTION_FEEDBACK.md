# V47 – Truthful API Status, Parallel Instance Fix, Action Feedback

## Fixes
- API Testing Area no longer equates generated payload with READY. It displays READY/BLOCKED/NOT VALIDATED/NOT APPLICABLE from the same persisted validation result used by Build Configuration.
- LIVE single-API execution is disabled unless the selected request is actually READY. Agent preflight remains available for diagnosis.
- Multi-instance creation now works for any active validated configuration, not only U-HAUL. Existing `/api/parallel/uhal-demo` remains as a compatibility alias; the UI uses `/api/parallel/demo-instances`.
- Newly created instances are refreshed into the queue and selected automatically.
- Async backend actions publish a global request-activity event and the app shows a small `Working…` spinner. High-value Parallel/API Testing buttons also show their own spinner/label while busy.
