from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
import time
import types
from pathlib import Path

from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.storage import JsonStore
from webapp.backend.app.autogen_runtime import run_with_autogen_agent

ROOT = Path(__file__).resolve().parent


def _workspace(root: Path, customer: str, idx: int = 0) -> Path:
    ws = root / f"{customer}_{idx}"
    for name in ("input_files", "payloads", "reports"):
        (ws / name).mkdir(parents=True, exist_ok=True)
    (ws / "input.json").write_text(json.dumps({
        "profile_name": f"{customer}_PC_856_ANS_MAPPING_OB_{idx}",
        "customer": customer,
        "direction": "Outbound",
        "tx_code": "856",
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": f"{customer}_FLOW_{idx}"}}},
    }), encoding="utf-8")
    return ws


def _queue(manager: ParallelManager, root: Path, customers: list[str]):
    validation = {"ok": True, "requests": {"ok": True, "validCount": 18, "total": 18}}
    rows = []
    for i, customer in enumerate(customers, start=1):
        ws = _workspace(root, customer, i)
        cfg = {"id": f"cfg-{i}", "workspace": str(ws), "customer": customer, "name": customer}
        rows.append(manager.queue_configuration(cfg, validation, f"{customer} instance {i}", i, len(customers), instance_group_id="group-one"))
    return rows


def _wait(manager: ParallelManager, batch_id: str, timeout: float = 8.0):
    end = time.time() + timeout
    while time.time() < end:
        row = manager.get_batch(batch_id)
        if str(row.get("status") or "").upper() == "COMPLETED":
            return row
        time.sleep(0.02)
    raise AssertionError(manager.get_batch(batch_id))


def test_v90_real_autogen_adapter_invokes_modern_agentchat_assistant_tool(monkeypatch):
    import webapp.backend.app.autogen_runtime as runtime

    calls = {"agent": 0, "run": 0, "executor": 0, "closed": 0}

    class FakeCancellationToken:
        def __init__(self): self.cancelled = False
        def cancel(self): self.cancelled = True

    class FakeModelClient:
        async def close(self): calls["closed"] += 1

    class FakeAssistantAgent:
        def __init__(self, **kwargs):
            calls["agent"] += 1
            self.tools = kwargs["tools"]
            assert kwargs["reflect_on_tool_use"] is False
            assert kwargs["max_tool_iterations"] == 1
        async def run(self, *, task=None, cancellation_token=None, **kwargs):
            calls["run"] += 1
            assert "execute" in str(task).lower()
            await self.tools[0]()
            return object()

    monkeypatch.setattr(runtime, "_load_agentchat", lambda: (FakeAssistantAgent, FakeModelClient, FakeCancellationToken))
    monkeypatch.setattr(runtime, "_build_model_client", lambda cls: FakeModelClient())

    result = run_with_autogen_agent(
        agent_name="hip_autogen_test",
        task={"jobId": "q1", "customer": "U-HAUL"},
        executor=lambda: calls.__setitem__("executor", calls["executor"] + 1) or {"jobId": "q1", "status": "PASS"},
    )
    assert calls == {"agent": 1, "run": 1, "executor": 1, "closed": 1}
    assert result["agentFramework"] == "AUTOGEN"
    assert result["autoGenApi"] == "AgentChat"
    assert result["autoGenVersion"] == "0.7.5"
    assert result["autoGenAgentType"] == "AssistantAgent"
    assert result["autoGenAgentName"] == "hip_autogen_test"


def test_v90_any_number_of_jobs_is_wave_capped_at_four_autogen_agents(tmp_path: Path, monkeypatch):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queue(manager, tmp_path / "src", ["U-HAUL"] * 9)
    lock = threading.Lock()
    active = 0
    peak = 0
    called: list[str] = []

    def fake_agent(batch_id, manifest, loop, execution_mode="LIVE"):
        nonlocal active, peak
        with lock:
            active += 1; peak = max(peak, active); called.append(str(manifest["jobId"]))
        time.sleep(0.04)
        with lock: active -= 1
        result = {"jobId": manifest["jobId"], "label": manifest["label"], "customer": manifest["customer"], "status": "PASS", "agentVerdict": "PASS", "elapsedSeconds": 0.04, "executionMode": "LIVE", "blockerDiagnostic": None, "agentFramework": "AUTOGEN"}
        manager._publish(batch_id, {"type": "job.completed", **result}, loop)
        return result

    monkeypatch.setattr(manager, "_run_autogen_agent", fake_agent)
    loop = asyncio.new_event_loop()
    try:
        batch = manager.start_batch([x["jobId"] for x in jobs], 5, loop)
        final = _wait(manager, batch["batchId"])
        assert final["parallelWorkers"] == 4
        assert final["autoGenAgentLimit"] == 4
        assert final["agentFramework"] == "AUTOGEN"
        assert final["knownUnstableAgentCount"] == 5
        assert final["knownUnstableReason"] == "HTTP 429"
        assert peak == 4
        assert len(called) == 9
        assert final["passCount"] == 9
    finally:
        loop.close()


def test_v90_delete_middle_instance_reindexes_group_immediately(tmp_path: Path):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queue(manager, tmp_path / "src", ["U-HAUL"] * 3)
    assert manager.delete_job(jobs[1]["jobId"]) is True
    rows = sorted(manager.list_queue(), key=lambda r: int(r.get("demoInstance") or 0))
    assert len(rows) == 2
    assert [(r["demoInstance"], r["demoInstanceCount"]) for r in rows] == [(1, 2), (2, 2)]
    assert all("Instance" in r["label"] and "/2" in r["label"] for r in rows)


def test_v90_bulk_delete_backend_and_immediate_ui_tombstones():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    assert "deletedJobIdsRef" in page
    assert "setJobs(current=>current.filter" in page
    assert "deleteQueuedJobs([...selected])" in page
    assert "Delete failed and was rolled back immediately" in page
    assert "deleteParallelMany" in api
    assert '/api/parallel/queue/delete-many' in main


def test_v90_frontend_exposes_concise_autogen_concurrency_guardrails():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    models = (ROOT / "webapp/backend/app/models.py").read_text(encoding="utf-8")
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    adapter = (ROOT / "webapp/backend/app/autogen_runtime.py").read_text(encoding="utf-8")
    assert "RUN LIVE EXECUTION" in page
    assert "Parallel AutoGen AgentChat agents" in page
    assert "up to 4 concurrent agents" in page
    assert "Maximum concurrent agents: 4" in page
    assert "Execution model:" not in page
    assert "Actual LIVE API execution:" not in page
    assert "max={4}" in page
    assert "workers: int = Field(default=4, ge=1, le=50)" in models
    assert "autogen-agentchat==0.7.5" in requirements
    assert "autogen-core==0.7.5" in requirements
    assert "autogen-ext[openai]==0.7.5" in requirements
    assert "pyautogen" not in "\n".join(line for line in requirements.splitlines() if not line.lstrip().startswith("#"))
    assert "AssistantAgent" in adapter
    assert "ConversableAgent(" not in adapter
    assert "agent.run(" in adapter


def test_v90_live_runner_keeps_n_api_parallelism_inside_each_autogen_agent():
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    runner = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert 'HIP_API_PARALLEL_ENABLED="1"' in manager
    assert 'HIP_API_MAX_PARALLEL=' in manager
    assert 'ThreadPoolExecutor' in runner
    assert 'deps_for(step_key)' in runner
    assert 'API parallel wave' in runner
    assert 'apiParallelStrategy": "DEPENDENCY_READY"' in runner
