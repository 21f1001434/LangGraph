from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_workspace_navigation_never_writes_instantiated_radio_key_directly():
    for name in ("hip_application_studio.py", "adaptive_uhal_app.py", "easy_studio.py"):
        text = (ROOT / name).read_text(encoding="utf-8")
        assert 'session_state["unified_studio_workspace"] =' not in text
    nav = (ROOT / "streamlit_navigation.py").read_text(encoding="utf-8")
    assert "_pending_unified_studio_workspace" in nav
    assert "apply_pending_workspace" in nav
    assert "request_workspace_switch" in nav


def test_new_configuration_upload_is_obvious_and_can_run_full_live():
    app = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    builder = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    assert "🧭 Build New Configuration" in app
    assert "Build a NEW configuration · choose interface + upload files" in app
    assert "Agent ingest + generate input.json" in builder
    assert "Map to 18 APIs + agent validate" in builder
    assert "RUN FULL CONFIGURATION LIVE" in builder
    assert "run_local_request_checks" in builder


def test_api_testing_area_uses_active_configuration_instead_of_uhal_reload():
    app = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    adaptive = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8")
    api_ui = (ROOT / "api_testing_area_ui.py").read_text(encoding="utf-8")
    assert 'if studio_workspace.startswith("🧪")' in app
    assert 'if studio_workspace.startswith("🧪")' in adaptive
    assert "request_inventory(root, include_migration=True)" in api_ui
    assert "run_single_step(step_key)" in api_ui


def test_interactive_game_graphs_are_packaged():
    req = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    scratch = (ROOT / "scratch_flow_ui.py").read_text(encoding="utf-8")
    graphs = (ROOT / "interactive_graphs.py").read_text(encoding="utf-8")
    assert "plotly" in req.lower()
    assert "st.plotly_chart" in scratch
    assert "mission_flow_figure" in scratch
    assert "execution_latency_figure" in scratch
    assert "Interactive Mission Map" in graphs or "Interactive Scratch-game mission map" in graphs


def test_legacy_filename_navigation_is_hidden_and_brand_fixed():
    nav = (ROOT / "streamlit_navigation.py").read_text(encoding="utf-8")
    app = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    assert "hide_legacy_page_navigation" in nav
    assert "HIP Application Studio" in app
    assert "showSidebarNavigation" not in app  # CSS helper is used instead of version-sensitive config.
