from __future__ import annotations

import scratch_flow
from execution_flow import STEP_DEFINITIONS
from run_agent import Result, Runner
from scratch_flow import execute_scratch_flow, new_component


def _pass_result(seq: int, group: str, api: str, attempt: str, method: str, url_key: str, *args, **kwargs) -> Result:
    return Result(
        sequence=seq,
        group=group,
        api=api,
        attempt=attempt,
        method=method,
        url=f"https://mock.local/{url_key}",
        token_kind=str(kwargs.get("token_kind") or "HIP"),
        scope=str(kwargs.get("scope_override") or ""),
        status_code=200,
        classification="PASS",
        business_success=True,
        elapsed_ms=1,
        payload_file="",
        request_preview="{}",
        response_preview='{"success": true}',
        extracted={},
        deterministic_owner="",
        llm_owner="",
        final_owner="",
        issue="",
        action_required="",
    )


def test_scratch_live_flow_honors_configured_wait(tmp_path, monkeypatch):
    waits = []
    monkeypatch.setattr(scratch_flow.time, "sleep", lambda seconds: waits.append(seconds))
    runner = Runner(llm_enabled=False)
    monkeypatch.setattr(runner, "call", _pass_result)
    flow = {
        "name": "Live pacing",
        "components": [new_component("validate_flow", wait_after_seconds=120, stop_on_blocked=False)],
    }
    report = execute_scratch_flow(tmp_path, runner, flow)
    assert report["completed"] is True
    assert report["passCount"] == 1
    assert waits == [120.0]


def test_every_hip_api_uses_live_scratch_execution_path(tmp_path, monkeypatch):
    runner = Runner(llm_enabled=False)
    calls = []

    def fake_call(*args, **kwargs):
        calls.append(args[2])
        return _pass_result(*args, **kwargs)

    monkeypatch.setattr(runner, "call", fake_call)
    flow = {
        "name": "All 18 through Scratch",
        "components": [new_component(key, stop_on_blocked=False) for key in STEP_DEFINITIONS],
    }
    report = execute_scratch_flow(tmp_path, runner, flow)
    assert report["componentCount"] == 18
    assert report["executedCount"] == 18
    assert report["passCount"] == 18
    assert report["blockedCount"] == 0
    assert report["completed"] is True
    assert len(calls) == 18
