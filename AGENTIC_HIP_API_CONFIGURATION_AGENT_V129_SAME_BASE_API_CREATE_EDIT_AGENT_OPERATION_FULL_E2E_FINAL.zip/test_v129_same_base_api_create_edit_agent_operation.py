from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from execution_flow import (
    ExecutionFlowConfig,
    OPERATION_CAPABLE_STEPS,
    reset_execution_flow,
    save_execution_flow,
    save_operation_mode,
)
from run_agent import Runner
from mcp_bridge import MCPBridge
from uhal_mcp_server import set_api_operation_mode_tool

ROOT = Path(__file__).resolve().parent


def _shape(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _shape(item) for key, item in sorted(value.items())}
    if isinstance(value, list):
        return [_shape(item) for item in value]
    return type(value).__name__


def _runner_with_flow(tmp_path: Path) -> Runner:
    reset_execution_flow(tmp_path)
    runner = Runner(llm_enabled=False)
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    return runner


def test_v129_only_existing_dev_approved_operation_steps_are_agent_writable(tmp_path: Path):
    reset_execution_flow(tmp_path)
    assert set(OPERATION_CAPABLE_STEPS) == {"source_tp", "target_tp", "flow_create"}
    for forbidden in ("account_source", "partner_target", "system_source", "doctype_source", "map", "rule", "flow_deploy"):
        with pytest.raises(ValueError):
            save_operation_mode(tmp_path, forbidden, "edit", source="agent")


def test_v129_source_tp_edit_uses_exact_same_method_and_endpoint_and_shape(tmp_path: Path):
    runner = _runner_with_flow(tmp_path)
    created = runner.preview_step_request("source_tp")
    assert created["payload"]["operation"] == "Create"
    assert created["payload"]["transportProfileDetails"][0]["transportProfileOperation"] == "create"

    save_operation_mode(tmp_path, "source_tp", "edit", source="agent")
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    edited = runner.preview_step_request("source_tp")

    assert edited["method"] == created["method"] == "POST"
    assert edited["urlKey"] == created["urlKey"] == "orch_tp_create"
    assert edited["url"] == created["url"]
    assert _shape(edited["payload"]) == _shape(created["payload"])
    assert edited["payload"]["operation"] == "Edit"
    assert edited["payload"]["transportProfileDetails"][0]["transportProfileOperation"] == "edit"
    assert edited["operationSelection"]["sameBaseApi"] is True
    assert edited["operationSelection"]["applied"] is True


def test_v129_target_tp_edit_uses_exact_same_method_endpoint_and_operation_fields(tmp_path: Path):
    runner = _runner_with_flow(tmp_path)
    created = runner.preview_step_request("target_tp")
    save_operation_mode(tmp_path, "target_tp", "edit", source="agent")
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    edited = runner.preview_step_request("target_tp")

    assert (edited["method"], edited["urlKey"], edited["url"]) == (created["method"], created["urlKey"], created["url"])
    assert _shape(edited["payload"]) == _shape(created["payload"])
    assert edited["payload"]["operation"].lower() == "edit"
    assert edited["payload"]["transportProfileDetails"][0]["transportProfileOperation"].lower() == "edit"


def test_v129_flow_edit_uses_same_orchestration_create_endpoint_and_only_operation_value_changes(tmp_path: Path):
    runner = _runner_with_flow(tmp_path)
    created = runner.preview_step_request("flow_create")
    save_operation_mode(tmp_path, "flow_create", "edit", source="agent")
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    edited = runner.preview_step_request("flow_create")

    assert created["urlKey"] == edited["urlKey"] == "orch_flow_create"
    assert created["method"] == edited["method"] == "POST"
    assert created["url"] == edited["url"]
    assert _shape(created["payload"]) == _shape(edited["payload"])
    assert created["payload"]["operation"].lower() == "create"
    assert edited["payload"]["operation"].lower() == "edit"
    changed = [key for key in created["payload"] if created["payload"][key] != edited["payload"][key]]
    assert changed == ["operation"]


def test_v129_human_execution_flow_save_preserves_operation_mode(tmp_path: Path):
    summary = reset_execution_flow(tmp_path)
    rows = list(summary["steps"])
    for row in rows:
        if row["stepKey"] == "source_tp":
            row["operationMode"] = "edit"
    saved = save_execution_flow(tmp_path, rows, migration_enabled=False)
    source = next(row for row in saved["steps"] if row["stepKey"] == "source_tp")
    assert source["operationMode"] == "edit"
    assert source["operationCapable"] is True
    assert source["operationPaths"] == ["operation", "transportProfileDetails.0.transportProfileOperation"]


def test_v129_mcp_agent_tool_changes_only_operation_selector(tmp_path: Path):
    reset_execution_flow(tmp_path)
    result = set_api_operation_mode_tool("flow_create", "edit", str(tmp_path))
    assert result["ok"] is True
    assert result["mode"] == "edit"
    assert result["sameBaseApi"] is True
    assert result["methodChanged"] is False
    assert result["urlChanged"] is False
    assert result["requestStructureChanged"] is False
    assert result["agentOperationEditAllowed"] is True
    assert result["agentArbitraryPayloadEditAllowed"] is False
    assert ExecutionFlowConfig(tmp_path).operation_mode("flow_create") == "edit"


def test_v129_mcp_agent_tool_rejects_invented_edit_operation_on_other_api(tmp_path: Path):
    reset_execution_flow(tmp_path)
    result = set_api_operation_mode_tool("doctype_source", "edit", str(tmp_path))
    assert result["ok"] is False
    assert "no Dev-approved" in result["error"]
    assert ExecutionFlowConfig(tmp_path).operation_mode("doctype_source") == "inherit"


def test_v129_tp_audit_follows_effective_edit_when_execution_mode_inherits(tmp_path: Path):
    reset_execution_flow(tmp_path)
    runner = Runner.__new__(Runner)
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    runner.source_tp = lambda: {"profile_name": "SRC"}
    runner.target_tp = lambda: {"profile_name": "TGT"}
    runner.preview_step_request = lambda step: {"payload": {"operation": "Edit"}}
    body = {
        "data": [
            {"operation": "CREATE", "status": "FAILED"},
            {"operation": "EDIT", "status": "SUCCESS"},
        ]
    }
    classification, ok = runner.validate_step_business_result(
        "tp_audits", body, "PASS_SUCCESS", True, params={"transportProfileName": "SRC"}
    )
    assert ok is True
    assert classification == "PASS_SUCCESS"


def test_v129_as2_receiver_ssl_certificate_confirmed_default_is_in_active_runtime():
    runner = Runner(llm_enabled=False)
    params = runner.tp_parameters(
        {"profile_usage": "Receiver", "interface_type": "HTTPS-AS2", "interface_parameters": {}},
        "target",
    )
    assert params["SSL Certificate"] == "dellroot_ca_6_able.crt"



def test_v129_inherit_rejects_mixed_tp_create_edit_values(tmp_path: Path):
    runner = _runner_with_flow(tmp_path)
    factory = {
        "method": "POST", "url_key": "orch_tp_create", "suffix": "",
        "payload": runner.tp_orch_payload(runner.source_tp(), "source"),
    }
    factory["payload"]["operation"] = "Edit"
    factory["payload"]["transportProfileDetails"][0]["transportProfileOperation"] = "create"
    with pytest.raises(ValueError, match="operation fields disagree"):
        runner.apply_execution_operation_mode("source_tp", factory)


def test_v129_human_execution_flow_records_user_operation_source(tmp_path: Path):
    summary = reset_execution_flow(tmp_path)
    rows = list(summary["steps"])
    for row in rows:
        if row["stepKey"] == "flow_create":
            row["operationMode"] = "edit"
    saved = save_execution_flow(tmp_path, rows, migration_enabled=False, operation_source="user")
    flow = next(row for row in saved["steps"] if row["stepKey"] == "flow_create")
    assert flow["operationMode"] == "edit"
    assert flow["operationModeSource"] == "user"

def test_v129_frontend_and_backend_expose_governed_operation_selector():
    types = (ROOT / "webapp/frontend/src/types.ts").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    builder = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    backend = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    assert "operationMode?:'inherit'|'create'|'edit'" in types
    assert "setApiOperationMode" in api
    assert "operationMode:operationMode||'inherit'" in api
    assert "SAME CREATE/EDIT API" in builder
    assert 'api-operation/{step_key}' in backend
    assert "CREATE_EDIT_SAME_API_INVARIANT_BROKEN" in backend


def test_v129_mcp_bridge_exposes_operation_tool_to_agent(tmp_path: Path):
    reset_execution_flow(tmp_path)
    bridge = MCPBridge(tmp_path, enabled=True, required=False)
    assert "set_api_operation_mode" in bridge.status()["toolNames"]
    assert bridge.status()["toolCoverage"]["sameBaseApiCreateEdit"] is True
    result = bridge.set_api_operation_mode("source_tp", "edit")
    assert result["ok"] is True
    assert ExecutionFlowConfig(tmp_path).operation_mode("source_tp") == "edit"
