from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

import run_agent
from canonical_payload_contract import catalog_summary, interface_shape_summary, lock_request_value
from interface_registry import BUILTIN_INTERFACES
from migration_api_contract import MIGRATION_STEP_DEFINITIONS, migration_catalog
from scratch_flow import ALL_STEP_DEFINITIONS, new_component

ROOT = Path(__file__).resolve().parent

NAS_SOURCE_KEYS = [
    "Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern",
    "Polling Interval", "Post File Transfer Action NAS", "Cron Expression",
]
NAS_TARGET_KEYS = ["Protocol", "Server Name", "Server Path", "AD Group"]
RABBIT_KEYS = ["Interface Environment", "Exchange Name"]


def runner() -> run_agent.Runner:
    return run_agent.Runner(llm_enabled=False)


def test_v122_nas_and_rabbitmq_are_registered_with_exact_dev_shapes():
    assert "NAS" in BUILTIN_INTERFACES
    assert "Rabbit MQ" in BUILTIN_INTERFACES
    summary = interface_shape_summary(include_additive=True)
    assert set(summary["families"]) == {"FILE", "HTTPS", "HTTPS_AS2"}
    fam = summary["allFamilies"]
    assert fam["NAS"]["sourceKeys"] == NAS_SOURCE_KEYS
    assert fam["NAS"]["targetKeys"] == NAS_TARGET_KEYS
    assert fam["RABBIT_MQ"]["sourceKeys"] == RABBIT_KEYS
    assert fam["RABBIT_MQ"]["targetKeys"] == RABBIT_KEYS


def test_v122_nas_source_materializer_exact_keys_and_rules():
    payload = runner().tp_parameters({
        "interface_type": "NAS",
        "profile_usage": "Sender",
        "interface_parameters": {
            "Protocol": "NFS",
            "Server Name": "10.20.30.25",
            "Server Path": "/var/data/files",
            "AD Group": "HarmonyNASUsersSIT",
            "File Filtering Pattern": "*.xml",
            "Polling Interval": "Every Hour",
            "Post File Transfer Action NAS": "Delete",
            "Cron Expression": "",
            "Unknown Attribute": "must-drop",
        },
    }, "source")
    assert list(payload) == NAS_SOURCE_KEYS
    assert "Unknown Attribute" not in payload
    assert payload["Post File Transfer Action NAS"] == "Delete"


def test_v122_nas_nfs_rejects_non_delete_and_cron_requires_expression():
    with pytest.raises(ValueError, match="INVALID_INTERFACE_VALUE"):
        runner().tp_parameters({"interface_type":"NAS","interface_parameters":{"Protocol":"NFS","Post File Transfer Action NAS":"Rename"}}, "source")
    with pytest.raises(ValueError, match="MISSING_INTERFACE_VALUE"):
        runner().tp_parameters({"interface_type":"NAS","interface_parameters":{"Protocol":"SMB","Post File Transfer Action NAS":"Rename","Polling Interval":"Cron Expression"}}, "source")


def test_v122_rabbitmq_materializer_and_environment_enum():
    payload = runner().tp_parameters({
        "interface_type":"Rabbit MQ",
        "interface_parameters":{"Interface Environment":"TEST","Exchange Name":"Test_Exchange_Name","Queue Name":"must-drop"},
    }, "source")
    assert payload == {"Interface Environment":"TEST","Exchange Name":"Test_Exchange_Name"}
    with pytest.raises(ValueError, match="INVALID_INTERFACE_VALUE"):
        runner().tp_parameters({"interface_type":"Rabbit MQ","interface_parameters":{"Interface Environment":"UAT","Exchange Name":"x"}}, "source")


def test_v122_canonical_lock_drops_unknown_nas_parameter_and_enforces_enum():
    body = {
        "interfaceType":"NAS",
        "propertyMap": {
            "Protocol":"SMB", "Server Name":"server", "Server Path":"/data", "AD Group":"group",
            "File Filtering Pattern":"*.xml", "Polling Interval":"Every Hour",
            "Post File Transfer Action NAS":"Move To Archive", "Cron Expression":"", "Invented":"x",
        },
        "transportProfileName":"NAS_SRC", "hipEnvironment":"DEV",
    }
    locked, meta = lock_request_value("validate_source", "payload", body, interface_family="NAS")
    assert "Invented" not in locked["propertyMap"]
    assert locked["propertyMap"]["Protocol"] == "SMB"
    bad = deepcopy(body); bad["propertyMap"]["Protocol"] = "FTP"
    with pytest.raises(ValueError, match="INVALID_INTERFACE_VALUE"):
        lock_request_value("validate_source", "payload", bad, interface_family="NAS")


def test_v122_migration_catalog_is_additive_18_plus_7_not_default_pipeline_replacement():
    summary = catalog_summary()
    assert summary["stepCount"] == 18
    assert summary["migrationStepCount"] == 7
    assert summary["totalRegisteredStepCount"] == 25
    rows = migration_catalog()
    assert len(rows) == 7
    assert rows[0]["order"] == 19 and rows[-1]["order"] == 25
    assert set(MIGRATION_STEP_DEFINITIONS).issubset(ALL_STEP_DEFINITIONS)
    assert new_component("migrate_flow")["stepKey"] == "migrate_flow"


def test_v122_migration_urls_exactly_match_supplied_dev_endpoints():
    urls = run_agent.hip_config_service_urls("https://host/hip-config-service")
    assert urls["migration_document_type"].endswith("/api/migration/orchestration/document-type")
    assert urls["migration_data_map"].endswith("/api/migration/orchestration/data-map")
    assert urls["migration_rule"].endswith("/api/migration/orchestration/rule")
    assert urls["migration_transport_profile"].endswith("/api/migration/orchestration/transport-profile")
    assert urls["migration_flow"].endswith("/api/migration/orchestration/flow")


def test_v122_migration_payloads_use_current_canonical_objects_and_human_editable_target_env(monkeypatch):
    monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "TEST2")
    r = runner()
    source = r.preview_step_request("migrate_doctype_source")
    assert source["method"] == "POST"
    assert source["payload"]["sourceEnvironment"] == r.env
    assert source["payload"]["targetEnvironment"] == "TEST2"
    assert source["payload"]["documentTypeName"] == r.source_doc()["name"]
    tp = r.preview_step_request("migrate_source_tp")["payload"]
    assert tp["transportProfileName"] == r.source_tp()["profile_name"]
    assert tp["transportProfileInterfaceType"] == r.tp_interface_type(r.source_tp())
    assert tp["transportProfileInterfaceParameters"] == r.tp_parameters(r.source_tp(), "source")


def test_v122_migration_target_environment_is_not_silently_hardcoded_from_screenshot(monkeypatch):
    monkeypatch.delenv("HIP_MIGRATION_TARGET_ENVIRONMENT", raising=False)
    payload = runner().preview_step_request("migrate_flow")["payload"]
    assert payload["targetEnvironment"] == ""
    assert payload["targetEnvironment"] != "TEST2"


def test_v122_migration_tp_nested_attributes_are_schema_locked():
    body = {
        "sourceEnvironment":"DEV", "targetEnvironment":"TEST2",
        "transportProfileName":"NAS_SRC", "transportProfileInterfaceType":"NAS",
        "transportProfileInterfaceParameters": {
            "Protocol":"NFS", "Server Name":"server", "Server Path":"/data", "AD Group":"group",
            "File Filtering Pattern":"*.xml", "Polling Interval":"Every Hour",
            "Post File Transfer Action NAS":"Delete", "Cron Expression":"", "NewField":"blocked",
        },
    }
    locked, meta = lock_request_value("migrate_source_tp", "payload", body, interface_family="NAS")
    assert "NewField" not in locked["transportProfileInterfaceParameters"]
    assert meta["locked"] is True


def test_v122_react_surfaces_expose_additive_catalog_for_edit_test_and_flow_game():
    api_testing=(ROOT/"webapp/frontend/src/pages/ApiTestingPage.tsx").read_text(encoding="utf-8")
    builder=(ROOT/"webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    flow=(ROOT/"webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    assert "all_api_catalog" in api_testing and "migration_api_catalog" in api_testing
    assert "all_api_catalog" in builder and "migration_api_catalog" in builder
    assert "all_api_catalog" in flow and "migration_api_catalog" in flow
    assert "'Migration'" in flow


def test_v122_migration_live_preflight_requires_only_hip_and_aia_credentials(monkeypatch):
    r = runner()
    monkeypatch.setattr(r, "migration_preflight", lambda: {
        "buildId": run_agent.BUILD_ID, "mode": "MIGRATION_PREFLIGHT", "ready": True,
        "sourceEnvironment": "DEV", "targetEnvironment": "TEST", "items": [],
    })
    r.hip_token_url = "https://token"
    r.hip_client_id = "id"
    r.hip_client_secret = "secret"
    r.account_token_url = r.account_client_id = r.account_client_secret = ""
    r.partner_token_url = r.partner_client_id = r.partner_client_secret = ""
    r.system_token_url = r.system_client_id = r.system_client_secret = ""
    monkeypatch.setattr(r.judge, "available", lambda: True)
    monkeypatch.setattr(r.payload_overrides, "summary", lambda: {"valid": True, "errors": []})
    monkeypatch.setattr(r.mcp, "status", lambda: {"status": "OK"})
    gate = r.migration_live_preflight()
    assert gate["ready"] is True
    assert gate["credentialProfiles"]["hipConfig"]["required"] is True
    assert gate["credentialProfiles"]["dellAia"]["required"] is True
    for name in ("account", "partner", "system"):
        assert gate["credentialProfiles"][name]["required"] is False


def test_v122_migration_pipeline_never_calls_live_api_when_preflight_is_blocked(monkeypatch):
    r = runner()
    monkeypatch.setattr(r, "migration_preflight", lambda: {"ready": False, "items": []})
    called = []
    monkeypatch.setattr(r, "run_single_step", lambda key: called.append(key))
    result = r.run_migration_pipeline()
    assert result["executed"] is False
    assert result["status"] == "MIGRATION_PREFLIGHT_BLOCKED"
    assert called == []


def test_v122_migration_pipeline_executes_applicable_blocks_in_published_safe_order(monkeypatch):
    r = runner()
    monkeypatch.setattr(r, "migration_preflight", lambda: {"ready": True, "items": []})
    monkeypatch.setattr(r, "step_applicable", lambda key: key not in {"migrate_map", "migrate_rule"})
    monkeypatch.setattr(r, "applicability_reason", lambda key: "passthrough")
    monkeypatch.setattr(r, "enforce_live_id_integrity", lambda *args, **kwargs: None)
    called = []

    def fake_run(key):
        called.append(key)
        return run_agent.Result(
            sequence=len(called), group="Migration", api=key, attempt="test", method="POST",
            url="https://host/api/migration", token_kind="HIP", scope="", status_code=200,
            classification="PASS", business_success=True, elapsed_ms=1, payload_file="",
            request_preview="{}", response_preview='{"status":"ok"}', extracted={},
            deterministic_owner="deterministic", llm_owner="", final_owner="deterministic",
            issue="", action_required="", error="",
        )

    monkeypatch.setattr(r, "run_single_step", fake_run)
    result = r.run_migration_pipeline()
    expected = [key for key in run_agent.MIGRATION_ORDER if key not in {"migrate_map", "migrate_rule"}]
    assert called == expected
    assert result["status"] == "PASS"
    skipped = {row["stepKey"] for row in result["results"] if row.get("status") == "NOT_APPLICABLE"}
    assert skipped == {"migrate_map", "migrate_rule"}


def test_v122_builtin_flow_game_has_full_migration_template():
    from webapp.backend.app.templates import builtin_templates
    templates = {row["id"]: row for row in builtin_templates()}
    template = templates["builtin-environment-migration-all-published-objects"]
    assert [node["api_key"] for node in template["nodes"]] == list(run_agent.MIGRATION_ORDER)
    assert len(template["edges"]) == len(run_agent.MIGRATION_ORDER) - 1
    assert template["lifecycle"] == "PUBLISHED"


def test_v122_env_example_exposes_migration_environment_inputs_without_example_business_default():
    env_text = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert "HIP_MIGRATION_SOURCE_ENVIRONMENT=" in env_text
    assert "HIP_MIGRATION_TARGET_ENVIRONMENT=" in env_text
    assert "HIP_MIGRATION_TARGET_ENVIRONMENT=TEST2" not in env_text
