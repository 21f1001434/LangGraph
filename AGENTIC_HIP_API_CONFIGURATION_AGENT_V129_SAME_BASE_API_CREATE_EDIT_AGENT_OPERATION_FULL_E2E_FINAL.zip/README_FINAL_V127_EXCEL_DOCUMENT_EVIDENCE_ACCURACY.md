# V127 — Evidence-Accurate Excel Mapping + End-to-End Execution Hardening

## Purpose
V127 corrects Excel → API mapping for Document Type identity and extends the same no-fabrication rule through raw-file extraction, guided configuration, dependent API references and Migration requests. `Document Type Name` and `Document Type Version` are independent business values and cannot be substituted for each other.

## Authoritative mapping rules
- Document Type Name is read only from an exact name column for the matching API role.
- Document Type Version is read only from an exact version column or from strict `NAME(version)` syntax in the name cell.
- An explicit version column wins over a version embedded in `NAME(version)`.
- If no version exists in the workbook row, the mapper suppresses inherited/default `1` or `1.0`, leaves the proposed version blank, and marks the row `NEEDS_INPUT` when the API requires it.
- A version-like value such as `1`, `1.0`, or `2.5` in a Document Type Name column is rejected as a name.
- Dell AIA mapping hints pass the same deterministic guard and cannot cross-map name/version fields.
- Rule `name/version` are never overwritten by Document Type Name/Version; the Rule API uses `documentTypeName/documentTypeVersion` for document evidence.
- Standalone Document Type Create uses its own `name/version` leaves only when that Document Type API is selected.
- Source/Target roles remain separate; evidence for one role is not silently copied to the other.

## No-fabrication beyond the Excel page
- Raw-file builder no longer creates Source/Target Document Type version `1`/`1.0` when source evidence is absent.
- Guided configuration keeps Source Document Type, Target Document Type, Data Map, Rule and Flow versions separate and explicit.
- Transport Profile, Rule and Flow document references become `NAME(version)` only when both values are known.
- Migration Document Type/Map/Rule/Flow payloads use only explicitly available canonical versions. Missing versions block Migration preflight rather than defaulting to `1`.
- Generic XML `<ROUTING destination_value=... source_value=...>` evidence is now extracted for Rule/Flow routing identity, while Partner Create DUNS/value remains a separate Dev-approved identity and is never inferred from the routing ID.

## Human governance and execution
Analysis remains non-mutating. Only `GOOD_TO_TRIGGER` Excel rows can be approved/staged. Human payload editing remains value-only/structure-locked in Build Configuration, API Testing Area and API Flow Game. Agent/Dell-AIA may inspect, map, explain and validate but cannot persist payload values or execution-flow changes.

V126 execution controls remain intact:
- Migration ON/OFF is an explicit human choice and defaults OFF.
- 18 base + 7 Migration logical blocks are registered.
- The user can save a dependency-safe exact sequential execution order.
- Saved execution plans survive clone/export/import and refresh queued/not-yet-running snapshots.
- LEGRAND TP name edits propagate to canonical configuration and queued snapshots before execution.

## Execution-path validation
The offline production integration harness executes the complete 18-step base pipeline through the same Runner request factories and response-processing boundary used by LIVE execution. It validates validation calls, Account/Partner/System, Document Types, Map, Rule, Source/Target TP orchestration, TP audits, Flow Create, Flow Deploy and Flow History with runtime dependency IDs propagated across steps.

External Dell HIP endpoints are not called by the release validator because this environment does not have the user's production credentials/network context. LIVE HTTP behavior therefore still depends on the real environment, OAuth credentials and Dev endpoint availability.
