# V112 — Latest 02:17 LIVE Run Fixes

## Scope

V112 is based on V111 and addresses the two application-side defects visible in the LIVE batch captured at approximately 02:17 on 2026-08-31. It preserves V108+ no-reuse and immutable-request rules and does not alter the developer-approved Mapping Rule POST contract.

## 1. LEGRAND pre-LIVE Flow-name split-brain fixed

The latest report still showed `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` (43 characters) even though V110/V111 had already generated the valid nested BizFlow name `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 characters) in some paths.

Root cause: a persisted configuration can contain two Flow-name representations:

- top-level `profile_name`
- `objects.biz_flow.flow_details.business_flow_name`

V111 returned early when the nested value was already valid, leaving a stale top-level value untouched. Some final-preflight/report paths then read the stale top-level value.

V112 reconciles both representations before LIVE materialization. One deterministic HIP-valid canonical name is selected and written to both locations. The queue snapshot, isolated staged workspace, and direct `Runner` initialization all use this normalization before API request construction.

This is canonical input normalization, not a post-response API-payload mutation.

## 2. U-HAUL current-LIVE Rule ID resolution hardened

The latest U-HAUL run reached PASS/EXISTING through Rule and both TP audits, but Flow Create was blocked by `LIVE_RULE_ID_UNRESOLVED`. The canonical Rule POST was correctly executed and HIP reported that the Rule already exists, but the duplicate response contained no numeric `ruleId`.

V111 attempted targeted Rule detail/summary queries and pagination. The actual SecureLink Rules evidence shows that the principal Rules inventory API is also loaded as plain `GET /api/rule/summary`, with environment-specific `versions[]` entries containing `ruleId`.

V112 adds these GET-only current-LIVE read shapes:

1. exact targeted Rule details queries;
2. exact targeted Rule summary/search queries;
3. **plain Rule summary GET with no query parameters**;
4. summary GET with only `hipEnvironment=DEV`;
5. summary GET with only `environment=DEV`;
6. exact targeted GET on the Rule collection root where supported;
7. bounded deterministic summary pagination using `page/size` and `pageNumber/pageSize`.

The resolver accepts an ID only when the current response matches the exact Rule name, exact version, and DEV environment. Zero matches fail closed. Multiple exact IDs fail closed as ambiguous. The known U-HAUL Rule ID from historical/KB evidence is **not** hardcoded or injected.

Every resolution request is GET-only and sends no body. The original Rule POST is not changed or retried with a different payload.

## Mapping Rule contract remains immutable

The standalone Mapping Rule continues to contain:

- `documentTypeName` + `documentTypeVersion`
- `actions[].params.mapIdentifier` + `mapVersion`

and continues to omit:

- `documentTypeId`
- `flowDefinitionId`
- `actions[].params.mapId`

## Latest-run behavior already proven correct and retained

The supplied 02:17 U-HAUL report demonstrates that these prior fixes are working and are preserved:

- Source TP unique validation PASS
- Target TP unique validation PASS
- Flow-name validation executed
- Source/Target Document Type duplicate responses PASS / EXISTING
- Source/Target TP Create duplicate responses PASS / EXISTING
- MAC Map duplicate response PASS / EXISTING
- Mapping Rule duplicate response PASS / EXISTING
- Source TP CREATE audit PASS
- Target TP CREATE audit PASS

## External Dell route condition

Account source/target, Partner and System still return the Dell gateway message that the configured upstream PCF route does not exist/is not deployed. V112 continues to classify this as `API_UPSTREAM_ROUTE_UNAVAILABLE`. It does not mutate those approved request payloads or falsely claim those API calls succeeded.

If the API team provides replacement routes, continue to use:

- `HIP_ACCOUNT_API_URL`
- `HIP_PARTNER_API_URL`
- `HIP_SYSTEM_API_URL`

## Optional Rule read controls

- `HIP_RULE_SUMMARY_API_URL`
- `HIP_RULE_DETAILS_API_URL`
- `HIP_RULE_LEGACY_READ_BASE_URL`
- `HIP_RULE_PORTAL_READ_BASE_URL`
- `HIP_RULE_LOOKUP_MAX_PAGES` (default 25)
- `HIP_RULE_LOOKUP_PAGE_SIZE` (default 500)

Read endpoints must be HTTPS and Dell-owned hosts.

## Validation

V112 source validation:

- Application tests: **395/395 PASS**.
- Backend/FastAPI tests: **48/48 PASS** (443/443 combined).
- Package validator: 58/58 PASS.
- Adaptive validator: 60/60 PASS.
- Business readiness: 69/69 PASS.
- Final release: 16/16 PASS.
- Required self-check: 45/45 PASS.
- Phases 1–6: PASS.

No authenticated Dell/HIP mutation was executed while packaging V112.
