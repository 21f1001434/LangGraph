from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from webapp.backend.app import main
from webapp.backend.app.models import ParallelSourcesQueueCreate
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.phase2_service import validate_configuration
from webapp.backend.app.storage import JsonStore
from parallel_configurations import _SNAPSHOT_DIRS, _SNAPSHOT_FILES

ROOT = Path(__file__).resolve().parent


def _copy_valid_workspace(destination: Path, customer: str) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    for name in _SNAPSHOT_FILES:
        src = ROOT / name
        if src.exists() and src.is_file():
            shutil.copy2(src, destination / name)
    for name in _SNAPSHOT_DIRS:
        src = ROOT / name
        if src.exists() and src.is_dir():
            shutil.copytree(src, destination / name, dirs_exist_ok=True)
    data = json.loads((destination / "input.json").read_text(encoding="utf-8"))
    data["customer"] = customer
    data["profile_name"] = f"{customer}_VALIDATED_PROFILE"
    (destination / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    return destination


def test_v49_parallel_sources_offer_uhal_and_saved_validated_customer(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    monkeypatch.setattr(main, "STORE", store)
    monkeypatch.setattr(main, "PARALLEL", manager)

    config = store.create_configuration({
        "name": "LEGRAND_TEST", "customer": "LEGRAND_TEST", "direction": "Outbound",
        "transaction_code": "856", "transaction_name": "", "flow_type": "Auto",
        "source_interface": "SFTP", "target_interface": "SFTP", "input_mode": "files", "user_instructions": "",
    })
    ws = Path(config["workspace"])
    _copy_valid_workspace(ws, "LEGRAND_TEST")
    validation = validate_configuration(ws)
    assert validation["ok"] is True
    store.update_configuration(config["id"], {"validation": validation, "status": "VALIDATED"})

    sources = main.parallel_sources()
    by_id = {row["sourceId"]: row for row in sources}
    assert by_id["reference:uhal"]["customer"] == "U-HAUL"
    assert by_id["reference:uhal"]["validated"] is True
    assert by_id["reference:uhal"]["validCount"] == 18
    assert by_id[config["id"]]["customer"] == "LEGRAND_TEST"
    assert by_id[config["id"]]["validated"] is True


def test_v49_queue_selected_different_customers_creates_two_isolated_ready_jobs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    monkeypatch.setattr(main, "STORE", store)
    monkeypatch.setattr(main, "PARALLEL", manager)

    config = store.create_configuration({
        "name": "LEGRAND_TEST", "customer": "LEGRAND_TEST", "direction": "Outbound",
        "transaction_code": "856", "transaction_name": "", "flow_type": "Auto",
        "source_interface": "SFTP", "target_interface": "SFTP", "input_mode": "files", "user_instructions": "",
    })
    ws = Path(config["workspace"])
    _copy_valid_workspace(ws, "LEGRAND_TEST")
    validation = validate_configuration(ws)
    store.update_configuration(config["id"], {"validation": validation, "status": "VALIDATED"})

    result = main.parallel_queue_sources(ParallelSourcesQueueCreate(source_ids=["reference:uhal", config["id"]]))
    assert result["created"] == 2
    assert result["errors"] == []
    assert {row["customer"] for row in result["items"]} == {"U-HAUL", "LEGRAND_TEST"}
    assert {row["sourceId"] for row in result["items"]} == {"reference:uhal", config["id"]}

    queued = manager.list_queue()
    assert len(queued) == 2
    assert all(row["ready"] for row in queued)
    assert len({row["workspace"] for row in queued}) == 2
    assert {row["customer"] for row in queued} == {"U-HAUL", "LEGRAND_TEST"}


def test_v49_parallel_ui_exposes_multi_customer_selection_and_auto_selects_queued_jobs():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    assert "VALIDATED CUSTOMERS" in page
    assert "Select U-HAUL + active" in page
    assert "Add selected customers to queue" in page
    assert "queueParallelSources(selectedSources)" in page
    assert "setSelected(createdIds)" in page
    assert "RUN LIVE EXECUTION" in page
    assert "/api/parallel/sources" in api
    assert "/api/parallel/queue-sources" in api
