from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from unittest.mock import patch

import production_guard
import run_agent


class _TokenResponse:
    status_code = 200
    ok = True
    text = json.dumps({"access_token": "v93.test.token"})
    url = "https://example.dell.com/oauth/token"
    headers = {"Content-Type": "application/json"}
    history = []

    def json(self):
        return {"access_token": "v93.test.token"}


class _TokenSession:
    def __init__(self):
        self.trust_env = True

    def post(self, url, **kwargs):
        return _TokenResponse()

    def close(self):
        return None


def _runner():
    runner = run_agent.Runner.__new__(run_agent.Runner)
    runner.hip_token_url = "https://example.dell.com/oauth/token"
    runner.hip_client_id = "client"
    runner.hip_client_secret = "secret"
    runner.hip_scope = ""
    runner.__dict__.pop("token_sources", None)
    runner.__dict__.pop("hip_token_user_agent", None)
    return runner


def test_v93_successful_oauth_is_not_failed_by_winerror5_diagnostic_write():
    """Exact field failure from the user's LIVE report must be non-fatal."""
    run_agent.TOKEN_CACHE.clear()
    runner = _runner()

    def denied(*args, **kwargs):
        raise PermissionError(5, "Access is denied")

    with patch.object(run_agent.requests, "Session", _TokenSession), patch.object(
        run_agent.requests.utils, "get_environ_proxies", return_value={}
    ), patch.object(run_agent, "atomic_write_json", side_effect=denied):
        token = runner.get_token("HIP")

    assert token == "v93.test.token"
    assert runner.token_sources["HIP"] == "oauth2-client-credentials-basic-auth"


def test_v93_token_diagnostic_latest_writes_are_serialized(tmp_path: Path):
    """Parallel HIP calls must not replace the same latest JSON concurrently."""
    active = 0
    maximum_active = 0
    gate = threading.Lock()

    def observed_write(path, value, **kwargs):
        nonlocal active, maximum_active
        with gate:
            active += 1
            maximum_active = max(maximum_active, active)
        time.sleep(0.015)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(value), encoding="utf-8")
        with gate:
            active -= 1

    with patch.object(run_agent, "REPORTS", tmp_path), patch.object(
        run_agent, "atomic_write_json", side_effect=observed_write
    ):
        threads = [
            threading.Thread(
                target=run_agent._write_token_diagnostic_best_effort,
                args=("HIP", {"status": 200, "tokenFound": True, "n": i}),
            )
            for i in range(8)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=5)

    assert all(not thread.is_alive() for thread in threads)
    assert maximum_active == 1
    assert (tmp_path / "hip_token_diagnostics_latest.json").exists()


def test_v93_atomic_write_retries_transient_windows_replace_denial(tmp_path: Path):
    target = tmp_path / "reports" / "hip_token_diagnostics_latest.json"
    real_replace = os.replace
    attempts = 0

    def flaky_replace(source, destination):
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise PermissionError(5, "Access is denied", str(destination))
        return real_replace(source, destination)

    with patch.object(production_guard.os, "replace", side_effect=flaky_replace):
        production_guard.atomic_write_text(target, '{"ok":true}', retries=5)

    assert attempts == 3
    assert target.read_text(encoding="utf-8") == '{"ok":true}'



def test_v93_parallel_runner_policy_code_cannot_override_clean_agent_evidence():
    from webapp.backend.app.parallel_manager import _final_status_from_runner

    assert _final_status_from_runner(return_code=2, agent_verdict="PASS", hard_agent_failures=0) == "PASS"
    assert _final_status_from_runner(return_code=2, agent_verdict="WARNING", hard_agent_failures=0) == "WARNING"
    assert _final_status_from_runner(return_code=2, agent_verdict="FAIL", hard_agent_failures=1) == "FAIL"
    assert _final_status_from_runner(return_code=2, agent_verdict="PASS", hard_agent_failures=1) == "BLOCKED"
    assert _final_status_from_runner(return_code=0, agent_verdict="PASS", hard_agent_failures=0, timed_out=True) == "BLOCKED"


def test_v93_explicit_already_exists_is_pass_but_downstream_inference_is_disabled():
    from report_insights import analyze_api_response, reconcile_execution_analyses

    existing = analyze_api_response({
        "status_code": 500,
        "classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD",
        "response_preview": "Object already exists",
        "business_success": False,
    })
    assert existing["verdict"] == "PASS"
    assert existing["outcome"] == "EXISTING"

    recovered = reconcile_execution_analyses([
        {"status_code": 500, "classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", "response_preview": "create error", "extracted": {"logicalStepKey": "account_source"}},
        {"status_code": 201, "classification": "PASS_SUCCESS", "business_success": True, "response_preview": "created", "extracted": {"logicalStepKey": "source_tp"}},
    ])
    assert recovered[0]["verdict"] == "FAIL"
    assert recovered[0]["outcome"] == "API_ERROR"

def test_v93_release_manifest_documents_winerror5_fix():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "LIVE_ONLY_RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    fix = manifest.get("winError5Fix") or {}
    assert str(manifest.get("version") or "").startswith("V")
    assert "WinError 5" in str(fix.get("issue"))
    assert fix.get("parallelWriteSerialization") is True
    assert "no longer overridden" in str(fix.get("behavior"))
