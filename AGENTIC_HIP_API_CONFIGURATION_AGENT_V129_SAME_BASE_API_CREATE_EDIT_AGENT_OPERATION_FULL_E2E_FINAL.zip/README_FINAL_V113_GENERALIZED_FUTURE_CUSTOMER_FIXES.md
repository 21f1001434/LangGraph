# V113 — Generalized Future-Customer LIVE Hardening

## Why this release exists

The 02:55 LIVE batch showed that the remaining application-side U-HAUL blocker was Rule identity resolution (`LIVE_RULE_ID_UNRESOLVED`) and that the parallel summary could hide that real blocker behind a generic "Final pre-LIVE safety gate" message. It also prompted a review of whether the LEGRAND 40-character Flow-name fix was customer-specific. V113 makes these protections generic for all present and future customers.

## Generic Flow-name policy

- Maximum HIP Flow name length: 40.
- Applies to every customer and every build/import/queued/staged path.
- Allowed characters and starting-character rules are validated before LIVE execution.
- Structural HIP tokens may be shortened deterministically: PASSTHROUGH→PASS, MAPPING→MAP, TRANSLATION→TRN, INBOUND→IB, OUTBOUND→OB.
- Customer/business tokens are not rewritten.
- If the name remains too long, a stable SHA-256-derived digest is inserted while preserving right-hand transaction/flow/direction tokens.
- All known Flow-name aliases are reconciled before request materialization.
- Normalization is pure/copy-based so repaired aliases are reliably written to queued/staged input instead of existing only in memory.
- No post-HTTP rename is permitted.

The LEGRAND value remains `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 chars), but no LEGRAND-specific string replacement is required.

## Generic current-LIVE Rule identity resolution

The canonical Rule POST is still executed unchanged. If it returns success/existing without a numeric ID, V113 performs GET-only current-LIVE identity reads. The resolver:

- requires exact Rule name + exact version + exact environment;
- supports common JSON row/list/page/environment/version response shapes;
- supports current HTML/text wrappers only when name, version, environment and explicit ID marker coexist in the same bounded response evidence;
- accepts standards-compliant Location/Content-Location identity from the current response;
- supports configured Rule summary/details endpoints, approved/config-service/legacy/portal read surfaces, and optional `HIP_RULE_READ_BASE_URL`;
- uses bounded deterministic pagination;
- rejects missing or ambiguous matches;
- never reads a Rule ID from a packaged KB, historical run, local report, or hardcoded customer mapping.

## Immutable API contract retained

Standalone Mapping Rule continues to use Document Type name/version and Map identifier/version and continues to omit `documentTypeId`, `flowDefinitionId`, and `actions[].params.mapId`. Changed mutation retries remain blocked.

## Accurate batch diagnostics

The parallel summary now selects the real BLOCKED canonical API/dependency before independent foundation failures. If detailed rows are unavailable, it names the non-passing canonical step instead of presenting a generic final safety gate as the root cause.

## Account / Partner / System route condition

The current Dell gateway response that its upstream PCF route does not exist/is not deployed is external. Earlier evidence shows the same gateway API paths have reached working/existing backend services, so V113 does not invent a replacement route. Use `HIP_ACCOUNT_API_URL`, `HIP_PARTNER_API_URL`, and `HIP_SYSTEM_API_URL` when the API team provides replacements.

## Validation

- Top-level application tests: 406/406 PASS
- FastAPI/backend tests: 48/48 PASS
- Combined: 454/454 PASS
- V110–V113 focused compatibility/release gate: 48/48 PASS
- Package: 58/58 PASS
- Adaptive package: 60/60 PASS
- Business readiness: 69/69 PASS
- Final release: 16/16 PASS
- Required self-check: 45/45 PASS
- Phase 1–6: 12/12, 19/19, 31/31, 26/26, 28/28, 38/38 PASS
- Controlled 18-step end-to-end simulation: PASS with no blocked steps
- FastAPI process smoke: health/bootstrap/system status HTTP 200; bootstrap exposes 18 API definitions

No authenticated Dell/HIP mutation was executed during packaging validation.
