# Agentic HIP Web Application — Phase 6

React/Bun is the primary UI and FastAPI/Python is the execution backend. Phase 6 adds the final React-native API Testing Area and System & Connections workspace, and makes the compiled React/FastAPI single-port runtime the default application path.

See `README_AGENTIC_HIP_V38_PHASE6.md` in the project root.
