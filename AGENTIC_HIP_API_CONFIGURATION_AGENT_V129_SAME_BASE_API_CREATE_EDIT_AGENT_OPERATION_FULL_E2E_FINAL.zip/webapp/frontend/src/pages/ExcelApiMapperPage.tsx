import { useMemo, useState } from 'react';
import {
  AlertTriangle, BrainCircuit, CheckCircle2, ChevronDown, CircleAlert, FileSpreadsheet,
  Gauge, LoaderCircle, LockKeyhole, Play, ScanSearch, ShieldCheck, Sparkles, UploadCloud,
} from 'lucide-react';
import { api } from '../lib/api';
import type { Bootstrap, Configuration, IntelligentMapperResult, IntelligentMappingRow } from '../types';

const pretty=(value:unknown)=>JSON.stringify(value??{},null,2);
const pct=(value?:number)=>`${Math.round((Number(value)||0)*100)}%`;
const humanStatus=(status:string)=>status==='GOOD_TO_TRIGGER'?'Good to Trigger':status==='NEEDS_INPUT'?'Needs Input':'Do Not Trigger';
const statusClass=(status:string)=>status==='GOOD_TO_TRIGGER'?'good':status==='NEEDS_INPUT'?'needs':'blocked';

export function ExcelApiMapperPage({bootstrap,active,onActive}:{bootstrap:Bootstrap;active:Configuration|null;onActive?:(c:Configuration)=>void}){
  const catalog=bootstrap.all_api_catalog||bootstrap.api_catalog||[];
  const [file,setFile]=useState<File|null>(null);
  const [apiKey,setApiKey]=useState('AUTO');
  const [sheetName,setSheetName]=useState('');
  const [headerRow,setHeaderRow]=useState(0);
  const [useDellAia,setUseDellAia]=useState(true);
  const [result,setResult]=useState<IntelligentMapperResult|null>(null);
  const [selectedIndex,setSelectedIndex]=useState(0);
  const [busy,setBusy]=useState('');
  const [message,setMessage]=useState('Upload the team workbook, then let the governed agents map each row and fill proposed values only into attributes that already exist in the selected HIP API request.');
  const [stagedKey,setStagedKey]=useState('');
  const [preflight,setPreflight]=useState<any>(null);
  const [liveResult,setLiveResult]=useState<any>(null);
  const immutable=Boolean(active?.approved_reference||active?.immutable_reference||active?.managed_reference_source==='reference:uhal');
  const selected=result?.results?.[selectedIndex]||null;
  const selectedKey=selected?`${selected.excelRow}:${selected.apiKey}`:'';
  const staged=Boolean(selectedKey&&stagedKey===selectedKey);
  const preflightPassed=Boolean(staged&&preflight?.ok);
  const good=selected?.status==='GOOD_TO_TRIGGER';

  const groupedCatalog=useMemo(()=>{
    const groups=new Map<string,typeof catalog>();
    catalog.forEach(item=>{const rows=groups.get(item.group)||[];rows.push(item);groups.set(item.group,rows)});
    return Array.from(groups.entries());
  },[catalog]);

  const resetExecution=()=>{setStagedKey('');setPreflight(null);setLiveResult(null)};
  const selectResult=(index:number)=>{setSelectedIndex(index);resetExecution()};

  const analyze=async()=>{
    if(!active){setMessage('Open or build a configuration first. The active configuration supplies the canonical HIP API contracts.');return}
    if(!file){setMessage('Choose an .xlsx, .xlsm, or .csv file first.');return}
    setBusy('analyze');resetExecution();
    try{
      const data=await api.analyzeWorkbook(active.id,file,apiKey,sheetName,headerRow,useDellAia);
      setResult(data);setSelectedIndex(0);
      if(!sheetName)setSheetName(data.sheet?.name||'');
      if(!headerRow)setHeaderRow(data.sheet?.headerRow||0);
      const s=data.summary;
      setMessage(`Analyzed ${s.rows} row(s): ${s.GOOD_TO_TRIGGER} good to trigger, ${s.NEEDS_INPUT} need input, ${s.DO_NOT_TRIGGER} blocked. No payload was saved and no API was called LIVE.`);
    }catch(e:any){setResult(null);setMessage(e.message||String(e))}finally{setBusy('')}
  };

  const stage=async(row:IntelligentMappingRow)=>{
    if(!active||immutable||row.status==='DO_NOT_TRIGGER')return;
    setBusy('stage');setPreflight(null);setLiveResult(null);
    try{
      const response=await api.savePayloadOverride(active.id,row.apiKey,row.proposedRequest,row.requestKind,'paths');
      setStagedKey(`${row.excelRow}:${row.apiKey}`);
      const updated=await api.getConfiguration(active.id);onActive?.(updated);
      const sync=Array.isArray(response?.identitySync)?response.identitySync.length:0;
      setMessage(sync?`Agent-mapped values approved and staged for Excel row ${row.excelRow}. ${sync} linked identity value(s) were synchronized. Run preflight next.`:`Agent-mapped values approved and staged for Excel row ${row.excelRow}. Run preflight next.`);
    }catch(e:any){setMessage(e.message||String(e))}finally{setBusy('')}
  };

  const runPreflight=async(row:IntelligentMappingRow)=>{
    if(!active||!staged)return;
    setBusy('preflight');setLiveResult(null);
    try{
      const response=await api.apiTestPreflight(active.id,row.apiKey,{},'merge');setPreflight(response);
      setMessage(response.ok?'Agent preflight passed. The LIVE trigger button is now enabled for this staged row.':'Preflight found a blocker. LIVE remains disabled; review the response and correct values before retrying.');
    }catch(e:any){setPreflight(null);setMessage(e.message||String(e))}finally{setBusy('')}
  };

  const runLive=async(row:IntelligentMappingRow)=>{
    if(!active||!good||!staged||!preflightPassed)return;
    if(!window.confirm(`Run ${row.apiLabel||row.apiKey} LIVE for ${row.account||`Excel row ${row.excelRow}`} using the staged, schema-locked request?`))return;
    setBusy('live');
    try{
      const response=await api.apiTestExecute(active.id,row.apiKey,{},'merge');setLiveResult(response);
      setMessage(response.ok?'LIVE API completed successfully.':'LIVE API returned a blocker. Review the response evidence below.');
    }catch(e:any){setLiveResult(null);setMessage(e.message||String(e))}finally{setBusy('')}
  };

  return <div className="page fade-in intelligent-mapper-page">
    <div className="page-title"><div><span className="eyebrow"><BrainCircuit size={14}/> Intelligent Excel → API Mapper</span><h1>Decide what is safe to trigger before touching HIP</h1><p>Use deterministic contract matching plus the same Dell AIA LLM layer as the app to map team-extracted Excel data, fill the VALUES of existing API payload attributes, score every account/row, and gate LIVE execution behind explicit user approval and agent preflight.</p></div></div>

    {!active?<div className="empty-state large">Open or build a configuration first. Its generated requests are the immutable API schemas used by this mapper.</div>:<>
      <div className="mapper-policy-card"><LockKeyhole size={18}/><div><strong>Schema locked · agent maps values</strong><span>Agents may map Excel fields and fill/change VALUES only on existing canonical API paths. They cannot add/remove/rename attributes or alter structure. Your explicit Stage approval is required before those agent-prepared values are persisted or can reach LIVE.</span></div><span className="mapper-policy-chip">VALUE-MAPPING AGENTS</span></div>

      <section className="section-card mapper-input-card">
        <div className="section-head"><div><span className="eyebrow"><FileSpreadsheet size={13}/> Workbook intake</span><h2>Upload and analyze</h2></div>{result&&<span className="count-pill">{result.sheet.dataRowCount} rows</span>}</div>
        <div className="mapper-input-grid">
          <label className="mapper-file-drop"><UploadCloud size={22}/><div><strong>{file?.name||'Choose team Excel / CSV'}</strong><span>.xlsx, .xlsm or .csv · workbook is analyzed read-only</span></div><input type="file" accept=".xlsx,.xlsm,.csv" onChange={(e:any)=>{setFile(e.target.files?.[0]||null);setResult(null);setSheetName('');setHeaderRow(0);resetExecution()}}/></label>
          <label><span className="field-label">API selection</span><select value={apiKey} onChange={(e:any)=>{setApiKey(e.target.value);setResult(null);resetExecution()}}><option value="AUTO">AUTO · choose best API per Excel row</option>{groupedCatalog.map(([group,items])=><optgroup key={group} label={group}>{items.map(item=><option key={item.key} value={item.key}>{item.label} · {item.key}</option>)}</optgroup>)}</select><span className="field-help">AUTO evaluates every API applicable to the active configuration and shows alternatives.</span></label>
          <label><span className="field-label">Worksheet</span><select value={sheetName} onChange={(e:any)=>setSheetName(e.target.value)} disabled={!result}><option value="">Auto-detect best sheet</option>{result?.sheets?.map((row:IntelligentMapperResult['sheets'][number])=><option key={row.name} value={row.name}>{row.name} · {row.dataRowCount} rows</option>)}</select><span className="field-help">Run once for auto-detection, then select another sheet and re-analyze if needed.</span></label>
          <label><span className="field-label">Header row</span><input className="text-input" type="number" min={0} max={200} value={headerRow||''} placeholder="Auto" onChange={(e:any)=>setHeaderRow(Math.max(0,Number(e.target.value)||0))}/><span className="field-help">0 = auto-detect. Otherwise use the Excel row number containing column names.</span></label>
        </div>
        <div className="mapper-analyze-row"><label className="mapper-agent-toggle"><input type="checkbox" checked={useDellAia} onChange={(e:any)=>setUseDellAia(e.target.checked)}/><span><Sparkles size={14}/><b>Use Dell AIA mapping agents</b><small>LLM suggestions are confidence-gated and must match exact API paths.</small></span></label><button className="primary" disabled={!file||busy!==''} onClick={analyze}>{busy==='analyze'?<LoaderCircle className="spin" size={16}/>:<ScanSearch size={16}/>}Analyze workbook</button></div>
      </section>

      <div className="notice-card"><Gauge size={17}/><div><strong>{active.name}</strong><span>{message}</span>{immutable&&<small>This is an immutable approved reference. Analysis is allowed, but Stage and LIVE actions are disabled. Clone/Create from the reference to execute mapped rows.</small>}</div></div>

      {result&&<>
        <div className="mapper-kpis"><div className="good"><span>Good to Trigger</span><strong>{result.summary.GOOD_TO_TRIGGER}</strong><small>Mapped identity + critical values + contract-safe structure</small></div><div className="needs"><span>Needs Input</span><strong>{result.summary.NEEDS_INPUT}</strong><small>Missing/uncertain values or identity still inherited</small></div><div className="blocked"><span>Do Not Trigger</span><strong>{result.summary.DO_NOT_TRIGGER}</strong><small>Unsafe mapping or schema/value contract blocker</small></div><div><span>Accounts / records</span><strong>{result.summary.accounts}</strong><small>{result.llm?.used?`Dell AIA used`:`Deterministic mapping`}</small></div></div>

        <div className="mapper-results-layout">
          <section className="section-card mapper-row-list"><div className="section-head"><div><span className="eyebrow">Row readiness</span><h2>Account-by-account decision</h2></div><span className="count-pill">{result.summary.rows}</span></div><div className="mapper-table-wrap"><table className="mapper-table"><thead><tr><th>Excel</th><th>Account / record</th><th>Recommended API</th><th>Mapped</th><th>Score</th><th>Decision</th></tr></thead><tbody>{result.results.map((row:IntelligentMappingRow,index:number)=><tr key={`${row.excelRow}:${row.apiKey}`} className={index===selectedIndex?'selected':''} onClick={()=>selectResult(index)}><td>#{row.excelRow}</td><td><strong>{row.account}</strong><small>{row.recordLabel}</small></td><td><strong>{row.apiLabel||row.apiKey}</strong><small>{row.apiKey}</small></td><td>{row.mappedCount}</td><td><b>{row.score}</b>/100</td><td><span className={`mapper-status ${statusClass(row.status)}`}>{row.status==='GOOD_TO_TRIGGER'?<CheckCircle2 size={13}/>:row.status==='NEEDS_INPUT'?<AlertTriangle size={13}/>:<CircleAlert size={13}/>}{humanStatus(row.status)}</span></td></tr>)}</tbody></table></div></section>

          {selected&&<section className="section-card mapper-review-card">
            <div className="mapper-review-head"><div><span className="eyebrow">Selected row #{selected.excelRow}</span><h2>{selected.account}</h2><p>{selected.apiLabel||selected.apiKey} · score {selected.score}/100</p></div><span className={`mapper-status large ${statusClass(selected.status)}`}>{selected.status==='GOOD_TO_TRIGGER'?<CheckCircle2 size={15}/>:selected.status==='NEEDS_INPUT'?<AlertTriangle size={15}/>:<CircleAlert size={15}/>}{humanStatus(selected.status)}</span></div>

            <div className="mapper-gate-flow"><div className="done"><CheckCircle2 size={15}/><span>1. Analyze</span></div><div className={staged?'done':''}><ShieldCheck size={15}/><span>2. Approve agent values</span></div><div className={preflightPassed?'done':''}><BrainCircuit size={15}/><span>3. Agent preflight</span></div><div className={liveResult?.ok?'done':''}><Play size={15}/><span>4. LIVE API</span></div></div>

            {(selected.missingCriticalPaths.length>0||selected.inheritedIdentityPaths.length>0||selected.contractErrors.length>0||selected.warnings.length>0)&&<div className={`mapper-readiness-box ${selected.status==='DO_NOT_TRIGGER'?'blocked':selected.status==='NEEDS_INPUT'?'needs':'good'}`}><strong>{humanStatus(selected.status)}</strong>{selected.missingCriticalPaths.length>0&&<p><b>Missing critical:</b> {selected.missingCriticalPaths.join(' · ')}</p>}{selected.inheritedIdentityPaths.length>0&&<p><b>Identity inherited from active config:</b> {selected.inheritedIdentityPaths.join(' · ')}</p>}{selected.contractErrors.length>0&&<p><b>Contract errors:</b> {selected.contractErrors.map((e:any)=>e.message||e.field||JSON.stringify(e)).join(' · ')}</p>}{selected.warnings.map((warning:string,i:number)=><p key={i}>{warning}</p>)}</div>}

            <div className="mapper-actions"><button className="secondary" disabled={busy!==''||immutable||!good} onClick={()=>stage(selected)}>{busy==='stage'?<LoaderCircle className="spin" size={15}/>:<ShieldCheck size={15}/>}Approve & stage values</button><button className="secondary" disabled={busy!==''||!staged} onClick={()=>runPreflight(selected)}>{busy==='preflight'?<LoaderCircle className="spin" size={15}/>:<BrainCircuit size={15}/>}Agent preflight</button><button className="primary live-action" disabled={busy!==''||!good||!staged||!preflightPassed||immutable} onClick={()=>runLive(selected)}>{busy==='live'?<LoaderCircle className="spin" size={15}/>:<Play size={15}/>}Run API LIVE</button></div>
            {!good&&<div className="mapper-action-note"><LockKeyhole size={14}/><span>LIVE is gated until this row is Good to Trigger. Needs Input rows must be corrected in the workbook or through the existing human value editor and re-analyzed before staging. Only Good to Trigger rows can enter the execution gate.</span></div>}

            <details open><summary>Excel → canonical payload mappings <ChevronDown size={13}/></summary><div className="mapper-table-wrap"><table className="mapper-table mapping-evidence"><thead><tr><th>Excel column</th><th>Value</th><th>Canonical API path</th><th>Confidence</th><th>Agent/method</th></tr></thead><tbody>{selected.mappings.length?selected.mappings.map((m:IntelligentMappingRow['mappings'][number],i:number)=><tr key={`${m.sourceColumn}:${m.targetPath}:${i}`}><td><strong>{m.sourceColumn}</strong></td><td><code>{String(m.sourceValue??'')}</code>{m.valueNormalized&&<small>API canonical value → {String(m.mappedValue??'')}</small>}</td><td><code>{m.targetPath}</code></td><td>{pct(m.confidence)}</td><td>{m.method||'Deterministic'}<small>{m.reason||''}</small></td></tr>):<tr><td colSpan={5}>No safe mappings were found for this row/API.</td></tr>}</tbody></table></div></details>

            {selected.documentEvidence&&Object.keys(selected.documentEvidence).length>0&&<details open><summary>Document Type extraction proof <ChevronDown size={13}/></summary><div className="mapper-policy-grid"><div><b>Document Type Name</b><span>{selected.documentEvidence.nameSourceColumn?`${selected.documentEvidence.nameSourceColumn} → ${selected.documentEvidence.nameSourceValue||'blank'}`:'No Excel name evidence'}</span></div><div><b>Document Type Version</b><span>{selected.documentEvidence.versionSourceColumn?`${selected.documentEvidence.versionSourceColumn} → ${selected.documentEvidence.versionSourceValue||'blank'} (${selected.documentEvidence.versionOrigin||'explicit'})`:'No Excel version evidence — inherited/default version suppressed'}</span></div></div></details>}

            {selected.apiAlternatives?.length?<details><summary>Other API candidates <ChevronDown size={13}/></summary><div className="mapper-alternatives">{selected.apiAlternatives.map((alt:NonNullable<IntelligentMappingRow['apiAlternatives']>[number])=><div key={alt.apiKey}><span><b>{alt.apiLabel||alt.apiKey}</b><small>{alt.apiKey}</small></span><span>{alt.mappedCount} mapped</span><span>{alt.score}/100</span><em className={`mapper-status ${statusClass(alt.status)}`}>{humanStatus(alt.status)}</em></div>)}</div></details>:null}
            {selected.unmappedColumns.length?<details><summary>Workbook columns intentionally not mapped ({selected.unmappedColumns.length}) <ChevronDown size={13}/></summary><div className="mapper-unmapped">{selected.unmappedColumns.map((name:string)=><span key={name}>{name}</span>)}</div></details>:null}
            <details><summary>Proposed schema-locked request <ChevronDown size={13}/></summary><pre className="code-panel mapper-code">{pretty(selected.proposedRequest)}</pre></details>
            {preflight&&<details open><summary>Preflight evidence <ChevronDown size={13}/></summary><pre className="code-panel mapper-code">{pretty(preflight)}</pre></details>}
            {liveResult&&<details open><summary>LIVE response evidence <ChevronDown size={13}/></summary><pre className="code-panel mapper-code">{pretty(liveResult)}</pre></details>}
          </section>}
        </div>

        <section className="section-card mapper-agent-card"><div className="section-head"><div><span className="eyebrow"><Sparkles size={13}/> Mapping intelligence</span><h2>What the agents did</h2></div><span className={`mapper-agent-state ${result.llm?.used?'used':'fallback'}`}>{result.llm?.used?'Dell AIA + deterministic guardrails':'Deterministic fallback'}</span></div><p>{result.llm?.note||'The Excel Schema Analyst classified columns and the API Contract Mapping Agent suggested only exact canonical target paths. Every suggestion was revalidated deterministically before use.'}</p><div className="mapper-policy-grid"><div><b>Agent can</b><span>Understand headers · rank API candidates · map fields · fill/change proposed values at existing canonical paths · normalize approved value forms · score readiness · explain blockers</span></div><div><b>Agent cannot</b><span>Add/remove/rename API attributes · change nesting/cardinality · invent unsupported fields · bypass user Stage approval · bypass preflight · trigger LIVE automatically</span></div></div></section>
      </>}
    </>}
  </div>;
}
