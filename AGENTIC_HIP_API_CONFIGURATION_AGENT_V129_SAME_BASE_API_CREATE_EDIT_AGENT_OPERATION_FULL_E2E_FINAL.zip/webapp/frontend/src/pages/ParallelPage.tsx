import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, ArrowDown, ArrowUp, Bot, Clock3, CopyPlus, FileBarChart2, ListChecks, LoaderCircle, PlayCircle, RefreshCcw, Rocket, Save, Square, TimerReset, Trash2, UsersRound, Wrench, Zap, ShieldCheck } from 'lucide-react';
import type { BlockerDiagnostic, Configuration, ParallelBatch, ParallelJob, ParallelResult, ParallelSource, PipelineDefinition } from '../types';
import { api } from '../lib/api';
import { formatDuration } from '../lib/time';
import { ConfigurationFixModal } from '../components/ConfigurationFixModal';

type LiveJob = {jobId:string;label:string;customer:string;status:string;startedAt?:string;elapsedSeconds?:number;lines?:number;blockerDiagnostic?:BlockerDiagnostic;executionMode?:string};
// Backward-compatible createParallelInstances API remains available; V73 uses the source-aware queue path so U-HAUL/reference customers can also be repeated.

export function ParallelPage({active,onActive}:{active:Configuration|null;onActive:(c:Configuration)=>void}){
  const [jobs,setJobs]=useState<ParallelJob[]>([]);
  const [sources,setSources]=useState<ParallelSource[]>([]);
  const [selected,setSelected]=useState<string[]>([]);
  const [selectedSources,setSelectedSources]=useState<string[]>([]);
  const [runMode,setRunMode]=useState<'single'|'multiple'>('single');
  const [workers,setWorkers]=useState(4);
  const [demoCount,setDemoCount]=useState(3);
  const [repeatSourceId,setRepeatSourceId]=useState('');
  const [validation,setValidation]=useState<any>(active?.validation||null);
  const [batch,setBatch]=useState<ParallelBatch|null>(null);
  const [message,setMessage]=useState('Choose Single customer or Multiple customers, then select validated payload set(s) and run exactly what you selected.');
  const [busy,setBusy]=useState(false);
  const [busyAction,setBusyAction]=useState('');
  const [liveJobs,setLiveJobs]=useState<Record<string,LiveJob>>({});
  const [clock,setClock]=useState(Date.now());
  const [batchStartedAtMs,setBatchStartedAtMs]=useState<number|null>(null);
  const [repairSource,setRepairSource]=useState<ParallelSource|null>(null);
  const [pipelines,setPipelines]=useState<PipelineDefinition[]>([]);
  const [pipelineId,setPipelineId]=useState('');
  const [pipelineName,setPipelineName]=useState('Customer API Pipeline');
  const [pipelineStages,setPipelineStages]=useState<string[]>([]);
  const [pipelineSourceToAdd,setPipelineSourceToAdd]=useState('');
  const deletedJobIdsRef=useRef<Set<string>>(new Set());

  const refresh=async()=>{
    setBusyAction(v=>v||'refresh');
    try{
      const [queueRows,sourceRows,pipelineRows]=await Promise.all([api.parallelQueue(),api.parallelSources(),api.pipelines()]);
      const serverIds=new Set(queueRows.map(row=>row.jobId));
      deletedJobIdsRef.current.forEach(id=>{if(!serverIds.has(id))deletedJobIdsRef.current.delete(id)});
      setJobs(queueRows.filter(row=>!deletedJobIdsRef.current.has(row.jobId)));
      setSources(sourceRows);
      setPipelines(pipelineRows);
    }finally{
      setBusyAction(v=>v==='refresh'?'':v);
    }
  };

  useEffect(()=>{refresh().catch((e:any)=>setMessage(e.message||String(e)))},[]);
  useEffect(()=>setValidation(active?.validation||null),[active?.id,active?.validation]);
  useEffect(()=>{if(!busy)return;const timer=setInterval(()=>setClock(Date.now()),1000);return()=>clearInterval(timer)},[busy]);

  // Always make the active configuration easy to find/select. U-HAUL is a
  // first-class developer-approved configuration and is always selectable as the immutable test baseline.
  useEffect(()=>{
    if(!sources.length||selectedSources.length)return;
    const uhal=sources.find(s=>s.sourceId==='reference:uhal');
    const current=sources.find(s=>s.configurationId===active?.id);
    if(runMode==='single'){
      const preferred=current||uhal||sources[0];
      if(preferred){
        setSelectedSources([preferred.sourceId]);
        if(!preferred.validated)setMessage(`${preferred.customer} is selected but needs attention. Click “Fix now” on its card and answer the one thing the agent asks.`);else if(preferred.approvedReference)setMessage('U-HAUL is developer approved and test-ready. Runtime credentials/connectivity will be checked separately at preflight/LIVE time.');
      }
    }else{
      const defaults:string[]=[];
      if(uhal)defaults.push(uhal.sourceId);
      if(current&&!defaults.includes(current.sourceId))defaults.push(current.sourceId);
      if(defaults.length)setSelectedSources(defaults);
    }
  },[sources,active?.id,selectedSources.length,runMode]);
  useEffect(()=>{if(repeatSourceId&&sources.some(s=>s.sourceId===repeatSourceId&&s.validated))return;const current=sources.find(s=>s.configurationId===active?.id&&s.validated);const uhal=sources.find(s=>s.sourceId==='reference:uhal'&&s.validated);const preferred=current||uhal||sources.find(s=>s.validated);if(preferred)setRepeatSourceId(preferred.sourceId)},[sources,active?.id,repeatSourceId]);

  const ready=jobs.filter(x=>x.ready);
  const chosen=useMemo(()=>jobs.filter(x=>selected.includes(x.jobId)),[jobs,selected]);
  const validatedSources=sources.filter(x=>x.validated);
  const chosenSources=useMemo(()=>sources.filter(x=>selectedSources.includes(x.sourceId)),[sources,selectedSources]);
  const selectedSourcesReady=selectedSources.length>0&&chosenSources.length===selectedSources.length&&chosenSources.every(x=>x.validated);

  const validate=async()=>{
    if(!active)return;
    setBusy(true);setBusyAction('validate');
    try{
      const v=await api.validateConfiguration(active.id);
      setValidation(v);
      const c=await api.getConfiguration(active.id);onActive(c);
      await refresh();
      setMessage(v.ok?'Agent validation PASS. The active customer is now selectable for parallel execution.':'Validation found blockers. Fix them before adding this customer to the parallel queue.');
    }catch(e:any){const source=sources.find(x=>x.configurationId===active?.id);setMessage(e.message);if(source&&!source.validated)setRepairSource(source)}finally{setBusy(false);setBusyAction('')}
  };

  const queueActive=async()=>{
    if(!active)return;
    setBusy(true);setBusyAction('queue-active');
    try{
      const item=await api.queueParallel(active.id,`${active.customer||active.name} · ${active.transaction_code}`);
      await refresh();setSelected(v=>Array.from(new Set([...v,item.jobId])));
      setMessage(`${active.customer||active.name} validated payload snapshot added and selected.`);
    }catch(e:any){setMessage(e.message)}finally{setBusy(false);setBusyAction('')}
  };

  const chooseUhalAndActive=()=>{
    const ids:string[]=[];
    const uhal=sources.find(s=>s.sourceId==='reference:uhal'&&s.validated);
    const current=sources.find(s=>s.configurationId===active?.id&&s.validated);
    if(uhal)ids.push(uhal.sourceId);
    if(current&&!ids.includes(current.sourceId))ids.push(current.sourceId);
    setSelectedSources(ids);
    if(ids.length<2)setMessage('U-HAUL is available, but the active customer must also pass validation before both can be selected together.');
    else setMessage(`Selected ${uhal?.customer||'U-HAUL'} + ${current?.customer||current?.name||'active customer'}. Click “Add selected customers to queue”.`);
  };

  const queueSelectedSources=async()=>{
    if(!selectedSourcesReady){const blocked=chosenSources.find(x=>!x.validated);if(blocked)setRepairSource(blocked);setMessage(blocked?`${blocked.customer} needs one or more answers before it can be queued. Fix it here first.`:'Select a validated customer.');return;}
    setBusy(true);setBusyAction('queue-customers');
    const names=chosenSources.map(x=>x.customer).join(' + ');
    setMessage(`Revalidating and snapshotting ${names||selectedSources.length+' customer(s)'}…`);
    try{
      const result=await api.queueParallelSources(selectedSources);
      await refresh();
      const createdIds=(result.items||[]).map(x=>x.jobId);
      if(createdIds.length)setSelected(createdIds);
      if(result.errors?.length){
        const detail=result.errors.map(x=>x.error).join(' | ');
        setMessage(`Queued ${result.created} customer(s). ${result.errors.length} could not be queued: ${detail}`);
      }else{
        setMessage(result.created===1?'Queued one validated customer payload set and selected it for a single LIVE run.':`Queued ${result.created} validated customer payload sets and selected them for one parallel LIVE run.`);
      }
    }catch(e:any){setMessage(e.message)}finally{setBusy(false);setBusyAction('')}
  };

  const demo=async()=>{
    const source=sources.find(x=>x.sourceId===repeatSourceId&&x.validated);
    if(!source){setMessage('Choose a validated customer before creating repeated parallel instances.');return;}
    setBusy(true);setBusyAction('instances');setMessage(`Creating ${demoCount} immutable test snapshots of ${source.customer}…`);
    try{
      const created=await api.queueParallelSources(Array.from({length:demoCount},()=>source.sourceId));
      await refresh();
      const ids=(created.items||[]).map((x:any)=>x.jobId);
      setSelected(ids);setRunMode('multiple');setWorkers(Math.min(4,Math.max(1,ids.length)));
      if(created.errors?.length)setMessage(`Created ${created.created} instance(s); ${created.errors.length} instance(s) could not be queued: ${created.errors.map((x:any)=>x.error).join(' | ')}`);
      else setMessage(`Created ${created.created} ${source.customer} LIVE execution snapshots. RUN LIVE EXECUTION will process them with up to 4 real AutoGen agents; additional instances wait for the next wave.`);
    }catch(e:any){setMessage(e.message)}finally{setBusy(false);setBusyAction('')}
  };

  const attachBatchSocket=(b:ParallelBatch,startedAtMs:number)=>{
    const patchLiveBatch=(event:any)=>{
      setBatch(prev=>{
        if(!prev)return prev;
        let results=[...(prev.results||[])];
        if(event.type==='job.completed'||event.type==='job.cancelled'){
          const result:any={...event};delete result.type;
          const index=results.findIndex(row=>row.jobId===result.jobId);if(index>=0)results[index]=result;else results.push(result);
        }
        const statuses=results.map(row=>String(row.status||'').toUpperCase());
        const passCount=statuses.filter(x=>x==='PASS').length,warningCount=statuses.filter(x=>x==='WARNING').length,failCount=statuses.filter(x=>x==='FAIL').length,blockedCount=statuses.filter(x=>x==='BLOCKED').length,cancelledCount=statuses.filter(x=>x==='CANCELLED').length,skippedCount=statuses.filter(x=>x==='SKIPPED').length;
        const overallVerdict=failCount?'FAIL':blockedCount?'BLOCKED':cancelledCount?'CANCELLED':warningCount?'WARNING':passCount&&passCount===results.length?'PASS':'IN_PROGRESS';
        return {...prev,status:event.type==='batch.stop_requested'?'STOPPING':'RUNNING',results,completedCount:results.length,passCount,warningCount,failCount,blockedCount,cancelledCount,skippedCount,overallVerdict,elapsedSeconds:Math.max(0,(Date.now()-startedAtMs)/1000)};
      });
    };
    const protocol=location.protocol==='https:'?'wss':'ws';const ws=new WebSocket(`${protocol}://${location.host}/ws/parallel/${b.batchId}`);
    ws.onmessage=async ev=>{
      const event=JSON.parse(ev.data);if(event.type!=='batch.completed')patchLiveBatch(event);
      if(event.type==='batch.preflight_all_started')setMessage('Pipeline safety gate: validating and production-preflighting EVERY stage before the first LIVE API call.');
      if(event.type==='batch.preflight_all_passed')setMessage('All pipeline payloads and preflight checks passed. LIVE stage execution is starting in order.');
      if(event.type==='batch.stop_requested')setMessage('Stop requested. Running processes are being terminated and queued instances will not start.');
      if(event.type==='job.final_checks_started'||event.type==='job.final_checks_progress')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.label||event.customer,customer:event.customer||''}),status:'CHECKING'}}));
      if(event.type==='job.final_checks_passed')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.label||event.customer,customer:event.customer||''}),status:'CHECKED'}}));
      if(event.type==='job.started')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.label||event.customer,customer:event.customer||''}),status:'RUNNING',startedAt:event.startedAt}}));
      if(event.type==='job.heartbeat')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.jobId,customer:''}),status:'RUNNING',lines:event.lines}}));
      if(event.type==='job.stop_requested')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.label||event.jobId,customer:event.customer||''}),status:'STOPPING'}}));
      if(event.type==='job.cancelled'||event.type==='job.completed')setLiveJobs(rows=>({...rows,[event.jobId]:{...(rows[event.jobId]||{jobId:event.jobId,label:event.label||event.customer,customer:event.customer||''}),status:event.status||(event.type==='job.cancelled'?'CANCELLED':'COMPLETED'),elapsedSeconds:event.elapsedSeconds,blockerDiagnostic:event.blockerDiagnostic,executionMode:event.executionMode}}));
      if(event.type==='batch.completed'){setBatch({...event.summary,status:'COMPLETED'});setBatchStartedAtMs(null);setBusy(false);setBusyAction('');setMessage(`Batch complete · ${event.summary.passCount||0} PASS · ${event.summary.blockedCount||0} BLOCKED · ${event.summary.cancelledCount||0} CANCELLED · ${formatDuration(event.summary.elapsedSeconds||0)}`);await refresh();ws.close()}
    };
    ws.onerror=()=>{setMessage('Live connection interrupted; recovering the batch state from FastAPI…');setTimeout(async()=>{try{const recovered=await api.parallelBatch(b.batchId);setBatch(recovered);const rows:Record<string,any>={};Object.entries((recovered as any).jobs||{}).forEach(([id,value]:any)=>{rows[id]={jobId:id,...value}});if(Object.keys(rows).length)setLiveJobs(rows);if(recovered.status==='COMPLETED'){setBusy(false);setBusyAction('')}}catch(e:any){setMessage(`Could not recover batch state: ${e.message}`)}},800)};
  };

  const addPipelineStage=()=>{
    if(!pipelineSourceToAdd)return;
    setPipelineStages(v=>[...v,pipelineSourceToAdd]);
    setPipelineSourceToAdd('');
  };
  const movePipelineStage=(index:number,delta:number)=>{
    setPipelineStages(v=>{const next=[...v];const target=index+delta;if(target<0||target>=next.length)return next;[next[index],next[target]]=[next[target],next[index]];return next});
  };
  const removePipelineStage=(index:number)=>setPipelineStages(v=>v.filter((_,i)=>i!==index));
  const loadPipeline=(id:string)=>{
    setPipelineId(id);const row=pipelines.find(x=>x.id===id);if(!row)return;setPipelineName(row.name);setPipelineStages([...(row.sourceIds||[])]);setMessage(`${row.name} loaded. Validate all stages before LIVE execution.`);
  };
  const deletePipelineNow=async()=>{
    if(!pipelineId)return;const row=pipelines.find(x=>x.id===pipelineId);if(!row)return;if(!confirm(`Delete pipeline ${row.name}?`))return;
    const previous=[...pipelines];setPipelines(v=>v.filter(x=>x.id!==pipelineId));setPipelineId('');setPipelineName('Customer API Pipeline');setPipelineStages([]);setMessage(`${row.name} removed.`);
    try{await api.deletePipeline(row.id)}catch(e:any){setPipelines(previous);setPipelineId(row.id);setPipelineName(row.name);setPipelineStages(row.sourceIds||[]);setMessage(`Delete failed and was rolled back: ${e.message}`)}
  };
  const savePipeline=async()=>{
    if(!pipelineStages.length){setMessage('Add at least one validated customer payload stage to the pipeline.');return;}
    setBusyAction('pipeline-save');
    try{
      const saved=pipelineId?await api.updatePipeline(pipelineId,pipelineName,pipelineStages):await api.createPipeline(pipelineName,pipelineStages);
      setPipelineId(saved.id);setPipelineName(saved.name);setPipelineStages(saved.sourceIds||[]);await refresh();
      setMessage(saved.validation?.ok?`${saved.name} saved and all ${saved.validation.stageCount} stage payloads validate.`:`${saved.name} saved, but one or more stages need attention before LIVE execution.`);
    }catch(e:any){setMessage(e.message)}finally{setBusyAction('')}
  };
  const validatePipeline=async()=>{
    if(!pipelineId){setMessage('Save the pipeline first, then validate all stages.');return;}
    setBusyAction('pipeline-validate');
    try{const row=await api.validatePipeline(pipelineId);await refresh();setMessage(row.validation?.ok?`Pipeline validation PASS · ${row.validation.stageCount} stages · every payload is ready.`:`Pipeline validation found ${row.validation?.errors?.length||1} blocker(s). Nothing can run LIVE until every stage is correct.`)}catch(e:any){setMessage(e.message)}finally{setBusyAction('')}
  };
  const runPipeline=async()=>{
    if(!pipelineId){setMessage('Save the pipeline first.');return;}
    const row=pipelines.find(x=>x.id===pipelineId);
    if(!row?.validation?.ok){setMessage('Pipeline is not validated. Click Validate all payloads first.');return;}
    if(!confirm(`Run ${row.name} LIVE in the saved stage order? The backend will preflight EVERY stage before the first HIP API mutation.`))return;
    setBusy(true);setBusyAction('pipeline-run');setMessage(`Starting all-payload preflight for ${row.name}…`);
    try{
      const b=await api.runPipeline(pipelineId);
      const startedAtMs=Date.now();setBatch({...b,status:'RUNNING',overallVerdict:'IN_PROGRESS',elapsedSeconds:0,results:b.results||[]});setBatchStartedAtMs(startedAtMs);setClock(startedAtMs);
      const initial:Record<string,LiveJob>={};Object.entries((b as any).jobs||{}).forEach(([id,value]:any)=>{initial[id]={jobId:id,label:value.label,customer:value.customer,status:value.status||'QUEUED'}});setLiveJobs(initial);
      attachBatchSocket(b,startedAtMs);
    }catch(e:any){setMessage(e.message);setBusy(false);setBusyAction('')}
  };

  const run=async()=>{
    if(runMode==='single'&&chosen.length!==1){setMessage('Single-customer mode requires exactly one queued payload set. Select one customer only.');return;}
    if(runMode==='multiple'&&chosen.length<2){setMessage('Multiple-customer mode requires at least two queued payload sets or repeated snapshots of the same customer.');return;}
    const uniqueCustomers=Array.from(new Set(chosen.map(x=>x.customer)));
    const customers=uniqueCustomers.join(', ');
    const actualWorkers=runMode==='single'?1:Math.min(4,workers,chosen.length);
    const waveCount=Math.ceil(chosen.length/Math.max(1,actualWorkers));
    const confirmation=runMode==='single'
      ?`Run ${customers} against the strict LIVE HIP pipeline now? Every applicable API will be called and its live result captured; no existing-object API will be skipped by assumption.`
      :`Run ${chosen.length} validated payload snapshot(s) (${customers}) against LIVE HIP now? ${actualWorkers} AutoGen agent${actualWorkers===1?'':'s'} will execute the real HIP APIs concurrently (${waveCount} wave${waveCount===1?'':'s'}). Each agent calls every applicable HIP API with no skip assumptions, resolves/creates missing prerequisites, retries recoverable steps, and captures the live HTTP result before the final deploy/audit verdict.`;
    if(!confirm(confirmation))return;
    setBusy(true);setBusyAction('run');
    try{
      const initial:Record<string,LiveJob>={};
      chosen.forEach(job=>{initial[job.jobId]={jobId:job.jobId,label:job.label,customer:job.customer,status:'QUEUED',executionMode:'LIVE'}});setLiveJobs(initial);
      const b=await api.startParallel(selected,actualWorkers);
      const startedAtMs=Date.now();
      setBatch({...b,status:'RUNNING',overallVerdict:'IN_PROGRESS',elapsedSeconds:0,results:b.results||[]});setBatchStartedAtMs(startedAtMs);setClock(startedAtMs);
      setMessage(`LIVE batch ${b.batchId} started. ${b.parallelWorkers} AutoGen agent(s) are running the strict whole pipeline. Every applicable HIP API must return live HTTP evidence; missing prerequisites are created/resolved and retried before Flow deploy/audit and the final verdict.`);
      attachBatchSocket(b,startedAtMs);
    }catch(e:any){setMessage(e.message);setBusy(false);setBusyAction('')}
  };

  const deleteQueuedJobs=async(jobIds:string[])=>{
    const ids=Array.from(new Set(jobIds.filter(Boolean)));
    if(!ids.length)return;
    const rowsToDelete=jobs.filter(job=>ids.includes(job.jobId));
    if(!rowsToDelete.length)return;
    if(!confirm(`Delete ${rowsToDelete.length} queued instance${rowsToDelete.length===1?'':'s'}? The queue will update immediately.`))return;
    const previousJobs=[...jobs];const previousSelected=[...selected];
    ids.forEach(id=>deletedJobIdsRef.current.add(id));
    setJobs(current=>current.filter(job=>!ids.includes(job.jobId)));
    setSelected(current=>current.filter(id=>!ids.includes(id)));
    setMessage(`${rowsToDelete.length} queued instance${rowsToDelete.length===1?'':'s'} removed immediately.`);
    try{
      const result=ids.length===1?await api.deleteParallel(ids[0]):await api.deleteParallelMany(ids);
      if(ids.length===1&&!result?.deleted)throw new Error('Backend did not confirm deletion.');
      if(ids.length>1&&Number(result?.deletedCount||0)!==ids.length)throw new Error(`Backend deleted ${result?.deletedCount||0}/${ids.length} selected instances.`);
      const serverRows=await api.parallelQueue();
      const serverIds=new Set(serverRows.map(row=>row.jobId));
      ids.forEach(id=>{if(!serverIds.has(id))deletedJobIdsRef.current.delete(id)});
      setJobs(serverRows.filter(row=>!deletedJobIdsRef.current.has(row.jobId)));
      setMessage(`${rowsToDelete.length} queued instance${rowsToDelete.length===1?'':'s'} deleted. Remaining instance numbering has been refreshed.`);
    }catch(e:any){
      ids.forEach(id=>deletedJobIdsRef.current.delete(id));
      setJobs(previousJobs);setSelected(previousSelected);
      setMessage(`Delete failed and was rolled back immediately: ${e.message}`);
    }
  };

  const stopActiveBatch=async()=>{
    if(!batch?.batchId)return;if(!confirm('Stop this batch? Running HIP worker processes will be terminated and queued instances will not start.'))return;
    setBusyAction('stop-batch');try{await api.stopParallelBatch(batch.batchId);setMessage('Stop requested. Waiting for running workers to terminate safely…')}catch(e:any){setMessage(e.message)}finally{setBusyAction('')}
  };
  const stopInstance=async(jobId:string)=>{
    if(!batch?.batchId)return;if(!confirm('Stop this execution instance?'))return;
    try{await api.stopParallelJob(batch.batchId,jobId);setMessage(`Stop requested for ${jobId}.`)}catch(e:any){setMessage(e.message)}
  };

  const toggle=(id:string)=>setSelected(v=>runMode==='single'?(v.includes(id)?[]:[id]):(v.includes(id)?v.filter(x=>x!==id):[...v,id]));
  const selectSourceForRepair=(id:string)=>{setSelectedSources(v=>runMode==='single'?[id]:(v.includes(id)?v:[...v,id]));};
  const toggleSource=(id:string)=>{const source=sources.find(x=>x.sourceId===id);if(source?.approvedReference&&!source.validated){setMessage(source.error||source.nextAction||'The packaged U-HAUL reference could not be loaded. Refresh after the local runtime is available; the approved baseline itself is not blocked.');return;}if(source&&!source.validated){selectSourceForRepair(id);setRepairSource(source);setMessage(`${source.customer} needs configuration input. The issue is open now—choose the correct value and the agent will re-check it.`);return;}setSelectedSources(v=>runMode==='single'?(v.includes(id)?[]:[id]):(v.includes(id)?v.filter(x=>x!==id):[...v,id]));};
  const selectAllReady=()=>{if(runMode==='multiple')setSelected(ready.map(x=>x.jobId));};
  const liveRows=Object.values(liveJobs);
  const selectedUniqueCustomers=new Set(chosen.map(x=>x.customer)).size;
  const sameCustomerParallel=runMode==='multiple'&&chosen.length>1&&selectedUniqueCustomers===1;
  const activeAutoGenAgents=runMode==='single'?(chosen.length===1?1:0):Math.min(4,workers,chosen.length);
  const waves=chosen.length?Math.ceil(chosen.length/Math.max(1,activeAutoGenAgents)):0;
  const liveElapsed=(row:{startedAt?:string;elapsedSeconds?:number})=>row.elapsedSeconds??(row.startedAt?Math.max(0,(clock-new Date(row.startedAt).getTime())/1000):0);

  return <div className="page fade-in">
    <div className="page-title">
      <div><span className="eyebrow"><Zap size={14}/> LIVE execution</span><h1>Execution Center</h1><p>Run one validated customer, multiple customers, or repeated instances from the same execution queue.</p><div className="execution-capability-note"><ShieldCheck size={14}/><span>AutoGen AgentChat 0.7.5 · up to 4 concurrent agents · strict LIVE pipeline · 18 base APIs + 7 Migration blocks when applicable</span></div></div>
      <button className="ghost" disabled={busyAction==='refresh'} onClick={()=>refresh().catch((e:any)=>setMessage(e.message))}>{busyAction==='refresh'?<LoaderCircle className="spin" size={16}/>:<RefreshCcw size={16}/>}Refresh</button>
    </div>

    <div className="parallel-top-grid">
      <section className="section-card">
        <div className="section-head"><div><span className="step-kicker">ACTIVE CONFIGURATION</span><h2>{active?.customer||active?.name||'No active configuration'}</h2></div><span className={validation?.ok?'mini-pass':'mini-muted'}>{validation?.ok?'VALIDATED':'NEEDS VALIDATION'}</span></div>
        <div className="metric-strip"><div><span>Direction</span><b>{active?.direction||'—'}</b></div><div><span>Transaction</span><b>{active?.transaction_code||'—'}</b></div><div><span>Flow</span><b>{active?.resolved_flow_type||active?.flow_type||'—'}</b></div><div><span>API contracts</span><b>{validation?.requests?`${validation.requests.validCount}/${validation.requests.total}`:'—'}</b></div></div>
        <div className="button-row"><button className="secondary" disabled={!active||busy} onClick={validate}>{busyAction==='validate'?<LoaderCircle className="spin" size={16}/>:<Bot size={16}/>}Validate configuration</button><button className="primary" disabled={!active||!validation?.ok||busy} onClick={queueActive}>{busyAction==='queue-active'?<LoaderCircle className="spin" size={16}/>:<CopyPlus size={16}/>}Queue active customer</button></div>
      </section>

      <section className="section-card multi-customer-card">
        <div className="section-head"><div><span className="step-kicker">EXECUTION MODE</span><h2>One customer or multiple customers</h2></div><UsersRound size={22}/></div>
        <div className="execution-mode-toggle"><button className={runMode==='single'?'active':''} disabled={busy} onClick={()=>{setRunMode('single');setSelectedSources([]);setSelected([]);setMessage('Single-customer mode: choose exactly one validated customer below.')}}>Run one customer</button><button className={runMode==='multiple'?'active':''} disabled={busy} onClick={()=>{setRunMode('multiple');setSelectedSources([]);setSelected([]);setMessage('Multi-customer mode: choose two or more validated customers below.')}}>Run multiple customers</button></div>
        <p>{runMode==='single'?'Choose one validated customer to run.':'Choose two or more validated customers, or create repeated instances below.'}</p>
        <div className="multi-customer-metrics"><div><b>{validatedSources.length}</b><span>validated customers</span></div><div><b>{selectedSources.length}</b><span>selected now</span></div></div>
        <div className="button-row">{runMode==='multiple'&&<button className="secondary" disabled={busy} onClick={chooseUhalAndActive}>Select U-HAUL + active</button>}<button className="primary" disabled={!selectedSourcesReady||busy||(runMode==='single'&&selectedSources.length!==1)||(runMode==='multiple'&&selectedSources.length<2)} onClick={queueSelectedSources}>{busyAction==='queue-customers'?<LoaderCircle className="spin" size={16}/>:<CopyPlus size={16}/>} {busyAction==='queue-customers'?'Queueing…':runMode==='single'?'Queue selected customer':'Queue selected customers'}</button></div>
      </section>
    </div>

    <section className="section-card">
      <div className="section-head"><div><span className="step-kicker">VALIDATED CUSTOMERS</span><h2>{runMode==='single'?'Choose one customer':'Choose multiple customers'}</h2><p className="muted-copy top-gap">Validated customer configurations appear here automatically.</p></div><div className="queue-toolbar"><span>{selectedSources.length} selected</span>{runMode==='multiple'&&<button className="ghost" disabled={!validatedSources.length||busy} onClick={()=>setSelectedSources(validatedSources.map(x=>x.sourceId))}>Select all validated</button>}<button className="ghost" disabled={!selectedSources.length||busy} onClick={()=>setSelectedSources([])}>Clear</button></div></div>
      <div className="customer-source-grid">
        {sources.length===0?<div className="empty-state">No customer configurations are available yet.</div>:sources.map(source=>{
          const isActive=source.configurationId===active?.id;
          const checked=selectedSources.includes(source.sourceId);
          return <article key={source.sourceId} className={`${checked?'customer-source-card selected':'customer-source-card'} ${!source.validated?'needs-fix':''} ${source.approvedReference?'approved-source-card':''}`} onClick={()=>{if(!busy)toggleSource(source.sourceId)}}>
            <div className="source-check"><input type="checkbox" checked={checked} disabled={busy} readOnly/><span/></div>
            <div className="source-main"><div className="source-title"><strong>{source.customer}</strong>{source.approvedReference&&<span className="reference-pill">DEV APPROVED · TEST READY</span>}{isActive&&<span className="active-pill">ACTIVE</span>}</div><small>{source.name}</small><div className="source-facts"><span>{source.direction||'—'}</span><span>{source.transactionCode||'—'}</span><span>{source.flowType||'—'}</span><span>{source.validCount}/{source.totalContracts} {source.approvedReference?'approved':'contracts'}</span></div>{source.approvedReference?<div className="approved-runtime-note"><ShieldCheck size={14}/><span><b>RUNTIME PRE-LIVE:</b> Immutable developer-approved baseline. Runtime credentials/connectivity are checked separately when you run.</span></div>:!source.validated&&<div className="source-fix-summary"><AlertTriangle size={14}/><span>{source.nextAction||source.error||'This configuration needs attention.'}</span></div>}</div>
            {source.approvedReference?<span className={source.validated?'ready-pill dev-approved-pill':'warning-pill'}>{source.validated?'DEV APPROVED':'RELOAD REQUIRED'}</span>:source.validated?<span className="ready-pill">VALIDATED</span>:<button className="source-fix-button" onClick={e=>{e.stopPropagation();selectSourceForRepair(source.sourceId);setRepairSource(source)}}><Wrench size={14}/>Fix now</button>}
          </article>;
        })}
      </div>
    </section>

    <section className="section-card pipeline-builder-card">
      <div className="section-head"><div><span className="step-kicker">PIPELINE EXECUTION</span><h2>Build an ordered execution pipeline</h2><p className="muted-copy top-gap">Stages run in order only after every selected payload passes final validation and production preflight.</p></div><ListChecks size={22}/></div>
      <div className="pipeline-toolbar"><label><span>Saved pipeline</span><select value={pipelineId} disabled={busy} onChange={e=>loadPipeline(e.target.value)}><option value="">New pipeline</option>{pipelines.map(row=><option key={row.id} value={row.id}>{row.name} · {row.status}</option>)}</select></label><label className="pipeline-name"><span>Pipeline name</span><input value={pipelineName} disabled={busy} onChange={e=>setPipelineName(e.target.value)}/></label></div>
      <div className="pipeline-add-row"><select value={pipelineSourceToAdd} disabled={busy} onChange={e=>setPipelineSourceToAdd(e.target.value)}><option value="">Add validated customer stage…</option>{validatedSources.map(source=><option key={source.sourceId} value={source.sourceId}>{source.customer} · {source.direction||'—'} {source.transactionCode||''} · {source.flowType||'—'}</option>)}</select><button className="secondary" disabled={!pipelineSourceToAdd||busy} onClick={addPipelineStage}><CopyPlus size={15}/>Add stage</button></div>
      <div className="pipeline-stage-list">{pipelineStages.length===0?<div className="empty-state">No stages yet. Add customers in the exact order they must run.</div>:pipelineStages.map((sourceId,index)=>{const source=sources.find(x=>x.sourceId===sourceId);return <div className="pipeline-stage" key={`${sourceId}-${index}`}><span className="pipeline-stage-number">{index+1}</span><div><strong>{source?.customer||sourceId}</strong><small>{source?.direction||'—'} {source?.transactionCode||''} · {source?.flowType||'—'} · {source?.validated?'base payload ready · Migration checked pre-LIVE':'needs attention'}</small></div><button className="icon-button" disabled={busy||index===0} onClick={()=>movePipelineStage(index,-1)} title="Move up"><ArrowUp size={15}/></button><button className="icon-button" disabled={busy||index===pipelineStages.length-1} onClick={()=>movePipelineStage(index,1)} title="Move down"><ArrowDown size={15}/></button><button className="icon-button" disabled={busy} onClick={()=>removePipelineStage(index)} title="Remove"><Trash2 size={15}/></button></div>})}</div>
      <div className="pipeline-actions"><button className="secondary" disabled={!pipelineStages.length||busyAction==='pipeline-save'} onClick={savePipeline}>{busyAction==='pipeline-save'?<LoaderCircle className="spin" size={16}/>:<Save size={16}/>}Save pipeline</button><button className="secondary" disabled={!pipelineId||busyAction==='pipeline-validate'} onClick={validatePipeline}>{busyAction==='pipeline-validate'?<LoaderCircle className="spin" size={16}/>:<ShieldCheck size={16}/>}Validate all payloads</button><button className="icon-danger" title="Delete saved pipeline" disabled={!pipelineId||busy} onClick={deletePipelineNow}><Trash2 size={15}/></button><button className="danger-live" disabled={!pipelineId||!pipelines.find(x=>x.id===pipelineId)?.validation?.ok||busy} onClick={runPipeline}>{busyAction==='pipeline-run'?<LoaderCircle className="spin" size={18}/>:<PlayCircle size={18}/>}RUN VALIDATED PIPELINE LIVE</button></div>
    </section>

    <div className="agent-message"><Bot size={18}/><span>{message}</span></div>

    <section className="section-card compact-instance-card">
      <div className="section-head"><div><span className="step-kicker">REPEAT CUSTOMER</span><h2>Create repeated execution instances</h2><p className="muted-copy top-gap">Create multiple immutable snapshots of one validated customer. Runs are processed automatically in groups of up to four.</p></div><UsersRound size={20}/></div>
      <div className="instance-inline"><div className="repeat-customer-fields"><label><span>Validated customer</span><select value={repeatSourceId} disabled={busy} onChange={e=>setRepeatSourceId(e.target.value)}>{validatedSources.map(source=><option key={source.sourceId} value={source.sourceId}>{source.customer} · {source.direction||'—'} {source.transactionCode||''} · {source.flowType||'—'}</option>)}</select></label><label><span>Instances</span><input className="number-input" type="number" min={2} max={50} value={demoCount} onChange={e=>setDemoCount(Math.max(2,Math.min(50,Number(e.target.value)||2)))}/></label></div><button className="secondary" disabled={!repeatSourceId||busy} onClick={demo}>{busyAction==='instances'?<LoaderCircle className="spin" size={16}/>:<CopyPlus size={16}/>} {busyAction==='instances'?'Creating…':`Create ${demoCount} LIVE instances`}</button></div>
    </section>

    <section className="section-card">
      <div className="section-head"><div><span className="step-kicker">EXECUTION QUEUE</span><h2>Validated customer payload snapshots</h2></div><div className="queue-toolbar"><span>{ready.length} ready</span>{runMode==='multiple'&&<button className="ghost" disabled={!ready.length||busy} onClick={selectAllReady}>Select all ready</button>}<button className="ghost" disabled={!selected.length||busy} onClick={()=>setSelected([])}>Clear selection</button><button className="ghost danger-text" disabled={!selected.length||busy} onClick={()=>deleteQueuedJobs([...selected])}><Trash2 size={14}/>Delete selected</button></div></div>
      <div className="queue-list">{jobs.length===0?<div className="empty-state">No validated customer payload is queued yet. Choose one or more validated customers above and add exactly what you want to run.</div>:jobs.map(job=><div key={job.jobId} className={selected.includes(job.jobId)?'queue-row selected':'queue-row'}><label className="queue-check"><input type="checkbox" checked={selected.includes(job.jobId)} disabled={!job.ready||busy} onChange={()=>toggle(job.jobId)}/><span/></label><div className="queue-main"><strong>{job.label}</strong><small>{job.customer} · {job.direction} · {job.transactionCode||''} · {job.flowType}</small></div>{job.demoInstance&&<span className="demo-pill">Instance {job.demoInstance}/{job.demoInstanceCount}</span>}<span className={job.ready?'ready-pill':'blocked-pill'} title={(job as any).readinessReason||''}>{job.ready?'READY':'NOT READY'}</span><button className="icon-button" disabled={busy||deletedJobIdsRef.current.has(job.jobId)} onClick={()=>deleteQueuedJobs([job.jobId])}><Trash2 size={15}/></button></div>)}</div>
      <div className="parallel-runbar"><div><label title="Parallel AutoGen AgentChat agents">Parallel agents</label><input className="number-input" type="number" min={1} max={4} value={runMode==='single'?1:workers} disabled={runMode==='single'} onChange={e=>setWorkers(Math.max(1,Math.min(4,Number(e.target.value)||4)))}/><small>Maximum concurrent agents: 4</small></div><div className="run-summary"><b>{chosen.length}</b><span>payload sets</span></div><div className="run-summary"><b>{selectedUniqueCustomers}</b><span>unique customers</span></div><div className="run-summary"><b>{activeAutoGenAgents}</b><span>active AutoGen agents</span></div><div className="run-summary"><b>{waves}</b><span>execution waves</span></div><button className="danger-live" disabled={busy||(runMode==='single'?chosen.length!==1:chosen.length<2)} onClick={run}>{busyAction==='run'?<LoaderCircle className="spin" size={18}/>:<PlayCircle size={18}/>}RUN LIVE EXECUTION</button></div>
    </section>

    {batch&&liveRows.length>0&&<section className="section-card parallel-live-board"><div className="section-head"><div><span className="step-kicker">{batch.batchKind==='PIPELINE'?'LIVE PIPELINE BOARD':'LIVE EXECUTION BOARD'}</span><h2>{busy?(batch.batchKind==='PIPELINE'?'Pipeline running in stage order':'Customer agents executing LIVE HIP APIs'):'Last execution batch'}</h2></div><div className="button-row"><span className={busy?'live-running-pill':'mini-pass'}>{busy?'LIVE':'COMPLETE'}</span>{busy&&<button className="stop-live-button" onClick={stopActiveBatch} disabled={busyAction==='stop-batch'}>{busyAction==='stop-batch'?<LoaderCircle className="spin" size={15}/>:<Square size={15}/>}STOP BATCH</button>}</div></div><div className="live-job-grid">{liveRows.map(row=><div className={`live-job-card live-${row.status.toLowerCase()}`} key={row.jobId}><div><strong>{row.label}</strong><span>{row.customer}</span></div><b>{row.status}</b><div className="live-job-time"><Clock3 size={14}/>{formatDuration(liveElapsed(row))}</div>{row.lines?<small>{row.lines} log lines processed</small>:<small>{row.status==='QUEUED'?'Waiting for a worker':row.status==='CHECKING'?'Revalidating contracts + production preflight':row.status==='CHECKED'?'Final checks passed':row.status==='RUNNING'?'LIVE HIP execution in progress':row.status==='STOPPING'?'Stopping worker…':row.status==='CANCELLED'?'Stopped by user':row.status==='BLOCKED'?'Blocked — see exact cause below':row.status==='SKIPPED'?'Pipeline stage did not run':'Execution finished'}</small>}{hasBlockerDiagnostic(row.status,row.blockerDiagnostic)&&<BlockerPanel diagnostic={row.blockerDiagnostic!} compact/>}{busy&&['QUEUED','CHECKING','CHECKED','RUNNING'].includes(String(row.status||'').toUpperCase())&&<button className="stop-instance-button" onClick={()=>stopInstance(row.jobId)}><Square size={13}/>Stop instance</button>}</div>)}</div></section>}
    {batch&&<BatchResult batch={batch} liveRows={liveRows.map(row=>({...row,elapsedSeconds:liveElapsed(row)}))} liveElapsedSeconds={busy&&batchStartedAtMs?Math.max(0,(clock-batchStartedAtMs)/1000):(batch.elapsedSeconds||0)}/>}  
    {repairSource&&<ConfigurationFixModal source={repairSource} onClose={()=>setRepairSource(null)} onResolved={async(configuration)=>{onActive(configuration);setValidation(configuration.validation||null);await refresh();selectSourceForRepair(repairSource.sourceId);setMessage(`${configuration.customer||configuration.name} is fixed and validated. It is selected and ready to queue.`)}}/>}
  </div>;
}

function BatchResult({batch,liveRows,liveElapsedSeconds}:{batch:ParallelBatch;liveRows:LiveJob[];liveElapsedSeconds:number}){
  const results=batch.results||[];
  const completed=batch.completedCount??results.length;
  const running=String(batch.status||'').toUpperCase()!=='COMPLETED';
  const displayVerdict=running?(completed?batch.overallVerdict||'IN_PROGRESS':'IN_PROGRESS'):(batch.overallVerdict||'—');
  return <section className="section-card live-result-section"><div className="section-head"><div><span className="step-kicker">{batch.batchKind==='PIPELINE'?'PIPELINE RESULT':'LIVE EXECUTION RESULT'}</span><h2>{batch.batchId}</h2><p className="muted-copy top-gap">Agent verdict: <b>{displayVerdict==='IN_PROGRESS'?'IN PROGRESS':displayVerdict}</b>{running?<span className="live-updating-dot"> updating live</span>:null} · AutoGen agents <b>{batch.parallelWorkers}/{batch.autoGenAgentLimit||4} max</b> · API parallelism <b>{batch.apiParallelism||'DEPENDENCY_SAFE_AUTOMATIC'}</b></p></div><div className="button-row"><span>{formatDuration(liveElapsedSeconds)}</span>{!running&&results.length?<button className="secondary" onClick={()=>api.downloadParallelReport(batch.batchId)}><FileBarChart2 size={15}/>Download final HTML report</button>:null}</div></div><div className="execution-result-metrics"><div><span>Run instances</span><b>{batch.configurationCount}</b></div><div><span>Completed</span><b>{completed}/{batch.configurationCount}</b></div><div><span>PASS</span><b>{batch.passCount??0}</b></div><div><span>WARNING</span><b>{batch.warningCount??0}</b></div><div><span>FAIL</span><b>{batch.failCount??0}</b></div><div><span>BLOCKED</span><b>{batch.blockedCount??0}</b></div><div><span>CANCELLED</span><b>{batch.cancelledCount??0}</b></div><div><span>SKIPPED</span><b>{batch.skippedCount??0}</b></div><div><span>Elapsed</span><b>{formatDuration(liveElapsedSeconds)}</b></div></div>{running&&liveRows.length>0&&<div className="live-result-progress">{liveRows.map(row=><div key={row.jobId}><span className={`live-state-dot state-${String(row.status||'queued').toLowerCase()}`}/><strong>{row.label}</strong><small>{row.status==='CHECKING'?'Final safety checks':row.status==='CHECKED'?'Checks passed':row.status==='RUNNING'?'Calling LIVE HIP APIs':row.status}</small><b>{formatDuration(row.elapsedSeconds||0)}</b></div>)}</div>}{results.length?<div className="result-grid">{results.map(r=><ResultCard key={r.jobId} result={r}/>)}</div>:!running?<div className="empty-state">No final result rows were produced for this batch.</div>:null}</section>;
}

function hasBlockerDiagnostic(status:string,diagnostic?:BlockerDiagnostic){
  const s=String(status||'').toUpperCase();
  if(s==='PASS'||s==='WARNING'||!diagnostic)return false;
  return Boolean(diagnostic.api||diagnostic.stage||diagnostic.reason||diagnostic.httpStatus!==undefined||diagnostic.hipResponse);
}

function verdictPill(status:string){const s=String(status||'').toUpperCase();return s==='PASS'?'ready-pill':s==='WARNING'?'warning-pill':'blocked-pill'}

function BlockerPanel({diagnostic,compact=false}:{diagnostic:BlockerDiagnostic;compact?:boolean}){
  const [open,setOpen]=useState(!compact);
  const response=diagnostic.hipResponse;
  return <div className={compact?'blocker-panel compact':'blocker-panel'}><button className="blocker-toggle" onClick={()=>setOpen(v=>!v)}><AlertTriangle size={14}/>{open?'Hide cause':'View cause'}{diagnostic.httpStatus!==undefined&&diagnostic.httpStatus!==null&&diagnostic.httpStatus!==''?<span>HTTP {String(diagnostic.httpStatus)}</span>:null}</button>{open&&<div className="blocker-detail"><div><span>First failing API / gate</span><b>{diagnostic.api||diagnostic.stage||'Execution'}</b></div>{diagnostic.group&&<div><span>Group</span><b>{diagnostic.group}</b></div>}<div><span>Reason</span><p>{diagnostic.reason||'The execution did not pass.'}</p></div>{diagnostic.nextAction&&<div><span>What to do next</span><p>{diagnostic.nextAction}</p></div>}{diagnostic.requestId&&<div><span>Request ID</span><code>{diagnostic.requestId}</code></div>}{response!==undefined&&response!==null&&String(response)!==''&&<details><summary>HIP response / technical evidence</summary><pre>{typeof response==='string'?response:JSON.stringify(response,null,2)}</pre></details>}</div>}</div>;
}

function ResultCard({result}:{result:ParallelResult}){
  const [open,setOpen]=useState(false);
  const reason=result.agentSummary?.reason;
  return <div className="run-card"><div className="run-card-head"><div><strong>{result.label||result.customer||result.jobId}</strong><span>{result.flow}</span></div><span className={verdictPill(result.status)}>{result.status}</span></div><div className="run-time"><Clock3 size={15}/><b>{formatDuration(result.elapsedSeconds||0)}</b><span>{result.executionMode||'LIVE'} · {result.stepTimings?.length||0} timed steps{result.apiCoverage?.strict?` · ${result.apiCoverage.called||0}/${result.apiCoverage.expected||18} APIs called`:''}</span></div>{reason&&<div className={result.status==='WARNING'?'warning-box':result.status==='PASS'?'success-box':'error-box'}><b>Agent conclusion:</b> {reason}</div>}{hasBlockerDiagnostic(result.status,result.blockerDiagnostic)&&<BlockerPanel diagnostic={result.blockerDiagnostic!}/>} {!hasBlockerDiagnostic(result.status,result.blockerDiagnostic)&&result.error&&String(result.status||'').toUpperCase()!=='PASS'&&<div className="error-box">{result.error}</div>}<button className="ghost wide" onClick={()=>setOpen(v=>!v)}><TimerReset size={15}/>{open?'Hide':'Show'} step timings</button>{open&&<div className="timing-list">{(result.stepTimings||[]).map((t,i)=><div key={`${t.stepKey}-${i}`}><span>{t.label||t.stepKey}</span><b>{formatDuration(t.totalStepSeconds||0)}</b><small>API {formatDuration(t.apiElapsedSeconds||0)} · wait {formatDuration(t.waitSeconds||0)}</small></div>)}</div>}</div>;
}
