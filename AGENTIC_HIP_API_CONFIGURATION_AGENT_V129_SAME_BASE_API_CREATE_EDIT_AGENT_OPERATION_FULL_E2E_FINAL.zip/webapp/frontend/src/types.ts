export type Direction = 'Inbound' | 'Outbound';
export type FlowType = 'Auto' | 'Translation' | 'Passthrough';
export type InputMode = 'files' | 'cm_files' | 'input_files';

export type ApiCatalogItem = { key:string; label:string; group:string; order:number; reusable:boolean };
export type InterfaceDefinition = { key:string; displayName:string; apiInterfaceType:string; family:string; description?:string };

export type MappingLearning = {
  example_count:number; target_examples:number; source_tokens:string[]; target_tokens:string[];
  source_formats:Record<string,number>; target_formats:Record<string,number>; field_rule_count:number;
  examples?: Array<Record<string,unknown>>; role_tokens?:Record<string,string[]>; field_rule_counts?:Record<string,number>;
};

export type Bootstrap = {
  api_catalog: ApiCatalogItem[]; migration_api_catalog?: ApiCatalogItem[]; all_api_catalog?: ApiCatalogItem[]; interfaces: InterfaceDefinition[]; deployment_group:string; phase?:number;
  mapping_learning?: MappingLearning;
  transactions:{ default_direction:Direction; editable_direction:boolean; directions:Record<Direction,{suggested_transactions:string[];description:string}>; flow_types:FlowType[]; custom_transaction_allowed:boolean };
  templates:FlowTemplate[];
  capabilities?:Record<string,boolean>;
};

export type BuilderQuestion = { id:string; path:string; label:string; question:string; why:string; type:string; secret:boolean; options:string[]; current?:unknown; informational?:boolean; conflict?:{fileValues:unknown[];fileSources:string[];fileEvidence?:Array<{value?:unknown;sourceFile?:string;confidence?:string;rule?:string}>;fileConfidence?:string;selectedValue?:unknown;selectedField?:string;recommended?:string} };

export type ValidationResult = {
  ok:boolean; generatedAt?:string;
  mapper?:{ok:boolean;errors?:unknown[];issues?:unknown[]};
  requests?:{ok:boolean;validCount:number;total:number;items?:Array<Record<string,unknown>>};
  executionPlan?:{ok:boolean}; executionFlow?:{ok:boolean}; mcpSupervisor?:Record<string,unknown>;
};

export type Configuration = {
  id:string; name:string; customer:string; direction:Direction; transaction_code:string; transaction_name:string;
  flow_type:FlowType; source_interface:string; target_interface:string; input_mode:InputMode; user_instructions:string; user_selected_fields?:string[];
  status:string; uploaded_files:{name:string;size:number}[]; questions:BuilderQuestion[]; input_json?:Record<string,unknown>;
  validation?:ValidationResult; mapping_learning?:MappingLearning; cloned_from_configuration?:string; imported_from_configuration?:string; import_bundle_integrity?:boolean;
  resolved_flow_type?:'Translation'|'Passthrough'; input_built?:boolean; build_summary?:Record<string,any>; updated_at?:string;
  managed_reference_source?:string; flow_source_id?:string; approved_reference?:boolean; immutable_reference?:boolean; reference_approval_status?:string; test_ready?:boolean; starter_source?:string; cloned_from_approved_reference?:boolean;
};

export type Evidence = {
  manifest:string[]; fileMapping?:Record<string,any>; artifactValidation?:Record<string,any>; builderAudit?:Record<string,any>; extractionBlueprint?:Record<string,any>;
  documentTypes?:{source?:Record<string,any>;target?:Record<string,any>}; flowType?:string; direction?:string; transactionCode?:string; customer?:string;
};

export type EdgeMapping = { from:string; to:string };

export type ApiFlowNodeData = {
  apiKey:string; label:string; group:string;
  status:'IDLE'|'READY'|'RUNNING'|'PASS'|'EXISTING'|'BLOCKED'|'NEEDS_INPUT'|'VALIDATED'|'SKIPPED'|'AWAITING_APPROVAL'|'RESUMED'|'WARNING';
  payload?:unknown; generatedRequest?:unknown; response?:unknown; output?:unknown; verdict?:unknown;
  timing?:{apiMs?:number;waitMs?:number;totalMs?:number}; requestOverride?:Record<string,unknown>;
  enabled?:boolean; stopOnBlocked?:boolean; waitAfterSeconds?:number; overrideMode?:'merge'|'replace'; approvalRequired?:boolean; approvalMessage?:string;
  validation?:Record<string,unknown>; retries?:Array<Record<string,unknown>>; resolvedMappings?:Array<Record<string,unknown>>;
  [key:string]:unknown;
};
export type SerializableNode = { id:string;api_key:string;label:string;x:number;y:number;enabled:boolean;stop_on_blocked:boolean;wait_after_seconds:number;override_mode:'merge'|'replace';request_override:Record<string,unknown>;approval_required:boolean;approval_message:string };
export type SerializableEdge = { id:string;source:string;target:string;label:string;mappings:EdgeMapping[] };
export type FlowTemplate = { id:string;name:string;description:string;direction:Direction;transaction_code:string;flow_type:FlowType;nodes:SerializableNode[];edges:SerializableEdge[];variables:string[];default_values?:Record<string,unknown>;source_configuration_id?:string;tags:string[];version:number;builtin:boolean;lifecycle?:'DRAFT'|'PUBLISHED'|'ARCHIVED';published_at?:string;archived_at?:string;source_template_id?:string;updated_at?:string;created_at?:string };

export type PreflightIssue = { code?:string; nodeId?:string; edgeId?:string; message:string };
export type SuggestedMapping = { edgeId:string;source:string;target:string;mapping:EdgeMapping;confidence:string;reason:string };
export type FlowPreflight = {
  ok:boolean; readyForLive:boolean; errors:PreflightIssue[]; warnings:PreflightIssue[]; fixes:Array<Record<string,unknown>>;
  suggestedMappings:SuggestedMapping[]; executionOrder:string[]; nodePreviews:Record<string,any>;
  contractValidation:{ok:boolean;items:Array<Record<string,any>>}; configurationValidation?:ValidationResult;
  nodeCount:number;edgeCount:number;
};

export type ExecutionRecord = { id:string;configuration_id:string;status:string;created_at:string;updated_at?:string;started_at?:string;finished_at?:string;elapsedMs?:number;events?:Array<Record<string,any>>;flow?:Record<string,any>;resume_from_execution?:string;resumed_node_count?:number };
export type ExecutionComparison = { left:{id:string;status:string;elapsedMs:number;created_at?:string};right:{id:string;status:string;elapsedMs:number;created_at?:string};elapsedMsDelta:number;nodes:Array<{nodeId:string;left:Record<string,any>;right:Record<string,any>;statusChanged:boolean;totalMsDelta:number}> };

export type ParallelSource = {
  sourceId:string; configurationId?:string; repairConfigurationId?:string; sourceKind:'reference'|'managed_reference'|'configuration'; name:string; customer:string; direction?:string; transactionCode?:string; flowType?:string;
  validated:boolean; validCount:number; totalContracts:number; applicableCount?:number; status:string; error?:string; blockerCount?:number; questions?:BuilderQuestion[]; nextAction?:string; persistedEdits?:boolean; approvedReference?:boolean; immutableReference?:boolean; approvalStatus?:string; testReady?:boolean; runtimeCheckedSeparately?:boolean;
};

export type ParallelJob = {
  jobId:string;configurationId?:string;label:string;customer:string;flow:string;direction?:string;flowType?:string;transactionCode?:string;
  createdAt:string;status:string;ready?:boolean;integrityOk?:boolean;runtimeValuesReady?:boolean;demoInstance?:number;demoInstanceCount?:number;instanceGroupId?:string;
};
export type StepTiming = { stepKey?:string;label?:string;sequence?:number;classification?:string;startedAt?:string;finishedAt?:string;apiElapsedMs?:number;apiElapsedSeconds?:number;waitSeconds?:number;totalStepSeconds?:number };
export type BlockerDiagnostic = { sequence?:number|string;api?:string;group?:string;stage?:string;verdict?:string;httpStatus?:number|string|null;classification?:string;method?:string;url?:string;reason?:string;nextAction?:string;hipResponse?:unknown;requestId?:string };
export type ParallelResult = { jobId:string;label?:string;customer?:string;flow?:string;demoInstance?:number;status:string;elapsedSeconds?:number;stepTimings?:StepTiming[];error?:string;agentVerdict?:string;agentSummary?:{overallVerdict?:string;reason?:string;counts?:Record<string,number>};apiCoverage?:{strict?:boolean;complete?:boolean;called?:number;expected?:number;migrationEnabled?:boolean;missing?:string[];nonPassing?:string[]};blockerDiagnostic?:BlockerDiagnostic;attentionItems?:BlockerDiagnostic[];executionMode?:string };
export type ParallelBatch = { batchId:string;status?:string;parallelWorkers:number;configurationCount:number;completedCount?:number;passCount?:number;warningCount?:number;failCount?:number;blockedCount?:number;cancelledCount?:number;skippedCount?:number;overallVerdict?:string;elapsedSeconds?:number;startedAt?:string;finishedAt?:string;results?:ParallelResult[];events?:Array<Record<string,unknown>>;batchKind?:string;pipelineId?:string;preflightAll?:boolean;allPayloadsValidated?:boolean;reportWarning?:string;jobs?:Record<string,any>;executionMode?:string;nonMutating?:boolean;autoGenAgentLimit?:number;agentFramework?:string;knownUnstableAgentCount?:number;knownUnstableReason?:string;apiParallelism?:string };
export type PipelineValidationStage = {index:number;sourceId:string;sourceKind?:string;configurationId?:string;customer?:string;direction?:string;transactionCode?:string;flowType?:string;ok:boolean;validCount?:number;total?:number};
export type PipelineDefinition = {id:string;name:string;sourceIds:string[];status:string;createdAt:string;updatedAt:string;lastBatchId?:string;lastRunAt?:string;validation?:{ok:boolean;stageCount:number;stages:PipelineValidationStage[];errors:Array<Record<string,any>>;validatedAt?:string}};

export type LearnRecord = { id:string;filename:string;kind:string;learnedAt?:string;summary?:string;vision?:Record<string,any>;warnings?:string[];storedRedacted?:boolean };
export type ReportRecord = { name:string;size:number;modified:number;kind:string };

export type AuditEvent = { id:string;timestamp:string;actor:string;action:string;entity_type:string;entity_id:string;summary:string;metadata?:Record<string,unknown>;previous_hash?:string;hash:string };
export type AuditVerification = { ok:boolean;events:number;brokenAt?:string;headHash?:string };
export type BundleInspection = { integrityOk:boolean;fileCount:number;manifest:Record<string,any>;configuration:Record<string,any>;verifiedFiles:Array<{path:string;size:number;sha256:string}> };

export type SystemStatus = {
  ok:boolean; phase:number; ui:string; backend:string; python:string; platform:string;
  bunAvailable:boolean; bunPath:string; frontendBuilt:boolean; singlePortReady:boolean;
  deploymentGroup:string; apiBlocks:number; streamlitRequired:boolean; legacyStreamlitInstalled:boolean;
  tuning:{parallelWorkers:number;httpPoolSize:number;reuseValidatedRequests:boolean;approvalTimeoutSeconds:number};
  skillPolicy?:{descriptionTriggered:boolean;preRunVetting:boolean;contextBudgeted:boolean;deterministicEntrypointsOnly:boolean;arbitrarySkillCodeExecution:boolean;vetted?:boolean;skillCount?:number;vettingError?:string};
  credentialEnvironment:Record<string,{clientId:boolean;clientSecret:boolean;tokenUrl:boolean}>; runtimeRoot?:string; runtimePolicy?:string; runtimeMigration?:Record<string,unknown>; note?:string;
};

export type ConnectionReadiness = {
  overall:string; secureConnectionsOk?:boolean; flowConfigurationValid?:boolean; buildId?:string;
  components?:Record<string,Record<string,any>>;
  configurationReadiness?:{status?:string;ready?:boolean;inputValidation?:Record<string,any>;readiness?:Record<string,any>;error?:string};
  apiExecutionPlan?:Record<string,any>; executionFlow?:Record<string,any>; [key:string]:any;
};

export type AgentCheckItem = { key:string;label:string;status:'PASS'|'WARNING'|'BLOCKED';reason:string };
export type FlowNodeAgentCheck = { ready:boolean;verdict:'PASS'|'BLOCKED';summary:string;checks:AgentCheckItem[];incomingRuntimeMappings?:number;approvalRequired?:boolean;approvalNote?:string };
export type ApiTestResult = {
  ok:boolean; executed:boolean; stepKey:string; applicable?:boolean; applicabilityReason?:string;
  request?:Record<string,any>; contractValidation?:Record<string,any>; response?:Record<string,any>;
  verdict?:Record<string,any>; output?:Record<string,any>; attempts?:Array<Record<string,any>>;
  timing?:{apiMs?:number;totalMs?:number}; result?:Record<string,any>; error?:string; nodeId?:string;
  readyForLive?:boolean; agentCheck?:FlowNodeAgentCheck;
};

export type IntelligentMappingStatus = 'GOOD_TO_TRIGGER'|'NEEDS_INPUT'|'DO_NOT_TRIGGER';
export type IntelligentColumnMapping = {
  sourceColumn:string;sourceValue?:string;targetPath:string;previousValue?:unknown;mappedValue?:unknown;
  confidence?:number;method?:string;reason?:string;valueNormalized?:boolean;
};
export type IntelligentApiAlternative = {
  apiKey:string;apiLabel?:string;status:IntelligentMappingStatus;score:number;mappedCount:number;missingCriticalPaths?:string[];
};
export type IntelligentMappingRow = {
  excelRow:number;account:string;recordLabel:string;apiKey:string;apiLabel?:string;group?:string;requestKind:'payload'|'params';
  status:IntelligentMappingStatus;score:number;goodToTrigger:boolean;mappings:IntelligentColumnMapping[];mappedCount:number;mappedPaths:string[];
  criticalPaths:string[];missingCriticalPaths:string[];inheritedIdentityPaths:string[];contractErrors:Array<Record<string,any>>;warnings:string[];
  unmappedColumns:string[];generatedRequest:Record<string,unknown>;baseEffectiveRequest:Record<string,unknown>;proposedRequest:Record<string,unknown>;
  documentEvidence?:{nameSourceColumn?:string;nameSourceValue?:string;versionSourceColumn?:string;versionSourceValue?:string;versionOrigin?:string;inheritedVersionSuppressed?:boolean;inheritedNameSuppressed?:boolean};
  contractStatusBeforeMapping?:string;apiAlternatives?:IntelligentApiAlternative[];
};
export type IntelligentMapperResult = {
  ok:boolean;policy:string;agentEditAllowed:boolean;userEditAllowed:boolean;
  file:{name:string;format?:string;size?:number};
  sheet:{name:string;headerRow:number;headers:string[];dataRowCount:number};
  sheets:Array<{name:string;headerRow:number;columnCount:number;dataRowCount:number;affinityScore?:number}>;
  selectionMode:string;
  summary:{rows:number;accounts:number;GOOD_TO_TRIGGER:number;NEEDS_INPUT:number;DO_NOT_TRIGGER:number};
  accounts:string[];results:IntelligentMappingRow[];
  mappingSummary:Array<{apiKey:string;apiLabel?:string;requestKind:'payload'|'params';canonicalLeafCount:number;contractStatus?:string;columnMappings:Array<{sourceColumn:string;targetPath:string;confidence?:number;method?:string;reason?:string}>}>;
  llm?:{enabled?:boolean;provider?:string;used?:boolean;note?:string;diagnostics?:Record<string,unknown>;agents?:Array<{name:string;model?:string;output?:unknown}>};
  notes?:string[];
  configuration?:{id:string;name?:string;customer?:string;status?:string;immutableReference?:boolean};
};

export type ExecutionFlowStep = {
  stepKey:string;
  order:number;
  waitAfterSeconds:number;
  label:string;
  group:string;
  dependencies:string[];
  migration?:boolean;
  includedInLive?:boolean;
  operationMode?:'inherit'|'create'|'edit';
  operationModeSource?:string;
  operationCapable?:boolean;
  operationPaths?:string[];
  operationDescription?:string;
};

export type ExecutionFlowSummary = {
  path?:string;
  version:number;
  valid:boolean;
  errors:string[];
  warnings:string[];
  migrationEnabled:boolean;
  registeredBaseCount:number;
  registeredMigrationCount:number;
  registeredTotalCount:number;
  liveStepCount:number;
  orderedSteps:string[];
  orderedAllSteps:string[];
  orderedLiveSteps:string[];
  steps:ExecutionFlowStep[];
  migrationSteps:ExecutionFlowStep[];
  liveSteps:ExecutionFlowStep[];
  validation?:any;
  queueRefresh?:any;
};
