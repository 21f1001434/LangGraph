import { useEffect, useRef, useState } from 'react';
import { LoaderCircle } from 'lucide-react';
import { Sidebar, type PageKey } from './components/Sidebar';
import { AppTopbar } from './components/AppTopbar';
import { DashboardPage } from './pages/DashboardPage';
import { BuilderPage } from './pages/BuilderPage';
import { FlowGamePage } from './pages/FlowGamePage';
import { TemplatesPage } from './pages/TemplatesPage';
import { OperationsPage } from './pages/OperationsPage';
import { ParallelPage } from './pages/ParallelPage';
import { LearnPage } from './pages/LearnPage';
import { ReportsPage } from './pages/ReportsPage';
import { WorkspacePage } from './pages/WorkspacePage';
import { ApiTestingPage } from './pages/ApiTestingPage';
import { ExcelApiMapperPage } from './pages/ExcelApiMapperPage';
import { SystemPage } from './pages/SystemPage';
import { api } from './lib/api';
import type { Bootstrap, Configuration, FlowTemplate } from './types';
import './styles.css';
const PAGE_KEYS:PageKey[]=['dashboard','workspace','builder','mapper','flow','testing','operations','templates','parallel','learn','reports','system'];
function savedPage():PageKey{try{const value=localStorage.getItem('hip.page') as PageKey|null;return value&&PAGE_KEYS.includes(value)?value:'dashboard'}catch{return 'dashboard'}}
export default function App(){
  const [page,setPage]=useState<PageKey>(savedPage),[bootstrap,setBootstrap]=useState<Bootstrap|null>(null),[configs,setConfigs]=useState<Configuration[]>([]),[active,setActive]=useState<Configuration|null>(null),[error,setError]=useState(''),[selectedTemplate,setSelectedTemplate]=useState<FlowTemplate|null>(null);
  const [apiActivity,setApiActivity]=useState<{count:number;url:string}>({count:0,url:''});
  const [sidebarCollapsed,setSidebarCollapsed]=useState(()=>{try{return localStorage.getItem('hip.sidebarCollapsed')==='1'}catch{return false}});
  const [mobileNavOpen,setMobileNavOpen]=useState(false);
  const activityStarted=useRef(0),activityHideTimer=useRef<number|undefined>(undefined),activityCount=useRef(0);
  useEffect(()=>{const handler=(event:Event)=>{const detail=(event as CustomEvent<{count:number;url:string}>).detail||{count:0,url:''};const previous=activityCount.current;activityCount.current=detail.count;if(detail.count>0){if(activityHideTimer.current)window.clearTimeout(activityHideTimer.current);if(previous===0)activityStarted.current=Date.now();setApiActivity({count:detail.count,url:detail.url||''});return;}const wait=Math.max(0,320-(Date.now()-activityStarted.current));activityHideTimer.current=window.setTimeout(()=>setApiActivity({count:0,url:''}),wait)};window.addEventListener('hip:api-activity',handler);return()=>{window.removeEventListener('hip:api-activity',handler);if(activityHideTimer.current)window.clearTimeout(activityHideTimer.current)}},[]);
  useEffect(()=>{Promise.all([api.bootstrap(),api.configurations()]).then(([b,c])=>{setBootstrap(b);setConfigs(c);let preferred='';try{preferred=localStorage.getItem('hip.activeConfigurationId')||''}catch{}const approved=c.find(x=>x.approved_reference||x.managed_reference_source==='reference:uhal');const selected=c.find(x=>x.id===preferred)||approved||c[0]||null;setActive(selected);try{if(selected)localStorage.setItem('hip.activeConfigurationId',selected.id)}catch{}}).catch(e=>setError(e.message))},[]);
  const go=(next:PageKey)=>{setPage(next);setMobileNavOpen(false);try{localStorage.setItem('hip.page',next)}catch{}};
  const toggleSidebar=()=>setSidebarCollapsed(value=>{const next=!value;try{localStorage.setItem('hip.sidebarCollapsed',next?'1':'0')}catch{}return next});
  const updateActive=(c:Configuration)=>{setActive(c);setSelectedTemplate(null);try{localStorage.setItem('hip.activeConfigurationId',c.id)}catch{}setConfigs(rows=>rows.some(x=>x.id===c.id)?rows.map(x=>x.id===c.id?c:x):[c,...rows])};
  const replaceConfigs=(rows:Configuration[])=>{setConfigs(rows);if(active){const refreshed=rows.find(x=>x.id===active.id);if(refreshed){setActive(refreshed);return}const approved=rows.find(x=>x.approved_reference||x.managed_reference_source==='reference:uhal');const next=approved||rows[0]||null;setActive(next);try{next?localStorage.setItem('hip.activeConfigurationId',next.id):localStorage.removeItem('hip.activeConfigurationId')}catch{}}};
  const syncTemplate=(t:FlowTemplate)=>setBootstrap(b=>b?({...b,templates:b.templates.some(x=>x.id===t.id)?b.templates.map(x=>x.id===t.id?t:x):[...b.templates,t]}):b);
  const useTemplate=(t:FlowTemplate)=>{setSelectedTemplate(t);go('flow')};
  const openFlow=()=>{setSelectedTemplate(null);setPage('flow');try{localStorage.setItem('hip.page','flow')}catch{}};
  const newConfiguration=()=>{setActive(null);setSelectedTemplate(null);try{localStorage.removeItem('hip.activeConfigurationId')}catch{}go('builder')};
  const findUhal=()=>configs.find(c=>c.managed_reference_source==='reference:uhal'||String(c.customer||'').toUpperCase().replace(/[^A-Z0-9]/g,'')==='UHAUL');
  const openUhal=()=>{const uhal=findUhal();if(!uhal){go('workspace');return}updateActive(uhal);go('workspace')};
  const startFromUhal=async()=>{const uhal=findUhal();if(!uhal)throw new Error('The approved U-HAUL starter configuration is not available yet. Refresh the Configuration Library and try again.');const row=await api.cloneConfiguration(uhal.id,'New Customer · U-HAUL starter');updateActive(row);go('builder')};
  if(error)return <div className="fatal-screen"><h1>HIP API Agent Studio could not start</h1><pre>{error}</pre></div>;
  if(!bootstrap)return <div className="loading-screen"><div className="loading-orb"/><strong>Starting HIP API Agent Studio…</strong></div>;
  return <div className={`app-shell ${sidebarCollapsed?'nav-collapsed':''}`}><Sidebar page={page} onChange={go} collapsed={sidebarCollapsed} onToggle={toggleSidebar} mobileOpen={mobileNavOpen} onMobileClose={()=>setMobileNavOpen(false)}/>{apiActivity.count>0&&<div className="global-api-activity" role="status" aria-live="polite"><LoaderCircle className="spin" size={16}/><span>Working…</span></div>}<main className="main-stage">
    <AppTopbar page={page} active={active} configs={configs} onMenu={()=>setMobileNavOpen(true)} onOpenWorkspace={()=>go('workspace')} onSelectCustomer={updateActive}/>
    {page==='dashboard'&&<DashboardPage bootstrap={bootstrap} configs={configs} onGo={go} onNewConfiguration={newConfiguration} onOpenUhal={openUhal} onStartFromUhal={startFromUhal}/>} 
    {page==='workspace'&&<WorkspacePage configs={configs} active={active} onActive={updateActive} onConfigs={replaceConfigs}/>} 
    {page==='mapper'&&<ExcelApiMapperPage bootstrap={bootstrap} active={active} onActive={updateActive}/>} 
    {page==='builder'&&<BuilderPage bootstrap={bootstrap} active={active} configurations={configs} onActive={updateActive} onTemplateSync={syncTemplate} onOpenFlow={openFlow} onOpenTesting={()=>go('testing')} onOpenParallel={()=>go('parallel')} onStartFromUhal={startFromUhal}/>} 
    {page==='flow'&&<FlowGamePage bootstrap={bootstrap} active={active} initialTemplate={selectedTemplate} onActive={updateActive}/>} 
    {page==='testing'&&<ApiTestingPage bootstrap={bootstrap} active={active} onActive={updateActive}/>} 
    {page==='operations'&&<OperationsPage active={active}/>} 
    {page==='templates'&&<TemplatesPage templates={bootstrap.templates} onUse={useTemplate}/>} 
    {page==='parallel'&&<ParallelPage active={active} onActive={updateActive}/>} 
    {page==='learn'&&<LearnPage active={active}/>} 
    {page==='reports'&&<ReportsPage active={active}/>} 
    {page==='system'&&<SystemPage active={active}/>} 
  </main></div>
}
