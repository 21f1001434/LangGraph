export function StatusBadge({ status }: { status: string }) {
  const normalized = (status || 'IDLE').toUpperCase();
  return <span className={`status-badge status-${normalized.replaceAll(' ', '_')}`}>{normalized}</span>;
}
