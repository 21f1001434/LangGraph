import { FileArchive, FileJson2, UploadCloud } from 'lucide-react';
import { useRef, useState } from 'react';

export function FileDrop({ onFiles, files }: { onFiles: (files: File[]) => void; files: File[] }) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return <div className={`file-drop ${over?'over':''}`} onDragOver={e=>{e.preventDefault();setOver(true)}} onDragLeave={()=>setOver(false)} onDrop={e=>{e.preventDefault();setOver(false);onFiles(Array.from(e.dataTransfer.files))}} onClick={()=>ref.current?.click()}>
    <input ref={ref} type="file" multiple hidden onChange={e=>onFiles(Array.from(e.target.files || []))}/>
    <UploadCloud size={30}/><strong>Drop customer files here</strong><span>ZIP, input.json, Configuration Manual, XML, EDI, XBM, JAR, TXT and JSON</span>
    {files.length > 0 && <div className="file-chip-row">{files.slice(0,6).map(file => <span key={file.name}>{file.name.endsWith('.json')?<FileJson2 size={12}/>:<FileArchive size={12}/>} {file.name}</span>)}{files.length>6&&<span>+{files.length-6} more</span>}</div>}
  </div>;
}
