import { Link2, Plus, Trash2, X, WandSparkles } from 'lucide-react';
import type { EdgeMapping, SuggestedMapping } from '../types';

export function EdgeInspector({ edge, sourceLabel, targetLabel, suggestions, onClose, onChange, onApplySuggestion }: {
  edge:{id:string;mappings:EdgeMapping[]}|null;sourceLabel:string;targetLabel:string;suggestions:SuggestedMapping[];
  onClose:()=>void;onChange:(mappings:EdgeMapping[])=>void;onApplySuggestion:(mapping:EdgeMapping)=>void;
}){
  if(!edge)return null;
  const update=(index:number,key:keyof EdgeMapping,value:string)=>onChange(edge.mappings.map((m,i)=>i===index?{...m,[key]:value}:m));
  const remove=(index:number)=>onChange(edge.mappings.filter((_,i)=>i!==index));
  const edgeSuggestions=suggestions.filter(s=>s.edgeId===edge.id);
  return <aside className="edge-inspector">
    <div className="inspector-head"><div><span>Connection mapping</span><strong>{sourceLabel} → {targetLabel}</strong></div><button onClick={onClose}><X size={18}/></button></div>
    <div className="edge-inspector-body">
      <p className="hint">Connections can carry runtime values only into fields that already exist in the approved API contract. Mapping Rule <code>documentTypeId</code> and <code>actions.params.mapId</code> are intentionally omitted per the latest Dev contract.</p>
      {edge.mappings.map((m,index)=><div className="mapping-editor-row" key={index}>
        <label><span>From upstream output</span><input value={m.from} placeholder="output.documentTypeId" onChange={e=>update(index,'from',e.target.value)}/></label>
        <Link2 size={14}/>
        <label><span>To downstream request</span><input value={m.to} placeholder="payload.documentTypeId" onChange={e=>update(index,'to',e.target.value)}/></label>
        <button className="icon-button" onClick={()=>remove(index)}><Trash2 size={14}/></button>
      </div>)}
      <button className="ghost compact-button" onClick={()=>onChange([...edge.mappings,{from:'',to:''}])}><Plus size={14}/>Add value mapping</button>
      {edgeSuggestions.length>0&&<div className="edge-suggestions"><div className="inspector-section-title"><WandSparkles size={13}/> Agent suggestions</div>{edgeSuggestions.map((s,i)=><button key={i} onClick={()=>onApplySuggestion(s.mapping)}><code>{s.mapping.from}</code><span>→</span><code>{s.mapping.to}</code><small>{s.reason}</small></button>)}</div>}
    </div>
  </aside>
}
