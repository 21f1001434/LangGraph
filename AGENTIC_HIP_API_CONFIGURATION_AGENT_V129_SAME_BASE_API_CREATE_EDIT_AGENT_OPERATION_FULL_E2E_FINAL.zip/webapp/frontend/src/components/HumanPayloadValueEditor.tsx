import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, RefreshCcw, ShieldCheck } from 'lucide-react';

type ScalarKind='string'|'number'|'boolean'|'null';
type Leaf={path:string;value:unknown;kind:ScalarKind};

function leaves(root:unknown,prefix=''):Leaf[]{
  if(root===null)return prefix?[{path:prefix,value:null,kind:'null'}]:[];
  if(Array.isArray(root))return root.flatMap((value:unknown,index:number)=>leaves(value,prefix?`${prefix}.${index}`:String(index)));
  if(typeof root==='object')return Object.entries(root as Record<string,unknown>).flatMap(([key,value]:[string,unknown])=>leaves(value,prefix?`${prefix}.${key}`:key));
  if(!prefix)return[];
  const kind:ScalarKind=typeof root==='boolean'?'boolean':typeof root==='number'?'number':'string';
  return [{path:prefix,value:root,kind}];
}
function readPath(root:unknown,path:string):unknown{
  let node:any=root;
  for(const part of path.split('.')){
    if(Array.isArray(node)){const index=Number(part);if(!Number.isInteger(index)||index<0||index>=node.length)return undefined;node=node[index]}
    else if(node&&typeof node==='object')node=node[part];
    else return undefined;
  }
  return node;
}
function writePath(root:Record<string,unknown>,path:string,value:unknown):Record<string,unknown>{
  const copy=JSON.parse(JSON.stringify(root??{})) as Record<string,unknown>;
  let node:any=copy;const parts=path.split('.');
  parts.forEach((part:string,index:number)=>{const last=index===parts.length-1;if(Array.isArray(node)){const pos=Number(part);if(last)node[pos]=value;else node=node[pos]}else{if(last)node[part]=value;else node=node[part]}});
  return copy;
}
function same(left:unknown,right:unknown){return JSON.stringify(left)===JSON.stringify(right)}
function text(value:unknown){return value===null?'null':String(value??'')}
function isSecret(path:string){return /(secret|password|token|certificate)/i.test(path)}
function operationValueFor(existing:string,mode:'create'|'edit'){
  if(existing===existing.toUpperCase())return mode.toUpperCase();
  if(existing.length>0&&existing[0]===existing[0].toUpperCase())return mode[0].toUpperCase()+mode.slice(1);
  return mode;
}
function setOperationMode(root:Record<string,unknown>,mode:'create'|'edit'):{value:Record<string,unknown>;paths:string[]}{
  const copy=JSON.parse(JSON.stringify(root??{})) as Record<string,unknown>;const paths:string[]=[];
  const walk=(node:unknown,prefix:string)=>{if(Array.isArray(node)){node.forEach((item:unknown,index:number)=>walk(item,prefix?`${prefix}.${index}`:String(index)));return}if(!node||typeof node!=='object')return;Object.entries(node as Record<string,unknown>).forEach(([key,value]:[string,unknown])=>{const path=prefix?`${prefix}.${key}`:key;const keyNorm=key.toLowerCase();if(typeof value==='string'&&(keyNorm==='operation'||keyNorm.endsWith('operation'))&&['create','edit'].includes(value.toLowerCase())){(node as Record<string,unknown>)[key]=operationValueFor(value,mode);paths.push(path)}else walk(value,path)})};
  walk(copy,'');return {value:copy,paths};
}

export function HumanPayloadValueEditor({
  effective,generated,requestKind='payload',identityKey='',disabled=false,disabledReason='',busy=false,
  compact=false,onSave,onRestoreAll
}:{
  effective:Record<string,unknown>;generated:Record<string,unknown>;requestKind?:'payload'|'params';identityKey?:string;
  disabled?:boolean;disabledReason?:string;busy?:boolean;compact?:boolean;
  onSave:(edited:Record<string,unknown>)=>Promise<unknown>;onRestoreAll:()=>Promise<unknown>;
}){
  const available=useMemo<Leaf[]>(()=>leaves(effective),[JSON.stringify(effective)]);
  const [path,setPath]=useState('');
  const [draft,setDraft]=useState('');
  const [kind,setKind]=useState<ScalarKind>('string');
  const [viewMode,setViewMode]=useState<'field'|'whole'>('whole');
  const [wholeDraft,setWholeDraft]=useState('{}');
  const [localBusy,setLocalBusy]=useState(false);
  const [message,setMessage]=useState('');
  const leaf=available.find((row:Leaf)=>row.path===path)||null;
  const generatedValue=path?readPath(generated,path):undefined;
  const modified=leaf?!same(leaf.value,generatedValue):false;

  useEffect(()=>{const first=available[0];setPath(first?.path||'');setDraft(first?text(first.value):'');setKind(first?.kind||'string');setWholeDraft(JSON.stringify(effective??{},null,2));setMessage('')},[identityKey,JSON.stringify(effective)]);
  useEffect(()=>{if(!leaf)return;setDraft(text(leaf.value));setKind(leaf.kind)},[path]);

  const parsed=()=>{if(kind==='null')return null;if(kind==='boolean')return draft==='true';if(kind==='number'){const n=Number(draft);if(!Number.isFinite(n))throw new Error('Enter a valid number.');return n}return draft};
  const save=async()=>{if(!path||disabled)return;try{setLocalBusy(true);setMessage('');await onSave(writePath(effective,path,parsed()));setMessage(`Saved human value edit for ${path}. The attribute path and request structure were not changed.`)}catch(e:any){setMessage(e?.message||String(e))}finally{setLocalBusy(false)}};
  const saveWhole=async()=>{if(disabled)return;try{setLocalBusy(true);setMessage('');let edited:unknown;try{edited=JSON.parse(wholeDraft)}catch(e:any){throw new Error(`Whole payload is not valid JSON: ${e?.message||String(e)}`)}if(!edited||typeof edited!=='object'||Array.isArray(edited))throw new Error('Whole payload must remain a JSON object.');await onSave(edited as Record<string,unknown>);setMessage('Saved whole payload value edits. Backend contract lock verified the exact same attributes/nesting/cardinality before persistence.')}catch(e:any){setMessage(e?.message||String(e))}finally{setLocalBusy(false)}};
  const prepareOperation=(mode:'create'|'edit')=>{try{const parsed=JSON.parse(wholeDraft) as Record<string,unknown>;if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw new Error('Whole payload must remain a JSON object.');const changed=setOperationMode(parsed,mode);if(!changed.paths.length){setMessage(`No existing create/edit operation field is present. ${mode.toUpperCase()} mode was not applied and no new attribute was added.`);return}setWholeDraft(JSON.stringify(changed.value,null,2));setMessage(`${mode.toUpperCase()} prepared in existing operation field(s): ${changed.paths.join(', ')}. Save whole payload to persist.`)}catch(e:any){setMessage(e?.message||String(e))}};
  const restoreSelected=async()=>{if(!path||disabled)return;try{setLocalBusy(true);setMessage('');await onSave(writePath(effective,path,generatedValue));setMessage(`Restored generated value for ${path}.`)}catch(e:any){setMessage(e?.message||String(e))}finally{setLocalBusy(false)}};
  const restoreAll=async()=>{if(disabled)return;try{setLocalBusy(true);setMessage('');await onRestoreAll();setMessage('Restored all generated values for this API.')}catch(e:any){setMessage(e?.message||String(e))}finally{setLocalBusy(false)}};
  const locked=disabled||busy||localBusy||!path;
  const wholeLocked=disabled||busy||localBusy;

  return <div className={`embedded-human-value-editor ${compact?'compact':''}`}>
    <div className="human-edit-policy"><ShieldCheck size={16}/><div><strong>VALUE ONLY · HUMAN USER</strong><span>Use Field view for one value or Whole payload to edit multiple existing values. Attribute names, method, URL, protected headers, nesting and array structure remain locked. The AI/agent has no arbitrary payload-edit authority; its only write exception is the Dev-approved Create/Edit selector for registered same-base-API TP/Flow operations.</span></div></div>
    <div className="payload-view-tabs"><button type="button" className={viewMode==='field'?'active':''} onClick={()=>setViewMode('field')}>Field view</button><button type="button" className={viewMode==='whole'?'active':''} onClick={()=>setViewMode('whole')}>Whole payload</button></div>
    {disabledReason&&<div className="warning-box">{disabledReason}</div>}
    {viewMode==='whole'?<div className="whole-payload-editor"><div className="payload-edit-head"><div><strong>Whole effective {requestKind}</strong><small>Change values only. The server rejects any key/nesting/array-structure change.</small></div><div className="button-row"><button className="secondary" type="button" disabled={wholeLocked} onClick={()=>prepareOperation('create')}>Set CREATE operation</button><button className="secondary" type="button" disabled={wholeLocked} onClick={()=>prepareOperation('edit')}>Set EDIT operation</button></div></div><textarea className="payload-json-editor" spellCheck={false} disabled={disabled} value={wholeDraft} onChange={e=>setWholeDraft(e.target.value)}/><div className="button-row human-value-actions"><button className="secondary" type="button" disabled={wholeLocked} onClick={()=>setWholeDraft(JSON.stringify(effective??{},null,2))}><RefreshCcw size={14}/>Reset unsaved JSON</button><button className="secondary" type="button" disabled={wholeLocked} onClick={restoreAll}><RefreshCcw size={14}/>Restore all for API</button><button className="primary" type="button" disabled={wholeLocked} onClick={saveWhole}><CheckCircle2 size={14}/>Save whole payload + revalidate</button></div></div>:!available.length?<div className="warning-box">This request has no editable scalar values in its current canonical structure.</div>:<>
      <div className="human-value-editor-grid"><div><label className="field-label">Attribute to change</label><select value={path} disabled={disabled} onChange={e=>setPath(e.target.value)}>{available.map((row:Leaf)=><option key={row.path} value={row.path}>{row.path}{!same(row.value,readPath(generated,row.path))?' · EDITED':''}</option>)}</select><p className="field-help">The attribute path is selectable but never editable.</p></div><div><label className="field-label">Locked attribute path</label><code className="locked-path">{path||'—'}</code><p className="field-help">{requestKind.toUpperCase()} · STRUCTURE LOCKED</p></div></div>
      <div className="human-value-compare"><div><span>GENERATED VALUE</span><code>{text(generatedValue)}</code></div><div className={modified?'edited':''}><span>CURRENT EFFECTIVE VALUE</span><code>{text(leaf?.value)}</code></div></div>
      <div className="human-value-editor-grid"><div><label className="field-label">Value data type</label><select value={kind} disabled={disabled} onChange={e=>setKind(e.target.value as ScalarKind)}><option value="string">Text / string</option><option value="number">Number</option><option value="boolean">Boolean</option><option value="null">Null</option></select></div><div><label className="field-label">New human-entered value</label>{kind==='boolean'?<select value={draft} disabled={disabled} onChange={e=>setDraft(e.target.value)}><option value="true">true</option><option value="false">false</option></select>:kind==='null'?<div className="locked-value">null</div>:<input className="text-input" type={isSecret(path)?'password':kind==='number'?'number':'text'} disabled={disabled} value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Enter the value you want"/>}</div></div>
      <div className="button-row human-value-actions"><button className="secondary" type="button" disabled={locked||!modified} onClick={restoreSelected}><RefreshCcw size={14}/>Restore selected</button><button className="secondary" type="button" disabled={locked} onClick={restoreAll}><RefreshCcw size={14}/>Restore all for API</button><button className="primary" type="button" disabled={locked} onClick={save}><CheckCircle2 size={14}/>Save selected value</button></div>
    </>}
    {message&&<div className="success-box human-edit-message">{message}</div>}
  </div>;
}
