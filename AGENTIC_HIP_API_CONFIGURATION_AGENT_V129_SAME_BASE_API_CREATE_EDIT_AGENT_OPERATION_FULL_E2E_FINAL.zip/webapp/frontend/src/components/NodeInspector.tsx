import { AlertTriangle, Braces, CheckCircle2, Clock3, FileOutput, Link2, LoaderCircle, MessageSquareText, Play, RotateCw, Send, Settings2, ShieldCheck, X } from 'lucide-react';
import type { ApiFlowNodeData, FlowNodeAgentCheck } from '../types';
import { useState } from 'react';
import { HumanPayloadValueEditor } from './HumanPayloadValueEditor';

export function NodeInspector({ node, onClose, onSettings, onApprove, onAgentCheck, onRunLive, onSaveValueEdit, onRestoreAllValueEdits, valueEditingDisabled, valueEditingDisabledReason, actionBusy }: {
  node: { id: string; data: ApiFlowNodeData } | null;
  onClose: () => void;
  onSaveValueEdit?: (id:string, value:Record<string,unknown>)=>Promise<unknown>;
  onRestoreAllValueEdits?: (id:string)=>Promise<unknown>;
  valueEditingDisabled?:boolean;
  valueEditingDisabledReason?:string;
  onSettings: (id: string, value: Partial<ApiFlowNodeData>) => void;
  onApprove?: (id: string) => void;
  onAgentCheck?: (id: string) => void;
  onRunLive?: (id: string) => void;
  actionBusy?: ''|'check'|'run';
}) {
  const [tab, setTab] = useState<'payload'|'response'|'agent'|'output'|'timing'|'settings'>('payload');
  if (!node) return null;
  const d = node.data;
  const agentCheck = d.agentCheck as FlowNodeAgentCheck | undefined;
  const tabs = [
    ['payload','Payload',Braces], ['response','Response',MessageSquareText], ['agent','Agent',Send], ['output','Output',FileOutput], ['timing','Timing',Clock3], ['settings','Settings',Settings2]
  ] as const;
  const value = tab === 'response' ? d.response : tab === 'agent' ? (d.verdict ?? d.agentCheck) : tab === 'output' ? d.output : d.timing;
  return <aside className="inspector">
    <div className="inspector-head"><div><span>{d.group}</span><strong>{d.label}</strong></div><button onClick={onClose}><X size={18}/></button></div>
    <div className="node-live-actions">
      <div className="node-live-copy">
        <span>INDIVIDUAL BLOCK</span>
        <strong>{agentCheck?.ready?'Agent checked · ready for LIVE':'Agent check required before LIVE'}</strong>
        <small>{agentCheck?.summary||'The agent will validate the latest effective payload, customer validation state, API applicability and standalone runtime dependencies.'}</small>
      </div>
      <div className="node-live-buttons">
        <button className="secondary" disabled={!!actionBusy||d.enabled===false} onClick={()=>onAgentCheck?.(node.id)}>{actionBusy==='check'?<LoaderCircle className="spin" size={14}/>:<ShieldCheck size={14}/>}Agent check</button>
        <button className="danger node-run-live" disabled={!!actionBusy||d.enabled===false} onClick={()=>onRunLive?.(node.id)}>{actionBusy==='run'?<LoaderCircle className="spin" size={14}/>:<Play size={14}/>}Check & run this block LIVE</button>
      </div>
      {agentCheck&&<div className={`node-agent-check ${agentCheck.ready?'ready':'blocked'}`}>
        <div className="node-agent-check-head">{agentCheck.ready?<CheckCircle2 size={15}/>:<AlertTriangle size={15}/>}<strong>{agentCheck.verdict}</strong><span>{agentCheck.checks.filter(x=>x.status==='PASS').length}/{agentCheck.checks.length} checks passed</span></div>
        <div className="node-agent-check-list">{agentCheck.checks.map(item=><div key={item.key} className={`check-${item.status.toLowerCase()}`}><b>{item.status}</b><span><strong>{item.label}</strong><small>{item.reason}</small></span></div>)}</div>
      </div>}
    </div>
    <div className="inspector-tabs">{tabs.map(([key,label,Icon]) => <button key={key} className={tab===key?'active':''} onClick={()=>setTab(key)}><Icon size={14}/>{label}</button>)}</div>
    <div className="inspector-body">
      {d.status==='AWAITING_APPROVAL'&&<div className="approval-callout"><ShieldCheck size={16}/><div><strong>LIVE approval required</strong><span>{String(d.approvalMessage||'Review this API request before continuing.')}</span></div><button className="primary" onClick={()=>onApprove?.(node.id)}>Approve step</button></div>}
      {tab === 'payload' && <>
        <p className="hint">Immutable API policy: Ad-hoc payload/parameter mutation is disabled. Human value editing is available directly on this API block only through the governed value-only editor. Select an existing attribute and change only its value; the attribute name/path and canonical request structure remain immutable. Runtime edge mappings may also populate only existing approved attributes.</p>
        <div className="inspector-section-title">Human Payload Value Editor</div>
        <HumanPayloadValueEditor compact identityKey={`${d.apiKey}:${String(d.requestKind||'payload')}`} effective={(d.payload??{}) as Record<string,unknown>} generated={(d.generatedRequest??d.payload??{}) as Record<string,unknown>} requestKind={d.requestKind==='params'?'params':'payload'} busy={!!actionBusy} disabled={Boolean(valueEditingDisabled)||d.applicable===false} disabledReason={valueEditingDisabledReason|| (d.applicable===false?'This API is not applicable to the active configuration.':'')} onSave={(edited)=>onSaveValueEdit?onSaveValueEdit(node.id,edited):Promise.reject(new Error('Value editing is unavailable.'))} onRestoreAll={()=>onRestoreAllValueEdits?onRestoreAllValueEdits(node.id):Promise.reject(new Error('Restore is unavailable.'))}/>
        <details className="node-generated-details"><summary>Generated/effective request baseline · read only</summary><pre className="json-view compact-json">{JSON.stringify(d.generatedRequest ?? d.payload ?? {}, null, 2)}</pre></details>
      </>}
      {tab === 'timing' && <>
        <pre className="json-view">{JSON.stringify(d.timing ?? {}, null, 2)}</pre>
        <div className="inspector-section-title"><RotateCw size={12}/> HTTP attempts / retries</div>
        <pre className="json-view compact-json">{JSON.stringify(d.retries ?? [], null, 2)}</pre>
        <div className="inspector-section-title"><Link2 size={12}/> Resolved connection mappings</div>
        <pre className="json-view compact-json">{JSON.stringify(d.resolvedMappings ?? [], null, 2)}</pre>
      </>}
      {tab === 'settings' && <div className="node-settings-grid">
        <label><span>Enabled</span><input type="checkbox" checked={d.enabled!==false} onChange={e=>onSettings(node.id,{enabled:e.target.checked})}/></label>
        <label><span>Stop flow if blocked</span><input type="checkbox" checked={d.stopOnBlocked!==false} onChange={e=>onSettings(node.id,{stopOnBlocked:e.target.checked})}/></label>
        <label><span>Manual approval before LIVE API</span><input type="checkbox" checked={d.approvalRequired===true} onChange={e=>onSettings(node.id,{approvalRequired:e.target.checked})}/></label>
        {d.approvalRequired&&<label className="wide-setting"><span>Approval message</span><input value={String(d.approvalMessage||'')} placeholder="Example: Approve Flow Deploy" onChange={e=>onSettings(node.id,{approvalMessage:e.target.value})}/></label>}
        <label><span>Wait after step (seconds)</span><input type="number" min="0" step="0.1" value={Number(d.waitAfterSeconds||0)} onChange={e=>onSettings(node.id,{waitAfterSeconds:Math.max(0,Number(e.target.value)||0)})}/></label>
      </div>}
      {!['payload','timing','settings'].includes(tab) && <pre className="json-view">{JSON.stringify(value ?? {}, null, 2)}</pre>}
    </div>
  </aside>;
}
