import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Bot, CheckCircle2, LoaderCircle, ShieldCheck, X } from 'lucide-react';
import type { BuilderQuestion, Configuration, ParallelSource } from '../types';
import { api } from '../lib/api';

function same(a:unknown,b:unknown){return String(a??'').trim().toLowerCase()===String(b??'').trim().toLowerCase()}

function questionValue(q:BuilderQuestion,answers:Record<string,string>){return answers[q.id]||''}

function ConflictChoice({q,value,onChange}:{q:BuilderQuestion;value:string;onChange:(value:string)=>void}){
  const [custom,setCustom]=useState('');
  const c=q.conflict||{fileValues:[],fileSources:[]};
  const fileValues=(c.fileValues||[]).map(v=>String(v??''));
  const selected=c.selectedValue==null?'':String(c.selectedValue);
  return <div className="quick-fix-conflict">
    <div className="quick-fix-compare">
      <div className={fileValues.some(v=>same(v,value))?'quick-fix-choice chosen':'quick-fix-choice'}>
        <span>CUSTOMER FILE</span>
        {fileValues.length?fileValues.map((v,i)=>{const ev=c.fileEvidence?.[i];return <div className="quick-fix-candidate" key={`${q.id}-file-${i}`}><strong>{v||'Blank'}</strong><small>{ev?.sourceFile||c.fileSources?.[i]||'Uploaded evidence'}</small><button className="secondary" onClick={()=>onChange(v)}>Use this</button></div>}):<small>No file value was found.</small>}
      </div>
      <div className={selected&&same(selected,value)?'quick-fix-choice chosen':'quick-fix-choice'}>
        <span>USER SELECTION</span><strong>{selected||'Not selected'}</strong><small>{c.selectedField||q.path}</small><button className="secondary" disabled={!selected} onClick={()=>onChange(selected)}>Keep this</button>
      </div>
      <div className={custom&&same(custom,value)?'quick-fix-choice chosen':'quick-fix-choice'}>
        <span>ANOTHER VALUE</span><input value={custom} onChange={e=>setCustom(e.target.value)} placeholder="Enter the approved value"/><small>Use only when neither value is correct.</small><button className="secondary" disabled={!custom.trim()} onClick={()=>onChange(custom.trim())}>Use custom</button>
      </div>
    </div>
    {value&&<div className="quick-fix-selected"><CheckCircle2 size={15}/>Selected for the agent: <b>{value}</b></div>}
  </div>
}

function contractQuestions(item:any){
  if(Array.isArray(item?.repairQuestions)&&item.repairQuestions.length)return item.repairQuestions;
  return (item?.errors||[]).map((err:any,i:number)=>{
    const field=String(err?.field||'request');
    const headerEditable=item?.stepKey==='partner_target'&&field.toLowerCase()==='header.x-account-name';
    const protectedField=field==='method'||field==='url'||field==='request'||(field.toLowerCase().startsWith('header.')&&!headerEditable);
    return {id:`${item?.stepKey||'api'}::${field}::${i}`,stepKey:item?.stepKey,field,label:`Correct ${field}`,message:err?.message||String(err),currentValue:'',inputType:'text',editable:!protectedField,why:protectedField?'This field is agent-managed. Revalidate after resolving the configuration decisions.':'Enter only the approved customer/HIP value.'};
  });
}

export function ConfigurationFixModal({source,onClose,onResolved}:{source:ParallelSource;onClose:()=>void;onResolved:(configuration:Configuration)=>void}){
  const [configuration,setConfiguration]=useState<Configuration|null>(null);
  const [answers,setAnswers]=useState<Record<string,string>>({});
  const [fixes,setFixes]=useState<Record<string,string>>({});
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('The agent will show only the decision that is preventing this customer from continuing.');
  const configId=source.repairConfigurationId||source.configurationId||'';

  const load=async()=>{
    if(!configId){setMessage(source.error||'This source does not yet have an editable configuration workspace.');return}
    try{setBusy(true);const cfg=await api.getConfiguration(configId);setConfiguration(cfg);setMessage(cfg.questions?.filter(q=>!q.informational).length?'Choose the correct value below. Your explicit human action saves it; the agent only re-checks the resulting request.':'No unanswered Build Configuration decisions remain. Checking the 18 base API contracts + 7 Migration blocks…');if(!cfg.questions?.filter(q=>!q.informational).length){try{await api.validateConfiguration(cfg.id);setConfiguration(await api.getConfiguration(cfg.id))}catch{}}}catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}};
  useEffect(()=>{load()},[configId]);

  const questions=(configuration?.questions||[]).filter(q=>!q.informational);
  const validation=configuration?.validation as any;
  const blocked=useMemo(()=>((validation?.requests?.blockedItems||validation?.requests?.items||[]) as any[]).filter(x=>x?.valid===false),[validation]);
  const ready=Boolean(configuration?.validation?.ok)&&questions.length===0;

  const applyDecisions=async()=>{
    if(!configuration)return;
    const required=questions.filter(q=>!String(answers[q.id]||'').trim());
    if(required.length){setMessage(`Choose or enter a value for ${required.length} remaining decision${required.length===1?'':'s'}.`);return}
    try{
      setBusy(true);setMessage('Saving your decision and rebuilding the effective configuration…');
      await api.answerQuestions(configuration.id,answers);
      let cfg=await api.getConfiguration(configuration.id);
      if(!(cfg.questions||[]).some(q=>!q.informational)){
        setMessage('Decision saved. The agent is now validating the 18 base HIP API contracts + Migration readiness…');
        await api.validateConfiguration(configuration.id);
        cfg=await api.getConfiguration(configuration.id);
      }
      setConfiguration(cfg);setAnswers({});
      if(cfg.validation?.ok){setMessage('Resolved successfully. This customer is validated and ready to select.');onResolved(cfg)}
      else if((cfg.questions||[]).some(q=>!q.informational))setMessage('One more configuration decision is required below.');
      else setMessage('Configuration decision resolved. One or more API contract values still need attention below.');
    }catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}
  };

  const applyContractFixes=async()=>{
    if(!configuration)return;
    const payload:any[]=[];
    blocked.forEach(item=>contractQuestions(item).forEach((q:any)=>{const value=String(fixes[q.id]??'').trim();if(q.editable&&value)payload.push({step_key:q.stepKey||item.stepKey,field:q.field,value})}));
    if(!payload.length){setMessage('Enter at least one corrected value first.');return}
    try{setBusy(true);setMessage('Applying the correction and revalidating immediately…');await api.applyValidationFixes(configuration.id,payload);const cfg=await api.getConfiguration(configuration.id);setConfiguration(cfg);setFixes({});if(cfg.validation?.ok){setMessage('Resolved successfully. This customer is validated and ready to select.');onResolved(cfg)}else setMessage('Correction saved. Review the remaining issue below.')}catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}
  };

  const revalidate=async()=>{if(!configuration)return;try{setBusy(true);await api.validateConfiguration(configuration.id);const cfg=await api.getConfiguration(configuration.id);setConfiguration(cfg);if(cfg.validation?.ok){setMessage('Validation passed. This customer is ready to use.');onResolved(cfg)}else setMessage('Validation still needs attention. The exact blocker is shown below.')}catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}};

  return <div className="quick-fix-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}>
    <section className="quick-fix-modal" role="dialog" aria-modal="true" aria-label={`Fix ${source.customer}`}>
      <header className="quick-fix-head"><div><span className="eyebrow"><Bot size={14}/> Guided issue resolution</span><h2>{source.customer} needs attention</h2><p>You do not need to know the HIP APIs. Choose the correct business value and the agent will update, rebuild and validate it for you.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18}/></button></header>
      <div className={ready?'quick-fix-status success':'quick-fix-status warning'}>{ready?<CheckCircle2 size={18}/>:<AlertTriangle size={18}/>}<div><strong>{ready?'Ready to use':source.nextAction||'A decision is blocking this configuration'}</strong><span>{message}</span></div></div>

      {busy&&!configuration&&<div className="quick-fix-loading"><LoaderCircle className="spin" size={20}/>Loading the exact issue…</div>}

      {questions.length>0&&<div className="quick-fix-section"><div className="quick-fix-section-title"><span>STEP 1</span><h3>Choose the correct configuration value</h3></div>{questions.map(q=><div className="quick-fix-question" key={q.id}><div className="quick-fix-question-copy"><strong>{q.label}</strong><span>{q.question||q.why}</span><small>{q.why}</small></div>{q.type==='conflict'?<ConflictChoice q={q} value={questionValue(q,answers)} onChange={value=>setAnswers(v=>({...v,[q.id]:value}))}/>:q.options?.length?<select value={questionValue(q,answers)} onChange={e=>setAnswers(v=>({...v,[q.id]:e.target.value}))}><option value="">Choose…</option>{q.options.map(option=><option key={option} value={option}>{option}</option>)}</select>:<input type={q.secret?'password':'text'} value={questionValue(q,answers)} onChange={e=>setAnswers(v=>({...v,[q.id]:e.target.value}))} placeholder="Enter approved value"/>}</div>)}<button className="primary wide" disabled={busy} onClick={applyDecisions}>{busy?<LoaderCircle className="spin" size={16}/>:<CheckCircle2 size={16}/>}Save decision & check automatically</button></div>}

      {questions.length===0&&!ready&&blocked.length>0&&<div className="quick-fix-section"><div className="quick-fix-section-title"><span>STEP 2</span><h3>Correct the blocked API value</h3></div>{blocked.map((item:any)=><div className="quick-fix-contract" key={item.stepKey||item.label}><div><strong>{item.label||item.stepKey}</strong><span>{item.nextAction||'The agent found a value that must be confirmed.'}</span></div>{contractQuestions(item).map((q:any)=><div className="quick-fix-contract-row" key={q.id}><div><b>{q.label||q.field}</b><span>{q.message}</span><small>{q.why}</small></div>{q.editable?<input value={fixes[q.id]||''} onChange={e=>setFixes(v=>({...v,[q.id]:e.target.value}))} placeholder={q.currentValue?`Current: ${q.currentValue}`:'Enter corrected value'}/>:<span className="agent-managed-value">Agent-managed</span>}</div>)}</div>)}<button className="primary wide" disabled={busy} onClick={applyContractFixes}>{busy?<LoaderCircle className="spin" size={16}/>:<ShieldCheck size={16}/>}Apply correction & revalidate</button></div>}

      {questions.length===0&&!ready&&blocked.length===0&&configuration&&<div className="quick-fix-section"><div className="empty-mini">No user question is pending. Run the validation again so the agent can refresh the exact blocker.</div><button className="primary wide" disabled={busy} onClick={revalidate}>{busy?<LoaderCircle className="spin" size={16}/>:<ShieldCheck size={16}/>}Re-check configuration</button></div>}

      {ready&&<div className="quick-fix-ready"><CheckCircle2 size={24}/><div><strong>Resolved</strong><span>{source.customer} is now selectable for API Flow and LIVE execution.</span></div><button className="primary" onClick={onClose}>Done</button></div>}
    </section>
  </div>
}
