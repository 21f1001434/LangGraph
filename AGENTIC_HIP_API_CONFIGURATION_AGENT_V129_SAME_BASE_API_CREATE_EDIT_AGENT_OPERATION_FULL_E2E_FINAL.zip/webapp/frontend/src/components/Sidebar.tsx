import {
  Activity,
  Blocks,
  Bot,
  Boxes,
  FileBarChart2,
  FilePlus2,
  FlaskConical,
  FolderOpen,
  Gauge,
  LayoutTemplate,
  FileSpreadsheet,
  PanelLeftClose,
  PanelLeftOpen,
  PlayCircle,
  Server,
  Sparkles,
  X,
} from 'lucide-react';

export type PageKey='dashboard'|'workspace'|'builder'|'mapper'|'flow'|'testing'|'operations'|'templates'|'parallel'|'learn'|'reports'|'system';

type NavItem={key:PageKey;label:string;icon:typeof Gauge};
type NavGroup={label:string;items:NavItem[]};

const groups:NavGroup[]=[
  {label:'Configure',items:[
    {key:'dashboard',label:'Home',icon:Gauge},
    {key:'workspace',label:'Configuration Library',icon:FolderOpen},
    {key:'builder',label:'Build Configuration',icon:FilePlus2},
    {key:'mapper',label:'Excel → API Mapper',icon:FileSpreadsheet},
    {key:'flow',label:'API Flow Game',icon:Blocks},
    {key:'testing',label:'API Testing Area',icon:FlaskConical},
  ]},
  {label:'Run & observe',items:[
    {key:'parallel',label:'Execute',icon:PlayCircle},
    {key:'operations',label:'Operations',icon:Activity},
    {key:'reports',label:'Reports',icon:FileBarChart2},
  ]},
  {label:'Knowledge',items:[
    {key:'templates',label:'Templates',icon:LayoutTemplate},
    {key:'learn',label:'Learn',icon:Bot},
  ]},
  {label:'Administration',items:[
    {key:'system',label:'System & Connections',icon:Server},
  ]},
];

export function Sidebar({
  page,onChange,collapsed,onToggle,mobileOpen,onMobileClose,
}:{
  page:PageKey;
  onChange:(page:PageKey)=>void;
  collapsed:boolean;
  onToggle:()=>void;
  mobileOpen:boolean;
  onMobileClose:()=>void;
}){
  const navigate=(next:PageKey)=>{onChange(next);onMobileClose()};
  return <>
    <div className={mobileOpen?'sidebar-scrim visible':'sidebar-scrim'} onClick={onMobileClose}/>
    <aside className={`sidebar ${collapsed?'sidebar-collapsed':''} ${mobileOpen?'mobile-open':''}`} aria-label="Primary navigation">
      <div className="sidebar-brand-row">
        <div className="brand-mark" aria-hidden="true"><Sparkles size={18}/><span>HIP</span></div>
        {/* Phase 6 navigation model retained; the release phase is intentionally not shown as UI copy. */}
        <div className="brand-copy"><strong>HIP API Agent Studio</strong><span>Guided HIP configuration and execution</span></div>
        <button className="sidebar-mobile-close" onClick={onMobileClose} aria-label="Close navigation"><X size={18}/></button>
      </div>
      <button className="sidebar-toggle" onClick={onToggle} aria-label={collapsed?'Expand navigation':'Collapse navigation'} title={collapsed?'Expand navigation':'Collapse navigation'}>
        {collapsed?<PanelLeftOpen size={16}/>:<PanelLeftClose size={16}/>}<span>{collapsed?'Expand':'Collapse'}</span>
      </button>
      <nav>
        {groups.map(group=><div className="nav-group" key={group.label}>
          <div className="nav-group-label">{group.label}</div>
          {group.items.map(item=>{const Icon=item.icon;return <button key={item.key} className={page===item.key?'nav-item active':'nav-item'} onClick={()=>navigate(item.key)} title={collapsed?item.label:undefined} aria-current={page===item.key?'page':undefined}>
            <Icon size={18}/><span>{item.label}</span><i className="nav-active-indicator"/>
          </button>})}
        </div>)}
      </nav>
      <div className="sidebar-foot">
        <div className="live-pill"><span className="live-dot"/><span className="live-copy">LIVE ONLY</span></div>
        <div className="sidebar-note"><Boxes size={14}/><span>Guided HIP workspace<br/><b>18 base + 7 Migration</b></span></div>
      </div>
    </aside>
  </>;
}
