from __future__ import annotations

import hashlib
import io
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from production_guard import redact_sensitive

BUNDLE_FORMAT = "agentic-hip-configuration-bundle/v1"
MAX_BUNDLE_BYTES = 250 * 1024 * 1024
MAX_FILE_BYTES = 80 * 1024 * 1024
MAX_FILES = 500


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_arcname(name: str) -> str:
    value = str(name or "").replace("\\", "/").lstrip("/")
    parts = [p for p in value.split("/") if p not in {"", "."}]
    if not parts or any(p == ".." for p in parts):
        raise ValueError(f"Unsafe bundle path: {name}")
    return "/".join(parts)


def _allowed_export_files(workspace: Path) -> Iterable[Tuple[str, Path]]:
    workspace = Path(workspace).resolve()
    for direct in ("input.json", "payload_overrides.json", "execution_flow.json"):
        path = workspace / direct
        if path.is_file():
            yield direct, path
    for folder_name in ("input_files", "uploads"):
        folder = workspace / folder_name
        if not folder.exists():
            continue
        for path in sorted(p for p in folder.rglob("*") if p.is_file()):
            rel = path.relative_to(workspace).as_posix()
            yield rel, path


def build_configuration_bundle(record: Dict[str, Any]) -> bytes:
    workspace = Path(record["workspace"]).resolve()
    safe_record = dict(record)
    for key in ("workspace", "validation", "mapping_learning"):
        safe_record.pop(key, None)
    safe_record["status"] = "IMPORTED_REVALIDATION_REQUIRED"
    safe_record["questions"] = []
    safe_record["build_summary"] = redact_sensitive(safe_record.get("build_summary") or {})

    files: Dict[str, bytes] = {"configuration.json": _json_bytes(redact_sensitive(safe_record))}
    for arcname, path in _allowed_export_files(workspace):
        data = path.read_bytes()
        if len(data) > MAX_FILE_BYTES:
            raise ValueError(f"File too large for safe export: {arcname}")
        files[_safe_arcname(arcname)] = data

    manifest_files = [
        {"path": name, "size": len(data), "sha256": _sha256(data)}
        for name, data in sorted(files.items())
    ]
    manifest = {
        "format": BUNDLE_FORMAT,
        "exportedAt": datetime.now(timezone.utc).isoformat(),
        "sourceConfigurationId": record.get("id"),
        "deploymentGroup": "hip-automation",
        "liveOnlyExecution": True,
        "requiresRevalidationOnImport": True,
        "files": manifest_files,
    }
    files["bundle_manifest.json"] = _json_bytes(manifest)

    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, data in sorted(files.items()):
            zf.writestr(name, data)
    return out.getvalue()


def inspect_configuration_bundle(data: bytes) -> Dict[str, Any]:
    if len(data) > MAX_BUNDLE_BYTES:
        raise ValueError("Configuration bundle exceeds the safe upload limit.")
    with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
        infos = zf.infolist()
        if len(infos) > MAX_FILES:
            raise ValueError("Configuration bundle contains too many files.")
        names = {_safe_arcname(info.filename): info for info in infos if not info.is_dir()}
        if "bundle_manifest.json" not in names or "configuration.json" not in names:
            raise ValueError("Not an Agentic HIP configuration bundle.")
        manifest = json.loads(zf.read(names["bundle_manifest.json"]).decode("utf-8"))
        if manifest.get("format") != BUNDLE_FORMAT:
            raise ValueError("Unsupported Agentic HIP bundle format.")
        expected = {str(row.get("path")): row for row in (manifest.get("files") or [])}
        verified: List[Dict[str, Any]] = []
        for path, row in expected.items():
            safe = _safe_arcname(path)
            info = names.get(safe)
            if not info:
                raise ValueError(f"Bundle file missing: {safe}")
            if info.file_size > MAX_FILE_BYTES:
                raise ValueError(f"Bundle member is too large: {safe}")
            payload = zf.read(info)
            digest = _sha256(payload)
            if digest != str(row.get("sha256") or ""):
                raise ValueError(f"Bundle integrity check failed: {safe}")
            verified.append({"path": safe, "size": len(payload), "sha256": digest})
        configuration = json.loads(zf.read(names["configuration.json"]).decode("utf-8"))
        return {
            "manifest": manifest,
            "configuration": redact_sensitive(configuration),
            "verifiedFiles": verified,
            "fileCount": len(verified),
            "integrityOk": True,
        }


def import_configuration_bundle(store: Any, data: bytes) -> Dict[str, Any]:
    inspected = inspect_configuration_bundle(data)
    source = inspected["configuration"]
    allowed = {
        "name", "customer", "direction", "transaction_code", "transaction_name", "flow_type",
        "source_interface", "target_interface", "input_mode", "user_instructions",
    }
    payload = {key: source.get(key) for key in allowed if key in source}
    payload["name"] = f"{payload.get('name') or 'Imported HIP Configuration'} (Imported)"
    record = store.create_configuration(payload)
    workspace = Path(record["workspace"]).resolve()

    with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
        manifest_paths = {str(row.get("path")) for row in (inspected["manifest"].get("files") or [])}
        for name in sorted(manifest_paths):
            safe = _safe_arcname(name)
            if safe == "configuration.json":
                continue
            if not (safe in {"input.json", "payload_overrides.json", "execution_flow.json"} or safe.startswith("input_files/") or safe.startswith("uploads/")):
                continue
            target = (workspace / safe).resolve()
            if workspace not in target.parents and target != workspace:
                raise ValueError(f"Unsafe import target: {safe}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(safe))

    uploads = workspace / "uploads"
    uploaded_files = []
    if uploads.exists():
        for path in sorted(p for p in uploads.rglob("*") if p.is_file()):
            uploaded_files.append({"name": path.name, "size": path.stat().st_size})
    input_path = workspace / "input.json"
    status = "READY_FOR_API_MAPPING" if input_path.exists() else "FILES_UPLOADED"
    return store.update_configuration(record["id"], {
        "status": status,
        "uploaded_files": uploaded_files,
        "imported_from_configuration": inspected["manifest"].get("sourceConfigurationId") or "",
        "import_bundle_integrity": True,
        "validation": {},
        "questions": [],
    })


def build_execution_evidence_bundle(record: Dict[str, Any], config: Dict[str, Any], reports: List[Dict[str, Any]]) -> bytes:
    out = io.BytesIO()
    files: Dict[str, bytes] = {
        "execution.json": _json_bytes(redact_sensitive(record)),
        "configuration_summary.json": _json_bytes(redact_sensitive({
            "id": config.get("id"), "name": config.get("name"), "customer": config.get("customer"),
            "direction": config.get("direction"), "transaction_code": config.get("transaction_code"),
            "flow_type": config.get("flow_type"), "source_interface": config.get("source_interface"),
            "target_interface": config.get("target_interface"), "deployment_group": "hip-automation",
        })),
        "report_index.json": _json_bytes(redact_sensitive(reports)),
    }
    manifest = {
        "format": "agentic-hip-execution-evidence/v1",
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "executionId": record.get("id"),
        "configurationId": record.get("configuration_id"),
        "files": [{"path": name, "sha256": _sha256(data), "size": len(data)} for name, data in sorted(files.items())],
    }
    files["evidence_manifest.json"] = _json_bytes(manifest)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, payload in sorted(files.items()):
            zf.writestr(name, payload)
    return out.getvalue()
