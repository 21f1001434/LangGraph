from __future__ import annotations

import hashlib
import json
import shutil
import threading
import uuid

from .resilient_io import atomic_write_json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

_LOCK = threading.RLock()


class JsonStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.config_root = self.root / "configurations"
        self.template_root = self.root / "templates"
        self.execution_root = self.root / "executions"
        self.template_history_root = self.root / "template_history"
        self.audit_root = self.root / "audit"
        for folder in (self.config_root, self.template_root, self.execution_root, self.template_history_root, self.audit_root):
            folder.mkdir(parents=True, exist_ok=True)
        self.audit_path = self.audit_root / "events.jsonl"

    @staticmethod
    def _read(path: Path, default: Any) -> Any:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default

    @staticmethod
    def _write(path: Path, value: Any) -> None:
        atomic_write_json(path, value)

    @staticmethod
    def _safe_audit_value(value: Any) -> Any:
        sensitive_tokens = ("secret", "password", "token", "authorization", "client_secret", "private_key")
        if isinstance(value, dict):
            out = {}
            for key, item in value.items():
                if any(token in str(key).lower() for token in sensitive_tokens):
                    out[key] = "[REDACTED]"
                else:
                    out[key] = JsonStore._safe_audit_value(item)
            return out
        if isinstance(value, list):
            return [JsonStore._safe_audit_value(v) for v in value]
        if isinstance(value, str) and len(value) > 4000:
            return value[:4000] + "…"
        return value

    def append_audit(self, action: str, entity_type: str, entity_id: str = "", *, actor: str = "User", summary: str = "", metadata: Dict[str, Any] | None = None) -> Dict[str, Any]:
        with _LOCK:
            previous_hash = ""
            if self.audit_path.exists():
                try:
                    last = self.audit_path.read_text(encoding="utf-8").strip().splitlines()[-1]
                    previous_hash = str(json.loads(last).get("hash") or "")
                except Exception:
                    previous_hash = ""
            event = {
                "id": uuid.uuid4().hex[:16],
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "actor": str(actor or "User")[:200],
                "action": str(action),
                "entity_type": str(entity_type),
                "entity_id": str(entity_id or ""),
                "summary": str(summary or "")[:1000],
                "metadata": self._safe_audit_value(metadata or {}),
                "previous_hash": previous_hash,
            }
            canonical = json.dumps(event, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
            event["hash"] = hashlib.sha256(canonical).hexdigest()
            with self.audit_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
            return event

    def list_audit(self, *, entity_type: str = "", entity_id: str = "", limit: int = 200) -> List[Dict[str, Any]]:
        if not self.audit_path.exists():
            return []
        rows: List[Dict[str, Any]] = []
        for line in reversed(self.audit_path.read_text(encoding="utf-8").splitlines()):
            try:
                item = json.loads(line)
            except Exception:
                continue
            if entity_type and str(item.get("entity_type") or "") != str(entity_type):
                continue
            if entity_id and str(item.get("entity_id") or "") != str(entity_id):
                continue
            rows.append(item)
            if len(rows) >= max(1, min(int(limit or 200), 1000)):
                break
        return rows

    def verify_audit(self) -> Dict[str, Any]:
        if not self.audit_path.exists():
            return {"ok": True, "events": 0, "brokenAt": ""}
        previous = ""
        count = 0
        for line in self.audit_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            count += 1
            try:
                item = json.loads(line)
            except Exception:
                return {"ok": False, "events": count - 1, "brokenAt": f"line:{count}"}
            stored_hash = str(item.pop("hash", ""))
            if str(item.get("previous_hash") or "") != previous:
                return {"ok": False, "events": count - 1, "brokenAt": str(item.get("id") or count)}
            canonical = json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
            calculated = hashlib.sha256(canonical).hexdigest()
            if calculated != stored_hash:
                return {"ok": False, "events": count - 1, "brokenAt": str(item.get("id") or count)}
            previous = stored_hash
        return {"ok": True, "events": count, "brokenAt": "", "headHash": previous}

    def create_configuration(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        with _LOCK:
            cid = uuid.uuid4().hex[:12]
            workspace = self.config_root / cid
            workspace.mkdir(parents=True, exist_ok=False)
            (workspace / "uploads").mkdir()
            (workspace / "input_files").mkdir()
            (workspace / "payloads").mkdir()
            (workspace / "reports").mkdir()
            now = datetime.now(timezone.utc).isoformat()
            record = {
                "id": cid,
                **payload,
                "status": "DRAFT",
                "created_at": now,
                "updated_at": now,
                "workspace": str(workspace),
                "uploaded_files": [],
                "questions": [],
                "build_summary": {},
            }
            self._write(workspace / "configuration.json", record)
            return record

    def get_configuration(self, cid: str) -> Dict[str, Any]:
        workspace = self.config_root / cid
        record = self._read(workspace / "configuration.json", {})
        if not record:
            raise KeyError(cid)
        record["workspace"] = str(workspace)
        return record

    def update_configuration(self, cid: str, patch: Dict[str, Any]) -> Dict[str, Any]:
        with _LOCK:
            record = self.get_configuration(cid)
            for key, value in patch.items():
                if value is not None:
                    record[key] = value
            record["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._write(Path(record["workspace"]) / "configuration.json", record)
            return record

    def list_configurations(self) -> List[Dict[str, Any]]:
        rows = []
        for folder in sorted(self.config_root.iterdir(), reverse=True):
            if folder.is_dir():
                item = self._read(folder / "configuration.json", {})
                if item:
                    item["workspace"] = str(folder)
                    rows.append(item)
        return rows

    def delete_configuration(self, cid: str) -> bool:
        with _LOCK:
            folder = self.config_root / cid
            if not folder.exists():
                return False
            shutil.rmtree(folder)
            return True

    def clone_configuration(self, cid: str, name: str = "") -> Dict[str, Any]:
        source = self.get_configuration(cid)
        payload_keys = ("name", "customer", "direction", "transaction_code", "transaction_name", "flow_type", "source_interface", "target_interface", "input_mode", "user_instructions")
        payload = {key: source.get(key) for key in payload_keys}
        payload["name"] = name or f"{source.get('name') or 'HIP Configuration'} Copy"
        target = self.create_configuration(payload)
        source_ws = Path(source["workspace"])
        target_ws = Path(target["workspace"])
        for rel in ("input.json", "payload_overrides.json", "execution_flow.json", "input_files", "uploads"):
            src = source_ws / rel
            dst = target_ws / rel
            if src.is_file():
                shutil.copy2(src, dst)
            elif src.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
        uploaded = []
        for path in sorted((target_ws / "uploads").rglob("*")) if (target_ws / "uploads").exists() else []:
            if path.is_file():
                uploaded.append({"name": path.name, "size": path.stat().st_size})
        status = "READY_FOR_API_MAPPING" if (target_ws / "input.json").exists() else ("FILES_UPLOADED" if uploaded else "DRAFT")
        return self.update_configuration(target["id"], {
            "status": status, "uploaded_files": uploaded, "validation": {}, "questions": [],
            "cloned_from_configuration": cid,
        })

    def save_template(self, payload: Dict[str, Any], template_id: str = "") -> Dict[str, Any]:
        with _LOCK:
            tid = template_id or uuid.uuid4().hex[:10]
            path = self.template_root / f"{tid}.json"
            old = self._read(path, {})
            version = int(old.get("version", 0)) + 1 if old else 1
            now = datetime.now(timezone.utc).isoformat()
            record = {
                "id": tid,
                **payload,
                "version": version,
                "lifecycle": "DRAFT",
                "published_at": old.get("published_at", ""),
                "archived_at": "",
                "updated_at": now,
                "created_at": old.get("created_at", now),
                "builtin": bool(old.get("builtin", False)),
                "source_template_id": old.get("source_template_id", ""),
            }
            self._write(path, record)
            self._write(self.template_history_root / tid / f"v{version}.json", record)
            return record

    def set_template_lifecycle(self, tid: str, lifecycle: str) -> Dict[str, Any]:
        with _LOCK:
            record = self.get_template(tid)
            state = str(lifecycle or "").upper()
            if state not in {"DRAFT", "PUBLISHED", "ARCHIVED"}:
                raise ValueError("Unsupported template lifecycle")
            now = datetime.now(timezone.utc).isoformat()
            record["lifecycle"] = state
            record["updated_at"] = now
            if state == "PUBLISHED":
                record["published_at"] = now
                record["archived_at"] = ""
            elif state == "ARCHIVED":
                record["archived_at"] = now
            self._write(self.template_root / f"{tid}.json", record)
            self._write(self.template_history_root / tid / f"v{record.get('version', 1)}.json", record)
            return record

    def clone_template(self, tid: str, name: str = "") -> Dict[str, Any]:
        source = self.get_template(tid)
        payload = {key: source.get(key) for key in ("name", "description", "direction", "transaction_code", "flow_type", "nodes", "edges", "variables", "default_values", "source_configuration_id", "tags")}
        payload["name"] = name or f"{source.get('name') or 'Template'} Copy"
        cloned = self.save_template(payload)
        cloned["source_template_id"] = tid
        self._write(self.template_root / f"{cloned['id']}.json", cloned)
        self._write(self.template_history_root / cloned["id"] / "v1.json", cloned)
        return cloned

    def list_template_versions(self, tid: str) -> List[Dict[str, Any]]:
        folder = self.template_history_root / tid
        values: List[Dict[str, Any]] = []
        if not folder.exists():
            return values
        for path in sorted(folder.glob("v*.json"), key=lambda p: int(p.stem[1:]) if p.stem[1:].isdigit() else 0, reverse=True):
            item = self._read(path, {})
            if item:
                values.append(item)
        return values

    def get_template(self, tid: str) -> Dict[str, Any]:
        value = self._read(self.template_root / f"{tid}.json", {})
        if not value:
            raise KeyError(tid)
        return value

    def list_templates(self) -> List[Dict[str, Any]]:
        values = []
        for path in sorted(self.template_root.glob("*.json")):
            item = self._read(path, {})
            if item:
                values.append(item)
        return values

    def delete_template(self, tid: str) -> bool:
        path = self.template_root / f"{tid}.json"
        if not path.exists():
            return False
        path.unlink()
        return True

    def save_execution(self, execution_id: str, payload: Dict[str, Any]) -> None:
        self._write(self.execution_root / f"{execution_id}.json", payload)

    def get_execution(self, execution_id: str) -> Dict[str, Any]:
        return self._read(self.execution_root / f"{execution_id}.json", {})


    def list_executions(self, configuration_id: str = "") -> List[Dict[str, Any]]:
        values: List[Dict[str, Any]] = []
        for path in sorted(self.execution_root.glob("*.json"), reverse=True):
            item = self._read(path, {})
            if not item:
                continue
            if configuration_id and str(item.get("configuration_id") or "") != str(configuration_id):
                continue
            values.append(item)
        return values[:50]
