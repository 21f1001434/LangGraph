from __future__ import annotations

"""Governed skill selection, context budgeting, and pre-run vetting.

The LLM is deliberately *not* allowed to load arbitrary Python or mutate HIP
requests. Skills are declarative JSON manifests. A deterministic router uses the
skill description as the primary trigger signal, vets the selected manifest and
its expert sources, then gives the model only a bounded, redacted task context.
The selected tool remains a hard-coded application callable.
"""

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence


SKILL_SCHEMA = "hip-agent-skill.v1"
SKILL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
SAFE_ENTRYPOINTS = {
    "governed_parallel_manager_execute",
    "production_preflight",
    "report_insights",
}
SAFE_TOOLS = {"execute_validated_hip_configuration", "none"}
SECRET_KEY_FRAGMENTS = (
    "password", "passwd", "secret", "token", "bearer", "credential", "cookie",
    "authorization", "api_key", "apikey", "client_secret", "private_key",
)
STOPWORDS = {
    "the", "a", "an", "to", "and", "or", "of", "for", "with", "this", "that",
    "when", "use", "asks", "ask", "task", "skill", "through", "all", "is", "be",
    "without", "any", "it", "its", "from", "into", "by", "on", "as", "must",
}


class SkillGovernanceError(RuntimeError):
    """Base error for deterministic skill selection/vetting."""


class SkillSelectionError(SkillGovernanceError):
    """Raised when no unambiguous description-triggered skill can be selected."""


class SkillVettingError(SkillGovernanceError):
    """Raised when a skill fails structural/provenance validation."""


@dataclass(frozen=True)
class SkillSpec:
    name: str
    description: str
    execution_modes: tuple[str, ...]
    risk: str
    deterministic_entrypoint: str
    allowed_tool: str
    context_fields: tuple[str, ...]
    max_context_chars: int
    expertise_sources: tuple[str, ...]
    invariants: tuple[str, ...]
    source_path: Path


def _project_root() -> Path:
    # .../webapp/backend/app/skill_governance.py -> project root
    return Path(__file__).resolve().parents[3]


def _normalize_words(value: Any) -> List[str]:
    words = re.findall(r"[a-z0-9_]+", str(value or "").lower())
    return [w for w in words if len(w) >= 3 and w not in STOPWORDS]


def _load_manifest(path: Path) -> SkillSpec:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SkillVettingError(f"Invalid skill manifest JSON {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise SkillVettingError(f"Skill manifest must be a JSON object: {path}")
    if raw.get("schemaVersion") != SKILL_SCHEMA:
        raise SkillVettingError(
            f"Unsupported skill schema for {path.name}: {raw.get('schemaVersion')!r}; expected {SKILL_SCHEMA}."
        )
    return SkillSpec(
        name=str(raw.get("name") or "").strip(),
        description=str(raw.get("description") or "").strip(),
        execution_modes=tuple(str(x).strip().upper() for x in (raw.get("executionModes") or [])),
        risk=str(raw.get("risk") or "").strip().lower(),
        deterministic_entrypoint=str(raw.get("deterministicEntrypoint") or "").strip(),
        allowed_tool=str(raw.get("allowedTool") or "").strip(),
        context_fields=tuple(str(x).strip() for x in (raw.get("contextFields") or [])),
        max_context_chars=int(raw.get("maxContextChars") or 0),
        expertise_sources=tuple(str(x).strip() for x in (raw.get("expertiseSources") or [])),
        invariants=tuple(str(x).strip() for x in (raw.get("invariants") or [])),
        source_path=path,
    )


def load_skills(root: Path | None = None) -> List[SkillSpec]:
    project = Path(root) if root is not None else _project_root()
    skill_dir = project / "skills"
    if not skill_dir.is_dir():
        raise SkillVettingError(f"Skill directory is missing: {skill_dir}")
    paths = sorted(skill_dir.glob("*.skill.json"))
    if not paths:
        raise SkillVettingError(f"No skill manifests found in {skill_dir}")
    return [_load_manifest(path) for path in paths]


def _safe_relative_source(project: Path, raw_source: str) -> Path:
    if not raw_source or Path(raw_source).is_absolute():
        raise SkillVettingError(f"Skill expertise source must be a relative project path: {raw_source!r}")
    candidate = (project / raw_source).resolve()
    try:
        candidate.relative_to(project.resolve())
    except ValueError as exc:
        raise SkillVettingError(f"Skill expertise source escapes the project root: {raw_source}") from exc
    return candidate


def vet_skill(skill: SkillSpec, root: Path | None = None) -> Dict[str, Any]:
    project = Path(root) if root is not None else _project_root()
    errors: List[str] = []
    if not SKILL_NAME_RE.fullmatch(skill.name):
        errors.append("name must match ^[a-z][a-z0-9_]{2,63}$")
    if not skill.description.lower().startswith("use when "):
        errors.append("description must start with 'Use when ' so the description is an explicit trigger")
    if len(skill.description) < 80:
        errors.append("description is too short to be a reliable routing trigger")
    if not skill.execution_modes:
        errors.append("executionModes must not be empty")
    if skill.deterministic_entrypoint not in SAFE_ENTRYPOINTS:
        errors.append(f"deterministicEntrypoint is not allowlisted: {skill.deterministic_entrypoint!r}")
    if skill.allowed_tool not in SAFE_TOOLS:
        errors.append(f"allowedTool is not allowlisted: {skill.allowed_tool!r}")
    if not 1000 <= skill.max_context_chars <= 12000:
        errors.append("maxContextChars must be between 1000 and 12000")
    if not skill.context_fields:
        errors.append("contextFields must not be empty")
    if not skill.expertise_sources:
        errors.append("expertiseSources must not be empty")
    if not skill.invariants:
        errors.append("invariants must not be empty")

    source_hashes: Dict[str, str] = {}
    for raw_source in skill.expertise_sources:
        try:
            source = _safe_relative_source(project, raw_source)
        except SkillVettingError as exc:
            errors.append(str(exc))
            continue
        if not source.is_file():
            errors.append(f"expertise source is missing: {raw_source}")
            continue
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        source_hashes[raw_source] = digest

    if errors:
        raise SkillVettingError(f"Skill {skill.name!r} failed vetting: " + " | ".join(errors))

    provenance_material = json.dumps(
        {
            "name": skill.name,
            "description": skill.description,
            "entrypoint": skill.deterministic_entrypoint,
            "tool": skill.allowed_tool,
            "expertise": source_hashes,
            "invariants": list(skill.invariants),
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return {
        "status": "PASS",
        "name": skill.name,
        "manifest": str(skill.source_path.relative_to(project)),
        "description": skill.description,
        "deterministicEntrypoint": skill.deterministic_entrypoint,
        "allowedTool": skill.allowed_tool,
        "risk": skill.risk,
        "expertiseSources": list(skill.expertise_sources),
        "expertiseSourceHashes": source_hashes,
        "expertiseDigest": hashlib.sha256(provenance_material.encode("utf-8")).hexdigest(),
        "invariants": list(skill.invariants),
    }


def vet_all_skills(root: Path | None = None) -> Dict[str, Any]:
    project = Path(root) if root is not None else _project_root()
    skills = load_skills(project)
    vetted = [vet_skill(skill, project) for skill in skills]
    return {"status": "PASS", "count": len(vetted), "skills": vetted}


def _task_text(task: Mapping[str, Any]) -> str:
    preferred = [
        task.get("intentDescription"), task.get("executionMode"), task.get("label"),
        task.get("customer"), task.get("jobId"), task.get("rules"),
    ]
    return " ".join(json.dumps(x, sort_keys=True, default=str) if isinstance(x, (dict, list)) else str(x or "") for x in preferred)


def _description_score(description: str, task_text: str) -> float:
    desc_words = set(_normalize_words(description))
    task_words = set(_normalize_words(task_text))
    if not desc_words or not task_words:
        return 0.0
    overlap = desc_words & task_words
    # Description remains the routing source. Repeated task noise cannot inflate
    # the score because both sides are sets.
    return round((len(overlap) / max(1, len(desc_words))) * 100.0, 4)


def select_skill(task: Mapping[str, Any], root: Path | None = None) -> tuple[SkillSpec, Dict[str, Any]]:
    project = Path(root) if root is not None else _project_root()
    mode = str(task.get("executionMode") or "").strip().upper()
    text = _task_text(task)
    candidates: List[tuple[float, SkillSpec]] = []
    for skill in load_skills(project):
        if mode and mode not in skill.execution_modes:
            continue
        candidates.append((_description_score(skill.description, text), skill))
    if not candidates:
        raise SkillSelectionError(f"No skill description accepts execution mode {mode or '<missing>'}.")
    candidates.sort(key=lambda item: (-item[0], item[1].name))
    best_score, best = candidates[0]
    if best_score <= 0:
        raise SkillSelectionError(
            f"No skill description matched the task strongly enough for mode {mode or '<missing>'}; refusing to guess."
        )
    if len(candidates) > 1 and candidates[1][0] == best_score:
        raise SkillSelectionError(
            f"Ambiguous skill descriptions: {best.name} and {candidates[1][1].name} both scored {best_score}."
        )
    return best, {
        "selected": best.name,
        "score": best_score,
        "mode": mode,
        "candidateScores": [{"name": skill.name, "score": score} for score, skill in candidates],
        "selectionBasis": "skill_description",
    }


def _is_secret_key(key: Any) -> bool:
    lowered = str(key or "").strip().lower()
    return any(fragment in lowered for fragment in SECRET_KEY_FRAGMENTS)


def _redact(value: Any) -> Any:
    if isinstance(value, Mapping):
        result: Dict[str, Any] = {}
        for key, item in value.items():
            result[str(key)] = "[REDACTED]" if _is_secret_key(key) else _redact(item)
        return result
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, tuple):
        return [_redact(item) for item in value]
    return value


def build_bounded_context(task: Mapping[str, Any], skill: SkillSpec) -> Dict[str, Any]:
    selected = {field: task.get(field) for field in skill.context_fields if field in task}
    selected = _redact(selected)
    raw = json.dumps(selected, sort_keys=True, ensure_ascii=False, default=str)
    input_chars = len(raw)
    omitted_fields = sorted(set(str(k) for k in task.keys()) - set(skill.context_fields))

    if input_chars <= skill.max_context_chars:
        bounded = selected
        output_chars = input_chars
        truncated = False
    else:
        # Keep high-value scalar identifiers/rules first; never blindly slice JSON.
        bounded = {}
        for field in skill.context_fields:
            if field not in selected:
                continue
            candidate = dict(bounded)
            candidate[field] = selected[field]
            encoded = json.dumps(candidate, sort_keys=True, ensure_ascii=False, default=str)
            if len(encoded) <= skill.max_context_chars:
                bounded = candidate
            else:
                omitted_fields.append(field)
        output_chars = len(json.dumps(bounded, sort_keys=True, ensure_ascii=False, default=str))
        truncated = True

    context_digest = hashlib.sha256(
        json.dumps(bounded, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    ).hexdigest()
    return {
        "task": bounded,
        "budget": {
            "maxChars": skill.max_context_chars,
            "inputChars": input_chars,
            "outputChars": output_chars,
            "truncated": truncated,
            "omittedFields": sorted(set(omitted_fields)),
            "contextDigest": context_digest,
        },
    }


def select_vet_and_pack(task: Mapping[str, Any], root: Path | None = None) -> Dict[str, Any]:
    project = Path(root) if root is not None else _project_root()
    skill, selection = select_skill(task, project)
    vetting = vet_skill(skill, project)
    context = build_bounded_context(task, skill)
    return {
        "skill": skill,
        "selection": selection,
        "vetting": vetting,
        "context": context,
    }
