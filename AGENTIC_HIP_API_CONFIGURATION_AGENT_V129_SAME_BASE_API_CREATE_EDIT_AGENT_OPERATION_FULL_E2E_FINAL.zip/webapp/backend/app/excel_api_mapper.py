from __future__ import annotations

"""Governed Excel/CSV -> HIP API request mapping service.

The mapper lets deterministic/LLM agents map workbook evidence to EXISTING API
attributes and prepare changed VALUES.  API attributes themselves are immutable:
agents cannot add/remove/rename fields, alter nesting/cardinality, method, URL or
protected headers.  A HUMAN USER must explicitly approve/stage the agent-prepared
values before they receive persistence/LIVE authority.  Every proposed target path
must already be present in the selected generated HIP request.
"""

import csv
import io
import json
import math
import re
import zipfile
from copy import deepcopy
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple
from xml.etree import ElementTree as ET

from canonical_payload_contract import validate_override_structure
from input_builder_aia_adapter import diagnostics as aia_diagnostics


MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_ROWS = 500
MAX_COLUMNS = 160
MAX_LLM_APIS = 10
MAX_LLM_HEADERS = 80

_BLANK_TEXT = {"", "-", "--", "n/a", "na", "none", "null", "tbd", "not available", "data not available"}

# Values in these columns are excellent record labels but are usually not API
# request values by themselves.
_RECORD_HEADER_HINTS = (
    "hip account", "account name", "application tracking", "lens tp name",
    "transport profile name", "transport name", "customer", "partner",
)

# Source-header aliases observed in the supplied connectivity workbook and common
# API/configuration manuals.  They only influence ranking; the target still must
# exist in the canonical generated request.
_HEADER_ALIASES: Dict[str, Tuple[str, ...]] = {
    "dev transport profile name": ("transportprofilename",),
    "transport profile name": ("transportprofilename",),
    "transport name": ("transportprofilename",),
    "transport type": ("interfacetype", "transportprofileinterfacetype"),
    "delivery type": ("interfacetype", "transportprofileinterfacetype"),
    "actual delivery type": ("interfacetype", "transportprofileinterfacetype"),
    "source interface type": ("interfacetype", "transportprofileinterfacetype"),
    "target interface type": ("interfacetype", "transportprofileinterfacetype"),
    "document type name": ("documenttypename", "name"),
    "document type version": ("documenttypeversion", "version"),
    "doc type version": ("documenttypeversion", "version"),
    "dell biz doc": ("documenttypename", "name", "transactiontype"),
    "biz doc type": ("documenttypename", "name", "transactiontype"),
    "biz flow name": ("flowname",),
    "hip name only": ("flowname",),
    "target system": ("systemname", "name"),
    "source system": ("systemname", "name"),
    "hip account names": ("accountname", "existingaccountname"),
    "hip account name": ("accountname", "existingaccountname"),
    "hip account": ("accountname", "existingaccountname"),
    "existing account name": ("accountname", "existingaccountname"),
    "interface environment": ("interfaceenvironment", "sourceenvironment", "targetenvironment"),
    "environment": ("hipenvironment", "environment", "sourceenvironment", "targetenvironment", "interfaceenvironment"),
    "partner identifier": ("partneridentifiervalue", "partneridentifier"),
    "duns": ("partneridentifiervalue",),
    "sftp server": ("servername", "partnerurl", "hipurl", "as2url"),
    "server": ("servername",),
    "server name": ("servername",),
    "server path": ("serverpath", "subscriptionfolder"),
    "subscription folder": ("subscriptionfolder",),
    "post transfer action": ("posttransferaction",),
    "post file transfer action": ("postfiletransferactionnas", "posttransferaction"),
    "directory": ("subscriptionfolder", "serverpath"),
    "folder": ("subscriptionfolder", "serverpath"),
    "exchange name": ("exchangename",),
    "protocol": ("protocol",),
    "request method": ("requestmethod",),
    "ssl certificate": ("sslcertificate",),
    "encryption certificate": ("encryptioncertificate",),
    "signing algorithm": ("signingalgorithm",),
    "encryption algorithm": ("encryptionalgorithm",),
}

# V127 document identity hardening.  Document Type name and version are separate
# business values.  They may only cross the Excel/API boundary through exact,
# role-aware evidence.  In particular, a version cell must never become a name
# and an inherited/default ``1`` must never masquerade as workbook evidence.
_DOCUMENT_NAME_HEADERS = (
    "Document Type Name", "Document Type", "Source Document Type Name",
    "Target Document Type Name", "Dell Biz Doc",
)
_DOCUMENT_VERSION_HEADERS = (
    "Document Type Version", "Doc Type Version", "Source Document Type Version",
    "Target Document Type Version",
)
_DOCUMENT_SOURCE_API_KEYS = {"doctype_source", "source_tp", "migrate_doctype_source", "rule"}
_DOCUMENT_TARGET_API_KEYS = {"doctype_target", "target_tp", "migrate_doctype_target"}
_DOCUMENT_EVIDENCE_API_KEYS = _DOCUMENT_SOURCE_API_KEYS | _DOCUMENT_TARGET_API_KEYS

def _document_header_kind(header: str) -> str:
    norm = _norm_text(header)
    if norm in {_norm_text(x) for x in _DOCUMENT_VERSION_HEADERS}:
        return "version"
    if norm in {_norm_text(x) for x in _DOCUMENT_NAME_HEADERS}:
        return "name"
    return ""

def _document_header_role(header: str) -> str:
    tokens = set(_tokens(header))
    if "source" in tokens:
        return "source"
    if "target" in tokens:
        return "target"
    return ""

def _document_api_role(api_key: str) -> str:
    if api_key in _DOCUMENT_SOURCE_API_KEYS:
        return "source"
    if api_key in _DOCUMENT_TARGET_API_KEYS:
        return "target"
    return ""

def _document_target_kind(api_key: str, path: str) -> str:
    leaf = _compact(_path_leaf(path))
    # Standalone Document Type create uses generic name/version leaves. Rule has
    # its own name/version too, so only its documentType* leaves are doc identity.
    if api_key in {"doctype_source", "doctype_target"}:
        if leaf == "name":
            return "name"
        if leaf == "version":
            return "version"
    if leaf == "documenttypename":
        return "name"
    if leaf == "documenttypeversion":
        return "version"
    return ""

def _document_mapping_allowed(header: str, api_key: str, path: str) -> bool:
    kind = _document_header_kind(header)
    if not kind:
        return True
    target_kind = _document_target_kind(api_key, path)
    if target_kind != kind:
        return False
    header_role = _document_header_role(header)
    api_role = _document_api_role(api_key)
    if header_role and api_role and header_role != api_role:
        return False
    return True

# For a row to be called GOOD_TO_TRIGGER, at least one object-identity field must
# be supplied by that row (rather than silently inherited from the active
# configuration), and all listed critical paths must be nonblank in the proposed
# request.  This prevents a different account row from looking ready solely
# because the active customer already has values.
_CRITICAL_PATHS: Dict[str, Tuple[str, ...]] = {
    "validate_source": ("transportProfileName", "interfaceType"),
    "validate_target": ("transportProfileName", "interfaceType"),
    "validate_flow": ("flowName",),
    "account_source": ("accountName",),
    "account_target": ("accountName",),
    "partner_target": ("name", "partnerIdentifierValue"),
    "system_source": ("systemName",),
    "doctype_source": ("name", "dataFormatType", "transactionType", "version"),
    "doctype_target": ("name", "dataFormatType", "transactionType", "version"),
    "map": ("mapName", "mapIdentifier", "mapIdentifierVersion"),
    "rule": ("name", "documentTypeName", "documentTypeVersion", "version"),
    "source_tp": (
        "systemName", "transportProfileDetails.0.transportProfileName",
        "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
    ),
    "target_tp": (
        "systemName", "transportProfileDetails.0.transportProfileName",
        "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
    ),
    "source_tp_audit": ("transportProfileName",),
    "target_tp_audit": ("transportProfileName",),
    "flow_create": ("flowName", "flowVersion"),
    "flow_deploy": ("flowName", "flowVersion", "environment"),
    "flow_history": ("flowName", "flowVersion", "environment"),
    "migrate_doctype_source": ("sourceEnvironment", "targetEnvironment", "documentTypeName", "documentTypeVersion"),
    "migrate_doctype_target": ("sourceEnvironment", "targetEnvironment", "documentTypeName", "documentTypeVersion"),
    "migrate_map": ("sourceEnvironment", "targetEnvironment", "mapIdentifier", "mapIdentifierVersion"),
    "migrate_rule": ("sourceEnvironment", "targetEnvironment", "ruleName", "ruleVersion"),
    "migrate_source_tp": (
        "sourceEnvironment", "targetEnvironment", "transportProfileName", "transportProfileInterfaceType",
    ),
    "migrate_target_tp": (
        "sourceEnvironment", "targetEnvironment", "transportProfileName", "transportProfileInterfaceType",
    ),
    "migrate_flow": ("sourceEnvironment", "targetEnvironment", "flowName", "flowVersion"),
}

_IDENTITY_SUFFIXES = {
    "accountname", "transportprofilename", "flowname", "systemname", "documenttypename",
    "mapname", "mapidentifier", "rulename", "partneridentifiervalue", "name",
}

# APIs that are downstream/audit actions receive a small AUTO-selection penalty
# unless workbook headers explicitly mention them. This keeps TP spreadsheets
# from selecting Flow History merely because flowName exists in the active config.
_AUTO_API_PENALTY = {
    "source_tp_audit": 18, "target_tp_audit": 18, "flow_history": 18,
    "flow_deploy": 12, "validate_source": 8, "validate_target": 8, "validate_flow": 8,
}

_TOKEN_EXPANSIONS = {
    "tp": ("transport", "profile"), "rcvr": ("receiver",), "recv": ("receiver",),
    "sndr": ("sender",), "biz": ("business",), "doc": ("document",),
    "acct": ("account",), "env": ("environment",), "intf": ("interface",),
    "src": ("source",), "tgt": ("target",), "aprf": ("profile",),
}


def _blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str):
        return value.strip().casefold() in _BLANK_TEXT
    return False


def _display(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _norm_text(value: Any) -> str:
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
    text = text.replace("&", " and ")
    return " ".join(re.findall(r"[a-z0-9]+", text.casefold()))


def _compact(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", _norm_text(value))


def _tokens(value: Any) -> List[str]:
    out: List[str] = []
    for token in _norm_text(value).split():
        out.extend(_TOKEN_EXPANSIONS.get(token, (token,)))
    return out


def _path_leaf(path: str) -> str:
    parts = [part for part in str(path).split(".") if not part.isdigit()]
    return parts[-1] if parts else str(path)


def _flatten_leaves(value: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    if isinstance(value, dict):
        out: List[Tuple[str, Any]] = []
        for key, child in value.items():
            out.extend(_flatten_leaves(child, f"{prefix}.{key}" if prefix else str(key)))
        return out
    if isinstance(value, list):
        out = []
        for index, child in enumerate(value):
            out.extend(_flatten_leaves(child, f"{prefix}.{index}" if prefix else str(index)))
        return out
    return [(prefix, value)] if prefix else []


def _read_path(root: Any, path: str) -> Any:
    node = root
    for part in str(path).split("."):
        if isinstance(node, list):
            try:
                node = node[int(part)]
            except Exception:
                return None
        elif isinstance(node, dict):
            node = node.get(part)
        else:
            return None
    return node


def _write_path(root: Any, path: str, value: Any) -> None:
    node = root
    parts = str(path).split(".")
    for index, part in enumerate(parts):
        last = index == len(parts) - 1
        if isinstance(node, list):
            pos = int(part)
            if last:
                node[pos] = value
            else:
                node = node[pos]
        else:
            if last:
                node[part] = value
            else:
                node = node[part]


def _interface_family(value: Any) -> str:
    compact = _compact(value)
    if "sftp" in compact:
        return "sftp"
    if compact in {"as2", "httpsas2"} or "httpsas2" in compact:
        return "https_as2"
    if "https" in compact:
        return "https"
    if "rabbitmq" in compact:
        return "rabbitmq"
    if compact == "nas" or compact.startswith("nas"):
        return "nas"
    if compact == "ftp" or compact.startswith("ftp"):
        return "ftp"
    return ""


def _coerce_like(value: Any, generated: Any, target_path: str = "") -> Tuple[Any, str | None]:
    if _blank(value):
        return generated, None
    if isinstance(generated, bool):
        raw = _display(value).casefold()
        if raw in {"true", "1", "yes", "y"}:
            return True, None
        if raw in {"false", "0", "no", "n"}:
            return False, None
        return generated, f"Could not coerce {value!r} to boolean"
    if isinstance(generated, int) and not isinstance(generated, bool):
        try:
            return int(float(str(value).replace(",", ""))), None
        except Exception:
            return generated, f"Could not coerce {value!r} to integer"
    if isinstance(generated, float):
        try:
            return float(str(value).replace(",", "")), None
        except Exception:
            return generated, f"Could not coerce {value!r} to number"
    if isinstance(generated, str):
        # Interface names are often abbreviated in team spreadsheets (for
        # example SFTP) while HIP expects the exact Dev-approved value (for
        # example SFTP HAFT). We only canonicalize when the workbook value and
        # the active generated request are demonstrably the same interface
        # family; otherwise the raw workbook value is preserved and contract
        # validation will block an unsafe mismatch.
        if "interfacetype" in _compact(target_path):
            source_family = _interface_family(value)
            generated_family = _interface_family(generated)
            if source_family and source_family == generated_family:
                return generated, None
        if "posttransferaction" in _compact(target_path) and _compact(value) == _compact(generated):
            # Preserve the exact Dev-approved enum spelling/capitalization such
            # as "Move To Archive" when Excel supplies the same semantic value.
            return generated, None
        return _display(value), None
    if generated is None:
        return value, None
    return value, None


def _role_alignment(header: str, api_key: str, path: str) -> float:
    h = set(_tokens(header))
    target = set(_tokens(path))
    score = 0.0
    for role in ("source", "target", "sender", "receiver"):
        if role in h:
            if role in api_key or role in target:
                score += 0.10
            elif (role == "source" and "target" in api_key) or (role == "target" and "source" in api_key):
                score -= 0.16
    return score


def mapping_score(header: str, path: str, api_key: str) -> float:
    if not _document_mapping_allowed(header, api_key, path):
        return 0.0
    h_tokens = _tokens(header)
    p_tokens = _tokens(path)
    if not h_tokens or not p_tokens:
        return 0.0
    hs, ps = set(h_tokens), set(p_tokens)
    overlap = len(hs & ps) / max(1, len(hs | ps))
    h_compact = _compact(header)
    leaf_compact = _compact(_path_leaf(path))
    path_compact = _compact(path)
    seq = SequenceMatcher(None, h_compact, leaf_compact).ratio() if h_compact and leaf_compact else 0.0
    score = 0.48 * overlap + 0.30 * seq
    if h_compact == leaf_compact:
        score += 0.34
    elif leaf_compact and (leaf_compact in h_compact or h_compact in leaf_compact):
        score += 0.18
    # Parameter labels contain spaces while the dotted path may contain the full
    # key, e.g. parameters.Existing Account Name.
    if _compact(_path_leaf(path)) in h_compact and len(leaf_compact) >= 5:
        score += 0.16
    normalized_header = _norm_text(header)
    for alias, targets in _HEADER_ALIASES.items():
        if alias in normalized_header or normalized_header in alias:
            if any(target in path_compact or target == leaf_compact for target in targets):
                score += 0.34
    score += _role_alignment(header, api_key, path)
    return max(0.0, min(1.0, score))


# ---------------- workbook reading (stdlib; no workbook mutation) ----------------

_NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_NS_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def _col_index(cell_ref: str) -> int:
    match = re.match(r"([A-Z]+)", str(cell_ref or "").upper())
    if not match:
        return 0
    value = 0
    for ch in match.group(1):
        value = value * 26 + (ord(ch) - 64)
    return max(0, value - 1)


def _shared_strings(zf: zipfile.ZipFile) -> List[str]:
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    out: List[str] = []
    for si in root.findall(f"{_NS_MAIN}si"):
        text = "".join((node.text or "") for node in si.iter(f"{_NS_MAIN}t"))
        out.append(text)
    return out


def _xlsx_sheet_targets(zf: zipfile.ZipFile) -> List[Tuple[str, str]]:
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    targets = {rel.attrib.get("Id", ""): rel.attrib.get("Target", "") for rel in rels.findall(f"{_NS_PKG_REL}Relationship")}
    out: List[Tuple[str, str]] = []
    sheets = workbook.find(f"{_NS_MAIN}sheets")
    for sheet in list(sheets) if sheets is not None else []:
        name = sheet.attrib.get("name", "Sheet")
        rel_id = sheet.attrib.get(f"{_NS_REL}id", "")
        target = targets.get(rel_id, "")
        if not target:
            continue
        if target.startswith("/"):
            path = target.lstrip("/")
        else:
            path = "xl/" + target.lstrip("/")
        path = re.sub(r"(^|/)\.(/|$)", r"\1", path)
        while "/../" in path:
            left, right = path.split("/../", 1)
            left = left.rsplit("/", 1)[0]
            path = left + "/" + right
        out.append((name, path))
    return out


def _read_xlsx_sheet(zf: zipfile.ZipFile, path: str, shared: Sequence[str]) -> List[List[Any]]:
    root = ET.fromstring(zf.read(path))
    data = root.find(f"{_NS_MAIN}sheetData")
    rows: List[List[Any]] = []
    for row in (list(data) if data is not None else [])[: MAX_ROWS + 40]:
        values: Dict[int, Any] = {}
        max_col = -1
        for cell in list(row):
            if not cell.tag.endswith("}c"):
                continue
            idx = _col_index(cell.attrib.get("r", "A1"))
            if idx >= MAX_COLUMNS:
                continue
            typ = cell.attrib.get("t", "")
            raw = cell.find(f"{_NS_MAIN}v")
            inline = cell.find(f"{_NS_MAIN}is")
            value: Any = ""
            if typ == "inlineStr" and inline is not None:
                value = "".join((node.text or "") for node in inline.iter(f"{_NS_MAIN}t"))
            elif raw is not None and raw.text is not None:
                text = raw.text
                if typ == "s":
                    try:
                        value = shared[int(text)]
                    except Exception:
                        value = text
                elif typ == "b":
                    value = text == "1"
                elif typ in {"str", "e"}:
                    value = text
                else:
                    try:
                        number = float(text)
                        value = int(number) if number.is_integer() else number
                    except Exception:
                        value = text
            values[idx] = value
            max_col = max(max_col, idx)
        if max_col < 0:
            rows.append([])
        else:
            rows.append([values.get(i, "") for i in range(max_col + 1)])
    return rows


def read_workbook(filename: str, data: bytes) -> Dict[str, Any]:
    if len(data) > MAX_FILE_BYTES:
        raise ValueError(f"Workbook is larger than {MAX_FILE_BYTES // (1024*1024)} MB.")
    low = str(filename or "").casefold()
    if low.endswith(".csv"):
        text = data.decode("utf-8-sig", errors="replace")
        rows = [row[:MAX_COLUMNS] for row in csv.reader(io.StringIO(text))][: MAX_ROWS + 40]
        return {"format": "CSV", "sheets": [{"name": "CSV", "rows": rows}]}
    if low.endswith((".xlsx", ".xlsm")):
        try:
            with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
                shared = _shared_strings(zf)
                sheets = []
                for name, path in _xlsx_sheet_targets(zf):
                    if path not in zf.namelist():
                        continue
                    sheets.append({"name": name, "rows": _read_xlsx_sheet(zf, path, shared)})
                if not sheets:
                    raise ValueError("No readable worksheets were found.")
                return {"format": "XLSX", "sheets": sheets}
        except zipfile.BadZipFile as exc:
            raise ValueError("The uploaded .xlsx/.xlsm file is not a valid Open XML workbook.") from exc
    if low.endswith(".xls"):
        raise ValueError("Legacy .xls is not accepted by the governed mapper. Save the workbook as .xlsx or CSV and upload it again.")
    raise ValueError("Upload an .xlsx, .xlsm, or .csv file.")


def _header_score(row: Sequence[Any]) -> float:
    texts = [_display(v) for v in row if not _blank(v)]
    if len(texts) < 2:
        return -1.0
    textual = sum(1 for v in texts if re.search(r"[A-Za-z]", v))
    unique = len({_norm_text(v) for v in texts if _norm_text(v)})
    hint = sum(1 for v in texts if any(word in _norm_text(v) for word in ("account", "transport", "interface", "document", "system", "flow", "name", "server", "type")))
    return textual * 1.0 + unique * 0.35 + hint * 1.6 - max(0, len(texts) - 80) * 0.1


def detect_header(rows: Sequence[Sequence[Any]]) -> int:
    candidates = [(index, _header_score(row)) for index, row in enumerate(rows[:30])]
    candidates.sort(key=lambda item: (item[1], -item[0]), reverse=True)
    return candidates[0][0] if candidates and candidates[0][1] >= 0 else 0


def _headers_and_records(rows: Sequence[Sequence[Any]], header_index: int) -> Tuple[List[str], List[Dict[str, Any]]]:
    raw_headers = list(rows[header_index]) if 0 <= header_index < len(rows) else []
    headers: List[str] = []
    used: Dict[str, int] = {}
    for index, value in enumerate(raw_headers[:MAX_COLUMNS]):
        base = _display(value) or f"Column {index + 1}"
        count = used.get(base, 0) + 1
        used[base] = count
        headers.append(base if count == 1 else f"{base} ({count})")
    records: List[Dict[str, Any]] = []
    for excel_row, row in enumerate(rows[header_index + 1 : header_index + 1 + MAX_ROWS], start=header_index + 2):
        values = list(row) + [""] * max(0, len(headers) - len(row))
        record = {headers[i]: values[i] for i in range(len(headers))}
        if not any(not _blank(v) for v in record.values()):
            continue
        records.append({"excelRow": excel_row, "values": record})
    return headers, records


# ---------------- agent advisory layer ----------------

def _aia_agents(headers: List[str], sample_rows: List[Dict[str, Any]], api_specs: List[Dict[str, Any]], enabled: bool) -> Dict[str, Any]:
    meta = {"enabled": bool(enabled), "provider": "Dell AIA", "used": False, "agents": [], "diagnostics": aia_diagnostics()}
    if not enabled:
        meta["note"] = "Dell AIA analysis disabled by the user; deterministic mapper used."
        return meta
    try:
        from run_agent import AIAJudge
        judge = AIAJudge({}, enabled=True)
        if not judge.available():
            meta["note"] = judge.auth_status()
            return meta
        safe_headers = headers[:MAX_LLM_HEADERS]
        safe_samples = []
        for row in sample_rows[:5]:
            safe_samples.append({k: ("<PRESENT>" if re.search(r"password|secret|token|certificate", k, re.I) and not _blank(v) else _display(v)[:160]) for k, v in row.items() if k in safe_headers})
        candidate_contracts = [
            {"apiKey": spec["apiKey"], "label": spec["label"], "paths": spec["paths"][:90]}
            for spec in api_specs[:MAX_LLM_APIS]
        ]
        schema_agent = judge.complete_json(
            system=(
                "You are Excel Schema Analyst for Dell HIP. Deterministic workbook parsing is authoritative. "
                "Identify semantic roles of column headers only. Never invent cell values, credentials, IDs, paths, "
                "certificates, API attributes, or account names. Return JSON only."
            ),
            user=(
                "Headers:\n" + json.dumps(safe_headers, ensure_ascii=False) +
                "\nSample rows (sensitive values are masked):\n" + json.dumps(safe_samples, ensure_ascii=False)[:10000] +
                "\nReturn {columnRoles:[{header,role,confidence,reason}], accountColumns:[header], notes:[string]}."
            ),
            temperature=0.0,
        )
        meta["agents"].append({"name": "Excel Schema Analyst", "model": judge.model, "output": schema_agent})

        mapping_agent = judge.complete_json(
            system=(
                "You are HIP API Contract Mapping Agent. You may map an Excel column only to one of the exact targetPaths "
                "provided for that exact apiKey. Never create, rename, remove, or infer API fields. Never invent a value. "
                "Prefer no mapping over a weak mapping. Return JSON only."
            ),
            user=(
                "Headers:\n" + json.dumps(safe_headers, ensure_ascii=False) +
                "\nCandidate canonical API request leaves:\n" + json.dumps(candidate_contracts, ensure_ascii=False)[:18000] +
                "\nReturn {mappings:[{header,apiKey,targetPath,confidence,reason}], apiRanking:[{apiKey,confidence,reason}], notes:[string]}. "
                "confidence must be 0..1. Use only exact header/apiKey/targetPath values from the input."
            ),
            temperature=0.0,
        )
        meta["agents"].append({"name": "API Contract Mapping Agent", "model": judge.model, "output": mapping_agent})
        meta["used"] = True
        meta["schema"] = schema_agent
        meta["mapping"] = mapping_agent
        return meta
    except Exception as exc:
        meta["note"] = f"Dell AIA mapping agents unavailable: {type(exc).__name__}: {exc}"
        return meta


def _validated_llm_hints(agent_meta: Mapping[str, Any], headers: Sequence[str], specs: Mapping[str, Dict[str, Any]]) -> Dict[Tuple[str, str], Dict[str, Any]]:
    out: Dict[Tuple[str, str], Dict[str, Any]] = {}
    mapping = agent_meta.get("mapping") if isinstance(agent_meta, Mapping) else {}
    rows = mapping.get("mappings") if isinstance(mapping, Mapping) else []
    header_lookup = {_norm_text(h): h for h in headers}
    for item in rows if isinstance(rows, list) else []:
        if not isinstance(item, dict):
            continue
        header = header_lookup.get(_norm_text(item.get("header")))
        api_key = str(item.get("apiKey") or "")
        path = str(item.get("targetPath") or "")
        try:
            confidence = float(item.get("confidence") or 0)
        except Exception:
            confidence = 0.0
        if not header or api_key not in specs or path not in specs[api_key]["paths"] or confidence < 0.78:
            continue
        out[(api_key, header)] = {"path": path, "confidence": min(1.0, confidence), "method": "Dell AIA", "reason": str(item.get("reason") or "LLM semantic match")[:400]}
    return out


# ---------------- mapping + readiness ----------------

def _request_for_preview(row: Mapping[str, Any]) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
    kind = str(row.get("requestKind") or "payload")
    generated = row.get("generatedParams") if kind == "params" else row.get("generatedPayload")
    effective = row.get("params") if kind == "params" else row.get("payload")
    return kind, deepcopy(generated if isinstance(generated, dict) else {}), deepcopy(effective if isinstance(effective, dict) else {})


def build_api_specs(preview_items: Sequence[Mapping[str, Any]], selected_api: str = "AUTO") -> List[Dict[str, Any]]:
    specs: List[Dict[str, Any]] = []
    selected = str(selected_api or "AUTO")
    for row in preview_items:
        key = str(row.get("stepKey") or "")
        if not key or (selected != "AUTO" and key != selected):
            continue
        if row.get("applicable") is False:
            continue
        kind, generated, effective = _request_for_preview(row)
        paths = [path for path, _ in _flatten_leaves(effective)]
        specs.append({
            "apiKey": key,
            "label": str(row.get("api") or row.get("label") or key),
            "group": str(row.get("group") or "API"),
            "requestKind": kind,
            "generated": generated,
            "effective": effective,
            "paths": paths,
            "contractStatus": str(row.get("contractStatus") or "UNKNOWN"),
            "applicable": row.get("applicable") is not False,
        })
    if selected != "AUTO" and not specs:
        raise ValueError(f"API {selected!r} is not available/applicable for the active configuration.")
    return specs


def _sheet_affinity(headers: Sequence[str], specs: Sequence[Mapping[str, Any]]) -> float:
    if not headers or not specs:
        return 0.0
    score = 0.0
    for header in headers:
        best = 0.0
        for spec in specs:
            for path in spec.get("paths") or []:
                best = max(best, mapping_score(header, str(path), str(spec.get("apiKey") or "")))
        if best >= 0.58:
            score += best
    return score


def choose_sheet(workbook: Dict[str, Any], specs: Sequence[Mapping[str, Any]], requested_sheet: str = "", requested_header_row: int = 0) -> Tuple[Dict[str, Any], int, List[Dict[str, Any]]]:
    candidates: List[Dict[str, Any]] = []
    requested = str(requested_sheet or "").strip()
    for sheet in workbook.get("sheets") or []:
        rows = sheet.get("rows") or []
        if requested and str(sheet.get("name")) != requested:
            continue
        header_index = max(0, int(requested_header_row) - 1) if requested_header_row else detect_header(rows)
        headers, records = _headers_and_records(rows, header_index)
        score = _header_score(rows[header_index] if header_index < len(rows) else []) + _sheet_affinity(headers, specs) * 2.5 + min(len(records), 20) * 0.05
        candidates.append({"sheet": sheet, "headerIndex": header_index, "headers": headers, "records": records, "score": score})
    if not candidates:
        raise ValueError(f"Worksheet {requested!r} was not found." if requested else "No readable worksheet has data.")
    candidates.sort(key=lambda item: item["score"], reverse=True)
    picked = candidates[0]
    meta = [{"name": str(item["sheet"].get("name") or "Sheet"), "headerRow": int(item["headerIndex"]) + 1, "columnCount": len(item["headers"]), "dataRowCount": len(item["records"]), "affinityScore": round(float(item["score"]), 3)} for item in candidates]
    return picked, int(picked["headerIndex"]), meta


def _deterministic_column_map(headers: Sequence[str], spec: Mapping[str, Any], llm_hints: Mapping[Tuple[str, str], Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
    api_key = str(spec.get("apiKey") or "")
    paths = [str(p) for p in spec.get("paths") or []]
    proposals: List[Tuple[float, str, str, str, str]] = []
    for header in headers:
        ranked = sorted(((mapping_score(header, path, api_key), path) for path in paths if _document_mapping_allowed(header, api_key, path)), reverse=True)
        if ranked and ranked[0][0] >= 0.56:
            proposals.append((ranked[0][0], header, ranked[0][1], "Deterministic", "Header/contract semantic match"))
        hint = llm_hints.get((api_key, header))
        if hint:
            hinted_path = str(hint.get("path") or "")
            if _document_mapping_allowed(header, api_key, hinted_path):
                proposals.append((float(hint.get("confidence") or 0), header, hinted_path, str(hint.get("method") or "Dell AIA"), str(hint.get("reason") or "LLM semantic match")))
    # One Excel column -> one API leaf and one leaf -> one Excel column. Highest
    # confidence wins, which also makes conflicts deterministic and auditable.
    proposals.sort(key=lambda item: item[0], reverse=True)
    used_headers: set[str] = set()
    used_paths: set[str] = set()
    out: Dict[str, Dict[str, Any]] = {}
    for confidence, header, path, method, reason in proposals:
        if header in used_headers or path in used_paths or not path:
            continue
        if confidence < 0.56:
            continue
        used_headers.add(header)
        used_paths.add(path)
        out[header] = {"path": path, "confidence": round(confidence, 3), "method": method, "reason": reason}
    return out


_EXACT_HIP_ACCOUNT_HEADERS = ("Hip Account names", "Hip Account name", "HIP Account", "Existing Account Name")
_EXPLICIT_TP_NAME_HEADERS = (
    "DEV-Transport Profile Name", "DEV Transport Profile Name", "Source Transport Profile Name",
    "Target Transport Profile Name", "Transport Profile Name", "TP Name",
)


def _exact_header_value(values: Mapping[str, Any], *headers: str) -> Tuple[str, Any]:
    lookup = {_norm_text(header): header for header in values}
    for wanted in headers:
        actual = lookup.get(_norm_text(wanted))
        if actual is not None and not _blank(values.get(actual)):
            return actual, values.get(actual)
    return "", ""


def _record_evidence(values: Mapping[str, Any], excel_row: int) -> Dict[str, str]:
    account_header, account_value = _exact_header_value(values, *_EXACT_HIP_ACCOUNT_HEADERS)
    app_header, app_value = _exact_header_value(values, "Application Tracking", "Application Tracking ID")
    lens_header, lens_value = _exact_header_value(values, "LENS TP Name")
    customer_header, customer_value = _exact_header_value(values, "Customer", "Customer Name", "Partner Name")
    tp_header, tp_value = _exact_header_value(values, *_EXPLICIT_TP_NAME_HEADERS)
    account = _display(account_value) if account_header else ""
    application = _display(app_value) if app_header else ""
    lens = _display(lens_value) if lens_header else ""
    customer = _display(customer_value) if customer_header else lens
    tp_name = _display(tp_value) if tp_header else ""
    label_parts = [x for x in (account, application, customer, tp_name) if x]
    return {
        "hipAccount": account,
        "applicationTracking": application,
        "lensTpName": lens,
        "customerName": customer,
        "explicitTpName": tp_name,
        "recordLabel": " · ".join(dict.fromkeys(label_parts)) if label_parts else f"Workbook row {excel_row}",
    }


def _record_label(values: Mapping[str, Any], excel_row: int) -> Tuple[str, str]:
    evidence = _record_evidence(values, excel_row)
    # `account` is intentionally exact-header-only. Generic columns named
    # `Account` are not identity evidence because V6 produced false values such
    # as Yes/Catalogues from those columns.
    account = evidence["hipAccount"] or f"Row {excel_row}"
    return account, evidence["recordLabel"]


def _identity_mapped(api_key: str, mapped_paths: Sequence[str], critical_paths: Sequence[str]) -> bool:
    mapped = set(mapped_paths)
    if api_key in {"source_tp", "target_tp"}:
        # V125/V7: Source/Target TP identity must come from an explicit TP-name
        # Excel column. A mapped system/account/interface is useful evidence but
        # cannot make an inherited Transport Profile identity executable.
        return "transportProfileDetails.0.transportProfileName" in mapped
    if api_key in {"validate_source", "validate_target", "source_tp_audit", "target_tp_audit"}:
        return "transportProfileName" in mapped
    for path in critical_paths:
        if path in mapped and _compact(_path_leaf(path)) in _IDENTITY_SUFFIXES:
            return True
    return any(path in mapped and any(suffix in _compact(path) for suffix in _IDENTITY_SUFFIXES) for path in critical_paths)


def _add_mapping(mappings: List[Dict[str, Any]], mapped_paths: List[str], *, header: str, source: Any, path: str, previous: Any, value: Any, method: str, reason: str, confidence: float = 1.0) -> None:
    existing = next((m for m in mappings if str(m.get("targetPath")) == path), None)
    if existing:
        existing.update({"sourceColumn": header, "sourceValue": _display(source), "previousValue": previous, "mappedValue": value, "confidence": confidence, "method": method, "reason": reason, "valueNormalized": _display(source) != _display(value)})
    else:
        mappings.append({"sourceColumn": header, "sourceValue": _display(source), "targetPath": path, "previousValue": previous, "mappedValue": value, "confidence": confidence, "method": method, "reason": reason, "valueNormalized": _display(source) != _display(value)})
    if path not in mapped_paths:
        mapped_paths.append(path)


def _remove_mapping_for_path(mappings: List[Dict[str, Any]], mapped_paths: List[str], path: str) -> None:
    mappings[:] = [m for m in mappings if str(m.get("targetPath") or "") != path]
    while path in mapped_paths:
        mapped_paths.remove(path)

def _document_evidence_headers(api_key: str, values: Mapping[str, Any]) -> Tuple[Tuple[str, Any], Tuple[str, Any]]:
    role = _document_api_role(api_key)
    if role == "source":
        name_candidates = ("Source Document Type Name", "Document Type Name", "Document Type", "Dell Biz Doc")
        version_candidates = ("Source Document Type Version", "Document Type Version", "Doc Type Version")
    elif role == "target":
        name_candidates = ("Target Document Type Name", "Document Type Name", "Document Type", "Dell Biz Doc")
        version_candidates = ("Target Document Type Version", "Document Type Version", "Doc Type Version")
    else:
        name_candidates = ("Document Type Name", "Document Type", "Dell Biz Doc")
        version_candidates = ("Document Type Version", "Doc Type Version")
    return _exact_header_value(values, *name_candidates), _exact_header_value(values, *version_candidates)

def _looks_like_version_only(value: Any) -> bool:
    text = _display(value).strip()
    return bool(text and re.fullmatch(r"[vV]?\d+(?:\.\d+)*", text))

def _document_evidence_postprocess(record: Mapping[str, Any], spec: Mapping[str, Any], proposed: Dict[str, Any], mappings: List[Dict[str, Any]], mapped_paths: List[str], warnings: List[str]) -> Dict[str, Any]:
    """Map Document Type name/version from Excel without inherited/fabricated defaults.

    V127 policy:
    * name and version are distinct values and can never map to each other's path;
    * explicit role-specific columns win over generic columns;
    * NAME(version) is the only supported implicit version extraction;
    * when version evidence is absent, an inherited active-config value (commonly
      ``1``/``1.0``) is blanked in the *proposed mapper request* and becomes a
      visible NEEDS_INPUT blocker rather than being presented as Excel evidence.
    """
    api_key = str(spec.get("apiKey") or "")
    if api_key not in _DOCUMENT_EVIDENCE_API_KEYS:
        return {}
    paths = [str(path) for path in (spec.get("paths") or [])]
    name_paths = [path for path in paths if _document_target_kind(api_key, path) == "name"]
    version_paths = [path for path in paths if _document_target_kind(api_key, path) == "version"]
    if not name_paths and not version_paths:
        return {}

    values = record.get("values") or {}
    (name_header, name_raw), (version_header, version_raw) = _document_evidence_headers(api_key, values)
    parsed_name = _display(name_raw).strip() if name_header else ""
    parsed_version = ""
    if parsed_name:
        match = re.match(r"^(.*?)\s*\(\s*([0-9]+(?:\.[0-9]+)*)\s*\)\s*$", parsed_name)
        if match:
            parsed_name = match.group(1).strip()
            parsed_version = match.group(2).strip()

    # A bare numeric value in the Name column is version-shaped evidence, not a
    # valid Document Type name. Never copy it into documentTypeName/name.
    invalid_name_value = bool(parsed_name and _looks_like_version_only(parsed_name))
    if invalid_name_value:
        warnings.append(f"{name_header} contains version-like value {_display(name_raw)!r}; it was not used as Document Type Name.")
        parsed_name = ""

    explicit_version = _display(version_raw).strip() if version_header and not _blank(version_raw) else ""
    final_version = explicit_version or parsed_version
    evidence = {
        "nameSourceColumn": name_header,
        "nameSourceValue": _display(name_raw) if name_header else "",
        "versionSourceColumn": version_header or (name_header if parsed_version else ""),
        "versionSourceValue": explicit_version or parsed_version,
        "versionOrigin": "explicit-column" if explicit_version else ("parsed-from-name" if parsed_version else "missing"),
        "inheritedVersionSuppressed": False,
        "inheritedNameSuppressed": False,
    }

    # Remove any generic/LLM mapping for these paths. Exact evidence below is the
    # sole authority for Document Type identity in mapper mode.
    for path in name_paths + version_paths:
        _remove_mapping_for_path(mappings, mapped_paths, path)

    if parsed_name:
        for path in name_paths:
            before = _read_path(proposed, path)
            value, error = _coerce_like(parsed_name, before, path)
            if error:
                warnings.append(f"{name_header} -> {path}: {error}")
                continue
            _write_path(proposed, path, value)
            _add_mapping(mappings, mapped_paths, header=name_header, source=name_raw, path=path, previous=before, value=value, confidence=1.0, method="V127 exact Document Type name", reason="Document Type Name is mapped only from an exact name column; version values are never accepted as names.")
    else:
        # The active configuration must not silently supply another customer's or
        # a baseline Document Type identity when this row is being evaluated.
        for path in name_paths:
            if not _blank(_read_path(proposed, path)):
                evidence["inheritedNameSuppressed"] = True
            _write_path(proposed, path, "")

    if final_version:
        source_header = version_header or name_header
        source_raw = version_raw if version_header else name_raw
        for path in version_paths:
            before = _read_path(proposed, path)
            value, error = _coerce_like(final_version, before, path)
            if error:
                warnings.append(f"{source_header} -> {path}: {error}")
                continue
            _write_path(proposed, path, value)
            _add_mapping(mappings, mapped_paths, header=source_header, source=source_raw, path=path, previous=before, value=value, confidence=1.0, method="V127 exact Document Type version" if explicit_version else "V127 parsed NAME(version)", reason="Document Type Version is mapped only from an explicit version column or a strict NAME(version) value.")
    else:
        for path in version_paths:
            inherited = _read_path(proposed, path)
            if not _blank(inherited):
                evidence["inheritedVersionSuppressed"] = True
            _write_path(proposed, path, "")
        if version_paths:
            warnings.append("Document Type Version is not present in this Excel row. No default/inherited version (including 1/1.0) was used; provide the actual version or use NAME(version).")

    return evidence


def _tp_postprocess(record: Mapping[str, Any], spec: Mapping[str, Any], proposed: Dict[str, Any], mappings: List[Dict[str, Any]], mapped_paths: List[str], warnings: List[str]) -> None:
    """Port the V7 U-HAUL TP payload-accuracy rules into the generic V123 mapper."""
    api_key = str(spec.get("apiKey") or "")
    if api_key not in {"source_tp", "target_tp"}:
        return
    values = record.get("values") or {}
    paths = {str(path) for path in (spec.get("paths") or [])}

    # LENS TP Name is reference/customer evidence only; never executable identity.
    lens_norm = _norm_text("LENS TP Name")
    removed = [m for m in list(mappings) if _norm_text(m.get("sourceColumn")) == lens_norm]
    if removed:
        for m in removed:
            mappings.remove(m)
            try:
                mapped_paths.remove(str(m.get("targetPath")))
            except ValueError:
                pass
        warnings.append("LENS TP Name is retained as customer/reference evidence only and was not used as executable Transport Profile identity.")

    tp_path = "transportProfileDetails.0.transportProfileName"
    tp_header, tp_raw = _exact_header_value(values, *_EXPLICIT_TP_NAME_HEADERS)
    if tp_path in paths and tp_header and not _blank(tp_raw):
        before = _read_path(proposed, tp_path)
        value, error = _coerce_like(tp_raw, before, tp_path)
        if not error:
            _write_path(proposed, tp_path, value)
            _add_mapping(mappings, mapped_paths, header=tp_header, source=tp_raw, path=tp_path, previous=before, value=value, method="V7 explicit TP identity", reason="Executable TP identity comes only from DEV/Source/Target/Transport Profile Name Excel columns.")

    # Exact HIP account evidence gets the approved FILE/SFTP account parameter.
    account_header, account_raw = _exact_header_value(values, *_EXACT_HIP_ACCOUNT_HEADERS)
    account_paths = [path for path in paths if _compact(_path_leaf(path)) == "existingaccountname"]
    if account_header and not _blank(account_raw):
        for path in account_paths:
            before = _read_path(proposed, path)
            value, error = _coerce_like(account_raw, before, path)
            if not error:
                _write_path(proposed, path, value)
                _add_mapping(mappings, mapped_paths, header=account_header, source=account_raw, path=path, previous=before, value=value, method="V7 exact HIP account mapping", reason="HIP Account extraction is exact-header-only; broad Account columns are not identity evidence.")

    # Fixed existing V122 tag leaves may receive customer/haftAccount values from
    # workbook evidence. No tag/attribute is created if it is absent in contract.
    customer_header, customer_raw = _exact_header_value(values, "Customer", "Customer Name", "Partner Name", "LENS TP Name")
    detail = (((proposed.get("transportProfileDetails") or [{}])[0]) if isinstance(proposed.get("transportProfileDetails"), list) else {})
    tags = detail.get("tags") if isinstance(detail, dict) else None
    if isinstance(tags, list):
        for index, tag in enumerate(tags):
            if not isinstance(tag, dict):
                continue
            key = str(tag.get("key") or "")
            path = f"transportProfileDetails.0.tags.{index}.value"
            if path not in paths:
                continue
            if key == "customer" and customer_header and not _blank(customer_raw):
                before = tag.get("value")
                tag["value"] = _display(customer_raw)
                _add_mapping(mappings, mapped_paths, header=customer_header, source=customer_raw, path=path, previous=before, value=tag["value"], method="V7 customer tag evidence", reason="Existing customer tag value populated from explicit workbook customer/LENS evidence.")
            elif key == "haftAccount" and account_header and not _blank(account_raw):
                before = tag.get("value")
                tag["value"] = _display(account_raw)
                _add_mapping(mappings, mapped_paths, header=account_header, source=account_raw, path=path, previous=before, value=tag["value"], method="V7 haftAccount tag evidence", reason="Existing haftAccount tag value populated from exact HIP account workbook evidence.")


def _critical_paths_for(api_key: str, spec: Mapping[str, Any], proposed: Mapping[str, Any]) -> List[str]:
    critical = list(_CRITICAL_PATHS.get(api_key) or ())
    paths = [str(path) for path in (spec.get("paths") or [])]
    if api_key in {"source_tp", "target_tp"}:
        # documentTypeVersion is a separate required TP field whenever present.
        for path in paths:
            if _compact(_path_leaf(path)) == "documenttypeversion" and path not in critical:
                critical.append(path)
        iface = _read_path(proposed, "transportProfileDetails.0.interfaceDetails.0.interfaceType")
        if _interface_family(iface) in {"sftp", "ftp"}:
            for leaf in ("subscriptionfolder", "existingaccountname"):
                for path in paths:
                    if _compact(_path_leaf(path)) == leaf and path not in critical:
                        critical.append(path)
    if not critical:
        critical = [path for path in paths if _compact(_path_leaf(path)) in _IDENTITY_SUFFIXES][:4]
    return critical


def _tp_identity_and_payload(row: Mapping[str, Any]) -> Tuple[str, str]:
    if str(row.get("apiKey") or "") not in {"source_tp", "target_tp"}:
        return "", ""
    proposed = row.get("proposedRequest") or {}
    name = _display(_read_path(proposed, "transportProfileDetails.0.transportProfileName"))
    if not name:
        return "", ""
    identity = f"{row.get('apiKey')}::{name.casefold()}"
    payload = json.dumps(proposed, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return identity, payload


def _merge_or_block_tp_duplicates(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    passthrough: List[Dict[str, Any]] = []
    for row in rows:
        identity, _ = _tp_identity_and_payload(row)
        if identity:
            groups.setdefault(identity, []).append(row)
        else:
            passthrough.append(row)
    merged: List[Dict[str, Any]] = list(passthrough)
    for group in groups.values():
        if len(group) == 1:
            group[0]["evidenceRows"] = [int(group[0].get("excelRow") or 0)]
            group[0]["mergedDuplicateEvidenceCount"] = 0
            merged.append(group[0])
            continue
        fingerprints = {_tp_identity_and_payload(row)[1] for row in group}
        excel_rows = [int(row.get("excelRow") or 0) for row in group]
        if len(fingerprints) == 1:
            keeper = group[0]
            keeper["evidenceRows"] = excel_rows
            keeper["mergedDuplicateEvidenceCount"] = len(group) - 1
            keeper.setdefault("warnings", []).append(f"Merged {len(group)} exact duplicate TP evidence rows {excel_rows} into one executable candidate.")
            merged.append(keeper)
        else:
            for row in group:
                row["status"] = "NEEDS_INPUT"
                row["goodToTrigger"] = False
                row["score"] = max(0, int(row.get("score") or 0) - 20)
                row["duplicateWorkbookIdentity"] = True
                row["duplicateWorkbookRows"] = excel_rows
                row["evidenceRows"] = excel_rows
                row.setdefault("warnings", []).append(f"Conflicting duplicate TP identity appears in workbook rows {excel_rows}; payload values differ, so human review is required.")
                merged.append(row)
    merged.sort(key=lambda row: int(row.get("excelRow") or 0))
    return merged


def _contract_errors(api_key: str, kind: str, request: Dict[str, Any]) -> List[Dict[str, Any]]:
    result = validate_override_structure(api_key, kind, request)
    return list(result.get("errors") or []) if isinstance(result, dict) else []


def evaluate_row(record: Mapping[str, Any], spec: Mapping[str, Any], column_map: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    api_key = str(spec.get("apiKey") or "")
    kind = str(spec.get("requestKind") or "payload")
    proposed = deepcopy(spec.get("effective") or {})
    generated = deepcopy(spec.get("generated") or {})
    values = record.get("values") or {}
    mappings: List[Dict[str, Any]] = []
    warnings: List[str] = []
    mapped_paths: List[str] = []
    for header, meta in column_map.items():
        source = values.get(header)
        if _blank(source):
            continue
        if api_key in {"source_tp", "target_tp"} and _norm_text(header) == _norm_text("LENS TP Name"):
            # Reference/customer label only (V7 hardening).
            continue
        path = str(meta.get("path") or "")
        current = _read_path(proposed, path)
        coerced, error = _coerce_like(source, current, path)
        if error:
            warnings.append(f"{header} -> {path}: {error}")
            continue
        _write_path(proposed, path, coerced)
        mapped_paths.append(path)
        mappings.append({
            "sourceColumn": header, "sourceValue": _display(source), "targetPath": path,
            "previousValue": current, "mappedValue": coerced,
            "confidence": meta.get("confidence"), "method": meta.get("method"), "reason": meta.get("reason"),
            "valueNormalized": _display(source) != _display(coerced),
        })

    document_evidence = _document_evidence_postprocess(record, spec, proposed, mappings, mapped_paths, warnings)
    _tp_postprocess(record, spec, proposed, mappings, mapped_paths, warnings)
    critical = _critical_paths_for(api_key, spec, proposed)
    missing = [path for path in critical if _blank(_read_path(proposed, path))]
    inherited_identity = [path for path in critical if path not in mapped_paths and not _blank(_read_path(proposed, path)) and _compact(_path_leaf(path)) in _IDENTITY_SUFFIXES]
    contract_errors = _contract_errors(api_key, kind, proposed)
    identity_from_excel = _identity_mapped(api_key, mapped_paths, critical)

    if contract_errors:
        status = "DO_NOT_TRIGGER"
    elif missing:
        status = "NEEDS_INPUT"
    elif not mappings:
        status = "DO_NOT_TRIGGER"
        warnings.append("No workbook value could be mapped safely into this API request.")
    elif not identity_from_excel:
        status = "NEEDS_INPUT"
        warnings.append("The API object identity is still inherited from the active configuration; map/confirm an identity value from this workbook row before triggering.")
    elif any(float(item.get("confidence") or 0) < 0.64 for item in mappings):
        status = "NEEDS_INPUT"
    else:
        status = "GOOD_TO_TRIGGER"

    base = 42 + min(32, len(mappings) * 8)
    if identity_from_excel:
        base += 12
    base -= len(missing) * 16
    base -= len(contract_errors) * 25
    base -= sum(1 for item in mappings if float(item.get("confidence") or 0) < 0.7) * 6
    if str(spec.get("contractStatus")) == "BLOCKED":
        base -= 8
        warnings.append("The active configuration currently reports this API contract as BLOCKED; stage the row and re-run preflight before LIVE.")
    score = max(0, min(100, int(round(base))))
    excel_row = int(record.get("excelRow") or 0)
    account, label = _record_label(values, excel_row)
    evidence = _record_evidence(values, excel_row)
    mapped_headers = {item["sourceColumn"] for item in mappings}
    unmapped = [header for header, value in values.items() if not _blank(value) and header not in mapped_headers]
    return {
        "excelRow": excel_row, "account": account, "recordLabel": label,
        "hipAccountName": evidence["hipAccount"], "applicationTracking": evidence["applicationTracking"],
        "lensTpName": evidence["lensTpName"], "customerName": evidence["customerName"], "explicitTpName": evidence["explicitTpName"],
        "apiKey": api_key, "apiLabel": spec.get("label"), "group": spec.get("group"), "requestKind": kind,
        "status": status, "score": score, "goodToTrigger": status == "GOOD_TO_TRIGGER",
        "mappings": mappings, "mappedCount": len(mappings), "mappedPaths": mapped_paths,
        "criticalPaths": critical, "missingCriticalPaths": missing, "inheritedIdentityPaths": inherited_identity,
        "contractErrors": contract_errors, "warnings": warnings, "unmappedColumns": unmapped,
        "documentEvidence": document_evidence,
        "generatedRequest": generated, "baseEffectiveRequest": spec.get("effective") or {}, "proposedRequest": proposed,
        "contractStatusBeforeMapping": spec.get("contractStatus"),
    }


def _api_row_rank(result: Mapping[str, Any]) -> float:
    status_bonus = {"GOOD_TO_TRIGGER": 42, "NEEDS_INPUT": 12, "DO_NOT_TRIGGER": -18}.get(str(result.get("status")), 0)
    mapped = int(result.get("mappedCount") or 0)
    missing = len(result.get("missingCriticalPaths") or [])
    errors = len(result.get("contractErrors") or [])
    key = str(result.get("apiKey") or "")
    return float(result.get("score") or 0) + status_bonus + mapped * 4 - missing * 10 - errors * 20 - _AUTO_API_PENALTY.get(key, 0)


def analyze_workbook(
    *, filename: str, data: bytes, preview_items: Sequence[Mapping[str, Any]], selected_api: str = "AUTO",
    requested_sheet: str = "", requested_header_row: int = 0, use_dell_aia: bool = True,
) -> Dict[str, Any]:
    workbook = read_workbook(filename, data)
    specs = build_api_specs(preview_items, selected_api)
    picked, header_index, sheet_meta = choose_sheet(workbook, specs, requested_sheet, requested_header_row)
    headers = picked["headers"]
    records = picked["records"]
    if not records:
        raise ValueError("The selected worksheet has a header but no populated data rows.")

    # For AUTO mode, constrain LLM context to the APIs that have the strongest
    # deterministic header affinity. The deterministic evaluator still considers
    # every applicable API.
    llm_specs = sorted(specs, key=lambda spec: _sheet_affinity(headers, [spec]), reverse=True)[:MAX_LLM_APIS]
    agent_meta = _aia_agents(headers, [r["values"] for r in records[:5]], llm_specs, use_dell_aia)
    spec_by_key = {str(spec["apiKey"]): spec for spec in specs}
    llm_hints = _validated_llm_hints(agent_meta, headers, spec_by_key)
    maps = {str(spec["apiKey"]): _deterministic_column_map(headers, spec, llm_hints) for spec in specs}

    results: List[Dict[str, Any]] = []
    alternatives: Dict[int, List[Dict[str, Any]]] = {}
    for record in records:
        evaluated = [evaluate_row(record, spec, maps[str(spec["apiKey"])]) for spec in specs]
        if str(selected_api or "AUTO") == "AUTO":
            evaluated.sort(key=_api_row_rank, reverse=True)
            chosen = evaluated[0]
            chosen["apiAlternatives"] = [
                {"apiKey": row["apiKey"], "apiLabel": row["apiLabel"], "status": row["status"], "score": row["score"], "mappedCount": row["mappedCount"], "missingCriticalPaths": row["missingCriticalPaths"]}
                for row in evaluated[1:6]
            ]
            alternatives[int(record.get("excelRow") or 0)] = chosen["apiAlternatives"]
            results.append(chosen)
        else:
            results.append(evaluated[0])

    raw_result_count = len(results)
    results = _merge_or_block_tp_duplicates(results)
    counts = {status: sum(1 for row in results if row["status"] == status) for status in ("GOOD_TO_TRIGGER", "NEEDS_INPUT", "DO_NOT_TRIGGER")}
    accounts = sorted({str(row.get("account") or "") for row in results if row.get("account")})
    mapping_summary = []
    for spec in specs:
        key = str(spec["apiKey"])
        mapping_summary.append({
            "apiKey": key, "apiLabel": spec["label"], "requestKind": spec["requestKind"],
            "columnMappings": [{"sourceColumn": header, "targetPath": meta["path"], "confidence": meta["confidence"], "method": meta["method"], "reason": meta["reason"]} for header, meta in maps[key].items()],
            "canonicalLeafCount": len(spec["paths"]), "contractStatus": spec["contractStatus"],
        })
    return {
        "ok": True,
        "policy": "AGENT_MAPS_EXISTING_VALUES_CANONICAL_ATTRIBUTES_IMMUTABLE_USER_APPROVES_STAGE",
        "agentSchemaEditAllowed": False,
        "agentValueMappingAllowed": True,
        "agentPersistentEditAllowed": False,
        "userApprovalRequiredBeforePersistence": True,
        "userEditAllowed": True,
        "file": {"name": filename, "format": workbook.get("format"), "size": len(data)},
        "sheet": {"name": picked["sheet"].get("name"), "headerRow": header_index + 1, "headers": headers, "dataRowCount": len(records)},
        "sheets": sheet_meta,
        "selectionMode": str(selected_api or "AUTO"),
        "summary": {"rows": len(results), "sourceRows": raw_result_count, "mergedDuplicateRows": max(0, raw_result_count-len(results)), "accounts": len(accounts), **counts},
        "accounts": accounts,
        "results": results,
        "mappingSummary": mapping_summary,
        "llm": agent_meta,
        "notes": [
            "GOOD_TO_TRIGGER is a local governed readiness result, not proof of LIVE endpoint availability.",
            "The agent may change proposed VALUES only at existing canonical leaf paths; it never adds/removes/renames API attributes or changes request structure.",
            "A proposed agent-mapped payload receives persistence/LIVE authority only after an explicit human Stage approval; then the existing API preflight must pass before LIVE execution.",
            "Columns that do not exist in the selected canonical API contract remain unmapped and are shown for review.",
            "V7 TP hardening is active: LENS TP Name is reference-only; HIP Account is exact-header-only; NAME(version) is split; SFTP/FTP requires Subscription Folder + Existing Account Name when those leaves exist; exact duplicate TP evidence is merged while conflicting duplicates are blocked.",
        ],
    }
