from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Iterable, List, Tuple


OUTPUT_HINTS: Dict[str, List[str]] = {
    "account_source": ["accountId", "id", "accountName"],
    "account_target": ["accountId", "id", "accountName"],
    "partner_target": ["partnerId", "id", "partnerIdentifierValue"],
    "system_source": ["systemId", "id", "systemName"],
    "doctype_source": ["documentTypeId", "id", "documentTypeName"],
    "doctype_target": ["documentTypeId", "id", "documentTypeName"],
    "map": ["mapId", "id", "mapIdentifier"],
    "rule": ["ruleId", "id", "ruleName"],
    "source_tp": ["transportProfileId", "id", "transportProfileName"],
    "target_tp": ["transportProfileId", "id", "transportProfileName"],
    "flow_create": ["flowId", "flowDefinitionId", "id", "flowName"],
    "flow_deploy": ["deploymentId", "id", "flowName"],
}


def _tokens(path: str) -> List[str]:
    return [part for part in str(path or "").strip().strip(".").split(".") if part != ""]


def get_path(value: Any, path: str) -> Tuple[bool, Any]:
    parts = _tokens(path)
    node = value
    for part in parts:
        if isinstance(node, dict) and part in node:
            node = node[part]
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return False, None
    return True, node


def set_path(value: Any, path: str, new_value: Any) -> Any:
    parts = _tokens(path)
    if not parts:
        return deepcopy(new_value)
    root = deepcopy(value)
    node = root
    for index, part in enumerate(parts):
        last = index == len(parts) - 1
        next_part = parts[index + 1] if not last else ""
        if isinstance(node, list):
            if not part.isdigit():
                raise ValueError(f"List path segment must be numeric: {path}")
            idx = int(part)
            while len(node) <= idx:
                node.append({} if not next_part.isdigit() else [])
            if last:
                node[idx] = deepcopy(new_value)
            else:
                if not isinstance(node[idx], (dict, list)):
                    raise ValueError(f"Mapping target crosses an existing scalar value: {path}")
                node = node[idx]
            continue
        if not isinstance(node, dict):
            raise ValueError(f"Cannot write mapping target path: {path}")
        if last:
            node[part] = deepcopy(new_value)
        else:
            if part not in node:
                node[part] = [] if next_part.isdigit() else {}
            elif not isinstance(node[part], (dict, list)):
                raise ValueError(f"Mapping target crosses an existing scalar value: {path}")
            node = node[part]
    return root


def leaf_paths(value: Any, prefix: str = "") -> List[str]:
    out: List[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            p = f"{prefix}.{key}" if prefix else str(key)
            out.extend(leaf_paths(child, p))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            p = f"{prefix}.{index}" if prefix else str(index)
            out.extend(leaf_paths(child, p))
    else:
        out.append(prefix)
    return out


def _normalize_target(path: str, request_kind: str = "payload") -> Tuple[str, str]:
    path = str(path or "").strip()
    if path.startswith("payload."):
        return "payload", path[len("payload."):]
    if path.startswith("params."):
        return "params", path[len("params."):]
    return request_kind or "payload", path


def _normalize_source(path: str) -> str:
    path = str(path or "").strip()
    for prefix in ("output.", "result.extracted.", "extracted."):
        if path.startswith(prefix):
            return path[len(prefix):]
    return path


def apply_edge_mappings(
    request: Dict[str, Any],
    incoming_edges: Iterable[Dict[str, Any]],
    step_outputs: Dict[str, Any],
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Apply explicit graph-edge mappings to a generated request.

    Returns (request, resolved_mappings, unresolved_mappings). Explicit edge
    mappings win over the generated request because the graph is the user's
    execution contract. Only values already produced by upstream nodes can be
    injected.
    """
    effective = deepcopy(request)
    resolved: List[Dict[str, Any]] = []
    unresolved: List[Dict[str, Any]] = []
    for edge in incoming_edges:
        source_id = str(edge.get("source") or "")
        source_output = step_outputs.get(source_id)
        for mapping in edge.get("mappings") or []:
            from_path = _normalize_source(str(mapping.get("from") or ""))
            to_path_raw = str(mapping.get("to") or "")
            if not from_path or not to_path_raw:
                unresolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": to_path_raw, "reason": "mapping path is blank"})
                continue
            found, mapped_value = get_path(source_output, from_path) if source_output is not None else (False, None)
            request_kind = str(effective.get("requestKind") or "payload")
            target_kind, target_path = _normalize_target(to_path_raw, request_kind)
            if not found:
                # The API Testing Area and generated request may already contain a
                # validated concrete ID/name from input.json/config/runtime fallback.
                # Auto-wired graph mappings are an enrichment path, not a reason to
                # erase a known-good value merely because an EXISTING response did
                # not echo the object ID. Preserve that concrete value and continue.
                current_base = effective.get(target_kind) if target_kind in {"payload", "params"} else None
                current_found, current_value = get_path(current_base, target_path) if isinstance(current_base, (dict, list)) else (False, None)
                if current_found and current_value not in (None, "", [], {}, 0, "0"):
                    resolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": f"{target_kind}.{target_path}", "value": deepcopy(current_value), "fallback": "validated_effective_request", "reason": "Upstream output did not expose this value; preserved the already validated request value."})
                    continue
                unresolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": to_path_raw, "reason": "upstream output path is unavailable"})
                continue
            if target_kind not in {"payload", "params"}:
                unresolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": to_path_raw, "reason": "target must be payload.* or params.*"})
                continue
            base = effective.get(target_kind)
            if not isinstance(base, (dict, list)):
                base = {}
            try:
                effective[target_kind] = set_path(base, target_path, mapped_value)
            except Exception as exc:
                unresolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": to_path_raw, "reason": str(exc)})
                continue
            resolved.append({"edgeId": edge.get("id"), "source": source_id, "from": from_path, "to": f"{target_kind}.{target_path}", "value": deepcopy(mapped_value)})
    return effective, resolved, unresolved


def _request_rows(preview: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {str(row.get("stepKey") or ""): row for row in (preview.get("items") or []) if row.get("stepKey")}


def _candidate_mapping(source_api: str, target_request: Dict[str, Any]) -> Dict[str, str] | None:
    hints = OUTPUT_HINTS.get(source_api) or []
    request_kind = "params" if target_request.get("params") is not None and target_request.get("payload") is None else "payload"
    body = target_request.get(request_kind)
    if not isinstance(body, (dict, list)):
        return None
    leaves = leaf_paths(body)
    by_leaf: Dict[str, List[str]] = {}
    for p in leaves:
        leaf = p.split(".")[-1]
        by_leaf.setdefault(leaf, []).append(p)
    for hint in hints:
        matches = by_leaf.get(hint) or []
        if len(matches) == 1:
            return {"from": f"output.{hint}", "to": f"{request_kind}.{matches[0]}"}
    return None


def compile_flow(
    flow: Dict[str, Any],
    catalog_keys: Iterable[str],
    preview: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    nodes = list(flow.get("nodes") or [])
    edges = list(flow.get("edges") or [])
    catalog = set(str(x) for x in catalog_keys)
    previews = _request_rows(preview or {})
    errors: List[Dict[str, Any]] = []
    warnings: List[Dict[str, Any]] = []
    fixes: List[Dict[str, Any]] = []
    suggestions: List[Dict[str, Any]] = []

    ids = [str(node.get("id") or "") for node in nodes]
    if any(not x for x in ids):
        errors.append({"code": "NODE_ID_REQUIRED", "message": "Every API block needs an id."})
    if len(set(ids)) != len(ids):
        errors.append({"code": "DUPLICATE_NODE_ID", "message": "API block ids must be unique."})
    node_by_id = {str(node.get("id") or ""): node for node in nodes if node.get("id")}
    for node in nodes:
        api_key = str(node.get("api_key") or "")
        if api_key not in catalog:
            errors.append({"code": "UNKNOWN_API", "nodeId": node.get("id"), "message": f"Unknown HIP API block: {api_key}"})

    edge_ids: set[str] = set()
    outgoing: Dict[str, List[str]] = {node_id: [] for node_id in node_by_id}
    indegree: Dict[str, int] = {node_id: 0 for node_id in node_by_id}
    for edge in edges:
        edge_id = str(edge.get("id") or "")
        if edge_id and edge_id in edge_ids:
            errors.append({"code": "DUPLICATE_EDGE_ID", "edgeId": edge_id, "message": "Connection ids must be unique."})
        edge_ids.add(edge_id)
        source, target = str(edge.get("source") or ""), str(edge.get("target") or "")
        if source not in node_by_id or target not in node_by_id:
            errors.append({"code": "UNKNOWN_EDGE_NODE", "edgeId": edge_id, "message": f"Connection references an unknown block: {source} -> {target}"})
            continue
        outgoing[source].append(target)
        indegree[target] += 1
        for mapping in edge.get("mappings") or []:
            from_path, to_path = str(mapping.get("from") or "").strip(), str(mapping.get("to") or "").strip()
            if not from_path or not to_path:
                errors.append({"code": "INVALID_MAPPING", "edgeId": edge_id, "message": "Both mapping From and To paths are required."})
            elif not (to_path.startswith("payload.") or to_path.startswith("params.")):
                warnings.append({"code": "IMPLICIT_TARGET_KIND", "edgeId": edge_id, "message": f"Mapping target '{to_path}' has no payload./params. prefix; the target request kind will be used."})
            else:
                # V71 structure lock: graph mappings may replace values only.
                # They cannot manufacture a new target attribute/path. The
                # preview is already normalized to the U-HAUL-tested structure.
                target_node = node_by_id.get(target) or {}
                target_request = previews.get(str(target_node.get("api_key") or "")) or {}
                if target_request:
                    request_kind = str(target_request.get("requestKind") or ("params" if target_request.get("params") is not None and target_request.get("payload") is None else "payload"))
                    target_kind, target_path = _normalize_target(to_path, request_kind)
                    body = target_request.get(target_kind)
                    exists, _current = get_path(body, target_path) if isinstance(body, (dict, list)) else (False, None)
                    if not exists:
                        errors.append({
                            "code": "NON_CANONICAL_MAPPING_TARGET",
                            "edgeId": edge_id,
                            "message": f"Connection mapping target '{to_path}' is not an existing canonical {target_kind} attribute. Only values may change.",
                        })

    queue = [node_id for node_id in node_by_id if indegree[node_id] == 0]
    order: List[str] = []
    while queue:
        current = queue.pop(0)
        order.append(current)
        for target in outgoing.get(current, []):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    if len(order) != len(node_by_id):
        errors.append({"code": "CYCLE", "message": "The API Flow contains a cycle. Remove the loop before execution."})

    node_previews: Dict[str, Any] = {}
    for node_id, node in node_by_id.items():
        api_key = str(node.get("api_key") or "")
        row = deepcopy(previews.get(api_key) or {})
        node_previews[node_id] = row
        if row.get("error"):
            warnings.append({"code": "REQUEST_PREVIEW_ERROR", "nodeId": node_id, "message": str(row.get("error"))})
        if row.get("applicable") is False and node.get("enabled", True):
            warnings.append({"code": "NOT_APPLICABLE", "nodeId": node_id, "message": f"{api_key} is not applicable to this configuration."})
            fixes.append({"type": "disable_node", "nodeId": node_id, "reason": "API is not applicable to the active configuration"})

    for edge in edges:
        if edge.get("mappings"):
            continue
        source = node_by_id.get(str(edge.get("source") or "")) or {}
        target = node_by_id.get(str(edge.get("target") or "")) or {}
        target_request = previews.get(str(target.get("api_key") or "")) or {}
        candidate = _candidate_mapping(str(source.get("api_key") or ""), target_request)
        if candidate:
            suggestions.append({"edgeId": edge.get("id"), "source": edge.get("source"), "target": edge.get("target"), "mapping": candidate, "confidence": "HIGH", "reason": "Upstream output name matches exactly one downstream request field."})

    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "fixes": fixes,
        "suggestedMappings": suggestions,
        "executionOrder": order,
        "nodePreviews": node_previews,
        "nodeCount": len(nodes),
        "edgeCount": len(edges),
    }


def apply_safe_fixes(flow: Dict[str, Any], compilation: Dict[str, Any]) -> Dict[str, Any]:
    fixed = deepcopy(flow)
    nodes = fixed.get("nodes") or []
    edges = fixed.get("edges") or []
    fixes_applied: List[Dict[str, Any]] = []

    disabled = {str(row.get("nodeId")) for row in (compilation.get("fixes") or []) if row.get("type") == "disable_node"}
    for node in nodes:
        if str(node.get("id")) in disabled and node.get("enabled", True):
            node["enabled"] = False
            fixes_applied.append({"type": "disable_node", "nodeId": node.get("id")})

    suggestion_by_edge = {str(row.get("edgeId")): row for row in (compilation.get("suggestedMappings") or [])}
    for edge in edges:
        if edge.get("mappings"):
            continue
        suggestion = suggestion_by_edge.get(str(edge.get("id")))
        if suggestion and suggestion.get("mapping"):
            edge["mappings"] = [deepcopy(suggestion["mapping"])]
            fixes_applied.append({"type": "add_mapping", "edgeId": edge.get("id"), "mapping": suggestion["mapping"]})

    return {"flow": fixed, "fixesApplied": fixes_applied}
