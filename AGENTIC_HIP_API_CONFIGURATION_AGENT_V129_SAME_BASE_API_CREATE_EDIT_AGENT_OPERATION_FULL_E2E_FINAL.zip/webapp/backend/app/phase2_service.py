from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List

from .legacy_adapter import LEGACY_ROOT, worker_command, attach_inline_validation_repairs, parse_worker_json_output, preview_migration_requests

from api_pdf_ingestion import PdfApiKnowledgeBase
from input_mapping_learner import load_mapping_knowledge, mapping_learning_summary, record_mapping_example
from learn_assistant import LearnAssistant
from production_guard import redact_sensitive
from execution_flow import ExecutionFlowConfig



def _load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def validate_configuration(workspace: Path) -> Dict[str, Any]:
    """Run the proven non-mutating Application Studio agent checks in an isolated worker."""
    workspace = Path(workspace).resolve()
    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(workspace)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(
        worker_command(workspace, "validate"),
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=240,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "Agent validation worker failed")
    result = parse_worker_json_output(proc.stdout, label="agent validation worker")
    result = attach_inline_validation_repairs(workspace, result)

    # V125: the historical validator remains the authoritative 18-base-contract
    # check, while all seven Dev-published Migration blocks are now surfaced in
    # the same validation response. Migration readiness is non-mutating and is
    # deliberately reported separately so the user can first build a valid base
    # configuration, then enter targetEnvironment/other migration values in the
    # governed value editor before LIVE. The final production preflight requires
    # both base validation and Migration readiness.
    try:
        migration_preview = preview_migration_requests(workspace)
        migration_items = list(migration_preview.get("items") or [])
        applicable = [row for row in migration_items if isinstance(row, dict) and row.get("applicable") is not False]
        ready_rows = [row for row in applicable if bool(row.get("migrationReady"))]
        blocked_rows = [
            {
                "stepKey": row.get("stepKey"),
                "label": row.get("api") or row.get("stepKey"),
                "errors": list(row.get("migrationErrors") or []),
            }
            for row in applicable if not bool(row.get("migrationReady"))
        ]
        flow_summary = ExecutionFlowConfig(workspace).summary()
        migration_requested = bool(flow_summary.get("migrationEnabled"))
        result["migration"] = {
            "requested": migration_requested,
            "enabledByUser": migration_requested,
            "ready": len(ready_rows) == len(applicable),
            "total": len(migration_items),
            "applicableCount": len(applicable),
            "readyCount": len(ready_rows),
            "blockedCount": len(blocked_rows),
            "blockedItems": blocked_rows,
            "items": [
                {
                    "stepKey": row.get("stepKey"),
                    "label": row.get("api") or row.get("stepKey"),
                    "applicable": row.get("applicable") is not False,
                    "ready": bool(row.get("migrationReady")) if row.get("applicable") is not False else True,
                    "errors": list(row.get("migrationErrors") or []),
                }
                for row in migration_items if isinstance(row, dict)
            ],
        }
        result["executionFlow"] = {
            "ok": bool(flow_summary.get("valid")),
            "valid": bool(flow_summary.get("valid")),
            "migrationEnabled": migration_requested,
            "orderedLiveSteps": list(flow_summary.get("orderedLiveSteps") or []),
            "liveStepCount": int(flow_summary.get("liveStepCount") or 0),
            "errors": list(flow_summary.get("errors") or []),
            "warnings": list(flow_summary.get("warnings") or []),
        }
        result["fullLiveReady"] = bool(result.get("ok")) and bool(flow_summary.get("valid")) and (not migration_requested or bool(result["migration"]["ready"]))
        result["registeredApiBlocks"] = {"base": int(((result.get("requests") or {}).get("total") or 18)), "migration": len(migration_items), "total": int(((result.get("requests") or {}).get("total") or 18)) + len(migration_items)}
    except Exception as migration_exc:
        result["migration"] = {
            "requested": False,
            "ready": False,
            "total": 7,
            "applicableCount": 0,
            "readyCount": 0,
            "blockedCount": 1,
            "blockedItems": [{"stepKey": "migration_preflight", "label": "Migration preflight", "errors": [f"Could not build Migration preview: {type(migration_exc).__name__}: {migration_exc}"]}],
            "items": [],
        }
        try:
            flow_summary = ExecutionFlowConfig(workspace).summary()
        except Exception:
            flow_summary = {"valid": False, "migrationEnabled": False, "errors": ["Execution flow could not be loaded."], "warnings": []}
        result["executionFlow"] = {
            "ok": bool(flow_summary.get("valid")),
            "valid": bool(flow_summary.get("valid")),
            "migrationEnabled": bool(flow_summary.get("migrationEnabled")),
            "orderedLiveSteps": list(flow_summary.get("orderedLiveSteps") or []),
            "liveStepCount": int(flow_summary.get("liveStepCount") or 0),
            "errors": list(flow_summary.get("errors") or []),
            "warnings": list(flow_summary.get("warnings") or []),
        }
        result["fullLiveReady"] = False
        result["registeredApiBlocks"] = {"base": int(((result.get("requests") or {}).get("total") or 18)), "migration": 7, "total": int(((result.get("requests") or {}).get("total") or 18)) + 7}
    return redact_sensitive(result)


def configuration_evidence(workspace: Path) -> Dict[str, Any]:
    workspace = Path(workspace).resolve()
    canonical = _load_json(workspace / "input.json", {})
    input_files = workspace / "input_files"
    manifest = sorted(str(path.relative_to(input_files)).replace("\\", "/") for path in input_files.rglob("*") if path.is_file()) if input_files.exists() else []
    fm = canonical.get("_file_mapping") if isinstance(canonical, dict) else {}
    artifact = canonical.get("_artifact_validation") if isinstance(canonical, dict) else {}
    audit = canonical.get("_builder_audit") if isinstance(canonical, dict) else {}
    blueprint = canonical.get("_input_extraction_blueprint") if isinstance(canonical, dict) else {}
    objects = canonical.get("objects") if isinstance(canonical, dict) else {}
    source_doc = (objects or {}).get("source_document_type") or {}
    target_doc = (objects or {}).get("target_document_type") or {}
    return redact_sensitive({
        "manifest": manifest,
        "fileMapping": fm if isinstance(fm, dict) else {},
        "artifactValidation": artifact if isinstance(artifact, dict) else {},
        "builderAudit": audit if isinstance(audit, dict) else {},
        "extractionBlueprint": blueprint if isinstance(blueprint, dict) else {},
        "documentTypes": {
            "source": {
                "name": source_doc.get("name") or source_doc.get("document_type_name"),
                "format": source_doc.get("data_format_type") or source_doc.get("dataFormatType"),
                "identifier": source_doc.get("document_identifier") or source_doc.get("documentIdentifier"),
            },
            "target": {
                "name": target_doc.get("name") or target_doc.get("document_type_name"),
                "format": target_doc.get("data_format_type") or target_doc.get("dataFormatType"),
                "identifier": target_doc.get("document_identifier") or target_doc.get("documentIdentifier"),
            },
        },
        "flowType": canonical.get("flow_type"),
        "direction": canonical.get("direction"),
        "transactionCode": canonical.get("tx_code"),
        "customer": canonical.get("customer"),
    })


def mapping_learning_state() -> Dict[str, Any]:
    knowledge = load_mapping_knowledge(LEGACY_ROOT)
    summary = mapping_learning_summary(knowledge)
    return redact_sensitive({
        **summary,
        "target_examples": 3,
        "examples": list(knowledge.get("examples") or []),
        "role_tokens": knowledge.get("role_tokens") or {},
        "field_rule_counts": knowledge.get("field_rule_counts") or {},
    })


def teach_mapping_reference(workspace: Path, source_kind: str = "react_validated_input_json_plus_customer_files") -> Dict[str, Any]:
    workspace = Path(workspace).resolve()
    canonical = _load_json(workspace / "input.json", {})
    if not isinstance(canonical, dict) or not canonical:
        raise ValueError("input.json must be built before teaching the mapping learner.")
    input_files = workspace / "input_files"
    manifest = sorted(path.name for path in input_files.rglob("*") if path.is_file()) if input_files.exists() else []
    learned = record_mapping_example(LEGACY_ROOT, canonical, manifest, source_kind=source_kind)
    return mapping_learning_state() | {"recorded": True, "example_count": len(learned.get("examples") or [])}


def learn_assistant_for(workspace: Path) -> LearnAssistant:
    workspace = Path(workspace).resolve()
    pdf_kb = PdfApiKnowledgeBase(workspace)
    return LearnAssistant(workspace, pdf_kb)


def learn_records(workspace: Path) -> List[Dict[str, Any]]:
    assistant = learn_assistant_for(workspace)
    rows = []
    for item in assistant.list_records():
        rows.append(redact_sensitive({
            "id": item.get("id"), "filename": item.get("filename"), "kind": item.get("kind"),
            "learnedAt": item.get("learnedAt"), "summary": item.get("summary"),
            "vision": item.get("vision") or {}, "warnings": item.get("warnings") or [],
            "storedRedacted": item.get("storedRedacted", False),
        }))
    return rows


def ingest_learn_file(workspace: Path, filename: str, data: bytes, mime_type: str = "", question: str = "") -> Dict[str, Any]:
    assistant = learn_assistant_for(workspace)
    return redact_sensitive(assistant.ingest(filename, data, mime_type, question))


def ask_learn(workspace: Path, question: str) -> Dict[str, Any]:
    assistant = learn_assistant_for(workspace)
    return redact_sensitive(assistant.ask(question))


def list_reports(workspace: Path) -> List[Dict[str, Any]]:
    workspace = Path(workspace).resolve()
    reports = workspace / "reports"
    if not reports.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for path in sorted((p for p in reports.iterdir() if p.is_file()), key=lambda p: p.stat().st_mtime, reverse=True):
        rows.append({
            "name": path.name,
            "size": path.stat().st_size,
            "modified": path.stat().st_mtime,
            "kind": path.suffix.lower().lstrip(".") or "file",
        })
    return rows


def read_report(workspace: Path, report_name: str) -> Dict[str, Any]:
    workspace = Path(workspace).resolve()
    safe_name = Path(report_name).name
    path = (workspace / "reports" / safe_name).resolve()
    if path.parent != (workspace / "reports").resolve() or not path.exists() or not path.is_file():
        raise FileNotFoundError(report_name)
    if path.suffix.lower() == ".json":
        return {"name": safe_name, "format": "json", "content": redact_sensitive(_load_json(path, {}))}
    text = path.read_text(encoding="utf-8", errors="replace")
    if path.suffix.lower() in {".html", ".htm"}:
        # HTML reports are generated with secret redaction already applied. Keep the
        # complete document so the React report viewer can render/download it.
        return {"name": safe_name, "format": "html", "content": text}
    return {"name": safe_name, "format": "text", "content": str(redact_sensitive(text))[:500000]}
