from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Tuple

LEGACY_ROOT = Path(__file__).resolve().parents[3]
if str(LEGACY_ROOT) not in sys.path:
    sys.path.insert(0, str(LEGACY_ROOT))

from api_execution_plan import STEP_DEFINITIONS
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
from input_builder_core import (
    build_from_config_manual,
    build_from_config_manual_and_raw_files,
    build_from_raw_files,
    combine_existing_input_with_artifact_evidence,
    _canonical_input_json_file_score,
    normalize_input_json,
    save_input_json,
)
from input_builder_integration import (
    apply_answers,
    apply_selected_interfaces,
    apply_user_request_hints,
    enrich_provable_values,
    force_hip_automation,
    unresolved_questions,
)
from interface_registry import registry
from input_bundle import extract_input_zip
from input_extraction_blueprint import apply_input_extraction_blueprint, merge_blueprint_questions, write_blueprint_execution_report, detect_user_selection_conflicts
from payload_overrides import PayloadOverrideStore, save_override
from api_contract_policy import assert_no_request_override
from migration_api_contract import MIGRATION_STEP_DEFINITIONS, migration_catalog


def api_catalog() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for index, (key, meta) in enumerate(STEP_DEFINITIONS.items(), start=1):
        rows.append({
            "key": key,
            "label": meta.get("label") or key,
            "group": meta.get("group") or "API",
            "order": index,
            "deployment_group": DEFAULT_DEPLOYMENT_GROUP,
            "reusable": True,
        })
    return rows


def migration_api_catalog() -> List[Dict[str, Any]]:
    """Additive migration blocks; does not change the historical 18 API pipeline."""
    return migration_catalog()


def all_api_catalog() -> List[Dict[str, Any]]:
    return api_catalog() + migration_api_catalog()


def interface_catalog() -> List[Dict[str, Any]]:
    values = registry(LEGACY_ROOT)
    return [{"key": key, **value} for key, value in values.items()]


def transaction_metadata() -> Dict[str, Any]:
    return {
        "default_direction": "Outbound",
        "editable_direction": True,
        "directions": {
            "Inbound": {
                "suggested_transactions": ["850"],
                "description": "Inbound transactions such as 850 can be Translation or Passthrough.",
            },
            "Outbound": {
                "suggested_transactions": ["832", "855", "856"],
                "description": "Outbound supports 832, 855, 856 and additional customer transactions.",
            },
        },
        "flow_types": ["Auto", "Translation", "Passthrough"],
        "custom_transaction_allowed": True,
    }


def _copy_uploads_to_input_files(workspace: Path) -> List[Path]:
    upload_dir = workspace / "uploads"
    input_files = workspace / "input_files"
    input_files.mkdir(parents=True, exist_ok=True)
    paths: List[Path] = []
    for src in upload_dir.iterdir() if upload_dir.exists() else []:
        if not src.is_file() or src.name.lower() == "input.json":
            continue
        if src.suffix.lower() == ".zip":
            extract_input_zip(src.read_bytes(), input_files)
            continue
        dst = input_files / src.name
        shutil.copy2(src, dst)
    # Re-scan after ZIP extraction so direct uploads and ZIP contents follow the
    # exact same Input Builder path.
    paths = [p for p in input_files.rglob("*") if p.is_file() and p.name.lower() != "input.json"]
    return paths


def _find_manual(paths: List[Path]) -> Path | None:
    for path in paths:
        low = path.name.lower()
        if path.suffix.lower() in {".xlsx", ".xlsm"} and ("manual" in low or "config" in low):
            return path
    return None


def _received_context_name(workspace: Path, customer: str = "") -> str:
    """Return a meaningful customer-package name, never the random workspace id."""
    if str(customer or "").strip():
        return str(customer).strip()
    upload_dir = Path(workspace) / "uploads"
    zips = [p for p in upload_dir.glob("*.zip") if p.is_file()] if upload_dir.exists() else []
    if len(zips) == 1:
        return zips[0].stem
    return ""


def _canonical_json_score(path: Path) -> tuple[int, Dict[str, Any] | None]:
    """Delegate canonical HIP JSON recognition to the shared core builder.

    Keeping React and core ZIP ingestion on one structural detector prevents a
    file from being authoritative in one UI path but treated as a raw payload in
    another.
    """
    return _canonical_input_json_file_score(path)


def _find_authoritative_json(workspace: Path, raw_paths: List[Path]) -> tuple[Path | None, Dict[str, Any] | None]:
    candidates: List[Path] = []
    upload_dir = Path(workspace) / "uploads"
    if upload_dir.exists():
        candidates.extend(p for p in upload_dir.rglob("*.json") if p.is_file())
    candidates.extend(p for p in raw_paths if p.suffix.lower() == ".json" and p.is_file())

    best_path: Path | None = None
    best_value: Dict[str, Any] | None = None
    best_score = 0
    seen: set[str] = set()
    for path in candidates:
        key = str(path.resolve())
        if key in seen:
            continue
        seen.add(key)
        score, value = _canonical_json_score(path)
        if score > best_score:
            best_path, best_value, best_score = path, value, score
    return best_path, best_value


def _approved_interface_key(workspace: Path, canonical: Dict[str, Any], side: str, fallback: str) -> str:
    """Resolve the UI/registry key that matches an approved TP interface type."""
    objects = canonical.get("objects") if isinstance(canonical.get("objects"), dict) else {}
    value = objects.get(f"{side}_transport_profile")
    if isinstance(value, list):
        value = next((item for item in value if isinstance(item, dict)), {})
    tp = value if isinstance(value, dict) else {}
    raw = str(tp.get("interface_type") or "").strip().lower().replace("_", "-")
    if not raw:
        return fallback
    squashed = raw.replace(" ", "").replace("-", "")
    for key, definition in registry(workspace).items():
        aliases = {
            str(key).strip().lower().replace("_", "-"),
            str(definition.get("displayName") or "").strip().lower().replace("_", "-"),
            str(definition.get("apiInterfaceType") or "").strip().lower().replace("_", "-"),
        }
        if raw in aliases:
            return key
        alias_squashed = {x.replace(" ", "").replace("-", "") for x in aliases}
        if squashed in alias_squashed:
            return key
    return fallback


def build_configuration(workspace: Path, settings: Dict[str, Any], *, use_dell_aia: bool = True) -> Dict[str, Any]:
    workspace = Path(workspace)
    raw_paths = _copy_uploads_to_input_files(workspace)
    input_mode = str(settings.get("input_mode") or "files")
    customer = str(settings.get("customer") or "")
    ui_direction = str(settings.get("direction") or "Outbound")
    # A new React configuration card carries convenience defaults (Outbound/850).
    # For files-only onboarding those defaults are *hints*, not authoritative
    # customer facts. Let physical customer evidence/manuals establish direction
    # first; use the card value only when extraction leaves it unresolved.
    direction = "" if str(settings.get("input_mode") or "files") == "files" else ui_direction
    flow_type_ui = str(settings.get("flow_type") or "Auto")
    flow_type = "" if flow_type_ui == "Auto" else flow_type_ui.lower()
    source_interface = str(settings.get("source_interface") or "SFTP")
    target_interface = str(settings.get("target_interface") or source_interface)
    tx_code = str(settings.get("transaction_code") or "").strip()
    user_instructions = str(settings.get("user_instructions") or "").strip()
    manual = _find_manual(raw_paths)
    received_context = _received_context_name(workspace, customer)

    authoritative_path, authoritative_input = _find_authoritative_json(workspace, raw_paths)
    supporting_paths = [
        p for p in raw_paths
        if authoritative_path is None or p.resolve() != authoritative_path.resolve()
    ]

    # A structurally valid HIP JSON is authoritative whenever the customer
    # uploads one, even if its filename is LEGRAND_*_dev_approved.json and even
    # if the UI was left on the default "Customer files only" mode.  This fixes
    # the previous behaviour where correct values were discarded and then asked
    # back to the user as unresolved questions.
    if authoritative_input is not None:
        existing = authoritative_input
        # The approved JSON must win over convenience defaults stored on a fresh
        # UI configuration card.  Otherwise normalize_input_json() would receive
        # "Outbound" and could flip a correct uploaded Inbound configuration.
        approved_customer = str(existing.get("customer") or customer)
        approved_direction = str(existing.get("direction") or direction)
        approved_flow_type = str(existing.get("flow_type") or "").strip().lower()
        if not approved_flow_type and "requires_data_map" in existing:
            approved_flow_type = "translation" if bool(existing.get("requires_data_map")) else "passthrough"
        if supporting_paths:
            evidence = build_from_raw_files(
                supporting_paths,
                customer=approved_customer,
                direction=approved_direction,
                flow_type=approved_flow_type,
                use_dell_aia=use_dell_aia,
                folder_name=received_context or approved_customer,
            )
            canonical = combine_existing_input_with_artifact_evidence(
                existing,
                evidence,
                manifest=[p.name for p in supporting_paths],
                customer=approved_customer,
                direction=approved_direction,
                flow_type=approved_flow_type,
            )
        else:
            canonical = normalize_input_json(
                existing, customer=approved_customer, direction=approved_direction, flow_type=approved_flow_type
            )
        canonical.setdefault("_builder_audit", {})["authoritative_json"] = {
            "filename": authoritative_path.name if authoritative_path else "uploaded JSON",
            "modeSelected": input_mode,
            "autoDetected": input_mode != "input_files" or (authoritative_path and authoritative_path.name.lower() != "input.json"),
            "source": "uploaded canonical HIP JSON",
            "note": "Approved input/config JSON remained authoritative; supporting files only filled blanks or validated evidence.",
        }
    elif manual:
        # No input.json is required. If a Configuration Manual is present among
        # the received customer files, consume it automatically as structured
        # evidence even when the UI was left on "Customer files only". This
        # makes ZIP/folder intake resilient and avoids asking the user for values
        # already present in the customer's workbook.
        other = [p for p in raw_paths if p != manual]
        if other:
            canonical = build_from_config_manual_and_raw_files(
                manual,
                other,
                folder_name=received_context,
                customer=customer,
                direction=direction,
                flow_type=flow_type,
                use_dell_aia=use_dell_aia,
                manual_primary=True,
            )
        else:
            canonical = build_from_config_manual(
                manual,
                folder_name=received_context,
                customer=customer,
                direction=direction,
                flow_type=flow_type,
            )
        canonical.setdefault("_builder_audit", {})["automatic_configuration_manual"] = {
            "filename": manual.name,
            "modeSelected": input_mode,
            "source": "received customer files",
            "note": "Configuration Manual was auto-detected and used because no authoritative input.json was supplied.",
        }
    else:
        if not raw_paths:
            raise ValueError("Upload at least one customer artifact before building input.json.")
        canonical = build_from_raw_files(
            raw_paths,
            customer=customer,
            direction=direction,
            flow_type=flow_type,
            use_dell_aia=use_dell_aia,
            folder_name=received_context,
        )

    # For a detected approved HIP JSON, the file is the configuration source of
    # truth.  Do not overwrite its Inbound/Outbound direction or transaction
    # code with convenience defaults from a newly-created UI card (Outbound /
    # 850).  When there is no authoritative JSON, explicit UI selections remain
    # authoritative as before.
    if authoritative_input is None:
        # Received customer evidence wins over untouched new-card defaults.
        # The UI values only fill unresolved fields, so an uploaded 856/Inbound
        # package cannot be silently rewritten to the default 850/Outbound.
        extracted_direction = str(canonical.get("direction") or "").strip()
        if not extracted_direction and ui_direction:
            canonical["direction"] = ui_direction
        if not str(canonical.get("tx_code") or "").strip() and tx_code:
            canonical["tx_code"] = tx_code
        if not str(canonical.get("tx_name") or "").strip() and settings.get("transaction_name"):
            canonical["tx_name"] = str(settings.get("transaction_name"))
        direction = str(canonical.get("direction") or ui_direction)
        tx_code = str(canonical.get("tx_code") or tx_code)
        canonical.setdefault("_builder_audit", {})["received_value_precedence"] = {
            "direction": direction,
            "transaction_code": tx_code,
            "note": "Extracted/manual customer values take precedence over untouched React card defaults; card values fill blanks only.",
        }
    else:
        direction = str(canonical.get("direction") or direction)
        tx_code = str(canonical.get("tx_code") or tx_code)
        canonical.setdefault("_builder_audit", {})["approved_json_precedence"] = {
            "direction": direction,
            "transaction_code": tx_code,
            "note": "Approved HIP JSON values were preserved over new-configuration UI defaults.",
        }

    # Before UI-selected interfaces/names are applied, compare every explicit
    # operator selection with deterministic customer-file/manual evidence. Any
    # disagreement becomes a side-by-side human decision gate; no silent winner.
    canonical = detect_user_selection_conflicts(canonical, settings)

    # For approved JSON, preserve the transport interface already present in the
    # file.  A fresh React card defaults to SFTP, but that default must never
    # rewrite an approved HTTPS/AS2/FTP customer configuration.
    if authoritative_input is not None:
        source_interface = _approved_interface_key(workspace, canonical, "source", source_interface)
        target_interface = _approved_interface_key(workspace, canonical, "target", target_interface)
    canonical = apply_selected_interfaces(
        workspace, canonical, source_interface, target_interface,
        preserve_existing=authoritative_input is not None,
    )
    if user_instructions:
        canonical, request_audit = apply_user_request_hints(
            workspace, canonical, user_instructions, use_aia=use_dell_aia
        )
        canonical.setdefault("_builder_audit", {})["user_request"] = request_audit
    canonical = enrich_provable_values(workspace, canonical, source_interface, target_interface)
    canonical = force_hip_automation(canonical)
    canonical = apply_input_extraction_blueprint(
        canonical, source_interface=source_interface, target_interface=target_interface,
        manifest=[p.name for p in raw_paths], workspace=workspace,
    )
    save_input_json(canonical, workspace / "input.json")
    questions = merge_blueprint_questions(
        canonical, unresolved_questions(workspace, canonical, source_interface, target_interface),
        source_interface=source_interface, target_interface=target_interface,
    )
    return {
        "input": canonical,
        "questions": questions,
        "ready_for_api_mapping": len(questions) == 0,
        "deployment_group": DEFAULT_DEPLOYMENT_GROUP,
        "uploaded_files": [p.name for p in raw_paths],
        "authoritative_json": authoritative_path.name if authoritative_path else "",
        "effective_source_interface": source_interface,
        "effective_target_interface": target_interface,
    }


def apply_configuration_answers(workspace: Path, settings: Dict[str, Any], answers: Dict[str, Any]) -> Dict[str, Any]:
    workspace = Path(workspace)
    canonical = json.loads((workspace / "input.json").read_text(encoding="utf-8"))
    source_interface = str(settings.get("source_interface") or "SFTP")
    target_interface = str(settings.get("target_interface") or source_interface)
    # Continue using the interface already present in the built input.json; the
    # answer step must not regress to stale/default UI interface values.
    source_interface = _approved_interface_key(workspace, canonical, "source", source_interface)
    target_interface = _approved_interface_key(workspace, canonical, "target", target_interface)
    questions = merge_blueprint_questions(
        canonical, unresolved_questions(workspace, canonical, source_interface, target_interface),
        source_interface=source_interface, target_interface=target_interface,
    )
    updated, changed = apply_answers(
        workspace, canonical, questions, answers, source_interface, target_interface
    )
    # A conflict decision may itself change source/target interface. Re-resolve
    # the effective registry keys immediately so enrichment, required-field
    # questions and the extraction blueprint never run with the stale UI value.
    effective_source = _approved_interface_key(workspace, updated, "source", source_interface)
    effective_target = _approved_interface_key(workspace, updated, "target", target_interface)
    updated = enrich_provable_values(workspace, updated, effective_source, effective_target)
    updated = force_hip_automation(updated)
    updated = apply_input_extraction_blueprint(
        updated, source_interface=effective_source, target_interface=effective_target, manifest=[], workspace=workspace,
    )
    save_input_json(updated, workspace / "input.json")
    remaining = merge_blueprint_questions(
        updated, unresolved_questions(workspace, updated, effective_source, effective_target),
        source_interface=effective_source, target_interface=effective_target,
    )
    effective_source = _approved_interface_key(workspace, updated, "source", effective_source)
    effective_target = _approved_interface_key(workspace, updated, "target", effective_target)
    return {"input": updated, "questions": remaining, "changed": changed, "ready_for_api_mapping": len(remaining) == 0,
            "effective_source_interface": effective_source, "effective_target_interface": effective_target}


def refresh_input_extraction_blueprint(workspace: Path, canonical: Dict[str, Any], settings: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Re-run blueprint provenance after any canonical mutation (answers/repairs)."""
    workspace = Path(workspace)
    settings = settings or {}
    src = _approved_interface_key(workspace, canonical, "source", str(settings.get("source_interface") or "SFTP"))
    tgt = _approved_interface_key(workspace, canonical, "target", str(settings.get("target_interface") or src))
    input_files = workspace / "input_files"
    manifest = sorted(p.name for p in input_files.rglob("*") if p.is_file()) if input_files.exists() else []
    updated = apply_input_extraction_blueprint(canonical, source_interface=src, target_interface=tgt, manifest=manifest, workspace=workspace)
    save_input_json(updated, workspace / "input.json")
    return updated


def worker_command(workspace: Path, mode: str, extra: List[str] | None = None) -> List[str]:
    worker = Path(__file__).resolve().parent / "legacy_worker.py"
    return [sys.executable, "-u", str(worker), mode, str(Path(workspace).resolve()), *(extra or [])]


def _utf8_worker_env(workspace: Path) -> Dict[str, str]:
    """Force deterministic UTF-8 I/O for Windows child processes.

    Payloads and reports legitimately contain Unicode punctuation/customer text.
    Without PYTHONUTF8/PYTHONIOENCODING, Windows can fall back to a legacy
    charmap and crash preflight before any HIP API call.
    """
    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(Path(workspace).resolve())
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def parse_worker_json_output(text: str, *, label: str = "worker") -> Dict[str, Any]:
    """Extract the authoritative JSON object from a noisy child-process stdout stream.

    Managed Windows hosts can emit benign diagnostics/warnings to stdout before the
    worker's JSON result (for example evidence-persistence or MCP fallback messages).
    Machine-readable Studio endpoints must not fail just because stdout contains such
    non-JSON lines.  We therefore prefer a full JSON parse and otherwise scan for the
    largest complete JSON object in the stream.  Historical/package data is never used;
    this only parses the current subprocess response.
    """
    raw = str(text or "").replace("\x00", "").lstrip("\ufeff").strip()
    raw = _ANSI_ESCAPE_RE.sub("", raw)
    if not raw:
        raise RuntimeError(f"{label} returned no JSON result")
    try:
        value = json.loads(raw)
        if isinstance(value, dict):
            return value
    except Exception:
        pass

    decoder = json.JSONDecoder()
    candidates: List[Tuple[int, int, int, Dict[str, Any]]] = []
    for start, char in enumerate(raw):
        if char != "{":
            continue
        try:
            value, consumed = decoder.raw_decode(raw[start:])
        except Exception:
            continue
        if isinstance(value, dict):
            # Prefer the largest complete object; absolute end breaks ties in favour
            # of the later authoritative result rather than an earlier log fragment.
            candidates.append((consumed, start + consumed, start, value))
    if candidates:
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        return candidates[0][3]
    tail = raw[-2000:]
    raise RuntimeError(f"Could not parse {label} JSON output; output={tail}")


def preview_api_requests(workspace: Path) -> Dict[str, Any]:
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        worker_command(workspace, "preview"),
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "API preview worker failed")
    return parse_worker_json_output(proc.stdout, label="API preview worker")


def preview_migration_requests(workspace: Path) -> Dict[str, Any]:
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        worker_command(workspace, "migration_preview"),
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "Migration API preview worker failed")
    return parse_worker_json_output(proc.stdout, label="Migration API preview worker")


def preview_all_api_requests(workspace: Path) -> Dict[str, Any]:
    base = preview_api_requests(workspace)
    migration = preview_migration_requests(workspace)
    return {"items": list(base.get("items") or []) + list(migration.get("items") or []), "configurationItems": list(base.get("items") or []), "migrationItems": list(migration.get("items") or [])}


def preflight_flow_requests(workspace: Path, graph: Dict[str, Any]) -> Dict[str, Any]:
    workspace = Path(workspace)
    graph_path = workspace / "react_flow_preflight.json"
    graph_path.write_text(json.dumps(graph, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        worker_command(workspace, "flow_preflight", [str(graph_path)]),
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "Flow preflight worker failed")
    return parse_worker_json_output(proc.stdout, label="Flow preflight worker")


def connection_readiness(workspace: Path) -> Dict[str, Any]:
    """Run the existing secure-connection/readiness diagnostic for one workspace.

    This is intentionally non-mutating with respect to HIP business objects. The
    diagnostic may obtain OAuth tokens and call connectivity/health endpoints.
    """
    workspace = Path(workspace).resolve()
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        [sys.executable, str(LEGACY_ROOT / "connection_check.py")],
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=240,
    )
    text = (proc.stdout or "").strip()
    if not text:
        raise RuntimeError(proc.stderr or "Connection readiness check returned no result")
    return parse_worker_json_output(text, label="connection readiness result")


def production_preflight(workspace: Path) -> Dict[str, Any]:
    """Run the existing non-mutating production readiness gate for one workspace."""
    workspace = Path(workspace).resolve()
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        [os.environ.get("PYTHON", sys.executable), "-u", str(LEGACY_ROOT / "run_agent.py"), "--preflight"],
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
    )
    raw = str(proc.stdout or "").strip()
    if not raw:
        raise RuntimeError(proc.stderr or "Production preflight returned no result")
    result = parse_worker_json_output(raw, label="production preflight")
    if proc.returncode != 0 and not result.get("ready"):
        return result
    return result


def api_test_request(workspace: Path, step_key: str, *, request_override: Dict[str, Any] | None = None,
                     override_mode: str = "merge", execute: bool = False) -> Dict[str, Any]:
    """Preflight or LIVE-execute exactly one HIP API block in an isolated worker."""
    workspace = Path(workspace).resolve()
    assert_no_request_override(request_override or {}, context="API Testing worker request")
    spec = {
        "step_key": str(step_key),
        "request_override": {},
        "override_mode": "merge",
        "execute": bool(execute),
    }
    request_file = workspace / "react_api_test_request.json"
    request_file.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    env = _utf8_worker_env(workspace)
    proc = subprocess.run(
        worker_command(workspace, "api_test", [str(request_file)]),
        cwd=str(LEGACY_ROOT), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
    )
    lines = [line.strip() for line in (proc.stdout or "").splitlines() if line.strip()]
    if not lines:
        raise RuntimeError(proc.stderr or "API Testing worker returned no result")
    try:
        result = json.loads(lines[-1])
    except Exception as exc:
        raise RuntimeError(f"Could not parse API Testing result: {exc}; output={(proc.stdout or '')[-2000:]}")
    if proc.returncode != 0 and not result:
        raise RuntimeError(proc.stderr or "API Testing worker failed")
    return result



def _canonical_fix_path(step_key: str, field: str) -> str:
    key = str(step_key or "")
    fld = str(field or "")
    mapping = {
        ("account_source", "accountName"): "objects.source_transport_profile.existing_account_name",
        ("account_target", "accountName"): "objects.target_transport_profile.existing_account_name",
        ("partner_target", "header.x-account-name"): "objects.source_transport_profile.existing_account_name",
        ("partner_target", "partnerIdentifierValue"): "partner_identifier_value",
        ("partner_target", "name"): "objects.target_transport_profile.partner_name",
        ("system_source", "systemName"): "objects.source_transport_profile.partner_name",
        ("doctype_source", "name"): "objects.source_document_type.name",
        ("doctype_target", "name"): "objects.target_document_type.name",
        ("map", "mapName"): "objects.data_map.map_name",
        ("map", "mapIdentifier"): "objects.data_map.map_identifier",
        ("map", "mapClassName"): "objects.data_map.map_class",
        ("map", "contivoVersion"): "objects.data_map.contivo_version",
        ("map", "mapFileName"): "objects.data_map.map_data_file",
        ("rule", "name"): "objects.rule.name",
        ("flow_create", "flowName"): "profile_name",
    }
    return mapping.get((key, fld), "")


def _canonical_set(canonical: Dict[str, Any], dotted_path: str, value: Any) -> None:
    parts = [p for p in str(dotted_path or "").split(".") if p]
    if not parts:
        raise ValueError("Canonical repair path is empty.")
    node: Any = canonical
    for i, part in enumerate(parts):
        last = i == len(parts) - 1
        if last:
            if not isinstance(node, dict):
                raise ValueError(f"Could not update canonical path {dotted_path}.")
            node[part] = value
            return
        if not isinstance(node, dict):
            raise ValueError(f"Could not update canonical path {dotted_path}.")
        child = node.get(part)
        if isinstance(child, list):
            # Canonical transport/document objects may be list-shaped for
            # multi-branch configurations. Update the first active dictionary
            # instead of replacing the branch list.
            target = next((x for x in child if isinstance(x, dict)), None)
            if target is None:
                target = {}
                child.append(target)
            node = target
        else:
            if not isinstance(child, dict):
                child = {}
                node[part] = child
            node = child

def _request_patch_set(root: Dict[str, Any], dotted_path: str, value: Any) -> Dict[str, Any]:
    """Set one dotted request path on an object/list tree."""
    parts = [part for part in str(dotted_path or "").split(".") if part != ""]
    if not parts:
        raise ValueError("A concrete request field is required.")
    node: Any = root
    for index, part in enumerate(parts):
        last = index == len(parts) - 1
        next_part = parts[index + 1] if not last else ""
        numeric = part.isdigit()
        if isinstance(node, list):
            if not numeric:
                raise ValueError(f"Expected an array index in field path '{dotted_path}'.")
            pos = int(part)
            while len(node) <= pos:
                node.append({} if not next_part.isdigit() else [])
            if last:
                node[pos] = value
            else:
                if not isinstance(node[pos], (dict, list)):
                    node[pos] = [] if next_part.isdigit() else {}
                node = node[pos]
            continue
        if numeric:
            raise ValueError(f"Array index '{part}' cannot follow an object directly in '{dotted_path}'.")
        if last:
            node[part] = value
        else:
            expected: Any = [] if next_part.isdigit() else {}
            current = node.get(part) if isinstance(node, dict) else None
            if not isinstance(current, (dict, list)):
                node[part] = expected
            node = node[part]
    return root


def _preview_field_value(value: Any, dotted_path: str) -> Any:
    node = value
    for part in [p for p in str(dotted_path or "").split(".") if p != ""]:
        if isinstance(node, dict):
            node = node.get(part)
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return None
    return node


def _coerce_inline_value(raw: Any, current: Any) -> Any:
    """Preserve JSON/scalar types when the inline UI sends text."""
    if not isinstance(raw, str):
        return raw
    text = raw.strip()
    if isinstance(current, bool):
        if text.lower() in {"true", "1", "yes", "on"}:
            return True
        if text.lower() in {"false", "0", "no", "off"}:
            return False
    if isinstance(current, int) and not isinstance(current, bool):
        try:
            return int(text)
        except Exception:
            pass
    if isinstance(current, float):
        try:
            return float(text)
        except Exception:
            pass
    if isinstance(current, (dict, list)) or (text[:1] in {"{", "["} and text[-1:] in {"}", "]"}):
        try:
            return json.loads(text)
        except Exception:
            if isinstance(current, (dict, list)):
                raise ValueError("Enter valid JSON for this object/array field.")
    return raw


def apply_inline_validation_fixes(workspace: Path, fixes: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Persist user-approved contract corrections without leaving Build Configuration.

    Corrections are request-content overrides only; method, URL and protected
    headers remain agent controlled. The exact corrected value is revalidated and
    is then reused by LIVE execution.
    """
    workspace = Path(workspace).resolve()
    preview = preview_api_requests(workspace)
    rows = {str(item.get("stepKey") or ""): item for item in (preview.get("items") or []) if isinstance(item, dict)}
    store = PayloadOverrideStore(workspace)
    if store.errors:
        raise ValueError("Existing request overrides are invalid: " + "; ".join(store.errors))
    applied: List[Dict[str, Any]] = []
    repairs: Dict[str, Any] = {}
    input_path = workspace / "input.json"
    canonical = json.loads(input_path.read_text(encoding="utf-8")) if input_path.exists() else {}
    if isinstance(canonical, dict) and isinstance(canonical.get("_contract_repairs"), dict):
        repairs = deepcopy(canonical.get("_contract_repairs") or {})

    protected_prefixes = ("header.", "headers.")
    protected_fields = {"method", "url", "request"}
    for fix in fixes:
        step_key = str(fix.get("step_key") or fix.get("stepKey") or "").strip()
        field = str(fix.get("field") or "").strip()
        if not step_key or not field:
            raise ValueError("Each inline fix requires step_key and field.")
        canonical_path = _canonical_fix_path(step_key, field)
        if (field in protected_fields or field.lower().startswith(protected_prefixes)) and not canonical_path:
            raise ValueError(f"{field} is agent-managed and cannot be overridden inline.")
        if canonical_path:
            current_for_type: Any = None
            # Header/account fixes are user-facing business configuration values,
            # so update canonical input.json rather than hiding the correction in
            # an API-only override. This also updates the generated template.
            if field.lower().startswith("header."):
                header_name = field.split(".", 1)[1]
                current_for_type = (rows.get(step_key) or {}).get("extraHeaders", {}).get(header_name)
            else:
                row0 = rows.get(step_key) or {}
                kind0 = str(row0.get("requestKind") or ("params" if row0.get("params") is not None else "payload"))
                current_for_type = _preview_field_value(row0.get(kind0) or {}, field)
            value = _coerce_inline_value(fix.get("value"), current_for_type)
            _canonical_set(canonical, canonical_path, value)
            if canonical_path.endswith("source_transport_profile.existing_account_name"):
                ov_path = workspace / "config_overrides.json"
                try:
                    ov = json.loads(ov_path.read_text(encoding="utf-8")) if ov_path.exists() else {}
                except Exception:
                    ov = {}
                if not isinstance(ov, dict):
                    ov = {}
                ov["source_haft_account"] = value
                ov["x_account_name"] = value
                ov_path.write_text(json.dumps(ov, indent=2, ensure_ascii=False), encoding="utf-8")
            elif canonical_path.endswith("target_transport_profile.existing_account_name"):
                ov_path = workspace / "config_overrides.json"
                try:
                    ov = json.loads(ov_path.read_text(encoding="utf-8")) if ov_path.exists() else {}
                except Exception:
                    ov = {}
                if not isinstance(ov, dict):
                    ov = {}
                ov["target_haft_account"] = value
                ov_path.write_text(json.dumps(ov, indent=2, ensure_ascii=False), encoding="utf-8")
            repairs.setdefault(step_key, {"canonical": {}})
            repairs[step_key].setdefault("canonical", {})[field] = {"path": canonical_path, "value": value}
            applied.append({"stepKey": step_key, "field": field, "canonicalPath": canonical_path, "value": value})
            continue
        row = rows.get(step_key)
        if not row:
            raise ValueError(f"Unknown API step: {step_key}")
        if row.get("applicable") is False:
            raise ValueError(f"{step_key} is not applicable to this configuration.")
        request_kind = str(row.get("requestKind") or ("params" if row.get("params") is not None else "payload"))
        current_request = row.get(request_kind) or {}
        current_value = _preview_field_value(current_request, field)
        value = _coerce_inline_value(fix.get("value"), current_value)

        existing = store.get(step_key) or {}
        existing_kind = str(existing.get("requestKind") or request_kind)
        if existing_kind != request_kind:
            raise ValueError(f"Existing override for {step_key} edits {existing_kind}; cannot mix it with {request_kind}.")
        # Deep-merge is safest for ordinary object fields because generated runtime
        # values continue to flow through. Lists are replacement units in the
        # override engine, so array-index repairs preserve the whole effective
        # request and use replace mode to avoid deleting sibling rows.
        has_array_index = any(part.isdigit() for part in field.split("."))
        if has_array_index:
            patch_value = deepcopy(current_request)
            mode = "replace"
        else:
            patch_value = deepcopy(existing.get("value") or {})
            mode = str(existing.get("mode") or "merge")
        _request_patch_set(patch_value, field, value)
        save_override(
            workspace, step_key, patch_value, request_kind=request_kind, mode=mode,
            note="Human user-approved inline fix from Build Configuration validation", enabled=True, edit_origin="USER",
        )
        store = PayloadOverrideStore(workspace)
        repairs.setdefault(step_key, {"requestKind": request_kind, "mode": mode, "value": {}})
        repairs[step_key]["requestKind"] = request_kind
        repairs[step_key]["mode"] = mode
        repairs[step_key]["value"] = deepcopy(patch_value)
        applied.append({"stepKey": step_key, "field": field, "requestKind": request_kind, "value": value})

    if isinstance(canonical, dict) and input_path.exists():
        canonical["_contract_repairs"] = repairs
        save_input_json(canonical, input_path)
    return {"applied": applied, "count": len(applied), "repairs": repairs, "overrideSummary": PayloadOverrideStore(workspace).summary()}


def attach_inline_validation_repairs(workspace: Path, validation: Dict[str, Any]) -> Dict[str, Any]:
    """Add same-screen repair prompts to blocked contract rows."""
    result = deepcopy(validation or {})
    blocked = list(((result.get("requests") or {}).get("blockedItems") or []))
    if not blocked:
        return result
    try:
        preview = preview_api_requests(workspace)
        rows = {str(item.get("stepKey") or ""): item for item in (preview.get("items") or []) if isinstance(item, dict)}
    except Exception:
        rows = {}
    for item in blocked:
        step_key = str(item.get("stepKey") or "")
        row = rows.get(step_key) or {}
        request_kind = str(row.get("requestKind") or ("params" if row.get("params") is not None else "payload"))
        request_value = row.get(request_kind) or {}
        questions: List[Dict[str, Any]] = []
        seen: set[str] = set()
        for err in item.get("errors") or []:
            if not isinstance(err, dict):
                continue
            field = str(err.get("field") or "").strip()
            if not field or field in seen:
                continue
            seen.add(field)
            canonical_path = _canonical_fix_path(step_key, field)
            protected = (field in {"method", "url", "request"} or field.lower().startswith(("header.", "headers."))) and not canonical_path
            if field.lower().startswith("header."):
                header_name = field.split(".", 1)[1]
                current = (row.get("extraHeaders") or {}).get(header_name)
            else:
                current = _preview_field_value(request_value, field)
            if isinstance(current, (dict, list)):
                current_display: Any = json.dumps(current, ensure_ascii=False, indent=2)
                input_type = "json"
            elif isinstance(current, bool):
                current_display = "true" if current else "false"
                input_type = "boolean"
            elif isinstance(current, (int, float)):
                current_display = str(current)
                input_type = "number"
            else:
                current_display = "" if current is None else str(current)
                input_type = "text"
            questions.append({
                "id": f"{step_key}::{field}",
                "stepKey": step_key,
                "field": field,
                "label": f"Change {field}",
                "message": str(err.get("message") or "Correct this request value."),
                "currentValue": current_display,
                "requestKind": request_kind,
                "inputType": input_type,
                "editable": not protected,
                "canonicalPath": canonical_path,
                "why": ("This is controlled by the agent/request transport and cannot be manually overridden here."
                        if protected else ("Enter the correct business value here; the agent will update input.json/template, regenerate the request, and revalidate immediately."
                                           if canonical_path else "Enter the correct value here; the agent will persist it, regenerate the request, and revalidate immediately.")),
            })
        item["repairQuestions"] = questions
    (result.setdefault("requests", {}))["blockedItems"] = blocked
    # Keep items synchronized so any consumer using requests.items sees the same prompts.
    by_key = {str(x.get("stepKey") or ""): x for x in blocked}
    result["requests"]["items"] = [by_key.get(str(x.get("stepKey") or ""), x) for x in (result["requests"].get("items") or [])]
    return result
