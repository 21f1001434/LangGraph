from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator

Direction = Literal["Inbound", "Outbound"]
FlowType = Literal["Auto", "Translation", "Passthrough"]
InputMode = Literal["files", "cm_files", "input_files"]


class ConfigurationCreate(BaseModel):
    name: str = "New HIP Configuration"
    customer: str = ""
    direction: Direction = "Outbound"
    transaction_code: str = "850"
    transaction_name: str = ""
    flow_type: FlowType = "Auto"
    source_interface: str = "SFTP"
    target_interface: str = "SFTP"
    input_mode: InputMode = "files"
    user_instructions: str = ""
    user_selected_fields: List[str] = Field(default_factory=list)

    @field_validator("transaction_code")
    @classmethod
    def normalize_tx(cls, value: str) -> str:
        return str(value or "").strip().upper()


class ConfigurationPatch(BaseModel):
    name: Optional[str] = None
    customer: Optional[str] = None
    direction: Optional[Direction] = None
    transaction_code: Optional[str] = None
    transaction_name: Optional[str] = None
    flow_type: Optional[FlowType] = None
    source_interface: Optional[str] = None
    target_interface: Optional[str] = None
    input_mode: Optional[InputMode] = None
    user_instructions: Optional[str] = None
    user_selected_fields: Optional[List[str]] = None


class AnswerPayload(BaseModel):
    answers: Dict[str, Any] = Field(default_factory=dict)


class ValidationFixItem(BaseModel):
    step_key: str
    field: str
    value: Any


class ValidationFixPayload(BaseModel):
    fixes: List[ValidationFixItem] = Field(default_factory=list)


class FlowNode(BaseModel):
    id: str
    api_key: str
    label: str = ""
    x: float = 0
    y: float = 0
    enabled: bool = True
    stop_on_blocked: bool = True
    wait_after_seconds: float = 0
    override_mode: Literal["merge", "replace"] = "merge"
    request_override: Dict[str, Any] = Field(default_factory=dict)
    approval_required: bool = False
    approval_message: str = ""


class FlowEdge(BaseModel):
    id: str
    source: str
    target: str
    label: str = ""
    mappings: List[Dict[str, str]] = Field(default_factory=list)


class FlowDefinition(BaseModel):
    id: str = ""
    name: str = "Untitled Flow"
    direction: Direction = "Outbound"
    transaction_code: str = "850"
    flow_type: FlowType = "Auto"
    nodes: List[FlowNode] = Field(default_factory=list)
    edges: List[FlowEdge] = Field(default_factory=list)
    template_id: str = ""


class FlowNodeAction(BaseModel):
    flow: FlowDefinition
    confirm_live: bool = False


class TemplateCreate(BaseModel):
    name: str
    description: str = ""
    direction: Direction = "Outbound"
    transaction_code: str = "850"
    flow_type: FlowType = "Auto"
    nodes: List[FlowNode] = Field(default_factory=list)
    edges: List[FlowEdge] = Field(default_factory=list)
    variables: List[str] = Field(default_factory=list)
    default_values: Dict[str, Any] = Field(default_factory=dict)
    source_configuration_id: str = ""
    tags: List[str] = Field(default_factory=list)


class ExecutionStart(BaseModel):
    configuration_id: str
    flow: FlowDefinition
    confirm_live: bool = False
    resume_execution_id: str = ""


class ExecutionResume(BaseModel):
    confirm_live: bool = False


class NodeApproval(BaseModel):
    approved_by: str = "User"
    note: str = ""

class ParallelQueueCreate(BaseModel):
    configuration_id: str
    label: str = ""


class ParallelSourcesQueueCreate(BaseModel):
    source_ids: List[str] = Field(default_factory=list)


class ParallelQueueDeleteMany(BaseModel):
    job_ids: List[str] = Field(default_factory=list)


class UhalDemoCreate(BaseModel):
    configuration_id: str
    count: int = Field(default=3, ge=2, le=8)


class ParallelBatchStart(BaseModel):
    job_ids: List[str] = Field(default_factory=list)
    # V92: each worker is a fresh AutoGen AgentChat 0.7.5 AssistantAgent. 1-4 concurrent agents are the
    # validated stable envelope; requests above four are safely wave-capped by
    # the backend so older clients cannot trigger the observed HTTP 429 at 5.
    workers: int = Field(default=4, ge=1, le=50)
    confirm_live: bool = False


class PipelineCreate(BaseModel):
    name: str = ""
    source_ids: List[str] = Field(default_factory=list)


class PipelineRun(BaseModel):
    confirm_live: bool = False


class LearnAskPayload(BaseModel):
    question: str


class MappingTeachPayload(BaseModel):
    configuration_id: str

class CloneRequest(BaseModel):
    name: str = ""


class TemplateLifecycleRequest(BaseModel):
    note: str = ""

class ApiTestRequest(BaseModel):
    request_override: Dict[str, Any] = Field(default_factory=dict)
    override_mode: Literal["merge", "replace"] = "merge"
    confirm_live: bool = False


class PayloadOverrideSave(BaseModel):
    value: Dict[str, Any] = Field(default_factory=dict)
    request_kind: Literal["payload", "params"] = "payload"
    mode: Literal["merge", "replace", "paths"] = "paths"
    note: str = "Edited from React API Testing Area"

class ExecutionFlowStepSave(BaseModel):
    stepKey: str
    order: int = Field(ge=1, le=200)
    waitAfterSeconds: float = Field(default=0.0, ge=0.0, le=3600.0)
    operationMode: Literal["inherit", "create", "edit"] = "inherit"


class ApiOperationModeSave(BaseModel):
    mode: Literal["inherit", "create", "edit"]
    source: Literal["agent", "user"] = "agent"


class ExecutionFlowSave(BaseModel):
    migrationEnabled: bool = False
    steps: List[ExecutionFlowStepSave] = Field(default_factory=list)
