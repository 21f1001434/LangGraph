from __future__ import annotations

import asyncio
import json
import os
import subprocess
import threading
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from .legacy_adapter import LEGACY_ROOT, worker_command
from .report_renderer import write_react_execution_reports


def _utf8_env(workspace: Path) -> Dict[str, str]:
    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(Path(workspace).resolve())
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


class ExecutionManager:
    def __init__(self, store):
        self.store = store
        self._queues: Dict[str, List[asyncio.Queue]] = defaultdict(list)
        self._lock = threading.RLock()
        self._processes: Dict[str, subprocess.Popen] = {}

    @staticmethod
    def topological_order(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> List[str]:
        ids = [str(n.get("id")) for n in nodes if n.get("id")]
        indegree = {node_id: 0 for node_id in ids}
        outgoing: Dict[str, List[str]] = {node_id: [] for node_id in ids}
        for edge in edges:
            source, target = str(edge.get("source") or ""), str(edge.get("target") or "")
            if source not in indegree or target not in indegree:
                raise ValueError(f"Edge references an unknown node: {source} -> {target}")
            outgoing[source].append(target)
            indegree[target] += 1
        queue = [node_id for node_id in ids if indegree[node_id] == 0]
        ordered: List[str] = []
        while queue:
            current = queue.pop(0)
            ordered.append(current)
            for target in outgoing[current]:
                indegree[target] -= 1
                if indegree[target] == 0:
                    queue.append(target)
        if len(ordered) != len(ids):
            raise ValueError("The API Flow contains a cycle. Remove the loop before execution.")
        return ordered

    async def subscribe(self, execution_id: str) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue()
        self._queues[execution_id].append(queue)
        existing = self.store.get_execution(execution_id)
        for event in existing.get("events", []) if existing else []:
            await queue.put(event)
        return queue

    def unsubscribe(self, execution_id: str, queue: asyncio.Queue) -> None:
        try:
            self._queues[execution_id].remove(queue)
        except Exception:
            pass

    def _publish(self, execution_id: str, event: Dict[str, Any], loop: asyncio.AbstractEventLoop) -> None:
        with self._lock:
            record = self.store.get_execution(execution_id) or {"id": execution_id, "events": []}
            record.setdefault("events", []).append(event)
            record["updated_at"] = datetime.now(timezone.utc).isoformat()
            event_type = str(event.get("type") or "")
            if event_type == "execution.started":
                record["status"] = "RUNNING"
                record["started_at"] = record.get("started_at") or record["updated_at"]
            elif event_type == "execution.completed":
                record["status"] = str(event.get("status") or "COMPLETED")
                record["elapsedMs"] = event.get("elapsedMs")
                record["finished_at"] = record["updated_at"]
            elif event_type == "execution.blocked":
                record["status"] = "BLOCKED"
            elif event_type == "execution.error":
                record["status"] = "ERROR"
                record["finished_at"] = record["updated_at"]
            elif event_type == "execution.cancelled":
                record["status"] = "CANCELLED"
                record["finished_at"] = record["updated_at"]
            elif event_type == "node.awaiting_approval":
                record["status"] = "WAITING_APPROVAL"
            elif event_type == "node.approval_received":
                record["status"] = "RUNNING"
            self.store.save_execution(execution_id, record)
            if event_type in {"execution.completed", "execution.error", "execution.cancelled"}:
                try:
                    config = self.store.get_configuration(str(record.get("configuration_id") or ""))
                    reports = Path(config["workspace"]) / "reports"
                    reports.mkdir(parents=True, exist_ok=True)
                    payload = json.dumps(record, indent=2, ensure_ascii=False, default=str)
                    (reports / f"react_flow_execution_{execution_id}.json").write_text(payload, encoding="utf-8")
                    (reports / "react_flow_execution_latest.json").write_text(payload, encoding="utf-8")
                    # V50: always keep the user-facing final HTML evidence beside JSON.
                    write_react_execution_reports(record, config)
                except Exception:
                    pass
        for queue in list(self._queues.get(execution_id, [])):
            asyncio.run_coroutine_threadsafe(queue.put(event), loop)

    @staticmethod
    def _resume_state(previous: Dict[str, Any]) -> Dict[str, Any]:
        outputs: Dict[str, Any] = {}
        completed: List[str] = []
        for event in previous.get("events", []) or []:
            if event.get("type") != "node.completed":
                continue
            node_id = str(event.get("nodeId") or "")
            verdict = event.get("verdict") or {}
            if node_id and str(verdict.get("verdict") or "").upper() == "PASS":
                outputs[node_id] = event.get("output") or {}
                if node_id not in completed:
                    completed.append(node_id)
        return {"completedNodeIds": completed, "outputs": outputs}

    def start(
        self,
        configuration: Dict[str, Any],
        flow: Dict[str, Any],
        loop: asyncio.AbstractEventLoop,
        resume_from_execution: str = "",
    ) -> Dict[str, Any]:
        execution_id = uuid.uuid4().hex[:14]
        order = self.topological_order(flow.get("nodes") or [], flow.get("edges") or [])
        resume_state: Dict[str, Any] = {"completedNodeIds": [], "outputs": {}}
        if resume_from_execution:
            previous = self.store.get_execution(resume_from_execution)
            if not previous:
                raise ValueError("Resume source execution not found.")
            if str(previous.get("configuration_id") or "") != str(configuration.get("id") or ""):
                raise ValueError("A run can only resume within the same configuration workspace.")
            resume_state = self._resume_state(previous)
        record = {
            "id": execution_id,
            "configuration_id": configuration["id"],
            "status": "QUEUED",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "events": [],
            "flow": flow,
            "resume_from_execution": resume_from_execution,
            "resumed_node_count": len(resume_state.get("completedNodeIds") or []),
        }
        self.store.save_execution(execution_id, record)
        workspace = Path(configuration["workspace"])
        graph_path = workspace / f"react_flow_execution_{execution_id}.json"
        graph_payload = {
            **flow,
            "execution_order": order,
            "execution_id": execution_id,
            "resume_from_execution": resume_from_execution,
            "resume_state": resume_state,
        }
        graph_path.write_text(json.dumps(graph_payload, indent=2), encoding="utf-8")

        def runner() -> None:
            env = _utf8_env(workspace)
            process = subprocess.Popen(
                worker_command(workspace, "execute", [str(graph_path)]),
                cwd=str(LEGACY_ROOT), env=env, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1,
            )
            with self._lock:
                self._processes[execution_id] = process
            self._publish(execution_id, {"type": "execution.process", "pid": process.pid}, loop)
            if process.stdout is not None:
                for raw in process.stdout:
                    text = raw.strip()
                    if not text:
                        continue
                    try:
                        event = json.loads(text)
                    except Exception:
                        event = {"type": "execution.log", "message": text}
                    self._publish(execution_id, event, loop)
            rc = process.wait()
            with self._lock:
                self._processes.pop(execution_id, None)
            current = self.store.get_execution(execution_id) or {}
            if rc != 0 and str(current.get("status") or "") != "CANCELLED":
                self._publish(execution_id, {"type": "execution.error", "returnCode": rc}, loop)
        threading.Thread(target=runner, name=f"hip-exec-{execution_id}", daemon=True).start()
        return record

    def cancel(self, execution_id: str, loop: asyncio.AbstractEventLoop) -> Dict[str, Any]:
        record = self.store.get_execution(execution_id)
        if not record:
            raise ValueError("Execution not found.")
        with self._lock:
            process = self._processes.get(execution_id)
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        self._publish(execution_id, {"type": "execution.cancelled", "reason": "Cancelled by user"}, loop)
        return self.store.get_execution(execution_id)

    def approve_node(self, execution_id: str, node_id: str, approved_by: str = "User", note: str = "") -> Dict[str, Any]:
        record = self.store.get_execution(execution_id)
        if not record:
            raise ValueError("Execution not found.")
        config = self.store.get_configuration(str(record.get("configuration_id") or ""))
        approval_dir = Path(config["workspace"]) / ".runtime_approvals" / execution_id
        approval_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "executionId": execution_id,
            "nodeId": node_id,
            "approvedBy": approved_by or "User",
            "note": note,
            "approvedAt": datetime.now(timezone.utc).isoformat(),
        }
        (approval_dir / f"{node_id}.approved.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return payload

    def compare(self, left_id: str, right_id: str) -> Dict[str, Any]:
        left = self.store.get_execution(left_id)
        right = self.store.get_execution(right_id)
        if not left or not right:
            raise ValueError("Both executions must exist.")

        def node_rows(record: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
            rows: Dict[str, Dict[str, Any]] = {}
            for event in record.get("events", []) or []:
                node_id = str(event.get("nodeId") or "")
                if not node_id:
                    continue
                row = rows.setdefault(node_id, {"nodeId": node_id})
                if event.get("type") == "node.completed":
                    row.update({
                        "status": (event.get("verdict") or {}).get("outcome") or (event.get("verdict") or {}).get("verdict") or "COMPLETED",
                        "timing": event.get("timing") or {},
                        "output": event.get("output") or {},
                    })
                elif event.get("type") in {"node.failed", "node.mapping_blocked"}:
                    row.update({"status": "BLOCKED", "error": event.get("error") or event.get("unresolvedMappings")})
                elif event.get("type") == "node.resumed":
                    row.update({"status": "RESUMED", "output": event.get("output") or {}})
            return rows

        lrows, rrows = node_rows(left), node_rows(right)
        ids = list(dict.fromkeys([*lrows.keys(), *rrows.keys()]))
        nodes = []
        for node_id in ids:
            l, r = lrows.get(node_id, {}), rrows.get(node_id, {})
            lt = int((l.get("timing") or {}).get("totalMs") or 0)
            rt = int((r.get("timing") or {}).get("totalMs") or 0)
            nodes.append({
                "nodeId": node_id,
                "left": l,
                "right": r,
                "statusChanged": l.get("status") != r.get("status"),
                "totalMsDelta": rt - lt,
            })
        return {
            "left": {"id": left_id, "status": left.get("status"), "elapsedMs": left.get("elapsedMs") or 0, "created_at": left.get("created_at")},
            "right": {"id": right_id, "status": right.get("status"), "elapsedMs": right.get("elapsedMs") or 0, "created_at": right.get("created_at")},
            "elapsedMsDelta": int(right.get("elapsedMs") or 0) - int(left.get("elapsedMs") or 0),
            "nodes": nodes,
        }
