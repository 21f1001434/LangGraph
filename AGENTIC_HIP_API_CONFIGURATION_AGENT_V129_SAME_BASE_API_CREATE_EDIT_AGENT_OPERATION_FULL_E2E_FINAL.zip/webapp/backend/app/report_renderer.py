from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List

from production_guard import redact_sensitive
from report_insights import analyze_api_response, format_duration_ms, format_duration_seconds


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _pretty(value: Any) -> str:
    try:
        safe = redact_sensitive(value)
        return html.escape(json.dumps(safe, indent=2, ensure_ascii=False, default=str))
    except Exception:
        return html.escape(str(value))


def _status_class(value: Any) -> str:
    text = str(value or "").upper()
    if text in {"PASS", "READY", "VALIDATED", "SUCCESS"}:
        return "pass"
    if text in {"WARNING", "EXISTING", "PENDING", "NEEDS_VERIFICATION"}:
        return "warning"
    if text in {"FAIL", "FAILED", "ERROR", "API_ERROR"}:
        return "fail"
    if text in {"BLOCKED", "CANCELLED", "NOT_EXECUTED"}:
        return "blocked"
    if text in {"NOT_APPLICABLE", "SKIPPED"}:
        return "skipped"
    return "neutral"


def _overall(counts: Dict[str, int]) -> str:
    if counts.get("FAIL", 0):
        return "FAIL"
    if counts.get("BLOCKED", 0):
        return "BLOCKED"
    if counts.get("WARNING", 0):
        return "WARNING"
    return "PASS"


def _base_css() -> str:
    return """
:root{--ink:#12283b;--muted:#64798a;--line:#d9e4eb;--bg:#f2f6f9;--blue:#0672ce;--green:#137454;--red:#b42318;--amber:#a36708;--slate:#617788}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif}.wrap{max-width:1380px;margin:0 auto;padding:22px}.hero{background:linear-gradient(135deg,#073556,#0672ce);color:#fff;border-radius:18px;padding:22px 25px;box-shadow:0 10px 28px rgba(6,73,126,.16)}.hero h1{margin:4px 0 7px;font-size:25px}.hero p{margin:4px 0;opacity:.92}.badges{display:flex;gap:7px;flex-wrap:wrap;margin-top:12px}.badge{display:inline-flex;align-items:center;border-radius:999px;padding:5px 9px;font-size:10px;font-weight:850;background:#edf3f7;color:#5d7183}.hero .badge{background:rgba(255,255,255,.15);color:#fff}.badge.pass{background:#dff7eb;color:#116a4b}.badge.warning{background:#fff3cf;color:#825500}.badge.fail{background:#ffe3e0;color:#9d251c}.badge.blocked{background:#fce8e8;color:#9e2a2a}.badge.skipped{background:#edf2f5;color:#617788}.badge.neutral{background:#eef3f7;color:#5d7183}.grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:9px;margin:14px 0}.metric,.card,.summary-panel{background:rgba(255,255,255,.86);border:1px solid rgba(217,228,235,.9);border-radius:14px;box-shadow:0 10px 30px rgba(25,52,76,.07);backdrop-filter:blur(16px) saturate(1.08);-webkit-backdrop-filter:blur(16px) saturate(1.08)}.metric{padding:12px}.metric span{display:block;color:var(--muted);font-size:9px;text-transform:uppercase;font-weight:850;letter-spacing:.05em}.metric b{display:block;margin-top:4px;font-size:17px}.section-title{margin:22px 0 9px;font-size:16px}.summary-panel{padding:16px;margin:12px 0;color:#17384d}.summary-panel.pass{background:rgba(239,252,246,.90)}.summary-panel.warning{background:rgba(255,249,232,.92)}.summary-panel.fail,.summary-panel.blocked{background:rgba(255,242,241,.92)}.summary-panel.pass{border-left:5px solid var(--green)}.summary-panel.warning{border-left:5px solid var(--amber)}.summary-panel.fail{border-left:5px solid var(--red)}.summary-panel.blocked{border-left:5px solid var(--red)}.summary-panel h2,.summary-panel h3{margin:0 0 6px}.summary-panel p{margin:4px 0;color:#486173}.result-table{width:100%;border-collapse:separate;border-spacing:0;background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden}.result-table th,.result-table td{border-bottom:1px solid #e7eef3;padding:10px 9px;text-align:left;font-size:10.5px;vertical-align:top}.result-table th{background:#f5f9fb;font-size:8.5px;text-transform:uppercase;color:#657b8d;letter-spacing:.04em;position:sticky;top:0}.result-table tr:last-child td{border-bottom:0}.result-table .reason{max-width:420px;color:#405a6d;line-height:1.45}.result-table .api strong{display:block;font-size:11px}.result-table .api small{display:block;color:var(--muted);margin-top:2px}.details-cell details{margin:5px 0}.details-cell summary,.evidence summary{cursor:pointer;color:var(--blue);font-weight:800}.evidence{margin-top:8px}.evidence-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px}.panel{min-width:0;border:1px solid #e2eaf0;border-radius:11px;background:#f9fbfd;padding:10px}.panel h4{margin:0 0 7px;font-size:10px;color:#536c7f;text-transform:uppercase;letter-spacing:.04em}pre{white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;margin:0;background:#0d1b28;color:#d8edf7;border-radius:8px;padding:10px;max-height:420px;overflow:auto;font:9.5px/1.5 Consolas,ui-monospace,monospace}.attention-list{display:grid;gap:7px}.attention-item{border:1px solid rgba(225,233,239,.92);border-radius:10px;padding:10px;background:rgba(255,255,255,.82);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}.attention-item b{font-size:11px}.attention-item p{font-size:10px;margin:4px 0;color:#51697a}.timeline{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:7px;margin-top:9px}.timeline div{border:1px solid #e1e9ef;border-radius:9px;padding:8px;background:#fbfdff}.timeline span{display:block;color:var(--muted);font-size:8px}.timeline b{font-size:10.5px}.footer{color:var(--muted);font-size:9px;text-align:center;margin:24px 0 5px}.embedded-report{margin-top:10px}.embedded-report summary{cursor:pointer;font-weight:800;color:var(--blue);padding:7px 0}.embedded-report iframe{width:100%;height:720px;border:1px solid #d8e4ec;border-radius:11px;background:#fff}.technical{margin-top:12px}.technical>summary{cursor:pointer;color:var(--blue);font-weight:850;padding:8px 0}.card{padding:14px;margin:9px 0}.card.pass{border-left:5px solid var(--green)}.card.warning{border-left:5px solid var(--amber)}.card.fail,.card.blocked{border-left:5px solid var(--red)}.card.skipped,.card.neutral{border-left:5px solid #8397a6}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.card-head h3{margin:0;font-size:14px}.card-head small{display:block;color:var(--muted);margin-top:3px}.compact-note{font-size:10px;color:var(--muted)}@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.evidence-grid{grid-template-columns:1fr}.wrap{padding:11px}.result-table{display:block;overflow:auto}}
"""


def _step_rows(record: Dict[str, Any]) -> tuple[Dict[str, Dict[str, Any]], Dict[str, Any]]:
    clean = redact_sensitive(record)
    flow = clean.get("flow") or {}
    nodes = flow.get("nodes") or []
    node_map = {str(n.get("id") or ""): dict(n) for n in nodes if n.get("id")}
    order = list(flow.get("execution_order") or [str(n.get("id") or "") for n in nodes])
    steps: Dict[str, Dict[str, Any]] = {node_id: {"node": node_map.get(node_id, {}), "attempts": []} for node_id in order if node_id}
    for event in list(clean.get("events") or []):
        node_id = str(event.get("nodeId") or "")
        if node_id and node_id not in steps:
            steps[node_id] = {"node": node_map.get(node_id, {}), "attempts": []}
        if not node_id:
            continue
        row = steps[node_id]
        kind = str(event.get("type") or "")
        if kind == "node.request": row["request"] = event.get("request")
        elif kind in {"node.http_attempt", "node.retry"}: row.setdefault("attempts", []).append(event)
        elif kind == "node.completed":
            row["completed"] = event; row["result"] = event.get("result"); row["output"] = event.get("output"); row["timing"] = event.get("timing"); row["verdict"] = event.get("verdict")
        elif kind in {"node.failed", "node.mapping_blocked"}: row["error"] = event
        elif kind == "node.skipped": row["skipped"] = event
        elif kind in {"node.awaiting_approval", "node.approval_received"}: row.setdefault("approvals", []).append(event)
    return steps, flow


def render_react_execution_html(record: Dict[str, Any], configuration: Dict[str, Any]) -> str:
    clean = redact_sensitive(record)
    steps, flow = _step_rows(clean)
    elapsed_seconds = float(clean.get("elapsedMs") or 0) / 1000.0
    customer = configuration.get("customer") or configuration.get("name") or "Customer"
    direction = configuration.get("direction") or ""
    tx = configuration.get("transaction_code") or ""
    execution_id = clean.get("id") or ""

    rendered: List[Dict[str, Any]] = []
    for index, (node_id, row) in enumerate(steps.items(), start=1):
        node = row.get("node") or {}
        label = node.get("label") or node.get("api_key") or node_id
        verdict = row.get("verdict") or {}
        result = row.get("result") or {}
        if row.get("skipped"):
            analysis = {"verdict": "SKIPPED", "outcome": "SKIPPED", "reason": str((row.get("skipped") or {}).get("reason") or "Step was skipped."), "nextAction": "No action required."}
        elif row.get("error") and not result:
            analysis = {"verdict": "BLOCKED", "outcome": "NOT_EXECUTED", "reason": str((row.get("error") or {}).get("error") or (row.get("error") or {}).get("reason") or "Step was blocked before a final API response."), "nextAction": "Resolve the blocker and revalidate before retrying."}
        else:
            analysis = analyze_api_response({**result, "agentVerdict": verdict, "issue": verdict.get("reason"), "action": verdict.get("nextAction"), "error": result.get("error") or (row.get("error") or {}).get("error")})
        rendered.append({"index": index, "nodeId": node_id, "node": node, "label": label, "row": row, "result": result, "verdict": verdict, "analysis": analysis})

    counts = {key: 0 for key in ("PASS", "WARNING", "FAIL", "BLOCKED", "SKIPPED")}
    for item in rendered:
        key = str(item["analysis"].get("verdict") or "WARNING").upper()
        counts[key] = counts.get(key, 0) + 1
    overall = _overall(counts)

    attention = []
    table_rows = []
    for item in rendered:
        row = item["row"]; result = item["result"]; analysis = item["analysis"]; node = item["node"]; verdict = item["verdict"]
        timing = row.get("timing") or {}
        duration = format_duration_ms(timing.get("totalMs") or timing.get("apiMs") or 0)
        http_status = result.get("status_code") or result.get("statusCode") or "—"
        status = str(analysis.get("verdict") or "WARNING")
        if status in {"WARNING", "FAIL", "BLOCKED", "CANCELLED", "SKIPPED"}:
            attention.append(f'<div class="attention-item"><b>{item["index"]}. {_esc(item["label"])} · <span class="badge {_status_class(status)}">{_esc(status)}</span></b><p>{_esc(analysis.get("reason"))}</p><p><b>Next:</b> {_esc(analysis.get("nextAction"))}</p></div>')
        response = {"statusCode": http_status, "classification": result.get("classification"), "response": result.get("response_preview") or result.get("responsePreview"), "error": result.get("error") or (row.get("error") or {}).get("error"), "requestId": result.get("request_id") or result.get("requestId") or result.get("correlation_id") or result.get("correlationId")}
        evidence = f'''<details class="evidence"><summary>Evidence: Effective request · Response / verdict</summary><div class="evidence-grid"><div class="panel"><h4>Effective request</h4><pre>{_pretty(row.get("request") or {})}</pre></div><div class="panel"><h4>Response / verdict</h4><pre>{_pretty({"agentAnalysis": analysis, "runnerVerdict": verdict, "response": response, "output": row.get("output") or {}})}</pre></div></div>{(f'<div class="panel" style="margin-top:8px"><h4>HTTP attempts / retries</h4><pre>{_pretty(row.get("attempts") or [])}</pre></div>' if row.get('attempts') else '')}</details>'''
        table_rows.append(f'''<tr><td>{item["index"]}</td><td class="api"><strong>{_esc(item["label"])}</strong><small>{_esc(node.get("api_key") or item["nodeId"])}</small></td><td>{_esc(http_status)}</td><td><span class="badge {_status_class(status)}">{_esc(status)}</span><br><span class="compact-note">{_esc(analysis.get("outcome"))}</span></td><td>{_esc(duration)}</td><td class="reason">{_esc(analysis.get("reason"))}<div class="details-cell">{evidence}</div></td></tr>''')

    generated = datetime.now(timezone.utc).isoformat()
    summary_reason = "All executed API responses were interpreted as successful." if overall == "PASS" else ("The LIVE run completed with review-only warnings. Each API keeps its own response verdict; no downstream success is used to infer or rewrite another API result." if overall == "WARNING" else "One or more API responses require correction or the run was blocked.")
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HIP Final Execution Report · {_esc(customer)}</title><style>{_base_css()}</style></head><body><div class="wrap">
<div class="hero"><small>Agentic HIP API Configuration Agent · Final LIVE Evidence</small><h1>{_esc(customer)} · {_esc(direction)} {_esc(tx)}</h1><p>Execution <b>{_esc(execution_id)}</b></p><div class="badges"><span class="badge {_status_class(overall)}">Agent verdict: {_esc(overall)}</span><span class="badge">Secrets redacted</span><span class="badge">Generated {_esc(generated)}</span></div></div>
<div class="grid"><div class="metric"><span>API steps</span><b>{len(rendered)}</b></div><div class="metric"><span>PASS</span><b>{counts['PASS']}</b></div><div class="metric"><span>WARNING</span><b>{counts['WARNING']}</b></div><div class="metric"><span>FAIL</span><b>{counts['FAIL']}</b></div><div class="metric"><span>BLOCKED</span><b>{counts['BLOCKED']}</b></div><div class="metric"><span>Elapsed</span><b>{_esc(format_duration_seconds(elapsed_seconds))}</b></div></div>
<section class="summary-panel {_status_class(overall)}"><h2>Agent final assessment · {_esc(overall)}</h2><p>{_esc(summary_reason)}</p><p>The agent reads the final HTTP response, response body, runner classification, business-success flag and available owner/AIA diagnosis; HTTP 2xx alone is not enough to force PASS.</p></section>
{(f'<h2 class="section-title">Needs attention</h2><div class="attention-list">{"".join(attention)}</div>' if attention else '')}
<h2 class="section-title">API result summary</h2><table class="result-table"><thead><tr><th>#</th><th>API</th><th>HTTP</th><th>Agent verdict</th><th>Time</th><th>Agent conclusion</th></tr></thead><tbody>{''.join(table_rows) or '<tr><td colspan="6">No node events were recorded.</td></tr>'}</tbody></table>
<details class="technical"><summary>Technical appendix · execution graph</summary><div class="panel"><pre>{_pretty(flow)}</pre></div></details>
<div class="footer">Generated by Agentic HIP API Configuration Agent · raw requests/responses remain available under expandable evidence; credential/secret values are redacted.</div></div></body></html>'''


def write_react_execution_reports(record: Dict[str, Any], configuration: Dict[str, Any]) -> Dict[str, str]:
    reports = Path(configuration["workspace"]) / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    execution_id = str(record.get("id") or "execution")
    html_text = render_react_execution_html(record, configuration)
    versioned = reports / f"HIP_final_live_execution_{execution_id}.html"
    latest = reports / "HIP_final_live_execution_latest.html"
    versioned.write_text(html_text, encoding="utf-8"); latest.write_text(html_text, encoding="utf-8")
    return {"html": str(versioned), "latest": str(latest)}


def render_parallel_batch_html(summary: Dict[str, Any], job_reports: Iterable[Dict[str, Any]] = ()) -> str:
    clean = redact_sensitive(summary)
    rows = list(clean.get("results") or [])
    report_meta = {str(x.get("jobId") or ""): x for x in job_reports}
    counts = {
        "PASS": int(clean.get("passCount") or sum(1 for r in rows if str(r.get("status")).upper() == "PASS")),
        "WARNING": int(clean.get("warningCount") or sum(1 for r in rows if str(r.get("status")).upper() == "WARNING")),
        "FAIL": int(clean.get("failCount") or sum(1 for r in rows if str(r.get("status")).upper() == "FAIL")),
        "BLOCKED": int(clean.get("blockedCount") or sum(1 for r in rows if str(r.get("status")).upper() == "BLOCKED")),
        "CANCELLED": int(clean.get("cancelledCount") or sum(1 for r in rows if str(r.get("status")).upper() == "CANCELLED")),
        "SKIPPED": int(clean.get("skippedCount") or sum(1 for r in rows if str(r.get("status")).upper() == "SKIPPED")),
    }
    overall = str(clean.get("overallVerdict") or _overall(counts)).upper()
    body: List[str] = []
    attention: List[str] = []
    for row in rows:
        job_id = str(row.get("jobId") or ""); meta = report_meta.get(job_id, {}); status = str(row.get("status") or "UNKNOWN").upper(); timing_rows = row.get("stepTimings") or []
        agent_summary = row.get("agentSummary") or {}; summary_reason = str(agent_summary.get("reason") or row.get("error") or ("Customer execution completed successfully." if status == "PASS" else "Review this customer result."))
        diagnostic = row.get("blockerDiagnostic") or {}
        diag_reason = str(diagnostic.get("reason") or summary_reason) if isinstance(diagnostic, dict) else summary_reason
        if status in {"WARNING", "FAIL", "BLOCKED", "CANCELLED", "SKIPPED"}:
            detail = ""
            if isinstance(diagnostic, dict) and diagnostic:
                detail = f'<p><b>First issue:</b> {_esc(diagnostic.get("api") or diagnostic.get("stage") or "Execution")}' + (f' · HTTP {_esc(diagnostic.get("httpStatus"))}' if diagnostic.get("httpStatus") not in (None, "") else '') + f'</p><p>{_esc(diag_reason)}</p><p><b>Next action:</b> {_esc(diagnostic.get("nextAction") or "Review the detailed evidence before retrying.")}</p>'
            attention.append(f'<div class="attention-item"><b>{_esc(row.get("label") or row.get("customer") or job_id)} · <span class="badge {_status_class(status)}">{_esc(status)}</span></b>{detail or f"<p>{_esc(summary_reason)}</p>"}</div>')
        timing_table = ''.join(f'<tr><td>{_esc(t.get("label") or t.get("stepKey") or "Step")}</td><td>{_esc(format_duration_seconds(t.get("apiElapsedSeconds") or (float(t.get("apiElapsedMs") or 0)/1000.0)))}</td><td>{_esc(format_duration_seconds(t.get("waitSeconds") or 0))}</td><td>{_esc(format_duration_seconds(t.get("totalStepSeconds") or 0))}</td></tr>' for t in timing_rows)
        embedded = str(meta.get("reportHtml") or ""); embedded_panel = ""
        if embedded:
            safe_embedded = html.escape(str(redact_sensitive(embedded)), quote=True)
            embedded_panel = f'<details class="embedded-report"><summary>Open full customer execution report (requests, responses, verdicts)</summary><iframe sandbox="" srcdoc="{safe_embedded}"></iframe></details>'
        diagnostic_panel = ""
        if isinstance(diagnostic, dict) and diagnostic:
            diagnostic_panel = f'''<details class="technical" open><summary>Why this instance did not pass</summary><div class="summary-panel fail"><p><b>First failing API / gate:</b> {_esc(diagnostic.get("api") or diagnostic.get("stage") or "Execution")}</p><p><b>HTTP status:</b> {_esc(diagnostic.get("httpStatus") if diagnostic.get("httpStatus") not in (None, "") else "—")}</p><p><b>Reason:</b> {_esc(diagnostic.get("reason") or summary_reason)}</p><p><b>Next action:</b> {_esc(diagnostic.get("nextAction") or "Review the full API evidence before retrying.")}</p>{(f'<p><b>Request ID:</b> {_esc(diagnostic.get("requestId"))}</p>' if diagnostic.get('requestId') else '')}<details><summary>HIP response / technical evidence</summary><pre>{_pretty(diagnostic.get("hipResponse") or {})}</pre></details></div></details>'''
        body.append(f'''<div class="card {_status_class(status)}"><div class="card-head"><div><h3>{_esc(row.get("label") or row.get("customer") or job_id)}</h3><small>{_esc(row.get("customer"))} · {_esc(row.get("flow"))}</small></div><span class="badge {_status_class(status)}">{_esc(status)}</span></div><p class="compact-note"><b>Agent conclusion:</b> {_esc(summary_reason)}</p><div class="timeline"><div><span>Elapsed</span><b>{_esc(format_duration_seconds(row.get("elapsedSeconds") or 0))}</b></div><div><span>Mode</span><b>{_esc(row.get("executionMode") or clean.get("executionMode") or "LIVE")}</b></div><div><span>Timed steps</span><b>{len(timing_rows)}</b></div><div><span>Return code</span><b>{_esc(row.get("returnCode", "—"))}</b></div></div>{diagnostic_panel}{(f'<details class="technical"><summary>Step timing details</summary><table class="result-table"><thead><tr><th>Step</th><th>API</th><th>Wait</th><th>Total</th></tr></thead><tbody>{timing_table}</tbody></table></details>' if timing_rows else '')}{(f'<div class="summary-panel fail"><b>Error</b><p>{_esc(row.get("error"))}</p></div>' if row.get('error') else '')}{embedded_panel}</div>''')
    elapsed = format_duration_seconds(clean.get("elapsedSeconds") or 0)
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HIP Parallel Final Report</title><style>{_base_css()}</style></head><body><div class="wrap"><div class="hero"><small>HIP API Agent Studio · LIVE Execution Report</small><h1>{_esc(clean.get("batchId"))}</h1><p>{_esc(clean.get("configurationCount"))} customer payload set(s) · {_esc(clean.get("parallelWorkers"))} worker(s) · {_esc(clean.get("executionMode") or "LIVE")} · {_esc(elapsed)}</p><div class="badges"><span class="badge {_status_class(overall)}">Agent verdict: {_esc(overall)}</span><span class="badge">Secrets redacted</span></div></div><div class="grid"><div class="metric"><span>Customers</span><b>{_esc(clean.get("configurationCount",0))}</b></div><div class="metric"><span>PASS</span><b>{counts['PASS']}</b></div><div class="metric"><span>WARNING</span><b>{counts['WARNING']}</b></div><div class="metric"><span>FAIL</span><b>{counts['FAIL']}</b></div><div class="metric"><span>BLOCKED</span><b>{counts['BLOCKED']}</b></div><div class="metric"><span>CANCELLED</span><b>{counts['CANCELLED']}</b></div><div class="metric"><span>SKIPPED</span><b>{counts['SKIPPED']}</b></div><div class="metric"><span>Elapsed</span><b>{_esc(elapsed)}</b></div></div>{(f'<h2 class="section-title">Needs attention</h2><div class="attention-list">{"".join(attention)}</div>' if attention else '')}<h2 class="section-title">Customer results</h2>{''.join(body)}<div class="footer">Generated by Agentic HIP API Configuration Agent · detailed evidence stays collapsed until opened.</div></div></body></html>'''
