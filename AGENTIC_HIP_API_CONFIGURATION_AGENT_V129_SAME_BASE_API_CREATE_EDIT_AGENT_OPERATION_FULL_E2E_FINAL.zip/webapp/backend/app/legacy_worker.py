from __future__ import annotations


import json
import os
import sys
import time
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List

MODE = sys.argv[1] if len(sys.argv) > 1 else ""
WORKSPACE = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else Path.cwd()
os.environ["HIP_WORKSPACE_ROOT"] = str(WORKSPACE)

LEGACY_ROOT = Path(__file__).resolve().parents[3]
if str(LEGACY_ROOT) not in sys.path:
    sys.path.insert(0, str(LEGACY_ROOT))

from api_contract_policy import assert_no_request_override
from api_execution_plan import STEP_DEFINITIONS
from migration_api_contract import MIGRATION_STEP_DEFINITIONS

ALL_TEST_STEP_DEFINITIONS = {**STEP_DEFINITIONS, **MIGRATION_STEP_DEFINITIONS}
from run_agent import Runner
from scratch_flow import agent_response_verdict, component_request, new_component
from production_guard import redact_sensitive
from report_insights import verdict_allows_progress
from runtime_id_state import load_runtime_ids, save_runtime_ids
from webapp.backend.app.flow_engine import apply_edge_mappings


def emit(payload: Dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, default=str), flush=True)



def workspace_runner() -> Runner:
    runner = Runner()
    persisted = load_runtime_ids(WORKSPACE)
    if persisted:
        runner.runtime_state.update(persisted)
    return runner


def persist_runner_runtime(runner: Runner) -> None:
    save_runtime_ids(WORKSPACE, runner.runtime_state)


def preview() -> None:
    runner = workspace_runner()
    rows: List[Dict[str, Any]] = []
    for key in STEP_DEFINITIONS:
        try:
            request = runner.preview_step_request(key)
            rows.append(redact_sensitive(request))
        except Exception as exc:
            rows.append({"stepKey": key, "error": f"{type(exc).__name__}: {exc}", "applicable": False})
    print(json.dumps({"items": rows}, ensure_ascii=False, default=str))




def _migration_preview_readiness(step_key: str, request: Dict[str, Any]) -> tuple[bool, List[str]]:
    body = request.get("payload") if isinstance(request.get("payload"), dict) else request.get("params") if isinstance(request.get("params"), dict) else {}
    errors: List[str] = []
    for field in ("sourceEnvironment", "targetEnvironment"):
        if not str(body.get(field) or "").strip():
            errors.append(f"{field} is required")
    identity_by_step = {
        "migrate_doctype_source": ("documentTypeName", "documentTypeVersion"),
        "migrate_doctype_target": ("documentTypeName", "documentTypeVersion"),
        "migrate_map": ("mapIdentifier", "mapIdentifierVersion"),
        "migrate_rule": ("ruleName", "ruleVersion"),
        "migrate_source_tp": ("transportProfileName", "transportProfileInterfaceType"),
        "migrate_target_tp": ("transportProfileName", "transportProfileInterfaceType"),
        "migrate_flow": ("flowName", "flowVersion"),
    }
    for field in identity_by_step.get(step_key, ()):
        value = body.get(field)
        if value is None or (isinstance(value, str) and not value.strip()):
            errors.append(f"{field} is required")
    if step_key in {"migrate_source_tp", "migrate_target_tp"}:
        params = body.get("transportProfileInterfaceParameters")
        if not isinstance(params, dict) or not params:
            errors.append("transportProfileInterfaceParameters is required")
    return not errors, errors


def migration_preview() -> None:
    runner = workspace_runner()
    rows: List[Dict[str, Any]] = []
    for key in MIGRATION_STEP_DEFINITIONS:
        try:
            request = runner.preview_step_request(key)
            ready, errors = _migration_preview_readiness(key, request)
            row = redact_sensitive(request)
            row["migrationReady"] = ready
            row["migrationErrors"] = errors
            rows.append(row)
        except Exception as exc:
            rows.append({"stepKey": key, "error": f"{type(exc).__name__}: {exc}", "applicable": False, "migrationReady": False, "migrationErrors": [str(exc)]})
    print(json.dumps({"items": rows}, ensure_ascii=False, default=str))


def execute(graph_path: Path) -> None:
    graph = json.loads(graph_path.read_text(encoding="utf-8"))
    runner = workspace_runner()
    nodes = graph.get("nodes") or []
    edges = graph.get("edges") or []
    order = graph.get("execution_order") or [n.get("id") for n in nodes]
    execution_id = str(graph.get("execution_id") or "")
    resume_state = graph.get("resume_state") or {}
    resumed_nodes = set(str(x) for x in (resume_state.get("completedNodeIds") or []))
    node_by_id = {n.get("id"): n for n in nodes}
    incoming: Dict[str, List[Dict[str, Any]]] = {}
    for edge in edges:
        incoming.setdefault(str(edge.get("target") or ""), []).append(edge)
    step_outputs: Dict[str, Any] = deepcopy(resume_state.get("outputs") or {})
    started = time.perf_counter()
    blocked = False
    completed_nodes = 0
    emit({"type": "execution.started", "nodeCount": len(order), "workspace": str(WORKSPACE), "executionOrder": order, "executionId": execution_id, "resumedNodeCount": len(resumed_nodes)})
    for index, node_id in enumerate(order, start=1):
        node = node_by_id.get(node_id) or {}
        if not node.get("enabled", True):
            emit({"type": "node.skipped", "nodeId": node_id, "reason": "Block is disabled"})
            continue
        if str(node_id) in resumed_nodes:
            emit({"type": "node.resumed", "nodeId": node_id, "reason": "Restored from prior successful execution", "output": redact_sensitive(step_outputs.get(str(node_id)) or {})})
            completed_nodes += 1
            continue
        if bool(node.get("approval_required", False)):
            if not execution_id:
                emit({"type": "node.failed", "nodeId": node_id, "error": "Execution id is required for an approval-gated node."})
                emit({"type": "execution.blocked", "nodeId": node_id, "reason": "Approval gate could not be initialized."})
                blocked = True
                break
            approval_dir = WORKSPACE / ".runtime_approvals" / execution_id
            approval_file = approval_dir / f"{node_id}.approved.json"
            timeout_seconds = max(1, int(os.getenv("HIP_NODE_APPROVAL_TIMEOUT_SECONDS", "3600") or "3600"))
            emit({"type": "node.awaiting_approval", "nodeId": node_id, "message": str(node.get("approval_message") or "Manual approval is required before this LIVE API call."), "timeoutSeconds": timeout_seconds})
            approval_started = time.perf_counter()
            while not approval_file.exists():
                if time.perf_counter() - approval_started >= timeout_seconds:
                    emit({"type": "node.failed", "nodeId": node_id, "error": "Manual approval timed out."})
                    emit({"type": "execution.blocked", "nodeId": node_id, "reason": "Manual approval timed out."})
                    blocked = True
                    break
                time.sleep(0.25)
            if blocked:
                break
            try:
                approval = json.loads(approval_file.read_text(encoding="utf-8"))
            except Exception:
                approval = {"approvedBy": "User"}
            emit({"type": "node.approval_received", "nodeId": node_id, "approval": redact_sensitive(approval), "waitedMs": int((time.perf_counter() - approval_started) * 1000)})
        component = new_component(
            node.get("api_key"),
            label=node.get("label") or "",
            enabled=True,
            wait_after_seconds=node.get("wait_after_seconds", 0),
            stop_on_blocked=node.get("stop_on_blocked", True),
            override_mode=node.get("override_mode", "merge"),
            request_override=node.get("request_override") or {},
            instance_id=node_id,
            source="react-flow",
        )
        emit({"type": "node.started", "nodeId": node_id, "apiKey": component["stepKey"], "index": index})
        try:
            request = component_request(runner, component, step_outputs)
            if request.get("applicable") is False:
                output = {
                    "classification": "NOT_APPLICABLE",
                    "verdict": "PASS",
                    "outcome": "NOT_APPLICABLE",
                    "reason": str(request.get("applicabilityReason") or "Not required by the active canonical configuration."),
                }
                step_outputs[str(node_id)] = output
                completed_nodes += 1
                emit({"type": "node.skipped", "nodeId": node_id, "apiKey": component["stepKey"], "reason": output["reason"], "output": output})
                continue
            request, resolved_mappings, unresolved_mappings = apply_edge_mappings(request, incoming.get(str(node_id), []), step_outputs)
            # Connection mappings are also values-only. Re-lock after mappings so
            # a manually authored edge can never create a new payload attribute.
            request_kind = str(request.get("requestKind") or ("params" if request.get("params") is not None and request.get("payload") is None else "payload"))
            locked_body, structure_meta = runner.lock_request_value(
                component["stepKey"], request_kind, request.get(request_kind) or {},
                fallback=request.get(request_kind) or {}, strict_unknown=True,
            )
            request[request_kind] = locked_body
            request["canonicalStructure"] = structure_meta
            if unresolved_mappings:
                emit({"type": "node.mapping_blocked", "nodeId": node_id, "unresolvedMappings": redact_sensitive(unresolved_mappings)})
                emit({"type": "execution.blocked", "nodeId": node_id, "reason": "One or more connection mappings could not be resolved from upstream outputs."})
                blocked = True
                break
            emit({"type": "node.request", "nodeId": node_id, "request": redact_sensitive({
                "method": request.get("method"), "url": request.get("url"),
                "payload": request.get("payload"), "params": request.get("params"),
            }), "resolvedMappings": redact_sensitive(resolved_mappings),
                "incomingEdgeIds": [str(e.get("id") or "") for e in incoming.get(str(node_id), [])]})

            def request_event(event: Dict[str, Any]) -> None:
                kind = str(event.get("type") or "")
                if kind == "http.retry":
                    emit({"type": "node.retry", "nodeId": node_id, **{k: v for k, v in event.items() if k != "type"}})
                elif kind == "http.attempt":
                    emit({"type": "node.http_attempt", "nodeId": node_id, **{k: v for k, v in event.items() if k != "type"}})

            runner.request_event_callback = request_event
            step_started = time.perf_counter()
            result = runner.call(
                index,
                str(request.get("group") or "API Flow Game"),
                str(component.get("label") or request.get("api") or component["stepKey"]),
                f"react_flow_{node_id}",
                str(request.get("method") or "POST"),
                str(request.get("urlKey") or ""),
                str(request.get("scopeKey") or ""),
                payload=request.get("payload"), params=request.get("params"),
                token_kind=str(request.get("tokenKind") or "HIP"),
                scope_override=request.get("scopeOverride"), suffix=str(request.get("suffix") or ""),
                extra_headers=request.get("extraHeaders") or {},
            )
            runner.request_event_callback = None
            runner.enforce_live_id_integrity(component["stepKey"], result, require_dependency_ids=True)
            persist_runner_runtime(runner)
            raw = asdict(result)
            verdict = agent_response_verdict(raw)
            extracted = dict(result.extracted or {})
            extracted.update({
                "httpStatus": result.status_code,
                "classification": result.classification,
                "verdict": verdict.get("verdict"),
                "outcome": verdict.get("outcome"),
            })
            step_outputs[node_id] = extracted
            wait = float(component.get("waitAfterSeconds") or 0)
            if wait > 0:
                emit({"type": "node.waiting", "nodeId": node_id, "waitMs": int(wait * 1000)})
                time.sleep(wait)
            total_ms = int((time.perf_counter() - step_started) * 1000)
            completed_nodes += 1
            emit({
                "type": "node.completed",
                "nodeId": node_id,
                "apiKey": component["stepKey"],
                "verdict": verdict,
                "result": redact_sensitive(raw),
                "output": redact_sensitive(extracted),
                "resolvedMappings": redact_sensitive(resolved_mappings),
                "timing": {"apiMs": result.elapsed_ms or 0, "waitMs": int(wait * 1000), "totalMs": total_ms},
            })
            if not verdict_allows_progress(verdict) and component.get("stopOnBlocked", True):
                emit({"type": "execution.blocked", "nodeId": node_id, "reason": verdict.get("reason") or verdict.get("outcome")})
                blocked = True
                break
        except Exception as exc:
            runner.request_event_callback = None
            emit({"type": "node.failed", "nodeId": node_id, "error": f"{type(exc).__name__}: {exc}"})
            emit({"type": "execution.blocked", "nodeId": node_id, "reason": str(exc)})
            blocked = True
            break
    emit({"type": "execution.completed", "status": "BLOCKED" if blocked else "PASS", "completedNodes": completed_nodes, "nodeCount": len(order), "elapsedMs": int((time.perf_counter() - started) * 1000)})


def flow_preflight(graph_path: Path) -> None:
    graph = json.loads(graph_path.read_text(encoding="utf-8"))
    runner = workspace_runner()
    nodes = graph.get("nodes") or []
    order = graph.get("execution_order") or [n.get("id") for n in nodes]
    execution_id = str(graph.get("execution_id") or "")
    resume_state = graph.get("resume_state") or {}
    resumed_nodes = set(str(x) for x in (resume_state.get("completedNodeIds") or []))
    node_by_id = {n.get("id"): n for n in nodes}
    incoming_count: Dict[str, int] = {}
    for edge in graph.get("edges") or []:
        if edge.get("mappings"):
            incoming_count[str(edge.get("target") or "")] = incoming_count.get(str(edge.get("target") or ""), 0) + len(edge.get("mappings") or [])
    items: List[Dict[str, Any]] = []
    for index, node_id in enumerate(order, start=1):
        node = node_by_id.get(node_id) or {}
        if not node.get("enabled", True):
            items.append({"nodeId": node_id, "apiKey": node.get("api_key"), "valid": True, "skipped": True, "reason": "Block is disabled"})
            continue
        try:
            component = new_component(
                node.get("api_key"), label=node.get("label") or "", enabled=True,
                wait_after_seconds=node.get("wait_after_seconds", 0),
                stop_on_blocked=node.get("stop_on_blocked", True),
                override_mode=node.get("override_mode", "merge"),
                request_override=node.get("request_override") or {},
                instance_id=node_id, source="react-flow-preflight",
            )
            request = component_request(runner, component, {})
            if request.get("applicable") is False:
                items.append({
                    "nodeId": node_id, "apiKey": component["stepKey"], "valid": True,
                    "skipped": True, "status": "NOT_APPLICABLE",
                    "reason": str(request.get("applicabilityReason") or "Not required by the active canonical configuration."),
                })
                continue
            contract = runner.validate_request_contract(
                seq=index, api_key=str(request.get("urlKey") or ""), method=str(request.get("method") or "POST"),
                url=str(request.get("url") or runner.build_url(str(request.get("urlKey") or ""), str(request.get("suffix") or ""))),
                extra_headers=request.get("extraHeaders") or {}, payload=request.get("payload"), params=request.get("params"),
            )
            items.append({
                "nodeId": node_id, "apiKey": component["stepKey"],
                "valid": bool(contract.get("valid")),
                "runtimeMappingCount": incoming_count.get(str(node_id), 0),
                "request": redact_sensitive({"method": request.get("method"), "url": request.get("url"), "payload": request.get("payload"), "params": request.get("params")}),
                "contractValidation": redact_sensitive(contract),
            })
        except Exception as exc:
            items.append({"nodeId": node_id, "apiKey": node.get("api_key"), "valid": False, "error": f"{type(exc).__name__}: {exc}"})
    emit({"ok": all(bool(item.get("valid")) for item in items), "items": items})


def api_test(spec_path: Path) -> None:
    """Preflight or execute one selected API block for the React API Testing Area."""
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
    step_key = str(spec.get("step_key") or "").strip()
    if step_key not in ALL_TEST_STEP_DEFINITIONS:
        emit({"ok": False, "error": f"Unknown HIP API step: {step_key}"})
        raise SystemExit(2)
    execute_live = bool(spec.get("execute"))
    override_mode = "merge"
    request_override = spec.get("request_override") or {}
    assert_no_request_override(request_override, context="API Testing worker request")
    request_override = {}
    runner = workspace_runner()
    component = new_component(
        step_key,
        label=str(ALL_TEST_STEP_DEFINITIONS.get(step_key, {}).get("label") or step_key),
        enabled=True,
        wait_after_seconds=0,
        stop_on_blocked=True,
        override_mode=override_mode,
        request_override=request_override,
        instance_id=f"api-test-{step_key}",
        source="react-api-testing-area",
    )
    try:
        request = component_request(runner, component, {})
        if request.get("applicable") is False:
            emit({
                "ok": True, "executed": False, "stepKey": step_key,
                "applicable": False,
                "applicabilityReason": str(request.get("applicabilityReason") or "Not required by the active canonical configuration."),
                "request": redact_sensitive({"method": request.get("method"), "url": request.get("url"), "payload": request.get("payload"), "params": request.get("params")}),
                "contractValidation": {"valid": True, "skipped": True, "status": "NOT_APPLICABLE"},
                "verdict": {"verdict": "PASS", "outcome": "NOT_APPLICABLE", "reason": str(request.get("applicabilityReason") or "Not required by the active canonical configuration.")},
            })
            return
        contract = runner.validate_request_contract(
            seq=1,
            api_key=str(request.get("urlKey") or ""),
            method=str(request.get("method") or "POST"),
            url=str(request.get("url") or runner.build_url(str(request.get("urlKey") or ""), str(request.get("suffix") or ""))),
            extra_headers=request.get("extraHeaders") or {},
            payload=request.get("payload"),
            params=request.get("params"),
        )
        base = {
            "ok": bool(contract.get("valid")),
            "executed": False,
            "stepKey": step_key,
            "applicable": bool(request.get("applicable", True)),
            "applicabilityReason": str(request.get("applicabilityReason") or ""),
            "request": redact_sensitive({
                "method": request.get("method"), "url": request.get("url"), "urlKey": request.get("urlKey"),
                "payload": request.get("payload"), "params": request.get("params"), "extraHeaders": request.get("extraHeaders") or {},
                "tokenKind": request.get("tokenKind"), "scopeKey": request.get("scopeKey"),
            }),
            "contractValidation": redact_sensitive(contract),
        }
        missing_runtime = runner.missing_standalone_runtime_requirements(step_key)
        base["runtimeDependencies"] = runner.standalone_runtime_requirements(step_key)
        base["missingRuntimeDependencies"] = missing_runtime
        if missing_runtime:
            base["ok"] = False
            base["runtimeDependencyBlocked"] = True
            base["error"] = (
                "Current-environment LIVE runtime ID(s) are required before this isolated API can run: "
                + ", ".join(missing_runtime)
                + ". Run the prerequisite block(s) LIVE first or execute the full dependency-safe pipeline."
            )
        if not execute_live:
            emit(base)
            return
        if missing_runtime:
            emit({**base, "executed": False})
            raise SystemExit(2)
        if not bool(request.get("applicable", True)):
            emit({**base, "ok": True, "executed": False, "verdict": {"verdict": "PASS", "outcome": "NOT_APPLICABLE", "reason": base["applicabilityReason"]}})
            return
        if not bool(contract.get("valid")):
            emit({**base, "ok": False, "executed": False, "error": "Selected API request failed contract preflight."})
            raise SystemExit(2)

        attempts: List[Dict[str, Any]] = []
        def request_event(event: Dict[str, Any]) -> None:
            attempts.append(redact_sensitive(dict(event)))
        runner.request_event_callback = request_event
        started = time.perf_counter()
        result = runner.call(
            1,
            str(request.get("group") or "API Testing Area"),
            str(component.get("label") or request.get("api") or step_key),
            f"react_api_test_{step_key}",
            str(request.get("method") or "POST"),
            str(request.get("urlKey") or ""),
            str(request.get("scopeKey") or ""),
            payload=request.get("payload"), params=request.get("params"),
            token_kind=str(request.get("tokenKind") or "HIP"),
            scope_override=request.get("scopeOverride"), suffix=str(request.get("suffix") or ""),
            extra_headers=request.get("extraHeaders") or {},
        )
        runner.request_event_callback = None
        runner.enforce_live_id_integrity(step_key, result, require_dependency_ids=True)
        persist_runner_runtime(runner)
        raw = asdict(result)
        verdict = agent_response_verdict(raw)
        extracted = dict(result.extracted or {})
        extracted.update({
            "httpStatus": result.status_code,
            "classification": result.classification,
            "verdict": verdict.get("verdict"),
            "outcome": verdict.get("outcome"),
        })
        payload = {
            **base,
            "ok": verdict_allows_progress(verdict),
            "executed": True,
            "result": redact_sensitive(raw),
            "response": redact_sensitive({"statusCode": result.status_code, "body": result.response_preview, "classification": result.classification}),
            "verdict": redact_sensitive(verdict),
            "output": redact_sensitive(extracted),
            "attempts": attempts,
            "timing": {"apiMs": result.elapsed_ms or 0, "totalMs": int((time.perf_counter() - started) * 1000)},
        }
        reports = WORKSPACE / "reports"
        reports.mkdir(parents=True, exist_ok=True)
        (reports / "react_api_test_latest.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        emit(payload)
    except SystemExit:
        raise
    except Exception as exc:
        runner.request_event_callback = None
        emit({"ok": False, "executed": False, "stepKey": step_key, "error": f"{type(exc).__name__}: {exc}"})
        raise SystemExit(2)


if MODE == "preview":
    preview()
elif MODE == "migration_preview":
    migration_preview()
elif MODE == "validate":
    from application_studio import run_local_request_checks
    emit(redact_sensitive(run_local_request_checks(WORKSPACE)))
elif MODE == "flow_preflight":
    flow_preflight(Path(sys.argv[3]))
elif MODE == "execute":
    execute(Path(sys.argv[3]))
elif MODE == "api_test":
    api_test(Path(sys.argv[3]))
else:
    raise SystemExit(f"Unknown worker mode: {MODE}")
