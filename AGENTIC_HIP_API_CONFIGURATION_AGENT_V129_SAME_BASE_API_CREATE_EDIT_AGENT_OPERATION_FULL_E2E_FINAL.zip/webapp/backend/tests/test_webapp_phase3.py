from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.flow_engine import apply_edge_mappings, apply_safe_fixes, compile_flow
from webapp.backend.app.main import app


def test_phase3_bootstrap_exposes_phase_three_and_all_18_blocks():
    data = TestClient(app).get('/api/bootstrap').json()
    assert data['phase'] >= 3
    assert len(data['api_catalog']) == 18


def test_runtime_edge_mapping_injects_upstream_values_into_nested_target_payload():
    request = {
        'requestKind': 'payload',
        'payload': {'documentTypeId': 0, 'actions': [{'params': {'mapId': 0}}]},
        'params': None,
    }
    edges = [
        {'id': 'doc-rule', 'source': 'doc', 'target': 'rule', 'mappings': [{'from': 'output.documentTypeId', 'to': 'payload.documentTypeId'}]},
        {'id': 'map-rule', 'source': 'map', 'target': 'rule', 'mappings': [{'from': 'output.mapId', 'to': 'payload.actions.0.params.mapId'}]},
    ]
    effective, resolved, unresolved = apply_edge_mappings(
        request, edges, {'doc': {'documentTypeId': 10483}, 'map': {'mapId': 1670}}
    )
    assert unresolved == []
    assert effective['payload']['documentTypeId'] == 10483
    assert effective['payload']['actions'][0]['params']['mapId'] == 1670
    assert {row['edgeId'] for row in resolved} == {'doc-rule', 'map-rule'}


def test_runtime_edge_mapping_blocks_when_upstream_output_is_missing():
    request = {'requestKind': 'payload', 'payload': {'documentTypeId': 0}, 'params': None}
    effective, resolved, unresolved = apply_edge_mappings(
        request,
        [{'id': 'e', 'source': 'doc', 'target': 'rule', 'mappings': [{'from': 'output.documentTypeId', 'to': 'payload.documentTypeId'}]}],
        {'doc': {}},
    )
    assert effective['payload']['documentTypeId'] == 0
    assert resolved == []
    assert unresolved[0]['reason'] == 'upstream output path is unavailable'


def test_phase3_agent_compiler_suggests_high_confidence_doc_and_map_wiring():
    flow = {
        'nodes': [
            {'id': 'doc', 'api_key': 'doctype_source', 'enabled': True},
            {'id': 'map', 'api_key': 'map', 'enabled': True},
            {'id': 'rule', 'api_key': 'rule', 'enabled': True},
        ],
        'edges': [
            {'id': 'doc-rule', 'source': 'doc', 'target': 'rule', 'mappings': []},
            {'id': 'map-rule', 'source': 'map', 'target': 'rule', 'mappings': []},
        ],
    }
    preview = {'items': [
        {'stepKey': 'doctype_source', 'payload': {'name': 'SRC'}},
        {'stepKey': 'map', 'payload': {'mapName': 'MAP'}},
        {'stepKey': 'rule', 'payload': {'documentTypeId': 0, 'actions': [{'params': {'mapId': 0}}]}},
    ]}
    compiled = compile_flow(flow, {'doctype_source', 'map', 'rule'}, preview)
    assert compiled['ok'] is True
    assert compiled['executionOrder'][-1] == 'rule'
    mappings = {row['edgeId']: row['mapping'] for row in compiled['suggestedMappings']}
    assert mappings['doc-rule'] == {'from': 'output.documentTypeId', 'to': 'payload.documentTypeId'}
    assert mappings['map-rule'] == {'from': 'output.mapId', 'to': 'payload.actions.0.params.mapId'}


def test_phase3_safe_autofix_adds_only_suggested_mapping_and_disables_not_applicable_node():
    flow = {
        'nodes': [{'id': 'doc', 'api_key': 'doctype_source', 'enabled': True}, {'id': 'target', 'api_key': 'doctype_target', 'enabled': True}, {'id': 'rule', 'api_key': 'rule', 'enabled': True}],
        'edges': [{'id': 'e', 'source': 'doc', 'target': 'rule', 'mappings': []}],
    }
    preview = {'items': [
        {'stepKey': 'doctype_source', 'payload': {}},
        {'stepKey': 'doctype_target', 'payload': {}, 'applicable': False},
        {'stepKey': 'rule', 'payload': {'documentTypeId': 0}},
    ]}
    compiled = compile_flow(flow, {'doctype_source', 'doctype_target', 'rule'}, preview)
    fixed = apply_safe_fixes(flow, compiled)
    assert fixed['flow']['edges'][0]['mappings'][0]['to'] == 'payload.documentTypeId'
    assert next(n for n in fixed['flow']['nodes'] if n['id'] == 'target')['enabled'] is False


def test_phase3_worker_streams_runtime_mapping_and_retry_telemetry():
    root = Path(__file__).resolve().parents[3]
    worker = (root / 'webapp/backend/app/legacy_worker.py').read_text(encoding='utf-8')
    runner = (root / 'run_agent.py').read_text(encoding='utf-8')
    assert 'apply_edge_mappings' in worker
    assert 'node.mapping_blocked' in worker
    assert 'node.retry' in worker
    assert 'node.http_attempt' in worker
    assert 'request_event_callback' in runner
    assert 'http.retry' in runner


def test_phase3_react_game_has_edge_inspector_preflight_and_autowire():
    root = Path(__file__).resolve().parents[3]
    flow = (root / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    edge = (root / 'webapp/frontend/src/components/EdgeInspector.tsx').read_text(encoding='utf-8')
    node = (root / 'webapp/frontend/src/components/NodeInspector.tsx').read_text(encoding='utf-8')
    assert 'Agent preflight' in flow
    assert 'Agent auto-wire' in flow
    assert 'runtime mappings' in flow
    assert 'onEdgeClick' in flow
    assert 'Connection mapping' in edge
    assert 'output.documentTypeId' in edge
    assert 'Generated/effective request' in node
    assert 'HTTP attempts / retries' in node


def test_phase3_main_enforces_graph_preflight_before_live_execution():
    root = Path(__file__).resolve().parents[3]
    main = (root / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    assert '/flow/preflight' in main
    assert '/flow/autofix' in main
    assert 'Agent validation must PASS before LIVE graph execution.' in main
    assert 'preflight_flow_requests' in main


def test_phase3_completed_graph_execution_is_persisted_into_configuration_reports(tmp_path: Path):
    import asyncio
    from webapp.backend.app.execution_manager import ExecutionManager
    from webapp.backend.app.storage import JsonStore
    store = JsonStore(tmp_path / "runtime")
    config = store.create_configuration({
        "name":"C", "customer":"C", "direction":"Inbound", "transaction_code":"850", "transaction_name":"",
        "flow_type":"Passthrough", "source_interface":"SFTP", "target_interface":"SFTP", "input_mode":"files", "user_instructions":""
    })
    manager = ExecutionManager(store)
    store.save_execution("exec1", {"id":"exec1","configuration_id":config["id"],"status":"RUNNING","events":[]})
    loop = asyncio.new_event_loop()
    try:
        manager._publish("exec1", {"type":"execution.completed","status":"PASS","elapsedMs":1234}, loop)
    finally:
        loop.close()
    report = Path(config["workspace"]) / "reports" / "react_flow_execution_latest.json"
    assert report.exists()
    assert '"status": "PASS"' in report.read_text(encoding="utf-8")
