from __future__ import annotations

import json
from pathlib import Path
from tempfile import TemporaryDirectory

from fastapi.testclient import TestClient

from webapp.backend.app.execution_manager import ExecutionManager
from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
from webapp.backend.app.templates import builtin_templates


def test_catalog_has_all_18_reusable_apis():
    rows = api_catalog()
    assert len(rows) == 18
    assert len({x["key"] for x in rows}) == 18
    assert all(x["reusable"] for x in rows)


def test_direction_default_is_outbound_but_inbound_is_editable():
    meta = transaction_metadata()
    assert meta["default_direction"] == "Outbound"
    assert meta["editable_direction"] is True
    assert "850" in meta["directions"]["Inbound"]["suggested_transactions"]
    assert {"832", "855", "856"}.issubset(set(meta["directions"]["Outbound"]["suggested_transactions"]))


def test_builtin_templates_cover_requested_initial_transaction_matrix():
    names = {x["name"] for x in builtin_templates()}
    assert "Inbound 850 Translation" in names
    assert "Inbound 850 Passthrough" in names
    for tx in ("832", "855", "856"):
        assert f"Outbound {tx} Translation" in names
        assert f"Outbound {tx} Passthrough" in names


def test_graph_allows_branching_and_repeated_api_blocks_but_rejects_cycles():
    nodes = [
        {"id": "a", "api_key": "doctype_source"},
        {"id": "b", "api_key": "doctype_source"},
        {"id": "c", "api_key": "map"},
        {"id": "d", "api_key": "rule"},
    ]
    edges = [
        {"source": "a", "target": "c"},
        {"source": "a", "target": "d"},
        {"source": "b", "target": "d"},
    ]
    order = ExecutionManager.topological_order(nodes, edges)
    assert set(order) == {"a", "b", "c", "d"}
    assert order.index("a") < order.index("c")
    assert order.index("a") < order.index("d")
    try:
        ExecutionManager.topological_order(nodes, edges + [{"source": "d", "target": "a"}])
    except ValueError as exc:
        assert "cycle" in str(exc).lower()
    else:
        raise AssertionError("cycle must fail")


def test_phase1_builder_uses_user_direction_and_uploaded_xml_as_physical_format(tmp_path: Path):
    from webapp.backend.app.legacy_adapter import build_configuration
    workspace = tmp_path / "cfg"
    (workspace / "uploads").mkdir(parents=True)
    (workspace / "input_files").mkdir()
    (workspace / "uploads" / "SRC_850.xml").write_text(
        '<?xml version="1.0"?><PurchaseOrder><Receiver>DELL</Receiver><Sender>CUSTOMER</Sender></PurchaseOrder>',
        encoding="utf-8",
    )
    settings = {
        "customer": "CUSTOMER",
        "direction": "Inbound",
        "transaction_code": "850",
        "transaction_name": "Purchase Order",
        "flow_type": "Passthrough",
        "source_interface": "SFTP",
        "target_interface": "SFTP",
        "input_mode": "files",
        "user_instructions": "Inbound passthrough. No separate target document type.",
    }
    result = build_configuration(workspace, settings, use_dell_aia=False)
    data = result["input"]
    assert data["direction"] == "Inbound"
    assert data["tx_code"] == "850"
    assert data["objects"]["source_document_type"]["data_format_type"] == "XML"
    assert data["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert data["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"


def test_phase1_builder_accepts_zip_customer_bundle(tmp_path: Path):
    import zipfile
    from webapp.backend.app.legacy_adapter import build_configuration
    workspace = tmp_path / "cfgzip"
    (workspace / "uploads").mkdir(parents=True)
    (workspace / "input_files").mkdir()
    bundle = workspace / "uploads" / "customer_files.zip"
    with zipfile.ZipFile(bundle, "w") as zf:
        zf.writestr("SRC_order.xml", '<?xml version="1.0"?><PurchaseOrder><Receiver>DELL</Receiver></PurchaseOrder>')
    settings = {
        "customer": "ZIP_CUSTOMER", "direction": "Inbound", "transaction_code": "850",
        "transaction_name": "Purchase Order", "flow_type": "Passthrough",
        "source_interface": "SFTP", "target_interface": "SFTP", "input_mode": "files",
        "user_instructions": "Inbound passthrough. No separate target document type."
    }
    result = build_configuration(workspace, settings, use_dell_aia=False)
    assert "SRC_order.xml" in result["uploaded_files"]
    assert result["input"]["objects"]["source_document_type"]["data_format_type"] == "XML"
