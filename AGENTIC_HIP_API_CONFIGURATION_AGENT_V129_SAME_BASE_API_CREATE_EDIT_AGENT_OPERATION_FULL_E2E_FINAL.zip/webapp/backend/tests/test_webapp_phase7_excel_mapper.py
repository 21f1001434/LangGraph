from __future__ import annotations

import json
import zipfile
from io import BytesIO
from pathlib import Path

from fastapi.testclient import TestClient

from canonical_payload_contract import validate_override_structure

from webapp.backend.app.excel_api_mapper import analyze_workbook, read_workbook
from webapp.backend.app.legacy_adapter import preview_all_api_requests
from webapp.backend.app.main import app

ROOT = Path(__file__).resolve().parents[3]


def _structure_signature(value, prefix=''):
    rows = []
    if isinstance(value, dict):
        rows.append((prefix or '$', 'object', tuple(sorted(value.keys()))))
        for key in sorted(value):
            rows.extend(_structure_signature(value[key], f"{prefix}.{key}" if prefix else key))
    elif isinstance(value, list):
        rows.append((prefix or '$', 'array', len(value)))
        for i, item in enumerate(value):
            rows.extend(_structure_signature(item, f"{prefix}.{i}" if prefix else str(i)))
    else:
        rows.append((prefix or '$', 'scalar', None))
    return rows


def _mini_xlsx() -> bytes:
    """Create a tiny standards-compliant XLSX fixture without spreadsheet libraries."""
    out = BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>''')
        z.writestr('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>''')
        z.writestr('xl/workbook.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="SFTP_UAT" sheetId="1" r:id="rId1"/></sheets></workbook>''')
        z.writestr('xl/_rels/workbook.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>''')
        z.writestr('xl/worksheets/sheet1.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>
<row r="1"><c r="A1" t="inlineStr"><is><t>Source System</t></is></c><c r="B1" t="inlineStr"><is><t>DEV-Transport Profile Name</t></is></c><c r="C1" t="inlineStr"><is><t>Source Interface Type</t></is></c><c r="D1" t="inlineStr"><is><t>Document Type Name</t></is></c><c r="E1" t="inlineStr"><is><t>Hip Account names</t></is></c><c r="F1" t="inlineStr"><is><t>SFTP Server</t></is></c><c r="G1" t="inlineStr"><is><t>Document Type Version</t></is></c></row>
<row r="2"><c r="A2" t="inlineStr"><is><t>AIC - DCE</t></is></c><c r="B2" t="inlineStr"><is><t>SFTP_ACME_ASN_SRC_OB</t></is></c><c r="C2" t="inlineStr"><is><t>SFTP HAFT</t></is></c><c r="D2" t="inlineStr"><is><t>XML_ACME_ASN_10</t></is></c><c r="E2" t="inlineStr"><is><t>acme-account</t></is></c><c r="F2" t="inlineStr"><is><t>sftp.acme.com</t></is></c><c r="G2" t="inlineStr"><is><t>1.0</t></is></c></row>
</sheetData></worksheet>''')
    return out.getvalue()


def test_phase7_bootstrap_exposes_intelligent_mapper_capability():
    data = TestClient(app).get('/api/bootstrap').json()
    assert data['capabilities']['intelligentExcelApiMapper'] is True
    assert data['capabilities']['humanGatedMappedPayloadStaging'] is True


def test_phase7_xlsx_reader_detects_sheet_header_and_rows():
    wb = read_workbook('team.xlsx', _mini_xlsx())
    assert wb['format'] == 'XLSX'
    assert wb['sheets'][0]['name'] == 'SFTP_UAT'
    assert wb['sheets'][0]['rows'][0][1] == 'DEV-Transport Profile Name'
    assert wb['sheets'][0]['rows'][1][4] == 'acme-account'


def test_phase7_transport_profile_mapping_is_schema_locked_and_good_to_trigger():
    preview = preview_all_api_requests(ROOT)
    result = analyze_workbook(
        filename='team.xlsx', data=_mini_xlsx(), preview_items=preview['items'],
        selected_api='source_tp', use_dell_aia=False,
    )
    row = result['results'][0]
    assert result['agentSchemaEditAllowed'] is False
    assert result['agentValueMappingAllowed'] is True
    assert result['userApprovalRequiredBeforePersistence'] is True
    assert row['status'] == 'GOOD_TO_TRIGGER'
    assert row['apiKey'] == 'source_tp'
    assert row['proposedRequest']['transportProfileDetails'][0]['transportProfileName'] == 'SFTP_ACME_ASN_SRC_OB'
    assert row['proposedRequest']['transportProfileDetails'][0]['interfaceDetails'][0]['interfaceType'] == 'SFTP HAFT'
    assert row['proposedRequest']['transportProfileDetails'][0]['documentTypeDetails'][0]['documentTypeName'] == 'XML_ACME_ASN_10'
    # The supplied workbook can contain useful legacy/connectivity data that is
    # not part of the current canonical SFTP payload. It must remain unmapped.
    assert 'SFTP Server' in row['unmappedColumns']
    assert not row['contractErrors']
    # Agent changed values/mapping only; the API attribute tree/cardinality is byte-for-byte structural-equivalent.
    assert _structure_signature(row['proposedRequest']) == _structure_signature(row['baseEffectiveRequest'])


def test_phase7_auto_mode_selects_source_tp_for_source_tp_workbook():
    preview = preview_all_api_requests(ROOT)
    result = analyze_workbook(
        filename='team.xlsx', data=_mini_xlsx(), preview_items=preview['items'],
        selected_api='AUTO', use_dell_aia=False,
    )
    row = result['results'][0]
    assert row['apiKey'] == 'source_tp'
    assert row['status'] == 'GOOD_TO_TRIGGER'
    assert row['apiAlternatives']



def test_phase7_sftp_abbreviation_is_canonicalized_only_with_same_active_interface_family():
    preview = preview_all_api_requests(ROOT)
    csv_data = (
        'Source System,DEV-Transport Profile Name,Source Interface Type,Document Type Name,Document Type Version,Hip Account names\n'
        'AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10,1.0,acme-account\n'
    ).encode()
    result = analyze_workbook(
        filename='team.csv', data=csv_data, preview_items=preview['items'],
        selected_api='source_tp', use_dell_aia=False,
    )
    row = result['results'][0]
    assert row['status'] == 'GOOD_TO_TRIGGER'
    mapping = next(item for item in row['mappings'] if item['sourceColumn'] == 'Source Interface Type')
    assert mapping['sourceValue'] == 'SFTP'
    assert mapping['mappedValue'] == 'SFTP HAFT'
    assert mapping['valueNormalized'] is True

def test_phase7_mapper_frontend_keeps_live_behind_human_stage_and_preflight():
    page = (ROOT / 'webapp/frontend/src/pages/ExcelApiMapperPage.tsx').read_text(encoding='utf-8')
    sidebar = (ROOT / 'webapp/frontend/src/components/Sidebar.tsx').read_text(encoding='utf-8')
    assert "label:'Excel → API Mapper'" in sidebar
    assert 'Approve & stage values' in page
    assert 'Agent preflight' in page
    assert 'Run API LIVE' in page
    assert '!good||!staged||!preflightPassed' in page
    assert 'Agents may map Excel fields and fill/change VALUES only on existing canonical API paths' in page


def test_phase7_agent_cannot_invent_or_add_api_attribute():
    preview = preview_all_api_requests(ROOT)
    item = next(row for row in preview['items'] if row.get('stepKey') == 'source_tp')
    request = json.loads(json.dumps(item.get('effectivePayload') or item.get('generatedPayload') or {}))
    request['agentInventedAttribute'] = 'must-never-be-accepted'
    verdict = validate_override_structure('source_tp', 'payload', request)
    assert verdict['valid'] is False
    assert any('agentInventedAttribute' in str(error.get('field') or '') for error in verdict['errors'])
