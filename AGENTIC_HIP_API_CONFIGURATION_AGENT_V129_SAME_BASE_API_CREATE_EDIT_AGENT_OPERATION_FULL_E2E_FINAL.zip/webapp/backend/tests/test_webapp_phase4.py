from __future__ import annotations

import asyncio
import json
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.execution_manager import ExecutionManager
from webapp.backend.app.main import app
from webapp.backend.app.models import FlowDefinition
from webapp.backend.app.storage import JsonStore


def _config(store: JsonStore):
    return store.create_configuration({
        "name":"Phase4", "customer":"Demo", "direction":"Inbound", "transaction_code":"850", "transaction_name":"PO",
        "flow_type":"Translation", "source_interface":"SFTP", "target_interface":"SFTP", "input_mode":"files", "user_instructions":""
    })


def test_phase4_bootstrap_and_18_api_blocks():
    data = TestClient(app).get('/api/bootstrap').json()
    assert data['phase'] >= 4
    assert data['deployment_group'] == 'hip-automation'
    assert len(data['api_catalog']) == 18


def test_phase4_flow_node_supports_manual_approval_gate():
    flow = FlowDefinition.model_validate({
        "name":"Approval", "nodes":[{"id":"deploy","api_key":"flow_deploy","approval_required":True,"approval_message":"Approve deployment"}], "edges":[]
    })
    node = flow.nodes[0]
    assert node.approval_required is True
    assert node.approval_message == 'Approve deployment'


def test_phase4_resume_state_restores_only_successful_completed_nodes(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    manager = ExecutionManager(store)
    previous = {
        "id":"old", "configuration_id":"cfg", "events":[
            {"type":"node.completed","nodeId":"doc","verdict":{"verdict":"PASS"},"output":{"documentTypeId":101}},
            {"type":"node.completed","nodeId":"rule","verdict":{"verdict":"BLOCKED"},"output":{"ruleId":202}},
            {"type":"node.failed","nodeId":"flow","error":"boom"},
        ]
    }
    state = manager._resume_state(previous)
    assert state['completedNodeIds'] == ['doc']
    assert state['outputs']['doc']['documentTypeId'] == 101
    assert 'rule' not in state['outputs']


def test_phase4_manual_approval_marker_is_runtime_only(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    config = _config(store)
    store.save_execution('exec1', {"id":"exec1","configuration_id":config['id'],"status":"WAITING_APPROVAL","events":[]})
    manager = ExecutionManager(store)
    result = manager.approve_node('exec1','deploy','Tester','Reviewed payload')
    marker = Path(config['workspace']) / '.runtime_approvals' / 'exec1' / 'deploy.approved.json'
    assert marker.exists()
    saved = json.loads(marker.read_text(encoding='utf-8'))
    assert saved['approvedBy'] == 'Tester'
    assert saved['note'] == 'Reviewed payload'
    assert result['nodeId'] == 'deploy'


def test_phase4_execution_comparison_reports_status_and_timing_delta(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    manager = ExecutionManager(store)
    store.save_execution('left', {"id":"left","configuration_id":"c","status":"PASS","elapsedMs":1000,"events":[{"type":"node.completed","nodeId":"doc","verdict":{"verdict":"PASS","outcome":"WORKED"},"timing":{"totalMs":400},"output":{"id":1}}]})
    store.save_execution('right', {"id":"right","configuration_id":"c","status":"PASS","elapsedMs":1600,"events":[{"type":"node.completed","nodeId":"doc","verdict":{"verdict":"PASS","outcome":"EXISTING"},"timing":{"totalMs":700},"output":{"id":1}}]})
    result = manager.compare('left','right')
    assert result['elapsedMsDelta'] == 600
    assert result['nodes'][0]['totalMsDelta'] == 300
    assert result['nodes'][0]['statusChanged'] is True


def test_phase4_publish_tracks_cancel_and_approval_states(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    config = _config(store)
    manager = ExecutionManager(store)
    store.save_execution('exec1', {"id":"exec1","configuration_id":config['id'],"status":"RUNNING","events":[]})
    loop = asyncio.new_event_loop()
    try:
        manager._publish('exec1', {"type":"node.awaiting_approval","nodeId":"deploy"}, loop)
        assert store.get_execution('exec1')['status'] == 'WAITING_APPROVAL'
        manager._publish('exec1', {"type":"node.approval_received","nodeId":"deploy"}, loop)
        assert store.get_execution('exec1')['status'] == 'RUNNING'
        manager._publish('exec1', {"type":"execution.cancelled","reason":"test"}, loop)
        assert store.get_execution('exec1')['status'] == 'CANCELLED'
    finally:
        loop.close()


def test_phase4_worker_contains_checkpoint_resume_and_approval_gate():
    root = Path(__file__).resolve().parents[3]
    worker = (root / 'webapp/backend/app/legacy_worker.py').read_text(encoding='utf-8')
    assert 'node.awaiting_approval' in worker
    assert 'node.approval_received' in worker
    assert 'node.resumed' in worker
    assert 'resume_state' in worker
    assert 'HIP_NODE_APPROVAL_TIMEOUT_SECONDS' in worker


def test_phase4_react_has_operations_recovery_and_approval_controls():
    root = Path(__file__).resolve().parents[3]
    ops = (root / 'webapp/frontend/src/pages/OperationsPage.tsx').read_text(encoding='utf-8')
    flow = (root / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    node = (root / 'webapp/frontend/src/components/NodeInspector.tsx').read_text(encoding='utf-8')
    sidebar = (root / 'webapp/frontend/src/components/Sidebar.tsx').read_text(encoding='utf-8')
    assert 'Resume from checkpoint' in ops
    assert 'Compare verdicts and timing' in ops
    assert 'Stop LIVE' in flow
    assert 'AWAITING_APPROVAL' in flow
    assert 'Manual approval before LIVE API' in node
    assert "label:'Operations'" in sidebar
