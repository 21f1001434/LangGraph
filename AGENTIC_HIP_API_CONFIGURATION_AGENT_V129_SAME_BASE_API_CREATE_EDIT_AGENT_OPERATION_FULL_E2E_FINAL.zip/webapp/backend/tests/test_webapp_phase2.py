from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.main import app
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.phase2_service import configuration_evidence, learn_assistant_for, list_reports, read_report
from webapp.backend.app.storage import JsonStore


def _workspace(root: Path, customer: str = "CUSTOMER") -> Path:
    ws = root / "cfg"
    for name in ("input_files", "payloads", "reports", "knowledge", "dev_approved"):
        (ws / name).mkdir(parents=True, exist_ok=True)
    input_data = {
        "customer": customer,
        "direction": "Inbound",
        "tx_code": "850",
        "flow_type": "translation",
        "profile_name": f"{customer}_850",
        "objects": {
            "source_document_type": {"name": "SRC_XML", "data_format_type": "XML", "document_identifier": "PurchaseOrder"},
            "target_document_type": {"name": "TGT_XML", "data_format_type": "XML", "document_identifier": "PurchaseOrderCollection"},
            "biz_flow": {"flow_details": {"business_flow_name": f"{customer}_FLOW"}},
        },
        "_file_mapping": {
            "source": {"filename": "SRC_850.xml", "data_format_type": "XML", "document_identifier": "PurchaseOrder"},
            "target": {"filename": "TGT_850.xml", "data_format_type": "XML", "document_identifier": "PurchaseOrderCollection"},
            "fieldMappings": [
                {"file": "SRC_850.xml", "path": "objects.source_document_type.data_format_type", "rule": "physical_file_format"},
                {"file": "TGT_850.xml", "path": "objects.target_document_type.data_format_type", "rule": "physical_file_format"},
            ],
        },
        "_artifact_validation": {"blockers": [], "warnings": [], "matched": ["SRC_850.xml", "TGT_850.xml"]},
    }
    (ws / "input.json").write_text(json.dumps(input_data), encoding="utf-8")
    (ws / "input_files" / "SRC_850.xml").write_text("<PurchaseOrder/>", encoding="utf-8")
    (ws / "input_files" / "TGT_850.xml").write_text("<PurchaseOrderCollection/>", encoding="utf-8")
    return ws


def test_phase2_bootstrap_exposes_phase_and_mapping_learner():
    client = TestClient(app)
    data = client.get("/api/bootstrap").json()
    assert data["phase"] >= 2
    assert "mapping_learning" in data
    assert len(data["api_catalog"]) == 18


def test_phase2_evidence_keeps_physical_xml_format_separate_from_850(tmp_path: Path):
    evidence = configuration_evidence(_workspace(tmp_path))
    assert evidence["transactionCode"] == "850"
    assert evidence["fileMapping"]["source"]["data_format_type"] == "XML"
    assert evidence["documentTypes"]["source"]["format"] == "XML"
    assert evidence["fileMapping"]["target"]["data_format_type"] == "XML"


def test_phase2_learn_redacts_json_secrets_before_persistence(tmp_path: Path):
    ws = _workspace(tmp_path)
    assistant = learn_assistant_for(ws)
    record = assistant.ingest("call.json", json.dumps({"Authorization":"Bearer secret-token","client_secret":"abc","payload":{"name":"safe"}}).encode(), "application/json")
    stored = Path(record["storedPath"]).read_text(encoding="utf-8")
    assert "secret-token" not in stored
    assert '"abc"' not in stored
    assert "safe" in stored


def test_phase2_reports_are_configuration_scoped(tmp_path: Path):
    ws = _workspace(tmp_path)
    (ws / "reports" / "execution_timing_latest.json").write_text(json.dumps({"events":[{"stepKey":"map","totalStepSeconds":1.2}]}), encoding="utf-8")
    rows = list_reports(ws)
    assert rows[0]["name"] == "execution_timing_latest.json"
    report = read_report(ws, rows[0]["name"])
    assert report["content"]["events"][0]["stepKey"] == "map"


def test_phase2_global_parallel_queue_accepts_different_configuration_workspaces(tmp_path: Path):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    validation = {"ok": True, "generatedAt": "now", "mapper": {"ok": True}, "requests": {"ok": True, "validCount": 18, "total": 18}, "mcpSupervisor": {"valid": True}}
    ws1 = _workspace(tmp_path / "one", "ALPHA")
    ws2 = _workspace(tmp_path / "two", "BETA")
    one = manager.queue_configuration({"id":"one","workspace":str(ws1),"customer":"ALPHA","name":"A"}, validation)
    two = manager.queue_configuration({"id":"two","workspace":str(ws2),"customer":"BETA","name":"B"}, validation)
    rows = manager.list_queue()
    assert {x["jobId"] for x in rows} == {one["jobId"], two["jobId"]}
    assert all(x["ready"] for x in rows)
    assert one["workspace"] != two["workspace"]


def test_phase2_uhal_demo_creates_isolated_instances(tmp_path: Path):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    ws = _workspace(tmp_path / "uhal", "U-HAUL")
    data = json.loads((ws / "input.json").read_text())
    data["profile_name"] = "U-HAUL ASN 856"
    data["direction"] = "Outbound"
    data["tx_code"] = "856"
    (ws / "input.json").write_text(json.dumps(data), encoding="utf-8")
    validation = {"ok": True, "mapper": {"ok": True}, "requests": {"ok": True, "validCount": 18, "total": 18}}
    rows = manager.create_demo_instances({"id":"uhal","workspace":str(ws),"customer":"U-HAUL","name":"U-HAUL ASN"}, validation, 3)
    assert len(rows) == 3
    assert [x["demoInstance"] for x in rows] == [1,2,3]
    assert len({x["workspace"] for x in rows}) == 3


def test_phase2_react_pages_replace_phase1_placeholders():
    root = Path(__file__).resolve().parents[3]
    app_source = (root / "webapp" / "frontend" / "src" / "App.tsx").read_text(encoding="utf-8")
    assert "ParallelPage" in app_source
    assert "LearnPage" in app_source
    assert "ReportsPage" in app_source
    assert "PlaceholderPage" not in app_source
    parallel = (root / "webapp" / "frontend" / "src" / "pages" / "ParallelPage.tsx").read_text(encoding="utf-8")
    assert "RUN LIVE EXECUTION" in parallel
    assert "parallel instances" in parallel


def test_phase2_worker_supports_non_mutating_validation_mode():
    root = Path(__file__).resolve().parents[3]
    worker = (root / "webapp" / "backend" / "app" / "legacy_worker.py").read_text(encoding="utf-8")
    assert 'MODE == "validate"' in worker
    assert "run_local_request_checks" in worker
