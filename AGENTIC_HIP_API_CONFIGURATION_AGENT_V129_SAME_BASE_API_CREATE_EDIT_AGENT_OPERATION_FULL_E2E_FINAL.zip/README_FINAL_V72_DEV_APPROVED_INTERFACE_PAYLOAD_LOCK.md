# V72 — Developer-Approved Interface Payload Lock

## Release rule

The 18 HIP API request structures are immutable. Customer onboarding changes values only.

- **SFTP / FTP**: keep the final U-HAUL + developer-tested FILE request attributes.
- **HTTPS / REST**: keep the exact developer-shared HTTPS Sender and Receiver `interfaceDetails.parameters` attributes.
- **HTTPS-AS2**: keep the approved HIP AS2 Sender/Source and Receiver/Target parameter attributes.
- No LLM, file extractor, customer JSON, payload override, Flow Game mapping, API Testing edit, or Execute run may add/rename/remove/re-nest a LIVE payload attribute.
- A concrete interface with no registered developer-approved template is **BLOCKED** from the 18-API LIVE path. It is not silently projected onto SFTP/FTP attributes.

## HTTPS Sender — fixed attributes

`Protocol`, `HIP URL`, `Proxy URI`, `Request Method`, `Request Format`, `Sender Authentication Type`, `Are Input Files Compressed?`, `Sender Grant Type`.

## HTTPS Receiver — fixed attributes

`Protocol`, `Partner URL`, `Request Method`, `Request Format`, `Receiver Authentication Type`, `Gateway URL`, `SSL Certificate`, `Are Input Files Compressed?`, `SSL Certificate CN - Expiry`, `Receiver Grant Type`, `Receiver Token Endpoint`, `Receiver Client Id`, `Receiver Client Secret`, `SSL Certificate Id`.

Secure values remain runtime values/placeholders. The package never needs to hard-code a customer secret.

## HTTPS-AS2 Source/Sender — fixed attributes

`Partner Verification Certificate`, `AS2 URL`, `Partner Verification Certificate Id`, `Dell Identifier`, `Interface Environment`, `Partner Identifier`, `Request Method`, `Are SSL and Partner Verification Certificates identical?`, `Partner Verification Certificate CN – Expiry`.

## HTTPS-AS2 Target/Receiver — fixed attributes

`Encryption Certificate`, `Asynchronous MDN Required`, `Encryption Certificate CN – Expiry`, `Signing Algorithm`, `Dell Identifier`, `Interface Environment`, `Encryption Certificate Id`, `Partner URL`, `Partner Identifier`, `Is Compression Required`, `Request Method`, `Encryption Algorithm`.

## FILE (SFTP / FTP) — fixed attributes

`Interface Environment`, `File Filtering Pattern`, `Post Transfer Action`, `Is Compression Required`, `Use Existing Folder`, `Existing Account`, `Subscription Folder`, `Existing Account Name`.

## Enforcement points

The same interface-aware structure lock is used by generated requests, payload override migration/save, API Testing, Flow Game, individual block execution, Execute single/multi-customer snapshots, and the final pre-LIVE request lock.

Old workspaces are migrated by interface family. For example, a Legrand HTTPS override that accidentally contains `Existing Account Name` or a made-up field is stripped/rejected rather than sent to HIP.

## Regression guarantees

V72 verifies:

1. Exact FILE/HTTPS/HTTPS-AS2 source and target key sets.
2. Dev-approved HTTPS Sender and Receiver keys are not mixed with SFTP fields.
3. HTTPS-AS2 source and target shapes are distinct and fixed.
4. Arbitrary customer/LLM keys are removed from generated data and rejected from manual overrides.
5. Old HTTPS overrides migrate using the HTTPS schema rather than the historical FILE schema.
6. Unsupported custom interface types are blocked from LIVE until a dev-approved template is registered.
7. U-HAUL FILE/SFTP effective requests remain identical to V71 across all 18 API steps.
