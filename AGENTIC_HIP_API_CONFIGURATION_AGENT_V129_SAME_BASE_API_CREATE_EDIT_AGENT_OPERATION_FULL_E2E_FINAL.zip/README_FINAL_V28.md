# HIP Application Studio V28 — Multi-Source Input Learning + Strict Flow Policies

V28 is the consolidated live-only HIP solution. Every onboarding path converges to a canonical `input.json` plus the customer supporting files, which are then mapped to the 18 HIP APIs.

## Supported onboarding paths

1. **Customer files only** — XML/EDI/TXT/XBM/JAR/etc.; the agent generates `input.json`.
2. **Configuration Manual + customer files** — the manual provides structured values and the files cross-check/fill evidence; the agent generates `input.json`.
3. **Existing `input.json` + supporting files** — ZIP or individual files; explicit JSON values are authoritative and artifacts fill blanks/cross-check evidence.
4. **User request / business instructions** — explicit natural-language values are parsed deterministically first, optionally mapped by Dell AIA on a strict allow-list, and recorded in the audit trail.

## Flow policy

- **Passthrough (default):** one Source Document Type reused by the target transport, no separate Target Document Type Create, no Data Map, no Mapping Rule and no Mapping Transformer. A separate target Document Type is supported only when the user explicitly enables the exception.
- **Translation:** requires a distinct target Document Type and mapping evidence (XBM/JAR/data map/rule); the Business Flow includes Mapping Transformer. Partial mapping evidence stays Translation so the agent asks for the missing artifact/value instead of silently downgrading the flow.

All prior functionality remains: mandatory `hip-automation`, all 18 APIs, Scratch/API Flow Game, interactive graphs, Easy Payload Editor, API Testing Area, Learn + Dell AIA vision, OAuth/readiness fixes, PASS/EXISTING/BLOCKED analysis, live-only execution, DUNS/certificate prerequisites and ZIP safety.

## Verified release checks

- 84 pytest tests passed
- 57/57 standard validator PASS
- 60/60 adaptive validator PASS
- 32/32 required final self-checks PASS
