# V59 — Completely Ignore `workType` Object

Latest HIP developer guidance supersedes V58: the agent must not supply any part of `workType`. HIP/backend code derives the complete object internally.

## Behavior
- Flow Orchestration Create omits `workType`.
- Flow Orchestration Deploy omits `workType`.
- TP orchestration/work-order payload helpers do not add `workType`.
- The API contract validator no longer requires `workType`, `workType.id`, `workType.type`, or description. It rejects `workType` on the reviewed orchestration requests so stale overrides cannot reintroduce it.
- Input/config missing-value logic never asks the user for work-type values.
- `config_overrides.json` and the U-HAUL approved config no longer store `workTypes`.
- Legacy configs containing `workTypes` are accepted but the field is stripped/ignored.
- Mapping lineage, reports, and legacy UI no longer display work-type IDs or labels.

## Validation
- Pytest: 215/215 PASS
- Package validation: 57/57 PASS
- Adaptive validation: 60/60 PASS
- Final self-check: required checks PASS
- Final release validation: 16/16 PASS
- U-HAUL: all 18 request contracts pass with no `workType` object in Flow Create/Deploy.
