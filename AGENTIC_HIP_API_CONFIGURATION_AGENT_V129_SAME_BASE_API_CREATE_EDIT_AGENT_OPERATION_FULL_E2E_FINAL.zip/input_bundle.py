from __future__ import annotations

import io
import json
import shutil
import stat
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Dict, List, Tuple

MAX_ZIP_FILES = 250
MAX_SINGLE_FILE_BYTES = 100 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED_BYTES = 300 * 1024 * 1024


ACTIVE_STATE_FILES = (
    "input.json",
    "config_overrides.json",
    "api_execution_plan.json",
    "payload_overrides.json",
    "scratch_flow.json",
    "knowledge/graph/hip_knowledge_graph.sqlite3",
)


def backup_active_state(root: Path, backup_root: Path) -> Dict[str, Any]:
    """Create a rollback snapshot for input bundle activation.

    The upload flow mutates input_files plus several active JSON files. Keeping a
    short-lived backup makes activation transactional: a failure while deriving
    config or rebuilding Scratch cannot leave half of the old package and half
    of the new package active.
    """
    root = Path(root)
    backup_root = Path(backup_root)
    backup_root.mkdir(parents=True, exist_ok=True)
    files_dir = backup_root / "files"
    files_dir.mkdir(parents=True, exist_ok=True)
    existed: Dict[str, bool] = {}
    for name in ACTIVE_STATE_FILES:
        src = root / name
        existed[name] = src.exists()
        if src.is_file():
            saved = files_dir / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, saved)
    src_inputs = root / "input_files"
    existed["input_files"] = src_inputs.exists()
    if src_inputs.exists():
        shutil.copytree(src_inputs, backup_root / "input_files", dirs_exist_ok=True)
    meta = {"existed": existed}
    (backup_root / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def restore_active_state(root: Path, backup_root: Path) -> None:
    root = Path(root)
    backup_root = Path(backup_root)
    meta_path = backup_root / "meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {"existed": {}}
    existed = meta.get("existed") if isinstance(meta, dict) else {}
    existed = existed if isinstance(existed, dict) else {}
    files_dir = backup_root / "files"
    for name in ACTIVE_STATE_FILES:
        dst = root / name
        saved = files_dir / name
        if saved.is_file():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved, dst)
        elif not bool(existed.get(name)):
            dst.unlink(missing_ok=True)
    dst_inputs = root / "input_files"
    if dst_inputs.exists():
        shutil.rmtree(dst_inputs)
    saved_inputs = backup_root / "input_files"
    if saved_inputs.exists():
        shutil.copytree(saved_inputs, dst_inputs)
    elif bool(existed.get("input_files")):
        dst_inputs.mkdir(parents=True, exist_ok=True)


def parse_input_json_bytes(data: bytes) -> Dict[str, Any]:
    try:
        value = json.loads(data.decode("utf-8-sig"))
    except Exception as exc:
        raise ValueError(f"input.json is not valid JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("input.json must contain one JSON object at the top level.")
    return value


def _safe_zip_member(info: zipfile.ZipInfo) -> Tuple[str, str]:
    raw = str(info.filename or "").replace("\\", "/")
    path = PurePosixPath(raw)
    if info.is_dir():
        return "", "directory"
    if not raw or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"Unsafe ZIP path is not allowed: {raw!r}")
    # Unix symlink bit can be stored in the upper 16 bits of external_attr.
    unix_mode = (info.external_attr >> 16) & 0xFFFF
    if unix_mode and stat.S_ISLNK(unix_mode):
        raise ValueError(f"Symbolic links are not allowed in the input ZIP: {raw}")
    basename = path.name.strip()
    if not basename or basename in {".", ".."}:
        raise ValueError(f"Invalid ZIP member name: {raw!r}")
    return basename, raw


def inspect_input_zip(data: bytes) -> Dict[str, Any]:
    if not data:
        raise ValueError("The input ZIP is empty.")
    try:
        zf = zipfile.ZipFile(io.BytesIO(data), "r")
    except Exception as exc:
        raise ValueError(f"The uploaded input file is not a readable ZIP: {exc}") from exc

    rows: List[Dict[str, Any]] = []
    seen_basenames: Dict[str, str] = {}
    total = 0
    with zf:
        bad = zf.testzip()
        if bad:
            raise ValueError(f"The ZIP is corrupt. First failing member: {bad}")
        infos = zf.infolist()
        file_infos = [x for x in infos if not x.is_dir()]
        if len(file_infos) > MAX_ZIP_FILES:
            raise ValueError(f"ZIP contains {len(file_infos)} files; maximum supported is {MAX_ZIP_FILES}.")
        for info in file_infos:
            basename, original = _safe_zip_member(info)
            if not basename:
                continue
            if info.flag_bits & 0x1:
                raise ValueError(f"Encrypted ZIP members are not supported: {original}")
            if info.file_size > MAX_SINGLE_FILE_BYTES:
                raise ValueError(f"ZIP member is too large: {original} ({info.file_size} bytes)")
            total += int(info.file_size or 0)
            if total > MAX_TOTAL_UNCOMPRESSED_BYTES:
                raise ValueError(
                    f"ZIP expands beyond the {MAX_TOTAL_UNCOMPRESSED_BYTES // (1024*1024)} MB safety limit."
                )
            collision_key = basename.lower()
            if collision_key in seen_basenames:
                raise ValueError(
                    "The ZIP contains duplicate file names in different folders: "
                    f"{seen_basenames[collision_key]!r} and {original!r}. "
                    "Rename one so the HIP input_files folder is unambiguous."
                )
            seen_basenames[collision_key] = original
            rows.append({
                "name": basename,
                "sourcePath": original,
                "sizeBytes": int(info.file_size or 0),
                "compressedBytes": int(info.compress_size or 0),
            })
    return {
        "valid": True,
        "fileCount": len(rows),
        "totalBytes": total,
        "files": rows,
        "containsInputJson": any(row["name"].lower() == "input.json" for row in rows),
    }


def extract_input_zip(data: bytes, destination: Path) -> Dict[str, Any]:
    """Safely replace destination contents with flattened ZIP files.

    HIP's existing runtime resolves JAR/XBM/XML assets as `input_files/<name>`, so
    nested ZIP folders are intentionally flattened to their base file names after
    duplicate-name validation.
    """
    destination = Path(destination)
    summary = inspect_input_zip(data)
    parent = destination.parent
    staging = parent / f".{destination.name}_staging_{uuid.uuid4().hex[:8]}"
    staging.mkdir(parents=True, exist_ok=False)
    try:
        with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                basename, _ = _safe_zip_member(info)
                if not basename:
                    continue
                with zf.open(info, "r") as src, (staging / basename).open("wb") as dst:
                    shutil.copyfileobj(src, dst, length=1024 * 1024)
        destination.mkdir(parents=True, exist_ok=True)
        for existing in destination.iterdir():
            if existing.is_dir():
                shutil.rmtree(existing)
            else:
                existing.unlink()
        for staged in staging.iterdir():
            shutil.move(str(staged), str(destination / staged.name))
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    return summary


def inspect_individual_files(file_pairs: List[Tuple[str, bytes]]) -> Dict[str, Any]:
    """Validate directly uploaded runtime files using the same safety limits as ZIP intake."""
    rows: List[Dict[str, Any]] = []
    seen: Dict[str, str] = {}
    total = 0
    if not file_pairs:
        raise ValueError('No related input files were uploaded.')
    if len(file_pairs) > MAX_ZIP_FILES:
        raise ValueError(f'Too many files: {len(file_pairs)}; maximum supported is {MAX_ZIP_FILES}.')
    for raw_name, raw in file_pairs:
        name = Path(str(raw_name or '')).name.strip()
        if not name or name in {'.', '..'}:
            raise ValueError(f'Invalid uploaded file name: {raw_name!r}')
        key = name.lower()
        if key in seen:
            raise ValueError(f'Duplicate uploaded file name: {name!r}')
        seen[key] = name
        size = len(raw or b'')
        if size > MAX_SINGLE_FILE_BYTES:
            raise ValueError(f'Uploaded file is too large: {name} ({size} bytes)')
        total += size
        if total > MAX_TOTAL_UNCOMPRESSED_BYTES:
            raise ValueError(f'Uploaded files exceed the {MAX_TOTAL_UNCOMPRESSED_BYTES // (1024*1024)} MB safety limit.')
        rows.append({'name': name, 'sourcePath': name, 'sizeBytes': size, 'compressedBytes': size})
    return {
        'valid': True,
        'fileCount': len(rows),
        'totalBytes': total,
        'files': rows,
        'containsInputJson': any(row['name'].lower() == 'input.json' for row in rows),
    }


def replace_input_files_from_pairs(file_pairs: List[Tuple[str, bytes]], destination: Path) -> Dict[str, Any]:
    """Transaction-friendly replacement for individually uploaded files."""
    summary = inspect_individual_files(file_pairs)
    destination = Path(destination)
    parent = destination.parent
    staging = parent / f'.{destination.name}_staging_{uuid.uuid4().hex[:8]}'
    staging.mkdir(parents=True, exist_ok=False)
    try:
        for name, raw in file_pairs:
            safe = Path(str(name)).name
            (staging / safe).write_bytes(raw)
        destination.mkdir(parents=True, exist_ok=True)
        for existing in destination.iterdir():
            if existing.is_dir():
                shutil.rmtree(existing)
            else:
                existing.unlink()
        for staged in staging.iterdir():
            shutil.move(str(staged), str(destination / staged.name))
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    return summary
