from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    studio = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    easy = (ROOT / "easy_studio.py").read_text(encoding="utf-8")
    report = (ROOT / "business_demo.py").read_text(encoding="utf-8")

    required_studio = [
        "✨ Easy Mode",
        "🧪 API Testing Area",
        "overflow-x:hidden!important",
        "backdrop-filter:blur(18px)",
        "@media(max-width:620px)",
        "easy-stage-track",
        "easy-glass",
        "render_easy_studio",
    ]
    for token in required_studio:
        assert token in studio, token

    required_easy = [
        "Hi! I can run the HIP configuration for you.",
        "You only need to make one choice at a time.",
        "First, choose the connection",
        "Here is what the agent will do",
        "Check everything for me",
        "Ready for the live run",
        "All live API calls are finished",
        "call all 18 live HIP APIs",
        "Download the complete request + response report",
    ]
    for token in required_easy:
        assert token in easy, token

    assert "st.dataframe" not in easy, "Easy Mode should avoid wide dataframes"
    assert "min-width:760px" in report
    assert "table-wrap" in report
    assert "Technical execution state — project team only" in report
    assert "backdrop-filter:blur(18px)" in report

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-glass-easy-studio-v14",
        "easyModeDefault": True,
        "oneStageAtATime": True,
        "responsiveGlassUi": True,
        "horizontalOverflowProtection": True,
        "businessReportResponsive": True,
        "technicalDetailsCollapsed": True,
        "apiTestingAreaPreserved": True,
    }
    path = ROOT / "examples" / "GLASS_EASY_STUDIO_UI_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
