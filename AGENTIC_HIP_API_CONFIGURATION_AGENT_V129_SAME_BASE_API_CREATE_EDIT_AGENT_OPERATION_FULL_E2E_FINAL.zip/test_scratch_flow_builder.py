from __future__ import annotations

import json
from pathlib import Path

from scratch_flow import (
    component_request,
    infer_flow_from_input,
    load_scratch_flow,
    new_component,
    normalize_flow,
    resolve_templates,
    save_scratch_flow,
)


def test_explicit_input_flow_can_repeat_document_type_four_times(tmp_path: Path):
    payloads = [{"name": f"DOC_{i}"} for i in range(1, 5)]
    flow, warnings = infer_flow_from_input({
        "api_flow": [{
            "stepKey": "doctype_source",
            "label": "Create Document Type",
            "repeat": 4,
            "payloads": payloads,
        }]
    })
    assert warnings == []
    assert len(flow["components"]) == 4
    assert [row["requestOverride"]["name"] for row in flow["components"]] == ["DOC_1", "DOC_2", "DOC_3", "DOC_4"]
    assert len({row["instanceId"] for row in flow["components"]}) == 4


def test_duplicate_step_keys_are_preserved(tmp_path: Path):
    rows = [new_component("doctype_source", label=f"Doc {i}") for i in range(4)]
    saved = save_scratch_flow(tmp_path, {"name": "Four docs", "components": rows})
    loaded = load_scratch_flow(tmp_path)
    assert len(saved["components"]) == 4
    assert len(loaded["components"]) == 4
    assert [row["stepKey"] for row in loaded["components"]] == ["doctype_source"] * 4


def test_empty_canvas_is_preserved():
    assert normalize_flow({"name": "Empty", "components": []})["components"] == []


def test_step_output_placeholder_resolution():
    value = {
        "documentTypeId": "{{steps.doc_a.documentTypeId}}",
        "mapId": "${runtime.map_id}",
        "label": "ID={{steps.doc_a.documentTypeId}}",
    }
    result = resolve_templates(value, {
        "runtime": {"map_id": 1670},
        "steps": {"doc_a": {"documentTypeId": 10483}},
    })
    assert result["documentTypeId"] == 10483
    assert result["mapId"] == 1670
    assert result["label"] == "ID=10483"


def test_navigation_compatibility_pages_exist_and_use_valid_page_paths():
    root = Path(__file__).resolve().parent
    agentic = root / "pages" / "10_Agentic_Interface_Studio.py"
    advanced = root / "pages" / "90_Advanced_Technical_Workspace.py"
    assert agentic.exists()
    assert advanced.exists()
    text = agentic.read_text(encoding="utf-8")
    assert 'safe_page_link(st, "pages/90_Advanced_Technical_Workspace.py"' in text
    assert 'st.page_link("90_Advanced_Technical_Workspace.py"' not in text
    assert 'st.page_link("hip_application_studio.py"' not in text
    assert "render_app_home_link(st)" in text


def test_drag_drop_template_creates_independent_instances_and_keeps_visual_order():
    from scratch_flow import drag_canvas_item, drag_palette_item, reconcile_drag_canvas

    first = new_component("account_source", label="Account first")
    second = new_component("system_source", label="System second")
    flow = {"name": "DnD", "components": [first, second]}

    visual = [
        drag_canvas_item(second, 2),
        drag_palette_item("doctype_source"),
        drag_palette_item("doctype_source"),
        drag_canvas_item(first, 1),
    ]
    updated, change = reconcile_drag_canvas(flow, visual)

    assert change["changed"] is True
    assert len(change["addedInstanceIds"]) == 2
    assert [row["stepKey"] for row in updated["components"]] == [
        "system_source", "doctype_source", "doctype_source", "account_source"
    ]
    doc_ids = [row["instanceId"] for row in updated["components"] if row["stepKey"] == "doctype_source"]
    assert len(doc_ids) == 2
    assert len(set(doc_ids)) == 2


def test_drag_drop_existing_instance_can_be_removed_by_leaving_canvas():
    from scratch_flow import drag_canvas_item, reconcile_drag_canvas

    first = new_component("account_source", label="Keep")
    second = new_component("system_source", label="Remove")
    flow = {"name": "DnD remove", "components": [first, second]}
    updated, change = reconcile_drag_canvas(flow, [drag_canvas_item(first, 1)])

    assert [row["instanceId"] for row in updated["components"]] == [first["instanceId"]]
    assert change["removedInstanceIds"] == [second["instanceId"]]


def test_drag_drop_four_document_type_blocks_can_be_created():
    from scratch_flow import drag_palette_item, reconcile_drag_canvas

    token = drag_palette_item("doctype_source")
    updated, change = reconcile_drag_canvas({"name": "Four docs", "components": []}, [token, token, token, token])
    assert len(updated["components"]) == 4
    assert [row["stepKey"] for row in updated["components"]] == ["doctype_source"] * 4
    assert len({row["instanceId"] for row in updated["components"]}) == 4
    assert len(change["addedInstanceIds"]) == 4


def test_drag_drop_dependency_is_declared():
    root = Path(__file__).resolve().parent
    req = (root / "requirements_legacy_streamlit.txt").read_text(encoding="utf-8")
    assert "streamlit-sortables==0.3.1" in req
