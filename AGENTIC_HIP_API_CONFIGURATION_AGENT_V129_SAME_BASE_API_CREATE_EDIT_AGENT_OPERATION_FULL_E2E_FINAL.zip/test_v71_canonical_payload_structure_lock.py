import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from canonical_payload_contract import (
    canonical_request_kind,
    catalog_summary,
    lock_request_value,
    step_contract,
    validate_override_structure,
)
from payload_overrides import PayloadOverrideStore, save_override
from run_agent import Runner
from scratch_flow import component_request, new_component

ROOT = Path(__file__).resolve().parent


def _shape(value):
    """Exact JSON attribute/nesting/cardinality signature, ignoring scalar values."""
    if isinstance(value, dict):
        return {key: _shape(child) for key, child in value.items()}
    if isinstance(value, list):
        return [_shape(child) for child in value]
    return "<value>"


def _request_body(row):
    kind = row.get("requestKind") or "payload"
    return row.get(kind) or {}


def test_v71_has_exactly_18_frozen_request_shapes_and_uhal_preview_matches_them():
    summary = catalog_summary()
    assert summary["stepCount"] == 18
    assert "U-HAUL" in summary["reference"]

    runner = Runner(llm_enabled=False)
    seen = []
    for step_key in (step_contract(k).get("stepKey", k) for k in json.loads((ROOT / "schemas/uhal_canonical_18_request_shapes.json").read_text(encoding="utf-8"))["steps"]):
        req = runner.preview_step_request(step_key)
        if req.get("applicable") is False:
            continue
        kind = canonical_request_kind(step_key)
        body = req.get(kind) or {}
        locked, meta = lock_request_value(step_key, kind, body, fallback=None, strict_unknown=True)
        assert locked == body, (step_key, meta)
        assert not meta["droppedPaths"], (step_key, meta)
        assert not meta["neutralFilledPaths"], (step_key, meta)
        seen.append(step_key)
    assert len(seen) == 18


def test_v71_unknown_payload_attribute_is_rejected_at_save_time(tmp_path: Path):
    with pytest.raises(ValueError, match="CANONICAL_PAYLOAD_STRUCTURE_LOCK"):
        save_override(
            tmp_path,
            "partner_target",
            {"name": "LEGRAND", "wrongPartnerAttribute": "must-not-be-sent"},
            request_kind="payload",
            mode="merge",
            edit_origin="USER",
        )
    assert not (tmp_path / "payload_overrides.json").exists()


def test_v71_legacy_legrand_wrong_attributes_are_auto_migrated_out(tmp_path: Path):
    old = {
        "version": 1,
        "overrides": {
            "source_tp": {
                "enabled": True,
                "requestKind": "payload",
                "mode": "merge",
                "value": {
                    "operation": "Create",
                    "wrongTopLevel": "BAD",
                    "transportProfileDetails": [{
                        "transportProfileName": "SFTP_LEGRAND_ASN_PC_SRC_IB",
                        "wrongNested": "BAD",
                        "interfaceDetails": [{
                            "interfaceType": "SFTP HAFT",
                            "interfaceRole": "Primary",
                            "parameters": {
                                "Subscription Folder": "/SFTP_LEGRAND_ASN_PC_SRC_IB",
                                "wrongParam": "BAD",
                            },
                        }],
                    }],
                },
            }
        },
    }
    (tmp_path / "payload_overrides.json").write_text(json.dumps(old, indent=2), encoding="utf-8")
    store = PayloadOverrideStore(tmp_path)
    row = store.get("source_tp")
    dumped_value = json.dumps((row or {}).get("value") or {}, ensure_ascii=False)
    assert "wrongTopLevel" not in dumped_value
    assert "wrongNested" not in dumped_value
    assert "wrongParam" not in dumped_value
    assert "SFTP_LEGRAND_ASN_PC_SRC_IB" in dumped_value
    assert store.data["structureLockMigration"]["version"] >= 71
    dropped = json.dumps(store.data["structureLockMigration"]["rows"], ensure_ascii=False)
    assert "wrongTopLevel" in dropped
    assert "wrongNested" in dropped
    assert "wrongParam" in dropped


def test_v71_replace_mode_changes_values_not_attribute_set():
    runner = Runner(llm_enabled=False)
    generated = runner.preview_step_request("account_source")["payload"]
    candidate = {"accountName": "LEGRAND_ACCOUNT"}
    locked, meta = lock_request_value(
        "account_source", "payload", candidate, fallback=generated, strict_unknown=True
    )
    assert list(locked) == list(generated)
    assert locked["accountName"] == "LEGRAND_ACCOUNT"
    assert locked["description"] == generated["description"]
    assert locked["domains"] == generated["domains"]
    assert "description" in meta["filledFromGeneratedPaths"]
    assert "domains" in meta["filledFromGeneratedPaths"]


def test_v71_flow_definition_inner_json_attributes_are_also_locked():
    runner = Runner(llm_enabled=False)
    flow = runner.preview_step_request("flow_create")["payload"]
    changed = json.loads(json.dumps(flow))
    inner = json.loads(changed["flowDefinition"])
    inner["wrongLegrandFlowAttribute"] = "BAD"
    changed["flowDefinition"] = json.dumps(inner)
    result = validate_override_structure("flow_create", "payload", changed)
    assert not result["valid"]
    assert any("wrongLegrandFlowAttribute" in e["field"] for e in result["errors"])


def test_v71_flow_game_rejects_manual_noncanonical_payload_attribute():
    runner = Runner(llm_enabled=False)
    component = new_component(
        "account_source",
        request_override={"accountName": "LEGRAND", "newWrongAttribute": "BAD"},
        override_mode="merge",
    )
    with pytest.raises(ValueError, match="IMMUTABLE_DEVELOPER_APPROVED_18_API_CONTRACT"):
        component_request(runner, component)


def test_v71_legrand_like_workspace_preview_keeps_all_18_uhal_structures(tmp_path: Path):
    # Exercise the same subprocess preview route used by the web application,
    # not only the pure structure helper. The synthetic customer intentionally
    # contains attributes that older generic-interface code could have passed
    # through. V71 must remove them from every effective request while keeping
    # LEGRAND values in canonical fields.
    data = json.loads((ROOT / "input.json").read_text(encoding="utf-8"))
    data["customer"] = "LEGRAND"
    data["folder"] = "/Outbound/ASN"
    data["objects"]["source_transport_profile"].update({
        "profile_name": "SFTP_LEGRAND_ASN_PC_SRC_IB",
        "subscription_folder": "/SFTP_LEGRAND_ASN_PC_SRC_IB",
        "interface_type": "SFTP HAFT",
        "interface_parameters": {"Queue Manager": "QM-LEGRAND", "wrongParam": "BAD"},
    })
    data["objects"]["target_transport_profile"].update({
        "profile_name": "SFTP_LEGRAND_ASN_PC_TGT_OB",
        "subscription_folder": "/Outbound/ASN",
    })
    for obj_key in ("source_document_type", "target_document_type"):
        obj = data["objects"].get(obj_key) or {}
        if isinstance(obj.get("name"), str):
            obj["name"] = obj["name"].replace("U-HAUL", "LEGRAND")
    (tmp_path / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    if (ROOT / "config_overrides.json").exists():
        shutil.copy2(ROOT / "config_overrides.json", tmp_path / "config_overrides.json")

    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(tmp_path)
    env["PYTHONUTF8"] = "1"
    proc = subprocess.run(
        [sys.executable, str(ROOT / "webapp/backend/app/legacy_worker.py"), "preview", str(tmp_path)],
        cwd=str(ROOT), env=env, text=True, encoding="utf-8", capture_output=True, timeout=60,
    )
    assert proc.returncode == 0, proc.stderr
    payload = json.loads(proc.stdout)
    rows = {row["stepKey"]: row for row in payload["items"] if not row.get("error")}
    assert len(rows) == 18, payload

    uhal = Runner(llm_enabled=False)
    for step_key, row in rows.items():
        ref = uhal.preview_step_request(step_key)
        if row.get("applicable") is False or ref.get("applicable") is False:
            continue
        assert row["requestKind"] == ref["requestKind"]
        assert _shape(_request_body(row)) == _shape(_request_body(ref)), step_key
        dumped = json.dumps(_request_body(row), ensure_ascii=False)
        assert "wrongParam" not in dumped
        assert "Queue Manager" not in dumped

    source_tp = rows["source_tp"]["payload"]["transportProfileDetails"][0]
    target_tp = rows["target_tp"]["payload"]["transportProfileDetails"][0]
    assert source_tp["transportProfileName"] == "SFTP_LEGRAND_ASN_PC_SRC_IB"
    assert target_tp["transportProfileName"] == "SFTP_LEGRAND_ASN_PC_TGT_OB"
    assert source_tp["interfaceDetails"][0]["parameters"]["Subscription Folder"] == "/SFTP_LEGRAND_ASN_PC_SRC_IB"
    assert target_tp["interfaceDetails"][0]["parameters"]["Subscription Folder"] == "/Outbound/ASN"



def test_v71_flow_edge_mapping_can_only_target_existing_canonical_attribute():
    from webapp.backend.app.flow_engine import compile_flow
    runner = Runner(llm_enabled=False)
    preview = {
        "items": [
            runner.preview_step_request("account_source"),
            runner.preview_step_request("partner_target"),
        ]
    }
    flow = {
        "nodes": [
            {"id": "a", "api_key": "account_source", "enabled": True},
            {"id": "p", "api_key": "partner_target", "enabled": True},
        ],
        "edges": [{
            "id": "e1", "source": "a", "target": "p",
            "mappings": [{"from": "output.accountName", "to": "payload.wrongLegrandAttribute"}],
        }],
    }
    compiled = compile_flow(flow, ["account_source", "partner_target"], preview)
    assert any(e.get("code") == "NON_CANONICAL_MAPPING_TARGET" for e in compiled.get("errors") or [])

    flow["edges"][0]["mappings"][0]["to"] = "payload.name"
    compiled_ok = compile_flow(flow, ["account_source", "partner_target"], preview)
    assert not any(e.get("code") == "NON_CANONICAL_MAPPING_TARGET" for e in compiled_ok.get("errors") or [])

def test_v71_worktype_is_still_hip_owned_and_stripped_before_structure_validation(tmp_path: Path):
    # V71 must not regress the V60 developer requirement: workType is not a
    # customer attribute. Legacy/user edits may contain it, but it is stripped.
    save_override(
        tmp_path,
        "flow_create",
        {"flowName": "LEGRAND_FLOW", "workType": {"id": 9999, "type": "BAD"}},
        request_kind="payload",
        mode="merge",
        edit_origin="USER",
    )
    row = PayloadOverrideStore(tmp_path).get("flow_create")
    assert "workType" not in (row or {}).get("value", {})
