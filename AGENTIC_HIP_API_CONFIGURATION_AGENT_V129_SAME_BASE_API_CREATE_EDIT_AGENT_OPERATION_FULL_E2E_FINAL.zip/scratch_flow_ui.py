from __future__ import annotations

import json
import re
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from execution_flow import STEP_DEFINITIONS
from payload_ui_helpers import (
    apply_quick_field_change,
    display_json_value,
    json_field_paths,
    parse_json_value,
    safe_request_for_ui,
)
from production_guard import redact_sensitive
from run_agent import Runner
from interactive_graphs import mission_flow_figure, execution_latency_figure
from scratch_flow import (
    SCRATCH_REPORT_HTML,
    SCRATCH_REPORT_JSON,
    component_request,
    drag_canvas_item,
    drag_palette_item,
    infer_flow_from_input,
    load_scratch_flow,
    new_component,
    parse_drag_item,
    reconcile_drag_canvas,
    reset_scratch_flow,
    save_scratch_flow,
)


def _load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _component_options() -> Dict[str, str]:
    out: Dict[str, str] = {}
    for key, meta in STEP_DEFINITIONS.items():
        group = str(meta.get("group") or "Other")
        label = str(meta.get("label") or key)
        out[f"{group} · {label}"] = key
    return out


def _save_and_rerun(root: Path, flow: Dict[str, Any], message: str = "") -> None:
    save_scratch_flow(root, flow)
    if message:
        st.session_state["scratch_notice"] = message
    st.rerun()


def _move(flow: Dict[str, Any], index: int, delta: int) -> None:
    rows = flow["components"]
    target = index + delta
    if 0 <= target < len(rows):
        rows[index], rows[target] = rows[target], rows[index]


def _report_table(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows = []
    for item in report.get("steps") or []:
        result = item.get("result") or {}
        verdict = item.get("agentVerdict") or {}
        rows.append({
            "#": item.get("order"),
            "Component": item.get("label"),
            "Instance": item.get("instanceId"),
            "HTTP": result.get("status_code") if result.get("status_code") is not None else "—",
            "Technical": result.get("classification") or "—",
            "Agent verdict": verdict.get("verdict") or "BLOCKED",
            "Outcome": verdict.get("outcome") or "",
            "Reason": verdict.get("reason") or "",
        })
    return rows




_DRAG_STYLE = r"""
.sortable-component {
    display: grid !important;
    grid-template-columns: minmax(300px, 0.9fr) minmax(470px, 1.55fr);
    gap: 20px;
    padding: 16px;
    border-radius: 26px;
    background:
      radial-gradient(circle at 12% 8%, rgba(72,156,255,.28), transparent 28%),
      radial-gradient(circle at 88% 12%, rgba(187,91,255,.24), transparent 30%),
      linear-gradient(145deg, #07172d, #0b2444 55%, #101633);
    border: 1px solid rgba(125,190,255,.25);
    box-shadow: 0 20px 55px rgba(5,20,45,.28), inset 0 0 0 1px rgba(255,255,255,.03);
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif;
}
.sortable-container {
    min-height: 480px;
    border: 2px solid rgba(125,190,255,.22);
    border-radius: 22px;
    background: rgba(5,18,40,.90);
    box-shadow: inset 0 0 24px rgba(65,149,255,.08), 0 12px 30px rgba(0,0,0,.20);
    overflow: hidden;
}
.sortable-container:first-child { border-color: rgba(103,176,255,.46); }
.sortable-container:nth-child(2) { border-color: rgba(126,255,169,.44); }
.sortable-container-header {
    position: sticky;
    top: 0;
    z-index: 2;
    padding: 16px 18px !important;
    background: linear-gradient(135deg, #1366d6, #7048e8) !important;
    color: #fff !important;
    font-weight: 900 !important;
    letter-spacing: .055em;
    text-transform: uppercase;
    text-shadow: 0 2px 8px rgba(0,0,0,.28);
    border-bottom: 1px solid rgba(255,255,255,.16);
}
.sortable-container:nth-child(2) .sortable-container-header {
    background: linear-gradient(135deg, #087a55, #13a267) !important;
}
.sortable-container-body {
    min-height: 410px;
    padding: 15px !important;
    background-image:
      linear-gradient(rgba(92,164,255,.06) 1px, transparent 1px),
      linear-gradient(90deg, rgba(92,164,255,.06) 1px, transparent 1px);
    background-size: 24px 24px;
}
.sortable-item, .sortable-item:hover {
    position: relative;
    margin: 10px 0 !important;
    padding: 14px 16px 14px 20px !important;
    border: 1px solid rgba(255,255,255,.24) !important;
    border-bottom: 4px solid rgba(0,0,0,.24) !important;
    border-radius: 16px 16px 16px 7px !important;
    background: linear-gradient(135deg, #2388ff, #2764d9) !important;
    color: #fff !important;
    font-weight: 850 !important;
    letter-spacing: .01em;
    text-shadow: 0 1px 3px rgba(0,0,0,.26);
    box-shadow: 0 8px 15px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.20);
    cursor: grab !important;
    user-select: none;
    transition: transform .13s ease, box-shadow .13s ease, filter .13s ease;
}
.sortable-item:hover {
    transform: translateY(-2px) scale(1.012);
    filter: brightness(1.07);
    box-shadow: 0 12px 20px rgba(0,0,0,.28), 0 0 0 2px rgba(255,255,255,.06);
}
.sortable-item:active { cursor: grabbing !important; transform: scale(.985); }
/* Scratch-like palette families: Validation / Foundation / Configuration / Orchestration / Verification */
.sortable-container:first-child .sortable-item:nth-child(-n+3) { background: linear-gradient(135deg,#2f80ed,#3157d7) !important; }
.sortable-container:first-child .sortable-item:nth-child(n+4):nth-child(-n+7) { background: linear-gradient(135deg,#e67e22,#f39c12) !important; }
.sortable-container:first-child .sortable-item:nth-child(n+8):nth-child(-n+11) { background: linear-gradient(135deg,#8e44ad,#b34bd5) !important; }
.sortable-container:first-child .sortable-item:nth-child(n+12):nth-child(-n+15) { background: linear-gradient(135deg,#16a085,#20b989) !important; }
.sortable-container:first-child .sortable-item:nth-child(n+16) { background: linear-gradient(135deg,#5c6f7b,#34495e) !important; }
/* Mission-track blocks stay bright and game-like regardless of order. */
.sortable-container:nth-child(2) .sortable-item { background: linear-gradient(135deg,#19a974,#0e8f62) !important; border-left: 7px solid #7dffb4 !important; }
@media (max-width: 860px) {
  .sortable-component { grid-template-columns: 1fr !important; padding: 10px; }
  .sortable-container { min-height: 300px; }
}
"""


HIP_API_BLOCK_COUNT = 18


def _effective_request_value(preview: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
    kind = str(preview.get("requestKind") or "payload")
    value = preview.get("params") if kind == "params" else preview.get("payload")
    return kind, deepcopy(value) if isinstance(value, dict) else {}


def _clear_payload_editor_state(instance_id: str) -> None:
    # Prevent old Streamlit widget values from overwriting a payload that was just
    # changed with the no-code editor/import actions. Quick-value keys include the
    # selected JSON path, so clear by prefix rather than by one exact key.
    prefixes = (
        f"scratch_override_{instance_id}",
        f"scratch_quick_value_{instance_id}_",
        f"scratch_payload_upload_{instance_id}",
    )
    for key in list(st.session_state.keys()):
        if any(str(key).startswith(prefix) for prefix in prefixes):
            st.session_state.pop(key, None)


def _persist_effective_payload(root: Path, flow: Dict[str, Any], index: int, component: Dict[str, Any],
                               *, request_kind: str, payload: Dict[str, Any], message: str) -> None:
    component["requestKind"] = request_kind if request_kind in {"payload", "params"} else "payload"
    component["overrideMode"] = "replace"
    component["requestOverride"] = deepcopy(payload)
    flow["components"][index] = component
    _clear_payload_editor_state(str(component.get("instanceId") or ""))
    _save_and_rerun(root, flow, message)


def _render_easy_payload_editor(root: Path, flow: Dict[str, Any], index: int, component: Dict[str, Any],
                                generated_preview: Dict[str, Any], preview_runner: Any) -> None:
    """Generic no-code payload editor that works for every API block."""
    instance_id = str(component.get("instanceId") or "")
    request_kind, effective = _effective_request_value(generated_preview)
    fields = [row for row in json_field_paths(effective) if str(row.get("type") or "") not in {"object", "array"}]

    st.markdown("#### ⚡ Easy Payload Editor")
    st.caption(
        "Human-user value-only editor. Pick an existing scalar field from the effective request, change only its value, and save. Attribute names/nesting stay locked. "
        "The complete request is preserved automatically. This works for POST payloads and GET query parameters."
    )
    m1, m2, m3 = st.columns(3)
    m1.metric("Editable fields", len(fields))
    m2.metric("Request type", request_kind.upper())
    m3.metric("Mode after quick edit", "REPLACE")

    search = st.text_input(
        "Find a payload field",
        placeholder="e.g. name, domain, documentTypeId, flowDetails, workOrderId",
        key=f"scratch_field_search_{instance_id}",
    ).strip().lower()
    filtered = [row for row in fields if not search or search in str(row.get("path") or "").lower()]
    if not filtered:
        st.info("No fields match that search. Clear the search to see the complete request.")
    else:
        path_options = [str(row.get("path")) for row in filtered]
        selected_path = st.selectbox(
            "Field", path_options, key=f"scratch_field_path_{instance_id}",
            help="Nested objects and arrays are shown with paths such as attributes[0].name.",
        )
        selected = next(row for row in filtered if str(row.get("path")) == selected_path)
        current_value = selected.get("value")
        value_type = str(selected.get("type") or "string")
        safe_path_key = re.sub(r"[^A-Za-z0-9]+", "_", selected_path).strip("_")[:90] or "root"
        quick_value_key = f"scratch_quick_value_{instance_id}_{safe_path_key}"
        st.caption(f"Current value type: **{value_type}** · Current value: `{display_json_value(current_value)[:500]}`")

        if value_type == "boolean":
            new_raw: Any = st.selectbox(
                "New value", [True, False], index=0 if bool(current_value) else 1,
                key=quick_value_key,
            )
        elif value_type == "integer":
            new_raw = st.number_input(
                "New value", value=int(current_value or 0), step=1,
                key=quick_value_key,
            )
        elif value_type == "number":
            new_raw = st.number_input(
                "New value", value=float(current_value or 0.0),
                key=quick_value_key,
            )
        else:
            new_raw = st.text_input(
                "New value", value="" if current_value is None else str(current_value),
                key=quick_value_key,
            )

        q1, q2 = st.columns(2)
        if q1.button("✓ Apply this field change", type="primary", width="stretch", key=f"scratch_quick_apply_{instance_id}"):
            try:
                parsed = parse_json_value(new_raw, value_type)
                updated = apply_quick_field_change(effective, selected_path, parsed)
                _persist_effective_payload(
                    root, flow, index, component, request_kind=request_kind, payload=updated,
                    message=f"Changed {selected_path} in {component.get('label') or component.get('stepKey')}."
                )
            except Exception as exc:
                st.error(f"Could not apply field change: {exc}")
        if q2.button("↺ Reset block to generated/Dev template", width="stretch", key=f"scratch_quick_reset_{instance_id}"):
            component["requestOverride"] = {}
            component["overrideMode"] = "merge"
            component["requestKind"] = ""
            flow["components"][index] = component
            _clear_payload_editor_state(instance_id)
            _save_and_rerun(root, flow, "Reset this block to its generated Dev-approved request.")

        with st.expander("🧲 Fill this field from input.json", expanded=False):
            input_data = _load_json(root / "input.json", {})
            input_fields = json_field_paths(input_data) if isinstance(input_data, dict) else []
            source_search = st.text_input(
                "Find input.json value",
                placeholder="Search source, target, account, partner, document type, flow...",
                key=f"scratch_input_search_{instance_id}_{safe_path_key}",
            ).strip().lower()
            matches = [row for row in input_fields if not source_search or source_search in str(row.get("path") or "").lower()]
            if matches:
                source_paths = [str(row.get("path")) for row in matches]
                source_path = st.selectbox(
                    "input.json field", source_paths,
                    key=f"scratch_input_path_{instance_id}_{safe_path_key}",
                )
                source_row = next(row for row in matches if str(row.get("path")) == source_path)
                source_value = source_row.get("value")
                st.caption(
                    f"Source value ({source_row.get('type')}): `{display_json_value(source_value)[:500]}` → "
                    f"target `{selected_path}` ({value_type})"
                )
                if str(source_row.get("type")) != value_type and value_type not in {"null", "string"}:
                    st.warning("The input.json value has a different type. Review the effective request after applying it.")
                if st.button("Use this input.json value", type="primary", width="stretch", key=f"scratch_use_input_{instance_id}_{safe_path_key}"):
                    try:
                        updated = apply_quick_field_change(effective, selected_path, source_value)
                        _persist_effective_payload(
                            root, flow, index, component, request_kind=request_kind, payload=updated,
                            message=f"Filled {selected_path} from input.json field {source_path}."
                        )
                    except Exception as exc:
                        st.error(f"Could not apply input.json value: {exc}")
            else:
                st.info("No matching input.json fields found.")

    with st.expander("📥 Copy / import payload", expanded=False):
        st.caption("Use another block as a starting point, or upload a complete JSON request for this block.")
        other_rows = [
            (i, row) for i, row in enumerate(flow.get("components") or [])
            if str(row.get("instanceId") or "") != instance_id
        ]
        if other_rows:
            labels = {
                f"{i + 1}. {row.get('label') or row.get('stepKey')} · {row.get('instanceId')}": (i, row)
                for i, row in other_rows
            }
            selected_source = st.selectbox("Copy effective request from", list(labels), key=f"scratch_copy_source_{instance_id}")
            if st.button("⧉ Copy payload into this block", width="stretch", key=f"scratch_copy_payload_{instance_id}"):
                try:
                    _, source_component = labels[selected_source]
                    source_preview = component_request(preview_runner, source_component, {})
                    source_kind, source_value = _effective_request_value(source_preview)
                    _persist_effective_payload(
                        root, flow, index, component, request_kind=source_kind, payload=source_value,
                        message=f"Copied the effective request from {source_component.get('label') or source_component.get('stepKey')}."
                    )
                except Exception as exc:
                    st.error(f"Could not copy payload: {exc}")
        else:
            st.caption("Add another block if you want to copy its payload.")

        uploaded_payload = st.file_uploader(
            "Upload JSON payload / params", type=["json"], key=f"scratch_payload_upload_{instance_id}"
        )
        if uploaded_payload is not None:
            try:
                imported = json.loads(uploaded_payload.getvalue().decode("utf-8-sig"))
                if not isinstance(imported, dict):
                    raise ValueError("Uploaded request must be a JSON object.")
                import_kind = st.radio(
                    "Imported request is", ["Payload", "Query params"],
                    index=0 if request_kind != "params" else 1, horizontal=True,
                    key=f"scratch_import_kind_{instance_id}",
                )
                if st.button("Use uploaded JSON for this block", type="primary", width="stretch", key=f"scratch_use_import_{instance_id}"):
                    _persist_effective_payload(
                        root, flow, index, component, request_kind="payload" if import_kind == "Payload" else "params",
                        payload=imported, message="Imported JSON into this Scratch block."
                    )
            except Exception as exc:
                st.error(f"Invalid JSON payload: {exc}")

def _drag_drop_notice(change: Dict[str, Any]) -> str:
    added = len(change.get("addedInstanceIds") or [])
    removed = len(change.get("removedInstanceIds") or [])
    parts = []
    if added:
        parts.append(f"added {added} new block{'s' if added != 1 else ''}")
    if removed:
        parts.append(f"removed {removed} block{'s' if removed != 1 else ''}")
    if not parts:
        parts.append("updated execution order")
    return "Drag-and-drop canvas " + " and ".join(parts) + "."


def _render_drag_drop_canvas(root: Path, flow: Dict[str, Any]) -> None:
    """Render the Scratch-like drag/drop palette and persist the visual order."""
    st.markdown("### 🕹️ HIP Flow Arcade")
    st.caption(
        "Pick a power-up from the API Block Deck and drag it onto the Mission Track. "
        "Move blocks up/down by dragging to change the live execution order; drag a mission block back to the deck to remove it. "
        "Every API card is reusable, so the same API can be dropped as many times as your mission needs."
    )
    try:
        from streamlit_sortables import sort_items
    except Exception:
        st.warning(
            "Drag-and-drop requires `streamlit-sortables==0.3.1`. Install/update dependencies with "
            "`pip install -r requirements.txt`. The button controls below remain available as a fallback."
        )
        return

    palette_header = "🎒 API BLOCK DECK · 18 REUSABLE POWER-UPS"
    canvas_header = "🏁 MISSION TRACK · START AT TOP → FINISH AT BOTTOM"
    palette_items = [drag_palette_item(key) for key in STEP_DEFINITIONS]
    canvas_items = [drag_canvas_item(row, index + 1) for index, row in enumerate(flow.get("components") or [])]
    containers = [
        {"header": palette_header, "items": palette_items},
        {"header": canvas_header, "items": canvas_items},
    ]
    result = sort_items(containers, multi_containers=True, custom_style=_DRAG_STYLE)
    if not isinstance(result, list):
        return

    canvas_result = None
    for container in result:
        if isinstance(container, dict) and str(container.get("header") or "") == canvas_header:
            canvas_result = container.get("items")
            break
    if canvas_result is None and len(result) > 1 and isinstance(result[1], dict):
        canvas_result = result[1].get("items")
    if not isinstance(canvas_result, list):
        return

    # Safety: never wipe a non-empty persisted canvas because a third-party
    # component transiently returned an empty result. A deliberate remove-all
    # action leaves HIP_INSTANCE markers in the palette, which is safe to honor.
    if flow.get("components") and not canvas_result:
        any_instance_marker = False
        for container in result:
            for item in (container.get("items") or []) if isinstance(container, dict) else []:
                kind, _ = parse_drag_item(item)
                if kind == "instance":
                    any_instance_marker = True
                    break
            if any_instance_marker:
                break
        if not any_instance_marker:
            return

    updated, change = reconcile_drag_canvas(flow, canvas_result)
    if change.get("changed"):
        save_scratch_flow(root, updated)
        st.session_state["scratch_notice"] = _drag_drop_notice(change)
        st.rerun()

    st.markdown("**🎯 Mission rule:** the top block runs first. Every successful live block earns a ✓; a blocker shows ⛔ and follows that block's Stop-if-BLOCKED rule.")
    st.caption(
        "Power move: for four Document Type creates, drag Source Document Type (or Target Document Type) "
        "onto the Mission Track four times. Each drop is an independent live block with its own payload and result."
    )


def render_scratch_flow_builder(root: Path, mcp: Any = None) -> None:
    root = Path(root)
    st.markdown("## 🎮 API Flow Game · Scratch-style Builder")
    st.caption(
        "Build the live HIP mission like a block game: drag API power-ups onto the Mission Track, stack repeats, "
        "change each block's payload independently, and run the track from START to FINISH. You can also generate the board from input.json."
    )

    notice = st.session_state.pop("scratch_notice", "")
    if notice:
        st.success(notice)
    for warning in st.session_state.pop("scratch_infer_warnings", []):
        st.warning(warning)

    flow = load_scratch_flow(root)

    enabled_count = sum(1 for row in (flow.get("components") or []) if row.get("enabled", True))
    repeated_types = len(flow.get("components") or []) - len({row.get("stepKey") for row in (flow.get("components") or [])})
    st.markdown(
        """
        <div style="padding:16px 18px;border-radius:20px;background:linear-gradient(135deg,#07172d,#102d52);border:1px solid rgba(100,180,255,.28);box-shadow:0 12px 30px rgba(5,20,45,.18);margin:8px 0 14px 0">
          <div style="font-size:.78rem;font-weight:900;letter-spacing:.12em;color:#78c6ff">LIVE MISSION BOARD</div>
          <div style="font-size:1.18rem;font-weight:850;color:white;margin-top:4px">START → Build your API combo → Review payloads → Run LIVE → FINISH</div>
          <div style="font-size:.82rem;color:#b9d8f6;margin-top:5px">Drag, stack, duplicate and reorder. The board is visual; execution follows the Mission Track exactly.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    gh1, gh2, gh3, gh4 = st.columns(4)
    gh1.metric("🎯 Mission blocks", len(flow.get("components") or []))
    gh2.metric("⚡ Enabled", enabled_count)
    gh3.metric("🧬 Repeated blocks", max(0, repeated_types))
    gh4.metric("🚀 Run mode", "LIVE")

    # Make full HIP API coverage obvious instead of leaving it implicit in the palette.
    coverage_count = len(STEP_DEFINITIONS)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("HIP APIs available", f"{coverage_count}/{HIP_API_BLOCK_COUNT}")
    c2.metric("Reusable blocks", "Unlimited")
    c3.metric("Payload editing", "Easy + JSON")
    c4.metric("Flow source", "Game board / input.json")
    if coverage_count != HIP_API_BLOCK_COUNT:
        st.error(f"API palette coverage mismatch: expected {HIP_API_BLOCK_COUNT}, found {coverage_count}.")

    st.markdown("### 🗺️ Interactive Game Map")
    st.caption("Hover a block for API details, drag the graph to pan, scroll to zoom, and use the toolbar to reset/download the view. The Mission Track below remains the editable drag/drop source of truth.")
    try:
        latest_report_for_map = _load_json(root / "reports" / SCRATCH_REPORT_JSON, {})
        st.plotly_chart(
            mission_flow_figure(flow, latest_report_for_map),
            use_container_width=True,
            config={"scrollZoom": True, "displaylogo": False, "responsive": True},
            key="scratch_interactive_mission_map",
        )
    except Exception as exc:
        st.warning(f"Interactive mission graph is unavailable: {exc}")
    with st.expander("See all 18 reusable HIP API blocks", expanded=False):
        api_rows = []
        for number, (key, meta) in enumerate(STEP_DEFINITIONS.items(), start=1):
            api_rows.append({
                "#": number,
                "Group": meta.get("group") or "Other",
                "API block": meta.get("label") or key,
                "Step key": key,
                "Reusable": "Yes",
                "Easy payload edit": "Yes",
            })
        st.dataframe(api_rows, hide_index=True, width="stretch")
        st.caption("Any of these 18 blocks can be dragged into the canvas multiple times and each copy keeps its own request.")

    top1, top2, top3, top4 = st.columns(4)
    if top1.button("↻ Standard flow", width="stretch", key="scratch_standard"):
        _save_and_rerun(root, reset_scratch_flow(root), "Standard HIP flow loaded into Scratch.")
    if top2.button("✨ Build from input.json", width="stretch", key="scratch_from_input"):
        input_data = _load_json(root / "input.json", {})
        try:
            request_builder = Runner(llm_enabled=False)
        except Exception:
            request_builder = None
        inferred, warnings = infer_flow_from_input(input_data, runner=request_builder)
        save_scratch_flow(root, inferred)
        st.session_state["scratch_infer_warnings"] = warnings
        st.session_state["scratch_notice"] = f"Built {len(inferred.get('components') or [])} component(s) from input.json."
        st.rerun()
    if top3.button("🧹 Clear canvas", width="stretch", key="scratch_clear"):
        save_scratch_flow(root, {"version": 2, "name": "Scratch Flow", "source": "manual", "components": []})
        st.session_state["scratch_notice"] = "Scratch canvas cleared."
        st.rerun()
    flow_bytes = json.dumps(flow, indent=2, ensure_ascii=False).encode("utf-8")
    top4.download_button("⬇ Flow JSON", flow_bytes, file_name="scratch_flow.json", mime="application/json", width="stretch")

    with st.expander("Import a Scratch Flow JSON", expanded=False):
        uploaded = st.file_uploader("Flow JSON", type=["json"], key="scratch_flow_upload")
        if uploaded is not None:
            try:
                candidate = json.loads(uploaded.getvalue().decode("utf-8"))
                if st.button("Use uploaded flow", type="primary", key="scratch_use_upload"):
                    save_scratch_flow(root, candidate)
                    st.session_state["scratch_notice"] = "Uploaded Scratch Flow loaded."
                    st.rerun()
            except Exception as exc:
                st.error(f"Invalid flow JSON: {exc}")

    _render_drag_drop_canvas(root, flow)

    with st.expander("⌨️ Button controls / accessibility fallback", expanded=False):
        st.caption("You can still add blocks without dragging. Reorder buttons are also available on every block below.")
        options = _component_options()
        a1, a2 = st.columns([4, 1])
        selected_label = a1.selectbox("Component", list(options), key="scratch_add_component")
        if a2.button("＋ Add", type="primary", width="stretch", key="scratch_add_button"):
            flow["components"].append(new_component(options[selected_label], source="manual"))
            _save_and_rerun(root, flow, f"Added {selected_label}.")

    st.info(
        "Every dropped copy is independent. Example: drop Document Type four times, then open each block "
        "and give it a different payload. The live runner executes the blocks exactly from top to bottom."
    )

    if not flow.get("components"):
        st.warning("The Scratch canvas is empty. Add a component or build it from input.json.")
    else:
        st.markdown(f"### 🏁 Mission block details · {len(flow['components'])} component(s)")

    # Request inspection builds the endpoint/generated request without invoking Runner.call().
    try:
        preview_runner = Runner(llm_enabled=False)
    except Exception as exc:
        preview_runner = None
        st.warning(f"Generated request previews are unavailable until the local configuration is readable: {exc}")

    for index, component in enumerate(list(flow.get("components") or [])):
        instance_id = component.get("instanceId")
        label = component.get("label") or STEP_DEFINITIONS.get(component.get("stepKey"), {}).get("label") or component.get("stepKey")
        group = STEP_DEFINITIONS.get(component.get("stepKey"), {}).get("group") or "Other"
        enabled_mark = "●" if component.get("enabled", True) else "○"
        with st.container(border=True):
            h1, h2, h3, h4, h5, h6 = st.columns([5, 1, 1, 1, 1, 1])
            h1.markdown(f"**{index + 1}. {label}**  \n`{group}` · `{component.get('stepKey')}` · `{instance_id}` · {enabled_mark}")
            if h2.button("↑", disabled=index == 0, key=f"scratch_up_{instance_id}", help="Move up"):
                _move(flow, index, -1)
                _save_and_rerun(root, flow)
            if h3.button("↓", disabled=index >= len(flow["components"]) - 1, key=f"scratch_down_{instance_id}", help="Move down"):
                _move(flow, index, 1)
                _save_and_rerun(root, flow)
            if h4.button("⧉", key=f"scratch_dup_{instance_id}", help="Duplicate component"):
                duplicate = deepcopy(component)
                duplicate["instanceId"] = ""
                duplicate["label"] = f"{label} copy"
                duplicate = new_component(
                    duplicate.get("stepKey"), label=duplicate.get("label"), enabled=duplicate.get("enabled", True),
                    wait_after_seconds=duplicate.get("waitAfterSeconds", 0), stop_on_blocked=duplicate.get("stopOnBlocked", True),
                    request_kind=duplicate.get("requestKind", ""), override_mode=duplicate.get("overrideMode", "merge"),
                    request_override=duplicate.get("requestOverride") or {}, source="duplicate", source_path=duplicate.get("sourcePath", ""),
                )
                flow["components"].insert(index + 1, duplicate)
                _save_and_rerun(root, flow, f"Duplicated {label}.")
            if h5.button("✎", key=f"scratch_open_{instance_id}", help="Open/edit settings"):
                st.session_state[f"scratch_expand_{instance_id}"] = not st.session_state.get(f"scratch_expand_{instance_id}", False)
            if h6.button("🗑", key=f"scratch_del_{instance_id}", help="Delete component"):
                flow["components"].pop(index)
                _save_and_rerun(root, flow, f"Removed {label}.")

            expanded = bool(st.session_state.get(f"scratch_expand_{instance_id}", False))
            with st.expander("Component settings & payload", expanded=expanded):
                e1, e2, e3 = st.columns(3)
                enabled = e1.checkbox("Enabled", value=bool(component.get("enabled", True)), key=f"scratch_enabled_{instance_id}")
                stop_block = e2.checkbox("Stop if BLOCKED", value=bool(component.get("stopOnBlocked", True)), key=f"scratch_stop_{instance_id}")
                wait_after = e3.number_input("Wait after (sec)", min_value=0.0, max_value=3600.0, value=float(component.get("waitAfterSeconds") or 0.0), step=1.0, key=f"scratch_wait_{instance_id}")
                custom_label = st.text_input("Component label", value=str(label), key=f"scratch_label_{instance_id}")

                request_kind = component.get("requestKind") or ""
                generated_preview = None
                if preview_runner is not None:
                    try:
                        generated_preview = component_request(preview_runner, component, {})
                        if not request_kind:
                            request_kind = generated_preview.get("requestKind") or "payload"
                        st.caption(f"Endpoint: {generated_preview.get('method')} {generated_preview.get('url')}")
                        st.info(f"Request type: {str(request_kind).upper()} · STRUCTURE LOCKED. Human users may edit existing scalar values below; they cannot change attribute names, nesting, method, URL or request kind.")
                    except Exception as exc:
                        st.caption(f"Preview pending: {exc}")

                if generated_preview is not None and preview_runner is not None:
                    _render_easy_payload_editor(root, flow, index, component, generated_preview, preview_runner)

                if st.button("Save block settings", width="stretch", key=f"scratch_save_settings_{instance_id}"):
                    component["label"] = custom_label
                    component["enabled"] = enabled
                    component["stopOnBlocked"] = stop_block
                    component["waitAfterSeconds"] = wait_after
                    flow["components"][index] = component
                    _save_and_rerun(root, flow, f"Saved graph settings for {custom_label}. Payload structure was not changed.")

                if generated_preview is not None:
                    with st.expander("Effective request preview", expanded=False):
                        safe = {
                            "method": generated_preview.get("method"),
                            "url": generated_preview.get("url"),
                            "requestKind": generated_preview.get("requestKind"),
                            "payload": generated_preview.get("payload"),
                            "params": generated_preview.get("params"),
                        }
                        st.json(safe_request_for_ui(safe))

    st.divider()
    st.markdown("### input.json → Scratch Flow")
    st.caption(
        "The agent first looks for an explicit `api_flow` / `scratch_flow` array in input.json. "
        "Each row may contain `stepKey`, `repeat`, `payloads`, `waitAfterSeconds` and `stopOnBlocked`. "
        "If no explicit flow is present, the normal HIP flow is inferred and repeated object collections such as `objects.document_types` are added automatically."
    )
    with st.expander("Example: create Document Type four times from input.json", expanded=False):
        st.code(json.dumps({
            "api_flow": [
                {
                    "stepKey": "doctype_source",
                    "label": "Create Document Type",
                    "repeat": 4,
                    "payloads": [
                        {"name": "DOC_TYPE_1", "hipEnvironment": "DEV"},
                        {"name": "DOC_TYPE_2", "hipEnvironment": "DEV"},
                        {"name": "DOC_TYPE_3", "hipEnvironment": "DEV"},
                        {"name": "DOC_TYPE_4", "hipEnvironment": "DEV"},
                    ],
                    "overrideMode": "merge",
                    "stopOnBlocked": True,
                }
            ]
        }, indent=2), language="json")

    st.divider()
    st.markdown("### 🚀 Launch this Mission LIVE")
    st.caption(
        "Execution is sequential in exactly the canvas order. Every block goes through the same request-contract validation, OAuth routing, MCP response interpretation and PASS/BLOCKED agent verdict used by API Testing Area."
    )
    ack = st.checkbox("I understand LAUNCH will call the configured live HIP APIs in the exact Mission Track order", key="scratch_live_ack")
    if st.button("🚀 LAUNCH MISSION LIVE", type="primary", width="stretch", disabled=not ack or not flow.get("components"), key="scratch_run_live"):
        logs: List[str] = []
        progress = st.progress(0.0)
        status = st.status("Running Scratch Flow...", expanded=True)
        proc = subprocess.Popen(
            [sys.executable, "-u", "scratch_flow_runner.py"],
            cwd=root,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
        )
        if proc.stdout is not None:
            for line in proc.stdout:
                text = line.rstrip()
                logs.append(text)
                st.write(text)
                match = re.match(r"^\[SCRATCH\s+(\d+)/(\d+)\]", text)
                if match:
                    current, total = int(match.group(1)), max(1, int(match.group(2)))
                    progress.progress(min(1.0, current / total))
        rc = proc.wait()
        progress.progress(1.0)
        st.session_state["scratch_logs"] = "\n".join(logs)
        if rc == 0:
            status.update(label="Scratch Flow completed", state="complete")
        else:
            status.update(label="Scratch Flow stopped/finished with a blocker", state="error")
        st.rerun()

    report = _load_json(root / "reports" / SCRATCH_REPORT_JSON, {})
    if report:
        st.markdown("### Latest Scratch Flow result")
        r1, r2, r3, r4 = st.columns(4)
        r1.metric("Components", report.get("componentCount", 0))
        r2.metric("Executed", report.get("executedCount", 0))
        r3.metric("PASS", report.get("passCount", 0))
        r4.metric("BLOCKED", report.get("blockedCount", 0))
        graph_tab, table_tab = st.tabs(["📊 Interactive execution graphs", "📋 Detailed result table"])
        with graph_tab:
            try:
                st.plotly_chart(
                    mission_flow_figure(flow, report), use_container_width=True,
                    config={"scrollZoom": True, "displaylogo": False, "responsive": True},
                    key="scratch_result_mission_map",
                )
                st.plotly_chart(
                    execution_latency_figure(report), use_container_width=True,
                    config={"scrollZoom": True, "displaylogo": False, "responsive": True},
                    key="scratch_result_latency",
                )
            except Exception as exc:
                st.warning(f"Interactive result graphs are unavailable: {exc}")
        with table_tab:
            st.dataframe(_report_table(report), width="stretch", hide_index=True)
        for item in report.get("steps") or []:
            verdict = item.get("agentVerdict") or {}
            icon = "✓" if verdict.get("verdict") == "PASS" else "⛔"
            with st.expander(f"{icon} {item.get('order')} · {item.get('label')} · {verdict.get('verdict')}"):
                st.markdown(f"**Agent response analysis:** {verdict.get('reason') or 'No explanation available.'}")
                st.caption(f"Next: {verdict.get('nextAction') or 'Review evidence.'}")
                st.json(redact_sensitive(item.get("request") or {}))
                result = item.get("result") or {}
                st.code(str(result.get("response_preview") or result.get("error") or ""))
        html_path = root / "reports" / SCRATCH_REPORT_HTML
        if html_path.exists():
            st.download_button("Download Scratch Flow HTML report", html_path.read_bytes(), file_name=html_path.name, mime="text/html", width="stretch")

    if st.session_state.get("scratch_logs"):
        with st.expander("Scratch execution logs", expanded=False):
            st.code(st.session_state["scratch_logs"])
