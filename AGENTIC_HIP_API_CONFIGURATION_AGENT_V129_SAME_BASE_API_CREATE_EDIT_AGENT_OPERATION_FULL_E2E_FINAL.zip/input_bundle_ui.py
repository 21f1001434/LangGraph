from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable, Dict

import streamlit as st

from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from input_bundle import (
    backup_active_state,
    extract_input_zip,
    inspect_input_zip, inspect_individual_files,
    parse_input_json_bytes, replace_input_files_from_pairs,
    restore_active_state,
)
from run_agent import Runner
from scratch_flow import infer_flow_from_input, save_scratch_flow
from application_studio import run_local_request_checks
from streamlit_navigation import request_workspace_switch
from production_guard import redact_sensitive
from interactive_graphs import validation_figure
from input_builder_core import build_from_raw_files, build_from_zip, combine_existing_input_with_artifact_evidence


def _summary_rows(value: Dict[str, Any]) -> list[dict[str, Any]]:
    objects = value.get("objects") if isinstance(value.get("objects"), dict) else {}
    src = objects.get("source_transport_profile") if isinstance(objects.get("source_transport_profile"), dict) else {}
    tgt = objects.get("target_transport_profile") if isinstance(objects.get("target_transport_profile"), dict) else {}
    biz = objects.get("biz_flow") if isinstance(objects.get("biz_flow"), dict) else {}
    flow_details = biz.get("flow_details") if isinstance(biz.get("flow_details"), dict) else {}
    return [
        {"Field": "Customer", "Value": value.get("customer") or "—"},
        {"Field": "Direction", "Value": value.get("direction") or "—"},
        {"Field": "Transaction", "Value": " ".join(str(value.get(k) or "") for k in ("tx_standard", "tx_code", "tx_name")).strip() or "—"},
        {"Field": "Flow", "Value": value.get("profile_name") or flow_details.get("business_flow_name") or "—"},
        {"Field": "Source deployment group", "Value": src.get("deployment_group") or DEFAULT_DEPLOYMENT_GROUP},
        {"Field": "Target deployment group", "Value": tgt.get("deployment_group") or DEFAULT_DEPLOYMENT_GROUP},
    ]


def render_input_bundle_workspace(
    root: Path,
    activate_input: Callable[[Dict[str, Any], bool], Dict[str, Any]],
) -> None:
    root = Path(root)
    st.markdown("## 📦 Upload New Configuration")
    st.markdown("### New package intake · same execution path as U-HAUL")
    st.caption(
        "1) Upload related files as a ZIP or select them individually. 2) Upload input.json. 3) Let the agent ingest both together and validate all generated API requests. "
        "4) Run the complete configuration LIVE or open the API Flow Game to reorder/repeat blocks."
    )
    st.info("📍 **This is the upload area.** Use it whenever you receive a new customer/interface configuration package.")
    st.info(
        f"Default deployment group is **{DEFAULT_DEPLOYMENT_GROUP}** for Source and Target whenever the uploaded input does not explicitly provide one."
    )

    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("### 1 · Upload related files")
        artifact_mode = st.radio(
            "Related-file input", ["ZIP bundle", "Individual files"], horizontal=True, key="hip_bundle_artifact_mode",
        )
        zip_upload = None
        zip_summary = None
        zip_bytes = b""
        direct_uploads = []
        direct_pairs = []
        direct_summary = None
        if artifact_mode == "ZIP bundle":
            zip_upload = st.file_uploader(
                "Input files bundle (.zip)", type=["zip"], key="hip_input_bundle_zip",
                help="Put map JAR, XBM, source/target/output XML and other runtime files in this ZIP.",
            )
            if zip_upload is not None:
                zip_bytes = zip_upload.getvalue()
                try:
                    zip_summary = inspect_input_zip(zip_bytes)
                    st.success(f"ZIP ready · {zip_summary['fileCount']} file(s) · {zip_summary['totalBytes']:,} bytes")
                    if zip_summary.get("containsInputJson"):
                        st.warning("The ZIP also contains input.json. The separately uploaded JSON remains authoritative.")
                    st.dataframe(zip_summary.get("files") or [], hide_index=True, width="stretch")
                except Exception as exc:
                    st.error(str(exc))
        else:
            direct_uploads = st.file_uploader(
                "Select related files", accept_multiple_files=True,
                type=["xml", "edi", "x12", "csv", "txt", "json", "jar", "xbm", "xlsx", "xlsm"],
                key="hip_input_bundle_direct_files",
                help="Select the XBM, mapping JAR, source XML, target XML, output/comparison XML and other supporting files directly.",
            ) or []
            if direct_uploads:
                direct_pairs = [(x.name, x.getvalue()) for x in direct_uploads]
                try:
                    direct_summary = inspect_individual_files(direct_pairs)
                    st.success(f"Files ready · {direct_summary['fileCount']} file(s) · {direct_summary['totalBytes']:,} bytes")
                    st.dataframe(direct_summary.get("files") or [], hide_index=True, width="stretch")
                except Exception as exc:
                    st.error(str(exc))

    with right:
        st.markdown("### 2 · Upload input.json")
        json_upload = st.file_uploader(
            "Input JSON (.json)", type=["json"], key="hip_input_bundle_json",
            help="This is the authoritative input.json; related files are ingested with it for validation and live runtime artifacts.",
        )
        input_data = None
        if json_upload is not None:
            try:
                parsed = parse_input_json_bytes(json_upload.getvalue())
                input_data, _ = with_default_deployment_group(parsed, {})
                st.success("input.json is valid and understood.")
                st.dataframe(_summary_rows(input_data), hide_index=True, width="stretch")
                with st.expander("Preview uploaded input.json", expanded=False):
                    st.json(input_data)
            except Exception as exc:
                st.error(str(exc))

    artifact_summary = zip_summary if artifact_mode == "ZIP bundle" else direct_summary
    artifact_validation = {}
    if artifact_summary and input_data:
        try:
            customer = str(input_data.get("customer") or "")
            direction = str(input_data.get("direction") or "")
            flow_type = str(input_data.get("flow_type") or "")
            manifest = [row.get("name") for row in (artifact_summary.get("files") or []) if str(row.get("name") or "").lower() != "input.json"]
            if artifact_mode == "ZIP bundle":
                evidence = build_from_zip(zip_bytes, customer=customer, direction=direction, flow_type=flow_type, use_dell_aia=False)
            else:
                with tempfile.TemporaryDirectory(prefix="hip_bundle_evidence_") as td:
                    troot = Path(td)
                    paths = []
                    for name, raw in direct_pairs:
                        safe = Path(str(name)).name
                        if safe.lower() == "input.json":
                            continue
                        path = troot / safe
                        path.write_bytes(raw)
                        paths.append(path)
                    evidence = build_from_raw_files(paths, customer=customer, direction=direction, flow_type=flow_type, use_dell_aia=False)
            input_data = combine_existing_input_with_artifact_evidence(input_data, evidence, manifest=manifest)
            artifact_validation = input_data.get("_artifact_validation") or {}
            if artifact_validation.get("blockers"):
                st.error(f"Related-file validation found {len(artifact_validation.get('blockers') or [])} blocker(s). Fix the input.json/file mismatch before activation.")
            elif artifact_validation.get("warnings"):
                st.warning(f"Related files ingested with {len(artifact_validation.get('warnings') or [])} review warning(s).")
            else:
                st.success("✓ input.json and related files are consistent for the checked artifact fields.")
            with st.expander("input.json ↔ related-file validation", expanded=bool(artifact_validation.get("blockers"))):
                st.json(redact_sensitive(artifact_validation))
        except Exception as exc:
            artifact_validation = {"blockers": [{"message": str(exc)}]}
            st.error(f"Could not ingest the related files with input.json: {exc}")

    st.divider()
    r1, r2, r3, r4 = st.columns(4)
    r1.metric("Related files", "READY" if artifact_summary else "WAITING")
    r2.metric("input.json", "READY" if input_data else "WAITING")
    r3.metric("Deployment", DEFAULT_DEPLOYMENT_GROUP)
    r4.metric("Execution", "LIVE ONLY")

    build_scratch = st.checkbox(
        "Also build the Scratch game board automatically from this input.json",
        value=True,
        key="bundle_build_scratch",
    )
    acknowledge = st.checkbox(
        "Replace the current input_files package and activate this input.json",
        key="bundle_replace_ack",
    )
    ready = bool(artifact_summary and input_data and acknowledge and not (artifact_validation.get("blockers") or []))
    if st.button("🤖 3 · Ingest + validate input.json + related files", type="primary", width="stretch", disabled=not ready, key="activate_input_bundle"):
        try:
            # Activation is transactional. If any later step fails, restore the
            # previous input_files + active JSON state instead of leaving a mixed package.
            with tempfile.TemporaryDirectory(prefix="hip_bundle_backup_") as temp_dir:
                backup_root = Path(temp_dir)
                backup_active_state(root, backup_root)
                try:
                    if artifact_mode == "ZIP bundle":
                        extract_result = extract_input_zip(zip_bytes, root / "input_files")
                    else:
                        extract_result = replace_input_files_from_pairs(direct_pairs, root / "input_files")
                    # activate_input derives config values, resets stale plans/overrides and records mapping evidence.
                    config = activate_input(input_data or {}, True)
                    if build_scratch:
                        try:
                            builder = Runner(llm_enabled=False)
                        except Exception:
                            builder = None
                        inferred, warnings = infer_flow_from_input(input_data or {}, runner=builder)
                        save_scratch_flow(root, inferred)
                        st.session_state["scratch_infer_warnings"] = warnings
                except Exception:
                    restore_active_state(root, backup_root)
                    raise
            with st.status("Agent is ingesting and validating the new package...", expanded=True) as validation_status:
                local_checks = run_local_request_checks(root)
                validation_status.write(f"Mapper: {'PASS' if (local_checks.get('mapper') or {}).get('ok') else 'BLOCKED'}")
                req = local_checks.get('requests') or {}
                validation_status.write(f"API request contracts: {req.get('validCount', 0)}/{req.get('total', 0)} valid")
                validation_status.update(
                    label="New configuration validated" if local_checks.get("ok") else "Agent found configuration blockers",
                    state="complete" if local_checks.get("ok") else "error",
                )
            st.session_state["bundle_activation"] = {
                "files": extract_result.get("fileCount", 0),
                "sourceDeploymentGroup": config.get("source_deployment_group_name") or DEFAULT_DEPLOYMENT_GROUP,
                "targetDeploymentGroup": config.get("target_deployment_group_name") or DEFAULT_DEPLOYMENT_GROUP,
                "scratchBuilt": bool(build_scratch),
                "validation": redact_sensitive(local_checks),
                "artifactValidation": redact_sensitive(artifact_validation),
            }
            st.rerun()
        except Exception as exc:
            st.error(f"Could not activate the package; the previous active package was restored. Details: {exc}")

    activated = st.session_state.get("bundle_activation")
    if activated:
        st.divider()
        st.markdown("### 4 · Agent ingestion & validation result")
        st.success(
            f"Active package loaded: {activated.get('files')} related input file(s). "
            f"Deployment defaults: {activated.get('sourceDeploymentGroup')} / {activated.get('targetDeploymentGroup')}."
        )
        validation = activated.get("validation") or {}
        request_validation = validation.get("requests") or {}
        mapper_validation = validation.get("mapper") or {}
        v1, v2, v3, v4 = st.columns(4)
        v1.metric("Agent validation", "PASS" if validation.get("ok") else "BLOCKED")
        v2.metric("Mapper", "PASS" if mapper_validation.get("ok") else "BLOCKED")
        v3.metric("API contracts", f"{request_validation.get('validCount', 0)}/{request_validation.get('total', 0)}")
        v4.metric("Execution", "LIVE ONLY")

        items = request_validation.get("items") or []
        if items:
            try:
                st.plotly_chart(
                    validation_figure(validation), use_container_width=True,
                    config={"scrollZoom": True, "displaylogo": False, "responsive": True},
                    key="bundle_validation_graph",
                )
            except Exception as exc:
                st.warning(f"Interactive validation graph is unavailable: {exc}")
            with st.expander("Detailed API validation table", expanded=False):
                st.dataframe([
                    {
                        "API": row.get("label") or row.get("stepKey"),
                        "Status": "PASS" if row.get("valid") else "BLOCKED",
                        "Errors": "; ".join(str(x) for x in (row.get("errors") or []))[:500],
                        "Warnings": "; ".join(str(x) for x in (row.get("warnings") or []))[:500],
                    }
                    for row in items
                ], hide_index=True, width="stretch")

        if validation.get("ok"):
            st.success("✓ Agent validation passed. This new package is ready for the same live execution pipeline used by U-HAUL.")
        else:
            st.error("⛔ Agent validation found one or more blockers. Open API Testing Area or the API Flow Game to inspect/fix the generated payloads before running live.")

        if activated.get("scratchBuilt"):
            st.caption("The API Flow Game mission was rebuilt automatically from this input.json.")

        nav1, nav2 = st.columns(2)
        if nav1.button("🧪 Review / test APIs", width="stretch", key="bundle_to_api_testing"):
            request_workspace_switch(st, "🧪 API Testing Area")
        if nav2.button("🎮 Open API Flow Game", width="stretch", key="bundle_to_game"):
            request_workspace_switch(st, "🎮 API Flow Game")

        st.markdown("### 5 · Run this NEW configuration LIVE")
        st.caption("This is the full dependency-aware HIP execution, not a simulation. It uses the active uploaded input.json and related files and produces the normal agent report.")
        full_ack = st.checkbox(
            "I confirm the uploaded configuration should now call the configured LIVE HIP APIs",
            key="bundle_full_live_ack",
        )
        can_run = bool(validation.get("ok") and full_ack)
        if st.button("🚀 RUN FULL CONFIGURATION LIVE", type="primary", width="stretch", disabled=not can_run, key="bundle_run_full_live"):
            logs: list[str] = []
            status = st.status("Running uploaded configuration LIVE...", expanded=True)
            proc = subprocess.Popen(
                [sys.executable, "-u", "run_agent.py"],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
            )
            if proc.stdout is not None:
                for line in proc.stdout:
                    text = line.rstrip()
                    logs.append(text)
                    st.write(text)
            rc = proc.wait()
            st.session_state["bundle_live_run"] = {"rc": rc, "logs": "\n".join(logs)}
            status.update(
                label="Live configuration completed" if rc == 0 else "Live configuration completed with blocker/error",
                state="complete" if rc == 0 else "error",
            )
            st.rerun()

        live_result = st.session_state.get("bundle_live_run")
        if live_result:
            if live_result.get("rc") == 0:
                st.success("✓ Full uploaded configuration completed through the live HIP runner.")
            else:
                st.error("⛔ The live runner returned a blocker/error. Review the report and evidence below.")
            with st.expander("Live execution log", expanded=False):
                st.code(live_result.get("logs") or "")

