from __future__ import annotations

import json
from pathlib import Path

from input_extraction_blueprint import (
    apply_input_extraction_blueprint,
    load_blueprint,
    merge_blueprint_questions,
)

ROOT = Path(__file__).resolve().parent


def _sample() -> dict:
    return {
        "customer": "LEGRAND_NEDERLAND",
        "profile_name": "",
        "tx_standard": "",
        "tx_code": "850",
        "tx_name": "Purchase Order",
        "direction": "Inbound",
        "flow_type": "translation",
        "requires_data_map": True,
        "objects": {
            "data_map": {
                "map_identifier": "DELLCiPMRPOXX10C_LEGRAND_NEDERLAND",
                "map_identifier_version": "1.0",
                "map_name": "DELLCiPMRPOXX10C",
                "map_class": "Transform_DELLCiPMRPOXX10C",
                "map_data_file": "Transform_DELLCiPMRPOXX10C.jar",
                "contivo_version": "6.7.2",
                "status": "Enable",
            },
            "source_document_type": {
                "name": "XML_850_10_LEGRAND_NEDERLAND_PRM_IB",
                "transaction_type": "850",
                "data_format_type": "XML",
                "version": "1.0",
                "description": "",
                "validation_type": "Structure",
                "document_identifier": {"rows": [{"derived_from": "TRANSACTION_ROOT_ELEMENT", "value": "PurchaseOrderCollection"}]},
                "attributes_to_configure": [{"attribute_name": "Receiver", "expression": "/PurchaseOrderCollection/Receiver"}],
            },
            "target_document_type": {
                "name": "XML_PO_10_LEGRAND_NEDERLAND_PO_OB",
                "transaction_type": "850",
                "data_format_type": "XML",
                "version": "1.0",
                "description": "",
                "validation_type": "Structure",
                "document_identifier": {"rows": [{"derived_from": "TRANSACTION_ROOT_ELEMENT", "value": "PO"}]},
                "attributes_to_configure": [{"attribute_name": "Receiver", "expression": "/PO/Receiver"}],
            },
            "rule": {"name": "DELLCiPMRPOXX10C_LEGRAND_NEDERLAND_RULE", "version": "1.0", "rule_scope": "GLOBAL", "conditions": {"rows": [{"attribute_name": "Receiver", "value": "LEGRAND"}]}, "actions": {"action_name": "DELLCiPMRPOXX10C_LEGRAND_NEDERLAND_ROUTE"}},
            "source_transport_profile": {"partner_name": "LEGRAND_NEDERLAND", "profile_name": "SFTP_LEGRAND_ASN_PC_SRC_IB", "deployment_group": "hip-automation", "interface_type": "SFTP HAFT", "interface_environment": "UAT", "existing_account_name": "acct-source", "subscription_folder": "/SFTP_LEGRAND_ASN_PC_SRC_IB"},
            "target_transport_profile": {"partner_name": "AIC - DCE", "profile_name": "SFTP_LEGRAND_ASN_PC_TGT_OB", "deployment_group": "hip-automation", "interface_type": "SFTP HAFT", "interface_environment": "UAT", "existing_account_name": "acct-target", "subscription_folder": "/Inbound/ASN"},
            "biz_flow": {
                "flow_details": {"business_flow_name": "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB", "flow_description": "Inbound 850"},
                "configure_source": {"source_type": "Partner", "source_application": "LEGRAND_NEDERLAND", "source_transport_profile": "pt-sender-sftphaft-dce-common", "document_type_name_version": "XML_850_10_LEGRAND_NEDERLAND_PRM_IB(1.0)"},
                "flow_identifiers": {"conditions": [{"attribute_name": "Receiver", "value": "DELL"}, {"attribute_name": "Sender", "value": "LEGRAND"}]},
                "configure_targets": {"target_type": "Dell Application", "target_application": "AIC - DCE", "target_transport_profile": "da-receiver-sftphaft-dce-common", "document_type_name_version": "XML_PO_10_LEGRAND_NEDERLAND_PO_OB(1.0)"},
                "process_steps": [{"step_type": "Mapping Transformer"}],
                "configure_routing": {"actions": {"target": ""}, "conditions": {"rows": [{"attribute_name": "Receiver", "value": "DELL"}]}}
            },
        },
        "_file_mapping": {"fieldMappings": [
            {"path": "objects.data_map.map_name", "sourceFile": "DELLCiPMRPOXX10C.xbm", "rule": "XBM transformMap logicalName", "confidence": "high"},
            {"path": "objects.data_map.map_data_file", "sourceFile": "Transform_DELLCiPMRPOXX10C.jar", "rule": "uploaded Contivo JAR", "confidence": "high"},
        ]},
    }


def test_engineer_blueprint_is_formal_and_example_values_are_not_customer_defaults():
    bp = load_blueprint()
    assert bp["schemaVersion"] == "1.0"
    assert len(bp["fields"]) >= 60
    assert "XML_TO_XML" in bp["supportedFlows"]
    paths = {x["path"] for x in bp["fields"]}
    for path in (
        "customer", "direction", "flow_type", "requires_data_map",
        "objects.data_map.map_name", "objects.source_document_type.document_identifier",
        "objects.source_transport_profile.subscription_folder",
        "objects.biz_flow.configure_routing",
    ):
        assert path in paths
    # The engineer screenshots contain Legrand examples; the operational schema
    # must never encode example business values that could leak to another customer.
    raw = json.dumps(bp)
    assert "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB" not in raw
    assert "PurchaseOrderCollection" not in raw


def test_blueprint_adds_safe_aliases_and_provenance_without_rewriting_customer_values():
    src = _sample()
    out = apply_input_extraction_blueprint(src, source_interface="SFTP", target_interface="SFTP", manifest=["source.xml", "target.xml", "map.xbm", "map.jar"])
    assert out["customer"] == "LEGRAND_NEDERLAND"
    assert out["profile_name"] == "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    assert out["tx_standard"] == "XML"
    assert out["objects"]["source_document_type"]["description"] == "XML_850_10_LEGRAND_NEDERLAND_PRM_IB"
    assert out["objects"]["target_document_type"]["description"] == "XML_PO_10_LEGRAND_NEDERLAND_PO_OB"
    assert out["objects"]["biz_flow"]["configure_routing"]["actions"]["target"] == "da-receiver-sftphaft-dce-common"
    bp = out["_input_extraction_blueprint"]
    assert bp["noInventedCustomerValues"] is True
    assert bp["ruleCount"] >= 60
    map_row = next(x for x in bp["fields"] if x["path"] == "objects.data_map.map_name")
    assert map_row["status"] == "EXTRACTED"
    assert map_row["source"] == "DELLCiPMRPOXX10C.xbm"


def test_blueprint_questions_ask_only_when_evidence_cannot_prove_required_value_and_dedupe():
    data = _sample()
    data["objects"]["target_transport_profile"]["subscription_folder"] = ""
    data["objects"]["data_map"]["map_class"] = ""
    qs = merge_blueprint_questions(data, [], source_interface="SFTP", target_interface="SFTP")
    paths = {q.get("path") for q in qs}
    assert "objects.target_transport_profile.subscription_folder" in paths
    assert "objects.data_map.map_class" in paths
    existing = [{"id": "old", "path": "objects.target_transport_profile.subscription_folder", "label": "Target folder"}]
    qs2 = merge_blueprint_questions(data, existing, source_interface="SFTP", target_interface="SFTP")
    assert sum(1 for q in qs2 if q.get("path") == "objects.target_transport_profile.subscription_folder") == 1


def test_non_file_interface_does_not_ask_haft_account_or_folder_from_blueprint():
    data = _sample()
    for side in ("source", "target"):
        tp = data["objects"][f"{side}_transport_profile"]
        tp["interface_type"] = "HTTPS"
        tp["existing_account_name"] = ""
        tp["subscription_folder"] = ""
    qs = merge_blueprint_questions(data, [], source_interface="HTTPS", target_interface="HTTPS")
    paths = {q.get("path") for q in qs}
    assert "objects.source_transport_profile.existing_account_name" not in paths
    assert "objects.target_transport_profile.subscription_folder" not in paths


def test_react_builder_exposes_customer_fallback_and_blueprint_summary():
    text = (ROOT / "webapp" / "frontend" / "src" / "pages" / "BuilderPage.tsx").read_text(encoding="utf-8")
    assert "Customer / partner name" in text
    assert "ENGINEER INPUT BLUEPRINT" in text
    assert "field-source rules active" in text


def test_backend_evidence_returns_extraction_blueprint():
    text = (ROOT / "webapp" / "backend" / "app" / "phase2_service.py").read_text(encoding="utf-8")
    assert '"extractionBlueprint"' in text
