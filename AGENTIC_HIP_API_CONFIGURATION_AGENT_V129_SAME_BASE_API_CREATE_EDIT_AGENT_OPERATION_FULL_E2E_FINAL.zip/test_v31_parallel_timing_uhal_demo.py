from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import parallel_configurations as pc


def _validation() -> dict:
    return {
        "ok": True,
        "generatedAt": "2026-08-17T00:00:00Z",
        "mapper": {"ok": True},
        "mcpSupervisor": {"valid": True},
        "requests": {"ok": True, "validCount": 18, "total": 18, "items": [{"valid": True}] * 18},
    }


def _write_uhal(root: Path) -> None:
    (root / "input_files").mkdir(parents=True, exist_ok=True)
    (root / "input_files" / "source.xml").write_text("<DellAutoASN/>", encoding="utf-8")
    (root / "input.json").write_text(json.dumps({
        "customer": "U-HAUL",
        "profile_name": "UHAL_PARALLEL_DEMO_FLOW",
        "direction": "Outbound",
        "flow_type": "translation",
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": "UHAL_PARALLEL_DEMO_FLOW"}}},
    }), encoding="utf-8")


def test_multiple_instances_of_same_validated_uhal_are_isolated(tmp_path: Path):
    _write_uhal(tmp_path)
    rows = pc.snapshot_validated_configuration_instances(
        tmp_path, _validation(), 3, label_prefix="U-HAUL Parallel Demo"
    )
    assert len(rows) == 3
    assert len({row["jobId"] for row in rows}) == 3
    assert [row["demoInstance"] for row in rows] == [1, 2, 3]
    for index, row in enumerate(rows, start=1):
        workspace = Path(row["workspace"])
        assert workspace.exists()
        assert json.loads((workspace / "input.json").read_text(encoding="utf-8"))["customer"] == "U-HAUL"
        manifest = json.loads((workspace / "queue_manifest.json").read_text(encoding="utf-8"))
        assert manifest["label"] == f"U-HAUL Parallel Demo #{index}"
        assert manifest["demoInstanceCount"] == 3


def test_parallel_job_step_timing_loader_returns_api_wait_and_total(tmp_path: Path):
    reports = tmp_path / "reports"
    reports.mkdir(parents=True)
    (reports / "execution_timing_latest.json").write_text(json.dumps({
        "events": [{
            "stepKey": "doctype_source",
            "label": "Source Document Type",
            "sequence": 8,
            "resultClassification": "PASS",
            "startedAt": "2026-08-17T00:00:00+00:00",
            "finishedAt": "2026-08-17T00:00:01.25+00:00",
            "apiElapsedMs": 1000,
            "apiElapsedSeconds": 1.0,
            "actualWaitSeconds": 0.25,
            "totalStepSeconds": 1.25,
        }]
    }), encoding="utf-8")
    rows = pc._load_step_timings(tmp_path)
    assert rows == [{
        "stepKey": "doctype_source",
        "label": "Source Document Type",
        "sequence": 8,
        "classification": "PASS",
        "startedAt": "2026-08-17T00:00:00+00:00",
        "finishedAt": "2026-08-17T00:00:01.25+00:00",
        "apiElapsedMs": 1000,
        "apiElapsedSeconds": 1.0,
        "waitSeconds": 0.25,
        "totalStepSeconds": 1.25,
    }]



def test_uhal_demo_instances_execute_concurrently(tmp_path: Path, monkeypatch):
    _write_uhal(tmp_path)
    rows = pc.snapshot_validated_configuration_instances(
        tmp_path, _validation(), 3, label_prefix="U-HAUL Parallel Demo"
    )
    active = 0
    max_active = 0
    lock = threading.Lock()

    def fake_run_one(root, code_root, job, batch_id, progress_callback=None):
        nonlocal active, max_active
        with lock:
            active += 1
            max_active = max(max_active, active)
        time.sleep(0.12)
        with lock:
            active -= 1
        return {
            "jobId": job["jobId"],
            "customer": job["customer"],
            "flow": job["flow"],
            "label": job.get("label"),
            "demoInstance": job.get("demoInstance"),
            "status": "PASS",
            "returnCode": 0,
            "elapsedSeconds": 0.12,
            "stepTimings": [],
            "stepCount": 0,
        }

    monkeypatch.setattr(pc, "_run_one", fake_run_one)
    summary = pc.run_parallel_configurations(
        tmp_path, [row["jobId"] for row in rows], max_workers=3
    )
    assert summary["passCount"] == 3
    assert summary["parallelWorkers"] == 3
    assert max_active >= 2


def test_v31_timing_and_parallel_demo_are_visible_in_application_studio():
    root = Path(__file__).resolve().parent
    runner = (root / "run_agent.py").read_text(encoding="utf-8")
    studio = (root / "hip_application_studio.py").read_text(encoding="utf-8")
    parallel_ui = (root / "parallel_config_ui.py").read_text(encoding="utf-8")
    api_testing = (root / "api_testing_area_ui.py").read_text(encoding="utf-8")

    assert "STEP TIME" in runner
    assert "apiElapsedSeconds" in runner and "totalStepSeconds" in runner
    assert "Time" in studio and "Total API time" in studio
    assert "⚡ Parallel LIVE" in studio
    assert "U-HAUL parallel capability demo" in parallel_ui
    assert "Create {int(demo_count)} isolated U-HAUL parallel instances" in parallel_ui
    assert "Total step time" in parallel_ui
    assert "Step completion time" in api_testing
