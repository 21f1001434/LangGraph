from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from migration_api_contract import MIGRATION_ORDER, MIGRATION_STEP_DEFINITIONS


# Historical 18-step contract remains exported as STEP_DEFINITIONS/DEFAULT_ORDER
# for compatibility with existing validators and Streamlit tools.
STEP_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "validate_source": {"label": "Validate Source TP", "group": "Validation", "dependencies": []},
    "validate_target": {"label": "Validate Target TP", "group": "Validation", "dependencies": []},
    "validate_flow": {"label": "Validate Flow Name", "group": "Validation", "dependencies": []},
    "account_source": {"label": "Source Account", "group": "Foundation", "dependencies": []},
    "account_target": {"label": "Target Account", "group": "Foundation", "dependencies": []},
    "partner_target": {"label": "Target Partner", "group": "Foundation", "dependencies": []},
    "system_source": {"label": "Source System", "group": "Foundation", "dependencies": []},
    "doctype_source": {"label": "Source Document Type", "group": "Configuration", "dependencies": []},
    "doctype_target": {"label": "Target Document Type", "group": "Configuration", "dependencies": []},
    "map": {"label": "MAC Map", "group": "Configuration", "dependencies": ["doctype_source", "doctype_target"]},
    "rule": {"label": "Mapping Rule", "group": "Configuration", "dependencies": ["doctype_source", "map"]},
    "source_tp": {"label": "Source TP Orchestration", "group": "Orchestration", "dependencies": ["doctype_source"]},
    "target_tp": {"label": "Target TP Orchestration", "group": "Orchestration", "dependencies": ["doctype_target"]},
    "source_tp_audit": {"label": "Source TP Audit", "group": "Verification", "dependencies": ["source_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
    "target_tp_audit": {"label": "Target TP Audit", "group": "Verification", "dependencies": ["target_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
    "flow_create": {"label": "Flow Orchestration Create/Edit", "group": "Orchestration", "dependencies": ["doctype_source", "doctype_target", "map", "rule", "source_tp_audit", "target_tp_audit"]},
    "flow_deploy": {"label": "Flow Orchestration Deploy", "group": "Orchestration", "dependencies": ["flow_create"]},
    "flow_history": {"label": "Flow Deployment Audit/History", "group": "Verification", "dependencies": ["flow_deploy"], "mandatory": True, "pollEverySeconds": 60, "timeoutSeconds": 3600},
}

DEFAULT_ORDER: List[str] = [
    "validate_source", "validate_target", "validate_flow",
    "account_source", "account_target", "partner_target", "system_source",
    "doctype_source", "doctype_target", "map", "rule",
    "source_tp", "target_tp", "source_tp_audit", "target_tp_audit",
    "flow_create", "flow_deploy", "flow_history",
]

# V126: all 25 blocks are configurable in one dependency-safe user plan.
# The seven Migration definitions remain additive and do not change the historical
# STEP_DEFINITIONS constant used by old integrations.
#
# V129 Dev confirmation: Transport Profile and Flow orchestration use the SAME
# base POST API for Create and Edit.  Only existing operation VALUE fields may
# switch between create/edit; method, URL and request structure remain fixed.
OPERATION_CAPABLE_STEPS: Dict[str, Dict[str, Any]] = {
    "source_tp": {
        "paths": ["operation", "transportProfileDetails.0.transportProfileOperation"],
        "description": "Source TP orchestration uses the same base API; switch operation values only.",
    },
    "target_tp": {
        "paths": ["operation", "transportProfileDetails.0.transportProfileOperation"],
        "description": "Target TP orchestration uses the same base API; switch operation values only.",
    },
    "flow_create": {
        "paths": ["operation"],
        "description": "Flow orchestration uses the same base API; switch operation value only.",
    },
}
OPERATION_MODES = {"inherit", "create", "edit"}

ALL_STEP_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    **STEP_DEFINITIONS,
    **MIGRATION_STEP_DEFINITIONS,
}
ALL_DEFAULT_ORDER: List[str] = DEFAULT_ORDER + [key for key in MIGRATION_ORDER if key not in DEFAULT_ORDER]

# Dev feedback replaces fixed sleeps with terminal-state Audit polling. Custom
# waits remain supported because users asked for a configurable execution flow.
DEFAULT_WAIT_AFTER_SECONDS: Dict[str, float] = {key: 0.0 for key in ALL_DEFAULT_ORDER}


def _row(key: str, order: int) -> Dict[str, Any]:
    row = {
        "stepKey": key,
        "order": order,
        "waitAfterSeconds": DEFAULT_WAIT_AFTER_SECONDS.get(key, 0.0),
    }
    if key in OPERATION_CAPABLE_STEPS:
        # inherit = keep the generated canonical Create value unless a legacy
        # human payload override already selected another approved value.
        row["operationMode"] = "inherit"
        row["operationModeSource"] = "generated"
    return row


def default_config() -> Dict[str, Any]:
    return {
        "version": 4,
        "savedAt": None,
        # Explicit user gate. Migration never turns itself on merely because a
        # targetEnvironment value happens to be present in a payload.
        "migrationEnabled": False,
        "steps": [_row(key, index + 1) for index, key in enumerate(DEFAULT_ORDER)],
        "migrationSteps": [
            _row(key, len(DEFAULT_ORDER) + index + 1)
            for index, key in enumerate(MIGRATION_ORDER)
        ],
    }


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
    except Exception:
        return default
    return max(0.0, min(parsed, 3600.0))


def _as_order(value: Any, fallback: int) -> int:
    try:
        parsed = int(value)
    except Exception:
        parsed = fallback
    return max(1, parsed)


def _normalized_rows(
    rows: Any,
    keys: List[str],
    defaults: Dict[str, int],
    *,
    source_version: int,
    force_legacy_default_order: bool,
) -> List[Dict[str, Any]]:
    raw_rows = rows if isinstance(rows, list) else []
    by_key: Dict[str, Dict[str, Any]] = {}
    for raw in raw_rows:
        if not isinstance(raw, dict):
            continue
        key = str(raw.get("stepKey") or "").strip()
        if key not in keys:
            continue
        order = _as_order(raw.get("order"), defaults[key])
        if force_legacy_default_order and source_version < 2 and key in DEFAULT_ORDER:
            order = defaults[key]
        normalized_row = {
            "stepKey": key,
            "order": order,
            "waitAfterSeconds": _as_float(raw.get("waitAfterSeconds"), 0.0),
        }
        if key in OPERATION_CAPABLE_STEPS:
            mode = str(raw.get("operationMode") or "inherit").strip().lower()
            if mode not in OPERATION_MODES:
                mode = "inherit"
            normalized_row["operationMode"] = mode
            normalized_row["operationModeSource"] = str(raw.get("operationModeSource") or ("legacy" if source_version < 4 else "generated"))
        by_key[key] = normalized_row
    return [
        by_key.get(key) or _row(key, defaults[key])
        for key in keys
    ]


def normalize_config(value: Any) -> Dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    try:
        source_version = int(raw.get("version") or 1)
    except Exception:
        source_version = 1

    base_defaults = {key: index + 1 for index, key in enumerate(DEFAULT_ORDER)}
    migration_defaults = {
        key: len(DEFAULT_ORDER) + index + 1
        for index, key in enumerate(MIGRATION_ORDER)
    }

    base_rows = _normalized_rows(
        raw.get("steps"), DEFAULT_ORDER, base_defaults,
        source_version=source_version, force_legacy_default_order=True,
    )
    migration_rows = _normalized_rows(
        raw.get("migrationSteps"), list(MIGRATION_ORDER), migration_defaults,
        source_version=source_version, force_legacy_default_order=False,
    )

    # V1/V2 files had no Migration rows. Append them after the highest saved base
    # order to make the upgrade deterministic without changing the old 18 order.
    if source_version < 3 or not isinstance(raw.get("migrationSteps"), list):
        max_base = max((int(row.get("order") or 0) for row in base_rows), default=len(DEFAULT_ORDER))
        migration_rows = [
            {**row, "order": max_base + index + 1}
            for index, row in enumerate(migration_rows)
        ]

    return {
        "version": 4,
        "savedAt": raw.get("savedAt"),
        "migrationEnabled": bool(raw.get("migrationEnabled", False)) if source_version >= 3 else False,
        "steps": base_rows,
        "migrationSteps": migration_rows,
    }


def _all_rows(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    return list(cfg.get("steps") or []) + list(cfg.get("migrationSteps") or [])


def validate_config(value: Any) -> Tuple[List[str], List[str]]:
    cfg = normalize_config(value)
    errors: List[str] = []
    warnings: List[str] = []
    rows = _all_rows(cfg)

    keys = [str(row.get("stepKey") or "") for row in rows]
    missing = [key for key in ALL_DEFAULT_ORDER if key not in keys]
    unknown = [key for key in keys if key not in ALL_STEP_DEFINITIONS]
    if missing:
        errors.append("Execution flow is missing step(s): " + ", ".join(missing))
    if unknown:
        errors.append("Execution flow contains unknown step(s): " + ", ".join(sorted(set(unknown))))

    orders = [int(row.get("order") or 0) for row in rows]
    if len(set(orders)) != len(orders):
        errors.append("Every base and Migration execution step must have a unique Order value.")

    for row in rows:
        key = str(row.get("stepKey") or "")
        if key in OPERATION_CAPABLE_STEPS:
            mode = str(row.get("operationMode") or "inherit").strip().lower()
            if mode not in OPERATION_MODES:
                errors.append(f"{ALL_STEP_DEFINITIONS[key]['label']} has invalid operationMode={mode!r}; use inherit/create/edit.")

    position = {str(row["stepKey"]): int(row["order"]) for row in rows if str(row.get("stepKey") or "") in ALL_STEP_DEFINITIONS}
    for key, meta in ALL_STEP_DEFINITIONS.items():
        if key not in position:
            continue
        current = position[key]
        for dependency in meta.get("dependencies", []):
            if dependency not in position:
                errors.append(f"{meta['label']} requires missing dependency {dependency}.")
                continue
            if position[dependency] >= current:
                errors.append(
                    f"{meta['label']} must run after {ALL_STEP_DEFINITIONS[dependency]['label']}."
                )

    for row in rows:
        if float(row.get("waitAfterSeconds") or 0.0) > 300:
            warnings.append(
                f"{ALL_STEP_DEFINITIONS[row['stepKey']]['label']} has a long wait of "
                f"{row['waitAfterSeconds']} seconds."
            )

    if cfg.get("migrationEnabled"):
        warnings.append(
            "Migration execution is ON. The seven applicable Migration payloads must pass preflight before LIVE starts."
        )
    return errors, warnings


class ExecutionFlowConfig:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.path = self.root / "execution_flow.json"
        self.data = self._load()
        self.errors, self.warnings = validate_config(self.data)

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return default_config()
        try:
            return normalize_config(json.loads(self.path.read_text(encoding="utf-8")))
        except Exception:
            return default_config()

    def migration_enabled(self) -> bool:
        return bool(self.data.get("migrationEnabled"))

    def user_controlled(self) -> bool:
        """True after a human has explicitly saved/reset this workspace execution plan."""
        return bool(self.data.get("savedAt"))

    def ordered_steps(self) -> List[str]:
        """Historical 18-step ordering, retained for compatibility."""
        rows = list(self.data["steps"])
        rows.sort(key=lambda row: (int(row["order"]), DEFAULT_ORDER.index(row["stepKey"])))
        return [row["stepKey"] for row in rows]

    def ordered_all_steps(self) -> List[str]:
        rows = _all_rows(self.data)
        fallback = {key: index for index, key in enumerate(ALL_DEFAULT_ORDER)}
        rows.sort(key=lambda row: (int(row["order"]), fallback.get(str(row["stepKey"]), 999)))
        return [str(row["stepKey"]) for row in rows]

    def ordered_live_steps(self, include_migration: Optional[bool] = None) -> List[str]:
        enabled = self.migration_enabled() if include_migration is None else bool(include_migration)
        ordered = self.ordered_all_steps()
        if enabled:
            return ordered
        return [key for key in ordered if key not in MIGRATION_STEP_DEFINITIONS]

    def operation_mode(self, step_key: str) -> str:
        key = str(step_key or "").strip()
        if key not in OPERATION_CAPABLE_STEPS:
            return "inherit"
        for row in _all_rows(self.data):
            if str(row.get("stepKey") or "") == key:
                mode = str(row.get("operationMode") or "inherit").strip().lower()
                return mode if mode in OPERATION_MODES else "inherit"
        return "inherit"

    def operation_mode_source(self, step_key: str) -> str:
        key = str(step_key or "").strip()
        for row in _all_rows(self.data):
            if str(row.get("stepKey") or "") == key:
                return str(row.get("operationModeSource") or "generated")
        return "generated"

    def operation_capable(self, step_key: str) -> bool:
        return str(step_key or "").strip() in OPERATION_CAPABLE_STEPS

    def wait_after(self, step_key: str) -> float:
        for row in _all_rows(self.data):
            if row["stepKey"] == step_key:
                return _as_float(row.get("waitAfterSeconds"), 0.0)
        return 0.0

    def summary(self) -> Dict[str, Any]:
        def enrich(row: Dict[str, Any]) -> Dict[str, Any]:
            meta = ALL_STEP_DEFINITIONS[row["stepKey"]]
            key = row["stepKey"]
            operation_meta = OPERATION_CAPABLE_STEPS.get(key) or {}
            return {
                **row,
                "label": meta["label"],
                "group": meta["group"],
                "dependencies": list(meta.get("dependencies", [])),
                "migration": key in MIGRATION_STEP_DEFINITIONS,
                "includedInLive": key not in MIGRATION_STEP_DEFINITIONS or self.migration_enabled(),
                "operationCapable": key in OPERATION_CAPABLE_STEPS,
                "operationPaths": list(operation_meta.get("paths") or []),
                "operationDescription": str(operation_meta.get("description") or ""),
                "operationMode": str(row.get("operationMode") or "inherit") if key in OPERATION_CAPABLE_STEPS else "inherit",
            }

        base_steps = [enrich(row) for row in sorted(self.data["steps"], key=lambda item: int(item["order"]))]
        migration_steps = [enrich(row) for row in sorted(self.data["migrationSteps"], key=lambda item: int(item["order"]))]
        all_steps = sorted(base_steps + migration_steps, key=lambda item: int(item["order"]))
        return {
            "path": str(self.path),
            "version": 4,
            "valid": not self.errors,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "migrationEnabled": self.migration_enabled(),
            "userControlled": self.user_controlled(),
            "executionStrategy": "EXACT_SEQUENTIAL" if self.user_controlled() else "DEFAULT_DEPENDENCY_READY",
            "registeredBaseCount": len(DEFAULT_ORDER),
            "registeredMigrationCount": len(MIGRATION_ORDER),
            "registeredTotalCount": len(ALL_DEFAULT_ORDER),
            "liveStepCount": len(self.ordered_live_steps()),
            "orderedSteps": self.ordered_steps(),
            "orderedAllSteps": self.ordered_all_steps(),
            "orderedLiveSteps": self.ordered_live_steps(),
            # Backwards-compatible field used by old UIs.
            "steps": base_steps,
            "migrationSteps": migration_steps,
            "liveSteps": all_steps,
        }


def save_execution_flow(
    root: Path,
    rows: Iterable[Dict[str, Any]],
    migration_enabled: Optional[bool] = None,
    *,
    operation_source: Optional[str] = None,
) -> Dict[str, Any]:
    root = Path(root)
    current = ExecutionFlowConfig(root).data
    incoming = [dict(row) for row in rows if isinstance(row, dict)]
    if operation_source:
        for row in incoming:
            if str(row.get("stepKey") or "") in OPERATION_CAPABLE_STEPS:
                row["operationModeSource"] = str(operation_source)
    incoming_base = [row for row in incoming if str(row.get("stepKey") or "") in STEP_DEFINITIONS]
    incoming_migration = [row for row in incoming if str(row.get("stepKey") or "") in MIGRATION_STEP_DEFINITIONS]

    payload = {
        "version": 4,
        "savedAt": dt.datetime.now().isoformat(),
        "migrationEnabled": bool(current.get("migrationEnabled")) if migration_enabled is None else bool(migration_enabled),
        "steps": incoming_base if incoming_base else list(current.get("steps") or []),
        "migrationSteps": incoming_migration if incoming_migration else list(current.get("migrationSteps") or []),
    }
    normalized = normalize_config(payload)
    normalized["savedAt"] = payload["savedAt"]
    normalized["migrationEnabled"] = payload["migrationEnabled"]
    errors, warnings = validate_config(normalized)
    if errors:
        raise ValueError("Invalid execution flow: " + " ".join(errors))
    path = root / "execution_flow.json"
    path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")
    result = ExecutionFlowConfig(root).summary()
    result["warnings"] = warnings
    return result


def save_operation_mode(root: Path, step_key: str, mode: str, *, source: str = "agent") -> Dict[str, Any]:
    """Persist only the Dev-approved Create/Edit operation selector for one API.

    This intentionally does NOT change Migration ON/OFF, step order, waits, method,
    URL, request kind, headers, attribute names, nesting or array cardinality. It
    gives the agent a narrow write capability approved by the Dev confirmation.
    """
    root = Path(root)
    key = str(step_key or "").strip()
    selected = str(mode or "").strip().lower()
    if key not in OPERATION_CAPABLE_STEPS:
        raise ValueError(f"API step {key!r} has no Dev-approved create/edit operation field.")
    if selected not in OPERATION_MODES:
        raise ValueError("Operation mode must be inherit, create, or edit.")
    cfg = ExecutionFlowConfig(root).data
    changed = False
    for row in cfg.get("steps") or []:
        if str(row.get("stepKey") or "") == key:
            row["operationMode"] = selected
            row["operationModeSource"] = str(source or "agent")
            changed = True
            break
    if not changed:
        raise ValueError(f"Execution flow does not contain registered step {key!r}.")
    cfg["version"] = 4
    cfg["operationModeUpdatedAt"] = dt.datetime.now().isoformat()
    errors, _ = validate_config(cfg)
    if errors:
        raise ValueError("Invalid execution flow after operation change: " + " ".join(errors))
    (root / "execution_flow.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return ExecutionFlowConfig(root).summary()


def reset_execution_flow(root: Path) -> Dict[str, Any]:
    root = Path(root)
    data = default_config()
    data["savedAt"] = dt.datetime.now().isoformat()
    (root / "execution_flow.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    return ExecutionFlowConfig(root).summary()
