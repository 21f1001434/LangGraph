"""Backward-compatible advanced tools page for old Streamlit links/bookmarks."""
from pathlib import Path
import sys
import streamlit as st


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from streamlit_navigation import render_app_home_link, safe_page_link

from mcp_bridge import MCPBridge
from unified_studio_views import render_advanced_tools
from scratch_flow_ui import render_scratch_flow_builder

st.set_page_config(page_title="HIP Advanced Tools", layout="wide")
render_app_home_link(st)
safe_page_link(st, "pages/10_Agentic_Interface_Studio.py", label="Agentic Interface Studio", icon="🤖")

t1, t2 = st.tabs(["🛠️ Payload / MCP / Advanced", "🧩 Scratch Flow Builder"])
with t1:
    render_advanced_tools(ROOT, MCPBridge(ROOT))
with t2:
    render_scratch_flow_builder(ROOT, MCPBridge(ROOT))
