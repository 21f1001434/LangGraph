"""Backward-compatible Streamlit page.

The current application uses one entrypoint and an in-app workspace switcher.
This wrapper keeps old bookmarks/sidebar links working without duplicating UI logic.
"""
from pathlib import Path
import sys
import streamlit as st


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from streamlit_navigation import render_app_home_link, safe_page_link

from api_pdf_ingestion import PdfApiKnowledgeBase
from mcp_bridge import MCPBridge
from unified_studio_views import render_agentic_interface_studio

st.set_page_config(page_title="HIP Agentic Interface Studio", layout="wide")
render_app_home_link(st)
safe_page_link(st, "pages/90_Advanced_Technical_Workspace.py", label="Payload / MCP / Advanced", icon="🛠️")

mcp = MCPBridge(ROOT)
pdf_kb = PdfApiKnowledgeBase(ROOT)
render_agentic_interface_studio(ROOT, mcp, pdf_kb)
