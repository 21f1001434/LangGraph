from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"name": name, "ok": bool(ok), "detail": detail})

manifest = json.loads((ROOT / "AGENTIC_HIP_PHASE5_MANIFEST.json").read_text(encoding="utf-8"))
main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
storage = (ROOT / "webapp/backend/app/storage.py").read_text(encoding="utf-8")
service = (ROOT / "webapp/backend/app/phase5_service.py").read_text(encoding="utf-8")
workspace = (ROOT / "webapp/frontend/src/pages/WorkspacePage.tsx").read_text(encoding="utf-8")
templates = (ROOT / "webapp/frontend/src/pages/TemplatesPage.tsx").read_text(encoding="utf-8")
operations = (ROOT / "webapp/frontend/src/pages/OperationsPage.tsx").read_text(encoding="utf-8")
sidebar = (ROOT / "webapp/frontend/src/components/Sidebar.tsx").read_text(encoding="utf-8")
api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")

check("Phase 5 manifest", manifest.get("phase") == 5 and manifest.get("release") == "V37")
check("LIVE-only preserved", manifest.get("liveOnlyExecution") is True)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
check("Current deployment group is hip-automation", DEFAULT_DEPLOYMENT_GROUP == "hip-automation")
check("Exactly 18 API blocks declared", manifest.get("apiBlocks") == 18)
check("FastAPI phase 5+ bootstrap", ('"phase": 5' in main or '"phase": 6' in main))
check("Configuration Library API", '/api/configurations/{cid}/clone' in main and '/api/configurations/{cid}/bundle' in main)
check("Portable bundle import", '/api/configuration-bundles/import' in main and 'import_configuration_bundle' in main)
check("Bundle SHA-256 manifest", 'sha256' in service and 'bundle_manifest.json' in service)
check("Bundle traversal protection", 'Unsafe bundle path' in service and 'MAX_FILES' in service and 'MAX_FILE_BYTES' in service)
check("Imported bundle revalidation", 'validation": {}' in service and 'requiresRevalidationOnImport' in service)
check("Audit middleware", 'audit_mutations' in main and 'X-HIP-Actor' in main)
check("Audit hash chain", 'previous_hash' in storage and 'verify_audit' in storage and 'hashlib.sha256' in storage)
check("Audit sensitive-key redaction", '[REDACTED]' in storage and 'client_secret' in storage)
check("Template publish route", '/api/templates/{tid}/publish' in main)
check("Template archive route", '/api/templates/{tid}/archive' in main)
check("Template version route", '/api/templates/{tid}/versions' in main)
check("Template history persisted", 'template_history_root' in storage and 'list_template_versions' in storage)
check("Execution evidence bundle", '/api/executions/{execution_id}/evidence-bundle' in main and 'build_execution_evidence_bundle' in service)
check("React Configuration Library", 'Configuration Library' in workspace and 'Import bundle' in workspace and 'Operator attribution' in workspace)
check("React template lifecycle", 'Publish' in templates and 'Archive' in templates and 'Versions' in templates)
check("React execution evidence download", 'Evidence bundle' in operations)
check("Configuration Library navigation", "label:'Configuration Library'" in sidebar and ('Phase 5' in sidebar or 'Phase 6' in sidebar))
check("Operator header client", 'X-HIP-Actor' in api and "hip.operator" in api)
check("Production launcher", (ROOT / 'RUN_AGENTIC_HIP_PRODUCTION.bat').exists() and (( 'bun run build' in (ROOT / 'RUN_AGENTIC_HIP_PRODUCTION.bat').read_text(encoding='utf-8')) or ('RUN_AGENTIC_HIP.bat' in (ROOT / 'RUN_AGENTIC_HIP_PRODUCTION.bat').read_text(encoding='utf-8'))))
check("Compiled React served by FastAPI", 'StaticFiles' in main and '_FRONTEND_DIST' in main)
check("Legacy Streamlit source retained or Phase6 archived", (ROOT/'hip_application_studio.py').exists())

try:
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    check("Exactly 18 reusable APIs at runtime", len(api_catalog()) == 18 and all(x.get("reusable") for x in api_catalog()))
    meta = transaction_metadata()
    check("Direction remains editable", meta.get("editable_direction") is True and meta.get("default_direction") == "Outbound")
except Exception as exc:
    check("Phase 5 Python imports", False, str(exc))

failed = [row for row in checks if not row["ok"]]
summary = {"status": "PASS" if not failed else "FAIL", "passed": len(checks)-len(failed), "failed": len(failed), "checks": checks}
print(json.dumps(summary, indent=2))
raise SystemExit(1 if failed else 0)
