# V55 — API Flow Game UI + Safe Individual Block Execution

V55 improves the API Flow Game as an operator workspace and adds a first-class way to check and run one API block without running the entire customer flow.

## Individual block execution

Select any API block on the Flow Game board. The inspector now exposes:

- **Agent check** — non-mutating. Rebuilds the effective request and checks the latest customer validation, block enabled state, API applicability, API contract, and standalone runtime dependencies.
- **Check & run this block LIVE** — runs the same agent check again immediately before the LIVE call. The API is never called if the fresh check is not PASS.

The server rechecks the block even if the browser previously showed it as READY. This prevents stale UI state from bypassing the LIVE gate.

## Runtime dependency safety

A block with incoming edge mappings is not considered standalone-ready because those mapped values come from upstream API outputs. The agent explains the dependency and asks the operator to either run the prerequisite/full flow, or replace the request with concrete values/remove the runtime mapping before a standalone run.

Unrelated blocks do not need to run just to prove one standalone-safe API.

## UI improvements

- Searchable API Block Deck.
- Flow health bar with checked, ready/pass, warning, needs-attention, runtime mapping, execution and retry counts.
- Selected block shows a clear hint that individual actions are available in the inspector.
- Inspector now has a dedicated individual-block action panel and compact agent-check results.
- Large JSON areas are constrained so the actions and verdict remain visible.
- WARNING has its own visual state instead of being displayed as a generic block failure.
- Human duration formatting is used on API nodes.

## Safety retained

V55 retains V54 response-verdict/report improvements, V53 final pre-LIVE validation and U-HAUL DUNS `12345666`, V52 short Windows parallel execution paths, single/multi-customer execution, snapshot integrity, payload editing, and final HTML reports.
