# V74 — Engineer Input Extraction Blueprint

V74 builds on V73 and incorporates the engineer-provided JSON screenshots as a formal, machine-readable field-source contract for automated `input.json` creation.

## Added

- `schemas/engineer_input_extraction_blueprint.json` — 66 extraction/source rules.
- `input_extraction_blueprint.py` — safe derivation, provenance and missing-value logic.
- Build Configuration now exposes Customer/Partner as an explicit fallback field.
- File Truth includes an Engineer Input Blueprint coverage panel.
- Customer Intake HTML includes blueprint provenance/coverage.
- Generated configs store `_input_extraction_blueprint` and audit metadata.
- Approved HIP JSON remains authoritative and does not receive new artificial questions.
- Blueprint questions are restricted to user-friendly scalar values; the agent/parser still owns complex JSON structures.

## Safety

- Legrand/U-HAUL examples are never customer defaults.
- No customer values are invented by the blueprint.
- SFTP/FTP/HTTPS/HTTPS-AS2 payload structure locks from V72 remain unchanged.
- U-HAUL Translation-only template and repeated same-customer parallel execution from V73 remain unchanged.
