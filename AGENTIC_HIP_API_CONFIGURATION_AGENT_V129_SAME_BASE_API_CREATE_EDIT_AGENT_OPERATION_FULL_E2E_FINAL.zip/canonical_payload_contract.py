from __future__ import annotations

"""Developer-approved 18-API request structure lock.

The outer 18 HIP API request structures are immutable. FILE (SFTP/FTP) uses the
final U-HAUL/dev-tested transport shape; HTTPS/REST and HTTPS-AS2 swap only the
reviewed interface parameter section. New customers change values only--never
attribute names, nesting, request kind, or array cardinality.

No reference-customer business value is copied into another customer. Missing
values remain neutral so normal validation/intake can request them explicitly.
"""

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple


ROOT = Path(__file__).resolve().parent
SCHEMA_PATH = ROOT / "schemas" / "uhal_canonical_18_request_shapes.json"
MIGRATION_SCHEMA_PATH = ROOT / "schemas" / "dev_published_migration_request_shapes.json"
INTERFACE_SCHEMA_PATH = ROOT / "schemas" / "dev_approved_transport_interface_shapes.json"
ADDITIVE_INTERFACE_SCHEMA_PATH = ROOT / "schemas" / "dev_supplied_nas_rabbitmq_interface_shapes.json"
ALIASES = {"map_primary": "map", "map_fallback": "map"}
_MISSING = object()


def canonical_step_key(step_key: str) -> str:
    key = str(step_key or "").strip()
    return ALIASES.get(key, key)


@lru_cache(maxsize=1)
def _catalog() -> Dict[str, Any]:
    """Historical immutable 18 create/configuration request catalog."""
    value = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("steps"), dict):
        raise ValueError(f"Canonical payload-shape catalog is invalid: {SCHEMA_PATH}")
    return value


@lru_cache(maxsize=1)
def _migration_catalog() -> Dict[str, Any]:
    """Additive Dev-published Migration request catalog (kept separate from 18)."""
    value = json.loads(MIGRATION_SCHEMA_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("steps"), dict):
        raise ValueError(f"Migration payload-shape catalog is invalid: {MIGRATION_SCHEMA_PATH}")
    return value


def _reference_for_step(step_key: str) -> str:
    key = canonical_step_key(step_key)
    cat = _migration_catalog() if key.startswith("migrate_") else _catalog()
    return str(cat.get("reference") or "Developer-approved request structure")


def catalog_summary() -> Dict[str, Any]:
    cat = _catalog()
    migration = _migration_catalog()
    steps = cat.get("steps") or {}
    migration_steps = migration.get("steps") or {}
    return {
        "version": cat.get("version"),
        "reference": cat.get("reference"),
        "policy": cat.get("policy"),
        "stepCount": len(steps),
        "migrationVersion": migration.get("version"),
        "migrationReference": migration.get("reference"),
        "migrationPolicy": migration.get("policy"),
        "migrationStepCount": len(migration_steps),
        "totalRegisteredStepCount": len(steps) + len(migration_steps),
        "path": str(SCHEMA_PATH),
        "migrationPath": str(MIGRATION_SCHEMA_PATH),
        "transportInterfaces": interface_shape_summary(include_additive=True),
    }


def step_contract(step_key: str) -> Dict[str, Any]:
    key = canonical_step_key(step_key)
    catalog = _migration_catalog() if key.startswith("migrate_") else _catalog()
    row = (catalog.get("steps") or {}).get(key)
    if not isinstance(row, dict):
        raise ValueError(f"No developer-approved canonical request structure is registered for HIP API step '{key}'.")
    return row


def canonical_request_kind(step_key: str) -> str:
    return str(step_contract(step_key).get("requestKind") or "payload")


@lru_cache(maxsize=1)
def _interface_catalog() -> Dict[str, Any]:
    """Historical FILE/HTTPS/HTTPS-AS2 interface family catalog."""
    value = json.loads(INTERFACE_SCHEMA_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("families"), dict):
        raise ValueError(f"Developer-approved interface-shape catalog is invalid: {INTERFACE_SCHEMA_PATH}")
    return value


@lru_cache(maxsize=1)
def _additive_interface_catalog() -> Dict[str, Any]:
    value = json.loads(ADDITIVE_INTERFACE_SCHEMA_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("families"), dict):
        raise ValueError(f"Additive interface-shape catalog is invalid: {ADDITIVE_INTERFACE_SCHEMA_PATH}")
    return value


def _all_interface_families() -> Dict[str, Any]:
    return {
        **dict(_interface_catalog().get("families") or {}),
        **dict(_additive_interface_catalog().get("families") or {}),
    }


def interface_family_from_type(interface_type: Any) -> str:
    raw = str(interface_type or "").strip().upper().replace("_", "-")
    if raw in {"SFTP", "SFTP HAFT", "SFTP-HAFT", "FTP"}:
        return "FILE"
    if raw in {"HTTPS-AS2", "AS2", "HTTPS AS2"}:
        return "HTTPS_AS2"
    if raw in {"HTTPS", "REST", "HTTPS REST"}:
        return "HTTPS"
    if raw == "NAS":
        return "NAS"
    if raw in {"RABBIT MQ", "RABBITMQ", "RABBIT-MQ"}:
        return "RABBIT_MQ"
    return ""


def _parameter_keys(family: str, role: str) -> List[str]:
    row = _all_interface_families().get(str(family or ""))
    if not isinstance(row, dict):
        raise ValueError(
            "CANONICAL_PAYLOAD_STRUCTURE_LOCK: no developer-approved payload attribute template "
            f"is registered for interface family '{family or 'UNKNOWN'}'."
        )
    role_row = row.get("source" if str(role).lower() == "source" else "target") or {}
    keys = role_row.get("keys") or []
    if not isinstance(keys, list) or not all(isinstance(x, str) and x for x in keys):
        raise ValueError(f"Invalid interface parameter-key catalog for {family}/{role}.")
    return list(keys)


def interface_shape_summary(*, include_additive: bool = False) -> Dict[str, Any]:
    """Describe transport interface schemas while preserving the frozen V72 view.

    `families` remains the historical FILE/HTTPS/HTTPS_AS2 set for backward
    compatibility. V122 additive NAS/Rabbit MQ contracts are exposed separately
    and, when requested, through `allFamilies`.
    """
    cat = _interface_catalog()
    additive = _additive_interface_catalog()

    def render(rows: Dict[str, Any]) -> Dict[str, Any]:
        return {
            family: {
                "reference": row.get("reference"),
                "interfaces": row.get("interfaces") or [],
                "sourceKeys": list((row.get("source") or {}).get("keys") or []),
                "targetKeys": list((row.get("target") or {}).get("keys") or []),
                "sourceAllowedValues": dict((row.get("source") or {}).get("allowedValues") or {}),
                "targetAllowedValues": dict((row.get("target") or {}).get("allowedValues") or {}),
                "sourceConditionalOmit": list((row.get("source") or {}).get("conditionalOmit") or []),
                "targetConditionalOmit": list((row.get("target") or {}).get("conditionalOmit") or []),
            }
            for family, row in rows.items()
            if isinstance(row, dict)
        }

    historical = render(dict(cat.get("families") or {}))
    additive_rows = render(dict(additive.get("families") or {}))
    output = {
        "version": cat.get("version"),
        "policy": cat.get("policy"),
        "path": str(INTERFACE_SCHEMA_PATH),
        "families": historical,
        "additiveVersion": additive.get("version"),
        "additiveReference": additive.get("reference"),
        "additivePolicy": additive.get("policy"),
        "additivePath": str(ADDITIVE_INTERFACE_SCHEMA_PATH),
        "additiveFamilies": additive_rows,
    }
    if include_additive:
        output["allFamilies"] = {**historical, **additive_rows}
    return output


def _interface_payload_section(step_key: str, value: Any) -> Tuple[str, Dict[str, Any]]:
    key = canonical_step_key(step_key)
    body = value if isinstance(value, dict) else {}
    if key in {"validate_source", "validate_target"}:
        return interface_family_from_type(body.get("interfaceType")), body.get("propertyMap") if isinstance(body.get("propertyMap"), dict) else {}
    if key in {"migrate_source_tp", "migrate_target_tp"}:
        return interface_family_from_type(body.get("transportProfileInterfaceType")), body.get("transportProfileInterfaceParameters") if isinstance(body.get("transportProfileInterfaceParameters"), dict) else {}
    if key in {"source_tp", "target_tp"}:
        details = body.get("transportProfileDetails")
        if isinstance(details, list) and details and isinstance(details[0], dict):
            interfaces = details[0].get("interfaceDetails")
            if isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], dict):
                item = interfaces[0]
                return interface_family_from_type(item.get("interfaceType")), item.get("parameters") if isinstance(item.get("parameters"), dict) else {}
    return "", {}


def _infer_family_from_parameter_keys(step_key: str, params: Dict[str, Any]) -> str:
    if not isinstance(params, dict) or not params:
        return ""
    role = "source" if canonical_step_key(step_key) in {"validate_source", "source_tp", "migrate_source_tp"} else "target"
    keys = set(params)
    scored = []
    for family in _all_interface_families():
        expected = set(_parameter_keys(family, role))
        score = len(keys & expected)
        if score:
            scored.append((score, family))
    scored.sort(reverse=True)
    return scored[0][1] if scored else ""


def interface_family_for_request(step_key: str, value: Any = None, fallback: Any = None, explicit: str | None = None) -> str:
    key = canonical_step_key(step_key)
    if key not in {"validate_source", "validate_target", "source_tp", "target_tp", "migrate_source_tp", "migrate_target_tp"}:
        return ""
    if explicit:
        fam = str(explicit).strip().upper()
        if fam in _all_interface_families():
            return fam
        by_type = interface_family_from_type(explicit)
        if by_type:
            return by_type
    for candidate in (value, fallback):
        body = candidate if isinstance(candidate, dict) else {}
        raw_type = ""
        if key in {"validate_source", "validate_target"}:
            raw_type = str(body.get("interfaceType") or "").strip()
        elif key in {"migrate_source_tp", "migrate_target_tp"}:
            raw_type = str(body.get("transportProfileInterfaceType") or "").strip()
        elif key in {"source_tp", "target_tp"}:
            details = body.get("transportProfileDetails")
            if isinstance(details, list) and details and isinstance(details[0], dict):
                interfaces = details[0].get("interfaceDetails")
                if isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], dict):
                    raw_type = str(interfaces[0].get("interfaceType") or "").strip()
        fam, params = _interface_payload_section(key, candidate)
        if fam:
            return fam
        if raw_type:
            raise ValueError(
                "CANONICAL_PAYLOAD_STRUCTURE_LOCK: interface type " + repr(raw_type) +
                " has no developer-approved LIVE payload template. Register the exact dev-team "
                "interfaceDetails attributes before using it in the 18-API execution path."
            )
        inferred = _infer_family_from_parameter_keys(key, params)
        if inferred:
            return inferred
    # Legacy partial overrides may contain neither interfaceType nor enough
    # parameter evidence. FILE is the historical baseline only in that narrow
    # no-evidence case; a concrete unsupported interfaceType is never coerced.
    return "FILE"


def interface_family_from_workspace(root: Path, step_key: str) -> str:
    key = canonical_step_key(step_key)
    if key not in {"validate_source", "validate_target", "source_tp", "target_tp", "migrate_source_tp", "migrate_target_tp"}:
        return ""
    path = Path(root) / "input.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            objects = data.get("objects") or {}
            tp_key = "source_transport_profile" if key in {"validate_source", "source_tp", "migrate_source_tp"} else "target_transport_profile"
            tp = objects.get(tp_key) or {}
            raw_type = str(tp.get("interface_type") or "").strip()
            family = interface_family_from_type(raw_type)
            if family:
                return family
            if raw_type:
                raise ValueError(
                    "CANONICAL_PAYLOAD_STRUCTURE_LOCK: interface type " + repr(raw_type) +
                    " has no developer-approved LIVE payload template."
                )
        except Exception:
            pass
    return "FILE"


def _parameter_role_contract(family: str, role: str) -> Dict[str, Any]:
    row = _all_interface_families().get(str(family or ""))
    if not isinstance(row, dict):
        return {}
    return dict(row.get("source" if str(role).lower() == "source" else "target") or {})


def _parameter_schema(family: str, role: str) -> Dict[str, Any]:
    return {"type": "object", "keys": {name: {"type": "string"} for name in _parameter_keys(family, role)}}


def _apply_parameter_conditionals(family: str, role: str, params: Dict[str, Any], issues: Dict[str, List[Any]]) -> Dict[str, Any]:
    """Apply Dev-documented enum/conditional rules without inventing values."""
    out = dict(params or {})
    contract = _parameter_role_contract(family, role)

    # Exact enum values supplied by Dev are part of the value contract.
    for field, allowed in (contract.get("allowedValues") or {}).items():
        actual = out.get(field)
        if actual in (None, ""):
            continue
        canonical = {str(v).strip().lower(): str(v) for v in (allowed or [])}
        raw = str(actual).strip()
        if raw.lower() not in canonical:
            issues.setdefault("valueConflicts", []).append({
                "path": f"parameters.{field}", "value": actual, "allowedValues": list(allowed or [])
            })
        else:
            out[field] = canonical[raw.lower()]

    # Dev-supplied conditional validations (NAS).
    for rule in contract.get("conditionalValidation") or []:
        if not isinstance(rule, dict):
            continue
        when_field = str(rule.get("whenField") or "")
        when_values = {str(v).strip().lower() for v in (rule.get("whenValues") or [])}
        if str(out.get(when_field) or "").strip().lower() not in when_values:
            continue
        field = str(rule.get("field") or "")
        actual = out.get(field)
        if rule.get("required") and str(actual or "").strip() == "":
            issues.setdefault("valueConflicts", []).append({
                "path": f"parameters.{field}", "value": actual, "message": str(rule.get("note") or f"{field} is required")
            })
        allowed = list(rule.get("allowedValues") or [])
        if allowed and str(actual or "").strip() and str(actual).strip().lower() not in {str(v).strip().lower() for v in allowed}:
            issues.setdefault("valueConflicts", []).append({
                "path": f"parameters.{field}", "value": actual, "allowedValues": allowed, "message": str(rule.get("note") or "Conditional value is invalid")
            })

    for rule in contract.get("conditionalOmit") or []:
        if not isinstance(rule, dict):
            continue
        field = str(rule.get("field") or "")
        when_field = str(rule.get("whenField") or "")
        when_values = {str(v).strip().lower() for v in (rule.get("whenValues") or [])}
        actual = str(out.get(when_field) or "").strip().lower()
        if field and when_field and actual in when_values and field in out:
            out.pop(field, None)
            issues.setdefault("conditionallyOmittedPaths", []).append(
                f"parameters.{field}"
            )
    return out


def _apply_interface_parameter_rules(step_key: str, normalized: Any, family: str, issues: Dict[str, List[Any]]) -> Any:
    key = canonical_step_key(step_key)
    role = "source" if key in {"validate_source", "source_tp", "migrate_source_tp"} else "target"
    if key in {"validate_source", "validate_target"} and isinstance(normalized, dict):
        params = normalized.get("propertyMap")
        if isinstance(params, dict):
            normalized["propertyMap"] = _apply_parameter_conditionals(family, role, params, issues)
    elif key in {"migrate_source_tp", "migrate_target_tp"} and isinstance(normalized, dict):
        params = normalized.get("transportProfileInterfaceParameters")
        if isinstance(params, dict):
            normalized["transportProfileInterfaceParameters"] = _apply_parameter_conditionals(family, role, params, issues)
    elif key in {"source_tp", "target_tp"} and isinstance(normalized, dict):
        details = normalized.get("transportProfileDetails")
        if isinstance(details, list) and details and isinstance(details[0], dict):
            interfaces = details[0].get("interfaceDetails")
            if isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], dict):
                params = interfaces[0].get("parameters")
                if isinstance(params, dict):
                    interfaces[0]["parameters"] = _apply_parameter_conditionals(family, role, params, issues)
    return normalized


def _effective_step_contract(step_key: str, value: Any = None, fallback: Any = None, interface_family: str | None = None) -> Tuple[Dict[str, Any], str]:
    key = canonical_step_key(step_key)
    contract = deepcopy(step_contract(key))
    if key not in {"validate_source", "validate_target", "source_tp", "target_tp", "migrate_source_tp", "migrate_target_tp"}:
        return contract, ""
    family = interface_family_for_request(key, value=value, fallback=fallback, explicit=interface_family)
    role = "source" if key in {"validate_source", "source_tp", "migrate_source_tp"} else "target"
    param_schema = _parameter_schema(family, role)
    schema = contract.get("schema") or {}
    if key in {"validate_source", "validate_target"}:
        schema["keys"]["propertyMap"] = param_schema
    elif key in {"migrate_source_tp", "migrate_target_tp"}:
        schema["keys"]["transportProfileInterfaceParameters"] = param_schema
    else:
        schema["keys"]["transportProfileDetails"]["items"][0]["keys"]["interfaceDetails"]["items"][0]["keys"]["parameters"] = param_schema
    contract["schema"] = schema
    contract["interfaceFamily"] = family
    contract["interfaceReference"] = (_all_interface_families().get(family) or {}).get("reference")
    return contract, family


def _neutral(schema: Dict[str, Any]) -> Any:
    typ = str(schema.get("type") or "")
    if typ == "object":
        return {key: _neutral(child) for key, child in (schema.get("keys") or {}).items()}
    if typ == "array":
        return []
    if typ == "string":
        return ""
    if typ == "number":
        return 0
    if typ == "boolean":
        return False
    if typ == "null":
        return None
    return None


def _is_nonblank_template(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    text = value.strip()
    return (text.startswith("{{") and text.endswith("}}")) or (text.startswith("${") and text.endswith("}"))


def _scalar(value: Any, schema: Dict[str, Any], path: str, issues: Dict[str, List[Any]]) -> Any:
    typ = str(schema.get("type") or "")
    if typ == "null":
        if value is not None:
            issues["coercedPaths"].append({"path": path, "reason": "canonical field is null-only"})
        return None
    if value is _MISSING:
        return _neutral(schema)
    if _is_nonblank_template(value):
        return value
    if typ == "string":
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        issues["coercedPaths"].append({"path": path, "fromType": type(value).__name__, "toType": "string"})
        return str(value)
    if typ == "number":
        if isinstance(value, bool):
            issues["typeConflicts"].append({"path": path, "expected": "number", "actual": "boolean"})
            return value
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, str):
            text = value.strip()
            try:
                parsed = float(text)
                if parsed.is_integer() and "." not in text:
                    return int(parsed)
                return parsed
            except Exception:
                issues["typeConflicts"].append({"path": path, "expected": "number", "actual": "string"})
                return value
        issues["typeConflicts"].append({"path": path, "expected": "number", "actual": type(value).__name__})
        return value
    if typ == "boolean":
        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
            return value.strip().lower() == "true"
        issues["typeConflicts"].append({"path": path, "expected": "boolean", "actual": type(value).__name__})
        return value
    return deepcopy(value)


def _normalize(
    candidate: Any,
    schema: Dict[str, Any],
    fallback: Any,
    path: str,
    issues: Dict[str, List[Any]],
) -> Any:
    typ = str(schema.get("type") or "")

    if typ == "object":
        cand = candidate if isinstance(candidate, dict) else {}
        fb = fallback if isinstance(fallback, dict) else {}
        if candidate is not _MISSING and candidate is not None and not isinstance(candidate, dict):
            issues["typeConflicts"].append({"path": path or "$", "expected": "object", "actual": type(candidate).__name__})
        canonical_keys = schema.get("keys") or {}
        for extra in cand.keys() - canonical_keys.keys():
            issues["droppedPaths"].append(f"{path}.{extra}" if path else str(extra))
        out: Dict[str, Any] = {}
        for key, child_schema in canonical_keys.items():
            child_path = f"{path}.{key}" if path else str(key)
            if key in cand:
                chosen = cand[key]
            elif key in fb:
                chosen = fb[key]
                issues["filledFromGeneratedPaths"].append(child_path)
            else:
                chosen = _MISSING
                issues["neutralFilledPaths"].append(child_path)
            child_fb = fb.get(key, _MISSING)
            out[key] = _normalize(chosen, child_schema, child_fb, child_path, issues)
        return out

    if typ == "array":
        cand_list = candidate if isinstance(candidate, list) else []
        fb_list = fallback if isinstance(fallback, list) else []
        if candidate not in (_MISSING, None) and not isinstance(candidate, list):
            issues["typeConflicts"].append({"path": path, "expected": "array", "actual": type(candidate).__name__})
        item_schemas = list(schema.get("items") or [])
        expected_len = int(schema.get("length", len(item_schemas)) or 0)
        if len(cand_list) > expected_len:
            for index in range(expected_len, len(cand_list)):
                issues["droppedPaths"].append(f"{path}[{index}]")
        out = []
        for index in range(expected_len):
            item_schema = item_schemas[index] if index < len(item_schemas) else {}
            if index < len(cand_list):
                item = cand_list[index]
            elif index < len(fb_list):
                item = fb_list[index]
                issues["filledFromGeneratedPaths"].append(f"{path}[{index}]")
            else:
                item = _MISSING
                issues["neutralFilledPaths"].append(f"{path}[{index}]")
            item_fb = fb_list[index] if index < len(fb_list) else _MISSING
            out.append(_normalize(item, item_schema, item_fb, f"{path}[{index}]", issues))
        return out

    selected = candidate
    if selected is _MISSING:
        if fallback is not _MISSING:
            selected = fallback
        else:
            selected = _MISSING

    if typ == "string" and schema.get("jsonStringSchema"):
        text = selected if isinstance(selected, str) else ""
        try:
            parsed = json.loads(text) if text else _MISSING
        except Exception as exc:
            issues["invalidJsonStrings"].append({"path": path, "error": str(exc)})
            parsed = _MISSING
        fb_parsed = _MISSING
        if isinstance(fallback, str) and fallback:
            try:
                fb_parsed = json.loads(fallback)
            except Exception:
                fb_parsed = _MISSING
        normalized = _normalize(parsed, schema["jsonStringSchema"], fb_parsed, path + ".<json>", issues)
        return json.dumps(normalized, separators=(",", ":"), ensure_ascii=True, default=str)

    return _scalar(selected, schema, path, issues)


def lock_request_value(
    step_key: str,
    request_kind: str,
    value: Any,
    *,
    fallback: Any = None,
    strict_unknown: bool = False,
    interface_family: str | None = None,
) -> Tuple[Any, Dict[str, Any]]:
    """Return the request using the immutable developer-approved attribute structure.

    `fallback` must be the customer's generated request, never reference-customer values.  It is used only to restore canonical fields that a replace-style edit
    omitted.  Unknown attributes are never emitted.
    """
    key = canonical_step_key(step_key)
    contract, resolved_family = _effective_step_contract(key, value=value, fallback=fallback, interface_family=interface_family)
    expected_kind = str(contract.get("requestKind") or "payload")
    actual_kind = str(request_kind or expected_kind)
    if actual_kind != expected_kind:
        raise ValueError(
            f"CANONICAL_PAYLOAD_STRUCTURE_LOCK: {key} uses {expected_kind}; "
            f"it cannot be changed to {actual_kind}. Only request values are editable."
        )
    issues: Dict[str, List[Any]] = {
        "droppedPaths": [],
        "filledFromGeneratedPaths": [],
        "neutralFilledPaths": [],
        "coercedPaths": [],
        "typeConflicts": [],
        "invalidJsonStrings": [],
        "conditionallyOmittedPaths": [],
        "valueConflicts": [],
    }
    normalized = _normalize(value if value is not None else {}, contract.get("schema") or {}, fallback if fallback is not None else _MISSING, "", issues)
    if resolved_family:
        normalized = _apply_interface_parameter_rules(key, normalized, resolved_family, issues)
    if issues.get("valueConflicts"):
        first = issues["valueConflicts"][0]
        allowed = first.get("allowedValues") or []
        suffix = ("; allowed values are " + ", ".join(map(str, allowed))) if allowed else ""
        raise ValueError("INVALID_INTERFACE_VALUE: " + str(first.get("path") or "parameters") + "=" + repr(first.get("value")) + suffix + (". " + str(first.get("message")) if first.get("message") else ""))
    meta: Dict[str, Any] = {
        "locked": True,
        "reference": _reference_for_step(key),
        "policy": "Payload attributes are immutable; only customer-specific values may change.",
        "stepKey": key,
        "requestKind": expected_kind,
        "interfaceFamily": resolved_family or None,
        "interfaceReference": contract.get("interfaceReference"),
        **issues,
    }
    meta["sanitized"] = bool(
        issues["droppedPaths"]
        or issues["filledFromGeneratedPaths"]
        or issues["neutralFilledPaths"]
        or issues["coercedPaths"]
        or issues["typeConflicts"]
        or issues["invalidJsonStrings"]
        or issues["conditionallyOmittedPaths"]
    )
    if strict_unknown and (issues["droppedPaths"] or issues["invalidJsonStrings"]):
        details = []
        if issues["droppedPaths"]:
            details.append("non-canonical attributes: " + ", ".join(issues["droppedPaths"][:20]))
        if issues["invalidJsonStrings"]:
            details.append("invalid nested JSON: " + json.dumps(issues["invalidJsonStrings"][:5], ensure_ascii=False))
        raise ValueError(
            "CANONICAL_PAYLOAD_STRUCTURE_LOCK: Only values may change; " + "; ".join(details)
        )
    return normalized, meta


def validate_override_structure(step_key: str, request_kind: str, value: Any, *, interface_family: str | None = None) -> Dict[str, Any]:
    """Validate an editor/Flow override without requiring every canonical field.

    Merge and replace editors are both *value* editors now. Missing canonical keys
    are allowed because the generated customer request keeps them; unknown keys are
    rejected because they would change the developer-approved API contract.
    """
    key = canonical_step_key(step_key)
    expected_kind = canonical_request_kind(key)
    errors: List[Dict[str, Any]] = []
    if str(request_kind or expected_kind) != expected_kind:
        errors.append({"field": "requestKind", "message": f"{key} must remain {expected_kind}; only values can change."})
        return {"valid": False, "stepKey": key, "requestKind": expected_kind, "errors": errors}

    try:
        _normalized, meta = lock_request_value(key, expected_kind, value, fallback={}, strict_unknown=False, interface_family=interface_family)
    except Exception as exc:
        return {"valid": False, "stepKey": key, "requestKind": expected_kind, "errors": [{"field": "request", "message": str(exc)}]}

    for path in meta.get("droppedPaths") or []:
        errors.append({"field": path, "message": "This attribute is not part of the developer-approved canonical payload for this interface. Change the value of an existing canonical field instead."})
    for item in meta.get("invalidJsonStrings") or []:
        errors.append({"field": item.get("path") or "flowDefinition", "message": "Nested JSON must preserve the canonical Flow Definition structure."})
    # Object/array type changes are structural. Scalar type differences are left
    # for the existing API contract validator, which has API-specific rules.
    for item in meta.get("typeConflicts") or []:
        if item.get("expected") in {"object", "array"}:
            errors.append({"field": item.get("path") or "request", "message": f"Expected canonical {item.get('expected')} structure, got {item.get('actual')}."})
    return {
        "valid": not errors,
        "stepKey": key,
        "requestKind": expected_kind,
        "errors": errors,
        "canonicalStructure": meta,
    }


def canonical_leaf_paths(step_key: str, *, interface_family: str | None = None) -> List[str]:
    """Return canonical editable leaf paths for the selected interface family."""
    contract, _family = _effective_step_contract(step_key, interface_family=interface_family)
    schema = contract.get("schema") or {}
    out: List[str] = []

    def walk(node: Dict[str, Any], prefix: str) -> None:
        typ = str(node.get("type") or "")
        if typ == "object":
            for key, child in (node.get("keys") or {}).items():
                walk(child, f"{prefix}.{key}" if prefix else key)
            return
        if typ == "array":
            items = list(node.get("items") or [])
            if not items:
                out.append(prefix)
            else:
                for index, item in enumerate(items):
                    walk(item, f"{prefix}.{index}")
            return
        if node.get("jsonStringSchema"):
            # Flow Definition is transported as one string field. Graph mappings
            # cannot address its internal JSON directly.
            out.append(prefix)
            return
        out.append(prefix)

    walk(schema, "")
    return out


def sanitize_override_patch(step_key: str, request_kind: str, value: Any, *, interface_family: str | None = None) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Remove non-canonical attributes from a stored partial override.

    Unlike :func:`lock_request_value`, this does not add fields that were absent
    from the override.  It is therefore safe for migration of old merge/replace
    records; the generated customer request supplies all omitted canonical fields
    when the override is applied.
    """
    key = canonical_step_key(step_key)
    expected_kind = canonical_request_kind(key)
    if str(request_kind or expected_kind) != expected_kind:
        request_kind = expected_kind
    issues: Dict[str, List[Any]] = {"droppedPaths": [], "invalidJsonStrings": [], "typeConflicts": []}

    def partial(candidate: Any, schema: Dict[str, Any], path: str) -> Any:
        typ = str(schema.get("type") or "")
        if typ == "object":
            if not isinstance(candidate, dict):
                issues["typeConflicts"].append({"path": path or "$", "expected": "object", "actual": type(candidate).__name__})
                return {}
            canonical_keys = schema.get("keys") or {}
            out: Dict[str, Any] = {}
            for extra in candidate.keys() - canonical_keys.keys():
                issues["droppedPaths"].append(f"{path}.{extra}" if path else str(extra))
            for name, child in canonical_keys.items():
                if name in candidate:
                    out[name] = partial(candidate[name], child, f"{path}.{name}" if path else name)
            return out
        if typ == "array":
            if not isinstance(candidate, list):
                issues["typeConflicts"].append({"path": path, "expected": "array", "actual": type(candidate).__name__})
                return []
            item_schemas = list(schema.get("items") or [])
            expected_len = int(schema.get("length", len(item_schemas)) or 0)
            if len(candidate) > expected_len:
                for index in range(expected_len, len(candidate)):
                    issues["droppedPaths"].append(f"{path}[{index}]")
            return [
                partial(candidate[i], item_schemas[i], f"{path}[{i}]")
                for i in range(min(len(candidate), expected_len, len(item_schemas)))
            ]
        if typ == "string" and schema.get("jsonStringSchema") and isinstance(candidate, str):
            try:
                parsed = json.loads(candidate)
            except Exception as exc:
                issues["invalidJsonStrings"].append({"path": path, "error": str(exc)})
                return candidate
            cleaned = partial(parsed, schema["jsonStringSchema"], path + ".<json>")
            return json.dumps(cleaned, separators=(",", ":"), ensure_ascii=True, default=str)
        return deepcopy(candidate)

    effective_contract, resolved_family = _effective_step_contract(key, value=value, interface_family=interface_family)
    cleaned = partial(value if isinstance(value, dict) else {}, effective_contract.get("schema") or {}, "")
    meta = {
        "locked": True,
        "stepKey": key,
        "requestKind": expected_kind,
        "reference": _reference_for_step(key),
        "interfaceFamily": resolved_family or None,
        "interfaceReference": effective_contract.get("interfaceReference"),
        **issues,
    }
    meta["sanitized"] = bool(issues["droppedPaths"] or issues["invalidJsonStrings"] or issues["typeConflicts"])
    return cleaned, meta
