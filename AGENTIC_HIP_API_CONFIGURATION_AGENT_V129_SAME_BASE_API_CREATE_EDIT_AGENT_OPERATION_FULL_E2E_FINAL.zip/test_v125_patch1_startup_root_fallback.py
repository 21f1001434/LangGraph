from pathlib import Path


def test_backend_root_has_frontend_missing_fallback():
    source = Path('webapp/backend/app/main.py').read_text(encoding='utf-8')
    assert '_FRONTEND_INDEX.is_file()' in source
    assert 'def frontend_not_built()' in source
    assert 'HIP API Agent Studio backend is running' in source
    assert 'bun run build' in source
    assert '/api/health' in source


def test_windows_production_runner_auto_builds_missing_frontend():
    bat = Path('RUN_AGENTIC_HIP.bat').read_text(encoding='utf-8')
    assert 'if not exist "webapp\\frontend\\dist\\index.html"' in bat
    assert 'bun install' in bat
    assert 'bun run build' in bat
    assert 'runtime_preflight.py --production' in bat
    assert '--reload' not in bat


def test_powershell_runner_auto_builds_missing_frontend():
    ps = Path('RUN_AGENTIC_HIP.ps1').read_text(encoding='utf-8')
    assert "webapp\\frontend\\dist\\index.html" in ps
    assert 'bun install' in ps
    assert 'bun run build' in ps
    assert 'runtime_preflight.py --production' in ps
    assert '--reload' not in ps
