from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT / 'webapp' / 'frontend' / 'src'
TYPES = (FRONTEND / 'types.ts').read_text(encoding='utf-8')
API = (FRONTEND / 'lib' / 'api.ts').read_text(encoding='utf-8')
PAGE = (FRONTEND / 'pages' / 'ExcelApiMapperPage.tsx').read_text(encoding='utf-8')
BUILDER = (FRONTEND / 'pages' / 'BuilderPage.tsx').read_text(encoding='utf-8')


def test_mapper_shared_types_are_exported():
    assert 'export type IntelligentMapperResult' in TYPES
    assert 'export type IntelligentMappingRow' in TYPES
    assert 'export type IntelligentColumnMapping' in TYPES
    assert 'export type IntelligentApiAlternative' in TYPES


def test_mapper_api_client_method_is_present_and_typed():
    assert 'IntelligentMapperResult' in API.splitlines()[0]
    assert 'analyzeWorkbook:async' in API
    assert 'request<IntelligentMapperResult>' in API
    assert '/intelligent-mapper/analyze' in API
    assert "form.append('workbook',file)" in API
    assert "form.append('api_key',apiKey)" in API
    assert "form.append('sheet_name',sheetName)" in API
    assert "form.append('header_row'" in API
    assert "form.append('use_dell_aia'" in API


def test_mapper_page_imports_shared_contract_and_explicitly_types_callbacks():
    assert 'IntelligentMapperResult' in PAGE
    assert 'IntelligentMappingRow' in PAGE
    assert "row:IntelligentMapperResult['sheets'][number]" in PAGE
    assert 'row:IntelligentMappingRow,index:number' in PAGE
    assert 'warning:string,i:number' in PAGE
    assert "m:IntelligentMappingRow['mappings'][number],i:number" in PAGE
    assert "NonNullable<IntelligentMappingRow['apiAlternatives']>[number]" in PAGE
    assert 'name:string' in PAGE


def test_builder_v124_fix_is_preserved():
    assert "import { useEffect, useMemo, useState } from 'react'" in BUILDER
    assert 'ApiCatalogItem' in BUILDER
    assert 'useMemo<ApiCatalogItem[]>' in BUILDER


def test_mapper_governance_stays_user_gated_and_schema_locked():
    assert 'Approve & stage values' in PAGE
    assert 'Run API LIVE' in PAGE
    assert 'They cannot add/remove/rename attributes or alter structure' in PAGE
    assert 'savePayloadOverride' in PAGE
