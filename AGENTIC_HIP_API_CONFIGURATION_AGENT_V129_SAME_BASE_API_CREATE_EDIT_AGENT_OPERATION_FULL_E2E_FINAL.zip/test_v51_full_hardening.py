from __future__ import annotations

import json
from pathlib import Path

import pytest

from webapp.backend.app import main
from webapp.backend.app.models import ConfigurationPatch
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.report_renderer import render_parallel_batch_html
from webapp.backend.app.storage import JsonStore

ROOT = Path(__file__).resolve().parent


def test_queue_integrity_covers_payload_overrides_not_only_input(tmp_path: Path):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    source = tmp_path / "source"
    source.mkdir()
    (source / "input.json").write_text(json.dumps({"customer": "DEMO", "direction": "Inbound", "tx_code": "850"}), encoding="utf-8")
    (source / "payload_overrides.json").write_text(json.dumps({"version": 1, "overrides": {}}), encoding="utf-8")
    config = {"id": "cfg1", "workspace": str(source), "customer": "DEMO", "name": "DEMO"}
    queued = manager.queue_configuration(config, {"ok": True, "requests": {"validCount": 18, "total": 18}})
    assert queued.get("snapshotHashes", {}).get("payload_overrides.json")
    row = manager.list_queue()[0]
    assert row["ready"] is True

    queued_workspace = Path(row["workspace"])
    (queued_workspace / "payload_overrides.json").write_text(json.dumps({"version": 1, "overrides": {"map": {"enabled": True}}}), encoding="utf-8")
    changed = manager.list_queue()[0]
    assert changed["ready"] is False
    assert changed["integrityOk"] is False
    assert "Re-queue" in changed["readinessReason"]


def test_configuration_patch_invalidates_old_validation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    store = JsonStore(tmp_path / "runtime")
    monkeypatch.setattr(main, "STORE", store)
    cfg = store.create_configuration({
        "name": "OLD", "customer": "OLD", "direction": "Outbound", "transaction_code": "856",
        "transaction_name": "", "flow_type": "Translation", "source_interface": "SFTP", "target_interface": "SFTP",
        "input_mode": "files", "user_instructions": "",
    })
    store.update_configuration(cfg["id"], {"validation": {"ok": True, "requests": {"validCount": 18, "total": 18}}, "status": "VALIDATED"})
    updated = main.patch_configuration(cfg["id"], ConfigurationPatch(customer="NEW"))
    assert updated["customer"] == "NEW"
    assert updated["validation"] == {}
    assert updated["status"] == "CONFIGURATION_CHANGED"


def test_parallel_final_report_can_embed_full_customer_html():
    customer_html = "<!doctype html><html><body><h1>FULL CUSTOMER REQUEST RESPONSE EVIDENCE</h1></body></html>"
    html = render_parallel_batch_html(
        {"batchId": "b1", "parallelWorkers": 1, "configurationCount": 1, "passCount": 1, "blockedCount": 0, "elapsedSeconds": 1.2,
         "results": [{"jobId": "j1", "customer": "DEMO", "status": "PASS", "stepTimings": []}]},
        [{"jobId": "j1", "reportName": "customer.html", "reportHtml": customer_html}],
    )
    assert "Open full customer execution report" in html
    assert "srcdoc=" in html
    assert "FULL CUSTOMER REQUEST RESPONSE EVIDENCE" in html


def test_single_multi_queue_selection_is_strict_in_react_ui():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    assert "Single-customer mode requires exactly one queued payload set" in page
    assert "Multiple-customer mode requires at least two queued payload sets" in page
    assert "runMode==='single'?(v.includes(id)?[]:[id])" in page
    assert "runMode==='multiple'&&<button className=\"ghost\"" in page


def test_payload_edits_are_audited_and_api_errors_are_human_readable():
    backend = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    assert "PAYLOAD_VALUE_EDIT_SAVED" in backend
    assert "Payload value editing is HUMAN USER ONLY" in backend
    assert "PAYLOAD_OVERRIDE_CLEARED" in backend
    assert "parsed?.detail||parsed?.message" in api


def test_parallel_runner_has_idle_heartbeats_and_timeout():
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert "HIP_PARALLEL_JOB_TIMEOUT_SECONDS" in manager
    assert "job.heartbeat" in manager
    assert "elapsedSeconds" in manager
    assert "process.terminate()" in manager
