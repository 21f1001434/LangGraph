@echo off
cd /d "%~dp0"
python final_self_check.py
