from __future__ import annotations

import gzip
import json
import tempfile
import zipfile
from pathlib import Path

from input_builder_artifacts import flatten_json
from input_builder_aia_adapter import DELL_AIA_BASE_DEFAULT, resolve_base_url
from input_builder_core import (
    _profile_runner_value,
    _set_flattened_path,
    build_from_raw_files,
    normalize_input_json,
)


def test_flattened_profile_runner_reconstruction():
    rows = [
        ("profile_name", "CUSTOMER_PC_850_PREMIER_MAPPING_IB"),
        ("customer", "CUSTOMER"),
        ("direction", "Inbound"),
        ("flow_type", "translation"),
        ("requires_data_map", "True"),
        ("objects.data_map.map_identifier", "MAP_CUSTOMER"),
        ("objects.data_map.map_name", "MAP"),
        ("objects.rule.name", "MAP_CUSTOMER_RULE"),
        ("objects.source_document_type.name", "XML_SRC"),
        ("objects.source_document_type.version", "1"),
        ("objects.target_document_type.name", "XML_TGT"),
        ("objects.target_document_type.version", "1"),
        ("objects.source_transport_profile.profile_name", "SFTP_CUSTOMER_SRC_IB"),
        ("objects.source_transport_profile.document_type", "XML_SRC(1.0)"),
        ("objects.target_transport_profile.profile_name", "SFTP_CUSTOMER_TGT_OB"),
        ("objects.target_transport_profile.document_type", "XML_TGT(1.0)"),
        ("objects.biz_flow.configure_source.source_transport_profile", "SFTP_CUSTOMER_SRC_IB"),
        ("objects.biz_flow.configure_targets.target_transport_profile", "SFTP_CUSTOMER_TGT_OB"),
    ]
    cfg = {}
    for path, value in rows:
        _set_flattened_path(cfg, path, _profile_runner_value(value, path))
    out = normalize_input_json(cfg)
    assert out["profile_name"] == "CUSTOMER_PC_850_PREMIER_MAPPING_IB"
    assert out["customer"] == "CUSTOMER"
    assert out["flow_type"] == "translation"
    assert out["requires_data_map"] is True
    assert out["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert out["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"


def test_raw_builder_and_contivo_metadata():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / "CUSTOMER_PO.xml").write_text(
            "<PurchaseOrderCollection><PurchaseOrderItem><BuyerParty><CompanyName>CUSTOMER</CompanyName>"
            "</BuyerParty><SellerParty><SupplierName>Dell</SupplierName></SellerParty>"
            "<PurchaseOrderNo>123</PurchaseOrderNo><Currency>EUR</Currency></PurchaseOrderItem>"
            "</PurchaseOrderCollection>", encoding="utf-8")
        xbm = '<transformMap logicalName="MAP850" analystVersionLastSaved="6.7.2"><sources><schemaRoot logicalName="PurchaseOrderCollection"/></sources><targets><schemaRoot logicalName="PurchaseOrder"/></targets></transformMap>'
        (root / "MAP850.xbm").write_bytes(gzip.compress(xbm.encode("utf-8")))
        with zipfile.ZipFile(root / "Transform_MAP850.jar", "w") as zf:
            zf.writestr("com/dell/Transform_MAP850.class", b"class")
        cfg = build_from_raw_files(list(root.iterdir()), customer="CUSTOMER", direction="Inbound",
                                   flow_type="translation", use_dell_aia=False)
        assert cfg["objects"]["data_map"]["map_name"] == "MAP850"
        assert cfg["objects"]["data_map"]["map_class"] == "Transform_MAP850"
        assert cfg["objects"]["data_map"]["contivo_version"] == "6.7.2"
        assert cfg["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
        assert cfg["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
        assert cfg["_agent"]["llm_invoked"] is False


def test_flatten_output_has_profile_runner_paths():
    cfg = {"objects": {"biz_flow": {"process_steps": [{"configuration": {"action": "Mapping"}}]}}}
    flat = dict(flatten_json(cfg))
    assert flat["objects.biz_flow.process_steps[0].configuration.action"] == "Mapping"


def test_dell_aia_public_openai_block(monkeypatch=None):
    import os
    old = os.environ.get("BASE_URL")
    try:
        os.environ["BASE_URL"] = "https://api.openai.com/v1"
        assert resolve_base_url() == DELL_AIA_BASE_DEFAULT
    finally:
        if old is None: os.environ.pop("BASE_URL", None)
        else: os.environ["BASE_URL"] = old


def main():
    test_flattened_profile_runner_reconstruction()
    test_raw_builder_and_contivo_metadata()
    test_flatten_output_has_profile_runner_paths()
    test_dell_aia_public_openai_block()
    print("PASS: standalone Dell AIA Input Builder smoke tests")


if __name__ == "__main__":
    main()
