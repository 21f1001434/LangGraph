# V80 Final — Developer-Approved U-HAUL Reference

## What is fixed

V80 separates **developer approval** from **runtime/pre-LIVE readiness**.

### U-HAUL reference
- `U-HAUL Outbound 856 Translation` is a first-class configuration.
- The packaged U-HAUL reference is marked `DEV_APPROVED`, `TEST READY`, and immutable.
- Its approval view reports 18/18 approved API contracts.
- Customer validation, stale browser state, or a previously persisted blocker cannot downgrade the original reference to `BLOCKED`.
- Direct edits, delete, customer-file replacement, rebuild, validation fixes, and persistent payload overrides on the approved reference are rejected server-side.
- API Testing and Flow Game can use the approved reference directly.
- Runtime credentials, endpoint connectivity, and LIVE preflight remain real safety checks, but are shown as runtime conditions rather than configuration-approval failures.

### Create from U-HAUL
- `Create from U-HAUL` makes a separate editable customer configuration.
- The clone does **not** inherit immutable developer-approval status.
- Customer changes, evidence conflicts, missing values, and 18-API validation belong to the clone.
- A clone can become `NEEDS INPUT` / `BLOCKED` without changing the approved U-HAUL reference.

### Guided blocker repair
For editable customer configurations, `Fix now` opens a guided resolution dialog. File evidence and the user's selected value are shown side by side, and the user can choose either one or enter another value. The answer is saved into the canonical configuration and revalidated before execution can continue.

### UI
- Product name: **HIP API Agent Studio**.
- User-facing React/React-native branding has been removed from the home page/runtime status.
- U-HAUL is easy to open for testing or use as a starter.
- Approved U-HAUL does not show a misleading `Fix now` button.
- New/edited customer configurations retain guided `Fix now` behavior.

## Validation performed
- Full pytest regression: **306 passed**.
- Focused V80/V79 immutable-reference and guided-resolution regression: **9 passed** on the final source state.
- U-HAUL migration/clone/conflict targeted suite: **16 passed** before final release metadata cleanup.
- Phase 6 package checker: **38/38 PASS**.
- Final application self-check: **43/43 required checks PASS**.
- Adaptive package validation: **60/60 PASS**.
- Python compile check: **PASS**.
- Frontend TypeScript/TSX syntax transpilation: **24/24 source files PASS, 0 diagnostics**.
- User-facing frontend brand search: no `React-native`, `React/Bun`, or `REACT` dashboard branding remains.

## Frontend production-bundle note
The source package intentionally does not include `node_modules`. Dependency installation from the execution sandbox timed out, so a fresh Vite production bundle could not be generated in that sandbox. The complete frontend source is included and all 24 TypeScript/TSX source files passed TypeScript transpilation. Install the package dependencies in the normal development environment, then run the included frontend build command/helper.

## Release behavior that must remain true
1. The original developer-approved U-HAUL reference is immutable.
2. Approval status and runtime readiness are separate concepts.
3. Editing starts by cloning (`Create from U-HAUL`).
4. `Fix now` is for editable customer configurations, not the original approved reference.
5. Unresolved customer decisions remain a backend hard gate for Flow/LIVE execution.
