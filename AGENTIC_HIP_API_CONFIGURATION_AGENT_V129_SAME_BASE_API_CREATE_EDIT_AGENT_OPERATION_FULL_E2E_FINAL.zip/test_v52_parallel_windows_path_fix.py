from __future__ import annotations

import json
from pathlib import Path

from webapp.backend.app.parallel_manager import ParallelManager, _snapshot_hashes
from webapp.backend.app.storage import JsonStore

ROOT = Path(__file__).resolve().parent


def _tiny_valid_workspace(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    nested = root / "input_files" / "CUSTOMER_4506868691_69D_ASN"
    nested.mkdir(parents=True, exist_ok=True)
    (nested / "VSHIP_20260410124029.xml").write_text("<DellAutoASN/>", encoding="utf-8")
    (root / "input.json").write_text(
        json.dumps({"customer": "U-HAUL", "profile_name": "U-HAUL_PC_856_ANS_MAPPING_OB", "direction": "Outbound", "tx_code": "856"}),
        encoding="utf-8",
    )
    return root


def test_v52_parallel_execution_uses_short_physical_workspace_for_deep_project_path(tmp_path: Path):
    # Simulate a deep Windows/OneDrive project location that would make the old
    # runtime/parallel_runs/<batch>/jobs/<job>/input_files path exceed ~260 chars.
    deep_root = tmp_path
    for index in range(8):
        deep_root = deep_root / (f"OneDrive_Dell_Technologies_Browser_Testing_{index}_" + "x" * 18)
    store = JsonStore(deep_root / "webapp" / "runtime")
    manager = ParallelManager(store)
    source = _tiny_valid_workspace(tmp_path / "source")
    queued = manager.queue_configuration(
        {"id": "reference:uhal", "workspace": str(source), "customer": "U-HAUL", "name": "U-HAUL"},
        {"ok": True, "requests": {"validCount": 18, "total": 18}},
    )
    assert queued["jobId"].startswith("q")
    assert len(queued["jobId"]) <= 12

    source_snapshot = Path(queued["workspace"])
    old_style = manager.run_root / ("batch_20260818_060249_" + "a" * 6) / "jobs" / queued["jobId"]
    short_style = manager._execution_workspace("batch_20260818_060249_32a95a", queued["jobId"])
    assert len(str(short_style)) < len(str(old_style))
    assert str(short_style).startswith(str(manager.exec_root))

    manager._copy_snapshot(source_snapshot, short_style)
    staged = short_style / "input_files" / "CUSTOMER_4506868691_69D_ASN" / "VSHIP_20260410124029.xml"
    assert staged.exists()
    assert _snapshot_hashes(source_snapshot) == _snapshot_hashes(short_style)


def test_v52_shipped_uhal_reference_customer_file_survives_parallel_staging(tmp_path: Path):
    # Regression for the exact U-HAUL customer evidence filename visible in the
    # reported failure. A queued U-HAUL snapshot must carry it into the short
    # execution workspace without depending on the original project path.
    source_file = ROOT / "input_files" / "UHAUL_4506868691_69D_ASN_VSHIP_20260410124029.xml"
    assert source_file.exists()

    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    queued = manager.queue_configuration(
        {"id": "reference:uhal", "workspace": str(ROOT), "customer": "U-HAUL", "name": "U-HAUL_PC_856_ANS_MAPPING_OB"},
        {"ok": True, "requests": {"validCount": 18, "total": 18}},
    )
    source_snapshot = Path(queued["workspace"])
    destination = manager._execution_workspace("batch_regression", queued["jobId"])
    manager._copy_snapshot(source_snapshot, destination)

    staged_file = destination / "input_files" / source_file.name
    assert staged_file.exists()
    assert staged_file.read_bytes() == source_file.read_bytes()
    assert _snapshot_hashes(source_snapshot) == _snapshot_hashes(destination)


def test_v52_parallel_manager_contains_staging_integrity_guard_and_persistent_job_report():
    source = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert "Parallel staging integrity check failed before LIVE execution" in source
    assert "HIP_PARALLEL_EXEC_ROOT" in source
    assert "persistentHtmlReport" in source
    assert "executionWorkspacePathLength" in source
