from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_v92_active_deployment_group_is_dce_shared_everywhere_that_builds_live_payloads():
    from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
    assert DEFAULT_DEPLOYMENT_GROUP == "hip-automation"

    active_files = [
        "hip_defaults.py",
        "input_builder_core.py",
        "input_builder_integration.py",
        "configuration_workspace.py",
        "adaptive_engine.py",
        "interface_registry.py",
        "uhal_mapper.py",
        "run_agent.py",
        "webapp/backend/app/main.py",
        "webapp/backend/app/phase5_service.py",
    ]
    for rel in active_files:
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "dce-shared" not in text.replace("dce-shared-sender", "").replace("dce-shared-receiver", ""), rel

    inp = json.loads((ROOT / "input.json").read_text(encoding="utf-8"))
    cfg = json.loads((ROOT / "config_overrides.json").read_text(encoding="utf-8"))
    assert inp["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert inp["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
    assert cfg["source_deployment_group_name"] == "hip-automation"
    assert cfg["target_deployment_group_name"] == "hip-automation"


def test_v92_dev_approved_uhal_reference_uses_dce_shared_without_changing_payload_shape():
    inp = json.loads((ROOT / "dev_approved/UHAL_input_dev_approved.json").read_text(encoding="utf-8"))
    cfg = json.loads((ROOT / "dev_approved/UHAL_config_dev_approved.json").read_text(encoding="utf-8"))
    assert inp["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert inp["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
    assert cfg["source_deployment_group_name"] == "hip-automation"
    assert cfg["target_deployment_group_name"] == "hip-automation"
    assert inp["objects"]["target_transport_profile"]["partner_name"] == "dce-test-partner"
    assert inp["partner_identifier_value"] == "12345666"


def test_v92_partner_identifier_ownership_is_not_misattributed_to_uhal():
    manifest = json.loads((ROOT / "LIVE_ONLY_RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    policy = manifest["partnerIdentifierPolicy"]
    assert "dce-test-partner" in policy
    assert "not U-HAUL's DUNS" in policy
    active = (ROOT / "application_studio.py").read_text(encoding="utf-8")
    assert "dce-test-partner DUNS value 12345666" in active
    assert "Dev-approved U-HAUL DUNS" not in active


def test_v92_phase2_validator_targets_current_execution_center_markers():
    checker = (ROOT / "CHECK_AGENTIC_HIP_PHASE2.py").read_text(encoding="utf-8")
    assert "RUN LIVE EXECUTION" in checker
    assert "AutoGen AgentChat 0.7.5" in checker
    assert "REPEAT CUSTOMER" in checker
    assert "RUN SELECTED LIVE IN PARALLEL" not in checker


def test_v92_pipeline_does_not_emit_duplicate_job_completed_event():
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    duplicate = (
        'self._publish(batch_id, {"type": "job.completed", **result}, loop)\n'
        '                        self._publish(batch_id, {"type": "job.completed", **result}, loop)'
    )
    assert duplicate not in manager


def test_v92_agentchat_075_and_four_agent_ceiling_remain_locked():
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    runtime = (ROOT / "webapp/backend/app/autogen_runtime.py").read_text(encoding="utf-8")
    assert "autogen-agentchat==0.7.5" in requirements
    assert "autogen-core==0.7.5" in requirements
    assert "autogen-ext[openai]==0.7.5" in requirements
    assert "AssistantAgent" in runtime
    assert "CancellationToken" in runtime
    assert "AUTOGEN_KNOWN_UNSTABLE_AT = 5" in manager
    assert 'min(4, max(1, int(os.getenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4") or "4")))' in manager
