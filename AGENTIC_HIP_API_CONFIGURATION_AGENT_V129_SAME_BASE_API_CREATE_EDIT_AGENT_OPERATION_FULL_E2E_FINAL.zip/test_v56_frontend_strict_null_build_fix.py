from pathlib import Path


def test_flow_game_node_action_access_is_null_safe():
    text = Path("webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    assert "nodeAction?.id===selectedNode?.id?(nodeAction?.action??''):''" in text
    assert "nodeAction?.id===selectedNode?.id?nodeAction.action:''" not in text
