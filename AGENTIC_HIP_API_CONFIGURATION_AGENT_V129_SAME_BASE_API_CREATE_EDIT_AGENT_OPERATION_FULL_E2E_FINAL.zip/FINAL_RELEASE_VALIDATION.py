#!/usr/bin/env python3
"""Quick, non-mutating packaged release validation for Agentic HIP V42.

This script intentionally avoids any Dell HIP mutation API. The Windows full
validator launcher runs this quick check plus the full pytest/validator suites
as separate processes so inherited helper handles cannot keep one parent Python
process open.
"""
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CHECKS=[]

def check(name, ok, detail=''):
    CHECKS.append({'name':name,'ok':bool(ok),'detail':detail})
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f": {detail}" if detail else ''))

def main():
    try:
        from fastapi.testclient import TestClient
        from webapp.backend.app.main import app
        with TestClient(app) as client:
            health=client.get('/api/health'); boot=client.get('/api/bootstrap'); status=client.get('/api/system/status')
        check('FastAPI health',health.status_code==200 and health.json().get('ok') is True)
        bd=boot.json() if boot.status_code==200 else {}
        check('Bootstrap Phase 6',boot.status_code==200 and bd.get('phase')==6)
        check('Exactly 18 reusable HIP API blocks',len(bd.get('api_catalog') or [])==18 and all(x.get('reusable') for x in bd.get('api_catalog') or []))
        check('hip-automation mandatory deployment default',bd.get('deployment_group')=='hip-automation')
        tx=bd.get('transactions') or {}
        check('Direction editable',tx.get('editable_direction') is True)
        check('Inbound 850 offered','850' in (((tx.get('directions') or {}).get('Inbound') or {}).get('suggested_transactions') or []))
        out=set((((tx.get('directions') or {}).get('Outbound') or {}).get('suggested_transactions') or []))
        check('Outbound 832/855/856 offered',{'832','855','856'}.issubset(out))
        sd=status.json() if status.status_code==200 else {}
        check('HIP API Agent Studio primary UI',status.status_code==200 and sd.get('ui')=='HIP API Agent Studio Web UI' and sd.get('streamlitRequired') is False)
    except Exception as exc:
        check('FastAPI smoke',False,f'{type(exc).__name__}: {exc}')

    req=(ROOT/'requirements.txt').read_text(encoding='utf-8').lower()
    check('Primary requirements are Streamlit-free','streamlit>=' not in req and 'streamlit-sortables' not in req)
    runbat=(ROOT/'RUN_AGENTIC_HIP.bat').read_text(encoding='utf-8').lower()
    check('Normal launcher starts HIP API Agent Studio/FastAPI','streamlit run' not in runbat and 'uvicorn webapp.backend.app.main:app' in runbat)
    css=(ROOT/'webapp/frontend/src/styles.css').read_text(encoding='utf-8')
    check('No forced 1180px overflow','min-width:1180px' not in css.replace(' ',''))
    flow=(ROOT/'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    check('Flow Game automatic preflight','Automatic preflight PASS' in flow and 'LIVE blocked by preflight' in flow)
    check('Flow Game collapsible panels','deckOpen' in flow and 'railOpen' in flow and 'fitView({padding:.2,duration:300})' in flow)
    parallel=(ROOT/'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    check('Parallel LIVE board','LIVE EXECUTION BOARD' in parallel and 'Select all ready' in parallel)
    check('Parallel reconnect recovery','api.parallelBatch(b.batchId)' in parallel)

    proc=subprocess.run([sys.executable,'-m','compileall','-q','-f','.'],cwd=ROOT)
    check('Python source compilation',proc.returncode==0)

    failed=[x for x in CHECKS if not x['ok']]
    result={'status':'PASS' if not failed else 'FAIL','passed':len(CHECKS)-len(failed),'failed':len(failed),'checks':CHECKS,
            'scope':'Quick local/package validation only; no authenticated Dell HIP mutation APIs were called.'}
    (ROOT/'FINAL_RELEASE_VALIDATION_RESULT.json').write_text(json.dumps(result,indent=2,default=str),encoding='utf-8')
    print(json.dumps({'status':result['status'],'passed':result['passed'],'failed':result['failed']},indent=2))
    raise SystemExit(0 if not failed else 1)
if __name__=='__main__': main()
