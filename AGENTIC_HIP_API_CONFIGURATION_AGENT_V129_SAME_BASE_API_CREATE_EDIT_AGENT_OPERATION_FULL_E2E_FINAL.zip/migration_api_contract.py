from __future__ import annotations

"""Dev-published HIP Migration API contracts supplied by the user on 2026-09-07.

The migration endpoints are additive to the existing 18 configuration APIs. They
are exposed as seven logical reusable blocks because Source/Target Document Type
and Source/Target Transport Profile are separate objects in the existing HIP
configuration model, while sharing the same published migration endpoints.

No screenshot example business value is treated as a customer default. The
current canonical configuration supplies object names/versions; source/target
migration environments are human-editable request values.
"""

from typing import Any, Dict, List

MIGRATION_STEP_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "migrate_doctype_source": {
        "label": "Migrate Source Document Type",
        "group": "Migration",
        "endpoint": "migration_document_type",
        "objectType": "Document Type",
        "role": "source",
        "dependencies": ["doctype_source"],
    },
    "migrate_doctype_target": {
        "label": "Migrate Target Document Type",
        "group": "Migration",
        "endpoint": "migration_document_type",
        "objectType": "Document Type",
        "role": "target",
        "dependencies": ["doctype_target"],
    },
    "migrate_map": {
        "label": "Migrate Data Map",
        "group": "Migration",
        "endpoint": "migration_data_map",
        "objectType": "Data Map",
        "dependencies": ["map"],
    },
    "migrate_rule": {
        "label": "Migrate Rule",
        "group": "Migration",
        "endpoint": "migration_rule",
        "objectType": "Rule",
        "dependencies": ["rule"],
    },
    "migrate_source_tp": {
        "label": "Migrate Source Transport Profile",
        "group": "Migration",
        "endpoint": "migration_transport_profile",
        "objectType": "Transport Profile",
        "role": "source",
        "dependencies": ["source_tp_audit"],
    },
    "migrate_target_tp": {
        "label": "Migrate Target Transport Profile",
        "group": "Migration",
        "endpoint": "migration_transport_profile",
        "objectType": "Transport Profile",
        "role": "target",
        "dependencies": ["target_tp_audit"],
    },
    "migrate_flow": {
        "label": "Migrate Flow",
        "group": "Migration",
        "endpoint": "migration_flow",
        "objectType": "Flow",
        "dependencies": ["flow_history"],
    },
}

MIGRATION_ORDER: List[str] = list(MIGRATION_STEP_DEFINITIONS)


def migration_catalog() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for index, (key, meta) in enumerate(MIGRATION_STEP_DEFINITIONS.items(), start=19):
        rows.append({
            "key": key,
            "label": meta["label"],
            "group": "Migration",
            "order": index,
            "migration": True,
            "object_type": meta.get("objectType"),
            "reusable": True,
        })
    return rows
