@echo off
rem Phase 6 compatibility alias. The primary HIP Studio is now React/FastAPI.
call "%~dp0RUN_AGENTIC_HIP.bat"
exit /b %errorlevel%
