from __future__ import annotations

import html
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from input_builder_integration import enrich_provable_values, unresolved_questions
from interface_registry import get_interface, registry
from production_guard import redact_sensitive


REPORT_HTML = "HIP_customer_intake_requirements_latest.html"
REPORT_JSON = "HIP_customer_intake_requirements_latest.json"


def _clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, (dict, list)):
        if not value:
            return ""
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value).strip()


def _tokens(path: str) -> List[Any]:
    out: List[Any] = []
    for part in str(path or "").split("."):
        while "[" in part and "]" in part:
            head, tail = part.split("[", 1)
            if head:
                out.append(head)
            idx, rest = tail.split("]", 1)
            try:
                out.append(int(idx))
            except Exception:
                out.append(idx)
            part = rest.lstrip(".")
        if part:
            out.append(part)
    return out


def _get(data: Any, path: str, default: Any = "") -> Any:
    cur = data
    for tok in _tokens(path):
        try:
            if isinstance(tok, int):
                cur = cur[tok]
            elif isinstance(cur, dict):
                cur = cur.get(tok)
            else:
                return default
        except Exception:
            return default
        if cur is None:
            return default
    return cur


def _resolve_interface_key(root: Path, canonical: Dict[str, Any], side: str, fallback: str) -> str:
    value = _clean(_get(canonical, f"objects.{side}_transport_profile.interface_type"))
    if value:
        lowered = value.lower().replace("_", "-").replace(" ", "")
        for key, definition in registry(root).items():
            aliases = {
                str(key).lower().replace("_", "-").replace(" ", ""),
                str(definition.get("displayName") or "").lower().replace("_", "-").replace(" ", ""),
                str(definition.get("apiInterfaceType") or "").lower().replace("_", "-").replace(" ", ""),
            }
            if lowered in aliases:
                return key
    return fallback or "SFTP"


def _field_specs(is_translation: bool, separate_target: bool) -> List[Dict[str, Any]]:
    specs: List[Dict[str, Any]] = [
        {"group":"Business basics","path":"customer","label":"Customer / partner name","meaning":"Who this integration is for. Used in names, audit history and the final report.","capability":"Usually extractable from an approved input/configuration manual, XML partner names, EDI sender/receiver IDs or filenames. If ambiguous, the user confirms it."},
        {"group":"Business basics","path":"direction","label":"Business direction","meaning":"Inbound means customer → Dell. Outbound means Dell → customer.","capability":"Often derived from sender/receiver evidence, document naming and the configuration manual; otherwise the user selects it."},
        {"group":"Business basics","path":"tx_standard","label":"Transaction standard","meaning":"The business-message standard such as X12, EDIFACT, XML/cXML or another approved format.","capability":"Extracted from EDI envelopes, XML/cXML content, document metadata or the approved manual."},
        {"group":"Business basics","path":"tx_code","label":"Transaction code","meaning":"The business transaction, for example 850 Purchase Order or 856 Ship Notice.","capability":"Extracted from X12 ST01, EDIFACT UNH, XML/document metadata or the configuration manual."},
        {"group":"Business basics","path":"tx_name","label":"Transaction name","meaning":"Human-readable transaction description used in the flow and reports.","capability":"Derived from the transaction catalogue when the code/standard is known, or read from the approved manual."},
        {"group":"Business basics","path":"profile_name","label":"Business Flow name","meaning":"The name of the end-to-end HIP flow that will be created/deployed.","capability":"Read from approved input/manual when present; otherwise derived from proven customer/direction/transaction naming or confirmed by the user."},
        {"group":"Business basics","path":"requires_data_map","label":"Translation required?","meaning":"Whether HIP must transform the source message into a different target structure.","capability":"Proven by XBM/JAR/map evidence or the approved configuration. Passthrough has no Data Map/Mapping Rule."},

        {"group":"Source document","path":"objects.source_document_type.name","label":"Source Document Type name","meaning":"HIP name for the incoming/source message definition.","capability":"Read from approved input/manual; can be generated from strong naming evidence when safe."},
        {"group":"Source document","path":"objects.source_document_type.data_format_type","label":"Source file format","meaning":"The physical source format: XML, cXML, EDIX12, EDIFACT, CSV, JSON, FlatFile, etc.","capability":"Extracted from the actual source file content/extension. The agent does not infer EDI solely from a transaction code."},
        {"group":"Source document","path":"objects.source_document_type.document_identifier.rows","label":"Source document identifier","meaning":"How HIP recognizes the source document, such as an XML root element or EDI transaction identifier.","capability":"Extracted from XML root/schema, X12 ST, EDIFACT UNH or configuration manual."},
        {"group":"Source document","path":"objects.source_document_type.attributes_to_configure","label":"Source routing/business attributes","meaning":"Sender, Receiver, Transaction Type and business identifiers that HIP extracts from each message.","capability":"Derived from XML paths/XPaths, EDI positions and approved document configuration."},

        {"group":"Source transport","path":"objects.source_transport_profile.interface_type","label":"Source connection type","meaning":"How the source side sends/receives data, such as SFTP, FTP, HTTPS or HTTPS-AS2.","capability":"Read from the manual/approved input, customer connection information or explicit user selection."},
        {"group":"Source transport","path":"objects.source_transport_profile.profile_name","label":"Source Transport Profile name","meaning":"HIP name for the source-side connection profile.","capability":"Read from approved files/manual or generated from the proven naming convention."},
        {"group":"Source transport","path":"objects.source_transport_profile.partner_name","label":"Source application/system","meaning":"The application or partner system attached to the source Transport Profile.","capability":"Reused from Biz Flow evidence or derived from direction rules when the Dell side is deterministic."},
        {"group":"Source transport","path":"objects.source_transport_profile.existing_account_name","label":"Source HIP account","meaning":"Existing HIP account identity used by the source transport/profile APIs.","capability":"For the current SFTP/FTP UAT path the approved shared account can be supplied by the agent. Other environments/interfaces require approved customer/environment information."},
        {"group":"Source transport","path":"objects.source_transport_profile.subscription_folder","label":"Source subscription/folder path","meaning":"Folder/subscription HIP watches on the source side.","capability":"For SFTP/FTP the source folder can be derived as /<source Transport Profile name>; approved manuals/files override this when present."},
        {"group":"Source transport","path":"objects.biz_flow.configure_source.source_transport_profile","label":"Source shared Flow Transport Profile","meaning":"Shared dce-common profile reference used by the Biz Flow.","capability":"Supplied from the selected interface catalogue when standard; custom/contract-driven interfaces may require an approved value."},

        {"group":"Target transport","path":"objects.target_transport_profile.interface_type","label":"Target connection type","meaning":"How HIP sends/receives data on the target side.","capability":"Read from the manual/approved input, customer connection information or explicit user selection."},
        {"group":"Target transport","path":"objects.target_transport_profile.profile_name","label":"Target Transport Profile name","meaning":"HIP name for the target-side connection profile.","capability":"Read from approved files/manual or generated from the proven naming convention."},
        {"group":"Target transport","path":"objects.target_transport_profile.partner_name","label":"Target application/system","meaning":"The partner or Dell application attached to the target Transport Profile.","capability":"Reused from Biz Flow evidence or derived from direction rules when the Dell side is deterministic."},
        {"group":"Target transport","path":"objects.target_transport_profile.existing_account_name","label":"Target HIP account","meaning":"Existing HIP account identity used by the target transport/profile APIs.","capability":"For the current SFTP/FTP UAT path the approved shared account can be supplied by the agent. Other environments/interfaces require approved customer/environment information."},
        {"group":"Target transport","path":"objects.target_transport_profile.subscription_folder","label":"Target subscription/folder path","meaning":"Destination/subscription folder on the target side, for example /Inbound/ASN or /Outbound/ASN.","capability":"Read from the configuration manual/customer connection files when present. Because customer folder conventions vary, the agent asks the user if evidence cannot prove it."},
        {"group":"Target transport","path":"objects.biz_flow.configure_targets.target_transport_profile","label":"Target shared Flow Transport Profile","meaning":"Shared dce-common profile reference used by the Biz Flow.","capability":"Supplied from the selected interface catalogue when standard; custom/contract-driven interfaces may require an approved value."},

        {"group":"Partner identity","path":"partner_identifier_value","label":"External HIP partner identifier / DUNS","meaning":"Approved identifier used by Partner Create for the HIP partner object. The identifier belongs to that partner object; it is not automatically the customer/integration name. For a DUNS contract this must be the actual approved DUNS value.","capability":"The agent never invents this. It can read it from an approved input/manual/customer master reference; otherwise the user must provide/confirm it. Routing text is not a substitute for DUNS."},
        {"group":"Flow & routing","path":"objects.biz_flow.flow_identifiers.conditions","label":"Flow matching conditions","meaning":"Rules that decide which messages belong to this flow, typically Sender/Receiver conditions.","capability":"Extracted from EDI/XML sender/receiver evidence, rules/configuration manual and approved routing configuration."},
        {"group":"Flow & routing","path":"objects.biz_flow.process_steps","label":"Flow process steps","meaning":"What HIP does after matching the message, such as Mapping Transformer or Enricher.","capability":"Read from the configuration manual/approved flow; mapping evidence can prove when a Mapping Transformer is needed."},
        {"group":"Flow & routing","path":"objects.biz_flow.configure_routing","label":"Final routing rule/action","meaning":"Where the processed document is routed and under what conditions.","capability":"Read from approved rules/flow/manual or derived from proven Sender/Receiver + target-profile evidence."},
        {"group":"HIP managed","path":"objects.source_transport_profile.deployment_group","label":"Deployment group","meaning":"HIP deployment group used by this automation.","capability":"System rule. The agent sets hip-automation; the user should not have to supply it."},
        {"group":"HIP managed","path":"__worktype__","label":"workType object","meaning":"Internal HIP work-order metadata.","capability":"Not a customer value. The agent omits it (or allows null where required); HIP/backend logic owns it."},
    ]
    if is_translation:
        specs.extend([
            {"group":"Target document","path":"objects.target_document_type.name","label":"Target Document Type name","meaning":"HIP definition for the transformed target message.","capability":"Read from mapping/manual/approved input; required for Translation."},
            {"group":"Target document","path":"objects.target_document_type.data_format_type","label":"Target file format","meaning":"Physical format created after transformation.","capability":"Extracted from target sample/schema/map metadata or approved manual."},
            {"group":"Target document","path":"objects.target_document_type.document_identifier.rows","label":"Target document identifier","meaning":"How HIP recognizes the transformed target document.","capability":"Extracted from target XML root/schema, EDI metadata, mapping/manual evidence."},
            {"group":"Target document","path":"objects.target_document_type.attributes_to_configure","label":"Target routing/business attributes","meaning":"Sender, Receiver and business identifiers on the target document.","capability":"Derived from target schema/sample/manual and approved mapping configuration."},
            {"group":"Translation","path":"objects.data_map.map_identifier","label":"Data Map identifier","meaning":"Stable HIP identifier for the transformation map.","capability":"Extracted from XBM/configuration manual/approved input. The agent will not invent it."},
            {"group":"Translation","path":"objects.data_map.map_name","label":"Data Map name","meaning":"Human-readable mapping name.","capability":"Extracted from XBM/map metadata/manual."},
            {"group":"Translation","path":"objects.data_map.map_class","label":"Mapping class","meaning":"Executable mapping class used by the transformation.","capability":"Extracted/cross-checked from XBM/JAR mapping artifacts."},
            {"group":"Translation","path":"objects.data_map.contivo_version","label":"Contivo/map-engine version","meaning":"Mapping-engine version associated with the map when the artifact declares it.","capability":"Extracted from XBM/map metadata when present."},
            {"group":"Translation","path":"objects.data_map.map_data_file","label":"Mapping JAR file","meaning":"Executable JAR containing the approved transformation.","capability":"Extracted from uploaded JAR/XBM evidence. The agent will never invent an executable mapping artifact."},
            {"group":"Translation","path":"objects.rule.name","label":"Mapping Rule name","meaning":"HIP rule that invokes the approved Data Map.","capability":"Extracted from configuration manual/approved input and map/rule evidence."},
            {"group":"Translation","path":"objects.rule.conditions.rows","label":"Mapping Rule conditions","meaning":"Conditions under which the mapping is applied.","capability":"Read from approved rule/manual; Sender/Receiver values can be cross-checked against payload evidence."},
        ])
    elif separate_target:
        specs.extend([
            {"group":"Target document","path":"objects.target_document_type.name","label":"Target Document Type name","meaning":"Separate target definition explicitly enabled for this Passthrough exception.","capability":"Must be proven by approved configuration/manual because normal Passthrough reuses the source Document Type."},
            {"group":"Target document","path":"objects.target_document_type.data_format_type","label":"Target file format","meaning":"Physical format for the explicit Passthrough target definition.","capability":"Read from the target sample/manual."},
            {"group":"Target document","path":"objects.target_document_type.document_identifier.rows","label":"Target document identifier","meaning":"Recognition rule for the explicit Passthrough target definition.","capability":"Read from target sample/manual."},
        ])
    return specs


def _file_mapping_index(canonical: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    fm = canonical.get("_file_mapping") if isinstance(canonical, dict) else {}
    rows = fm.get("fieldMappings") if isinstance(fm, dict) else []
    out: Dict[str, Dict[str, Any]] = {}
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        path = str(row.get("path") or row.get("field") or "").strip()
        if path:
            out[path] = row
    return out


def _auto_index(canonical: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    audit = canonical.get("_builder_audit") if isinstance(canonical, dict) else {}
    rows = audit.get("auto_resolved") if isinstance(audit, dict) else []
    out: Dict[str, Dict[str, Any]] = {}
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and row.get("path"):
            out[str(row["path"])] = row
    return out


def _blueprint_index(canonical: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    value = canonical.get("_input_extraction_blueprint") if isinstance(canonical, dict) else {}
    rows = value.get("fields") if isinstance(value, dict) else []
    out: Dict[str, Dict[str, Any]] = {}
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and row.get("path"):
            out[str(row["path"])] = row
    return out


def _question_index(questions: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for q in questions or []:
        if not isinstance(q, dict) or q.get("informational"):
            continue
        path = str(q.get("path") or "").strip()
        if path:
            out[path] = q
        for p in q.get("multi_paths") or []:
            out[str(p)] = q
    return out


def _display_value(value: Any, *, sensitive: bool = False, limit: int = 220) -> str:
    if sensitive:
        return "Provided securely at runtime — not stored in the report"
    if value in (None, "", [], {}):
        return "—"
    safe = redact_sensitive(deepcopy(value))
    if isinstance(safe, (dict, list)):
        text = json.dumps(safe, ensure_ascii=False, default=str)
    else:
        text = str(safe)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _runtime_specs(root: Path, canonical: Dict[str, Any], source_key: str, target_key: str, uhal: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for side, key in (("source", source_key), ("target", target_key)):
        try:
            definition = get_interface(root, key)
        except Exception:
            continue
        params = _get(canonical, f"objects.{side}_transport_profile.interface_parameters", {})
        uparams = _get(uhal, f"objects.{side}_transport_profile.interface_parameters", {})
        required = definition.get(f"{side}Required") or []
        sensitive = set(definition.get(f"{side}SensitiveFields") or [])
        pending = set(definition.get("pendingFields") or [])
        for field in required:
            if field in {"__PARAMETERS__", "__SHARED_PROFILE__"}:
                continue
            rows.append({
                "group": f"{side.title()} interface",
                "path": f"objects.{side}_transport_profile.interface_parameters.{field}",
                "label": f"{side.title()} {field}",
                "meaning": f"Required by the selected {definition.get('displayName') or key} interface contract.",
                "capability": "Read from approved connection/configuration documentation when present. Secrets are accepted only as runtime values and are not copied into reusable templates/reports.",
                "sensitive": field in sensitive,
                "pending": field in pending,
                "current_override": params.get(field) if isinstance(params, dict) else "",
                "uhal_override": uparams.get(field) if isinstance(uparams, dict) else "",
            })
        # HTTPS-AS2 certificate requirement from the 2026-09-02 Dev contract.
        # The approved payload uses certificate value attributes, not certificate IDs.
        api_type = str(definition.get("apiInterfaceType") or "").upper()
        direction = str(canonical.get("direction") or "Outbound").lower()
        partner_side = "source" if direction == "inbound" else "target"
        if side == partner_side and api_type == "HTTPS-AS2":
            cert_fields = ["Partner Verification Certificate"] if side == "source" else ["Encryption Certificate", "SSL Certificate"]
            for cert_field in cert_fields:
                cert_path = f"objects.{side}_transport_profile.interface_parameters.{cert_field}"
                if not any(row.get("path") == cert_path for row in rows):
                    rows.append({
                        "group": f"{side.title()} interface",
                        "path": cert_path,
                        "label": f"{side.title()} {cert_field}",
                        "meaning": "Certificate value required by the Dev-approved HTTPS-AS2 interfaceDetails contract.",
                        "capability": "Cannot be invented. The user/Dev team supplies the approved certificate value unless trusted configuration evidence already contains it.",
                    })
    return rows


def build_customer_intake_model(workspace: Path, record: Dict[str, Any], root: Path) -> Dict[str, Any]:
    workspace = Path(workspace).resolve()
    root = Path(root).resolve()
    canonical_path = workspace / "input.json"
    canonical = json.loads(canonical_path.read_text(encoding="utf-8")) if canonical_path.exists() else {}
    uhal_path = root / "input.json"
    uhal = json.loads(uhal_path.read_text(encoding="utf-8")) if uhal_path.exists() else {}

    source_key = _resolve_interface_key(root, canonical, "source", str(record.get("source_interface") or "SFTP"))
    target_key = _resolve_interface_key(root, canonical, "target", str(record.get("target_interface") or source_key))
    canonical = enrich_provable_values(root, canonical, source_key, target_key) if canonical else canonical
    questions = unresolved_questions(root, canonical, source_key, target_key) if canonical else list(record.get("questions") or [])
    required_questions = [q for q in questions if isinstance(q, dict) and not q.get("informational")]

    is_translation = bool(canonical.get("requires_data_map")) or str(canonical.get("flow_type") or record.get("flow_type") or "").lower() == "translation"
    separate_target = bool(canonical.get("passthrough_target_document_type_required")) and not is_translation
    specs = _field_specs(is_translation, separate_target) + _runtime_specs(root, canonical, source_key, target_key, uhal)
    fm = _file_mapping_index(canonical)
    auto = _auto_index(canonical)
    qidx = _question_index(required_questions)
    bpidx = _blueprint_index(canonical)

    rows: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for spec in specs:
        path = str(spec.get("path") or "")
        if path in seen:
            continue
        seen.add(path)
        special_worktype = path == "__worktype__"
        current = spec.get("current_override", _get(canonical, path)) if not special_worktype else ""
        uhal_value = spec.get("uhal_override", _get(uhal, path)) if not special_worktype else "Omitted / HIP-managed"
        sensitive = bool(spec.get("sensitive"))
        q = qidx.get(path)
        mapping = fm.get(path)
        derived = auto.get(path)
        blueprint_row = bpidx.get(path) or {}
        if special_worktype:
            status, source, action = "HIP_MANAGED", "HIP/backend derives it", "No user action"
        elif q is not None:
            status, source, action = ("RUNTIME_REQUIRED" if q.get("secret") or sensitive else "USER_REQUIRED"), "Not proven by current evidence", str(q.get("question") or f"Provide {spec['label']}")
        elif mapping is not None:
            status = "EXTRACTED"
            source = str(mapping.get("sourceFile") or mapping.get("file") or mapping.get("source") or "Customer file evidence")
            action = "No user action unless the extracted value is wrong"
        elif derived is not None:
            status = "DERIVED"
            source = f"Agent rule: {derived.get('source') or 'deterministic derivation'}"
            action = "No user action; review if desired"
        elif blueprint_row.get("status") == "EXTRACTED":
            status = "EXTRACTED"
            source = str(blueprint_row.get("source") or "Customer file evidence")
            action = "No user action unless the extracted value is wrong"
        elif blueprint_row.get("status") == "DERIVED":
            status = "DERIVED"
            source = f"Engineer blueprint: {blueprint_row.get('source') or 'deterministic derivation'}"
            action = "No user action; review if desired"
        elif blueprint_row.get("status") == "USER_REQUIRED":
            status = "USER_REQUIRED"
            source = "Engineer extraction blueprint: current evidence cannot prove this value"
            action = f"Provide {spec['label']}"
        elif _clean(current):
            # If there is no fine-grained provenance, this is still a usable
            # approved/configured value rather than something the report should
            # mislabel as user-missing.
            auth = ((canonical.get("_builder_audit") or {}).get("authoritative_json") or {}) if isinstance(canonical, dict) else {}
            if auth:
                status, source = "APPROVED_INPUT", str(auth.get("filename") or "Approved input.json")
            else:
                status, source = "AVAILABLE", "Current canonical input/configuration"
            action = "No user action"
        else:
            status, source, action = "NOT_APPLICABLE", "Not used by this configuration", "No user action"
        reference_owner = "U-HAUL reference flow"
        reference_display = _display_value(uhal_value, sensitive=sensitive)
        if path == "partner_identifier_value":
            # The packaged U-HAUL flow points to a separate HIP partner object.
            # Its DUNS belongs to that partner object, not to U-HAUL itself.
            reference_partner = _clean(_get(uhal, "objects.target_transport_profile.partner_name")) or "dce-test-partner"
            reference_owner = reference_partner
            if _clean(uhal_value):
                reference_display = f"{reference_partner} — DUNS {_clean(uhal_value)}"
        rows.append({
            **spec,
            "status": status,
            "source": source,
            "action": action,
            "currentValue": _display_value(current, sensitive=sensitive),
            "uhalValue": reference_display,
            "referenceOwner": reference_owner,
            "confidence": str((mapping or {}).get("confidence") or ("high" if status in {"DERIVED","HIP_MANAGED","APPROVED_INPUT"} else "")),
        })

    # Dynamic questions not covered by the core catalogue must still appear so
    # the report is complete for custom interfaces / newly learned fields.
    for q in required_questions:
        path = str(q.get("path") or "")
        if path and path in seen:
            continue
        label = str(q.get("label") or path or q.get("id") or "Required value")
        rows.append({
            "group":"Additional customer input",
            "path":path or str(q.get("id") or ""),
            "label":label,
            "meaning":str(q.get("why") or "Required by the selected HIP configuration/API contract."),
            "capability":"The agent could not prove this value from the supplied evidence and will not guess it.",
            "status":"RUNTIME_REQUIRED" if q.get("secret") else "USER_REQUIRED",
            "source":"Not proven by current evidence",
            "action":str(q.get("question") or f"Provide {label}"),
            "currentValue":_display_value(q.get("current"), sensitive=bool(q.get("secret"))),
            "uhalValue":"—",
            "referenceOwner":"Not applicable",
            "confidence":"",
            "sensitive":bool(q.get("secret")),
        })

    counts: Dict[str, int] = {}
    for row in rows:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    user_rows = [r for r in rows if r["status"] in {"USER_REQUIRED", "RUNTIME_REQUIRED"}]
    extracted_rows = [r for r in rows if r["status"] == "EXTRACTED"]
    automatic_rows = [r for r in rows if r["status"] in {"DERIVED", "HIP_MANAGED"}]
    available_rows = [r for r in rows if r["status"] in {"AVAILABLE", "APPROVED_INPUT"}]

    manifest = []
    input_files = workspace / "input_files"
    if input_files.exists():
        manifest = sorted(str(p.relative_to(input_files)).replace("\\", "/") for p in input_files.rglob("*") if p.is_file())

    capabilities = [
        {"file":"Approved input.json / HIP JSON","extracts":"All declared business/configuration values; treated as authoritative. Supporting files validate it and only fill blanks."},
        {"file":"Configuration Manual (.xlsx)","extracts":"Document Types, Data Maps, Mapping Rules, Transport Profiles, Business Flow, connection/profile names, folders and routing values present in the manual."},
        {"file":"XML / cXML","extracts":"Root/document identifier, XML format, sender/receiver/partner names or IDs, transaction/business identifiers, routing clues and schema/root evidence."},
        {"file":"X12 EDI","extracts":"ISA06 sender, ISA08 receiver, ST01 transaction code, BAK/REF business identifiers and envelope/routing evidence."},
        {"file":"EDIFACT","extracts":"UNB sender/receiver, UNH transaction type, BGM/RFF business identifiers and routing evidence."},
        {"file":"XBM map file","extracts":"Map identifier/name/class, map metadata, source/target schema/root evidence and Contivo version when declared."},
        {"file":"JAR mapping artifact","extracts":"Approved mapping JAR filename and executable/class consistency evidence; the agent never invents a JAR."},
        {"file":"JSON / structured customer config","extracts":"Recognized customer, direction, transaction, interface, document, routing and mapping fields when the schema/evidence is clear."},
    ]

    runtime_prerequisites = [
        {"label":"HIP/API OAuth credentials","who":"Environment / operator","why":"Needed to call LIVE HIP APIs. Kept in environment/runtime settings, not customer files or reusable templates.","example":"HIP_CLIENT_ID, HIP_CLIENT_SECRET, HIP_TOKEN_URL (and service-specific profiles when configured)."},
        {"label":"Partner connection secrets","who":"Customer / Dev team when interface requires them","why":"HTTPS/AS2 OAuth secrets or similar sensitive connection values cannot be inferred from payload samples.","example":"Receiver Client Secret is stored only in runtime secure values, never printed in this report."},
        {"label":"Partner certificate reference","who":"Dev team / customer connection owner","why":"For HTTPS-AS2, the certificate must already exist in HIP and the approved certificate ID/reference is required. Plain HTTPS Receiver SSL certificate fields are ignored in the V117 Dev-validation candidate.","example":"Not applicable to the packaged U-HAUL SFTP example."},
    ]

    return redact_sensitive({
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "customer": canonical.get("customer") or record.get("customer") or record.get("name") or "Current customer",
        "direction": canonical.get("direction") or record.get("direction") or "",
        "transactionCode": canonical.get("tx_code") or record.get("transaction_code") or "",
        "transactionName": canonical.get("tx_name") or record.get("transaction_name") or "",
        "flowType": "Translation" if is_translation else "Passthrough",
        "sourceInterface": source_key,
        "targetInterface": target_key,
        "manifest": manifest,
        "counts": counts,
        "rows": rows,
        "userRequired": user_rows,
        "extracted": extracted_rows,
        "automatic": automatic_rows,
        "available": available_rows,
        "capabilities": capabilities,
        "runtimePrerequisites": runtime_prerequisites,
        "extractionBlueprint": canonical.get("_input_extraction_blueprint") if isinstance(canonical.get("_input_extraction_blueprint"), dict) else {},
        "readyForApiMapping": len(required_questions) == 0,
        "requiredQuestionCount": len(required_questions),
        "uhalReference": {
            "integrationCustomer":"U-HAUL",
            "transaction":"856 Ship Notice",
            "direction":"Outbound",
            "flowType":"Translation",
            "partnerReference": {
                "name": _clean(_get(uhal, "objects.target_transport_profile.partner_name")) or "dce-test-partner",
                "identifierType": "DUNS Number",
                "identifierValue": _clean(uhal.get("partner_identifier_value")),
                "note": "This DUNS belongs to the HIP partner object, not to U-HAUL.",
            },
        },
    })


def _status_label(status: str) -> str:
    return {
        "EXTRACTED":"EXTRACTED FROM FILE",
        "DERIVED":"AGENT DERIVED",
        "HIP_MANAGED":"HIP / SYSTEM",
        "APPROVED_INPUT":"APPROVED INPUT",
        "AVAILABLE":"AVAILABLE",
        "USER_REQUIRED":"USER MUST GIVE",
        "RUNTIME_REQUIRED":"SECURE RUNTIME INPUT",
        "NOT_APPLICABLE":"NOT APPLICABLE",
    }.get(status, status.replace("_", " "))


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _render_rows(rows: List[Dict[str, Any]]) -> str:
    chunks: List[str] = []
    for row in rows:
        st = str(row.get("status") or "")
        chunks.append(
            f'<tr class="status-{_esc(st.lower())}">'
            f'<td><span class="badge { _esc(st.lower()) }">{_esc(_status_label(st))}</span></td>'
            f'<td><strong>{_esc(row.get("label"))}</strong><small>{_esc(row.get("meaning"))}</small><code>{_esc(row.get("path"))}</code></td>'
            f'<td>{_esc(row.get("currentValue"))}</td>'
            f'<td>{_esc(row.get("uhalValue"))}<small>Owner/context: {_esc(row.get("referenceOwner") or "U-HAUL reference flow")}</small></td>'
            f'<td><strong>{_esc(row.get("source"))}</strong><small>{_esc(row.get("capability"))}</small></td>'
            f'<td>{_esc(row.get("action"))}</td>'
            '</tr>'
        )
    return "".join(chunks)


def render_customer_intake_html(model: Dict[str, Any]) -> str:
    rows = list(model.get("rows") or [])
    required = list(model.get("userRequired") or [])
    extracted = list(model.get("extracted") or [])
    automatic = list(model.get("automatic") or [])
    caps = list(model.get("capabilities") or [])
    runtime = list(model.get("runtimePrerequisites") or [])
    manifest = list(model.get("manifest") or [])
    ready = bool(model.get("readyForApiMapping"))
    bp = model.get("extractionBlueprint") if isinstance(model.get("extractionBlueprint"), dict) else {}
    bp_summary = bp.get("summary") if isinstance(bp.get("summary"), dict) else {}
    glass = """<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>HIP Customer Intake Requirements</title><style>
:root{--ink:#14213d;--muted:#64748b;--line:rgba(20,33,61,.12);--glass:rgba(255,255,255,.78);--blue:#2563eb;--green:#059669;--amber:#d97706;--red:#dc2626;--violet:#7c3aed;--slate:#475569}
*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--ink);background:radial-gradient(circle at 12% 10%,rgba(37,99,235,.14),transparent 34%),radial-gradient(circle at 90% 18%,rgba(124,58,237,.12),transparent 30%),linear-gradient(135deg,#eef4ff,#f8fbff 45%,#eef2ff);line-height:1.45}.wrap{max-width:1500px;margin:auto;padding:34px 28px 60px}.glass{background:var(--glass);border:1px solid rgba(255,255,255,.8);box-shadow:0 18px 55px rgba(15,23,42,.10);backdrop-filter:blur(18px) saturate(135%);-webkit-backdrop-filter:blur(18px) saturate(135%);border-radius:22px}.hero{padding:30px}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.12em;color:var(--blue);text-transform:uppercase}.hero h1{margin:8px 0 7px;font-size:34px;line-height:1.1}.hero p{margin:0;color:var(--muted);max-width:1050px}.context{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.pill{padding:7px 11px;border:1px solid var(--line);background:rgba(255,255,255,.65);border-radius:999px;font-size:12px;font-weight:700}.summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:16px 0}.metric{padding:18px}.metric b{display:block;font-size:27px}.metric span{display:block;color:var(--muted);font-size:12px;margin-top:4px}.metric.need b{color:var(--red)}.metric.extract b{color:var(--green)}.metric.auto b{color:var(--violet)}.metric.ready b{color:var(--green)}.section{margin-top:16px;padding:24px}.section h2{margin:0 0 4px}.section>p{margin:0 0 18px;color:var(--muted)}.callout{padding:16px 18px;border-radius:16px;background:rgba(255,255,255,.58);border:1px solid var(--line);margin:12px 0}.callout strong{display:block}.callout small{color:var(--muted)}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.cap{padding:14px;border-radius:16px;border:1px solid var(--line);background:rgba(255,255,255,.54)}.cap b{display:block;margin-bottom:4px}.cap span{color:var(--muted);font-size:13px}.table-wrap{overflow:auto;border-radius:16px;border:1px solid var(--line);background:rgba(255,255,255,.46)}table{width:100%;border-collapse:separate;border-spacing:0;min-width:1180px}th{position:sticky;top:0;background:rgba(241,245,249,.96);text-align:left;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#475569;padding:12px;border-bottom:1px solid var(--line)}td{vertical-align:top;padding:13px 12px;border-bottom:1px solid var(--line);font-size:13px}td strong{display:block}td small{display:block;color:var(--muted);margin-top:5px;max-width:420px}td code{display:inline-block;margin-top:6px;font-size:10px;color:#64748b;background:rgba(226,232,240,.65);padding:2px 5px;border-radius:5px}.badge{display:inline-flex;font-size:10px;font-weight:850;white-space:nowrap;border-radius:999px;padding:5px 8px}.extracted{background:#d1fae5;color:#047857}.derived{background:#ede9fe;color:#6d28d9}.hip_managed{background:#dbeafe;color:#1d4ed8}.approved_input,.available{background:#e0f2fe;color:#0369a1}.user_required{background:#fee2e2;color:#b91c1c}.runtime_required{background:#ffedd5;color:#c2410c}.not_applicable{background:#e2e8f0;color:#475569}.files{display:flex;gap:7px;flex-wrap:wrap}.file{font-family:ui-monospace,Consolas,monospace;font-size:11px;background:rgba(255,255,255,.65);border:1px solid var(--line);padding:6px 8px;border-radius:9px}.footer{margin-top:18px;padding:16px 20px;color:var(--muted);font-size:12px}@media(max-width:900px){.summary{grid-template-columns:repeat(2,1fr)}.grid2{grid-template-columns:1fr}.wrap{padding:18px 12px}.hero h1{font-size:27px}}
</style></head><body><div class='wrap'>"""
    summary_counts = model.get("counts") or {}
    auto_count = len(automatic)
    extracted_count = len(extracted)
    need_count = len(required)
    available_count = len(model.get("available") or [])
    parts = [glass,
        f"<section class='glass hero'><div class='eyebrow'>Agent customer-intake report · plain-language requirements</div><h1>{_esc(model.get('customer'))}</h1><p>This report explains what HIP needs, what the agent can read from customer files, what it can safely derive, what the packaged reference flow used as an example, and exactly what still needs human input. Reference-flow values are examples only — they are never copied to another customer unless a documented shared Dev rule explicitly applies. When an identifier belongs to a separate HIP partner object, the report names that owner explicitly.</p><div class='context'><span class='pill'>{_esc(model.get('direction'))}</span><span class='pill'>{_esc(model.get('transactionCode'))} {_esc(model.get('transactionName'))}</span><span class='pill'>{_esc(model.get('flowType'))}</span><span class='pill'>Source: {_esc(model.get('sourceInterface'))}</span><span class='pill'>Target: {_esc(model.get('targetInterface'))}</span></div></section>",
        "<div class='summary'>",
        f"<div class='glass metric {'ready' if ready else 'need'}'><b>{'READY' if ready else 'NEEDS INPUT'}</b><span>Agent intake status</span></div>",
        f"<div class='glass metric extract'><b>{extracted_count}</b><span>Values proven from customer files</span></div>",
        f"<div class='glass metric auto'><b>{auto_count}</b><span>Values derived / HIP-managed</span></div>",
        f"<div class='glass metric'><b>{available_count}</b><span>Already available/approved</span></div>",
        f"<div class='glass metric need'><b>{need_count}</b><span>User/runtime values still required</span></div></div>",
        (f"<section class='glass section'><h2>Engineer input-extraction blueprint</h2><p>The engineer-provided JSON has been converted into {int(bp.get('ruleCount') or 0)} field-source rules. It is used as an extraction contract, not as customer data: examples are never copied into another customer.</p><div class='grid2'><div class='cap'><b>{int(bp_summary.get('extracted') or 0)} extracted</b><span>Values linked directly to customer-file evidence.</span></div><div class='cap'><b>{int(bp_summary.get('derived') or 0)} safely derived</b><span>Naming/alias values derived only from already-proven data.</span></div><div class='cap'><b>{int(bp_summary.get('selected_or_configured') or 0)} selected/configured</b><span>Approved input, dropdown or environment configuration.</span></div><div class='cap'><b>{int(bp_summary.get('user_required') or 0)} still unproven</b><span>Values the agent refuses to guess.</span></div></div></section>" if bp else ""),
        "<section class='glass section'><h2>What the agent can extract from customer files</h2><p>The exact result depends on what the customer supplied. The agent combines these sources and keeps evidence/provenance so it does not ask for information it already has.</p><div class='grid2'>",
        *[f"<div class='cap'><b>{_esc(c.get('file'))}</b><span>{_esc(c.get('extracts'))}</span></div>" for c in caps],
        "</div></section>",
        "<section class='glass section'><h2>What the user ultimately has to provide</h2><p>Only values that the files, approved configuration, deterministic rules and HIP interface catalogue cannot prove. Secrets are runtime-only and are never printed back.</p>",
    ]
    if required:
        for row in required:
            parts.append(f"<div class='callout'><strong>{_esc(row.get('label'))} · {_esc(_status_label(row.get('status')))}</strong><small>{_esc(row.get('meaning'))}</small><div style='margin-top:7px'><b>Agent asks:</b> {_esc(row.get('action'))}</div><div><b>Reference example:</b> {_esc(row.get('uhalValue'))}</div></div>")
    else:
        parts.append("<div class='callout'><strong>No unresolved customer values remain for this built configuration.</strong><small>The configuration can move to the 18-API non-mutating validation. Environment credentials are still checked separately before LIVE execution.</small></div>")
    parts.extend([
        "</section>",
        "<section class='glass section'><h2>Runtime / environment prerequisites</h2><p>These are not business values extracted from customer payloads. They are supplied securely by the operator/Dev environment when required.</p><div class='grid2'>",
        *[f"<div class='cap'><b>{_esc(r.get('label'))}</b><span>{_esc(r.get('why'))}<br><strong style='display:inline'>Who supplies:</strong> {_esc(r.get('who'))}<br><strong style='display:inline'>Example:</strong> {_esc(r.get('example'))}</span></div>" for r in runtime],
        "</div></section>",
        "<section class='glass section'><h2>Complete value matrix</h2><p>Current customer value vs the packaged reference flow. Partner-owned identifiers are explicitly attributed to their owner. Read the Status and User action columns first; technical paths are shown only for traceability.</p><div class='table-wrap'><table><thead><tr><th>Status</th><th>Value in plain language</th><th>Current customer</th><th>Reference example</th><th>How the agent gets it</th><th>User action</th></tr></thead><tbody>",
        _render_rows(rows),
        "</tbody></table></div></section>",
        "<section class='glass section'><h2>Files considered for this customer</h2><p>Files staged into the configuration workspace after ingestion.</p><div class='files'>",
        *(f"<span class='file'>{_esc(x)}</span>" for x in manifest),
        "</div></section>",
        f"<div class='glass footer'>Generated {_esc(model.get('generatedAt'))}. This is an intake/requirements explanation, not approval to execute LIVE. LIVE execution still requires the final contract validation, production preflight and credential checks.</div></div></body></html>"
    ])
    return "".join(parts)


def write_customer_intake_report(workspace: Path, record: Dict[str, Any], root: Path) -> Dict[str, Any]:
    workspace = Path(workspace).resolve()
    reports = workspace / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    model = build_customer_intake_model(workspace, record, root)
    safe_model = redact_sensitive(model)
    (reports / REPORT_JSON).write_text(json.dumps(safe_model, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    (reports / REPORT_HTML).write_text(render_customer_intake_html(safe_model), encoding="utf-8")
    return safe_model
