# Engineer Input Blueprint — End-to-End Implementation (V75)

## What is implemented

The engineer-provided field/source JSON is now an executable input-creation contract, not only documentation.

1. Build Configuration receives approved JSON/manual/customer artifacts and the UI selections.
2. Existing deterministic parsers extract XML/X12/EDIFACT/XBM/JAR evidence.
3. `input_extraction_blueprint.py` executes the 66 field-source rules.
4. Existing approved/canonical values always win.
5. Exact deterministic file mappings can fill only blank safe canonical fields.
6. Conflicting evidence is not guessed; the field is marked `USER_REQUIRED`.
7. Safe derived aliases/names are computed only from already-proven values.
8. Targeted scalar questions are generated only for unresolved business/environment values.
9. Human answers are persisted cumulatively and the blueprint is re-executed.
10. Inline contract repairs also re-execute the blueprint and refresh provenance.
11. The generated canonical `input.json` enters the fixed 18-API payload pipeline.
12. `reports/input_extraction_blueprint_execution_latest.json` records non-secret provenance for all 66 fields.

## Safety / precedence

`approved input.json > deterministic customer evidence > safe deterministic derivation > controlled user/config selection > targeted user question`.

U-HAUL/Legrand/example values are never copied into another customer. Complex Document Type/routing JSON is still built by the dedicated parsers rather than by generic scalar blueprint mapping. Secrets stay runtime-only.

## Main implementation files

- `schemas/engineer_input_extraction_blueprint.json`
- `input_extraction_blueprint.py`
- `input_builder_core.py`
- `input_builder_integration.py`
- `webapp/backend/app/legacy_adapter.py`
- `webapp/backend/app/main.py`
- `webapp/backend/app/phase2_service.py`
- `customer_intake_report.py`
- `webapp/frontend/src/pages/BuilderPage.tsx`
- `webapp/frontend/src/lib/api.ts`
- `test_v75_engineer_blueprint_e2e.py`

## UI additions

Build Configuration shows blueprint coverage and unresolved fields with the source order checked. It can download both the layman HTML required-values report and the detailed extraction trace JSON.
