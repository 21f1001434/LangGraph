from __future__ import annotations

import json
from pathlib import Path

import run_agent
from canonical_payload_contract import interface_shape_summary, lock_request_value
from interface_registry import BUILTIN_INTERFACES
from transport_interface_react import HTTPS_AS2_TARGET_KEYS, HTTPS_AS2_TARGET_REQUIRED, build_interface_parameters

ROOT = Path(__file__).resolve().parent


def _target_params(ssl_value: str = "dellroot_ca_6_able.crt"):
    return {
        "Interface Environment": "UAT",
        "Request Method": "POST",
        "Partner URL": "https://partner.example/as2",
        "Partner Identifier": "PARTNER",
        "Dell Identifier": "DELL_PARTNER",
        "Signing Algorithm": "SHA256",
        "Encryption Algorithm": "AES128",
        "Encryption Certificate": "encrypt.crt",
        "SSL Certificate": ssl_value,
        "Enable AS2 Message Compression": "False",
        "Asynchronous MDN Required": "False",
        "Are Input Files Compressed?": "False",
        "Is EBCDIC enabled?": "False",
        "Compression Format": "ZIP",
    }


def test_v121_schema_adds_required_receiver_ssl_certificate():
    keys = interface_shape_summary()["families"]["HTTPS_AS2"]["targetKeys"]
    assert "SSL Certificate" in keys
    assert keys.index("SSL Certificate") == keys.index("Encryption Certificate") + 1
    assert "SSL Certificate" in HTTPS_AS2_TARGET_KEYS
    assert "SSL Certificate" in HTTPS_AS2_TARGET_REQUIRED
    assert "SSL Certificate" in BUILTIN_INTERFACES["HTTPS-AS2"]["targetRequired"]


def test_v121_receiver_materializer_emits_ssl_certificate():
    payload = run_agent.Runner(llm_enabled=False).tp_parameters({
        "profile_usage": "Receiver",
        "interface_type": "HTTPS-AS2",
        "interface_parameters": _target_params(),
    }, "target")
    assert payload["SSL Certificate"] == "dellroot_ca_6_able.crt"


def test_v121_canonical_live_lock_never_omits_receiver_ssl_certificate():
    body = {
        "interfaceType": "HTTPS-AS2",
        "propertyMap": _target_params(),
        "transportProfileName": "AS2_TARGET",
        "hipEnvironment": "DEV",
    }
    locked, meta = lock_request_value("validate_target", "payload", body, interface_family="HTTPS_AS2")
    assert locked["propertyMap"]["SSL Certificate"] == "dellroot_ca_6_able.crt"
    assert "Compression Format" not in locked["propertyMap"]
    assert "parameters.SSL Certificate" not in meta.get("conditionallyOmittedPaths", [])


def test_v121_human_supplied_ssl_certificate_value_is_preserved():
    params = build_interface_parameters("target", "HTTPS-AS2", _target_params("custom-approved.crt"))
    assert params["SSL Certificate"] == "custom-approved.crt"


def test_v121_dev_approved_payload_contains_confirmed_value():
    payload = json.loads((ROOT / "V121_AS2_TARGET_TP_VALIDATE_DEV_APPROVED.json").read_text(encoding="utf-8"))
    assert payload["propertyMap"]["SSL Certificate"] == "dellroot_ca_6_able.crt"


def test_v121_dev_confirmed_ssl_certificate_is_default_but_human_override_wins():
    defaulted = run_agent.Runner(llm_enabled=False).tp_parameters({
        "profile_usage": "Receiver", "interface_type": "HTTPS-AS2", "interface_parameters": {}
    }, "target")
    assert defaulted["SSL Certificate"] == "dellroot_ca_6_able.crt"
    overridden = build_interface_parameters("target", "HTTPS-AS2", {"SSL Certificate": "human-approved.crt"})
    assert overridden["SSL Certificate"] == "human-approved.crt"
