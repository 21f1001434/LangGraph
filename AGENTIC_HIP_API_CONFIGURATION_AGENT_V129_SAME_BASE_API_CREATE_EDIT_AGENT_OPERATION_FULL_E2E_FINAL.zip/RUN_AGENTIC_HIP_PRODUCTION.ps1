$ErrorActionPreference = 'Stop'
& "$PSScriptRoot/RUN_AGENTIC_HIP.ps1"
