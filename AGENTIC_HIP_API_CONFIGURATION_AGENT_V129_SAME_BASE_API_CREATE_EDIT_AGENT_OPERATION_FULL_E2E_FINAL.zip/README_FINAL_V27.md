# HIP Application Studio V27 — Input JSON + Supporting Artifacts

V27 extends V26 readiness fixes with a combined intake path. Users can provide an existing `input.json` together with either a ZIP bundle or individual related artifacts such as XBM, mapping JAR, source XML, target XML, output/comparison XML, EDI/TXT, and optional Configuration Manual files.

The existing `input.json` is authoritative for explicit business values. Supporting artifacts fill blank high-confidence fields and are cross-validated before mapping to the 18 HIP APIs. Translation flows block before API mapping when the referenced mapping JAR is not actually uploaded.

All prior capabilities remain: all 18 APIs, mandatory `hip-automation`, live-only execution, API Testing Area, Scratch/API Flow Game, easy payload editing, Learn, OAuth/readiness fixes, PASS/EXISTING/BLOCKED analysis, and dependency-aware full execution.
