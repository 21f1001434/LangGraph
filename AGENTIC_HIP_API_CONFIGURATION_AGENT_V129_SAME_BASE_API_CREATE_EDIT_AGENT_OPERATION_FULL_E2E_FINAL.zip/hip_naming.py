from __future__ import annotations

import copy
import hashlib
import re
from typing import Any, Dict

HIP_FLOW_NAME_MAX_LENGTH = 40
HIP_FLOW_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$")


def validate_hip_flow_name(value: Any) -> Dict[str, Any]:
    name = str(value or "").strip()
    errors = []
    if not name:
        errors.append("Flow name is required.")
    if len(name) > HIP_FLOW_NAME_MAX_LENGTH:
        errors.append(f"Flow name must be at most {HIP_FLOW_NAME_MAX_LENGTH} characters; received {len(name)}.")
    if name and not re.match(r"^[A-Za-z0-9]", name):
        errors.append("Flow name must start with a letter or number.")
    if name and re.search(r"[^A-Za-z0-9_-]", name):
        errors.append("Flow name may contain only letters, numbers, underscore, or hyphen.")
    return {
        "valid": not errors,
        "name": name,
        "length": len(name),
        "maxLength": HIP_FLOW_NAME_MAX_LENGTH,
        "errors": errors,
    }


def compact_hip_flow_name(value: Any) -> str:
    """Return a deterministic HIP-compliant flow name (<=40 chars).

    This is a canonical-input normalization utility. It must run before LIVE
    request materialization; it is never a post-HTTP retry mutation.
    """
    original = str(value or "").strip()
    if not original:
        return ""

    # Sanitize first, preserving the business-token structure.
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", original)
    name = re.sub(r"_+", "_", name).strip("_-")
    if not name or not re.match(r"^[A-Za-z0-9]", name):
        name = "F_" + name.lstrip("_-")

    if len(name) <= HIP_FLOW_NAME_MAX_LENGTH:
        return name

    # Prefer abbreviations only for *structural HIP flow tokens*.  Never
    # shorten customer/business names (for example PREMIER, RETAIL, HARMONY).
    # This keeps the policy generic for every future customer while preserving
    # business identity.
    replacements = (
        (r"(^|_)PASSTHROUGH(?=_|$)", r"\1PASS"),
        (r"(^|_)MAPPING(?=_|$)", r"\1MAP"),
        (r"(^|_)TRANSLATION(?=_|$)", r"\1TRN"),
        (r"(^|_)INBOUND(?=_|$)", r"\1IB"),
        (r"(^|_)OUTBOUND(?=_|$)", r"\1OB"),
    )
    for pattern, replacement in replacements:
        candidate = re.sub(pattern, replacement, name, flags=re.IGNORECASE)
        name = candidate
        if len(name) <= HIP_FLOW_NAME_MAX_LENGTH:
            return name

    # Collision-resistant final fallback. Preserve the right-hand transaction /
    # application / flow-type / direction tokens and shorten only the customer
    # prefix, with a stable digest of the original canonical name.
    digest = hashlib.sha256(original.encode("utf-8")).hexdigest()[:6].upper()
    parts = name.split("_")
    suffix_parts = parts[-5:] if len(parts) >= 6 else parts[-3:]
    suffix = "_".join(suffix_parts)
    budget = HIP_FLOW_NAME_MAX_LENGTH - len(suffix) - len(digest) - 2
    prefix = "_".join(parts[:-len(suffix_parts)]) if len(parts) > len(suffix_parts) else "FLOW"
    prefix = prefix[: max(1, budget)].rstrip("_-") or "F"
    candidate = f"{prefix}_{digest}_{suffix}"
    candidate = candidate[:HIP_FLOW_NAME_MAX_LENGTH].rstrip("_-")
    if not HIP_FLOW_NAME_PATTERN.fullmatch(candidate):
        candidate = re.sub(r"[^A-Za-z0-9_-]", "_", candidate)
        if not re.match(r"^[A-Za-z0-9]", candidate):
            candidate = "F" + candidate[1:]
        candidate = candidate[:HIP_FLOW_NAME_MAX_LENGTH]
    return candidate


def normalize_input_flow_name(config: Dict[str, Any]) -> Dict[str, Any]:
    """Reconcile every canonical Flow-name alias before LIVE execution.

    The policy is deliberately customer-agnostic.  Any customer can arrive via
    a newly built input, an older persisted configuration, a queued snapshot, or
    a legacy import.  All known Flow-name aliases are normalized to one HIP-safe
    value before request materialization.  No post-HTTP rename is permitted.
    """
    if not isinstance(config, dict):
        return config

    # Keep normalization pure: callers compare the returned canonical snapshot
    # with the persisted/staged input to decide whether it must be written.
    # Mutating the caller's dict in place makes that comparison ineffective and
    # can leave a stale alias on disk even though the in-memory request is fixed.
    config = copy.deepcopy(config)

    objects = config.get("objects") if isinstance(config.get("objects"), dict) else {}
    biz = objects.get("biz_flow") if isinstance(objects.get("biz_flow"), dict) else {}
    details = biz.get("flow_details") if isinstance(biz.get("flow_details"), dict) else {}

    aliases = {
        "profile_name": str(config.get("profile_name") or "").strip(),
        "flow_name": str(config.get("flow_name") or "").strip(),
        "objects.biz_flow.flow_name": str(biz.get("flow_name") or "").strip(),
        "objects.biz_flow.flow_details.business_flow_name": str(details.get("business_flow_name") or "").strip(),
    }

    checks = {k: (validate_hip_flow_name(v) if v else {"valid": False, "errors": ["missing"]}) for k, v in aliases.items()}

    # Most specific canonical BizFlow field wins when already valid.  Otherwise
    # prefer a valid top-level canonical profile_name, then any other valid
    # legacy alias.  Only if none is valid do we deterministically compact the
    # most specific supplied value.
    priority = (
        "objects.biz_flow.flow_details.business_flow_name",
        "profile_name",
        "objects.biz_flow.flow_name",
        "flow_name",
    )
    effective = ""
    source = ""
    for key in priority:
        value = aliases.get(key) or ""
        if value and checks[key].get("valid"):
            effective, source = value, key
            break
    if not effective:
        original_candidate = next((aliases.get(key) for key in priority if aliases.get(key)), "")
        effective = compact_hip_flow_name(original_candidate)
        source = "deterministic_compaction"

    effective_check = validate_hip_flow_name(effective)
    if not effective_check["valid"]:
        return config

    if all((not value or value == effective) for value in aliases.values()) and aliases.get("profile_name") == effective and aliases.get("objects.biz_flow.flow_details.business_flow_name") == effective:
        return config

    # Write the two canonical representations unconditionally.  If legacy aliases
    # already exist, reconcile them too so no later adapter can resurrect a stale
    # >40-character value.
    details["business_flow_name"] = effective
    biz["flow_details"] = details
    if "flow_name" in biz:
        biz["flow_name"] = effective
    objects["biz_flow"] = biz
    config["objects"] = objects
    config["profile_name"] = effective
    if "flow_name" in config:
        config["flow_name"] = effective

    reasons = []
    changed_aliases = []
    for key, value in aliases.items():
        if value and value != effective:
            changed_aliases.append(key)
            if not checks[key].get("valid"):
                reasons.extend([f"{key}: {x}" for x in checks[key].get("errors", [])])
            else:
                reasons.append(f"{key} differed from canonical Flow name")

    config["_flow_name_normalization"] = {
        "original": next((aliases.get(key) for key in priority if aliases.get(key)), ""),
        "originalTopLevel": aliases.get("profile_name") or "",
        "originalNested": aliases.get("objects.biz_flow.flow_details.business_flow_name") or "",
        "originalAliases": aliases,
        "effective": effective,
        "source": source,
        "changedAliases": changed_aliases,
        "reason": reasons,
        "policy": "generic HIP flow name <=40 chars, alphanumeric start, [A-Za-z0-9_-] only; all known aliases must agree",
        "stage": "canonical input build/queue/preflight/Runner init; never post-HTTP retry mutation",
    }
    return config

