from __future__ import annotations

import datetime as dt
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from configuration_workspace import normalize_interface_type


ALLOWED_CANONICAL_PATHS = {
    "objects.source_transport_profile.interface_type",
    "objects.source_transport_profile.interface_parameters",
    "objects.target_transport_profile.interface_type",
    "objects.target_transport_profile.interface_parameters",
    # Interface selection deterministically chooses the corresponding shared
    # dce-common transport profile reference used by Flow. These are derived
    # bindings, not free-form business changes.
    "objects.biz_flow.configure_source.source_transport_profile",
    "objects.biz_flow.configure_targets.target_transport_profile",
    "objects.biz_flow.configure_routing.actions.target",
    "_interface_only_mode",
}

INTERFACE_SHARED_PROFILES: Dict[str, Dict[str, str]] = {
    "SFTP HAFT": {
        "source": "da-sender-sftphaft-dce-common",
        "target": "pt-receiver-sftphaft-dce-common",
    },
    "FTP": {
        "source": "da-sender-sftphaft-dce-common",
        "target": "pt-receiver-sftphaft-dce-common",
    },
    "HTTPS": {
        "source": "da-sender-https-dce-common",
        "target": "pt-receiver-https-dce-common",
    },
}

def interface_shared_profiles(interface_type: str) -> Dict[str, str]:
    return dict(INTERFACE_SHARED_PROFILES.get(normalize_interface_type(interface_type), {"source": "", "target": ""}))

HTTPS_SENDER_DEFAULTS: Dict[str, Any] = {
    "Protocol": "REST",
    "HIP URL": "URL will be shared later after API Publish is successful.",
    "Proxy URI": "dce-common-sv1",
    "Request Method": "POST",
    "Request Format": "Request Body",
    "Sender Authentication Type": "OAuth2",
    "Are Input Files Compressed?": "False",
    "Sender Grant Type": "client_credentials",
}

HTTPS_RECEIVER_DEFAULTS: Dict[str, Any] = {
    "Protocol": "REST",
    "Request Method": "POST",
    "Request Format": "Request Body",
    "Receiver Authentication Type": "OAuth2",
    "Gateway URL": "URL will be shared later after API Publish is successful.",
    "Are Input Files Compressed?": "False",
}

# Latest Dev guidance: these values must come from the Partner. Do not default
# or infer them. Certificate-related values are intentionally not in this list
# until the Dell team confirms the certificate contract.
HTTPS_RECEIVER_REQUIRED = [
    "Partner URL",
    "Receiver Grant Type",
    "Receiver Token Endpoint",
    "Receiver Client Id",
    "Receiver Client Secret",
]

HTTPS_RECEIVER_CERTIFICATE_IGNORED = [
    "SSL Certificate",
    "SSL Certificate CN - Expiry",
    "SSL Certificate Id",
]


HTTPS_AS2_SOURCE_KEYS = [
    "Interface Environment",
    "Request Method",
    "Partner Identifier",
    "Dell Identifier",
    "Partner Verification Certificate",
    "Are SSL and Partner Verification Certificates identical?",
    "AS2 URL",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
    "SSL Certificate",
    "Compression Format",
]

HTTPS_AS2_TARGET_KEYS = [
    "Interface Environment",
    "Request Method",
    "Partner URL",
    "Partner Identifier",
    "Dell Identifier",
    "Signing Algorithm",
    "Encryption Algorithm",
    "Encryption Certificate",
    "SSL Certificate",
    "Enable AS2 Message Compression",
    "Asynchronous MDN Required",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
    "Compression Format",
]

HTTPS_AS2_SOURCE_DEFAULTS = {
    "Interface Environment": "UAT",
    "Request Method": "POST",
    "Are SSL and Partner Verification Certificates identical?": "No",
    "Are Input Files Compressed?": "False",
    "Is EBCDIC enabled?": "False",
}

HTTPS_AS2_TARGET_DEFAULTS = {
    "Interface Environment": "UAT",
    "Request Method": "POST",
    "SSL Certificate": "dellroot_ca_6_able.crt",
    "Enable AS2 Message Compression": "False",
    "Asynchronous MDN Required": "False",
    "Are Input Files Compressed?": "False",
    "Is EBCDIC enabled?": "False",
}

HTTPS_AS2_SOURCE_REQUIRED = [
    "Partner Identifier",
    "Dell Identifier",
    "Partner Verification Certificate",
    "Are SSL and Partner Verification Certificates identical?",
    "AS2 URL",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
]

HTTPS_AS2_TARGET_REQUIRED = [
    "Partner URL",
    "Partner Identifier",
    "Dell Identifier",
    "Signing Algorithm",
    "Encryption Algorithm",
    "Encryption Certificate",
    "SSL Certificate",
    "Enable AS2 Message Compression",
    "Asynchronous MDN Required",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
]


NAS_SOURCE_KEYS = ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS", "Cron Expression"]
NAS_TARGET_KEYS = ["Protocol", "Server Name", "Server Path", "AD Group"]
RABBIT_MQ_KEYS = ["Interface Environment", "Exchange Name"]


SENSITIVE_KEYS = {
    "Receiver Client Secret",
    "Sender Client Secret",
    "client_secret",
    "clientSecret",
}


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _deep_diff(before: Any, after: Any, prefix: str = "") -> List[str]:
    paths: List[str] = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after), key=str):
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in before or key not in after:
                paths.append(path)
            else:
                paths.extend(_deep_diff(before[key], after[key], path))
        return paths
    if isinstance(before, list) and isinstance(after, list):
        length = max(len(before), len(after))
        for index in range(length):
            path = f"{prefix}[{index}]" if prefix else f"[{index}]"
            if index >= len(before) or index >= len(after):
                paths.append(path)
            else:
                paths.extend(_deep_diff(before[index], after[index], path))
        return paths
    if before != after:
        paths.append(prefix or "<root>")
    return paths


def _allowed(path: str) -> bool:
    for allowed in ALLOWED_CANONICAL_PATHS:
        if path == allowed or path.startswith(allowed + ".") or path.startswith(allowed + "["):
            return True
    return False


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            if str(key) in SENSITIVE_KEYS or "secret" in str(key).lower() :
                out[key] = "<REDACTED>"
            else:
                out[key] = _redact(item)
        return out
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value


def _interface_questions(side: str, interface_type: str, params: Dict[str, Any]) -> List[Dict[str, str]]:
    normalized = normalize_interface_type(interface_type)
    questions: List[Dict[str, str]] = []

    if normalized in {"SFTP HAFT", "FTP"}:
        return questions

    if normalized == "HTTPS":
        if side == "source":
            # Sender screenshot supplies safe defaults for every required base field.
            return questions
        for field in HTTPS_RECEIVER_REQUIRED:
            if not _clean(params.get(field)):
                questions.append({
                    "field": field,
                    "question": f"What should I use for Receiver {field}?" if not field.startswith("Receiver") else f"What should I use for {field}?",
                    "why": "The Dev-team HTTPS Receiver interfaceDetails requires this value.",
                })
        return questions

    if normalized == "NAS":
        required = NAS_SOURCE_KEYS[:-1] if side == "source" else NAS_TARGET_KEYS
        if side == "source" and _clean(params.get("Polling Interval")) == "Cron Expression":
            required = list(required) + ["Cron Expression"]
        for field in required:
            if not _clean(params.get(field)):
                questions.append({"field": field, "question": f"What should I use for NAS {side} {field}?", "why": "Required by the Dev-team NAS interfaceDetails contract supplied on 2026-09-07."})
        return questions

    if normalized == "Rabbit MQ":
        for field in RABBIT_MQ_KEYS:
            if not _clean(params.get(field)):
                questions.append({"field": field, "question": f"What should I use for Rabbit MQ {side} {field}?", "why": "Required by the Dev-team Rabbit MQ interfaceDetails contract supplied on 2026-09-07."})
        return questions

    if normalized == "HTTPS-AS2":
        required = HTTPS_AS2_SOURCE_REQUIRED if side == "source" else HTTPS_AS2_TARGET_REQUIRED
        for field in required:
            if not _clean(params.get(field)):
                questions.append({
                    "field": field,
                    "question": f"What should I use for HTTPS-AS2 {side} {field}?",
                    "why": "This value is required by the Dev-team HTTPS-AS2 interfaceDetails contract supplied on 2026-09-02; the agent will not invent it.",
                })
        questions.append({
            "field": f"{side}_https_as2_shared_profile",
            "question": f"What dce-common shared Transport Profile reference should the {side} Flow use for HTTPS-AS2?",
            "why": "The supplied AS2 evidence defines interfaceDetails attributes but does not provide a shared dce-common Flow profile name. The strict agent will not guess one.",
        })
    return questions


def build_interface_parameters(side: str, interface_type: str, supplied: Dict[str, Any] | None = None) -> Dict[str, Any]:
    normalized = normalize_interface_type(interface_type)
    supplied = deepcopy(supplied or {})

    if normalized in {"SFTP HAFT", "FTP"}:
        # SFTP/FTP reuse the baseline U-HAUL account/folder/file model. No
        # interface_parameters object is needed in canonical input.
        return {}

    if normalized == "HTTPS":
        base = deepcopy(HTTPS_SENDER_DEFAULTS if side == "source" else HTTPS_RECEIVER_DEFAULTS)
        ignored = set(HTTPS_RECEIVER_CERTIFICATE_IGNORED) if side == "target" else set()
        base.update({k: v for k, v in supplied.items() if v not in (None, "") and k not in ignored})
        for key in ignored:
            base.pop(key, None)
        return base

    if normalized == "NAS":
        keys = NAS_SOURCE_KEYS if side == "source" else NAS_TARGET_KEYS
        return {key: supplied.get(key, "") for key in keys}

    if normalized == "Rabbit MQ":
        return {key: supplied.get(key, "") for key in RABBIT_MQ_KEYS}

    if normalized == "HTTPS-AS2":
        keys = HTTPS_AS2_SOURCE_KEYS if side == "source" else HTTPS_AS2_TARGET_KEYS
        base = deepcopy(HTTPS_AS2_SOURCE_DEFAULTS if side == "source" else HTTPS_AS2_TARGET_DEFAULTS)
        for key in keys:
            if key in supplied and supplied.get(key) not in (None, ""):
                base[key] = supplied.get(key)
            elif key not in base:
                base[key] = ""
        return {key: base.get(key, "") for key in keys}

    return supplied


class TransportInterfaceReActAgent:
    """ReAct-style interface-only planner with an enforceable critic guard.

    The agent follows a compact Observe -> Plan -> Validate -> Act -> Critic
    lifecycle. The returned trace contains only safe state/action summaries,
    not hidden chain-of-thought.
    """

    def __init__(self, root: Path, baseline_input: Dict[str, Any]):
        self.root = Path(root)
        self.baseline = deepcopy(baseline_input)

    def analyze(
        self,
        *,
        source_interface: str,
        target_interface: str,
        source_parameters: Dict[str, Any] | None = None,
        target_parameters: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        source_type = normalize_interface_type(source_interface)
        target_type = normalize_interface_type(target_interface)
        source_params = build_interface_parameters("source", source_type, source_parameters)
        target_params = build_interface_parameters("target", target_type, target_parameters)

        questions = (
            _interface_questions("source", source_type, source_params)
            + _interface_questions("target", target_type, target_params)
        )

        trace = [
            {
                "phase": "OBSERVE",
                "status": "OK",
                "summary": (
                    "Loaded the approved U-HAUL baseline. All Document Type, Map, Rule, "
                    "Account, Partner, System, Flow, names, IDs, routing and deployment values are frozen."
                ),
            },
            {
                "phase": "PLAN",
                "status": "OK",
                "summary": (
                    f"Change Source TP interface to {source_type} and Target TP interface to {target_type}; "
                    "no other canonical configuration paths are allowed to change."
                ),
            },
            {
                "phase": "VALIDATE",
                "status": "NEEDS_INPUT" if questions else "OK",
                "summary": (
                    f"{len(questions)} interface-specific value(s) still required."
                    if questions
                    else "All interface-specific values required by the selected interface templates are present."
                ),
            },
        ]

        return {
            "ready": not questions,
            "sourceInterface": source_type,
            "targetInterface": target_type,
            "sourceSharedProfile": interface_shared_profiles(source_type).get("source"),
            "targetSharedProfile": interface_shared_profiles(target_type).get("target"),
            "deploymentGroup": "hip-automation",
            "sourceParameters": _redact(source_params),
            "targetParameters": _redact(target_params),
            "questions": questions,
            "trace": trace,
        }

    def propose(
        self,
        *,
        source_interface: str,
        target_interface: str,
        source_parameters: Dict[str, Any] | None = None,
        target_parameters: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        analysis = self.analyze(
            source_interface=source_interface,
            target_interface=target_interface,
            source_parameters=source_parameters,
            target_parameters=target_parameters,
        )
        if not analysis["ready"]:
            return {
                **analysis,
                "valid": False,
                "proposal": None,
                "critic": {
                    "status": "BLOCKED",
                    "violations": [],
                    "summary": "The agent will not generate a runnable change until the missing interface values are supplied.",
                },
            }

        proposed = deepcopy(self.baseline)
        objects = proposed.setdefault("objects", {})
        source_tp = objects.setdefault("source_transport_profile", {})
        target_tp = objects.setdefault("target_transport_profile", {})

        source_type = normalize_interface_type(source_interface)
        target_type = normalize_interface_type(target_interface)
        source_tp["interface_type"] = source_type
        target_tp["interface_type"] = target_type

        source_params = build_interface_parameters("source", source_type, source_parameters)
        target_params = build_interface_parameters("target", target_type, target_parameters)
        if source_type in {"HTTPS", "HTTPS-AS2"}:
            source_tp["interface_parameters"] = source_params
        else:
            source_tp.pop("interface_parameters", None)
        if target_type in {"HTTPS", "HTTPS-AS2"}:
            target_tp["interface_parameters"] = target_params
        else:
            target_tp.pop("interface_parameters", None)

        # Bind Flow to the Dev-confirmed shared dce-common profile for the
        # selected interface. SFTP/FTP share the sftphaft common profiles;
        # HTTPS uses the https common profiles. HTTPS-AS2 stays explicit until
        # the Dev team/API contract supplies its shared profile names.
        source_shared = interface_shared_profiles(source_type)
        target_shared = interface_shared_profiles(target_type)
        biz_flow = objects.setdefault("biz_flow", {})
        configure_source = biz_flow.setdefault("configure_source", {})
        configure_targets = biz_flow.setdefault("configure_targets", {})
        routing_actions = biz_flow.setdefault("configure_routing", {}).setdefault("actions", {})
        if source_shared.get("source"):
            configure_source["source_transport_profile"] = source_shared["source"]
        if target_shared.get("target"):
            configure_targets["target_transport_profile"] = target_shared["target"]
            routing_actions["target"] = target_shared["target"]

        proposed["_interface_only_mode"] = {
            "enabled": True,
            "baseline": "U-HAUL",
            "strict": True,
            "sourceInterface": source_type,
            "targetInterface": target_type,
            "createdAt": dt.datetime.now().isoformat(),
            "rule": (
                "Everything stays identical to the U-HAUL baseline except Source/Target "
                "Transport Profile interface details and the deterministic dce-common shared "
                "profile reference required by that interface."
            ),
        }

        diff_paths = _deep_diff(self.baseline, proposed)
        violations = [path for path in diff_paths if not _allowed(path)]
        valid = not violations

        trace = list(analysis["trace"])
        trace.append({
            "phase": "ACT",
            "status": "OK" if valid else "REJECTED",
            "summary": "Prepared the interface-only canonical configuration proposal.",
        })
        trace.append({
            "phase": "CRITIC",
            "status": "PASS" if valid else "FAIL",
            "summary": (
                "Strict diff guard passed: only Transport Profile interface paths and their deterministic dce-common shared profile references changed."
                if valid
                else f"Rejected because {len(violations)} non-interface path(s) changed."
            ),
        })

        return {
            **analysis,
            "valid": valid,
            "proposal": proposed if valid else None,
            "changedPaths": diff_paths,
            "critic": {
                "status": "PASS" if valid else "FAIL",
                "violations": violations,
                "allowedPaths": sorted(ALLOWED_CANONICAL_PATHS),
                "summary": trace[-1]["summary"],
            },
            "trace": trace,
        }


def _flow_definition_diff(before_payload: Any, after_payload: Any) -> Dict[str, Any]:
    """Validate that a Flow Create change only switches shared TP references."""
    allowed = {
        "sourceDetails.sourceTransportProfile",
        "targetDetails.targets[0].targetTransportProfile",
        "ruleDetails[0].actions[0].target",
    }
    try:
        before = before_payload or {}
        after = after_payload or {}
        before_def = json.loads(before.get("flowDefinition") or "{}")
        after_def = json.loads(after.get("flowDefinition") or "{}")
    except Exception as exc:
        return {"valid": False, "changedPaths": ["flowDefinition"], "violations": [f"flowDefinition parse error: {exc}"]}

    outer_before = deepcopy(before)
    outer_after = deepcopy(after)
    outer_before.pop("flowDefinition", None)
    outer_after.pop("flowDefinition", None)
    outer_changes = _deep_diff(outer_before, outer_after)
    inner_changes = _deep_diff(before_def, after_def)
    violations = list(outer_changes)
    for path in inner_changes:
        if not any(path == prefix or path.startswith(prefix + ".") or path.startswith(prefix + "[") for prefix in allowed):
            violations.append(path)
    return {
        "valid": not violations,
        "changedPaths": inner_changes,
        "violations": violations,
        "allowedPaths": sorted(allowed),
    }


def compare_request_bundles(
    baseline: Dict[str, Any],
    proposed: Dict[str, Any],
    *,
    allowed_steps: Iterable[str] = ("validate_source", "validate_target", "source_tp", "target_tp", "flow_create"),
) -> Dict[str, Any]:
    """Critic for generated API requests.

    Transport Profile requests may change for the selected interface. Flow
    Create may also change, but only at the deterministic shared dce-common TP
    references required by that interface. Every other API remains frozen.
    """
    allowed = set(allowed_steps)
    changed: Dict[str, List[str]] = {}
    violations: Dict[str, List[str]] = {}
    flow_detail: Dict[str, Any] = {}
    for key in sorted(set(baseline) | set(proposed)):
        paths = _deep_diff(baseline.get(key), proposed.get(key))
        if not paths:
            continue
        changed[key] = paths
        if key not in allowed:
            violations[key] = paths
            continue
        if key == "flow_create":
            before_payload = (baseline.get(key) or {}).get("payload") if isinstance(baseline.get(key), dict) else {}
            after_payload = (proposed.get(key) or {}).get("payload") if isinstance(proposed.get(key), dict) else {}
            flow_detail = _flow_definition_diff(before_payload, after_payload)
            if not flow_detail.get("valid"):
                violations[key] = flow_detail.get("violations") or paths
    return {
        "valid": not violations,
        "changedSteps": changed,
        "violations": violations,
        "flowCreateCritic": flow_detail,
        "allowedChangedSteps": sorted(allowed),
        "summary": (
            "Only Transport Profile requests and deterministic Flow shared-profile references changed."
            if not violations
            else "A frozen API request or non-profile Flow field changed and the proposal must be rejected."
        ),
    }


def validate_interface_only_input(baseline: Dict[str, Any], candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Public strict guard used by the live runner before any API is called."""
    changed = _deep_diff(baseline, candidate)
    violations = [path for path in changed if not _allowed(path)]
    mode = candidate.get("_interface_only_mode") if isinstance(candidate, dict) else None
    enabled = bool(isinstance(mode, dict) and mode.get("enabled"))
    return {
        "enabled": enabled,
        "valid": (not enabled) or not violations,
        "changedPaths": changed,
        "violations": violations,
        "summary": (
            "Strict interface-only guard passed."
            if (not enabled or not violations)
            else "Strict interface-only guard failed: a frozen business path changed."
        ),
    }


REQUEST_ALLOWED_PREFIXES = {
    "validate_source": ("interfaceType", "propertyMap"),
    "validate_target": ("interfaceType", "propertyMap"),
    "source_tp": ("transportProfileDetails[0].interfaceDetails",),
    "target_tp": ("transportProfileDetails[0].interfaceDetails",),
}


def validate_interface_only_request_override(step_key: str, generated: Any, effective: Any) -> Dict[str, Any]:
    """Reject a manual request edit that changes anything outside TP interface fields."""
    changed = _deep_diff(generated, effective)
    allowed_prefixes = REQUEST_ALLOWED_PREFIXES.get(str(step_key), ())
    violations: List[str] = []
    if str(step_key) not in REQUEST_ALLOWED_PREFIXES and changed:
        violations = list(changed)
    else:
        for path in changed:
            if not any(path == prefix or path.startswith(prefix + ".") or path.startswith(prefix + "[") for prefix in allowed_prefixes):
                violations.append(path)
    return {
        "valid": not violations,
        "stepKey": str(step_key),
        "changedPaths": changed,
        "violations": violations,
        "allowedPrefixes": list(allowed_prefixes),
        "summary": (
            "Manual edit stays inside Transport Profile interface fields."
            if not violations
            else "Manual edit changes a frozen non-interface request field."
        ),
    }
