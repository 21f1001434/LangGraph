# V120 — Dev-Approved HTTPS-AS2 Interface Schema Ingest

## What changed

V120 ingests the HTTPS-AS2 Sender and Receiver `interfaceDetails.parameters` attributes supplied by the Dev team on 2026-09-02. The application no longer treats HTTPS-AS2 as an unknown/free-form JSON contract.

The Transport Profile architecture remains unchanged: the outer Source/Target Transport Profile payload and nesting are invariant across SFTP HAFT, FTP, HTTPS and HTTPS-AS2. Only `transportProfileDetails[0].interfaceDetails` varies by interface.

## Sender / Source HTTPS-AS2 attributes

The active schema is exactly:

1. `Interface Environment`
2. `Request Method`
3. `Partner Identifier`
4. `Dell Identifier`
5. `Partner Verification Certificate`
6. `Are SSL and Partner Verification Certificates identical?`
7. `AS2 URL`
8. `Are Input Files Compressed?`
9. `Is EBCDIC enabled?`
10. `SSL Certificate`
11. `Compression Format`

Dev rules ingested:

- `Are SSL and Partner Verification Certificates identical?`: `Yes` / `No`.
- If that value is `Yes`, `SSL Certificate` is omitted from the LIVE request.
- `Are Input Files Compressed?`: `True` / `False`.
- If that value is `False`, `Compression Format` is omitted from the LIVE request.
- `Compression Format`: `GZIP`, `ZIP`, or `TAR`.
- `Is EBCDIC enabled?`: handled as `True` / `False`.

## Receiver / Target HTTPS-AS2 attributes

The active schema is exactly:

1. `Interface Environment`
2. `Request Method`
3. `Partner URL`
4. `Partner Identifier`
5. `Dell Identifier`
6. `Signing Algorithm`
7. `Encryption Algorithm`
8. `Encryption Certificate`
9. `Enable AS2 Message Compression`
10. `Asynchronous MDN Required`
11. `Are Input Files Compressed?`
12. `Is EBCDIC enabled?`
13. `Compression Format`

Dev values/rules ingested:

- `Signing Algorithm`: `SHA1`, `SHA256`, `SHA512`.
- `Encryption Algorithm`: `AES128`, `AES256`.
- `Compression Format`: `GZIP`, `ZIP`, `TAR`.
- `Are Input Files Compressed?`: `True` / `False`; when `False`, `Compression Format` is omitted.
- `Enable AS2 Message Compression`: `True` / `False`.
- `Asynchronous MDN Required`: `True` / `False`.
- `Is EBCDIC enabled?`: handled as `True` / `False`.

## Removed from the active V120 AS2 contract

The latest supplied AS2 payload does not contain the older AS2 fields below, so V120 no longer emits them for HTTPS-AS2:

- `Partner Verification Certificate Id`
- `Partner Verification Certificate CN – Expiry`
- `Encryption Certificate Id`
- `Encryption Certificate CN – Expiry`
- Receiver `Is Compression Required`

Historical V117 proof files are retained as historical release evidence only; the active runtime schema is `schemas/dev_approved_transport_interface_shapes.json` version 3 and this V120 contract supersedes their AS2 sections.

## Runtime enforcement

`run_agent.py` now materializes only the approved HTTPS-AS2 keys. Unknown AS2 attributes are dropped by the canonical structure lock. Dev-enumerated values are validated before LIVE request construction; unsupported values such as an unapproved signing/encryption/compression algorithm fail closed.

The canonical LIVE request lock applies the two documented conditional omission rules. These deterministic omissions are contract behavior, not agent payload mutation.

## User editing governance remains unchanged

The same V119 editor remains available in:

- Build Configuration
- API Testing Area
- API Flow Game

A human user can select an existing API attribute and change only its value. The user cannot rename/add/remove API attributes or alter method, URL, protected headers, request kind, nesting or array cardinality. AI/AutoGen/Dell-AIA cannot persist an active payload value edit.

## UI behavior

Legacy/advanced interface configuration screens now render the approved HTTPS-AS2 Sender/Receiver fields directly instead of asking the user to paste arbitrary AS2 JSON. Conditional fields are shown/omitted according to the Dev rules.

## Validation artifact

`V120_HTTPS_AS2_INTERFACE_CONTRACT_INGEST.json` is the machine-readable Sender/Receiver contract bundle for Dev review and integration evidence.

## Dev-validation payload artifacts

- `V120_AS2_SOURCE_TP_VALIDATE_DEV_VALIDATION.json`
- `V120_AS2_TARGET_TP_VALIDATE_DEV_VALIDATION.json`
- `V120_HTTPS_AS2_INTERFACE_CONTRACT_INGEST.json`
- `V120_AS2_RUNTIME_PROOF.json` — runtime materialization + conditional-omission proof.

The two validation JSONs intentionally show the complete approved attribute catalogue. At runtime, the conditional omission rules remove `SSL Certificate` and/or `Compression Format` when their controlling values require omission.
