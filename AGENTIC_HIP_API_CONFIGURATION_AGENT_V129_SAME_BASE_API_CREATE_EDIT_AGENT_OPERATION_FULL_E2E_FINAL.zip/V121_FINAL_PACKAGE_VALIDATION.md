# V121 Final Package Validation

## Release

V121 applies the final Dev-approved HTTPS-AS2 correction supplied on 2026-09-02: **Receiver/Target `SSL Certificate` is required**. The reviewed DEV value is `dellroot_ca_6_able.crt`, used as the Receiver Dev default while remaining human-editable. All other V120 HTTPS-AS2 attributes, enums and conditional rules remain unchanged.

## Runtime implementation

- HTTPS-AS2 Receiver schema now contains `SSL Certificate` immediately after `Encryption Certificate`.
- `SSL Certificate` is included in Receiver required-value/gap collection.
- Runtime TP validation and TP orchestration materializers preserve the supplied SSL Certificate value.
- Canonical LIVE locking keeps Receiver `SSL Certificate`; it is **not** subject to the Sender-only certificate-identical omission rule.
- `Compression Format` remains the only Receiver conditional omission when `Are Input Files Compressed? = False`.
- Build Configuration, API Testing Area and API Flow Game keep human-only value editing; AI/AutoGen/Dell-AIA cannot persist the value.
- The outer Transport Profile contract remains invariant across SFTP HAFT, FTP, HTTPS and HTTPS-AS2.

## Approval evidence

- `V121_AS2_TARGET_TP_VALIDATE_DEV_APPROVED.json` includes `"SSL Certificate": "dellroot_ca_6_able.crt"`.
- `V121_AS2_TARGET_TP_ORCHESTRATION_DEV_APPROVED.json` includes the same field/value under `transportProfileDetails[0].interfaceDetails[0].parameters`.
- `V121_HTTPS_AS2_INTERFACE_CONTRACT_DEV_APPROVED.json` records the corrected schema.
- `V121_AS2_SSL_CERTIFICATE_RUNTIME_PROOF.json` verifies schema, required-field and runtime-preservation behavior.

## Validation results

- Full repository regression: **515/515 PASS**
- FastAPI/backend: **48/48 PASS**
- Package validator: **59/59 PASS**
- Adaptive validator: **60/60 PASS**
- Business readiness: **70/70 PASS**
- Final release: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1: **12/12 PASS**
- Phase 2: **19/19 PASS**
- Phase 3: **31/31 PASS**
- Phase 4: **26/26 PASS**
- Phase 5: **28/28 PASS**
- Phase 6: **38/38 PASS**

No authenticated Dell LIVE mutation was executed in this validation environment. Contract/runtime verification is non-mutating.
