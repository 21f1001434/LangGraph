import json
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.main import STORE, PARALLEL, app
from webapp.backend.app.legacy_adapter import preview_api_requests


def _cleanup_uhal_test_workspaces() -> None:
    for row in list(STORE.list_configurations()):
        if str(row.get("managed_reference_source") or "") == "reference:uhal" or bool(row.get("cloned_from_approved_reference")):
            STORE.delete_configuration(str(row.get("id") or ""))


def test_v66_uhal_reference_is_immutable_and_clones_carry_customer_edits():
    client = TestClient(app)
    _cleanup_uhal_test_workspaces()
    reference_job = ""
    clone_job = ""
    managed_id = ""
    clone_id = ""
    try:
        before = [row for row in client.get("/api/parallel/sources").json() if row.get("sourceId") == "reference:uhal"]
        assert len(before) == 1
        assert before[0].get("sourceKind") == "reference"
        assert before[0].get("approvalStatus") == "DEV_APPROVED"
        assert before[0].get("validated") is True
        assert before[0].get("validCount") == before[0].get("totalContracts") == 18

        managed = client.post("/api/flow/sources/reference:uhal/materialize").json()
        managed_id = str(managed["id"])
        assert managed.get("approved_reference") is True
        assert managed.get("immutable_reference") is True

        marker = "V66_CUSTOMER_CLONE_OVERRIDE"
        blocked = client.put(
            f"/api/configurations/{managed_id}/payload-overrides/account_source",
            headers={"X-HIP-User-Action": "payload-value-edit-v1", "X-HIP-Actor": "Human User"},
            json={"mode": "merge", "value": {"description": marker}},
        )
        assert blocked.status_code == 409
        assert "Create from U-HAUL" in blocked.text or "Clone" in blocked.text

        cloned = client.post(
            f"/api/configurations/{managed_id}/clone",
            json={"name": "V66 editable U-HAUL starter"},
        )
        assert cloned.status_code == 200
        clone = cloned.json()
        clone_id = str(clone["id"])
        assert clone.get("approved_reference") is not True
        assert clone.get("cloned_from_approved_reference") is True

        baseline_rows = client.get(f"/api/configurations/{clone_id}/api-requests").json()["items"]
        baseline_account = next(row for row in baseline_rows if row.get("stepKey") == "account_source")
        edited_account = dict(baseline_account["payload"])
        edited_account["description"] = marker
        saved = client.put(
            f"/api/configurations/{clone_id}/payload-overrides/account_source",
            headers={"X-HIP-User-Action": "payload-value-edit-v1", "X-HIP-Actor": "Human User"},
            json={"mode": "paths", "request_kind": "payload", "value": edited_account},
        )
        assert saved.status_code == 200
        assert saved.json().get("agentEditAllowed") is False
        assert saved.json().get("userEditAllowed") is True
        request_rows = client.get(f"/api/configurations/{clone_id}/api-requests").json()["items"]
        account = next(row for row in request_rows if row.get("stepKey") == "account_source")
        assert account["payload"]["description"] == marker

        # The immutable reference stays approved and does not inherit clone edits.
        after = [row for row in client.get("/api/parallel/sources").json() if row.get("sourceId") == "reference:uhal"]
        assert len(after) == 1
        assert after[0].get("sourceKind") == "reference"
        assert after[0].get("persistedEdits") is False
        assert after[0].get("approvalStatus") == "DEV_APPROVED"
        assert after[0].get("validated") is True

        queued_ref_response = client.post("/api/parallel/queue-sources", json={"source_ids": ["reference:uhal"]})
        assert queued_ref_response.status_code == 200
        queued_ref = queued_ref_response.json()["items"][0]
        reference_job = str(queued_ref["jobId"])
        assert queued_ref.get("sourceKind") == "reference"
        ref_workspace = Path(str(queued_ref["workspace"]))
        if (ref_workspace / "payload_overrides.json").exists():
            assert marker not in (ref_workspace / "payload_overrides.json").read_text(encoding="utf-8")
        ref_requests = preview_api_requests(ref_workspace)["items"]
        ref_account = next(row for row in ref_requests if row.get("stepKey") == "account_source")
        assert marker not in json.dumps(ref_account.get("payload") or {})

        # Once validated, the clone can be queued independently and the explicit HUMAN USER value edit persists.
        validated_clone = client.post(f"/api/configurations/{clone_id}/validate")
        assert validated_clone.status_code == 200
        assert validated_clone.json().get("ok") is True
        queued_clone_response = client.post("/api/parallel/queue-sources", json={"source_ids": [clone_id]})
        assert queued_clone_response.status_code == 200
        queued_clone = queued_clone_response.json()["items"][0]
        clone_job = str(queued_clone["jobId"])
        clone_workspace = Path(str(queued_clone["workspace"]))
        override_file = clone_workspace / "payload_overrides.json"
        assert override_file.exists()
        persisted = json.loads(override_file.read_text(encoding="utf-8"))
        assert marker in json.dumps(persisted)
        assert persisted["overrides"]["account_source"]["editOrigin"] == "USER"
        clone_requests = preview_api_requests(clone_workspace)["items"]
        clone_account = next(row for row in clone_requests if row.get("stepKey") == "account_source")
        assert marker in json.dumps(clone_account.get("payload") or {})
    finally:
        if reference_job:
            PARALLEL.delete_job(reference_job)
        if clone_job:
            PARALLEL.delete_job(clone_job)
        if clone_id:
            STORE.delete_configuration(clone_id)
        if managed_id:
            STORE.delete_configuration(managed_id)
        _cleanup_uhal_test_workspaces()
