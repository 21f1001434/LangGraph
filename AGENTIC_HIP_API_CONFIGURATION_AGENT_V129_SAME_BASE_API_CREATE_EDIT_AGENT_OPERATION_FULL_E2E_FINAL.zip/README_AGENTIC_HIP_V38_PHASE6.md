# Agentic HIP API Configuration Agent — Phase 6 / V38

Phase 6 completes the primary UI cutover to **React/Bun + FastAPI/Python**.

## What changed

- The normal product path no longer requires Streamlit.
- `SETUP_AGENTIC_HIP.bat` installs the Python runtime, installs/builds the React frontend with Bun, and starts the single-port application.
- `RUN_AGENTIC_HIP.bat` starts the compiled React UI from FastAPI at `http://127.0.0.1:8765`.
- `RUN_HIP_STUDIO.bat` and `SETUP_AND_RUN.bat` are compatibility aliases to the React application.
- `RUN_AGENTIC_HIP_DEV.bat` keeps the two-process Vite + FastAPI development mode.
- The old Streamlit source remains only as an optional archive/reference path through `RUN_LEGACY_STREAMLIT_ARCHIVE.bat` and `requirements_legacy_streamlit.txt`.

## React feature parity

The React application now includes:

1. Configuration Library / portable configuration bundles / audit ledger.
2. Input Builder for customer-files-only, Configuration Manual + files, or existing `input.json` + files.
3. Physical file truth and file→`input.json` mapping learner.
4. All 18 reusable HIP API blocks.
5. API Flow Game with executable edges and output→payload runtime mappings.
6. **API Testing Area** for one selected API: inspect, override, agent preflight, then LIVE execution.
7. Manual approval gates, Stop LIVE, checkpoint resume and run comparison.
8. Parallel validated configurations and U-HAUL multi-instance demo.
9. Learn / Dell AIA text and vision intake.
10. Reports and execution evidence bundles.
11. Template draft/publish/archive/version lifecycle.
12. **System & Connections** with secure connection health separated from configuration/payload readiness.

## Phase 6 startup

First setup:

```bat
SETUP_AGENTIC_HIP.bat
```

Normal run after setup:

```bat
RUN_AGENTIC_HIP.bat
```

Development mode:

```bat
RUN_AGENTIC_HIP_DEV.bat
```

Optional archived Streamlit reference UI:

```bat
python -m pip install -r requirements_legacy_streamlit.txt
RUN_LEGACY_STREAMLIT_ARCHIVE.bat
```

## Safety / execution policy

- User-triggered API execution is LIVE-only.
- API/graph preflight is non-mutating.
- The API Testing Area requires explicit LIVE confirmation for the selected API.
- `hip-automation` remains mandatory for automation interfaces.
- `PASS / EXISTING` remains a successful reusable outcome.
- Unresolved DUNS/certificates/business prerequisites remain blockers rather than fabricated values.

## Transaction model

Direction remains editable. `Outbound` is only a convenience default.

- Inbound: 850 and future transaction codes; Translation or Passthrough.
- Outbound: 832, 855, 856 and future transaction codes; Translation or Passthrough.

Physical customer files determine physical document format. A transaction code such as `850` does not force EDI when the uploaded payload is XML.

## Release verification

- Python regression: **144/144 PASS**
- Standard package validator: **57/57 PASS**
- Adaptive package validator: **60/60 PASS**
- Required final self-check: **43/43 PASS**
- Phase checks: Phase 1 **12/12**, Phase 2 **19/19**, Phase 3 **30/30**, Phase 4 **26/26**, Phase 5 **28/28**, Phase 6 **30/30**
- React/TypeScript syntax transpilation: **22 files, 0 diagnostics**
- FastAPI smoke: `/api/health`, `/api/bootstrap`, `/api/system/status` all **200 OK**

Bun itself is not installed in the build sandbox, so the actual Vite production bundle was not built here. `SETUP_AGENTIC_HIP.bat` performs `bun install` + `bun run build` on the target Windows machine before normal Phase 6 use.
