# V122 — NAS + Rabbit MQ + Migration API Full End-to-End Integration

## Release scope

V122 extends the V121 release with the Dev-supplied NAS and Rabbit MQ Transport Profile interface contracts and the five published HIP Migration orchestration endpoints shared on 2026-09-07.

The integration is additive. The historical **18 create/configuration APIs remain frozen and unchanged**, while **7 reusable Migration blocks** are added for the five published Migration endpoints. The complete Studio therefore exposes **25 reusable blocks = 18 existing + 7 migration** without changing the old create pipeline.

## NAS Transport Profile contract

### Sender

Exact attributes:

- `Protocol`
- `Server Name`
- `Server Path`
- `AD Group`
- `File Filtering Pattern`
- `Polling Interval`
- `Post File Transfer Action NAS`
- `Cron Expression`

### Receiver

Exact attributes:

- `Protocol`
- `Server Name`
- `Server Path`
- `AD Group`

Dev-supplied value rules are enforced:

- `Protocol`: `NFS`, `SMB`, `Multi Protocol`
- `Post File Transfer Action NAS`: `Delete`, `Move To Archive`, `Rename`
- For `Protocol=NFS`, the post-transfer action must be `Delete`.
- `Polling Interval`: `Every 5 Minutes`, `Every 15 Minutes`, `Every 30 Minutes`, `Every Hour`, `Every 12 Hours`, `Every Day`, `Cron Expression`.
- When `Polling Interval=Cron Expression`, `Cron Expression` is required.

Unknown NAS parameters are removed by the canonical structure lock; the agent cannot invent additional NAS attributes.

## Rabbit MQ Transport Profile contract

Sender and Receiver use exactly:

- `Interface Environment`
- `Exchange Name`

`Interface Environment` is restricted to `DEV`, `TEST`, or `PERF`. No queue name, routing key, host, port, credentials, or other unshared Rabbit MQ attributes are invented.

## Migration APIs

Published endpoints integrated exactly as POST requests:

1. `/api/migration/orchestration/document-type`
2. `/api/migration/orchestration/data-map`
3. `/api/migration/orchestration/rule`
4. `/api/migration/orchestration/transport-profile`
5. `/api/migration/orchestration/flow`

They are exposed as seven logical reusable blocks because Source/Target Document Types and Source/Target Transport Profiles are separate canonical objects:

1. `migrate_doctype_source`
2. `migrate_doctype_target`
3. `migrate_map`
4. `migrate_rule`
5. `migrate_source_tp`
6. `migrate_target_tp`
7. `migrate_flow`

Migration requests use the active canonical object identity and version. `sourceEnvironment` defaults to the active HIP environment. `targetEnvironment` is intentionally **not copied from screenshot examples** and must be configured or explicitly changed by the human user.

Transport Profile migration reuses the selected Source/Target TP interface type and the same schema-locked parameter materializer used by the create/validate path. NAS, Rabbit MQ, SFTP/FTP, HTTPS and HTTPS-AS2 therefore do not have competing migration-only interface schemas.

## End-to-end Migration execution

V122 includes:

- deterministic Migration request factories;
- non-mutating Migration preflight across all applicable blocks;
- strict LIVE Migration credential/preflight gate;
- ordered Migration pipeline execution in the published object order;
- `NOT_APPLICABLE` handling for objects that are not part of a configuration, instead of manufacturing neutral payloads;
- CLI switches `--migration-preflight` and `--migration-run`;
- built-in Flow Game template **Environment Migration · All Published Objects**;
- Migration blocks in Build Configuration, API Testing Area and API Flow Game.

A Migration-only run requires the HIP Config OAuth profile and governed Dell-AIA/LIVE controls. It does not incorrectly require unrelated Account/Partner/System OAuth profiles unless those APIs are actually part of the requested create/configuration run.

## Human-only value editing governance

The V117–V121 governance remains unchanged across all 25 blocks:

- the user may select an existing API attribute and change **only its value**;
- attribute names, method, endpoint, protected headers, request kind, nesting and array shape remain immutable;
- AutoGen/Dell-AIA may inspect, explain, validate and recommend, but cannot persist an active payload value change;
- LIVE materialized requests are fingerprinted so retries/agents cannot silently mutate a previously approved request.

This same editor model is used in **Build Configuration**, **API Testing Area**, and **API Flow Game**.

## Existing contracts preserved

- V121 HTTPS-AS2 Receiver `SSL Certificate` remains required and is not removed by V122.
- The outer Transport Profile orchestration contract remains invariant; only `transportProfileDetails[0].interfaceDetails` varies by interface.
- The original immutable 18-API schema is still the historical create/configuration contract. NAS/Rabbit MQ and Migration are additive catalogs rather than silent modifications to that frozen baseline.

## Machine-readable contract evidence

- `V122_NAS_RABBITMQ_INTERFACE_CONTRACT_INGEST.json`
- `V122_MIGRATION_API_CONTRACT_INGEST.json`
- `schemas/dev_supplied_nas_rabbitmq_interface_shapes.json`
- `schemas/dev_published_migration_request_shapes.json`
- `V122_FINAL_PACKAGE_VALIDATION.md`

## Validation

Final source validation completed successfully:

- Complete repository pytest inventory: **531/531 PASS**
- V117–V122 focused governance/interface/migration regression: **57/57 PASS**
- FastAPI/backend: **48/48 PASS**
- Package validator: **59/59 PASS**
- Adaptive package validator: **60/60 PASS**
- Business readiness: **70/70 PASS**
- Final release: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1: **12/12 PASS**
- Phase 2: **19/19 PASS**
- Phase 3: **31/31 PASS**
- Phase 4: **26/26 PASS**
- Phase 5: **28/28 PASS**
- Phase 6: **38/38 PASS**
- Frontend TypeScript/TSX isolated syntax transpilation: **25 files / 0 errors**
- Non-mutating Migration preflight with an explicit target environment: **5 published endpoints / 7 logical blocks READY**

No authenticated Dell HIP mutation was executed as part of release validation.
