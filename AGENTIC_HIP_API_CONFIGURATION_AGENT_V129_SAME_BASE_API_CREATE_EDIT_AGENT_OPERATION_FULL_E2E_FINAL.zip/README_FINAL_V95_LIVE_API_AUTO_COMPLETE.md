# V95 — LIVE API Auto-Completion + Parallel OAuth Hardening

## Runtime behavior

`RUN LIVE EXECUTION` in the React application is a real mutating HIP execution path. The frontend sends `confirm_live=true` to FastAPI. The backend creates a LIVE parallel batch, and every selected immutable customer snapshot is owned by a Microsoft AutoGen AgentChat 0.7.5 `AssistantAgent`.

Each worker:

1. Revalidates the exact staged payload/contracts.
2. Runs production readiness checks.
3. Calls the real HIP APIs; there is no dry-run fallback.
4. Executes dependency-ready APIs in parallel.
5. Resolves/reuses objects that already exist.
6. Performs bounded LIVE auto-completion passes for any unresolved Account, Partner, System, Document Type, Map, Rule, Transport Profile, Flow Create, Flow Deploy, and Flow History steps.
7. Reconciles earlier transient failures only when later concrete LIVE evidence proves the object/flow is usable.
8. Produces the final HTML/JSON evidence and final batch verdict.

## V94/V95 OAuth hardening retained

- One token request per credential profile inside a worker (`single-flight`).
- Token endpoint requests are serialized across separate AutoGen worker processes using a secret-free OS temp lock keyed only by token URL hash.
- Transient network/proxy/timeout failures retry with bounded backoff.
- OAuth HTTP 408/425/429/500/502/503/504 retry.
- OAuth HTTP 400/401/403 fail immediately.
- Token diagnostic file persistence remains best-effort and cannot turn a successful token/API call into a failure.

## What auto-completion does not fabricate

V95 creates/resolves missing HIP objects from an already validated customer configuration. It never invents customer-owned or security-sensitive values such as OAuth credentials, partner DUNS, certificate references, passwords, keys, or other required secrets. Those remain explicit preflight blockers.
