from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"name": name, "ok": bool(ok), "detail": detail})

manifest = json.loads((ROOT / "AGENTIC_HIP_PHASE3_MANIFEST.json").read_text(encoding="utf-8"))
main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
flow_engine = (ROOT / "webapp/backend/app/flow_engine.py").read_text(encoding="utf-8")
worker = (ROOT / "webapp/backend/app/legacy_worker.py").read_text(encoding="utf-8")
runner = (ROOT / "run_agent.py").read_text(encoding="utf-8")
flow_ui = (ROOT / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
edge_ui = (ROOT / "webapp/frontend/src/components/EdgeInspector.tsx").read_text(encoding="utf-8")
node_ui = (ROOT / "webapp/frontend/src/components/NodeInspector.tsx").read_text(encoding="utf-8")
sidebar = (ROOT / "webapp/frontend/src/components/Sidebar.tsx").read_text(encoding="utf-8")

check("Phase 3 manifest", manifest.get("phase") == 3 and manifest.get("release") == "V35")
check("LIVE-only preserved", manifest.get("liveOnlyExecution") is True)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
check("Current deployment group is hip-automation", DEFAULT_DEPLOYMENT_GROUP == "hip-automation")
check("18 API block declaration", manifest.get("apiBlocks") == 18)
check("Executable graph declared", manifest.get("features", {}).get("executableGraph") is True)
check("Runtime edge mapping engine", "def apply_edge_mappings" in flow_engine and "set_path" in flow_engine)
check("Graph compiler detects cycles", "CYCLE" in flow_engine and "executionOrder" in flow_engine)
check("High-confidence mapping suggestions", "suggestedMappings" in flow_engine and "confidence" in flow_engine)
check("Safe graph auto-fix", "def apply_safe_fixes" in flow_engine)
check("Flow preflight route", '/flow/preflight' in main)
check("Flow auto-fix route", '/flow/autofix' in main)
check("LIVE launch requires validated configuration", "Agent validation must PASS before LIVE graph execution." in main)
check("LIVE launch repeats graph preflight", "preflight_flow_requests" in main)
check("Worker applies runtime edge mappings", "apply_edge_mappings" in worker and "resolvedMappings" in worker)
check("Missing edge output blocks before request", "node.mapping_blocked" in worker)
check("HTTP attempt stream", "node.http_attempt" in worker and "http.attempt" in runner)
check("Retry stream", "node.retry" in worker and "http.retry" in runner)
check("Per-node timing retained", '"apiMs"' in worker and '"totalMs"' in worker)
execution_manager = (ROOT / "webapp/backend/app/execution_manager.py").read_text(encoding="utf-8")
check("Graph execution persisted into Reports", "react_flow_execution_latest.json" in execution_manager)
check("Connection inspector exists", "Connection mapping" in edge_ui and "Add value mapping" in edge_ui)
check("React graph can select edges", "onEdgeClick" in flow_ui)
check("React Agent preflight visible", "Agent preflight" in flow_ui)
check("React Agent auto-wire visible", "Agent auto-wire" in flow_ui)
check("React runtime mapping metric", "runtime mappings" in flow_ui)
check("Node block settings visible", "Stop flow if blocked" in node_ui and "Manual approval before LIVE API" in node_ui and "Wait after step (seconds)" in node_ui)
check("Immutable node payload policy visible", "Ad-hoc payload/parameter mutation is disabled" in node_ui and "Override mode" not in node_ui)
check("Node retry evidence visible", "HTTP attempts / retries" in node_ui)
check("Phase 3+ visible in sidebar", ("Phase 3" in sidebar or "Phase 4" in sidebar or "Phase 5" in sidebar or "Phase 6" in sidebar))

try:
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    from webapp.backend.app.flow_engine import apply_edge_mappings
    check("Exactly 18 reusable APIs at runtime", len(api_catalog()) == 18 and all(x.get("reusable") for x in api_catalog()))
    meta = transaction_metadata()
    check("Direction remains editable", meta.get("editable_direction") is True and meta.get("default_direction") == "Outbound")
    req, resolved, unresolved = apply_edge_mappings(
        {"requestKind":"payload","payload":{"documentTypeId":0}},
        [{"id":"e","source":"doc","target":"rule","mappings":[{"from":"output.documentTypeId","to":"payload.documentTypeId"}]}],
        {"doc":{"documentTypeId":123}},
    )
    check("Runtime mapping functional smoke test", req["payload"]["documentTypeId"] == 123 and len(resolved) == 1 and not unresolved)
except Exception as exc:
    check("Phase 3 Python imports", False, str(exc))

failed = [row for row in checks if not row["ok"]]
summary = {"status": "PASS" if not failed else "FAIL", "passed": len(checks)-len(failed), "failed": len(failed), "checks": checks}
print(json.dumps(summary, indent=2))
raise SystemExit(1 if failed else 0)
