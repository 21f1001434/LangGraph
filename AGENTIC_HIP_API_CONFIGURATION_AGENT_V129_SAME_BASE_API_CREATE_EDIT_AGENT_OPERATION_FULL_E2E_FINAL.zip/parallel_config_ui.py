from __future__ import annotations

import os
import json
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from parallel_configurations import (
    delete_queued_configuration,
    list_queued_configurations,
    run_parallel_configurations,
    snapshot_validated_configuration_instances,
)
from application_studio import run_local_request_checks


def render_parallel_configuration_workspace(root: Path) -> None:
    root = Path(root)
    st.markdown("## ⚡ Parallel Configuration Agents")
    st.caption(
        "Run multiple agent-validated customer configurations at the same time. "
        "Each configuration keeps its own dependency-safe 18-API sequence and isolated reports/payloads."
    )

    st.markdown("### 🎬 U-HAUL parallel capability demo")
    st.caption(
        "When the active configuration is the validated U-HAUL configuration, clone the exact same approved payload set into multiple isolated agent instances. "
        "They run concurrently to demonstrate parallel capability; each instance still preserves the dependency order inside its own 18-API flow."
    )
    try:
        input_data = json.loads((root / "input.json").read_text(encoding="utf-8")) if (root / "input.json").exists() else {}
    except Exception:
        input_data = {}
    active_customer = str((input_data or {}).get("customer") or "")
    is_uhal = "UHAUL" in active_customer.upper().replace("-", "").replace(" ", "")
    d1, d2 = st.columns([1, 2])
    demo_count = d1.number_input(
        "U-HAUL instances", min_value=2, max_value=8, value=3, step=1, key="uhal_parallel_instance_count"
    )
    d2.caption(
        "This does not rename HIP objects. All demo instances use the same validated U-HAUL payloads, so existing-object responses remain PASS / EXISTING. "
        "Use only when repeated live calls to the approved U-HAUL baseline are acceptable."
    )
    demo_ack = st.checkbox(
        "I confirm the active U-HAUL configuration is approved for repeated LIVE parallel execution",
        key="uhal_parallel_demo_ack",
    )
    if st.button(
        f"➕ Create {int(demo_count)} isolated U-HAUL parallel instances",
        width="stretch",
        disabled=not (is_uhal and demo_ack),
        key="uhal_parallel_demo_queue",
    ):
        try:
            validation = run_local_request_checks(root)
            if not validation.get("ok"):
                st.error("The active U-HAUL configuration is not agent-validated yet. Fix the validation blocker before creating parallel instances.")
            else:
                queued_demo = snapshot_validated_configuration_instances(
                    root, validation, int(demo_count), label_prefix="U-HAUL Parallel Demo"
                )
                st.success(f"Created {len(queued_demo)} isolated U-HAUL demo instances. Select them below and launch the parallel LIVE batch.")
                st.rerun()
        except Exception as exc:
            st.error(f"Could not create U-HAUL parallel demo instances: {exc}")
    if not is_uhal:
        st.info("Load or build the U-HAUL configuration and validate it first; then this demo control becomes available.")

    rows = list_queued_configurations(root)
    if not rows:
        st.info("No validated configurations are queued yet. Build/validate a configuration first, then add it to the parallel queue.")
        return

    display_rows: List[Dict[str, Any]] = []
    for row in rows:
        display_rows.append({
            "Ready": "✓" if row.get("ready") else "⛔",
            "Customer": row.get("customer"),
            "Flow": row.get("flow"),
            "Direction": row.get("direction"),
            "Flow type": row.get("flowType"),
            "Validated": row.get("createdAt"),
            "Label": row.get("label"),
            "Instance": row.get("demoInstance") or "",
            "Job ID": row.get("jobId"),
        })
    st.dataframe(display_rows, width="stretch", hide_index=True)

    ready = [row for row in rows if row.get("ready")]
    labels = {f"{row.get('customer')} · {row.get('flow')} · {row.get('jobId')}": row.get("jobId") for row in ready}
    selected_labels = st.multiselect(
        "Validated configurations to run",
        options=list(labels),
        default=list(labels)[: min(3, len(labels))],
        key="parallel_config_selected",
    )
    selected_ids = [labels[label] for label in selected_labels]

    default_workers = max(1, min(int(os.getenv("HIP_PARALLEL_CONFIG_WORKERS", "3") or 3), 8))
    workers = st.number_input(
        "Parallel agent workers",
        min_value=1,
        max_value=8,
        value=min(default_workers, max(1, len(selected_ids) or 1)),
        step=1,
        help="This controls how many independent customer configurations run concurrently. The API steps inside each configuration remain dependency ordered.",
        key="parallel_config_workers",
    )
    st.caption("Default is intentionally bounded to protect HIP API/OAuth services from unnecessary bursts. HTTP 429/temporary gateway responses still use the existing retry/backoff logic.")

    ack = st.checkbox(
        "I confirm every selected configuration is approved for LIVE HIP execution",
        key="parallel_config_ack",
    )
    if st.button(
        "🚀 RUN SELECTED CONFIGURATIONS IN PARALLEL LIVE",
        type="primary",
        width="stretch",
        disabled=not (selected_ids and ack),
        key="parallel_config_run",
    ):
        status = st.status("Launching validated configurations with independent agents...", expanded=True)
        progress = st.progress(0.0)
        message = st.empty()
        finished = 0
        total = len(selected_ids)

        def callback(event: Dict[str, Any]) -> None:
            nonlocal finished
            if event.get("event") == "STARTED":
                message.info(f"Started · {event.get('customer')} · {event.get('flow')}")
            elif event.get("event") == "FINISHED":
                finished += 1
                progress.progress(min(1.0, finished / max(1, total)))
                if event.get("status") == "PASS":
                    message.success(f"Completed {finished}/{total} · {event.get('customer')} · PASS · {event.get('elapsedSeconds', 0)} s")
                else:
                    message.warning(f"Completed {finished}/{total} · {event.get('customer')} · BLOCKED · {event.get('elapsedSeconds', 0)} s")

        try:
            summary = run_parallel_configurations(root, selected_ids, max_workers=int(workers), progress_callback=callback)
            st.session_state["parallel_batch_result"] = summary
            progress.progress(1.0)
            if summary.get("blockedCount"):
                status.update(label="Parallel batch completed with one or more blockers", state="error")
            else:
                status.update(label="Parallel batch completed successfully", state="complete")
        except Exception as exc:
            status.update(label="Parallel batch could not start", state="error")
            st.error(str(exc))

    result = st.session_state.get("parallel_batch_result")
    if isinstance(result, dict):
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Configurations", result.get("configurationCount", 0))
        c2.metric("Parallel agents", result.get("parallelWorkers", 0))
        c3.metric("PASS", result.get("passCount", 0))
        c4.metric("BLOCKED", result.get("blockedCount", 0))
        st.metric("Parallel batch wall-clock time", f"{result.get('elapsedSeconds', 0)} s")

        config_rows = []
        for item in result.get("results") or []:
            config_rows.append({
                "Configuration": item.get("label") or item.get("customer"),
                "Customer": item.get("customer"),
                "Instance": item.get("demoInstance") or "",
                "Status": item.get("status"),
                "Time": f"{item.get('elapsedSeconds', 0)} s",
                "Steps timed": item.get("stepCount", 0),
            })
        if config_rows:
            st.markdown("#### Configuration completion times")
            st.dataframe(config_rows, width="stretch", hide_index=True)

        for item in result.get("results") or []:
            timings = item.get("stepTimings") or []
            if not timings:
                continue
            title = item.get("label") or f"{item.get('customer')} · {item.get('jobId')}"
            with st.expander(f"⏱ Step timing · {title}", expanded=False):
                timing_rows = []
                for event in timings:
                    timing_rows.append({
                        "#": event.get("sequence"),
                        "Step": event.get("label"),
                        "Result": event.get("classification"),
                        "API time": f"{event.get('apiElapsedSeconds', 0)} s",
                        "Wait": f"{event.get('waitSeconds', 0)} s",
                        "Total step time": f"{event.get('totalStepSeconds', 0)} s",
                    })
                st.dataframe(timing_rows, width="stretch", hide_index=True)
        with st.expander("Parallel batch technical summary", expanded=False):
            st.json(result)

    with st.expander("Queue maintenance", expanded=False):
        delete_options = {f"{row.get('customer')} · {row.get('jobId')}": row.get("jobId") for row in rows}
        to_delete = st.selectbox("Remove queued snapshot", [""] + list(delete_options), key="parallel_delete_select")
        if st.button("Remove selected queued configuration", disabled=not bool(to_delete), key="parallel_delete_btn"):
            if delete_queued_configuration(root, delete_options[to_delete]):
                st.success("Queued snapshot removed.")
                st.rerun()
