import json
import zipfile
from pathlib import Path

from input_builder_core import build_from_raw_files
from webapp.backend.app.legacy_adapter import build_configuration


def _approved_legrand():
    return {
        "profile_name": "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB",
        "customer": "LEGRAND_NEDERLAND",
        "tx_standard": "XML",
        "tx_code": "850",
        "tx_name": "PurchaseOrderCollection",
        "direction": "Inbound",
        "flow_type": "translation",
        "requires_data_map": True,
        "objects": {
            "data_map": {
                "map_identifier": "DELLCiPMPROXX10C_LEGRAND_NEDERLAND",
                "map_name": "DELLCiPMPROXX10C",
                "map_data_file": "Transform_DELLCiPMPROXX10C.jar",
            },
            "source_document_type": {
                "name": "XML_POC_850_10_LEGRAND_NEDERLAND_PRM_IB",
                "data_format_type": "XML",
                "document_identifier": {"rows": [{"value": "PurchaseOrderCollection"}]},
            },
            "target_document_type": {
                "name": "XML_PO_10_LEGRAND_NEDERLAND_PO_OB",
                "data_format_type": "XML",
                "document_identifier": {"rows": [{"value": "PurchaseOrder"}]},
            },
            "rule": {
                "name": "DELLCiPMPROXX10C_LEGRAND_NEDERLAND_RULE",
                "conditions": {"rows": [
                    {"attribute_name": "Receiver", "operator": "Equals", "value": "Dell Computer B.V."},
                    {"attribute_name": "Sender", "operator": "Equals", "value": "Legrand Nederland B.V."},
                ]},
            },
            "source_transport_profile": {
                "system_type": "Partner",
                "partner_name": "dce-test-partner",
                "profile_name": "SFTP_LEGRAND_NEDERLAND_PC_SRC_IB",
                "existing_account_name": "haftatap10251594",
                "subscription_folder": "/SFTP_LEGRAND_NEDERLAND_PC_SRC_IB",
            },
            "target_transport_profile": {
                "system_type": "Dell Application",
                "partner_name": "AIC - DCE",
                "profile_name": "SFTP_LEGRAND_NEDERLAND_PC_TGT_OB",
                "existing_account_name": "haftatap10251593",
                "subscription_folder": "/SFTP_LEGRAND_NEDERLAND_PC_TGT_OB",
            },
            "biz_flow": {
                "flow_details": {"business_flow_name": "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"},
                "flow_identifiers": {"conditions": [
                    {"attribute_name": "Receiver", "operator": "Equals", "value": "Dell Computer B.V."},
                    {"attribute_name": "Sender", "operator": "Equals", "value": "Legrand Nederland B.V."},
                ]},
                "configure_source": {"source_system_name": "dce-test-partner"},
                "configure_targets": {"target_system_name": "AIC - DCE"},
            },
        },
    }


def test_approved_json_is_auto_detected_without_input_json_filename(tmp_path: Path):
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    (uploads / "LEGRAND_NEDERLAND_dev_approved.json").write_text(
        json.dumps(_approved_legrand()), encoding="utf-8"
    )

    # Deliberately use conflicting fresh-card defaults. The approved file must win.
    result = build_configuration(
        tmp_path,
        {
            "input_mode": "files",
            "direction": "Outbound",
            "transaction_code": "999",
            "source_interface": "SFTP",
            "target_interface": "SFTP",
        },
        use_dell_aia=False,
    )
    data = result["input"]
    assert result["authoritative_json"] == "LEGRAND_NEDERLAND_dev_approved.json"
    assert data["direction"] == "Inbound"
    assert data["tx_code"] == "850"
    assert data["partner_identifier_value"] == "12345666"
    assert data["objects"]["source_transport_profile"]["existing_account_name"] == "haftatap10251594"
    assert data["objects"]["target_transport_profile"]["existing_account_name"] == "haftatap10251593"
    assert result["questions"] == []


def test_customer_map_artifacts_populate_map_metadata_and_evidence(tmp_path: Path):
    xbm = tmp_path / "DELLCiPMPROXX10C.xbm"
    xbm.write_text(
        '<transformMap logicalName="DELLCiPMPROXX10C" analystVersionLastSaved="6.7.2">'
        '<sources><schemaRoot logicalName="PurchaseOrderCollection"/></sources>'
        '<targets><schemaRoot logicalName="PurchaseOrder"/></targets>'
        '</transformMap>',
        encoding="utf-8",
    )
    jar = tmp_path / "Transform_DELLCiPMPROXX10C.jar"
    with zipfile.ZipFile(jar, "w") as zf:
        zf.writestr("com/dell/Transform_DELLCiPMPROXX10C.class", b"fixture")
    src = tmp_path / "SRC_order.xml"
    src.write_text("<PurchaseOrderCollection/>", encoding="utf-8")
    tgt = tmp_path / "TGT_order.xml"
    tgt.write_text("<PurchaseOrder/>", encoding="utf-8")

    data = build_from_raw_files(
        [xbm, jar, src, tgt],
        customer="LEGRAND_NEDERLAND",
        direction="Inbound",
        flow_type="translation",
        use_dell_aia=False,
    )
    mapping = data["objects"]["data_map"]
    assert mapping["map_name"] == "DELLCiPMPROXX10C"
    assert mapping["map_class"] == "Transform_DELLCiPMPROXX10C"
    assert mapping["map_data_file"] == "Transform_DELLCiPMPROXX10C.jar"
    assert mapping["contivo_version"] == "6.7.2"

    paths = {row.get("path") for row in data.get("_file_mapping", {}).get("fieldMappings", [])}
    assert "objects.data_map.map_name" in paths
    assert "objects.data_map.map_class" in paths
    assert "objects.data_map.map_data_file" in paths
    assert "objects.data_map.contivo_version" in paths
