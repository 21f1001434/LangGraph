# Agentic HIP API Configuration Agent — Phase 5 (V37)

Phase 5 makes the Bun/React + FastAPI Studio easier to reuse across customers and safer to operate as a persistent team workspace.

## Configuration Library
The React sidebar now includes **Configuration Library**. Users can:
- switch the active customer configuration without rebuilding it;
- clone a configuration as a new isolated workspace;
- export a portable Agentic HIP configuration bundle;
- import a bundle on another machine;
- delete local workspaces explicitly.

Clones and imports deliberately do **not** inherit old agent-validation PASS state. They must be revalidated before LIVE execution.

## Portable configuration bundles
Configuration exports contain the canonical `input.json` plus customer evidence under `input_files/` and uploaded artifacts under `uploads/`.

Each exported member is listed in `bundle_manifest.json` with a SHA-256 digest. Import verifies every member before extraction and rejects traversal paths, unsupported bundle formats, excessive file counts, oversized files, missing members, and checksum mismatches.

Runtime secrets, OAuth tokens, runtime approvals, reports, validation cache, `.env`, and execution state are not exported in the portable configuration bundle.

## Tamper-evident local audit ledger
Mutating FastAPI operations are written to a local append-only JSONL audit ledger. Each event includes:
- timestamp;
- browser/operator attribution from `X-HIP-Actor`;
- action and entity;
- previous event hash;
- current event SHA-256 hash.

The Configuration Library displays recent actions and verifies the full hash chain. Common secret/token/password fields are redacted before audit persistence.

Operator attribution is evidence metadata, **not an authentication system**.

## Template lifecycle and version history
Custom API Flow templates now support:
- **DRAFT** — editable working version;
- **PUBLISHED** — reviewed reusable flow;
- **ARCHIVED** — retired flow retained for history;
- clone from built-in or custom template;
- persistent version history.

Editing/saving a custom template creates a new DRAFT version. Publishing is explicit.

## Execution evidence bundles
Operations can download a compact evidence ZIP for a selected React graph execution containing the redacted execution record, configuration summary, report index, and an evidence manifest with SHA-256 digests.

## Production React launch
Development launch remains:

```bat
RUN_AGENTIC_HIP.bat
```

Phase 5 also adds:

```bat
RUN_AGENTIC_HIP_PRODUCTION.bat
```

This builds the Bun/Vite React frontend and starts FastAPI with the compiled frontend served from the same `127.0.0.1:8765` process. The standard setup script must be run first.

## Safety preserved
- LIVE-only execution remains enforced.
- `hip-automation` remains mandatory.
- Translation/Passthrough applicability rules are unchanged.
- imported/cloned configurations require agent revalidation;
- manual approval, stop/resume, graph preflight, runtime mappings, parallel execution, Learn and reports from earlier phases remain available.
- Streamlit is retained only as a compatibility/reference fallback until Phase 6.
