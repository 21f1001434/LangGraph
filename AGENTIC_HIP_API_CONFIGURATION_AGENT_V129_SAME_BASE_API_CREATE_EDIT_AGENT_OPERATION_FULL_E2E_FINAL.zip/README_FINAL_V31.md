# HIP Application Studio V31

V31 adds visible per-step timing and a U-HAUL multi-instance parallel demonstration on top of the V30 parallel-agent and low-latency backend.

## Step timing
Every logical live step records:
- start timestamp
- finish timestamp
- API elapsed milliseconds/seconds
- configured wait-after time
- actual wait time
- total step wall-clock time

The timing is written to `reports/execution_timing_latest.json`, shown in the full Application Studio API-by-API results, shown for a selected API in API Testing Area, and shown per configuration/per step in **Parallel Configurations**.

## Parallel execution in Application Studio
The Home screen includes **⚡ Parallel LIVE** and the sidebar contains **⚡ Parallel Configurations**. Validated configurations can be queued and executed concurrently with bounded workers. Parallelism is across configurations; the API dependency order inside one configuration remains protected.

## U-HAUL multi-instance demo
When the active configuration is a validated U-HAUL configuration, the Parallel workspace can create 2–8 isolated queue instances from the exact same validated snapshot. Those instances can be selected and executed concurrently to demonstrate the parallel capability. The demo does not rename HIP objects; therefore existing-object responses are expected to be interpreted as PASS / EXISTING when the objects already exist.

Use the demo only when repeated LIVE calls to the approved U-HAUL baseline are acceptable in the target environment.

## Validation
- pytest: 93 passed
- standard validator: 57/57 PASS
- adaptive validator: 60/60 PASS
- final self-check: 40 required checks PASS / 0 failed

All Run/Test/Launch paths remain LIVE-only.
