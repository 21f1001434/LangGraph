from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List

KNOWLEDGE_FILE = "input_builder_mapping_knowledge.json"


def _tokens(filename: str) -> List[str]:
    stem = Path(str(filename or "")).stem.upper()
    raw = [x for x in re.split(r"[^A-Z0-9]+", stem) if x]
    # Do not learn numeric/customer-specific-looking tokens as generic role rules.
    generic = []
    for tok in raw:
        if tok.isdigit() or len(tok) <= 1:
            continue
        if tok in {"XML", "EDI", "X12", "JSON", "CSV", "JAR", "XBM"}:
            continue
        generic.append(tok)
    return generic


def load_mapping_knowledge(root: Path) -> Dict[str, Any]:
    path = Path(root) / KNOWLEDGE_FILE
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        raw = {}
    if not isinstance(raw, dict):
        raw = {}
    raw.setdefault("version", 1)
    raw.setdefault("examples", [])
    raw.setdefault("role_token_counts", {"source": {}, "target": {}})
    raw.setdefault("field_rule_counts", {})
    raw.setdefault("format_counts", {"source": {}, "target": {}})
    raw["role_tokens"] = _effective_role_tokens(raw)
    return raw


def _effective_role_tokens(data: Dict[str, Any]) -> Dict[str, List[str]]:
    counts = data.get("role_token_counts") or {}
    out: Dict[str, List[str]] = {"source_tokens": [], "target_tokens": []}
    for side, key in (("source", "source_tokens"), ("target", "target_tokens")):
        side_counts = counts.get(side) or {}
        # A token becomes a learned hint after it has appeared as that role at
        # least twice, or after one example when it is a canonical role marker.
        canonical = {"SRC", "SOURCE"} if side == "source" else {"TGT", "TARGET", "OUTPUT"}
        out[key] = sorted(tok for tok, n in side_counts.items() if int(n or 0) >= 2 or tok in canonical)
    return out


def _safe_example_id(customer: str, manifest: List[str], source_file: str, target_file: str) -> str:
    raw = "|".join([str(customer or ""), *sorted(str(x) for x in manifest), source_file, target_file])
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:16]


def record_mapping_example(root: Path, canonical: Dict[str, Any], manifest: List[str], *, source_kind: str = "reference_input_json") -> Dict[str, Any]:
    """Learn reusable file→input.json mapping structure from a validated pair.

    Only role tokens, field/extractor counts and format counts are persisted. Raw
    payload contents, OAuth data, DUNS, certificates and other business secrets
    are deliberately not stored in the mapping knowledge file.
    """
    root = Path(root)
    data = load_mapping_knowledge(root)
    fm = canonical.get("_file_mapping") if isinstance(canonical, dict) else None
    if not isinstance(fm, dict):
        return data
    src = fm.get("source") if isinstance(fm.get("source"), dict) else {}
    tgt = fm.get("target") if isinstance(fm.get("target"), dict) else {}
    src_file = str(src.get("filename") or "")
    tgt_file = str(tgt.get("filename") or "")
    ex_id = _safe_example_id(str(canonical.get("customer") or ""), manifest, src_file, tgt_file)
    if any(str(x.get("id")) == ex_id for x in data.get("examples") or [] if isinstance(x, dict)):
        data["role_tokens"] = _effective_role_tokens(data)
        return data

    example = {
        "id": ex_id,
        "customer": str(canonical.get("customer") or ""),
        "source_kind": source_kind,
        "source_file": src_file,
        "target_file": tgt_file,
        "source_format": str(src.get("data_format_type") or ""),
        "target_format": str(tgt.get("data_format_type") or ""),
        "file_count": len(manifest or []),
        "mapped_fields": len(fm.get("fieldMappings") or []),
    }
    data.setdefault("examples", []).append(example)

    counts = data.setdefault("role_token_counts", {"source": {}, "target": {}})
    for side, filename in (("source", src_file), ("target", tgt_file)):
        for tok in _tokens(filename):
            side_map = counts.setdefault(side, {})
            side_map[tok] = int(side_map.get(tok, 0) or 0) + 1

    formats = data.setdefault("format_counts", {"source": {}, "target": {}})
    for side, fmt in (("source", example["source_format"]), ("target", example["target_format"])):
        if fmt:
            formats.setdefault(side, {})[fmt] = int(formats.setdefault(side, {}).get(fmt, 0) or 0) + 1

    field_counts = data.setdefault("field_rule_counts", {})
    for row in fm.get("fieldMappings") or []:
        if not isinstance(row, dict):
            continue
        path = str(row.get("path") or "")
        rule = str(row.get("rule") or "")
        if not path or not rule:
            continue
        key = f"{path}|{rule}"
        field_counts[key] = int(field_counts.get(key, 0) or 0) + 1

    data["role_tokens"] = _effective_role_tokens(data)
    path = root / KNOWLEDGE_FILE
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return deepcopy(data)


def mapping_learning_summary(data: Dict[str, Any]) -> Dict[str, Any]:
    data = data or {}
    return {
        "example_count": len(data.get("examples") or []),
        "source_tokens": list((data.get("role_tokens") or {}).get("source_tokens") or []),
        "target_tokens": list((data.get("role_tokens") or {}).get("target_tokens") or []),
        "source_formats": deepcopy((data.get("format_counts") or {}).get("source") or {}),
        "target_formats": deepcopy((data.get("format_counts") or {}).get("target") or {}),
        "field_rule_count": len(data.get("field_rule_counts") or {}),
    }


def clear_mapping_knowledge(root: Path) -> None:
    path = Path(root) / KNOWLEDGE_FILE
    if path.exists():
        path.unlink()
