# V64 — Fresh Intake, Cross-Surface Payload Consistency, Live Result and Report Reconciliation

V64 fixes the production consistency issues observed after V63 when a new customer file was ingested and when the same persisted API payload behaved differently in API Testing Area, API Flow Game and Execute.

## Fixed

- **Fresh customer intake is isolated**: uploading new customer evidence after an existing configuration has already been built creates a fresh workspace instead of merging with stale source/target/XBM/JAR evidence.
- The Build Configuration UI clears stale File Truth/validation as soon as new evidence is selected and refreshes from the newly built configuration after ingest.
- Active configuration state now reacts to backend `updated_at` changes so persisted edits refresh correctly.
- **API Testing payload persistence is global**: Save/Clear payload override refreshes the application active configuration. Flow Game and Execute use the same persisted `payload_overrides.json`.
- **Flow Game runtime mappings are fallback-safe**: if an upstream EXISTING/reused response does not echo an ID, a correct concrete value already present in the validated effective request is preserved instead of blocking the graph.
- EXISTING/reused states are dependency-compatible and do not stop downstream LIVE execution.
- Generic, customer and combined reports use the same response reconciliation logic. An early create/resolve response is downgraded from FAIL to WARNING/EXISTING_REUSED when later dependent LIVE success proves the object was reusable.
- **LIVE RESULT metrics** use full-width readable labels and responsive cards; labels no longer collapse vertically.
- LIVE result/report surfaces use high-contrast glass panels so status text cannot disappear into red/amber backgrounds.
- Human duration formatting remains seconds → minutes → hours.
- WorkType behavior from V60 is preserved: omit `workType` by default; null is accepted; populated workType objects are stripped.

## Safety

Queue snapshots remain immutable after validation. A persisted payload/configuration change must be revalidated/re-queued before LIVE execution; V64 does not silently mutate a running queued snapshot.

## Validation

- `pytest`: 235 passed
- Phase 1–6 checks: PASS
- Final release validation: 16/16 PASS
- Package validation: 57/57 PASS
- Adaptive validation: 60/60 PASS
- Required final self-checks: 43/43 PASS
- Python source compilation: PASS

No mutating HIP LIVE API calls were executed during release validation.
