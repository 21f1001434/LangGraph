import json
from pathlib import Path

import webapp.backend.app.main as main_module
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.storage import JsonStore

ROOT = Path(__file__).resolve().parent


def _validation_ok():
    return {"ok": True, "requests": {"ok": True, "validCount": 18, "total": 18, "items": []}}


def test_v79_uhal_is_materialized_as_first_class_configuration(monkeypatch, tmp_path):
    store = JsonStore(tmp_path / "runtime")
    monkeypatch.setattr(main_module, "STORE", store)
    monkeypatch.setattr(main_module, "PARALLEL", ParallelManager(store))
    monkeypatch.setattr(main_module, "validate_configuration", lambda _path: _validation_ok())

    rows = main_module.list_configurations()
    assert rows
    assert rows[0].get("managed_reference_source") == "reference:uhal"
    assert "U-HAUL" in f"{rows[0].get('customer')} {rows[0].get('name')}".upper()
    assert (Path(rows[0]["workspace"]) / "input.json").exists()


def test_v79_stale_blocked_uhal_is_migrated_back_to_dev_approved(monkeypatch, tmp_path):
    store = JsonStore(tmp_path / "runtime")
    monkeypatch.setattr(main_module, "STORE", store)
    monkeypatch.setattr(main_module, "PARALLEL", ParallelManager(store))

    created = store.create_configuration({
        "name": "U-HAUL Outbound 856 Translation",
        "customer": "U-HAUL",
        "direction": "Outbound",
        "transaction_code": "856",
        "flow_type": "Translation",
    })
    workspace = Path(created["workspace"])
    reference = json.loads((main_module.LEGACY_ROOT / "input.json").read_text(encoding="utf-8"))
    (workspace / "input.json").write_text(json.dumps(reference), encoding="utf-8")
    store.update_configuration(created["id"], {
        "managed_reference_source": "reference:uhal",
        "flow_source_id": "reference:uhal",
        "questions": [{"id":"old_blocker", "question":"obsolete", "informational":False}],
        "status": "NEEDS_INPUT",
        "validation": {"ok": False},
    })

    rows = main_module.parallel_sources()
    uhal = next(row for row in rows if row.get("sourceId") == "reference:uhal")
    assert uhal["configurationId"] == created["id"]
    assert uhal["repairConfigurationId"] == ""
    assert uhal["validated"] is True
    assert uhal["status"] == "DEV_APPROVED"
    assert uhal["approvalStatus"] == "DEV_APPROVED"
    assert uhal["validCount"] == uhal["totalContracts"] == 18
    assert uhal["blockerCount"] == 0
    assert uhal["questions"] == []
    repaired = store.get_configuration(created["id"])
    assert repaired["status"] == "DEV_APPROVED"
    assert repaired["questions"] == []
    assert repaired["validation"]["ok"] is True


def test_v79_frontend_has_guided_fix_modal_and_no_react_branding_on_home():
    dashboard = (ROOT / "webapp/frontend/src/pages/DashboardPage.tsx").read_text(encoding="utf-8")
    parallel = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    flow = (ROOT / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    modal = (ROOT / "webapp/frontend/src/components/ConfigurationFixModal.tsx").read_text(encoding="utf-8")
    app = (ROOT / "webapp/frontend/src/App.tsx").read_text(encoding="utf-8")
    workspace = (ROOT / "webapp/frontend/src/pages/WorkspacePage.tsx").read_text(encoding="utf-8")
    builder = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    operations = (ROOT / "webapp/frontend/src/pages/OperationsPage.tsx").read_text(encoding="utf-8")
    index = (ROOT / "webapp/frontend/index.html").read_text(encoding="utf-8")

    assert "HIP API Agent Studio" in dashboard
    assert "React-native" not in dashboard
    assert ">REACT<" not in dashboard
    assert "DEV APPROVED · TEST READY" in parallel
    assert "Fix now" in parallel and "ConfigurationFixModal" in parallel
    assert "DEV APPROVED · TEST READY" in flow and "Fix configuration" in flow and "ConfigurationFixModal" in flow
    assert "CUSTOMER FILE" in modal and "USER SELECTION" in modal and "ANOTHER VALUE" in modal
    assert "Save decision & check automatically" in modal
    assert "localStorage.removeItem('hip.activeConfigurationId')" in app
    assert "openUhal" in app and "Test approved U-HAUL" in dashboard
    assert "ConfigurationFixModal" in workspace and "Fix now" in workspace
    assert "Create from U-HAUL" in builder and "setSelectedFields(new Set())" in builder
    assert "No React graph executions yet." not in operations
    assert "<title>HIP API Agent Studio</title>" in index
