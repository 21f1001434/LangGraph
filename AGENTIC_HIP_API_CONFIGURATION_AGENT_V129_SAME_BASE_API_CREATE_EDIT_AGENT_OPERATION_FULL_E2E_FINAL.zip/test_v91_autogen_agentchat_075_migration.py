from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

import webapp.backend.app.autogen_runtime as runtime

ROOT = Path(__file__).resolve().parent


def test_v91_requirements_pin_microsoft_agentchat_075_and_remove_legacy_pyautogen():
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    active = "\n".join(line for line in requirements.splitlines() if not line.lstrip().startswith("#"))
    assert "autogen-agentchat==0.7.5" in requirements
    assert "autogen-core==0.7.5" in requirements
    assert "autogen-ext[openai]==0.7.5" in requirements
    assert "pyautogen" not in active


def test_v91_dell_aia_model_client_is_openai_compatible_and_tool_capable(monkeypatch):
    captured = {}

    class FakeClient:
        def __init__(self, **kwargs):
            captured.update(kwargs)

    monkeypatch.setattr(runtime, "_get_dell_aia_token", lambda: "unit-test-token")
    monkeypatch.setenv("DELL_AIA_BASE_URL", "https://aia.gateway.dell.com/genai/dev/v1")
    monkeypatch.setenv("DELL_AIA_MODEL", "gpt-oss-120b")
    monkeypatch.setenv("AIA_CHAT_PATH", "/chat/completions")
    runtime._build_model_client(FakeClient)
    assert captured["base_url"].endswith("/genai/dev/v1")
    assert captured["api_key"] == "unit-test-token"
    assert captured["model"] == "gpt-oss-120b"
    assert captured["model_info"]["function_calling"] is True
    assert captured["parallel_tool_calls"] is False
    assert captured["include_name_in_message"] is False


def test_v91_agentchat_stop_cancels_model_phase(monkeypatch):
    class FakeCancellationToken:
        def __init__(self): self.cancelled = False
        def cancel(self): self.cancelled = True

    class FakeModelClient:
        async def close(self): return None

    class SlowAssistantAgent:
        def __init__(self, **kwargs): pass
        async def run(self, *, task=None, cancellation_token=None, **kwargs):
            while not cancellation_token.cancelled:
                await asyncio.sleep(0.01)
            raise asyncio.CancelledError()

    monkeypatch.setattr(runtime, "_load_agentchat", lambda: (SlowAssistantAgent, FakeModelClient, FakeCancellationToken))
    monkeypatch.setattr(runtime, "_build_model_client", lambda cls: FakeModelClient())
    ticks = {"n": 0}
    def should_cancel():
        ticks["n"] += 1
        return ticks["n"] >= 2
    with pytest.raises(runtime.AutoGenCancelled):
        runtime.run_with_autogen_agent(
            agent_name="cancel_test",
            task={"jobId": "cancel-1"},
            executor=lambda: {"status": "PASS"},
            cancel_check=should_cancel,
        )


def test_v91_frontend_and_status_report_agentchat_075():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    assert "AutoGen AgentChat 0.7.5" in page
    assert '"agentFramework": "Microsoft AutoGen AgentChat"' in main
    assert '"autoGenVersionRequired": "0.7.5"' in main
    assert 'find_spec("autogen_agentchat")' in main


def test_v91_scheduler_keeps_four_agent_ceiling_and_fifth_429_evidence():
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert 'HIP_AUTOGEN_MAX_STABLE_AGENTS' in manager
    assert 'AUTOGEN_KNOWN_UNSTABLE_AT = 5' in manager
    assert 'knownUnstableReason": "HTTP 429"' in manager
    assert 'AssistantAgent' in manager
