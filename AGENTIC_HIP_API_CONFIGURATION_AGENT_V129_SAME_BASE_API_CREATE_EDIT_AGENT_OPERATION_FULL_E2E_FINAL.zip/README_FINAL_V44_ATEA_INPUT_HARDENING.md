# V44 - ATEA Passthrough Reference + Input Creation Hardening

This release builds on V43 and adds regression coverage from the `ATEA_NORWAY_dev_approved.json` reference screenshots.

## ATEA passthrough behavior hardened

- Preserves **Inbound / XML / 850 / Purchase Order** from approved JSON.
- Treats `requires_data_map: false` and `flow_type: passthrough` as the authoritative applicability contract.
- Keeps Data Map empty for passthrough and does not ask for mapping metadata.
- Keeps the separate Target Document Type empty by default; the target transport reuses the Source Document Type.
- Keeps Mapping Rule as `NA` and does not create a Mapping Transformer step.
- Preserves Flow routing conditions/actions (`Receiver`, `Sender`, `Route Document`) independently of Mapping Rule applicability.
- Resolves the external partner identifier from the direction-aware routing identity (`Sender` for Inbound, `Receiver` for Outbound) when already present.

## General input creation hardening

- Canonical/approved HIP JSON is now detected by **schema inside ZIPs** in the core builder, not only in the React adapter.
- JSON filenames are not relied on; `*_dev_approved.json`, `input.json`, and structurally equivalent files are supported.
- Wrapped canonical JSON (`input`, `configuration`, or `config`) is recognized.
- List-shaped HIP sections are recognized so multi-source/multi-target approved inputs are not misclassified as customer payload JSON.
- Approved transport `interface_type` now wins over fresh-card UI defaults. A default SFTP selection cannot silently rewrite an approved FTP/HTTPS/HTTPS-AS2 configuration.
- Interface application is list-safe and no longer collapses multi-branch Transport Profile / Biz Flow sections to one dict.
- Follow-up answer handling resolves the interface from the built input.json rather than reverting to stale UI defaults.

## 18-API passthrough applicability

The ATEA regression still produces the complete 18-slot API plan. For a normal passthrough flow, these mapping-only slots are **Not Applicable**, not blocked:

- Target Document Type
- Data Map
- Mapping Rule

The remaining 15 steps stay applicable. Mapper validation reports zero errors for the ATEA reference fixture.

## Verification

- New ATEA hardening tests: **6/6 passed**.
- Complete packaged Python regression suite: **159/159 passed**.
- Python compile-all: passed.
