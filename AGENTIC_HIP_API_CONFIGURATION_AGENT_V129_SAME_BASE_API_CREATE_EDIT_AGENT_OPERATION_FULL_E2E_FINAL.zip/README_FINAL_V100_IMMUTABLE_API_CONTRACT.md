# V100 — Immutable API Contract + hip-automation Defaults

## Final policy

V100 retains the strict whole-pipeline LIVE execution and evidence model, but locks the developer-approved 18-API request contracts against ad-hoc mutation.

### Deployment group

The canonical default is `hip-automation`. Known spellings such as `deployment_group`, `deployment-group`, `deploymentGroup`, and `deploymentGroupName` are normalized to `hip-automation` when they occur in input/config/request structures. No additional payload attribute is invented merely to carry the default.

### MAP

For the approved U-HAUL configuration the MAC Map is already present. HIP responses such as `Map identifier should be unique in an Environment` are classified as `PASS / EXISTING`; the configured/live map ID is reused for downstream Rule/Flow dependencies. V100 adds no map update/edit API.

### No API request mutation

- API Testing payload editors are removed.
- Flow Game payload editors are removed.
- Payload override save endpoints return HTTP 409.
- Historical `payload_overrides.json` files may remain for audit/backward compatibility, but the runtime never applies them.
- Per-node `request_override` values are removed/sanitized by backend flow preflight/LIVE execution and rejected by direct request generation.
- Customer business values come from canonical Build Configuration/input and approved runtime dependency outputs only.
- Canonical schema/attributes, methods, URLs, OAuth profile selection, and protected headers are not mutable by the agent.

This does **not** convert the configured whole pipeline into a read-only validation workflow: approved POST/deploy calls still execute when the selected LIVE pipeline requires them. The restriction is against mutation of the approved API contract/request definition.

### Startup

V98 OneDrive/Uvicorn stability fixes remain active: normal startup does not run repository-wide WatchFiles reload.

### Validation

Run `python -m pytest -q`, `python FINAL_RELEASE_VALIDATION.py`, `python validate_package.py`, and `python final_self_check.py`.
