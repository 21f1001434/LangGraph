# Production Readiness Guide

## Mandatory preflight

```powershell
python run_agent.py --preflight
```

A live run will not start when preflight fails.

## TLS

TLS verification is enabled by default:

```env
HIP_VERIFY_SSL=true
```

When Dell's internal CA is not in the Windows trust store:

```env
HIP_CA_BUNDLE=C:\certificates\dell-corporate-ca.pem
```

Do not disable TLS verification in production.

## Production execution controls

For a real PROD environment:

```env
HIP_ENVIRONMENT=PROD
PRODUCTION_EXECUTION_CONFIRMATION=YES
CHANGE_TICKET=CHG0123456
```

## Safety controls added

- Exclusive live-run lock to prevent concurrent duplicate creation.
- Credential, endpoint, XML, JAR, work-type, mapping and MCP preflight checks.
- Stale configured IDs are rejected for non-U-HAUL input.
- Semantic orchestration-response validation.
- Flow deployment history must contain a successful deployment state.
- Token diagnostics and report evidence are redacted.
- Final state is written atomically.
- Offline full-chain integration test validates dynamic ID propagation.

## Promotion rule

Complete a successful DEV/SIT run with the intended production subscription
before promotion. Retain:

- `reports/production_preflight_latest.json`
- `reports/uhal_end_to_end_status_latest.json`
- the untruncated HTML report
- Flow deployment history
- Source and Target TP audit history
