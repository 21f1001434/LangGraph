# OAuth Postman Parity Fix

## Root cause found in the previous package

The previous Python token client defaulted to `HIP_TOKEN_NETWORK_MODE=direct` and set `requests.Session().trust_env = False`. That explicitly bypassed Windows/environment proxy settings. Postman can use those machine proxy settings automatically even when the user did not manually configure any routing in the request.

The previous Streamlit `save_env()` also refused to overwrite an existing non-empty value with a blank value. Therefore, choosing a blank HIP scope in the UI could leave an old scope in `.env`, while the working Postman request sent no scope.

Both behaviors are removed.

## Current token request

- OAuth 2.0 Client Credentials
- Access Token URL exactly as entered
- Client Authentication: Basic Auth header
- `grant_type=client_credentials`
- scope omitted when blank
- `requests.Session().trust_env=True` (normal Windows/environment network settings)
- redirects enabled
- no manual bearer token
- no token cookie
- no JSON credential format
- no separate MAC Map OAuth credential

## Build marker

The Streamlit header and connection report show:

`2026-08-07-postman-native-oauth-v1`

If that build marker is not visible, an older extracted application is still running.
