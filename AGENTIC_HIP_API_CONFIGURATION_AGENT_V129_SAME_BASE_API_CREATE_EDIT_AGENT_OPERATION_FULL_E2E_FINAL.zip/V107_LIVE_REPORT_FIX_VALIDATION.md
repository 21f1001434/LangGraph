# V107 LIVE Report Fix Validation

## Issues from the 2026-08-29 16:34 report

### 1. Account/System upstream PCF route unavailable
- Classification remains `API_UPSTREAM_ROUTE_UNAVAILABLE` because the Dell gateway is reachable but its configured upstream PCF route is absent.
- This is external API/platform ownership; V107 does not falsify success or mutate the approved Account/System payload.
- Replacement endpoints remain configurable with `HIP_ACCOUNT_API_URL`, `HIP_PARTNER_API_URL`, and `HIP_SYSTEM_API_URL`.
- V107 removes these name-addressed foundation creates from the hard TP dependency gate. TP orchestration can now independently attempt the known `systemName`, Partner name, `Existing Account Name`, and `deploymentGroupName`.

### 2. Partner blocked only because Account create route failed
- Fixed. Partner Create is no longer hard-blocked by Account Create because the approved Partner request uses `x-account-name`, not an Account numeric ID returned by the create call.
- Partner API is still called and its own response is reported truthfully.

### 3. Source/Target TP blocked by Account/System/Partner route failures
- Fixed as a runner dependency defect.
- Source TP hard dependency is now Source Document Type.
- Target TP hard dependency is now Target Document Type.
- Account/System/Partner names remain in the approved TP payload; if they truly do not exist, the TP API can return the specific business error itself.

### 4. Mapping Rule ORA-02291 / FK_MAC_RULE_FLOW_DEF
- Root cause in V106: `flowDefinitionId` was hardcoded to `0`.
- Fixed without changing the API attribute set. V107 retains `flowDefinitionId` but resolves a positive value in this order:
  1. live-observed `flowDefinitionId`;
  2. explicit config `rule_flow_definition_id` / `flowDefinitionId`;
  3. `HIP_RULE_FLOW_DEFINITION_ID`;
  4. the approved Flow `flowTemplateId` (package default `1`).
- The effective packaged U-HAUL Mapping Rule preview now has `flowDefinitionId: 1`, never `0`.
- `documentTypeId` remains omitted and Map remains referenced by `mapIdentifier` + `mapVersion`.

### 5. Same permanent Mapping Rule failure repeated #12/#19/#20/#21
- Fixed. `FK_MAC_RULE_FLOW_DEF` is deterministic `API_BACKEND_CONTRACT_MISMATCH` evidence and is terminal/non-retriable for live auto-completion.
- If HIP rejects the corrected positive reference, V107 reports the backend/contract issue once instead of blindly repeating it.

### 6. Flow/Audit cascade
- Corrected indirectly: Flow create/deploy still requires Rule and TP audit success; no success is fabricated.
- Because foundation route errors no longer suppress TP attempts and Rule no longer sends `flowDefinitionId=0`, the old application-generated cascade is removed.
- TP audit still waits for a successful corresponding TP create. Flow create still waits for Rule + both TP audits, preserving dependency safety.

## Validation
- Targeted V107/V106 regression: 13/13 PASS
- Application tests: 366/366 PASS
- Backend tests: 48/48 PASS
- Combined Python tests: 414/414 PASS
- Package validation: 58/58 PASS
- Adaptive package validation: 60/60 PASS
- Business readiness: 69/69 PASS
- Final release: 16/16 PASS
- Final self-check: 45/45 PASS
- Phase 1-6 validators: PASS

No credentialed LIVE Dell/HIP mutation was executed while producing this package.
