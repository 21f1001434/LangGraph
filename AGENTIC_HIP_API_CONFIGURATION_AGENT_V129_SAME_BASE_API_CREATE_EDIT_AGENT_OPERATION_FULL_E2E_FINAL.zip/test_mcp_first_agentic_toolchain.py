from __future__ import annotations

import json
from pathlib import Path

from mcp_bridge import MCPBridge, MCP_TOOL_NAMES

ROOT = Path(__file__).resolve().parent


def load_json(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def main() -> None:
    bridge = MCPBridge(ROOT, enabled=True, required=False)
    input_data = load_json("input.json")
    config = load_json("config_overrides.json")

    status = bridge.status()
    assert status["active"] is True
    assert status["toolCount"] == 18, status
    assert set(status["toolNames"]) == set(MCP_TOOL_NAMES)
    assert status.get("tracePath"), status

    interfaces = bridge.list_interface_profiles()
    keys = set(interfaces.get("keys") or [])
    assert {"SFTP", "FTP", "HTTPS", "HTTPS-AS2"}.issubset(keys), interfaces

    # Existing U-HAUL SFTP baseline should be plan-able without inventing fields.
    sftp_plan = bridge.plan_interface_configuration(
        baseline_input=input_data,
        source_interface="SFTP",
        target_interface="SFTP",
    )
    assert sftp_plan.get("critic", {}).get("status") == "PASS", sftp_plan
    assert sftp_plan.get("executionStrategy", {}).get("strategy") == "SAFE_VALIDATION"

    # HTTPS receiver must ask for Partner-owned values rather than guessing them.
    https_plan = bridge.plan_interface_configuration(
        baseline_input=input_data,
        source_interface="SFTP",
        target_interface="HTTPS",
        target_parameters={},
    )
    questions = json.dumps(https_plan.get("questions") or [])
    for expected in [
        "Partner URL",
        "Receiver Grant Type",
        "Receiver Token Endpoint",
        "Receiver Client Id",
        "Receiver Client Secret",
    ]:
        assert expected in questions, (expected, questions)
    assert https_plan.get("critic", {}).get("status") == "BLOCKED"

    policy = bridge.validate_execution_policy()
    assert policy.get("valid") is True, policy

    readiness = bridge.assess_execution_readiness(input_data, config)
    assert readiness.get("valid") is True, readiness

    # Raw secret values are prohibited in saved overrides, but a secure
    # runtime-payload placeholder is allowed because the live payload still
    # contains the actual Partner value at execution time.
    raw_secret = bridge.validate_payload_override(
        "target_tp",
        {
            "transportProfileDetails": [
                {"interfaceDetails": [{"interfaceType": "HTTPS", "parameters": {}}]}
            ]
        },
        {
            "transportProfileDetails": [
                {
                    "interfaceDetails": [
                        {
                            "interfaceType": "HTTPS",
                            "parameters": {"Receiver Client Secret": "SHOULD_NOT_BE_STORED"},
                        }
                    ]
                }
            ]
        },
        interface_only=True,
    )
    assert raw_secret.get("valid") is False, raw_secret
    assert raw_secret.get("secretViolations"), raw_secret

    safe_runtime_ref = bridge.validate_payload_override(
        "target_tp",
        {
            "transportProfileDetails": [
                {"interfaceDetails": [{"interfaceType": "SFTP HAFT", "parameters": {}}]}
            ]
        },
        {
            "transportProfileDetails": [
                {
                    "interfaceDetails": [
                        {
                            "interfaceType": "HTTPS",
                            "parameters": {
                                "Receiver Client Secret": "{{runtime_payload.target.receiver_client_secret}}"
                            },
                        }
                    ]
                }
            ]
        },
        interface_only=True,
    )
    assert safe_runtime_ref.get("valid") is True, safe_runtime_ref

    # HTTP 200 is not success if the body says success=false.
    semantic_failure = bridge.interpret_api_response(
        "flow_create",
        200,
        {"success": False, "errorMessage": "backend rejected"},
    )
    assert semantic_failure.get("businessSuccess") is False, semantic_failure
    assert semantic_failure.get("classification") == "HTTP_SUCCESS_BUT_BUSINESS_ERROR"

    # Deployment history needs a successful state.
    deployment = bridge.interpret_api_response(
        "flow_deploy_history",
        200,
        [{"deploymentStatus": "DEPLOYED", "flowId": 400517}],
    )
    assert deployment.get("businessSuccess") is True, deployment
    assert deployment.get("extracted", {}).get("flowId") == 400517

    contract = bridge.get_api_contract_summary("tp_validate")
    assert contract.get("contract", {}).get("method") == "POST", contract

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "mcpToolCount": status["toolCount"],
        "protocolTransportAvailableInThisBuildEnvironment": status.get("sdkAvailable"),
        "transportUsedInThisTest": status.get("transport"),
        "interfacePlanning": True,
        "partnerOwnedHttpsQuestions": True,
        "executionPolicy": True,
        "payloadCritic": True,
        "secretPolicy": True,
        "responseSemantics": True,
        "runtimeIdResolution": True,
        "contractSummary": True,
        "readinessSupervisor": True,
        "toolActivityTrace": True,
    }
    path = ROOT / "examples" / "MCP_FIRST_AGENTIC_TOOLCHAIN_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
