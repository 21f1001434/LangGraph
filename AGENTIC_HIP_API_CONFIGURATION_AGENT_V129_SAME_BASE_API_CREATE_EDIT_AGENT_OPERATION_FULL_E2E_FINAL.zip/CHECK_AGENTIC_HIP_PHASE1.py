from __future__ import annotations

import json
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"name": name, "ok": bool(ok), "detail": detail})

try:
    from webapp.backend.app.main import app
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    from webapp.backend.app.templates import builtin_templates
    client = TestClient(app)
    boot = client.get('/api/bootstrap')
    check('FastAPI bootstrap endpoint', boot.status_code == 200, boot.status_code)
    body = boot.json() if boot.status_code == 200 else {}
    check('18 reusable API blocks', len(body.get('api_catalog', [])) == 18, len(body.get('api_catalog', [])))
    tx = transaction_metadata()
    check('Outbound convenience default', tx.get('default_direction') == 'Outbound')
    check('Direction remains user editable', tx.get('editable_direction') is True)
    check('Inbound 850 suggested', '850' in tx['directions']['Inbound']['suggested_transactions'])
    check('Outbound 832/855/856 suggested', {'832','855','856'}.issubset(set(tx['directions']['Outbound']['suggested_transactions'])))
    names = {x['name'] for x in builtin_templates()}
    check('Inbound 850 Translation template', 'Inbound 850 Translation' in names)
    check('Inbound 850 Passthrough template', 'Inbound 850 Passthrough' in names)
    check('Outbound starter templates', all(f'Outbound {x} Translation' in names and f'Outbound {x} Passthrough' in names for x in ('832','855','856')))
except Exception as exc:
    check('Backend import/bootstrap', False, f'{type(exc).__name__}: {exc}')

frontend_required = [
    'webapp/frontend/package.json', 'webapp/frontend/src/App.tsx',
    'webapp/frontend/src/pages/BuilderPage.tsx', 'webapp/frontend/src/pages/FlowGamePage.tsx',
    'webapp/frontend/src/components/ApiNode.tsx', 'webapp/frontend/src/components/NodeInspector.tsx',
]
check('React/Bun frontend files', all((ROOT / p).exists() for p in frontend_required), frontend_required)
check('Bun launcher', (ROOT / 'RUN_AGENTIC_HIP.bat').exists() and (ROOT / 'SETUP_AGENTIC_HIP.bat').exists())
check('Legacy V32 runner preserved', (ROOT / 'run_agent.py').exists() and (ROOT / 'input_builder_core.py').exists())

failed = [x for x in checks if not x['ok']]
report = {'status': 'PASS' if not failed else 'FAIL', 'passed': len(checks)-len(failed), 'failed': len(failed), 'checks': checks}
print(json.dumps(report, indent=2, default=str))
raise SystemExit(1 if failed else 0)
