# V48 - Approved Work-Type Auto-Fill

## Fix
Flow Orchestration Create and Flow Orchestration Deploy no longer ask the user for known HIP workflow work-type metadata when a customer workspace contains only the numeric ID or omits the workTypes block.

The runtime loads the approved work-type catalogue from `schemas/hip_config_service_v3_contracts.json` and self-heals known semantic roles before request generation, mapper lineage, missing-value suggestions, and production readiness validation.

Approved values currently used:

- Flow Create: `3419 / HIP Flow Creation`
- Flow Deploy DEV: `4694 / HIP GSCM Flow Deployment DEV`
- TP Create DEV: `10008 / HIP DCE Transport Profile Create DEV`

If a configured ID/type conflicts with every approved catalogue entry, the agent fails closed and asks for resolution instead of inventing metadata.

## Validation

- Reproduced ID-only configuration for Flow Create and Flow Deploy.
- Both generated complete `workType` objects and passed request contract validation.
- Full non-live Python regression suite: `175 passed`.
