from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

import run_agent
from canonical_payload_contract import interface_shape_summary, lock_request_value

ROOT = Path(__file__).resolve().parent

SOURCE_KEYS = [
    "Interface Environment",
    "Request Method",
    "Partner Identifier",
    "Dell Identifier",
    "Partner Verification Certificate",
    "Are SSL and Partner Verification Certificates identical?",
    "AS2 URL",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
    "SSL Certificate",
    "Compression Format",
]

TARGET_KEYS = [
    "Interface Environment",
    "Request Method",
    "Partner URL",
    "Partner Identifier",
    "Dell Identifier",
    "Signing Algorithm",
    "Encryption Algorithm",
    "Encryption Certificate",
    "SSL Certificate",
    "Enable AS2 Message Compression",
    "Asynchronous MDN Required",
    "Are Input Files Compressed?",
    "Is EBCDIC enabled?",
    "Compression Format",
]


def _runner() -> run_agent.Runner:
    return run_agent.Runner(llm_enabled=False)


def test_v120_schema_exactly_matches_supplied_as2_sender_receiver_attributes():
    fam = interface_shape_summary()["families"]["HTTPS_AS2"]
    assert fam["sourceKeys"] == SOURCE_KEYS
    assert fam["targetKeys"] == TARGET_KEYS
    assert "Partner Verification Certificate Id" not in fam["sourceKeys"]
    assert "Partner Verification Certificate CN – Expiry" not in fam["sourceKeys"]
    assert "Encryption Certificate Id" not in fam["targetKeys"]
    assert "Encryption Certificate CN – Expiry" not in fam["targetKeys"]
    assert "Is Compression Required" not in fam["targetKeys"]


def test_v120_sender_materializer_uses_only_approved_keys_and_values():
    payload = _runner().tp_parameters({
        "profile_usage": "Sender",
        "interface_type": "HTTPS-AS2",
        "interface_parameters": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "Partner Identifier": "PARTNER",
            "Dell Identifier": "DELL_PARTNER",
            "Partner Verification Certificate": "partner.crt",
            "Are SSL and Partner Verification Certificates identical?": "No",
            "AS2 URL": "URL will be shared later after AS2 API Publish is successful.",
            "Are Input Files Compressed?": "True",
            "Is EBCDIC enabled?": "False",
            "SSL Certificate": "ssl.crt",
            "Compression Format": "ZIP",
            "OLD CERT ID": "must-drop",
        },
    }, "source")
    assert list(payload) == SOURCE_KEYS
    assert payload["Compression Format"] == "ZIP"
    assert "OLD CERT ID" not in payload


def test_v120_receiver_materializer_uses_only_approved_keys_and_enum_values():
    payload = _runner().tp_parameters({
        "profile_usage": "Receiver",
        "interface_type": "HTTPS-AS2",
        "interface_parameters": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "Partner URL": "https://partner.example/as2",
            "Partner Identifier": "PARTNER",
            "Dell Identifier": "DELL_PARTNER",
            "Signing Algorithm": "SHA256",
            "Encryption Algorithm": "AES128",
            "Encryption Certificate": "encrypt.crt",
            "SSL Certificate": "dellroot_ca_6_able.crt",
            "Enable AS2 Message Compression": "False",
            "Asynchronous MDN Required": "False",
            "Are Input Files Compressed?": "True",
            "Is EBCDIC enabled?": "False",
            "Compression Format": "TAR",
            "Encryption Certificate Id": "must-drop",
        },
    }, "target")
    assert list(payload) == TARGET_KEYS
    assert payload["Signing Algorithm"] == "SHA256"
    assert payload["Encryption Algorithm"] == "AES128"
    assert payload["Compression Format"] == "TAR"
    assert "Encryption Certificate Id" not in payload


def test_v120_sender_conditional_fields_are_omitted_by_canonical_live_lock():
    body = {
        "interfaceType": "HTTPS-AS2",
        "propertyMap": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "Partner Identifier": "PARTNER",
            "Dell Identifier": "DELL_PARTNER",
            "Partner Verification Certificate": "same.crt",
            "Are SSL and Partner Verification Certificates identical?": "Yes",
            "AS2 URL": "pending",
            "Are Input Files Compressed?": "False",
            "Is EBCDIC enabled?": "False",
            "SSL Certificate": "same.crt",
            "Compression Format": "ZIP",
        },
        "transportProfileName": "AS2_SRC",
        "hipEnvironment": "DEV",
    }
    locked, meta = lock_request_value("validate_source", "payload", body, interface_family="HTTPS_AS2")
    assert "SSL Certificate" not in locked["propertyMap"]
    assert "Compression Format" not in locked["propertyMap"]
    assert len(meta["conditionallyOmittedPaths"]) == 2


def test_v120_receiver_compression_format_is_omitted_only_when_files_not_compressed():
    body = {
        "interfaceType": "HTTPS-AS2",
        "propertyMap": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "Partner URL": "https://partner.example/as2",
            "Partner Identifier": "PARTNER",
            "Dell Identifier": "DELL_PARTNER",
            "Signing Algorithm": "SHA256",
            "Encryption Algorithm": "AES128",
            "Encryption Certificate": "encrypt.crt",
            "SSL Certificate": "dellroot_ca_6_able.crt",
            "Enable AS2 Message Compression": "False",
            "Asynchronous MDN Required": "False",
            "Are Input Files Compressed?": "False",
            "Is EBCDIC enabled?": "False",
            "Compression Format": "ZIP",
        },
        "transportProfileName": "AS2_TGT",
        "hipEnvironment": "DEV",
    }
    locked, _ = lock_request_value("validate_target", "payload", body, interface_family="HTTPS_AS2")
    assert "Compression Format" not in locked["propertyMap"]
    body["propertyMap"]["Are Input Files Compressed?"] = "True"
    locked2, _ = lock_request_value("validate_target", "payload", body, interface_family="HTTPS_AS2")
    assert locked2["propertyMap"]["Compression Format"] == "ZIP"


def test_v120_rejects_as2_enum_values_outside_dev_allowed_values():
    with pytest.raises(ValueError, match="INVALID_INTERFACE_VALUE"):
        _runner().tp_parameters({
            "profile_usage": "Receiver",
            "interface_type": "HTTPS-AS2",
            "interface_parameters": {
                "Signing Algorithm": "MD5",
                "Encryption Algorithm": "AES128",
            },
        }, "target")


def test_v120_outer_transport_profile_contract_still_changes_only_interface_details():
    original = (ROOT / "input.json").read_text(encoding="utf-8")
    try:
        data = json.loads(original)
        snapshots = {}
        for interface in ("SFTP HAFT", "HTTPS-AS2"):
            current = deepcopy(data)
            tp = current["objects"]["source_transport_profile"]
            tp["interface_type"] = interface
            if interface == "HTTPS-AS2":
                tp["interface_parameters"] = {
                    "Partner Identifier": "PARTNER",
                    "Dell Identifier": "DELL_PARTNER",
                    "Partner Verification Certificate": "partner.crt",
                    "Are SSL and Partner Verification Certificates identical?": "No",
                    "AS2 URL": "pending",
                    "Are Input Files Compressed?": "False",
                    "Is EBCDIC enabled?": "False",
                    "SSL Certificate": "ssl.crt",
                    "Compression Format": "ZIP",
                }
            else:
                tp.pop("interface_parameters", None)
            (ROOT / "input.json").write_text(json.dumps(current, indent=2), encoding="utf-8")
            payload = _runner().preview_step_request("source_tp")["generatedPayload"]
            stripped = deepcopy(payload)
            stripped["transportProfileDetails"][0].pop("interfaceDetails", None)
            snapshots[interface] = stripped
        assert snapshots["SFTP HAFT"] == snapshots["HTTPS-AS2"]
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")
