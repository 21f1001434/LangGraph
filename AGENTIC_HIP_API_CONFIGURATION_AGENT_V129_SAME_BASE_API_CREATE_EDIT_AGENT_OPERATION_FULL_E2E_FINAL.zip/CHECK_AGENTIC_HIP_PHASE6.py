from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=''):
    checks.append({'name': name, 'ok': bool(ok), 'detail': detail})

manifest = json.loads((ROOT / 'AGENTIC_HIP_PHASE6_MANIFEST.json').read_text(encoding='utf-8'))
main = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
worker = (ROOT / 'webapp/backend/app/legacy_worker.py').read_text(encoding='utf-8')
models = (ROOT / 'webapp/backend/app/models.py').read_text(encoding='utf-8')
api = (ROOT / 'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
app_src = (ROOT / 'webapp/frontend/src/App.tsx').read_text(encoding='utf-8')
sidebar = (ROOT / 'webapp/frontend/src/components/Sidebar.tsx').read_text(encoding='utf-8')
testing = (ROOT / 'webapp/frontend/src/pages/ApiTestingPage.tsx').read_text(encoding='utf-8')
system = (ROOT / 'webapp/frontend/src/pages/SystemPage.tsx').read_text(encoding='utf-8')
flow_game = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
requirements = (ROOT / 'requirements.txt').read_text(encoding='utf-8')
legacy_req = (ROOT / 'requirements_legacy_streamlit.txt').read_text(encoding='utf-8')
normal_launcher = (ROOT / 'RUN_AGENTIC_HIP.bat').read_text(encoding='utf-8')
alias_launcher = (ROOT / 'RUN_HIP_STUDIO.bat').read_text(encoding='utf-8')
legacy_launcher = (ROOT / 'RUN_LEGACY_STREAMLIT_ARCHIVE.bat').read_text(encoding='utf-8')

check('Phase 6 manifest', manifest.get('phase') == 6 and manifest.get('release') == 'V80')
check('HIP API Agent Studio primary UI', manifest.get('primaryUi') == 'HIP API Agent Studio Web UI' and manifest.get('streamlitRequired') is False)
check('LIVE-only preserved', manifest.get('liveOnlyExecution') is True)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
check('Current deployment group is hip-automation', DEFAULT_DEPLOYMENT_GROUP == 'hip-automation')
check('18 API blocks declared', manifest.get('apiBlocks') == 18)
check('FastAPI phase 6 bootstrap', '"phase": 6' in main)
check('Studio web primary capability', '"studioWebPrimary": True' in main and '"streamlitFallback": False' in main)
check('System status endpoint', '/api/system/status' in main and 'streamlitRequired' in main)
check('Connection readiness endpoint', '/api/configurations/{cid}/readiness' in main and 'connection_readiness' in main)
check('Single API preflight endpoint', '/api/configurations/{cid}/api-tests/{step_key}/preflight' in main)
check('Single API LIVE endpoint', '/api/configurations/{cid}/api-tests/{step_key}/execute' in main and 'confirm_live' in main)
check('API test worker', 'def api_test(' in worker and 'runner.call(' in worker and 'validate_request_contract' in worker)
check('API test model', 'class ApiTestRequest' in models)
check('Studio API Testing page', 'Run this API LIVE' in testing and 'Agent preflight' in testing)
check('Studio System page', 'System & Connections' in system and 'Secure connections' in system and 'Configuration readiness' in system)
check('Sidebar Phase 6', 'Phase 6' in sidebar and "label:'API Testing Area'" in sidebar and "label:'System & Connections'" in sidebar)
check('App routes Phase 6 pages', 'ApiTestingPage' in app_src and 'SystemPage' in app_src)
check('Frontend API client testing methods', 'apiTestPreflight' in api and 'apiTestExecute' in api and 'systemStatus' in api and 'readiness' in api)
check('Primary requirements Streamlit-free', 'streamlit>=' not in requirements and 'streamlit-sortables' not in requirements)
check('Optional legacy Streamlit requirements', 'streamlit>=1.50,<2.0' in legacy_req and 'streamlit-sortables==0.3.1' in legacy_req)
check('Normal launcher is single-port Studio web UI', '127.0.0.1:8765' in normal_launcher and 'streamlit run' not in normal_launcher.lower())
check('RUN_HIP_STUDIO aliases Studio web UI', 'RUN_AGENTIC_HIP.bat' in alias_launcher and 'streamlit run' not in alias_launcher.lower())
check('Legacy Streamlit explicitly archived', 'streamlit run' in legacy_launcher.lower() and 'LEGACY' in legacy_launcher)
check('Development launcher exists', (ROOT / 'RUN_AGENTIC_HIP_DEV.bat').exists())
check('Frontend build helper exists', (ROOT / 'BUILD_AGENTIC_HIP_FRONTEND.bat').exists())
check('Static frontend serving retained', 'StaticFiles' in main and '_FRONTEND_DIST' in main)
check('Auto flow type does not assume Translation', "active?.flow_type==='Auto'?'Translation'" not in flow_game and 'Auto is intentionally left blank' in flow_game and 'resolved_flow_type' in flow_game)
check('Stale selected template cleared on customer/build flow switch', "setSelectedTemplate(null);setPage('flow')" in app_src and 'setActive(c);setSelectedTemplate(null)' in app_src)

styles = (ROOT / 'webapp/frontend/src/styles.css').read_text(encoding='utf-8')
parallel = (ROOT / 'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
check('Responsive body has no forced 1180px overflow', 'min-width:1180px' not in styles and 'body{margin:0;min-width:0' in styles)
check('Flow Game viewport overflow fixed', '.flow-page{height:100vh;min-height:0' in styles and '.flow-shell{height:auto!important;flex:1 1 auto;min-height:0' in styles)
check('Flow Game panels are collapsible', 'deckOpen' in flow_game and 'railOpen' in flow_game and 'fitView' in flow_game)
check('Run LIVE performs automatic preflight', 'Automatic preflight PASS' in flow_game and 'if(!checked?.readyForLive)' in flow_game)
check('Parallel live board exists', 'LIVE EXECUTION BOARD' in parallel and 'liveJobs' in parallel and 'Select all ready' in parallel)
check('Workspace continuity persisted', "hip.activeConfigurationId" in app_src and "hip.page" in app_src)

try:
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    from webapp.backend.app.main import app
    from fastapi.testclient import TestClient
    boot = TestClient(app).get('/api/bootstrap').json()
    status = TestClient(app).get('/api/system/status').json()
    check('Exactly 18 reusable APIs at runtime', len(api_catalog()) == 18 and all(x.get('reusable') for x in api_catalog()))
    check('Runtime bootstrap phase 6', boot.get('phase') == 6 and boot.get('capabilities',{}).get('studioWebPrimary') is True)
    check('Runtime system status phase 6', status.get('phase') == 6 and status.get('streamlitRequired') is False)
    meta = transaction_metadata()
    check('Direction remains editable', meta.get('editable_direction') is True and meta.get('default_direction') == 'Outbound')
except Exception as exc:
    check('Phase 6 Python imports', False, str(exc))

failed = [row for row in checks if not row['ok']]
summary = {'status': 'PASS' if not failed else 'FAIL', 'passed': len(checks)-len(failed), 'failed': len(failed), 'checks': checks}
print(json.dumps(summary, indent=2))
raise SystemExit(1 if failed else 0)
