from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

os.environ["HIP_TOKEN_URL"] = (
    "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token"
)
os.environ["HIP_CLIENT_ID"] = "test-client"
os.environ["HIP_CLIENT_SECRET"] = "test-secret"
os.environ["HIP_SCOPE"] = ""
os.environ.setdefault("DELL_AIA_CLIENT_ID", "aia-client")
os.environ.setdefault("DELL_AIA_CLIENT_SECRET", "aia-secret")

import run_agent


class Response:
    status_code = 200
    ok = True
    text = json.dumps({"access_token": "test.jwt.token"})
    url = "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token"
    headers = {"Content-Type": "application/json"}
    history = []

    def json(self):
        return {"access_token": "test.jwt.token"}


class Session:
    last = None

    def __init__(self):
        self.trust_env = True
        self.request = None
        Session.last = self

    def close(self):
        return None

    def post(self, url, **kwargs):
        self.request = {"url": url, **kwargs}
        return Response()


def main():
    run_agent.TOKEN_CACHE.clear()
    runner = run_agent.Runner(llm_enabled=False)
    with patch.object(run_agent.requests, "Session", Session):
        token = runner.get_token("HIP", "legacy-scope-must-be-ignored")

    request = Session.last.request
    auth = request["auth"]
    assert token == "test.jwt.token"
    assert Session.last.trust_env is True
    assert request["data"] == {"grant_type": "client_credentials"}
    assert request["allow_redirects"] is True
    assert auth.username == "test-client"
    assert auth.password == "test-secret"
    assert request["headers"]["Content-Type"] == (
        "application/x-www-form-urlencoded"
    )
    assert "scope" not in request["data"]
    assert "json" not in request

    result = {
        "status": "PASS",
        "buildId": run_agent.BUILD_ID,
        "grantType": request["data"]["grant_type"],
        "scopeSent": "scope" in request["data"],
        "trustEnv": Session.last.trust_env,
        "allowRedirects": request["allow_redirects"],
        "auth": "HTTPBasicAuth(client_id, client_secret)",
    }
    path = ROOT / "examples" / "EXACT_POSTMAN_OAUTH_TEST.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
