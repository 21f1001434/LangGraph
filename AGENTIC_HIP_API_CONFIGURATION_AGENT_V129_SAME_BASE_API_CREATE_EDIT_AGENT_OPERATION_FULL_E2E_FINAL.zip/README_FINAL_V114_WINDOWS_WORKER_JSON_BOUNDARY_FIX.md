# V114 — Windows Worker JSON Boundary + Pre-LIVE Stability Fix

## Latest 20:28 run root cause

The supplied run never reached a HIP LIVE API. Both U-HAUL and LEGRAND stopped at 0 ms with:

`JSONDecodeError: Expecting value: line 1 column 1 (char 0)`

The System & Connections page simultaneously returned HTTP 400 for `/api/configurations/{id}/readiness` even though the captured diagnostic body contained valid readiness data such as `secureConnectionsOk` and `flowConfigurationValid`.

The defect was in the React/FastAPI subprocess boundary. Managed Windows/MCP/evidence persistence can emit benign diagnostic text around a worker's machine-readable JSON. V113 still used strict `json.loads(proc.stdout)` in configuration validation and strict whole-stdout parsing in connection readiness. A warning before the JSON therefore converted a valid worker result into a false pre-LIVE blocker.

## V114 implementation

### Shared resilient worker-result parser

`webapp/backend/app/legacy_adapter.py` now provides `parse_worker_json_output()`.

It:
- strips BOM/NUL/ANSI terminal sequences;
- accepts ordinary pure JSON directly;
- when stdout contains diagnostics, scans for complete JSON objects and selects the largest authoritative result;
- never reads historical/package business data while parsing;
- fails closed if no valid current worker JSON exists.

The same parser is used for:
- API request preview;
- Flow Game preflight;
- System & Connections readiness;
- production preflight;
- Phase 2 / final pre-LIVE configuration validation.

### Clean machine-readable stdout

Best-effort OAuth diagnostic and LIVE response-evidence persistence warnings in `run_agent.py` are now written to `stderr`, not `stdout`. Evidence write problems still do not alter API verdicts, but they can no longer corrupt a JSON worker protocol.

### Effective Flow-name reporting

V113 already normalized every customer's Flow name before LIVE materialization. V114 additionally updates the in-memory queued manifest/result with the effective staged `profile_name` after canonicalization. Therefore an old queue created before the generic 40-character naming fix cannot display a stale 43-character LEGRAND alias as if that were the Flow about to execute.

This is reporting/state reconciliation only; there is still no post-error API rename.

### Browser startup cleanliness

`GET /favicon.ico` now returns HTTP 204 instead of producing a harmless but misleading 404 in the production terminal.

## Unchanged API-safety guarantees

V114 retains V108–V113 protections:
- every applicable canonical API is executed in strict LIVE mode;
- no cross-step `EXISTING_REUSED` inference;
- no packaged/historical Rule ID injection;
- Mapping Rule POST still omits `documentTypeId`, `flowDefinitionId`, and `actions[].params.mapId`;
- current-LIVE Rule identity resolution remains GET-only and exact name + version + environment matched;
- no changed-payload retry after a LIVE request is materialized;
- no post-error Flow rename;
- generic <=40-character Flow naming applies to every customer;
- deployment group remains `hip-automation`.

## Validation completed before packaging

- New V114 parser/readiness tests: **8/8 PASS**
- V108–V114 compatibility/release gate: **74/74 PASS**
- Application regression: **414/414 PASS**
- FastAPI/backend regression: **48/48 PASS**
- Combined Python regression: **462/462 PASS**
- Package validator: **58/58 PASS**
- Adaptive validator: **60/60 PASS**
- Business readiness: **69/69 PASS**
- Final release: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1–6 validators: **PASS**
- Controlled 18-step end-to-end API simulation: **PASS**, 18/18 steps and zero blocked steps
- Current-process `connection_readiness()` result parsing: **PASS**
- No authenticated Dell/HIP mutation was performed during packaging.

The external Dell API/platform conditions identified in prior LIVE runs remain external. V114 does not fake success for a missing upstream PCF route and does not invent a Rule ID if the current authenticated Rule-read service cannot prove one.
