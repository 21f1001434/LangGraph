# V61 — UI, LIVE result, and existing-object verdict hardening

V61 improves UI consistency across Execute and API Flow Game.

- Sidebar navigation now uses **Execute** instead of Parallel Runs.
- The lower **LIVE RESULT** panel updates during execution: elapsed time, completed customers, verdict counts, and live per-customer state no longer remain at zero until batch completion.
- Parallel batch state persists incremental completed-job results/counts for reconnect/recovery.
- `pre-existing`, `preexisting`, `already configured`, `object exists`, `duplicate key`, and similar responses are classified as **WARNING / EXISTING**, not FAIL.
- Dependency resolution uses the same response judge as final reports, so reusable existing objects can unblock downstream APIs.
- A non-zero runner exit caused only by coverage/final-state policy does not overwrite an agent WARNING when API evidence contains no FAIL/BLOCKED result.
- Flow Game customer-load messages auto-collapse after 3.2 seconds once loading finishes.
- Flow Game customer helper text is compact and inspectors/panels are repositioned below the customer selector/toolbar/health bar.
- Execute run controls remain visible with a sticky run bar on desktop/tablet.
- Existing V60 workType null-or-omitted behavior is preserved.
