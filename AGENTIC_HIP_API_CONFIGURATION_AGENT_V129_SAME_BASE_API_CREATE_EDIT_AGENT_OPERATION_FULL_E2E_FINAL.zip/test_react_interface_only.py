from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from transport_interface_react import (
    TransportInterfaceReActAgent,
    compare_request_bundles,
    validate_interface_only_input,
    validate_interface_only_request_override,
)

ROOT = Path(__file__).resolve().parent


def bundle() -> dict:
    from run_agent import Runner
    runner = Runner(llm_enabled=False)
    return {
        key: runner.preview_step_request(key)
        for key in runner.execution_flow.ordered_steps()
    }


def main() -> None:
    input_path = ROOT / "input.json"
    original = input_path.read_text(encoding="utf-8")
    baseline = json.loads((ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8"))

    target_https = {
        "Protocol": "REST",
        "Partner URL": "https://partner.example",
        "Request Method": "POST",
        "Request Format": "Request Body",
        "Receiver Authentication Type": "OAuth2",
        "Gateway URL": "URL will be shared later after API Publish is successful.",
        "SSL Certificate": "sample.crt",
        "Are Input Files Compressed?": "False",
        "SSL Certificate CN - Expiry": "Sample Issuing CA - 2030-09-28",
        "Receiver Grant Type": "client_credentials",
        "Receiver Token Endpoint": "https://partner.example/oauth/token",
        "Receiver Client Id": "sample-client",
        "Receiver Client Secret": "{{runtime_payload.target.receiver_client_secret}}",
        "SSL Certificate Id": "sample-cert-id",
    }

    agent = TransportInterfaceReActAgent(ROOT, baseline)

    missing_partner = agent.analyze(
        source_interface="SFTP",
        target_interface="HTTPS",
        source_parameters={},
        target_parameters={
            "Protocol": "REST",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "URL will be shared later after API Publish is successful.",
            "Are Input Files Compressed?": "False",
        },
    )
    assert missing_partner["ready"] is False
    missing_fields = {q["field"] for q in missing_partner["questions"]}
    assert {
        "Partner URL",
        "Receiver Grant Type",
        "Receiver Token Endpoint",
        "Receiver Client Id",
        "Receiver Client Secret",
    } <= missing_fields
    assert "SSL Certificate" not in missing_fields
    assert "SSL Certificate Id" not in missing_fields

    analysis = agent.analyze(
        source_interface="SFTP",
        target_interface="HTTPS",
        source_parameters={},
        target_parameters=target_https,
    )
    assert analysis["ready"] is True, analysis
    assert [row["phase"] for row in analysis["trace"]] == ["OBSERVE", "PLAN", "VALIDATE"]

    proposal = agent.propose(
        source_interface="SFTP",
        target_interface="HTTPS",
        source_parameters={},
        target_parameters=target_https,
    )
    assert proposal["valid"] is True, proposal
    assert proposal["critic"]["status"] == "PASS"
    assert not proposal["critic"]["violations"]
    allowed_canonical_prefixes = (
        "objects.target_transport_profile.interface_",
        "objects.source_transport_profile.interface_",
        "objects.biz_flow.configure_source.source_transport_profile",
        "objects.biz_flow.configure_targets.target_transport_profile",
        "objects.biz_flow.configure_routing.actions.target",
        "_interface_only_mode",
    )
    assert all(
        any(path.startswith(prefix) for prefix in allowed_canonical_prefixes)
        for path in proposal["changedPaths"]
    ), proposal["changedPaths"]
    assert proposal["proposal"]["objects"]["biz_flow"]["configure_source"]["source_transport_profile"] == "da-sender-sftphaft-dce-common"
    assert proposal["proposal"]["objects"]["biz_flow"]["configure_targets"]["target_transport_profile"] == "pt-receiver-https-dce-common"
    assert proposal["proposal"]["objects"]["biz_flow"]["configure_routing"]["actions"]["target"] == "pt-receiver-https-dce-common"

    strict = validate_interface_only_input(baseline, proposal["proposal"])
    assert strict["valid"] is True

    # Prove the critic rejects any accidental non-interface change.
    tampered = deepcopy(proposal["proposal"])
    tampered["profile_name"] = "SHOULD_NOT_CHANGE"
    rejected = validate_interface_only_input(baseline, tampered)
    assert rejected["valid"] is False
    assert "profile_name" in rejected["violations"]

    try:
        input_path.write_text(json.dumps(baseline, indent=2), encoding="utf-8")
        baseline_bundle = bundle()
        input_path.write_text(json.dumps(proposal["proposal"], indent=2), encoding="utf-8")
        proposed_bundle = bundle()
    finally:
        input_path.write_text(original, encoding="utf-8")

    request_critic = compare_request_bundles(baseline_bundle, proposed_bundle)
    assert request_critic["valid"] is True, request_critic
    changed_steps = set(request_critic["changedSteps"])
    assert changed_steps <= {"validate_source", "validate_target", "source_tp", "target_tp", "flow_create"}, changed_steps
    assert "target_tp" in changed_steps
    assert "flow_create" in changed_steps
    assert request_critic["flowCreateCritic"]["valid"] is True, request_critic

    # For the target TP request, everything outside interfaceDetails must stay identical.
    base_tp = baseline_bundle["target_tp"]["payload"]
    new_tp = proposed_bundle["target_tp"]["payload"]
    base_details = deepcopy(base_tp)
    new_details = deepcopy(new_tp)
    base_interface = base_details["transportProfileDetails"][0].pop("interfaceDetails")
    new_interface = new_details["transportProfileDetails"][0].pop("interfaceDetails")
    assert base_details == new_details
    assert base_interface != new_interface
    assert new_interface[0]["interfaceType"] == "HTTPS"
    assert new_interface[0]["parameters"]["Partner URL"] == "https://partner.example"

    # Manual payload edits remain allowed only within the interface section.
    allowed_edit = deepcopy(new_tp)
    allowed_edit["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]["Partner URL"] = "https://partner2.example"
    allowed_guard = validate_interface_only_request_override("target_tp", new_tp, allowed_edit)
    assert allowed_guard["valid"] is True, allowed_guard

    forbidden_edit = deepcopy(new_tp)
    forbidden_edit["transportProfileDetails"][0]["deploymentGroupName"] = "not-allowed"
    forbidden_guard = validate_interface_only_request_override("target_tp", new_tp, forbidden_edit)
    assert forbidden_guard["valid"] is False, forbidden_guard
    assert any("deploymentGroupName" in path for path in forbidden_guard["violations"])

    non_tp_guard = validate_interface_only_request_override(
        "map", {"name": "same"}, {"name": "changed"}
    )
    assert non_tp_guard["valid"] is False

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-dce-common-partner-https-v7",
        "reactPhases": ["OBSERVE", "PLAN", "VALIDATE", "ACT", "CRITIC"],
        "strictCanonicalCritic": "PASS",
        "nonInterfaceTamperRejected": True,
        "nonTpApiRequestsUnchangedExceptDeterministicFlowProfileBinding": True,
        "httpsPartnerRequiredFieldsEnforced": True,
        "certificateFieldsPendingNotInvented": True,
        "dceCommonSharedProfileBinding": True,
        "targetTpOnlyInterfaceDetailsChanged": True,
        "manualInterfaceEditAllowed": True,
        "manualFrozenFieldEditRejected": True,
        "nonTpPayloadEditRejected": True,
        "changedApiSteps": sorted(changed_steps),
    }
    path = ROOT / "examples" / "REACT_INTERFACE_ONLY_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
