# V49 — Multi-Customer Parallel Execution

## What changed

Parallel Runs now supports selecting and queueing different validated customers together. The user no longer has to clone the active customer to demonstrate concurrency.

### Validated Customer Library

The Parallel Execution Center now shows:

- the packaged approved U-HAUL reference (`reference:uhal`), validated against the current 18 API contracts;
- every saved customer configuration whose `input.json` has been built;
- each configuration's validation state, direction, transaction, flow type, and contract count;
- the active configuration marker.

Only validated customers can be selected for LIVE parallel execution.

### U-HAUL + active customer shortcut

`Select U-HAUL + active` selects the approved U-HAUL reference and the currently active validated customer. For example:

- U-HAUL Outbound 856 Translation
- LEGRAND_NEDERLAND Inbound 850 Translation

`Add selected customers to queue` revalidates each source immediately before snapshotting it, creates one isolated queue workspace per customer, and automatically selects the created queue jobs.

### Real customer payload isolation

Each queued customer receives its own snapshot of:

- `input.json`
- `config_overrides.json`
- `payload_overrides.json`
- API execution plan / execution flow
- input files
- knowledge
- approved reference data
- ephemeral runtime values where present

One customer cannot overwrite another customer's files or payload state.

### Parallel LIVE execution

After multiple customer payload snapshots are selected, `RUN SELECTED LIVE IN PARALLEL` executes those customers concurrently up to the configured worker limit. Dependency ordering inside each individual customer's API flow is unchanged.

### U-HAUL reference safety

The packaged U-HAUL reference workspace is read-only from the Parallel Runs workflow. It is validated, then copied into an isolated queue snapshot before LIVE execution.

### Same-customer instances retained

The existing instance feature is still available as an optional same-customer load test. It is clearly separated from the new multi-customer workflow.

## Validation

- New V49 multi-customer tests: 3/3 PASS
- Parallel/V47/V48 focused regression: 23/23 PASS
- Full non-LIVE test suite: 178/178 PASS
- Modified TypeScript/TSX files pass TypeScript `transpileModule` syntax validation.

The full Vite/Bun production build was not run in the packaging container because frontend `node_modules` are not installed there. Run `bun install` and `bun run build` on the target machine.
