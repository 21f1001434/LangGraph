from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

# V123 policy:
# - developer-approved method / URL / request kind / attribute structure remain immutable;
# - the mapper/LLM may map workbook evidence to EXISTING canonical leaves and prepare changed VALUES;
# - an agent can never add/remove/rename attributes, alter nesting/cardinality, method, URL or protected headers;
# - persistence/LIVE authority still requires an explicit HUMAN USER approval action (the Stage button);
# - the saved row records the human approval while audit metadata preserves that the values came from agent mapping;
# - persisted value edits are contract-validated and applied before the first LIVE fingerprint;
# - ad-hoc graph/request structure mutation remains forbidden.
API_REQUEST_MUTATION_ALLOWED = False  # structural/ad-hoc mutation remains forbidden
API_REQUEST_VALUE_EDIT_ALLOWED = True
POLICY_NAME = "IMMUTABLE_DEVELOPER_APPROVED_18_API_CONTRACT_AGENT_MAPS_VALUES_USER_APPROVES_STAGE"
# Compatibility marker for legacy governance tests/docs: persistence authority remains HUMAN_USER_VALUE_EDIT_ONLY.
LEGACY_PERSISTENCE_AUTHORITY = "HUMAN_USER_VALUE_EDIT_ONLY"


def has_request_override(value: Any) -> bool:
    return isinstance(value, dict) and bool(value)


def assert_no_request_override(value: Any, *, context: str = "API request") -> None:
    """Reject one-off request overrides that bypass the persisted value editor.

    API Testing/Flow nodes may not smuggle a transient request body into LIVE.
    User edits must first be saved through the schema-locked Payload Value Editor,
    where they are validated, audited, and visible in generated/effective previews.
    """
    if has_request_override(value):
        raise ValueError(
            f"{POLICY_NAME}: {context} ad-hoc request override is disabled. "
            "Save the value edit through Payload Value Editor first. API method, URL, "
            "request kind, attribute names, nesting and protected headers are immutable."
        )


def immutable_flow_graph(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Remove transient Flow-graph request overrides while preserving edge mappings."""
    value = deepcopy(graph if isinstance(graph, dict) else {})
    for node in value.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        node["request_override"] = {}
        node["override_mode"] = "merge"
    return value


def immutable_override_meta(step_key: str, *, persisted_count: int = 0) -> Dict[str, Any]:
    """Compatibility metadata when no persisted value edit is applied."""
    return {
        "applied": False,
        "stepKey": str(step_key or ""),
        "policy": POLICY_NAME,
        "structureMutationAllowed": False,
        "valueEditAllowed": True,
        "persistedOverrideIgnored": False,
        "persistedValueEditCount": int(persisted_count or 0),
        "note": (
            "Developer-approved request structure is immutable. The agent may map workbook data and prepare values "
            "only for existing canonical leaves. A human user must explicitly approve/stage those values before LIVE materialization."
        ),
    }
