from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_normal_launcher_has_no_reload():
    text = (ROOT / "RUN_AGENTIC_HIP.bat").read_text(encoding="utf-8", errors="replace")
    assert "python -m uvicorn webapp.backend.app.main:app" in text
    assert "--reload" not in text
    assert "cd /d %~dp0 && python -m uvicorn" not in text


def test_dev_batch_defaults_stable_and_reload_is_scoped_when_opted_in():
    text = (ROOT / "RUN_AGENTIC_HIP_DEV.bat").read_text(encoding="utf-8", errors="replace")
    assert 'HIP_BACKEND_HOT_RELOAD' in text
    assert '--reload --reload-dir webapp\\backend\\app' in text
    assert 'set "BACKEND_RELOAD="' in text
    assert 'cd /d %~dp0 && python -m uvicorn' not in text
    # Bare repo-wide reload must never appear.
    assert '--port 8765 --reload"' not in text


def test_dev_powershell_defaults_stable_and_scopes_optional_reload():
    text = (ROOT / "RUN_AGENTIC_HIP_DEV.ps1").read_text(encoding="utf-8", errors="replace")
    assert 'HIP_BACKEND_HOT_RELOAD' in text
    assert '--reload --reload-dir webapp/backend/app' in text
    assert "Backend hot reload disabled for startup stability" in text


def test_v98_docs_explain_one_drive_watchfiles_loop():
    text = (ROOT / "README_FINAL_V98_STARTUP_STABILITY_FIX.md").read_text(encoding="utf-8", errors="replace")
    assert "WatchFiles" in text
    assert "OneDrive" in text
    assert "KeyboardInterrupt" in text
