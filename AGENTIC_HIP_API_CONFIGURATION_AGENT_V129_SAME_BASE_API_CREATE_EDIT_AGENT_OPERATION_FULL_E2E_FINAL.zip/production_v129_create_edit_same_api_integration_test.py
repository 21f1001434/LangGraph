from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import run_agent
from api_execution_plan import clear_execution_plan
from execution_flow import ExecutionFlowConfig, save_execution_flow
from production_integration_test import fake_response

ROOT = Path(__file__).resolve().parent


def main() -> None:
    plan_path = ROOT / "api_execution_plan.json"
    flow_path = ROOT / "execution_flow.json"
    original_plan = plan_path.read_bytes() if plan_path.exists() else None
    original_flow = flow_path.read_bytes() if flow_path.exists() else None
    try:
        clear_execution_plan(ROOT, ROOT / "input.json")
        flow = ExecutionFlowConfig(ROOT)
        rows = []
        for row in flow.summary()["steps"]:
            item = {
                "stepKey": row["stepKey"],
                "order": row["order"],
                "waitAfterSeconds": 0,
                "operationMode": "edit" if row["stepKey"] in {"source_tp", "target_tp", "flow_create"} else "inherit",
            }
            rows.append(item)
        save_execution_flow(ROOT, rows, migration_enabled=False)
        _run_edit_18()
    finally:
        if original_plan is None:
            plan_path.unlink(missing_ok=True)
        else:
            plan_path.write_bytes(original_plan)
        if original_flow is None:
            flow_path.unlink(missing_ok=True)
        else:
            flow_path.write_bytes(original_flow)


def _run_edit_18() -> None:
    runner = run_agent.Runner(llm_enabled=False)
    runner.ov["tpProcessingWaitSeconds"] = 0
    runner.ov["flowProcessingWaitSeconds"] = 0
    runner.get_token = lambda token_kind, scope: "offline-token"
    runner.judge.judge = lambda result: {}
    runner.judge.available = lambda: False
    captured = []

    def mocked_request(method, url, token_kind, scope, extra_headers, payload, params):
        captured.append({"method": method, "url": url, "payload": payload, "params": params})
        return fake_response(method, url, payload, params)

    runner._request_with_retry = mocked_request
    with patch("run_agent.time.sleep", return_value=None), patch.object(
        runner.adaptive, "record_api_result", return_value=None
    ), patch.object(
        runner.adaptive, "record_mapping_graph", return_value={"status": "mocked"}
    ):
        results = runner.run()

    assert runner.final_state["success"] is True, runner.final_state
    assert runner.final_state["businessSuccess"] is True, runner.final_state
    assert runner.final_state["expectedApplicableApiCount"] == 18, runner.final_state
    assert runner.final_state["calledApplicableApiCount"] == 18, runner.final_state

    source_name = runner.source_tp().get("profile_name")
    target_name = runner.target_tp().get("profile_name")
    tp_calls = [row for row in captured if "/transport-profiles/orchestration/create" in row["url"]]
    assert len(tp_calls) == 2, tp_calls
    by_name = {
        row["payload"]["transportProfileDetails"][0]["transportProfileName"]: row
        for row in tp_calls
    }
    for name in (source_name, target_name):
        row = by_name[name]
        assert row["method"].upper() == "POST"
        assert row["payload"]["operation"] == "Edit"
        assert row["payload"]["transportProfileDetails"][0]["transportProfileOperation"] == "edit"

    flow_calls = [row for row in captured if "/flows/orchestration/create" in row["url"]]
    assert len(flow_calls) == 1, flow_calls
    assert flow_calls[0]["method"].upper() == "POST"
    assert flow_calls[0]["payload"]["operation"] == "edit"

    output = {
        "status": "PASS",
        "baseApiSteps": 18,
        "sameBaseApiEditCalls": 3,
        "sourceTp": {"method": tp_calls[0]["method"], "endpoint": tp_calls[0]["url"], "operation": "edit"},
        "targetTp": {"method": tp_calls[1]["method"], "endpoint": tp_calls[1]["url"], "operation": "edit"},
        "flow": {"method": flow_calls[0]["method"], "endpoint": flow_calls[0]["url"], "operation": "edit"},
        "endToEndSuccess": runner.final_state["success"],
        "businessSuccess": runner.final_state["businessSuccess"],
        "unresolvedRequiredSteps": runner.final_state["unresolvedRequiredSteps"],
    }
    path = ROOT / "examples" / "PRODUCTION_MOCK_V129_CREATE_EDIT_SAME_API_INTEGRATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
