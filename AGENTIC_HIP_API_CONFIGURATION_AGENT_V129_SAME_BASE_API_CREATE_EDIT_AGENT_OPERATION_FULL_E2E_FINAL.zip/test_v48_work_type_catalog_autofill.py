from pathlib import Path
from work_type_catalog import load_approved_work_type_catalog, resolve_work_type, hydrate_work_types


def test_worktype_catalog_is_deprecated_and_empty():
    assert load_approved_work_type_catalog(Path.cwd()) == {}
    assert resolve_work_type("flow_create", {"id": 3419, "type": "OLD"}, {}) == {}


def test_legacy_worktypes_are_removed_from_config():
    cleaned = hydrate_work_types({"workTypes": {"flow_create": {"id": 3419}}, "x": 1}, Path.cwd())
    assert cleaned == {"x": 1}
