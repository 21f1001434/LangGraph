from __future__ import annotations

import datetime as dt
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List

REGISTRY_FILE = "interface_profiles.json"

BUILTIN_INTERFACES: Dict[str, Dict[str, Any]] = {
    "SFTP": {
        "displayName": "SFTP",
        "apiInterfaceType": "SFTP HAFT",
        "family": "FILE_TRANSFER",
        "description": "Secure file transfer using the existing account/folder HAFT model.",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "da-sender-sftphaft-dce-common",
        "targetSharedProfile": "pt-receiver-sftphaft-dce-common",
        "requiresDocumentation": False,
        "sourceDefaults": {},
        "targetDefaults": {},
        "sourceRequired": [],
        "targetRequired": [],
    },
    "FTP": {
        "displayName": "FTP",
        "apiInterfaceType": "FTP",
        "family": "FILE_TRANSFER",
        "description": "FTP uses the same account/folder model as SFTP; only the API interface type changes.",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "da-sender-sftphaft-dce-common",
        "targetSharedProfile": "pt-receiver-sftphaft-dce-common",
        "requiresDocumentation": False,
        "sourceDefaults": {},
        "targetDefaults": {},
        "sourceRequired": [],
        "targetRequired": [],
    },
    "HTTPS": {
        "displayName": "HTTPS / REST",
        "apiInterfaceType": "HTTPS",
        "family": "HTTP",
        "description": "REST/HTTPS Transport Profile. Receiver OAuth values are Partner-owned and must be supplied.",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "da-sender-https-dce-common",
        "targetSharedProfile": "pt-receiver-https-dce-common",
        "requiresDocumentation": False,
        "sourceDefaults": {
            "Protocol": "REST",
            "HIP URL": "URL will be shared later after API Publish is successful.",
            "Proxy URI": "dce-common-sv1",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Sender Authentication Type": "OAuth2",
            "Are Input Files Compressed?": "False",
            "Sender Grant Type": "client_credentials",
        },
        "targetDefaults": {
            "Protocol": "REST",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "URL will be shared later after API Publish is successful.",
            "Are Input Files Compressed?": "False",
        },
        "sourceRequired": [],
        "targetRequired": [
            "Partner URL",
            "Receiver Grant Type",
            "Receiver Token Endpoint",
            "Receiver Client Id",
            "Receiver Client Secret",
        ],
        "sourceSensitiveFields": [],
        "targetSensitiveFields": ["Receiver Client Secret"],
        "targetIgnoredFields": [
            "SSL Certificate",
            "SSL Certificate CN - Expiry",
            "SSL Certificate Id",
        ],
    },
    "NAS": {
        "displayName": "NAS",
        "apiInterfaceType": "NAS",
        "family": "NAS",
        "description": "Dev-team supplied NAS Sender/Receiver interfaceDetails contract (2026-09-07). Attribute names are fixed; values are customer/human-editable only.",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "",
        "targetSharedProfile": "",
        "requiresDocumentation": False,
        "sourceDefaults": {},
        "targetDefaults": {},
        "sourceRequired": ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS"],
        "targetRequired": ["Protocol", "Server Name", "Server Path", "AD Group"],
        "sourceSensitiveFields": [],
        "targetSensitiveFields": [],
        "sourceAllowedValues": {
            "Protocol": ["NFS", "SMB", "Multi Protocol"],
            "Post File Transfer Action NAS": ["Delete", "Move To Archive", "Rename"],
            "Polling Interval": ["Every 5 Minutes", "Every 15 Minutes", "Every 30 Minutes", "Every Hour", "Every 12 Hours", "Every Day", "Cron Expression"],
        },
        "targetAllowedValues": {"Protocol": ["NFS", "SMB", "Multi Protocol"]},
        "conditionalRules": [
            "Sender: when Protocol=NFS, Post File Transfer Action NAS must be Delete.",
            "Sender: when Polling Interval=Cron Expression, Cron Expression is required.",
        ],
    },
    "Rabbit MQ": {
        "displayName": "Rabbit MQ",
        "apiInterfaceType": "Rabbit MQ",
        "family": "RABBIT_MQ",
        "description": "Dev-team supplied Rabbit MQ Sender/Receiver interfaceDetails contract (2026-09-07).",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "",
        "targetSharedProfile": "",
        "requiresDocumentation": False,
        "sourceDefaults": {},
        "targetDefaults": {},
        "sourceRequired": ["Interface Environment", "Exchange Name"],
        "targetRequired": ["Interface Environment", "Exchange Name"],
        "sourceSensitiveFields": [],
        "targetSensitiveFields": [],
        "sourceAllowedValues": {"Interface Environment": ["DEV", "TEST", "PERF"]},
        "targetAllowedValues": {"Interface Environment": ["DEV", "TEST", "PERF"]},
    },
    "HTTPS-AS2": {
        "displayName": "HTTPS-AS2",
        "apiInterfaceType": "HTTPS-AS2",
        "family": "AS2",
        "description": "Dev-team approved HTTPS-AS2 Sender/Receiver interfaceDetails attributes supplied 2026-09-02. Values come from customer/user-approved evidence; the AI agent cannot edit active payload values or create request fields.",
        "deploymentGroup": "hip-automation",
        "sourceSharedProfile": "",
        "targetSharedProfile": "",
        "requiresDocumentation": False,
        "sourceDefaults": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "Are SSL and Partner Verification Certificates identical?": "No",
            "Are Input Files Compressed?": "False",
            "Is EBCDIC enabled?": "False",
        },
        "targetDefaults": {
            "Interface Environment": "UAT",
            "Request Method": "POST",
            "SSL Certificate": "dellroot_ca_6_able.crt",
            "Enable AS2 Message Compression": "False",
            "Asynchronous MDN Required": "False",
            "Are Input Files Compressed?": "False",
            "Is EBCDIC enabled?": "False",
        },
        "sourceRequired": [
            "Interface Environment",
            "Request Method",
            "Partner Identifier",
            "Dell Identifier",
            "Partner Verification Certificate",
            "Are SSL and Partner Verification Certificates identical?",
            "AS2 URL",
            "Are Input Files Compressed?",
            "Is EBCDIC enabled?",
        ],
        "targetRequired": [
            "Interface Environment",
            "Request Method",
            "Partner URL",
            "Partner Identifier",
            "Dell Identifier",
            "Signing Algorithm",
            "Encryption Algorithm",
            "Encryption Certificate",
            "SSL Certificate",
            "Enable AS2 Message Compression",
            "Asynchronous MDN Required",
            "Are Input Files Compressed?",
            "Is EBCDIC enabled?",
        ],
        "sourceSensitiveFields": [],
        "targetSensitiveFields": [],
        "sourceAllowedValues": {
            "Are SSL and Partner Verification Certificates identical?": ["Yes", "No"],
            "Are Input Files Compressed?": ["True", "False"],
            "Is EBCDIC enabled?": ["True", "False"],
            "Compression Format": ["GZIP", "ZIP", "TAR"],
        },
        "targetAllowedValues": {
            "Signing Algorithm": ["SHA1", "SHA256", "SHA512"],
            "Encryption Algorithm": ["AES128", "AES256"],
            "Enable AS2 Message Compression": ["True", "False"],
            "Asynchronous MDN Required": ["True", "False"],
            "Are Input Files Compressed?": ["True", "False"],
            "Is EBCDIC enabled?": ["True", "False"],
            "Compression Format": ["GZIP", "ZIP", "TAR"],
        },
        "conditionalRules": [
            "Sender: if Are SSL and Partner Verification Certificates identical? = Yes, omit SSL Certificate.",
            "Sender/Receiver: if Are Input Files Compressed? = False, omit Compression Format.",
        ],
    },
}


def _registry_path(root: Path) -> Path:
    return Path(root) / REGISTRY_FILE


def load_custom_interfaces(root: Path) -> Dict[str, Dict[str, Any]]:
    path = _registry_path(root)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    value = data.get("interfaces") if isinstance(data, dict) else {}
    return value if isinstance(value, dict) else {}


def save_custom_interface(root: Path, key: str, definition: Dict[str, Any]) -> Dict[str, Any]:
    root = Path(root)
    path = _registry_path(root)
    existing = load_custom_interfaces(root)
    normalized_key = str(key or definition.get("displayName") or definition.get("apiInterfaceType") or "").strip()
    if not normalized_key:
        raise ValueError("Interface name is required.")
    payload = deepcopy(definition)
    payload.setdefault("displayName", normalized_key)
    payload.setdefault("apiInterfaceType", normalized_key)
    payload.setdefault("family", "CUSTOM")
    payload.setdefault("description", "User-defined HIP Transport Profile interface.")
    payload["deploymentGroup"] = "hip-automation"
    payload.setdefault("sourceSharedProfile", "")
    payload.setdefault("targetSharedProfile", "")
    payload.setdefault("sourceDefaults", {})
    payload.setdefault("targetDefaults", {})
    payload.setdefault("sourceRequired", ["__PARAMETERS__", "__SHARED_PROFILE__"])
    payload.setdefault("targetRequired", ["__PARAMETERS__", "__SHARED_PROFILE__"])
    payload.setdefault("sourceSensitiveFields", [])
    payload.setdefault("targetSensitiveFields", [])
    payload.setdefault("requiresDocumentation", True)
    payload["custom"] = True
    payload["updatedAt"] = dt.datetime.now().isoformat()
    existing[normalized_key] = payload
    path.write_text(json.dumps({"version": 1, "interfaces": existing}, indent=2), encoding="utf-8")
    return payload


def delete_custom_interface(root: Path, key: str) -> bool:
    path = _registry_path(root)
    existing = load_custom_interfaces(root)
    if key not in existing:
        return False
    existing.pop(key, None)
    path.write_text(json.dumps({"version": 1, "interfaces": existing}, indent=2), encoding="utf-8")
    return True


def registry(root: Path) -> Dict[str, Dict[str, Any]]:
    merged = deepcopy(BUILTIN_INTERFACES)
    merged.update(load_custom_interfaces(root))
    for definition in merged.values():
        if isinstance(definition, dict):
            definition["deploymentGroup"] = "hip-automation"
    return merged


def interface_keys(root: Path) -> List[str]:
    builtins = list(BUILTIN_INTERFACES)
    custom = [key for key in load_custom_interfaces(root) if key not in builtins]
    return builtins + sorted(custom)


def get_interface(root: Path, key: str) -> Dict[str, Any]:
    value = registry(root).get(str(key))
    if not value:
        raise KeyError(f"Unknown interface: {key}")
    return deepcopy(value)


def materialize_parameters(definition: Dict[str, Any], side: str, supplied: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Materialize only interface-specific parameter VALUES for one TP side.

    Transport Profile orchestration's outer attributes are interface-invariant.
    Only ``interfaceDetails`` (interface type/role/parameters) varies by interface.
    An interface definition may declare generic ``ignoredFields`` and/or
    side-specific ``sourceIgnoredFields`` / ``targetIgnoredFields``; these are
    removed deterministically before any canonical payload is generated.
    """
    side = str(side or "").strip().lower()
    supplied = deepcopy(supplied or {})
    defaults = deepcopy(definition.get(f"{side}Defaults") or {})
    ignored = {
        str(x) for x in (
            list(definition.get("ignoredFields") or [])
            + list(definition.get(f"{side}IgnoredFields") or [])
        )
        if str(x)
    }
    for key in ignored:
        defaults.pop(key, None)
        supplied.pop(key, None)
    defaults.update({key: value for key, value in supplied.items() if value not in (None, "") and key not in ignored})
    return defaults


def missing_values(
    definition: Dict[str, Any],
    side: str,
    params: Dict[str, Any],
    shared_profile: str = "",
) -> List[Dict[str, str]]:
    missing: List[Dict[str, str]] = []
    required = definition.get(f"{side}Required") or []
    for field in required:
        if field == "__PARAMETERS__":
            if not params:
                missing.append({
                    "field": f"{side}Parameters",
                    "question": f"Provide the approved {side} interface parameters.",
                    "why": "This interface is contract-driven and the agent will not invent fields.",
                })
            continue
        if field == "__SHARED_PROFILE__":
            if not str(shared_profile or "").strip():
                missing.append({
                    "field": f"{side}SharedProfile",
                    "question": f"What shared dce-common Transport Profile reference should the {side} Flow use?",
                    "why": "The Flow must bind to the shared profile that matches this interface.",
                })
            continue
        if not str(params.get(field) or "").strip():
            label = field.replace(" Env", "")
            missing.append({
                "field": field,
                "question": f"What should I use for {label}?",
                "why": "Required by the selected interface contract.",
            })
    return missing
