from __future__ import annotations

import datetime as dt
import html
import json
import shutil
from pathlib import Path
from typing import Any, Dict, List

from api_execution_plan import save_execution_plan
from execution_flow import STEP_DEFINITIONS, save_execution_flow
from payload_overrides import clear_all_overrides
from production_guard import redact_sensitive


# The Application Studio is now a FULL LIVE API coverage tool. U-HAUL is an
# existing configuration, but we intentionally still call every configured API
# because these APIs are the reusable building blocks for future customers.
# Existing/duplicate responses are evidence, not a reason to skip the call.
BUSINESS_DEMO_SKIP_STEPS: List[str] = []
BUSINESS_DEMO_LIVE_STEPS: List[str] = list(STEP_DEFINITIONS.keys())


def _load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def prepare_uhal_business_demo(root: Path, *, reset_payload_edits: bool = True) -> Dict[str, Any]:
    """Prepare U-HAUL for full live API coverage.

    Important distinction:
    - U-HAUL remains the approved baseline/template.
    - No logical API is skipped merely because the object already exists.
    - The runner is placed in ``fullApiCoverageMode`` so downstream APIs are
      still attempted even when an earlier create API returns duplicate/error.
      No packaged/historical runtime IDs are preloaded; each API contributes only its own current-run evidence.
    """
    root = Path(root)
    baseline = root / "dev_approved"
    input_source = baseline / "UHAL_input_dev_approved.json"
    config_source = baseline / "UHAL_config_dev_approved.json"
    if not input_source.exists() or not config_source.exists():
        raise FileNotFoundError("The approved U-HAUL baseline files are missing.")

    input_path = root / "input.json"
    config_path = root / "config_overrides.json"
    shutil.copy2(input_source, input_path)
    shutil.copy2(config_source, config_path)
    if reset_payload_edits:
        clear_all_overrides(root)

    config = _load_json(config_path, {})
    config.update({
        "fullApiCoverageMode": True,
        "continueAfterApiFailure": True,
        "businessReportIncludePayloads": True,
        "applicationStudioMode": "UHAL_FULL_LIVE_API_COVERAGE",
    })
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    # V108 no-reuse execution: the business-demo plan carries no reusable
    # packaged IDs. Every applicable API is called; if HIP itself reports a
    # duplicate/existing object, that response is kept as this call's evidence.
    existing_ids = {}

    # Persist a plan with ZERO skips and ZERO packaged reuse IDs.
    plan = save_execution_plan(
        root,
        input_path,
        [],
        existing_ids,
        confirmed=True,
        reason=(
            "U-HAUL full live API coverage: call every configured HIP API. "
            "Existing/duplicate responses are recorded as live evidence and do not skip later APIs."
        ),
        existing_flow_version=str(config.get("flowVersion") or "1.0"),
    )

    flow_rows: List[Dict[str, Any]] = []
    for order, key in enumerate(STEP_DEFINITIONS, start=1):
        flow_rows.append({
            "stepKey": key,
            "order": order,
            "waitAfterSeconds": 0.0,
        })
    execution_flow = save_execution_flow(root, flow_rows)

    input_data = _load_json(input_path, {})
    objects = input_data.get("objects") or {}
    source_tp = objects.get("source_transport_profile") or {}
    target_tp = objects.get("target_transport_profile") or {}
    biz = objects.get("biz_flow") or {}
    source_cfg = biz.get("configure_source") or {}
    target_cfg = biz.get("configure_targets") or {}

    return {
        "status": "READY",
        "mode": "FULL_LIVE_API_COVERAGE",
        "customer": input_data.get("customer"),
        "flow": input_data.get("profile_name"),
        "transaction": f"{input_data.get('tx_standard', '')} {input_data.get('tx_code', '')} {input_data.get('tx_name', '')}".strip(),
        "direction": input_data.get("direction"),
        "interface": source_tp.get("interface_type") or "SFTP HAFT",
        "deploymentGroup": source_tp.get("deployment_group") or config.get("source_deployment_group_name"),
        "sourceSharedProfile": source_cfg.get("source_transport_profile") or config.get("source_transport_profile_name"),
        "targetSharedProfile": target_cfg.get("target_transport_profile") or config.get("target_transport_profile_name"),
        "executionPlan": plan,
        "executionFlow": execution_flow,
        "liveApiSteps": BUSINESS_DEMO_LIVE_STEPS,
        "skippedExistingSteps": [],
        "expectedLogicalSteps": len(STEP_DEFINITIONS),
    }


def latest_agent_results(root: Path) -> List[Dict[str, Any]]:
    reports = Path(root) / "reports"
    candidates = sorted(reports.glob("hip_aia_mcp_agent_report_*.json"))
    if not candidates:
        return []
    value = _load_json(candidates[-1], [])
    return value if isinstance(value, list) else []


def _logical_step(item: Dict[str, Any]) -> str:
    extracted = item.get("extracted") or {}
    if isinstance(extracted, dict) and extracted.get("logicalStepKey"):
        return str(extracted.get("logicalStepKey"))
    attempt = str(item.get("attempt") or "")
    aliases = {
        "validate_source": "validate_source",
        "validate_target": "validate_target",
        "validate_flow": "validate_flow",
        "source_account_dce_domain": "account_source",
        "target_account_dce_domain": "account_target",
        "partner_payload_x_account_name": "partner_target",
        "system_payload": "system_source",
        "numeric_document_type_id": "rule",
        "dependency_gated_flow_create": "flow_create",
        "dependency_gated_flow_deploy": "flow_deploy",
        "flow_history": "flow_history",
        "tp_source_audit": "source_tp_audit",
        "tp_target_audit": "target_tp_audit",
    }
    if attempt == "fixed_payload":
        api = str(item.get("api") or "").lower()
        return "doctype_source" if "source" in api else "doctype_target"
    if attempt.startswith("primary_") or attempt.startswith("fallback_"):
        return "map"
    if attempt == "dependency_gated_systemName_deploymentGroupName":
        api = str(item.get("api") or "").lower()
        return "source_tp" if "source" in api else "target_tp"
    return aliases.get(attempt, attempt)

def agent_response_verdict(item: Dict[str, Any]) -> Dict[str, str]:
    """Translate a raw API result into the business verdict shown in reports/UI.

    The HTTP status is intentionally *not* the business verdict. HIP create APIs
    can return an error-looking status while the response proves the object
    already exists. Those responses are PASS/EXISTING because downstream work
    can continue. Missing/dependency/not-found responses remain BLOCKED.
    """
    response = str(item.get("response_preview") or item.get("response") or item.get("error") or "")
    text = " ".join([
        response,
        str(item.get("classification") or ""),
        str(item.get("final_owner") or item.get("owner") or ""),
        str(item.get("issue") or ""),
    ]).lower()
    owner = str(item.get("final_owner") or item.get("owner") or "").upper()
    classification = str(item.get("classification") or "").upper()
    business_success = bool(item.get("business_success") if "business_success" in item else item.get("businessSuccess"))

    existing_markers = (
        "already exists", "already exist", "already exits", "is already exists", "is already exist",
        "existing object", "already present", "already created", "unique constraint", "duplicate", "duplicate entry",
        "transport profile already exists",
    )
    blocked_markers = (
        "unable to find", "not able to find", "not bale to find", "cannot find",
        "could not find", "not found", "missing required", "is mandatory",
        "mandatory parameter", "invalid_scope", "unauthorized", "forbidden",
        "dependency failure", "skipped_dependency",
    )

    if owner in {"EXPECTED_EXISTING_OBJECT", "EXPECTED_DUPLICATE_FROM_RETEST", "USER_APPROVED_SKIP"} or any(m in text for m in existing_markers):
        return {
            "verdict": "PASS",
            "outcome": "EXISTING",
            "reason": "The API itself was executed and reported that the requested object already exists. This is explicit same-call EXISTING evidence, not skipped/reused evidence from a prior run.",
            "nextAction": "Keep this API response as its own EXISTING evidence; do not inject a historical/package ID or skip the API in a later run.",
        }

    if business_success or owner == "WORKING" or classification == "PASS_SUCCESS":
        return {
            "verdict": "PASS",
            "outcome": "WORKED",
            "reason": "The response indicates the API operation completed successfully.",
            "nextAction": "Continue to the next configured step.",
        }

    if owner in {
        "MISSING_REQUIRED_ID_OR_CONFIG", "EXPECTED_DEPENDENCY_FAILURE",
        "API_DOC_OR_BACKEND_MISMATCH", "API_BACKEND_OR_ERROR_HANDLING",
        "API_CONTRACT_CLARIFICATION", "AUTH_OR_ENTITLEMENT",
        "USER_PAYLOAD_BUG", "NEEDS_REVIEW", "SKIPPED_DEPENDENCY",
    } or any(m in text for m in blocked_markers):
        return {
            "verdict": "BLOCKED",
            "outcome": "BLOCKER",
            "reason": str(item.get("issue") or "The response indicates a missing dependency, configuration, authorization, contract, or backend condition that prevents this step from being considered complete."),
            "nextAction": str(item.get("action") or item.get("action_required") or "Resolve the response condition, then retest this API."),
        }

    return {
        "verdict": "BLOCKED",
        "outcome": "NEEDS_REVIEW",
        "reason": str(item.get("issue") or "The response was received but does not prove that the API step is usable yet."),
        "nextAction": str(item.get("action") or item.get("action_required") or "Review the response and retest after the required correction."),
    }


def build_business_demo_summary(root: Path) -> Dict[str, Any]:
    root = Path(root)
    status = _load_json(root / "reports" / "uhal_end_to_end_status_latest.json", {})
    connection = _load_json(root / "reports" / "connection_check_latest.json", {})
    results = latest_agent_results(root)

    api_results: List[Dict[str, Any]] = []
    unique_steps = set()
    response_steps = set()
    skipped = 0
    live_attempts = 0
    response_issues = 0

    for index, item in enumerate(results, start=1):
        if not isinstance(item, dict):
            continue
        classification = str(item.get("classification") or "UNKNOWN")
        logical = _logical_step(item)
        if logical:
            unique_steps.add(logical)
        is_skipped = classification.startswith("SKIPPED_")
        if is_skipped:
            skipped += 1
        if item.get("status_code") is not None:
            live_attempts += 1
            if logical:
                response_steps.add(logical)
        ok = bool(item.get("business_success"))
        verdict = agent_response_verdict(item)
        if verdict.get("verdict") != "PASS":
            response_issues += 1
        api_results.append({
            "sequence": item.get("sequence") or index,
            "logicalStep": logical,
            "group": item.get("group") or "",
            "api": item.get("api") or logical,
            "attempt": item.get("attempt") or "",
            "method": item.get("method") or "",
            "url": item.get("url") or "",
            "http": item.get("status_code"),
            "classification": classification,
            "businessSuccess": ok,
            "agentVerdict": verdict.get("verdict"),
            "agentOutcome": verdict.get("outcome"),
            "agentReason": verdict.get("reason"),
            "agentNextAction": verdict.get("nextAction"),
            "elapsedMs": item.get("elapsed_ms"),
            "request": item.get("request_preview") or "",
            "response": item.get("response_preview") or item.get("error") or "",
            "owner": item.get("final_owner") or "",
            "issue": item.get("issue") or "",
            "action": item.get("action") or item.get("action_required") or "",
        })

    total_api_elapsed_ms = sum(int(item.get("elapsedMs") or 0) for item in api_results)
    slowest_step = max(api_results, key=lambda item: int(item.get("elapsedMs") or 0), default={})

    expected = set(STEP_DEFINITIONS.keys())
    coverage_missing = sorted(expected - response_steps)
    coverage_complete = not coverage_missing and skipped == 0

    # Keep execution coverage separate from configuration/business validation.
    # The response analyst is authoritative for the business verdict: an
    # already-existing object is PASS/EXISTING even when the raw create call
    # returned a non-2xx technical status.
    verdict_pass = sum(1 for item in api_results if item.get("agentVerdict") == "PASS")
    verdict_blocked = sum(1 for item in api_results if item.get("agentVerdict") == "BLOCKED")
    business_success = bool(api_results) and verdict_blocked == 0

    checks = [
        {
            "label": "Service credentials and agent tools",
            "ok": connection.get("overall") == "OK",
            "classification": connection.get("overall") or "NOT_CHECKED",
        },
        {
            "label": "All configured API building blocks called",
            "ok": coverage_complete,
            "classification": "COMPLETE" if coverage_complete else "INCOMPLETE",
        },
        {
            "label": "No API was reused/skipped",
            "ok": skipped == 0,
            "classification": "0_SKIPPED" if skipped == 0 else f"{skipped}_SKIPPED",
        },
        {
            "label": "Business/configuration verification",
            "ok": business_success,
            "classification": "PASS" if business_success else "ATTENTION",
        },
    ]

    input_data = _load_json(root / "input.json", {})

    return {
        "generatedAt": dt.datetime.now().isoformat(),
        "customer": input_data.get("customer") or "Current configuration",
        "flow": input_data.get("profile_name") or "",
        "direction": input_data.get("direction") or "",
        "agentPassCount": verdict_pass,
        "agentBlockedCount": verdict_blocked,
        # For the Studio, success means the requested API coverage completed.
        "success": coverage_complete,
        "businessSuccess": business_success,
        "coverageComplete": coverage_complete,
        "checks": checks,
        "expectedLogicalApis": len(expected),
        "logicalApisObserved": len(expected & unique_steps),
        "logicalApisWithHttpResponse": len(expected & response_steps),
        "liveApiCalls": live_attempts,
        "existingObjectsReused": 0,
        "skippedApiCalls": skipped,
        "responseIssueCount": response_issues,
        "missingLogicalApis": coverage_missing,
        "unresolved": status.get("unresolvedRequiredSteps") or [],
        "runtimeIds": status.get("runtimeIds") or {},
        "technicalStatus": status,
        "apiResults": api_results,
        "totalApiElapsedMs": total_api_elapsed_ms,
        "slowestApi": slowest_step.get("api") if slowest_step else "",
        "slowestApiElapsedMs": slowest_step.get("elapsedMs") if slowest_step else 0,
    }


def _pretty_json_or_text(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, indent=2, default=str)
    raw = str(value or "")
    try:
        parsed = json.loads(raw)
        return json.dumps(parsed, indent=2, default=str)
    except Exception:
        return raw


def write_business_demo_report(root: Path, summary: Dict[str, Any]) -> Path:
    """Business-friendly full API evidence report.

    Every API section contains the redacted request sent and response received.
    This is intentionally more detailed than the earlier validation-only demo
    because the live API outputs are now the building-block evidence for future
    interfaces/customers.
    """
    root = Path(root)
    reports = root / "reports"
    reports.mkdir(exist_ok=True)
    path = reports / "HIP_API_Testing_Area_Full_Live_Report.html"

    input_data = _load_json(root / "input.json", {})
    config = _load_json(root / "config_overrides.json", {})
    objects = input_data.get("objects") or {}
    source_tp = objects.get("source_transport_profile") or {}
    biz = objects.get("biz_flow") or {}
    src_flow = (biz.get("configure_source") or {}).get("source_transport_profile") or ""
    tgt_flow = (biz.get("configure_targets") or {}).get("target_transport_profile") or ""

    coverage_complete = bool(summary.get("coverageComplete"))
    business_success = bool(summary.get("businessSuccess"))
    customer = str(summary.get("customer") or input_data.get("customer") or "Current configuration")
    headline = (
        f"{customer} API execution completed"
        if coverage_complete
        else f"{customer} API execution coverage is incomplete"
    )
    subline = (
        "Every configured HIP API building block was attempted live. Request and response evidence is available below."
        if coverage_complete
        else "One or more configured APIs were not called. Review the missing-step evidence below."
    )

    summary_rows = []
    evidence_blocks = []
    for item in summary.get("apiResults") or []:
        http_status = item.get("http")
        http_text = "—" if http_status is None else str(http_status)
        verdict = str(item.get("agentVerdict") or "BLOCKED").upper()
        outcome = str(item.get("agentOutcome") or "NEEDS_REVIEW").upper()
        state_class = "pass" if verdict == "PASS" else "blocked"
        state_text = f"{verdict} · {outcome}"
        summary_rows.append(
            "<tr>"
            f"<td>{html.escape(str(item.get('sequence') or ''))}</td>"
            f"<td>{html.escape(str(item.get('api') or ''))}</td>"
            f"<td><code>{html.escape(str(item.get('method') or ''))}</code></td>"
            f"<td>{html.escape(http_text)}</td>"
            f"<td><span class='pill {state_class}'>{html.escape(state_text)}</span></td>"
            f"<td>{html.escape(str(item.get('agentReason') or ''))}</td>"
            f"<td>{html.escape(str(item.get('classification') or ''))}</td>"
            f"<td>{html.escape(str(item.get('elapsedMs') or '0'))} ms</td>"
            "</tr>"
        )
        req = _pretty_json_or_text(redact_sensitive(item.get("request") or ""))
        resp = _pretty_json_or_text(redact_sensitive(item.get("response") or ""))
        evidence_blocks.append(
            f"""
            <details class="api-card">
              <summary>
                <span class="seq">{html.escape(str(item.get('sequence') or ''))}</span>
                <span><b>{html.escape(str(item.get('api') or ''))}</b><small>{html.escape(str(item.get('method') or ''))} · HTTP {html.escape(http_text)} · {html.escape(str(item.get('classification') or ''))}</small></span>
              </summary>
              <div class="api-body">
                <div class="meta"><b>Endpoint</b><code>{html.escape(str(item.get('url') or ''))}</code></div>
                <div class="meta-grid">
                  <div><b>Elapsed</b><span>{html.escape(str(item.get('elapsedMs') or '—'))} ms</span></div>
                  <div><b>Agent owner</b><span>{html.escape(str(item.get('owner') or '—'))}</span></div>
                  <div><b>Agent response verdict</b><span class="verdict-text {('pass' if str(item.get('agentVerdict')).upper() == 'PASS' else 'blocked')}">{html.escape(str(item.get('agentVerdict') or 'BLOCKED'))} · {html.escape(str(item.get('agentOutcome') or 'NEEDS_REVIEW'))}</span></div>
                </div>
                <div class="response-analysis"><b>Agent response analysis</b><p>{html.escape(str(item.get('agentReason') or item.get('issue') or 'No additional issue identified.'))}</p><b>What happens next</b><p>{html.escape(str(item.get('agentNextAction') or item.get('action') or 'No action required.'))}</p></div>
                <div class="two-col">
                  <div><h4>Request sent</h4><pre>{html.escape(req)}</pre></div>
                  <div><h4>Response received</h4><pre>{html.escape(resp)}</pre></div>
                </div>
                <div class="diagnosis"><b>Technical classification</b><p>{html.escape(str(item.get('classification') or ''))}</p><b>Raw owner diagnosis</b><p>{html.escape(str(item.get('issue') or 'No additional issue identified.'))}</p></div>
              </div>
            </details>
            """
        )

    verification_text = "PASS" if business_success else "ATTENTION"
    verification_class = "pass" if business_success else "attention"
    safe_summary = redact_sensitive(summary)

    path.write_text(
        f"""<!doctype html>
<html><head><meta charset="utf-8"><title>HIP API Testing Area Report</title>
<style>
:root{{--navy:#071d38;--blue:#0b5cab;--cyan:#0a8791;--line:rgba(173,196,216,.48);--muted:#64748b;--green:#148447;--amber:#b76b00;--red:#b42318;--glass:rgba(255,255,255,.72)}}
*{{box-sizing:border-box;min-width:0}}html,body{{overflow-x:hidden}}body{{margin:0;background:radial-gradient(circle at 8% 0%,rgba(60,197,213,.20),transparent 27%),radial-gradient(circle at 95% 7%,rgba(37,99,235,.13),transparent 23%),linear-gradient(180deg,#eef8ff,#f8fbff 48%,#eef4f9);color:#162033;font-family:Segoe UI,Arial,sans-serif}}
.hero{{position:relative;overflow:hidden;padding:38px 42px;color:white;background:linear-gradient(135deg,rgba(6,27,54,.95),rgba(11,92,171,.92) 64%,rgba(10,135,145,.91));border-bottom:1px solid rgba(255,255,255,.18);box-shadow:0 18px 60px rgba(9,48,84,.16)}}
.hero:after{{content:"";position:absolute;width:300px;height:300px;border-radius:50%;right:-80px;top:-150px;background:rgba(255,255,255,.14)}}.hero h1{{margin:0;font-size:clamp(1.55rem,4vw,2.05rem);position:relative;z-index:1}}.hero p{{max-width:900px;color:#dceeff;margin:.65rem 0 0;position:relative;z-index:1}}
main{{max-width:1180px;margin:auto;padding:26px 22px 70px}}.card,.api-card{{background:var(--glass);border:1px solid var(--line);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);box-shadow:0 12px 34px rgba(13,42,73,.07)}}.card{{border-radius:22px;padding:21px;margin:15px 0}}
.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:11px}}.metric{{background:rgba(248,251,254,.75);border:1px solid #dce8f2;border-radius:16px;padding:15px;overflow:hidden}}.metric span{{color:var(--muted);font-size:.8rem}}.metric b{{display:block;font-size:clamp(1rem,2vw,1.28rem);color:#082b53;margin-top:4px;overflow-wrap:anywhere}}
.table-wrap{{width:100%;overflow-x:auto;border-radius:14px}}table{{width:100%;min-width:760px;border-collapse:collapse}}th{{text-align:left;background:rgba(234,243,251,.8);padding:11px;color:#173754}}td{{padding:10px 11px;border-top:1px solid #edf1f5;vertical-align:top}}code{{font-family:Consolas,monospace;overflow-wrap:anywhere}}
.pill{{display:inline-block;border-radius:999px;padding:4px 8px;font-size:.7rem;font-weight:800}}.pill.pass{{background:#e9f8ef;color:#146638}}.pill.blocked{{background:#feeceb;color:#9f261d}}.pill.attention{{background:#fff3dc;color:#8a5700}}.verdict-text{{font-weight:900}}.verdict-text.pass{{color:#146638}}.verdict-text.blocked{{color:#9f261d}}
.api-card{{border-radius:17px;margin:10px 0;overflow:hidden}}.api-card summary{{display:flex;align-items:center;gap:12px;cursor:pointer;padding:14px 16px;background:rgba(251,253,255,.72)}}.api-card summary small{{display:block;color:var(--muted);font-weight:500;margin-top:3px;overflow-wrap:anywhere}}.seq{{display:inline-flex;flex:0 0 31px;width:31px;height:31px;border-radius:50%;align-items:center;justify-content:center;background:#0b5cab;color:white;font-weight:850}}
.api-body{{padding:17px}}.meta code{{display:block;background:rgba(244,247,250,.82);border-radius:9px;padding:9px;margin-top:5px;word-break:break-all}}.meta-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:12px 0}}.meta-grid div{{background:rgba(247,250,252,.76);border-radius:10px;padding:10px}}.meta-grid span{{display:block;color:#526579;margin-top:3px}}
.two-col{{display:grid;grid-template-columns:1fr;gap:12px}}h4{{margin:10px 0 7px}}pre{{margin:0;background:#081624;color:#dbeafe;padding:13px;border-radius:12px;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;max-height:520px;overflow:auto;font-size:.76rem}}.response-analysis{{margin-top:14px;background:rgba(239,248,255,.82);border-left:5px solid #0a8791;padding:13px 15px;border-radius:11px}}.response-analysis p,.diagnosis p{{margin:4px 0 10px;color:#53657a}}.diagnosis{{margin-top:14px;background:rgba(248,251,254,.78);border-left:4px solid #0b5cab;padding:12px 14px;border-radius:10px}}
.tech-details{{margin-top:15px}}.tech-details summary{{cursor:pointer;font-weight:800;color:#244f72;padding:5px}}
@media(min-width:1100px){{.two-col{{grid-template-columns:1fr 1fr}}}}
@media(max-width:650px){{main{{padding:18px 10px 50px}}.hero{{padding:26px 18px}}.card{{padding:15px;border-radius:17px}}.metrics{{grid-template-columns:1fr 1fr}}}}
</style></head><body>
<div class="hero"><h1>{html.escape(headline)}</h1><p>{html.escape(subline)}</p></div>
<main>
<div class="card"><h2>Business scenario</h2><div class="metrics">
<div class="metric"><span>Customer / configuration</span><b>{html.escape(str(summary.get('customer') or input_data.get('customer') or 'Current configuration'))}</b></div>
<div class="metric"><span>Interface</span><b>{html.escape(str(source_tp.get('interface_type') or 'SFTP HAFT'))}</b></div>
<div class="metric"><span>Deployment</span><b>{html.escape(str(source_tp.get('deployment_group') or config.get('source_deployment_group_name') or 'hip-automation'))}</b></div>
<div class="metric"><span>Source shared TP</span><b style="font-size:.8rem">{html.escape(str(src_flow))}</b></div>
<div class="metric"><span>Target shared TP</span><b style="font-size:.8rem">{html.escape(str(tgt_flow))}</b></div>
</div></div>
<div class="card"><h2>Execution coverage</h2><div class="metrics">
<div class="metric"><span>Expected logical APIs</span><b>{summary.get('expectedLogicalApis', 18)}</b></div>
<div class="metric"><span>Logical APIs observed</span><b>{summary.get('logicalApisObserved', 0)}</b></div>
<div class="metric"><span>Live API attempts</span><b>{summary.get('liveApiCalls', 0)}</b></div>
<div class="metric"><span>Skipped APIs</span><b>{summary.get('skippedApiCalls', 0)}</b></div>
<div class="metric"><span>Business verification</span><b class="{verification_class}">{verification_text}</b></div>
<div class="metric"><span>Agent PASS verdicts</span><b>{summary.get('agentPassCount', 0)}</b></div>
<div class="metric"><span>Agent BLOCKED verdicts</span><b>{summary.get('agentBlockedCount', 0)}</b></div>
</div></div>
<div class="card"><h2>Agent response analysis & verdict</h2><p style="color:#64748b">The agent interprets the response separately from the raw HTTP status. Existing/duplicate objects are PASS; missing or unresolved dependencies are BLOCKED.</p><div class="table-wrap"><table><thead><tr><th>#</th><th>API</th><th>Method</th><th>HTTP</th><th>Agent verdict</th><th>Why</th><th>Technical classification</th></tr></thead><tbody>{''.join(summary_rows)}</tbody></table></div></div>
<div class="card"><h2>Live request and response evidence</h2><p style="color:#64748b">Expand any API to see the redacted payload/query sent and the response received. Secrets/tokens remain redacted.</p>{''.join(evidence_blocks)}</div>
<details class="card tech-details"><summary>Technical execution state — project team only</summary><pre>{html.escape(json.dumps(safe_summary, indent=2, default=str))}</pre></details>
</main></body></html>""",
        encoding="utf-8",
    )
    return path
