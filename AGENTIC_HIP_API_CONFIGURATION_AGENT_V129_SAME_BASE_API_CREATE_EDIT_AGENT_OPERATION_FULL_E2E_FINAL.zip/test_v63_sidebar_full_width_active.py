from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSS = (ROOT / 'webapp' / 'frontend' / 'src' / 'styles.css').read_text(encoding='utf-8')


def test_expanded_sidebar_navigation_rows_fill_available_width():
    assert '.nav-group{margin:3px 0 9px;width:100%;min-width:0}' in CSS
    assert '.nav-item{width:100%;align-self:stretch;' in CSS
    assert 'box-sizing:border-box' in CSS


def test_collapsed_sidebar_remains_compact():
    assert '.sidebar-collapsed .nav-item{width:46px;height:42px;' in CSS


def test_mobile_drawer_restores_full_width_rows():
    assert '.sidebar-collapsed .nav-item{width:100%;height:auto;' in CSS
