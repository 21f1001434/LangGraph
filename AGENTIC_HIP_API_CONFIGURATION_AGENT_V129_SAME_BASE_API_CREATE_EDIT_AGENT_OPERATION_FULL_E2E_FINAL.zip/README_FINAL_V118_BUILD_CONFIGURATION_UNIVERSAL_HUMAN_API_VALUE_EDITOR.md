# V118 — Build Configuration Universal Human API Value Editor

## What changed

V118 moves the governed payload-value editing workflow directly into **Build Configuration**.

After the customer configuration is built and required decisions are resolved, Build Configuration now contains:

**STEP 4 · OPTIONAL HUMAN EDIT — Edit values for any HIP API**

The human user can:

1. Select any API from the canonical API catalog.
2. Select an existing payload/parameter attribute path.
3. See the generated value and current effective value.
4. Enter the value they want.
5. Save only that selected value and immediately revalidate.
6. Restore the selected value to the generated value.
7. Restore all saved human value edits for the selected API.

## Hard governance rule

The editor is **VALUE ONLY**.

The human user may change an existing scalar value, but cannot:

- rename an attribute;
- add an attribute;
- delete an attribute;
- change object nesting;
- change array cardinality;
- change request kind;
- change the HTTP method or URL;
- change contract-governed/protected headers.

The Build Configuration UI exposes the attribute as a selector/read-only path and exposes a separate value control. It does not expose a raw JSON payload editor in Build Configuration.

The backend independently verifies exact object keys, nesting and array cardinality before a value edit is accepted. Therefore UI manipulation cannot bypass the canonical request structure lock.

## Human versus agent authority

- **Human user:** may explicitly persist an existing canonical payload/parameter value before LIVE.
- **AutoGen / Dell-AIA / AI agent:** may inspect, explain, recommend and validate only. It has no authority to save/apply a payload value edit.
- Persisted edits are LIVE-eligible only when `editOrigin == USER`.
- Explicit payload-edit actions require the human edit action marker and reject agent identities.
- The final LIVE materialized request remains protected by the immutable request fingerprint.

UI wording was also corrected so it no longer says that the agent saves a human correction. The user saves; the agent only revalidates.

## Any API, not Transport Profile only

The editor works against the generated canonical request for every applicable API in the API catalog, including payload-based and params-based requests.

For Transport Profile requests, the existing V117 universal contract remains unchanged:

- SFTP HAFT / U-HAUL / LEGRAND, FTP, HTTPS, HTTPS-AS2 and future Dev-approved interfaces retain the same outer Transport Profile attributes/nesting.
- Interface-specific differences remain confined to `transportProfileDetails[0].interfaceDetails`.
- A human Source/Target `transportProfileName` edit is synchronized into canonical configuration so dependent TP validation/create/audit references stay consistent.

## Value types

The editor supports existing scalar leaves as text/string, number, boolean or null values. Changing a scalar value/type does not change the API attribute structure; normal contract validation still decides whether the user-entered value is acceptable for that field.

Secrets/password/token/certificate-like paths use a password-style input control in the UI.

## Validation completed

Focused and broader checks performed on V118:

- V118 + V117 focused human-value-editor tests: **22/22 PASS**
- Targeted structure/editor/regression batch: **53/53 PASS**
- FastAPI/backend tests: **48/48 PASS**
- Package validator: **59/59 PASS**
- Adaptive package validator: **60/60 PASS**
- Business readiness: **70/70 PASS**
- Modified TypeScript files isolated syntax transpilation: **PASS**

`final_self_check.py` reports the Phase-6 frontend-toolchain advisory as unavailable in the validation container because Bun is not installed there. This is an environment/tooling advisory, not a V118 application regression. The Python/backend/package/business validators above all passed.

## Plain HTTPS Receiver boundary

V118 does not change the V117 plain HTTPS Receiver Dev-validation boundary. The candidate still omits:

- `SSL Certificate`
- `SSL Certificate CN - Expiry`
- `SSL Certificate Id`

for **plain HTTPS Receiver**, pending Dev/API-team confirmation. HTTPS-AS2 remains a separate unchanged certificate/encryption/verification contract.
