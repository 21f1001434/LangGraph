# HIP Application Studio V29 — Windows Artifact Portability Fix

V29 keeps the full V28 solution and fixes the two Windows-side regression failures seen in `test_v27_input_json_plus_artifacts.py`.

- No test depends on Linux `/mnt/data` paths.
- Legrand-style XBM/JAR/XML regression fixtures are generated inside pytest temporary directories on Windows/Linux.
- `input.json + supporting artifacts` can recover a blank `map_data_file` from the single uploaded JAR filename in the current manifest.
- Explicit `input.json` map-data values are never overwritten.
- All V28 multi-source, Translation/Passthrough, Scratch/Game, 18-API, Learn, OAuth/readiness and live-only behavior remains intact.
