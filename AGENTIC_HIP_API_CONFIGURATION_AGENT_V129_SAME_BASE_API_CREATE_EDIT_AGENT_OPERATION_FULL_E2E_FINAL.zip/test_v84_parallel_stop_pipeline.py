from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

import pytest

from webapp.backend.app.parallel_manager import ParallelCancelled, ParallelManager
from webapp.backend.app.storage import JsonStore

ROOT = Path(__file__).resolve().parent


def _workspace(root: Path, customer: str) -> Path:
    ws = root / customer
    for name in ("input_files", "payloads", "reports"):
        (ws / name).mkdir(parents=True, exist_ok=True)
    (ws / "input.json").write_text(json.dumps({
        "customer": customer,
        "direction": "Outbound",
        "tx_code": "856",
        "flow_type": "translation",
        "profile_name": f"{customer}_856",
    }), encoding="utf-8")
    return ws


def _queued(manager: ParallelManager, tmp_path: Path, count: int = 3):
    validation = {"ok": True, "requests": {"ok": True, "validCount": 18, "total": 18}}
    ws = _workspace(tmp_path, "U-HAUL")
    cfg = {"id": "cfg", "workspace": str(ws), "customer": "U-HAUL", "name": "U-HAUL"}
    return [manager.queue_configuration(cfg, validation, f"Instance {i}", i, count) for i in range(1, count + 1)]


def _wait_completed(manager: ParallelManager, batch_id: str, timeout: float = 5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        row = manager.get_batch(batch_id)
        if str(row.get("status") or "").upper() == "COMPLETED":
            return row
        time.sleep(0.02)
    raise AssertionError(f"batch did not complete: {manager.get_batch(batch_id)}")


def test_v84_summary_persistence_failure_cannot_block_8_worker_start(tmp_path: Path, monkeypatch):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queued(manager, tmp_path / "source", 8)
    started: list[str] = []

    monkeypatch.setattr(manager, "_persist_batch_best_effort", lambda *args, **kwargs: False)

    def fake_run(batch_id, manifest, loop):
        started.append(str(manifest["jobId"]))
        manager._publish(batch_id, {"type": "job.started", "jobId": manifest["jobId"], "label": manifest["label"], "customer": manifest["customer"]}, loop)
        result = {"jobId": manifest["jobId"], "label": manifest["label"], "customer": manifest["customer"], "status": "PASS", "elapsedSeconds": 0.01}
        manager._publish(batch_id, {"type": "job.completed", **result}, loop)
        return result

    monkeypatch.setattr(manager, "_run_one", fake_run)
    loop = asyncio.new_event_loop()
    try:
        batch = manager.start_batch([x["jobId"] for x in jobs], 8, loop)
        final = _wait_completed(manager, batch["batchId"])
        assert len(started) == 8
        assert final["configurationCount"] == 8
        assert final["passCount"] == 8
        assert final["blockedCount"] == 0
    finally:
        loop.close()


def test_v84_stop_batch_cancels_running_and_queued_instances(tmp_path: Path, monkeypatch):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queued(manager, tmp_path / "source", 4)

    def fake_run(batch_id, manifest, loop):
        job_id = str(manifest["jobId"])
        manager._publish(batch_id, {"type": "job.started", "jobId": job_id, "label": manifest["label"], "customer": manifest["customer"]}, loop)
        deadline = time.time() + 3
        while time.time() < deadline:
            if manager._batch_stop_event(batch_id).is_set() or manager._job_stop_event(batch_id, job_id).is_set():
                raise ParallelCancelled("Stopped by user")
            time.sleep(0.01)
        return {"jobId": job_id, "status": "PASS", "elapsedSeconds": 3}

    monkeypatch.setattr(manager, "_run_one", fake_run)
    loop = asyncio.new_event_loop()
    try:
        batch = manager.start_batch([x["jobId"] for x in jobs], 2, loop)
        time.sleep(0.08)
        manager.stop_batch(batch["batchId"], loop)
        final = _wait_completed(manager, batch["batchId"])
        assert final["cancelledCount"] == 4
        assert final["overallVerdict"] == "CANCELLED"
    finally:
        loop.close()


def test_v84_pipeline_preflights_every_payload_before_first_live_call(tmp_path: Path, monkeypatch):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queued(manager, tmp_path / "source", 3)
    preflighted: list[str] = []
    live_called: list[str] = []

    def fake_preflight(batch_id, manifest, loop):
        preflighted.append(str(manifest["jobId"]))
        if len(preflighted) == 2:
            raise RuntimeError("payload 2 preflight failed")
        return {"ready": True}

    def fake_live(*args, **kwargs):
        live_called.append("called")
        return {"status": "PASS"}

    monkeypatch.setattr(manager, "_preflight_only_one", fake_preflight)
    monkeypatch.setattr(manager, "_run_one", fake_live)
    loop = asyncio.new_event_loop()
    try:
        batch = manager.start_batch([x["jobId"] for x in jobs], 1, loop, batch_kind="PIPELINE", preflight_all=True, stop_on_error=True, pipeline_id="pipe_test")
        final = _wait_completed(manager, batch["batchId"])
        assert len(preflighted) == 2
        assert live_called == []
        assert final["blockedCount"] == 1
        assert final["skippedCount"] == 2
        assert final["batchKind"] == "PIPELINE"
    finally:
        loop.close()



def test_v84_stop_single_instance_does_not_cancel_sibling(tmp_path: Path, monkeypatch):
    manager = ParallelManager(JsonStore(tmp_path / "runtime"))
    jobs = _queued(manager, tmp_path / "source", 2)

    def fake_run(batch_id, manifest, loop):
        job_id = str(manifest["jobId"])
        manager._publish(batch_id, {"type": "job.started", "jobId": job_id, "label": manifest["label"], "customer": manifest["customer"]}, loop)
        deadline = time.time() + 0.35
        while time.time() < deadline:
            if manager._job_stop_event(batch_id, job_id).is_set():
                raise ParallelCancelled("Stopped by user")
            time.sleep(0.01)
        result = {"jobId": job_id, "label": manifest["label"], "customer": manifest["customer"], "status": "PASS", "elapsedSeconds": 0.35}
        manager._publish(batch_id, {"type": "job.completed", **result}, loop)
        return result

    monkeypatch.setattr(manager, "_run_one", fake_run)
    loop = asyncio.new_event_loop()
    try:
        batch = manager.start_batch([x["jobId"] for x in jobs], 2, loop)
        time.sleep(0.06)
        manager.stop_job(batch["batchId"], jobs[0]["jobId"], loop)
        final = _wait_completed(manager, batch["batchId"])
        statuses = {r["jobId"]: r["status"] for r in final["results"]}
        assert statuses[jobs[0]["jobId"]] == "CANCELLED"
        assert statuses[jobs[1]["jobId"]] == "PASS"
        assert final["cancelledCount"] == 1
        assert final["passCount"] == 1
    finally:
        loop.close()

def test_v84_pipeline_and_stop_controls_are_exposed_in_react_and_api():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    manager = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert "RUN LIVE EXECUTION" in page
    assert "PIPELINE EXECUTION" in page
    assert "RUN VALIDATED PIPELINE LIVE" in page
    assert "STOP BATCH" in page and "Stop instance" in page
    assert "stopParallelBatch" in api and "runPipeline" in api
    assert '/api/parallel/batches/{batch_id}/stop' in main
    assert '/api/pipelines/{pipeline_id}/run' in main
    assert "preflight_all" in manager and "batch.preflight_all_passed" in manager
    assert "summary.json.tmp" not in manager
