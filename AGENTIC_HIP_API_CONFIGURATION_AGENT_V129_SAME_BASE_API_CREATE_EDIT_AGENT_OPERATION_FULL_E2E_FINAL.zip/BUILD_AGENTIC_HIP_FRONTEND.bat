@echo off
setlocal
cd /d "%~dp0"
where bun >nul 2>nul
if errorlevel 1 (
  echo Bun is required. Install Bun and reopen this terminal.
  exit /b 1
)
pushd webapp\frontend
bun install || (popd & exit /b 1)
bun run build || (popd & exit /b 1)
popd
python runtime_preflight.py --production
exit /b %errorlevel%
