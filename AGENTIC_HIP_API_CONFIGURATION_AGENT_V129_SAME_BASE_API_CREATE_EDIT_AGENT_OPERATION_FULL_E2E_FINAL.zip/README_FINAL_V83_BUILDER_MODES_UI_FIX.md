# HIP API Agent Studio V83 — Builder Modes & Sidebar UI Fix

## Purpose
V83 makes **Build Configuration** the safe central workspace for all configuration lifecycle actions while retaining the V82 Windows runtime hardening, global customer selector, immutable developer-approved U-HAUL baseline, evidence/conflict gate, 18-API contract locks, API Testing, Flow Game, execution, reporting, and parallel-agent functionality.

## Build Configuration now has three explicit workflows

### 1. Create New
- Opens a clean blank customer configuration form.
- The globally selected customer is context only and is **not edited**.
- The new configuration is created only when the user starts ingest/build.
- After creation it becomes the working editable configuration.

### 2. Clone Existing
- Opens a popup listing all available configurations, including U-HAUL.
- The user can set the copy name before cloning.
- The backend creates a separate configuration ID and separate workspace.
- The source configuration is never changed.
- A clone must be validated again after customer-specific changes.
- This is the correct path for **Create from U-HAUL**.

### 3. Edit Existing
- Opens a selection + confirmation popup before any saved configuration enters edit mode.
- The popup clearly warns that existing customer values/files may change and validation must be run again.
- Clicking **Yes, edit this configuration** is required before the existing configuration is loaded into the editor.
- Changing the global Active Customer does not silently enter edit mode.
- If Active Customer changes while an edit is open, the Builder safely returns to Create New rather than editing the newly selected customer.

## U-HAUL protection
The packaged U-HAUL reference remains:

**DEV APPROVED · TEST READY · 18/18**

- U-HAUL is not editable.
- Edit Existing refuses the approved reference.
- Create from U-HAUL / Clone Existing creates an editable independent copy.
- The approved baseline payload/request structures remain unchanged.

## Sidebar overflow fix
V83 hardens the sidebar for normal Dell laptop resolutions:
- Brand title/subtitle wrap within the available width.
- Navigation labels are constrained to a maximum of two lines.
- Long text uses safe wrapping and ellipsis/clamping.
- Sidebar children use `min-width: 0` so flex/grid text cannot force horizontal overflow.
- Sidebar horizontal overflow is hidden while vertical navigation remains scrollable.
- The 1280px breakpoint uses a slightly wider, better-proportioned navigation rail.
- Mobile navigation retains the existing drawer behavior.

## Existing functionality preserved
- Global Active Customer dropdown.
- V82 writable runtime selection/fallback and OneDrive/LocalAppData hardening.
- Developer-approved U-HAUL materialization.
- Customer-file evidence extraction.
- File value vs user selection conflict popup/decision gate.
- Canonical `input.json` generation.
- 18 HIP API non-mutating validation.
- Canonical API payload structure lock.
- Interface-specific approved payload shapes.
- API Testing Area.
- API Flow Game.
- Parallel / Execution Center.
- Operations and reports.
- Mapping learning.
- LIVE preflight and execution protections.

## Payload safety
V83 does **not** loosen API payload controls.

- The 18 approved request structures remain fixed.
- New/invented attributes are not allowed to mutate the developer-approved API contract.
- Customer-specific values may change only inside an editable customer configuration/clone.
- The original U-HAUL reference remains immutable.

## Validation
- Targeted V77–V83 regression: **35/35 PASS**
- Application tests: **273/273 PASS**
- FastAPI/backend tests: **48/48 PASS**
- Total automated application/backend tests: **321/321 PASS**
- Phase 6 package checks: **38/38 PASS**
- Package validation: **57/57 PASS**
- Final required self-checks: **43/43 PASS**
- Adaptive package validation: **60/60 PASS**
- Frontend TS/TSX dependency-independent transpilation: **24/24 PASS**
- Full Vite/TypeScript project build: **not run in this sandbox because frontend npm dependencies are not installed**. The source transpilation check is dependency-independent and passed all 24 source files.

## Recommended upgrade
Extract V83 into a fresh folder and run it instead of copying individual files over V82. The V82 runtime hardening remains in this release.
