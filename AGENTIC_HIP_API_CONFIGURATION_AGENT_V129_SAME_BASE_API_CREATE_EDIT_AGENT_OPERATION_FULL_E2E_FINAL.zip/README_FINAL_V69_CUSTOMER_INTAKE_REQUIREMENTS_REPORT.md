# V69 — Customer Intake / Required Values HTML Report

V69 adds a plain-language customer-intake report generated from the exact canonical `input.json`, file-mapping evidence, deterministic builder audit and unresolved Input Builder questions.

## What the report answers

- What values HIP needs and what each means in business language.
- Which values were extracted from the uploaded customer files and from which evidence file.
- Which values were derived automatically by deterministic agent/HIP rules.
- Which values are already present in an approved input/configuration.
- Which values the user still has to provide and why the agent cannot safely guess them.
- Which values are secure runtime/environment prerequisites and are not stored in reusable templates/reports.
- The proven U-HAUL reference value alongside every applicable field, including approved DUNS `12345666`.
- What can generally be extracted from XML/cXML, X12, EDIFACT, XBM, JAR, Configuration Manual and approved input.json files.

## UI / persistence

After every successful Build Configuration run and after Apply Answers, the latest HTML + JSON report is automatically persisted into the customer `reports/` folder. Build Configuration shows an intake summary and a **Download Required Values HTML** action. The same report is visible from the normal Reports page.

The report is regenerated on demand and after validation/inline repair so it reflects the current canonical customer state.

## Safety

- U-HAUL values are examples only and are not copied to a new customer unless an existing deterministic Dev-approved rule already does so.
- Secrets are redacted and described as runtime-only inputs.
- `workType` is explicitly shown as HIP-managed, not a customer/user value.
- This report does not bypass the final pre-LIVE contract validation or production preflight.
