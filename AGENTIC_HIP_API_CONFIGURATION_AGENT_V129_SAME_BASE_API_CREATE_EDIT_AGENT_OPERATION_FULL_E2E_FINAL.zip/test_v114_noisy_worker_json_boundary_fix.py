from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace


def test_v114_shared_parser_extracts_authoritative_json_after_noisy_stdout():
    from webapp.backend.app.legacy_adapter import parse_worker_json_output

    payload = {"ok": True, "requests": {"validCount": 18, "total": 18}, "nested": {"a": 1}}
    noisy = (
        "OAuth diagnostic persistence warning: managed Windows file temporarily locked\n"
        "MCP warning: local-function-fallback active\n"
        + json.dumps(payload, indent=2)
        + "\n"
    )
    assert parse_worker_json_output(noisy, label="test") == payload


def test_v114_parser_ignores_ansi_and_json_log_fragments():
    from webapp.backend.app.legacy_adapter import parse_worker_json_output

    tiny_log = json.dumps({"warning": "fallback"})
    payload = {"overall": "OK", "secureConnectionsOk": True, "apiExecutionPlan": {"executeSteps": list(range(18))}}
    noisy = f"\x1b[33mwarning\x1b[0m {tiny_log}\n{json.dumps(payload, indent=2)}\n"
    assert parse_worker_json_output(noisy, label="readiness")["secureConnectionsOk"] is True


def test_v114_connection_readiness_accepts_noisy_current_worker_output(monkeypatch, tmp_path: Path):
    from webapp.backend.app import legacy_adapter

    payload = {"overall": "OK", "secureConnectionsOk": True, "flowConfigurationValid": True}
    monkeypatch.setattr(
        legacy_adapter.subprocess,
        "run",
        lambda *a, **k: SimpleNamespace(returncode=0, stdout="diagnostic line\n" + json.dumps(payload, indent=2), stderr=""),
    )
    assert legacy_adapter.connection_readiness(tmp_path) == payload


def test_v114_agent_validation_accepts_noisy_worker_stdout(monkeypatch, tmp_path: Path):
    from webapp.backend.app import phase2_service

    payload = {"ok": True, "generatedAt": "now", "requests": {"validCount": 18, "total": 18, "applicableCount": 18}}
    monkeypatch.setattr(
        phase2_service.subprocess,
        "run",
        lambda *a, **k: SimpleNamespace(returncode=0, stdout="benign warning before result\n" + json.dumps(payload, indent=2), stderr=""),
    )
    monkeypatch.setattr(phase2_service, "attach_inline_validation_repairs", lambda workspace, value: value)
    assert phase2_service.validate_configuration(tmp_path)["requests"]["validCount"] == 18


def test_v114_api_preview_accepts_noisy_worker_stdout(monkeypatch, tmp_path: Path):
    from webapp.backend.app import legacy_adapter

    payload = {"items": [{"stepKey": "validate_source", "applicable": True}]}
    monkeypatch.setattr(
        legacy_adapter.subprocess,
        "run",
        lambda *a, **k: SimpleNamespace(returncode=0, stdout="warning\n" + json.dumps(payload), stderr=""),
    )
    assert legacy_adapter.preview_api_requests(tmp_path) == payload


def test_v114_machine_readable_persistence_warnings_use_stderr():
    source = Path(__file__).with_name("run_agent.py").read_text(encoding="utf-8")
    assert 'OAuth diagnostic persistence warning:' in source
    assert 'LIVE response evidence persistence warning:' in source
    assert 'file=sys.stderr' in source


def test_v114_favicon_is_non_error_response():
    from fastapi.testclient import TestClient
    from webapp.backend.app.main import app

    response = TestClient(app).get("/favicon.ico")
    assert response.status_code == 204


def test_v114_parallel_uses_effective_normalized_flow_in_results():
    source = Path(__file__).with_name("webapp").joinpath("backend", "app", "parallel_manager.py").read_text(encoding="utf-8")
    assert '"effectiveFlowName": effective_flow_name' in source
    assert 'manifest["flow"] = effective_flow_name' in source
