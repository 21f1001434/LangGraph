from __future__ import annotations

import json
import py_compile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    guided = ROOT / "adaptive_uhal_app.py"
    advanced = ROOT / "legacy_pages" / "90_Advanced_Technical_Workspace.py"
    py_compile.compile(str(guided), doraise=True)
    py_compile.compile(str(advanced), doraise=True)
    text = guided.read_text(encoding="utf-8")
    advanced_text = advanced.read_text(encoding="utf-8")
    required = [
        "HIP Configuration Studio",
        "Ask the agent to guide me",
        "I want to create a new configuration",
        "I already have an input JSON",
        "I already have API payloads",
        "Teach the agent using your API documentation",
        "Tell the agent in normal language",
        "Do any of these already exist?",
        "How cautious should the timing be?",
        "Final check before anything changes",
        "Run safe preflight",
        "Run the live HIP configuration",
        "Advanced Technical Workspace",
    ]
    missing = [token for token in required if token not in text]
    assert not missing, missing
    for token in [
        "Payload Studio",
        "Execution Flow & Timing",
        "Ask Dell AIA to review/fix",
        "API Execution Plan",
        "Wait after (seconds)",
    ]:
        assert token in advanced_text, token
    output = {
        "status": "PASS",
        "guidedUiBuild": "2026-08-11-full-application-studio-v9",
        "guidedStages": 5,
        "agentHelpAtEveryStage": True,
        "advancedWorkspacePreserved": True,
        "payloadStudioPreserved": True,
        "pdfUploadPreserved": True,
        "plainLanguagePatchFlow": True,
        "simpleTimingPresets": ["Recommended", "Fast", "Careful"],
        "advancedIndividualApiTiming": True,
    }
    path = ROOT / "examples" / "LAYMAN_GUIDED_UI_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
