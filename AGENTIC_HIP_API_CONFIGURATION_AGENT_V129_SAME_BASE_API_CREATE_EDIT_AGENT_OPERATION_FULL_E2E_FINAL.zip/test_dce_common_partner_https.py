from __future__ import annotations

import json
from pathlib import Path

from configuration_workspace import default_flow_tp_references
from run_agent import Runner
from transport_interface_react import TransportInterfaceReActAgent, interface_shared_profiles

ROOT = Path(__file__).resolve().parent


def main() -> None:
    baseline = json.loads((ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8"))
    config = json.loads((ROOT / "dev_approved" / "UHAL_config_dev_approved.json").read_text(encoding="utf-8"))

    src = baseline["objects"]["source_transport_profile"]
    tgt = baseline["objects"]["target_transport_profile"]
    flow = baseline["objects"]["biz_flow"]

    assert src["deployment_group"] == "hip-automation"
    assert tgt["deployment_group"] == "hip-automation"
    assert config["source_deployment_group_name"] == "hip-automation"
    assert config["target_deployment_group_name"] == "hip-automation"
    assert flow["configure_source"]["source_transport_profile"] == "da-sender-sftphaft-dce-common"
    assert flow["configure_targets"]["target_transport_profile"] == "pt-receiver-sftphaft-dce-common"
    assert flow["configure_routing"]["actions"]["target"] == "pt-receiver-sftphaft-dce-common"

    assert interface_shared_profiles("SFTP") == {
        "source": "da-sender-sftphaft-dce-common",
        "target": "pt-receiver-sftphaft-dce-common",
    }
    assert interface_shared_profiles("FTP") == {
        "source": "da-sender-sftphaft-dce-common",
        "target": "pt-receiver-sftphaft-dce-common",
    }
    assert interface_shared_profiles("HTTPS") == {
        "source": "da-sender-https-dce-common",
        "target": "pt-receiver-https-dce-common",
    }
    assert default_flow_tp_references("SFTP")["source"] == "da-sender-sftphaft-dce-common"
    assert default_flow_tp_references("HTTPS")["target"] == "pt-receiver-https-dce-common"

    # Generated U-HAUL requests must carry the latest common deployment group and profile refs.
    runner = Runner(llm_enabled=False)
    source_tp = runner.preview_step_request("source_tp")["payload"]
    target_tp = runner.preview_step_request("target_tp")["payload"]
    assert source_tp["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"
    assert target_tp["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"

    flow_payload = runner.preview_step_request("flow_create")["payload"]
    flow_definition = json.loads(flow_payload["flowDefinition"])
    assert flow_definition["sourceDetails"]["sourceTransportProfile"] == ["da-sender-sftphaft-dce-common"]
    assert flow_definition["targetDetails"]["targets"][0]["targetTransportProfile"] == "pt-receiver-sftphaft-dce-common"
    assert flow_definition["ruleDetails"][0]["actions"][0]["target"] == "pt-receiver-sftphaft-dce-common"

    # HTTPS Receiver: Partner-owned values are mandatory; certificate values are pending/not invented.
    agent = TransportInterfaceReActAgent(ROOT, baseline)
    incomplete = agent.analyze(
        source_interface="SFTP",
        target_interface="HTTPS",
        target_parameters={
            "Protocol": "REST",
            "Request Method": "POST",
            "Request Format": "Request Body",
            "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "URL will be shared later after API Publish is successful.",
            "Are Input Files Compressed?": "False",
        },
    )
    fields = {q["field"] for q in incomplete["questions"]}
    expected_partner = {
        "Partner URL",
        "Receiver Grant Type",
        "Receiver Token Endpoint",
        "Receiver Client Id",
        "Receiver Client Secret",
    }
    assert expected_partner <= fields
    assert "SSL Certificate" not in fields
    assert "SSL Certificate CN - Expiry" not in fields
    assert "SSL Certificate Id" not in fields

    complete_params = {
        "Protocol": "REST",
        "Partner URL": "https://partner.example",
        "Request Method": "POST",
        "Request Format": "Request Body",
        "Receiver Authentication Type": "OAuth2",
        "Gateway URL": "URL will be shared later after API Publish is successful.",
        "Are Input Files Compressed?": "False",
        "Receiver Grant Type": "partner-grant",
        "Receiver Token Endpoint": "https://partner.example/oauth/token",
        "Receiver Client Id": "partner-client",
        "Receiver Client Secret": "{{runtime_payload.target.receiver_client_secret}}",
    }
    proposal = agent.propose(
        source_interface="SFTP",
        target_interface="HTTPS",
        target_parameters=complete_params,
    )
    assert proposal["valid"] is True, proposal
    assert proposal["targetSharedProfile"] == "pt-receiver-https-dce-common"
    assert proposal["deploymentGroup"] == "hip-automation"
    assert proposal["proposal"]["objects"]["biz_flow"]["configure_targets"]["target_transport_profile"] == "pt-receiver-https-dce-common"

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "uhalSftpDeploymentGroup": "hip-automation",
        "uhalSourceFlowProfile": "da-sender-sftphaft-dce-common",
        "uhalTargetFlowProfile": "pt-receiver-sftphaft-dce-common",
        "httpsSourceFlowProfile": "da-sender-https-dce-common",
        "httpsTargetFlowProfile": "pt-receiver-https-dce-common",
        "partnerOwnedHttpsFieldsRequired": sorted(expected_partner),
        "certificateDetailsStatus": "PENDING_DELL_TEAM_CONFIRMATION_NOT_INVENTED",
        "uhalGeneratedRequestsValidated": True,
    }
    path = ROOT / "examples" / "DCE_COMMON_PARTNER_HTTPS_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
