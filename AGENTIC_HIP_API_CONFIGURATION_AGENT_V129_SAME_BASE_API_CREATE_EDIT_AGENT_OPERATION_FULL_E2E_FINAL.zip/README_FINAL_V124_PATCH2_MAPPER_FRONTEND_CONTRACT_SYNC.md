# V124 Patch 2 — Excel Mapper Frontend Contract Sync

## Why this patch exists

The reported build moved from 3 `BuilderPage.tsx` errors to 12 `ExcelApiMapperPage.tsx` errors because the working folder contained a mixed frontend: the mapper page was from the newer V123/V124 feature set while `src/types.ts` and/or `src/lib/api.ts` were from an older baseline.

The 12 reported errors were:

- missing `IntelligentMapperResult` export;
- missing `IntelligentMappingRow` export;
- missing `api.analyzeWorkbook` method;
- nine downstream TS7006 implicit-any callback errors in the mapper page.

## Fix

This package is rebuilt from the coherent V124 full baseline, not from V122 Patch 1.

The following files are synchronized as one contract:

- `webapp/frontend/src/types.ts`
  - exports `IntelligentMappingStatus`
  - exports `IntelligentColumnMapping`
  - exports `IntelligentApiAlternative`
  - exports `IntelligentMappingRow`
  - exports `IntelligentMapperResult`
- `webapp/frontend/src/lib/api.ts`
  - imports `IntelligentMapperResult`
  - exposes typed `api.analyzeWorkbook(...)`
  - sends the exact backend form fields: `workbook`, `api_key`, `sheet_name`, `header_row`, `use_dell_aia`
- `webapp/frontend/src/pages/ExcelApiMapperPage.tsx`
  - retains the shared mapper result types
  - explicitly types mapper callbacks so strict TypeScript cannot degrade them to implicit `any`
- `webapp/frontend/src/pages/BuilderPage.tsx`
  - retains the V124 `useMemo` / `ApiCatalogItem[]` production build fix.

## Backend parity

The client method matches the packaged FastAPI route:

`POST /api/configurations/{cid}/intelligent-mapper/analyze`

with `UploadFile workbook` and the form fields listed above.

## Governance unchanged

This patch does not change the HIP API contract or execution policy. Mapper analysis is non-mutating. Agent-prepared values can persist only after explicit human **Approve & Stage**. API attributes, nesting, HTTP method, endpoint, and protected structure remain immutable. LIVE still requires preflight and explicit user confirmation.

## Validation

- Strict TypeScript semantic check of `types.ts + lib/api.ts + ExcelApiMapperPage.tsx`: **0 errors**.
- V117–V124 focused + mapper backend + Patch 2 contract-sync tests: **74/74 PASS**.
- `validate_package.py`: **59/59 PASS**.
- `validate_adaptive_package.py`: **60/60 PASS**.
- `BUSINESS_READINESS_VALIDATION.py`: **70/70 PASS**.
- `FINAL_RELEASE_VALIDATION.py`: **16/16 PASS**.
- `final_self_check.py`: **44/45**; the only failed advisory is `bun=false` in the validation container. No application/contract check failed.

## Important upgrade instruction

For the full package, extract into a **new empty folder**. Do not copy it over the previously mixed V122/V123/V124 tree.

Then run:

```powershell
cd webapp\frontend
bun install
bun run build
```

Or run `VERIFY_V124_PATCH2_FRONTEND.ps1` from the package root.
