# V129 — Same Base API Create/Edit + Governed Agent Operation Control

## What changed

V129 implements the Dev confirmation that **Edit uses the same base API as Create** for the operation-capable orchestration contracts. No alternate Edit URL is introduced.

- `source_tp`: POST to the existing Transport Profile orchestration `/create` endpoint. `operation` and `transportProfileOperation` change together between Create/Edit.
- `target_tp`: same rule as Source TP.
- `flow_create`: POST to the existing Flow orchestration `/create` endpoint. Only the existing `operation` value changes.
- Account, Partner, System, Document Type, Map, Rule, Flow Deploy and audit/history contracts are not given invented Edit fields.
- If a human value override creates conflicting TP operation values, V129 fails closed before HTTP rather than sending a mixed Create/Edit request.
- Edit mode bypasses legacy create-skip reuse behavior for the operation-capable step, ensuring the Edit API invocation actually occurs.
- TP audit verification follows the effective Create/Edit operation instead of hard-coding CREATE history.

## Agent authority

The agent gets one narrow governed write capability: `set_api_operation_mode(step_key, mode)` for `source_tp`, `target_tp`, and `flow_create` only. It can set `inherit`, `create`, or `edit`. Method, endpoint, headers, OAuth profile, request kind, payload keys, nesting, array cardinality, Migration ON/OFF, ordering, waits and ordinary business values remain outside this agent write capability.

The same selector is exposed through the FastAPI route:

`PUT /api/configurations/{configuration_id}/api-operation/{step_key}`

Human execution-flow edits record their operation source as `user`; MCP/agent edits record `agent`.

## Interface correction retained

For HTTPS-AS2 Receiver/Target, `interfaceDetails.parameters` requires:

`"SSL Certificate": "dellroot_ca_6_able.crt"`

A human may change the existing value when required by the customer/environment; the field itself remains schema-locked.

## Evidence/no-fabrication hardening retained

V128/V127 behavior remains active:

- Document Type name/version are independent evidence-backed values.
- Missing Document Type, Map, Rule and Flow versions stay blank and become preflight/HITL blockers; no silent `1`/`1.0` fabrication.
- XML Sender/Receiver routing values are not Partner Create DUNS values.
- `dce-test-partner` retains the Dev-approved shared UAT identifier `12345666` as an explicit partner mapping.
- Migration remains explicitly human-controlled and, when enabled, participates in final business success.

## Verification performed for V129

- Root Python regression: 548 tests passed across clean grouped runs.
- FastAPI backend regression: 55/55 passed.
- Package validator: 59/59 passed.
- Adaptive validator: 60/60 passed.
- Business readiness: 70/70 passed.
- Final release validator: 16/16 passed.
- TypeScript/TSX syntax/transpile parse: 26 files, 0 diagnostics.
- Deterministic mocked Runner Create path: 18/18 logical APIs, success.
- Deterministic mocked Runner Edit path: 18/18 logical APIs; Source TP, Target TP and Flow use their original `/create` endpoints with Edit operation values; success.
- Deterministic mocked Migration path: 25/25 logical APIs = 18 base + 7 Migration; success.

Real Dell HIP DEV/LIVE network execution is not claimed here because Dell OAuth/network access is unavailable in this environment.
