from __future__ import annotations

import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from execution_flow import ExecutionFlowConfig, STEP_DEFINITIONS
from migration_api_contract import MIGRATION_ORDER, MIGRATION_STEP_DEFINITIONS
from payload_overrides import PayloadOverrideStore
from run_agent import Runner
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app import main as main_app
from webapp.backend.app.excel_api_mapper import analyze_workbook
from webapp.backend.app.legacy_adapter import preview_all_api_requests

ROOT = Path(__file__).resolve().parent


class _Store:
    def __init__(self, root: Path):
        self.root = Path(root)


def _minimal_workspace(path: Path, tp_name: str = "SFTP_LEGRAND_NEDERLAND_PC_SRC_IB_01") -> Path:
    path.mkdir(parents=True, exist_ok=True)
    (path / "input_files").mkdir(exist_ok=True)
    (path / "payloads").mkdir(exist_ok=True)
    (path / "reports").mkdir(exist_ok=True)
    payload = {
        "customer": "LEGRAND",
        "direction": "Outbound",
        "tx_code": "856",
        "flow_type": "Translation",
        "profile_name": "LEGRAND_FLOW",
        "objects": {
            "source_transport_profile": {"profile_name": tp_name},
            "target_transport_profile": {"profile_name": "SFTP_LEGRAND_NEDERLAND_PC_TGT_OB_01"},
        },
    }
    (path / "input.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def test_v125_keeps_historical_18_flow_definition_but_composes_25_when_migration_is_requested(tmp_path, monkeypatch):
    assert len(STEP_DEFINITIONS) == 18
    assert len(MIGRATION_STEP_DEFINITIONS) == 7
    runner = Runner.__new__(Runner)
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    runner.include_migration_in_full_live = True
    runner.payload_overrides = PayloadOverrideStore(tmp_path)
    rows = [
        {"stepKey": row["stepKey"], "order": row["order"], "waitAfterSeconds": row.get("waitAfterSeconds", 0)}
        for row in runner.execution_flow.summary()["liveSteps"]
    ]
    from execution_flow import save_execution_flow
    save_execution_flow(tmp_path, rows, migration_enabled=True)
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    order = Runner.ordered_live_steps(runner)
    assert len(order) == 25
    assert order[:18] == runner.execution_flow.ordered_steps()
    assert order[18:] == MIGRATION_ORDER


def test_v125_ready_queue_snapshot_refreshes_after_human_legrand_tp_edit(tmp_path):
    store = _Store(tmp_path / "runtime")
    manager = ParallelManager(store)
    source = _minimal_workspace(tmp_path / "source")
    configuration = {"id": "cfg-legrand", "workspace": str(source), "customer": "LEGRAND", "name": "LEGRAND_FLOW"}
    validation = {"ok": True, "requests": {"validCount": 18, "total": 18}, "migration": {"requested": False, "ready": False}, "fullLiveReady": True}
    queued = manager.queue_configuration(configuration, validation)
    queued_input = Path(queued["workspace"]) / "input.json"
    assert json.loads(queued_input.read_text())["objects"]["source_transport_profile"]["profile_name"].endswith("_01")

    data = json.loads((source / "input.json").read_text())
    data["objects"]["source_transport_profile"]["profile_name"] = "SFTP_LEGRAND_NEDERLAND_PC_SRC_IB_99"
    (source / "input.json").write_text(json.dumps(data, indent=2), encoding="utf-8")

    refreshed = manager.refresh_ready_jobs_for_configuration(configuration, validation)
    assert queued["jobId"] in refreshed["refreshed"]
    after = json.loads(queued_input.read_text())
    assert after["objects"]["source_transport_profile"]["profile_name"] == "SFTP_LEGRAND_NEDERLAND_PC_SRC_IB_99"
    manifest = json.loads((queued_input.parent.parent / "manifest.json").read_text())
    assert manifest["status"] == "READY"
    assert manifest["snapshotSha256"]


def test_v125_blocked_validation_marks_refreshed_queue_needs_revalidation(tmp_path):
    store = _Store(tmp_path / "runtime")
    manager = ParallelManager(store)
    source = _minimal_workspace(tmp_path / "source")
    configuration = {"id": "cfg-legrand", "workspace": str(source), "customer": "LEGRAND", "name": "LEGRAND_FLOW"}
    ready = {"ok": True, "requests": {"validCount": 18, "total": 18}, "migration": {"requested": False}, "fullLiveReady": True}
    queued = manager.queue_configuration(configuration, ready)
    blocked = {"ok": False, "requests": {"validCount": 17, "total": 18}, "migration": {"requested": False}, "fullLiveReady": False}
    result = manager.refresh_ready_jobs_for_configuration(configuration, blocked)
    assert queued["jobId"] in result["blocked"]
    manifest = json.loads((manager.queue_root / queued["jobId"] / "manifest.json").read_text())
    assert manifest["status"] == "NEEDS_REVALIDATION"
    assert manifest["validated"] is False


def test_v125_whole_payload_lock_accepts_values_and_rejects_attribute_or_array_changes():
    base = {"operation": "create", "items": [{"name": "A", "enabled": True}]}
    changed_values = {"operation": "edit", "items": [{"name": "B", "enabled": False}]}
    assert main_app._exact_same_structure(base, changed_values) is True
    assert main_app._exact_same_structure(base, {**changed_values, "invented": 1}) is False
    assert main_app._exact_same_structure(base, {"operation": "edit", "items": []}) is False
    assert main_app._exact_same_structure(base, {"operation": "edit", "items": [{"renamed": "B", "enabled": False}]}) is False


def test_v125_migration_environment_sync_changes_only_existing_environment_values(monkeypatch, tmp_path):
    items = []
    for key in MIGRATION_ORDER:
        generated = {"sourceEnvironment": "DEV", "targetEnvironment": "", "identity": key}
        items.append({
            "stepKey": key, "applicable": True, "requestKind": "payload",
            "generatedPayload": dict(generated), "payload": dict(generated),
        })
    monkeypatch.setattr(main_app, "preview_all_api_requests", lambda _ws: {"items": items})
    calls = []
    monkeypatch.setattr(main_app, "save_override", lambda workspace, step, value, **kw: calls.append((step, value, kw)) or {"count": len(calls)})
    monkeypatch.setattr(main_app, "clear_override", lambda *a, **k: {"count": 0})
    syncs = main_app._sync_migration_environment_values(tmp_path, "migrate_flow", {"sourceEnvironment": "DEV", "targetEnvironment": "TEST2", "identity": "migrate_flow"})
    assert len(calls) == 7
    assert {step for step, _, _ in calls} == set(MIGRATION_ORDER)
    for step, diffs, kw in calls:
        assert diffs["targetEnvironment"] == "TEST2"
        assert set(diffs).issubset({"targetEnvironment"})
        assert kw["edit_origin"] == "USER"
    assert all(row["field"] == "targetEnvironment" for row in syncs)


def test_v125_create_edit_ui_changes_only_existing_operation_fields():
    builder = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    shared = (ROOT / "webapp/frontend/src/components/HumanPayloadValueEditor.tsx").read_text(encoding="utf-8")
    for source in (builder, shared):
        assert "Set EDIT operation" in source
        assert "keyNorm==='operation'||keyNorm.endsWith('operation')" in source
        assert "No existing create/edit operation" in source or "no existing create/edit operation" in source.lower()
        assert "payload-json-editor" in source
    # Backend generated TP/Flow contracts already contain the Dev-confirmed operation fields.
    run_source = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert '"transportProfileOperation": "create"' in run_source
    assert '"operation": "Create"' in run_source
    assert '"operation": "create"' in run_source


def test_v125_file_contract_preserves_v7_move_to_archive_capitalization():
    runner = Runner.__new__(Runner)
    tp = {
        "interface_type": "SFTP",
        "post_transfer_action": "Move to Archive",
        "interface_parameters": {},
        "existing_account": "Yes",
    }
    params = Runner.tp_parameters(runner, tp, "source")
    assert params["Post Transfer Action"] == "Move To Archive"
    assert Runner.tp_interface_type(runner, tp) == "SFTP HAFT"


def test_v125_excel_lens_name_is_reference_only_and_duplicate_rows_merge():
    preview = preview_all_api_requests(ROOT)
    csv_data = (
        "Source System,LENS TP Name,Source Interface Type,Document Type Name,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,LENS_REFERENCE_ONLY,SFTP,XML_ACME_ASN_10(1.0),acme-account,/Outbound/ASN,acme-account\n"
    ).encode()
    one = analyze_workbook(filename="lens.csv", data=csv_data, preview_items=preview["items"], selected_api="source_tp", use_dell_aia=False)
    row = one["results"][0]
    assert row["status"] != "GOOD_TO_TRIGGER"
    assert row["proposedRequest"]["transportProfileDetails"][0]["transportProfileName"] != "LENS_REFERENCE_ONLY"
    assert "transportProfileDetails.0.transportProfileName" in row.get("inheritedIdentityPaths", [])
    assert not any(m.get("sourceColumn") == "LENS TP Name" and m.get("targetPath", "").endswith("transportProfileName") for m in row.get("mappings", []))

    csv_dupes = (
        "Source System,DEV Transport Profile Name,Source Interface Type,Document Type Name,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10(1.0),acme-account,/Outbound/ASN,acme-account\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10(1.0),acme-account,/Outbound/ASN,acme-account\n"
    ).encode()
    dupes = analyze_workbook(filename="dupes.csv", data=csv_dupes, preview_items=preview["items"], selected_api="source_tp", use_dell_aia=False)
    assert len(dupes["results"]) == 1
    assert any("Merged 2 exact duplicate" in str(x) for x in dupes["results"][0].get("warnings", []))
