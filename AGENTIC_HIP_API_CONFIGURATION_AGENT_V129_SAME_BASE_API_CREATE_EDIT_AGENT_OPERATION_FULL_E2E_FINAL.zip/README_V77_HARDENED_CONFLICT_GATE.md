# V77 Hardened — Customer Evidence vs User Selection Decision Gate

This package keeps the V77 conflict UI and adds downstream enforcement so the application cannot continue with an unresolved customer-file vs operator-selection disagreement.

## Final behavior

When an operator explicitly changes a protected Build Configuration field and deterministic customer evidence contains a different value, Build Configuration enters `NEEDS_INPUT` and shows the conflict side by side:

1. **CUSTOMER FILE EVIDENCE** — value, source file, per-candidate confidence, and extraction/mapping rule when available.
2. **YOUR SELECTED VALUE** — the value explicitly selected or typed by the operator.
3. **OTHER APPROVED VALUE** — a free-form business-approved replacement.

The operator can choose **Use file value**, **Keep selected value**, or enter and choose **Use custom value**. The chosen value is written into canonical `input.json`, the conflict is removed, and `_builder_audit.selection_conflict_resolutions` records the decision source and both competing values.

## Hard gate

Until all required decisions are resolved, the backend blocks downstream progression even if someone bypasses the normal UI navigation or uses a direct endpoint. The gate covers:

- API Testing Area request preview and preflight
- LIVE API Testing Area calls
- payload override editing/revalidation
- API Flow Game preflight, node checks, autofix, and LIVE graph execution
- mapping learner promotion
- parallel queue and parallel instance creation
- final 18-API validation (already enforced by V77)

The React **Open API Flow Game** button is also disabled while required questions/conflicts remain.

## Interface conflict fix

If the decision changes an interface (for example customer evidence says `HTTPS` while the operator selected `SFTP`), the effective source/target interface is recalculated immediately after the decision and before enrichment/question generation. This prevents stale SFTP/FTP defaults from being injected into an HTTPS/AS2 decision.

## Validation performed

- Full Python regression suite: **297 passed / 0 failed**
- Targeted V77/V78 conflict tests: **11 passed / 0 failed**
- `final_self_check.py`: **43 required checks passed / 0 failed**
- `validate_adaptive_package.py`: **60 passed / 0 failed**
- Python compilation: **PASS**
- TypeScript/TSX dependency-independent syntax transpilation: **23 source files PASS**

### Frontend environment advisory

The sandbox did not contain Bun or `node_modules`. An `npm install` attempt timed out, so a dependency-resolved Vite production bundle could not be executed in this environment. The TypeScript/TSX source itself was syntax-transpiled successfully. Run the normal frontend dependency install/build in the target Windows environment to perform the final dependency-resolved bundle check.
