$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Frontend = Join-Path $Root 'webapp\frontend'
$Types = Get-Content (Join-Path $Frontend 'src\types.ts') -Raw
$Api = Get-Content (Join-Path $Frontend 'src\lib\api.ts') -Raw
$Page = Get-Content (Join-Path $Frontend 'src\pages\ExcelApiMapperPage.tsx') -Raw
$Builder = Get-Content (Join-Path $Frontend 'src\pages\BuilderPage.tsx') -Raw

$Checks = @(
  @{ Name='IntelligentMapperResult export'; Ok=($Types -match 'export type IntelligentMapperResult') },
  @{ Name='IntelligentMappingRow export'; Ok=($Types -match 'export type IntelligentMappingRow') },
  @{ Name='analyzeWorkbook API method'; Ok=($Api -match 'analyzeWorkbook:async') },
  @{ Name='typed mapper API result'; Ok=($Api -match 'request<IntelligentMapperResult>') },
  @{ Name='mapper page shared types'; Ok=(($Page -match 'IntelligentMapperResult') -and ($Page -match 'IntelligentMappingRow')) },
  @{ Name='V124 Builder useMemo fix'; Ok=(($Builder -match 'useMemo<ApiCatalogItem\[\]>') -and ($Builder -match 'useEffect, useMemo, useState')) }
)

$Failed = $Checks | Where-Object { -not $_.Ok }
$Checks | ForEach-Object { Write-Host (('[{0}] {1}' -f ($(if($_.Ok){'PASS'}else{'FAIL'})), $_.Name)) }
if ($Failed.Count -gt 0) { throw "Frontend source contract is not synchronized. Failed checks: $($Failed.Name -join ', ')" }

if (-not (Get-Command bun -ErrorAction SilentlyContinue)) { throw 'Bun is not available in PATH.' }
Push-Location $Frontend
try {
  Write-Host '[RUN] bun run build'
  bun run build
  if ($LASTEXITCODE -ne 0) { throw "bun run build failed with exit code $LASTEXITCODE" }
} finally { Pop-Location }
Write-Host '[PASS] Frontend source contract and Bun production build passed.'
