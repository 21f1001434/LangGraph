from pathlib import Path

from webapp.backend.app.excel_api_mapper import analyze_workbook, mapping_score, _deterministic_column_map
from webapp.backend.app.legacy_adapter import preview_all_api_requests

ROOT = Path(__file__).resolve().parent


def preview():
    return preview_all_api_requests(ROOT)["items"]


def analyze(csv_text: str, api_key: str):
    return analyze_workbook(
        filename="document_mapping.csv",
        data=csv_text.encode("utf-8"),
        preview_items=preview(),
        selected_api=api_key,
        use_dell_aia=False,
    )["results"][0]


def test_v127_missing_document_version_never_inherits_or_fabricates_one():
    row = analyze(
        "Source System,DEV Transport Profile Name,Source Interface Type,Document Type Name,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10,acme-account,/Outbound/ASN,acme-account\n",
        "source_tp",
    )
    doc = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]
    assert doc["documentTypeName"] == "XML_ACME_ASN_10"
    assert doc["documentTypeVersion"] == ""
    assert "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion" in row["missingCriticalPaths"]
    assert row["status"] == "NEEDS_INPUT"
    assert row["documentEvidence"]["versionOrigin"] == "missing"
    assert row["documentEvidence"]["inheritedVersionSuppressed"] is True
    assert not any(m["targetPath"].endswith("documentTypeVersion") for m in row["mappings"])
    assert any("No default/inherited version" in w for w in row["warnings"])


def test_v127_name_parentheses_version_splits_exactly():
    row = analyze(
        "Source System,DEV Transport Profile Name,Source Interface Type,Document Type Name,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10(2.5),acme-account,/Outbound/ASN,acme-account\n",
        "source_tp",
    )
    doc = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]
    assert doc["documentTypeName"] == "XML_ACME_ASN_10"
    assert doc["documentTypeVersion"] == "2.5"
    assert row["documentEvidence"]["versionOrigin"] == "parsed-from-name"
    assert row["documentEvidence"]["versionSourceValue"] == "2.5"


def test_v127_explicit_version_wins_over_name_parentheses_version():
    row = analyze(
        "Source System,DEV Transport Profile Name,Source Interface Type,Document Type Name,Document Type Version,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,XML_ACME_ASN_10(2.5),3.1,acme-account,/Outbound/ASN,acme-account\n",
        "source_tp",
    )
    doc = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]
    assert doc["documentTypeName"] == "XML_ACME_ASN_10"
    assert doc["documentTypeVersion"] == "3.1"
    assert row["documentEvidence"]["versionOrigin"] == "explicit-column"


def test_v127_document_version_can_never_be_document_name():
    row = analyze(
        "Source System,DEV Transport Profile Name,Source Interface Type,Document Type Version,Hip Account names,Subscription Folder,Existing Account Name\n"
        "AIC - DCE,SFTP_ACME_ASN_SRC_OB,SFTP,2.5,acme-account,/Outbound/ASN,acme-account\n",
        "source_tp",
    )
    doc = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]
    assert doc["documentTypeName"] == ""
    assert doc["documentTypeVersion"] == "2.5"
    assert "transportProfileDetails.0.documentTypeDetails.0.documentTypeName" in row["missingCriticalPaths"]
    assert not any(m["sourceColumn"] == "Document Type Version" and m["targetPath"].endswith("documentTypeName") for m in row["mappings"])


def test_v127_version_like_value_in_name_column_is_rejected_as_name():
    row = analyze(
        "Document Type Name,Document Type Version\n"
        "1.0,2.0\n",
        "doctype_source",
    )
    assert row["proposedRequest"]["name"] == ""
    assert row["proposedRequest"]["version"] == "2.0"
    assert "name" in row["missingCriticalPaths"]
    assert any("version-like value" in w for w in row["warnings"])


def test_v127_rule_document_fields_do_not_overwrite_rule_identity():
    row = analyze(
        "Document Type Name,Document Type Version\n"
        "XML_ACME_ASN_10,4.0\n",
        "rule",
    )
    req = row["proposedRequest"]
    assert req["documentTypeName"] == "XML_ACME_ASN_10"
    assert float(req["documentTypeVersion"]) == 4.0
    assert req["name"] != "XML_ACME_ASN_10"
    assert float(req["version"]) != 4.0
    assert not any(m["sourceColumn"] == "Document Type Name" and m["targetPath"] == "name" for m in row["mappings"])
    assert not any(m["sourceColumn"] == "Document Type Version" and m["targetPath"] == "version" for m in row["mappings"])


def test_v127_standalone_document_type_maps_name_and_version_to_exact_leaves():
    row = analyze(
        "Document Type Name,Document Type Version\n"
        "XML_ACME_ASN_10,6.2\n",
        "doctype_source",
    )
    assert row["proposedRequest"]["name"] == "XML_ACME_ASN_10"
    assert row["proposedRequest"]["version"] == "6.2"
    pairs = {(m["sourceColumn"], m["targetPath"]) for m in row["mappings"]}
    assert ("Document Type Name", "name") in pairs
    assert ("Document Type Version", "version") in pairs


def test_v127_mapping_score_hard_blocks_name_version_cross_mapping():
    assert mapping_score("Document Type Version", "documentTypeName", "rule") == 0.0
    assert mapping_score("Document Type Name", "documentTypeVersion", "rule") == 0.0
    assert mapping_score("Document Type Version", "name", "doctype_source") == 0.0
    assert mapping_score("Document Type Name", "version", "doctype_source") == 0.0


def test_v127_llm_hint_cannot_bypass_document_name_version_guard():
    spec = {"apiKey": "rule", "paths": ["name", "version", "documentTypeName", "documentTypeVersion"]}
    hints = {
        ("rule", "Document Type Version"): {"path": "documentTypeName", "confidence": 1.0, "method": "Dell AIA"},
        ("rule", "Document Type Name"): {"path": "version", "confidence": 1.0, "method": "Dell AIA"},
    }
    result = _deterministic_column_map(["Document Type Version", "Document Type Name"], spec, hints)
    assert result["Document Type Version"]["path"] == "documentTypeVersion"
    assert result["Document Type Name"]["path"] == "documentTypeName"
