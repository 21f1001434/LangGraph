from __future__ import annotations
from copy import deepcopy
from typing import Any, Dict, Optional, Tuple

DEFAULT_DEPLOYMENT_GROUP = "hip-automation"


def _force_tp_group(value: Any) -> Any:
    if isinstance(value, dict):
        # Keep the canonical input key and force every known spelling if it is
        # already present. We never invent extra payload attributes; this only
        # normalizes values on approved keys.
        value["deployment_group"] = DEFAULT_DEPLOYMENT_GROUP
        for key in list(value.keys()):
            normalized = str(key).replace("_", "").replace("-", "").lower()
            if normalized in {"deploymentgroup", "deploymentgroupname"}:
                value[key] = DEFAULT_DEPLOYMENT_GROUP
    elif isinstance(value, list):
        for item in value:
            _force_tp_group(item)
    return value


def with_default_deployment_group(input_data: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Enforce the Dev-approved logical deployment group for every automation interaction."""
    data = deepcopy(input_data if isinstance(input_data, dict) else {})
    cfg = deepcopy(config if isinstance(config, dict) else {})
    objects = data.setdefault("objects", {})
    if isinstance(objects, dict):
        for key in ("source_transport_profile", "target_transport_profile"):
            tp = objects.get(key)
            if not isinstance(tp, (dict, list)):
                tp = {}
                objects[key] = tp
            _force_tp_group(tp)
    cfg["source_deployment_group_name"] = DEFAULT_DEPLOYMENT_GROUP
    cfg["target_deployment_group_name"] = DEFAULT_DEPLOYMENT_GROUP
    for key in list(cfg.keys()):
        normalized = str(key).replace("_", "").replace("-", "").lower()
        if normalized in {"sourcedeploymentgroup", "targetdeploymentgroup", "deploymentgroup", "deploymentgroupname"}:
            cfg[key] = DEFAULT_DEPLOYMENT_GROUP
    return data, cfg
