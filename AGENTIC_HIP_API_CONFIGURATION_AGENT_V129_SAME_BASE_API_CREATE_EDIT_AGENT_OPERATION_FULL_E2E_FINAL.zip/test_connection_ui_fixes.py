from __future__ import annotations

import json
from unittest.mock import patch

import run_agent


class _Response:
    status_code = 200
    ok = True
    text = json.dumps({"access_token": "test.jwt.token"})
    url = "https://example.dell.com/oauth/token"
    headers = {"Content-Type": "application/json"}
    history = []

    def json(self):
        return {"access_token": "test.jwt.token"}


class _Session:
    calls = 0
    last = None

    def __init__(self):
        self.trust_env = True
        self.request = None
        _Session.last = self

    def close(self):
        return None

    def post(self, url, **kwargs):
        _Session.calls += 1
        self.request = {"url": url, **kwargs}
        return _Response()


def _lightweight_runner():
    # Mirrors connection diagnostics that intentionally bypass Runner.__init__.
    runner = run_agent.Runner.__new__(run_agent.Runner)
    runner.hip_token_url = "https://example.dell.com/oauth/token"
    runner.hip_client_id = "client"
    runner.hip_client_secret = "secret"
    runner.hip_scope = ""
    return runner


def test_json_token_success_without_full_runner_init():
    run_agent.TOKEN_CACHE.clear()
    _Session.calls = 0
    runner = _lightweight_runner()
    # Explicitly remove any instance value. The class/default resolution path
    # must still provide a valid User-Agent and token bookkeeping.
    runner.__dict__.pop("hip_token_user_agent", None)
    runner.__dict__.pop("token_sources", None)

    with patch.object(run_agent.requests, "Session", _Session), patch.object(
        run_agent.requests.utils, "get_environ_proxies", return_value={}
    ):
        token = runner.get_token("HIP")

    assert token == "test.jwt.token"
    assert runner.token_sources["HIP"] == "oauth2-client-credentials-basic-auth"
    assert _Session.last.request["headers"]["User-Agent"] == run_agent.DEFAULT_HIP_TOKEN_USER_AGENT


def test_route_redirect_stops_redundant_auth_attempts():
    # allow_redirects=True means Requests owns the redirect chain; get_token
    # must issue one logical POST rather than retrying auth itself.
    run_agent.TOKEN_CACHE.clear()
    _Session.calls = 0
    runner = _lightweight_runner()
    runner.__dict__.pop("hip_token_user_agent", None)
    runner.__dict__.pop("token_sources", None)

    with patch.object(run_agent.requests, "Session", _Session), patch.object(
        run_agent.requests.utils, "get_environ_proxies", return_value={}
    ):
        assert runner.get_token("HIP") == "test.jwt.token"

    assert _Session.calls == 1
    assert _Session.last.request["allow_redirects"] is True
