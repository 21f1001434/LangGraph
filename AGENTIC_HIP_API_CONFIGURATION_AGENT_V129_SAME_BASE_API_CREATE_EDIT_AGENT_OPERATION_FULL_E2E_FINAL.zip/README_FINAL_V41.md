# Agentic HIP API Configuration Agent — V41 FINAL AUDITED

V41 is the final audited Phase 6 release built on V40 UX/LIVE-parallel hardening.

## Product aim

1. Build canonical `input.json` from customer files, Configuration Manual + files, or existing `input.json` + files.
2. Keep uploaded physical file evidence authoritative for XML/EDI/etc.
3. Map the canonical configuration to the 18 HIP API blocks.
4. Validate graph + API contracts before any LIVE mutation.
5. Execute one configuration LIVE with visible request/response/verdict/output/retries/timing.
6. Execute multiple independently validated configurations concurrently while preserving dependency order inside each configuration.
7. Save templates, reports, audit evidence, execution history and recovery checkpoints in the React/FastAPI product.

## Primary workflow

`Configuration Library → Build Configuration → resolve real questions → Map to 18 APIs + Agent Validate → API Flow Game → Agent auto-wire/preflight → Run LIVE → Operations/Reports`

For parallel execution:

`Validated configurations → Parallel Runs → Select all ready → choose 1–8 workers → RUN SELECTED LIVE IN PARALLEL → LIVE Parallel Board → per-job/per-step evidence`

## Important policies

- LIVE-only mutation path; preflight/inspection remains non-mutating.
- `hip-automation` is mandatory for automation transport profiles.
- Already-existing objects are `PASS / EXISTING`, not blockers.
- Missing prerequisites are `BLOCKED` and stop dependent steps.
- Translation and Passthrough stay distinct; unresolved Auto never assumes Translation.
- DUNS/certificate IDs/credentials and unknown business values are never invented.
- Outbound is only a UI convenience default; the user's Direction selection is authoritative.

## Final validation utility

Run before a demonstration or after moving the ZIP to another machine:

```bat
RUN_FINAL_RELEASE_VALIDATION.bat
```

It runs the quick packaged check and then the full pytest/validator/Phase 1–6 suites as separate processes. The quick check writes `FINAL_RELEASE_VALIDATION_RESULT.json`.

This cannot prove Dell-network LIVE behavior without the real authenticated Dell environment. Use **System & Connections** for OAuth/service readiness and then perform an approved LIVE smoke configuration.

## Start

First setup:

```bat
SETUP_AGENTIC_HIP.bat
```

Normal use:

```bat
RUN_AGENTIC_HIP.bat
```

Open `http://127.0.0.1:8765`.
