from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_windows_default_uses_clean_v82_runtime_and_deep_workspace_probe(tmp_path: Path):
    from webapp.backend.app.runtime_paths import resolve_runtime_root
    local = tmp_path / "LocalAppData"
    resolved = resolve_runtime_root(ROOT, environ={"LOCALAPPDATA": str(local)}, platform_name="windows", temp_root=tmp_path / "temp")
    assert resolved == (local / "HIP API Agent Studio" / "runtime-v82").resolve()
    assert not any((resolved / "configurations").glob(".__probe_*"))


def test_runtime_falls_back_when_local_appdata_cannot_be_used(tmp_path: Path):
    from webapp.backend.app.runtime_paths import resolve_runtime_root
    blocked = tmp_path / "not-a-directory"
    blocked.write_text("blocked", encoding="utf-8")
    fallback = tmp_path / "temp"
    resolved = resolve_runtime_root(ROOT, environ={"LOCALAPPDATA": str(blocked)}, platform_name="windows", temp_root=fallback)
    assert resolved == (fallback / "hip_api_agent_studio" / "runtime-v82").resolve()


def test_builder_restores_complete_workflow_even_when_uhal_is_active():
    source = (ROOT / "webapp" / "frontend" / "src" / "pages" / "BuilderPage.tsx").read_text(encoding="utf-8")
    assert "Build Configuration" in source
    assert "Create New" in source and "Clone Existing" in source and "Edit Existing" in source
    assert "STEP 1" in source and "Interaction" in source
    assert "STEP 2" in source and "Feed the agent" in source
    assert "Agent ingest → generate input.json" in source
    assert "Resolve evidence and missing values" in source
    assert "Map input.json → all 18 HIP APIs" in source
    assert "if(active&&approvedReference)return" not in source
    assert "if(active&&!approvedReference)return api.patchConfiguration" in source


def test_approved_uhal_materialization_no_longer_deletes_reference_evidence_folder():
    source = (ROOT / "webapp" / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    copy_start = source.index("def _copy_flow_reference_snapshot")
    copy_end = source.index("def _materialize_flow_source", copy_start)
    block = source[copy_start:copy_end]
    assert "dirs_exist_ok=True" in block
    assert "shutil.rmtree(dst)" not in block
    assert "except PermissionError" in block


def test_backend_uhal_and_parallel_sources_work_from_clean_runtime(tmp_path: Path):
    runtime = tmp_path / "runtime"
    code = r'''
from pathlib import Path
from fastapi.testclient import TestClient
from webapp.backend.app.main import app, RUNTIME_ROOT
c = TestClient(app)
rows = c.get('/api/configurations').json()
uhal = next(row for row in rows if row.get('approved_reference'))
assert uhal['status'] == 'DEV_APPROVED'
assert uhal['validation']['requests']['validCount'] == 18
ws = Path(uhal['workspace'])
assert ws.is_relative_to(Path(RUNTIME_ROOT))
assert (ws / 'input_files').is_dir()
ref = next(row for row in c.get('/api/parallel/sources').json() if row.get('sourceId') == 'reference:uhal')
assert ref['validated'] is True
assert ref['status'] == 'DEV_APPROVED'
assert ref['validCount'] == 18 and ref['totalContracts'] == 18
assert not ref.get('error')
'''
    env = dict(os.environ)
    env["HIP_STUDIO_RUNTIME_ROOT"] = str(runtime)
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), str(ROOT / "webapp" / "backend"), env.get("PYTHONPATH", "")])
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, text=True, capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr
