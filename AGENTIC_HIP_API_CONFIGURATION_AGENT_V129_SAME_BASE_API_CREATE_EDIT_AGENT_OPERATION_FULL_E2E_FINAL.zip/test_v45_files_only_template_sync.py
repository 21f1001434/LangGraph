import json
import shutil
from pathlib import Path

from input_builder_artifacts import build_profile_runner_manual_bytes
from test_v44_atea_passthrough_hardening import _atea_approved
from webapp.backend.app.legacy_adapter import build_configuration
from webapp.backend.app.storage import JsonStore
from webapp.backend.app.templates import generated_template_from_configuration


def test_files_only_auto_consumes_configuration_manual_and_ignores_fresh_card_defaults(tmp_path: Path):
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    (uploads / "ATEA_NORWAY_Configuration_Manual.xlsx").write_bytes(
        build_profile_runner_manual_bytes(_atea_approved())
    )
    result = build_configuration(
        tmp_path,
        {
            "input_mode": "files",
            "direction": "Outbound",      # untouched fresh-card defaults must not win
            "transaction_code": "999",
            "source_interface": "SFTP",
            "target_interface": "SFTP",
        },
        use_dell_aia=False,
    )
    data = result["input"]
    assert data["customer"] == "ATEA_NORWAY"
    assert data["direction"] == "Inbound"
    assert data["tx_code"] == "850"
    assert data["requires_data_map"] is False
    assert result["questions"] == []
    assert data["_builder_audit"]["automatic_configuration_manual"]["filename"].endswith(".xlsx")
    assert (tmp_path / "input.json").exists()


def test_raw_customer_files_only_build_without_input_json_and_do_not_use_workspace_id_as_customer(tmp_path: Path):
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    root = Path(__file__).resolve().parent
    for name in (
        "source_DellAutoASN.xml",
        "output_u-haul_ASN.xml",
        "DELLCoXMLASNXX08C.xbm",
        "Transform_DELLCoXMLASNXX08C.jar",
    ):
        shutil.copy2(root / "input_files" / name, uploads / name)

    result = build_configuration(
        tmp_path,
        {
            "input_mode": "files",
            "direction": "Inbound",       # evidence proves Outbound 856
            "transaction_code": "850",   # evidence proves 856
            "source_interface": "SFTP",
            "target_interface": "SFTP",
        },
        use_dell_aia=False,
    )
    data = result["input"]
    assert data["direction"] == "Outbound"
    assert data["tx_code"] == "856"
    assert data["requires_data_map"] is True
    assert data["objects"]["data_map"]["map_name"] == "DELLCoXMLASNXX08C"
    assert data["objects"]["data_map"]["map_data_file"] == "Transform_DELLCoXMLASNXX08C.jar"
    assert data.get("customer", "") != tmp_path.name
    # The builder may ask for genuinely absent business values and now also asks
    # for evidence-backed API object versions instead of silently defaulting them
    # to 1/1.0. It must not fall back to a long form asking for already-extracted
    # map/document names or formats.
    assert len(result["questions"]) <= 8
    asked = {q.get("path") for q in result["questions"]}
    assert "objects.source_document_type.version" in asked
    assert "objects.target_document_type.version" in asked
    assert "objects.data_map.map_identifier_version" in asked
    assert "objects.rule.version" in asked
    assert "objects.biz_flow.flow_details.current_flow_version" in asked
    assert "objects.data_map.map_name" not in asked
    assert "objects.data_map.map_data_file" not in asked
    assert "objects.source_document_type.data_format_type" not in asked
    assert (tmp_path / "input.json").exists()


def test_generated_template_tracks_final_received_values_and_excludes_secrets():
    data = _atea_approved()
    data["objects"]["source_transport_profile"]["interface_parameters"] = {
        "client_id": "safe-id",
        "client_secret": "DO-NOT-COPY",
        "password": "DO-NOT-COPY-2",
        "access_token": "DO-NOT-COPY-3",
    }
    tpl = generated_template_from_configuration("cfg123", data)
    defaults = tpl["default_values"]
    assert tpl["source_configuration_id"] == "cfg123"
    assert tpl["direction"] == "Inbound"
    assert tpl["transaction_code"] == "850"
    assert tpl["flow_type"] == "Passthrough"
    assert defaults["customer"] == "ATEA_NORWAY"
    assert defaults["source_transport_profile"] == "SFTP_ATEA_NORWAY_PO_PC_SRC_IB"
    assert defaults["target_folder"] == "/SFTP_ATEA_NORWAY_PO_PC_TGT_OB"
    blob = json.dumps(tpl)
    assert "DO-NOT-COPY" not in blob
    assert "client_secret" not in blob
    assert len(tpl["nodes"]) == 15


def test_template_store_persists_received_defaults_and_versions(tmp_path: Path):
    store = JsonStore(tmp_path / "runtime")
    payload = generated_template_from_configuration("cfg123", _atea_approved())
    first = store.save_template(payload, template_id="generated-cfg123")
    assert first["default_values"]["customer"] == "ATEA_NORWAY"
    changed = dict(payload)
    changed["default_values"] = dict(payload["default_values"])
    changed["default_values"]["target_folder"] = "/Inbound/PO"
    second = store.save_template(changed, template_id="generated-cfg123")
    assert second["version"] == 2
    assert second["default_values"]["target_folder"] == "/Inbound/PO"
    assert len(store.list_template_versions("generated-cfg123")) == 2


def test_backend_sync_reuses_customer_template_and_versions_only_on_change(tmp_path: Path, monkeypatch):
    from webapp.backend.app import main as main_module
    store = JsonStore(tmp_path / "main-runtime")
    monkeypatch.setattr(main_module, "STORE", store)
    first = main_module._sync_generated_template("cfg777", _atea_approved())
    same = main_module._sync_generated_template("cfg777", _atea_approved())
    assert first["id"] == "generated-cfg777"
    assert same["version"] == 1
    changed = _atea_approved()
    changed["objects"]["target_transport_profile"]["subscription_folder"] = "/Inbound/PO"
    second = main_module._sync_generated_template("cfg777", changed)
    assert second["version"] == 2
    assert second["default_values"]["target_folder"] == "/Inbound/PO"


def test_ui_and_backend_include_files_only_and_template_sync_hardening():
    root = Path(__file__).resolve().parent
    legacy = (root / "webapp/backend/app/legacy_adapter.py").read_text(encoding="utf-8")
    main = (root / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    ui = (root / "input_builder_ui.py").read_text(encoding="utf-8")
    template_page = (root / "webapp/frontend/src/pages/TemplatesPage.tsx").read_text(encoding="utf-8")
    assert "automatic_configuration_manual" in legacy
    assert "received_value_precedence" in legacy
    assert "_sync_generated_template" in main
    assert "No input.json was supplied" in ui
    assert "Received configuration values" in template_page
