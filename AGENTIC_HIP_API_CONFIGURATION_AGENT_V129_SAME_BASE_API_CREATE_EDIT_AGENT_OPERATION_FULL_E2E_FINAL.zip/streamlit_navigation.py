from __future__ import annotations

import re
from pathlib import Path
from typing import Any
from urllib.parse import quote


def _page_slug(page: str | Path) -> str:
    """Return the URL slug Streamlit uses for a pages/ filename.

    Example: pages/10_Agentic_Interface_Studio.py -> Agentic_Interface_Studio
    """
    stem = Path(str(page)).stem
    return re.sub(r"^\d+[_ -]*", "", stem) or stem


def render_app_home_link(st: Any, label: str = "← Back to Application Studio", icon: str = "🧭") -> None:
    """Render an entrypoint-independent link back to the running app's root.

    A hard-coded st.page_link('hip_application_studio.py') only works when that
    file is the Streamlit entrypoint.  Compatibility launchers use a different
    entrypoint, so the browser-relative './' link is intentionally used here.
    It keeps any deployment base path and returns to whichever script was
    actually launched.
    """
    text = f"{icon} {label}" if icon else label
    st.markdown(f"[{text}](./)")


def safe_page_link(
    st: Any,
    page: str | Path,
    *,
    label: str,
    icon: str | None = None,
) -> None:
    """Use Streamlit native page navigation with a non-crashing URL fallback."""
    try:
        kwargs = {"label": label}
        if icon:
            kwargs["icon"] = icon
        st.page_link(str(page), **kwargs)
        return
    except Exception:
        # A stale bookmark or alternate entrypoint must never take down the UI.
        slug = quote(_page_slug(page), safe="_-~")
        text = f"{icon} {label}" if icon else label
        st.markdown(f"[{text}](./{slug})")


WORKSPACE_KEY = "unified_studio_workspace"
PENDING_WORKSPACE_KEY = "_pending_unified_studio_workspace"


def apply_pending_workspace(st: Any, *, workspace_key: str = WORKSPACE_KEY, pending_key: str = PENDING_WORKSPACE_KEY) -> None:
    """Apply a requested workspace before the radio widget is instantiated.

    Streamlit forbids writing directly to session_state[widget_key] after a
    widget with that key has been created in the current run. Navigation buttons
    therefore write only to a separate pending key. The next rerun applies the
    value before the workspace radio is rendered.
    """
    target = st.session_state.pop(pending_key, None)
    if target:
        st.session_state[workspace_key] = target


def request_workspace_switch(st: Any, target: str, *, pending_key: str = PENDING_WORKSPACE_KEY) -> None:
    """Request an in-app workspace switch without mutating an instantiated widget."""
    st.session_state[pending_key] = str(target)
    st.rerun()


def hide_legacy_page_navigation(st: Any) -> None:
    """Hide Streamlit's filename-based multipage navigation.

    The application has its own named workspace selector. Hiding the generated
    pages list avoids labels such as `adaptive uhal app` and keeps old page files
    only as compatibility targets for bookmarks.
    """
    st.markdown(
        """
        <style>
        [data-testid="stSidebarNav"], [data-testid="stSidebarNavItems"] {display:none !important;}
        </style>
        """,
        unsafe_allow_html=True,
    )
