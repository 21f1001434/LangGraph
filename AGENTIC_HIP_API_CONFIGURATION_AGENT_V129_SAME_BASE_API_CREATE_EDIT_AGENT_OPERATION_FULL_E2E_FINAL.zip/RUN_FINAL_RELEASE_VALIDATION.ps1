$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Run-Check([string]$Name, [scriptblock]$Command) {
  Write-Host "`n--- $Name ---"
  & $Command
  if ($LASTEXITCODE -ne 0) { throw "$Name failed." }
}
Run-Check 'Quick packaged runtime checks' { python .\FINAL_RELEASE_VALIDATION.py }
Run-Check 'Business workflow smoke' { python .\BUSINESS_READINESS_VALIDATION.py }
Run-Check 'Full Python regression' { python -m pytest -q }
Run-Check 'Standard package validator' { python .\validate_package.py }
Run-Check 'Adaptive package validator' { python .\validate_adaptive_package.py }
Run-Check 'Required final self-check' { python .\final_self_check.py }
1..6 | ForEach-Object { $i=$_; Run-Check "Phase $i release check" { python ".\CHECK_AGENTIC_HIP_PHASE$i.py" } }
Write-Host "`nFINAL LOCAL/PACKAGE VALIDATION: PASS"
Write-Host 'This validation does not mutate Dell HIP.'
Write-Host 'Next: verify System & Connections, then run one approved LIVE smoke configuration on the Dell network.'
