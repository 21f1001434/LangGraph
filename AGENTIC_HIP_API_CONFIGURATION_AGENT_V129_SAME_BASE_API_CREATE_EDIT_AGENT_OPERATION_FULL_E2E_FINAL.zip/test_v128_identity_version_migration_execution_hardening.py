from __future__ import annotations

from pathlib import Path

from execution_flow import ExecutionFlowConfig
from run_agent import Runner
from uhal_mapper import UhalInputMapper


def _routing_only_input(partner_name: str = "CUSTOMER_PARTNER") -> dict:
    return {
        "customer": "CUSTOMER",
        "direction": "Outbound",
        "partner_id": "UHI1001",
        "objects": {
            "source_transport_profile": {"partner_name": "AIC - DCE"},
            "target_transport_profile": {"partner_name": partner_name},
            "rule": {
                "conditions": {
                    "rows": [
                        {"attribute_name": "Receiver", "operator": "Equals", "value": "UHI1001"},
                        {"attribute_name": "Sender", "operator": "Equals", "value": "DELLCO01"},
                    ]
                }
            },
            "biz_flow": {
                "flow_identifiers": {
                    "conditions": [
                        {"attribute_name": "Receiver", "operator": "Equals", "value": "UHI1001"},
                        {"attribute_name": "Sender", "operator": "Equals", "value": "DELLCO01"},
                    ]
                },
                "configure_routing": {
                    "conditions": {
                        "rows": [
                            {"attribute_name": "Receiver", "operator": "Equals", "value": "UHI1001"}
                        ]
                    }
                },
            },
        },
    }


def test_v128_runner_never_promotes_routing_partner_id_into_partner_create():
    runner = Runner.__new__(Runner)
    runner.input = _routing_only_input()
    runner.ov = {}
    runner.source_tp = lambda: runner.input["objects"]["source_transport_profile"]
    runner.target_tp = lambda: runner.input["objects"]["target_transport_profile"]
    assert runner.partner_identifier_value() == ""


def test_v128_mapper_never_promotes_routing_partner_id_into_partner_create(tmp_path: Path):
    data = _routing_only_input()
    mapper = UhalInputMapper(data, {}, tmp_path)
    normalized = mapper.normalized()
    assert normalized["partnerIdentifierValue"] in (None, "")


def test_v128_dev_approved_dce_test_partner_maps_to_its_duns_not_routing_value():
    runner = Runner.__new__(Runner)
    runner.input = _routing_only_input("dce-test-partner")
    runner.ov = {}
    runner.source_tp = lambda: runner.input["objects"]["source_transport_profile"]
    runner.target_tp = lambda: runner.input["objects"]["target_transport_profile"]
    assert runner.partner_identifier_value() == "12345666"
    assert runner.partner_identifier_value() != "UHI1001"


def test_v128_force_environment_cannot_enable_migration_against_human_plan(tmp_path: Path, monkeypatch):
    runner = Runner.__new__(Runner)
    runner.include_migration_in_full_live = True
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    monkeypatch.setenv("HIP_FORCE_MIGRATION_IN_FULL_LIVE", "true")
    assert runner.migration_execution_requested() is False
    assert len(runner.ordered_live_steps()) == 18
