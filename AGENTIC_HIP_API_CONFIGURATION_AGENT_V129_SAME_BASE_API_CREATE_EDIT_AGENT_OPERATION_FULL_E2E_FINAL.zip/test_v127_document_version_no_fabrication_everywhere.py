from __future__ import annotations

import gzip
import zipfile

from configuration_workspace import build_guided_input, guided_questions, infer_fields_from_payload_bundle
from input_builder_core import _doc_type_name_version, build_from_raw_files
from input_extraction_blueprint import apply_input_extraction_blueprint


def _guided_fields() -> dict:
    return {
        "customer": "CUSTOMER",
        "flow_name": "FLOW",
        "tx_code": "850",
        "tx_name": "Purchase Order",
        "source_doc_name": "SRC_DOC",
        "source_root": "PurchaseOrder",
        "target_doc_name": "TGT_DOC",
        "target_root": "PurchaseOrderAck",
        "map_identifier": "MAP_ID",
        "map_name": "MAP",
        "map_data_file": "Transform_MAP.jar",
        "rule_name": "MAP_RULE",
        "receiver_value": "CUSTOMER",
        "source_system": "AIC - DCE",
        "target_partner": "CUSTOMER_PARTNER",
        "source_tp_profile": "SRC_TP",
        "target_tp_profile": "TGT_TP",
        "source_flow_tp": "SRC_TP",
        "target_flow_tp": "TGT_TP",
    }


def test_doc_reference_helper_never_fabricates_version():
    assert _doc_type_name_version({"name": "DOC", "version": ""}) == ""
    assert _doc_type_name_version({"name": "DOC", "version": None}) == ""
    assert _doc_type_name_version({"name": "DOC", "version": "2.5"}) == "DOC(2.5)"


def test_guided_builder_missing_versions_stay_blank_and_are_asked():
    fields = _guided_fields()
    built = build_guided_input(fields)
    objects = built["objects"]
    assert objects["source_document_type"]["version"] == ""
    assert objects["target_document_type"]["version"] == ""
    assert objects["source_transport_profile"]["document_type"] == ""
    assert objects["target_transport_profile"]["document_type"] == ""
    assert objects["rule"]["document_type_name_version"] == ""
    assert objects["biz_flow"]["configure_source"]["document_type_name_version"] == ""

    asked = {row["field"] for row in guided_questions(fields)}
    assert {"source_doc_version", "target_doc_version", "map_version", "rule_version", "flow_version"} <= asked


def test_guided_builder_uses_explicit_object_versions_without_cross_contamination():
    fields = _guided_fields() | {
        "source_doc_version": "2.5",
        "target_doc_version": "3.1",
        "map_version": "7",
        "rule_version": "8",
        "flow_version": "9",
    }
    built = build_guided_input(fields)
    objects = built["objects"]
    assert objects["source_document_type"]["version"] == "2.5"
    assert objects["target_document_type"]["version"] == "3.1"
    assert objects["source_transport_profile"]["document_type"] == "SRC_DOC(2.5)"
    assert objects["target_transport_profile"]["document_type"] == "TGT_DOC(3.1)"
    assert objects["data_map"]["map_identifier_version"] == "7"
    assert objects["rule"]["version"] == "8"
    assert objects["biz_flow"]["flow_details"]["current_flow_version"] == "9"


def test_blueprint_does_not_derive_doc_reference_from_name_only():
    canonical = {
        "requires_data_map": True,
        "objects": {
            "source_document_type": {"name": "SRC_DOC", "version": ""},
            "target_document_type": {"name": "TGT_DOC", "version": ""},
            "source_transport_profile": {"document_type": ""},
            "target_transport_profile": {"document_type": ""},
            "biz_flow": {"configure_source": {}, "configure_targets": {}},
        },
    }
    out = apply_input_extraction_blueprint(canonical)
    assert out["objects"]["source_transport_profile"]["document_type"] == ""
    assert out["objects"]["target_transport_profile"]["document_type"] == ""
    assert out["objects"]["biz_flow"]["configure_source"].get("document_type_name_version", "") == ""
    assert out["objects"]["biz_flow"]["configure_targets"].get("document_type_name_version", "") == ""


def test_raw_customer_files_without_version_evidence_never_get_one(tmp_path):
    (tmp_path / "CUSTOMER_PO.xml").write_text(
        "<PurchaseOrderCollection><PurchaseOrderItem><BuyerParty><CompanyName>CUSTOMER</CompanyName>"
        "</BuyerParty></PurchaseOrderItem></PurchaseOrderCollection>",
        encoding="utf-8",
    )
    xbm = (
        '<transformMap logicalName="MAP850" analystVersionLastSaved="6.7.2">'
        '<sources><schemaRoot logicalName="PurchaseOrderCollection"/></sources>'
        '<targets><schemaRoot logicalName="PurchaseOrder"/></targets></transformMap>'
    )
    (tmp_path / "MAP850.xbm").write_bytes(gzip.compress(xbm.encode("utf-8")))
    with zipfile.ZipFile(tmp_path / "Transform_MAP850.jar", "w") as zf:
        zf.writestr("com/dell/Transform_MAP850.class", b"fixture")

    out = build_from_raw_files(
        list(tmp_path.iterdir()),
        customer="CUSTOMER",
        direction="Inbound",
        flow_type="translation",
        use_dell_aia=False,
    )
    objects = out["objects"]
    assert objects["source_document_type"].get("version", "") == ""
    assert objects["target_document_type"].get("version", "") == ""
    assert objects["source_transport_profile"].get("document_type", "") == ""
    assert objects["target_transport_profile"].get("document_type", "") == ""
    assert objects["data_map"].get("map_identifier_version", "") == ""
    assert objects["rule"].get("version", "") == ""
    assert objects["rule"].get("actions", {}).get("mapping_id_version", "") == ""
    assert objects["biz_flow"].get("flow_details", {}).get("current_flow_version", "") == ""
    missing = {row.get("field") for row in out.get("missing_fields", [])}
    assert {
        "source_document_type_version", "target_document_type_version",
        "map_identifier_version", "rule_version", "flow_version",
    } <= missing


def test_payload_bundle_inference_keeps_source_and_target_versions_separate():
    fields = infer_fields_from_payload_bundle(
        {
            "doctype_source": {"name": "SRC_DOC", "version": "2.5", "dataFormatType": "XML"},
            "doctype_target": {"name": "TGT_DOC", "version": "3.1"},
            "map": {"mapIdentifier": "MAP_ID", "mapIdentifierVersion": "4.2", "mapName": "MAP"},
            "rule": {"name": "RULE", "version": "5.3"},
            "flow_create": {
                "flowDefinition": {
                    "flowDetails": {"businessFlowName": "FLOW", "currentFlowVersion": "6.4"},
                    "sourceDetails": {},
                    "targetDetails": {"targets": []},
                }
            },
        }
    )
    assert fields["source_doc_version"] == "2.5"
    assert fields["target_doc_version"] == "3.1"
    assert fields["map_version"] == "4.2"
    assert fields["rule_version"] == "5.3"
    assert fields["flow_version"] == "6.4"


def test_generic_xml_routing_identity_is_extracted_without_becoming_partner_create_duns():
    from input_builder_core import _agt_parse_xml

    parsed = _agt_parse_xml(
        '<SHIPMENT_NOTICE><ROUTING document_name="XML Shipment Notice v1.0" '
        'destination_value="UHI1001" source_value="DELLCO01"/></SHIPMENT_NOTICE>'
    )
    assert parsed["partner_id"] == "UHI1001"
    assert parsed["sender_id"] == "DELLCO01"
    assert parsed["routing_document_name"] == "XML Shipment Notice v1.0"
    assert "partner_identifier_value" not in parsed


def test_migration_payload_never_fabricates_missing_object_versions(monkeypatch):
    from run_agent import Runner

    runner = Runner.__new__(Runner)
    runner.env = "DEV"
    # A historical create-flow default must not be accepted as Migration evidence.
    runner.ov = {"flowVersion": "1.0"}
    runner.source_doc = lambda: {"name": "SRC_DOC", "version": ""}
    runner.effective_target_doc = lambda: {"name": "TGT_DOC", "version": ""}
    runner.data_map = lambda: {"map_identifier": "MAP", "map_identifier_version": ""}
    runner.rule = lambda: {"name": "RULE", "version": ""}
    runner.biz_flow = lambda: {"flow_details": {"business_flow_name": "FLOW", "current_flow_version": ""}}
    runner.flow_name = lambda: "FLOW"
    monkeypatch.setenv("HIP_MIGRATION_SOURCE_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "TEST")

    assert runner.migration_payload("migrate_doctype_source")["documentTypeVersion"] == ""
    assert runner.migration_payload("migrate_doctype_target")["documentTypeVersion"] == ""
    assert runner.migration_payload("migrate_map")["mapIdentifierVersion"] == ""
    assert runner.migration_payload("migrate_rule")["ruleVersion"] == ""
    assert runner.migration_payload("migrate_flow")["flowVersion"] == ""
    assert "documentTypeVersion is required" in runner.migration_readiness_errors(
        "migrate_doctype_source", runner.migration_payload("migrate_doctype_source")
    )
