from __future__ import annotations

import datetime as dt
import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

from api_contract_policy import API_REQUEST_MUTATION_ALLOWED, API_REQUEST_VALUE_EDIT_ALLOWED, POLICY_NAME, immutable_override_meta
from canonical_payload_contract import (
    canonical_request_kind,
    interface_family_from_workspace,
    sanitize_override_patch,
    validate_override_structure,
    canonical_leaf_paths,
)


ALIASES = {
    "map_primary": "map",
    "map_fallback": "map",
}

TOKEN_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}|\$\{\s*([A-Za-z0-9_.-]+)\s*\}")


HIP_DERIVED_WORKTYPE_STEPS = {
    "source_tp",
    "target_tp",
    "flow_create",
    "flow_deploy",
}


def _strip_hip_derived_worktype(step_key: str, request_kind: str, value: Any) -> Any:
    """Never allow a user/config override to re-introduce HIP-owned workType.

    HIP derives the complete workType object internally. The reviewed API
    contract accepts the field as absent (preferred) or null. The agent uses
    the safer default: omit it from the outbound request body.
    """
    if request_kind != "payload" or canonical_step_key(step_key) not in HIP_DERIVED_WORKTYPE_STEPS:
        return value
    if not isinstance(value, dict):
        return value
    cleaned = deepcopy(value)
    cleaned.pop("workType", None)
    return cleaned


def canonical_step_key(step_key: str) -> str:
    key = str(step_key or "").strip()
    return ALIASES.get(key, key)


def _deep_merge(base: Any, patch: Any) -> Any:
    if isinstance(base, dict) and isinstance(patch, dict):
        result = deepcopy(base)
        for key, value in patch.items():
            if key in result:
                result[key] = _deep_merge(result[key], value)
            else:
                result[key] = deepcopy(value)
        return result
    return deepcopy(patch)


def _set_value_path(root: Any, dotted_path: str, value: Any) -> Any:
    """Set one canonical dotted leaf path (arrays use numeric indexes)."""
    parts = [p for p in str(dotted_path or "").split(".") if p != ""]
    if not parts:
        raise ValueError("Payload value path cannot be empty.")
    node = root
    for index, part in enumerate(parts):
        last = index == len(parts) - 1
        if isinstance(node, list):
            if not part.isdigit():
                raise ValueError(f"Expected array index in value path {dotted_path!r}.")
            pos = int(part)
            if pos < 0 or pos >= len(node):
                raise ValueError(f"Array index out of range in value path {dotted_path!r}.")
            if last:
                node[pos] = deepcopy(value)
            else:
                node = node[pos]
            continue
        if not isinstance(node, dict) or part not in node:
            raise ValueError(f"Canonical value path {dotted_path!r} does not exist in the generated request.")
        if last:
            node[part] = deepcopy(value)
        else:
            node = node[part]
    return root


def _lookup(context: Dict[str, Any], path: str) -> Any:
    node: Any = context
    for part in str(path).split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def _resolve_tokens(value: Any, context: Dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {key: _resolve_tokens(item, context) for key, item in value.items()}
    if isinstance(value, list):
        return [_resolve_tokens(item, context) for item in value]
    if not isinstance(value, str):
        return value

    full = TOKEN_PATTERN.fullmatch(value.strip())
    if full:
        token = full.group(1) or full.group(2)
        resolved = _lookup(context, token)
        return value if resolved is None else deepcopy(resolved)

    def repl(match: re.Match[str]) -> str:
        token = match.group(1) or match.group(2)
        resolved = _lookup(context, token)
        return match.group(0) if resolved is None else str(resolved)

    return TOKEN_PATTERN.sub(repl, value)


class PayloadOverrideStore:
    """Persistent HUMAN-user-approved request payload/parameter overrides.

    The AI/agent has no authority to create an active override. Only rows explicitly
    marked ``editOrigin=USER`` by a human UI action are eligible for LIVE application.
    The override changes only request content. Method, URL, OAuth profile and
    protected headers remain controlled by the runner. Overrides can use
    runtime placeholders such as ``{{runtime.map_id}}`` or
    ``${runtime.source_document_type_id}``.
    """

    def __init__(self, root: Path):
        self.root = Path(root)
        self.path = self.root / "payload_overrides.json"
        self.data = self._load()
        self.errors = self._validate()

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "overrides": {}}
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(value, dict):
                raise ValueError("root must be an object")
            if not isinstance(value.get("overrides", {}), dict):
                raise ValueError("overrides must be an object")

            # V72 migration: all 18 HIP requests use developer-approved immutable
            # structures. FILE uses the U-HAUL/dev-tested shape; HTTPS/HTTPS-AS2
            # use their dev-approved interfaceDetails shapes. Older workspaces may contain
            # payload_overrides.json entries that added/renamed attributes.
            # Strip those attributes automatically while preserving every
            # canonical customer-specific value. No U-HAUL business value is
            # copied into the customer workspace.
            migrated = False
            migration_rows = []
            overrides = value.get("overrides") or {}
            for raw_key, row in list(overrides.items()):
                if not isinstance(row, dict):
                    continue
                key = canonical_step_key(raw_key)
                try:
                    expected_kind = canonical_request_kind(key)
                except Exception:
                    continue
                original_kind = str(row.get("requestKind") or expected_kind)
                original_value = deepcopy(row.get("value") or {})
                family = interface_family_from_workspace(self.root, key)
                if str(row.get("mode") or "") == "paths":
                    allowed = set(canonical_leaf_paths(key, interface_family=family))
                    cleaned = {str(path): deepcopy(v) for path, v in original_value.items() if str(path) in allowed}
                    meta = {"droppedPaths": sorted(str(path) for path in original_value if str(path) not in allowed)}
                else:
                    cleaned, meta = sanitize_override_patch(key, expected_kind, original_value, interface_family=family)
                if original_kind != expected_kind or cleaned != original_value or raw_key != key:
                    migrated = True
                    row = deepcopy(row)
                    row["requestKind"] = expected_kind
                    row["value"] = cleaned
                    row["structureLocked"] = True
                    row["structureMigration"] = {
                        "policy": "Developer-approved interface-specific canonical attributes; values only",
                        "interfaceFamily": family or None,
                        "droppedPaths": meta.get("droppedPaths") or [],
                        "migratedAt": dt.datetime.now().isoformat(),
                    }
                    if raw_key != key:
                        overrides.pop(raw_key, None)
                    overrides[key] = row
                    migration_rows.append({"stepKey": key, "droppedPaths": meta.get("droppedPaths") or []})
            value["overrides"] = overrides
            if migrated:
                value["structureLockMigration"] = {
                    "version": 72,
                    "policy": "All 18 request attributes are canonical; transport interfaceDetails use the developer-approved FILE/HTTPS/HTTPS-AS2 family shape; only values vary by customer.",
                    "rows": migration_rows,
                }
                self.path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
            return value
        except Exception as exc:
            return {
                "version": 1,
                "overrides": {},
                "loadError": str(exc),
            }

    def _validate(self) -> list[str]:
        errors: list[str] = []
        if self.data.get("loadError"):
            errors.append("payload_overrides.json is invalid: " + str(self.data["loadError"]))
        for key, row in (self.data.get("overrides") or {}).items():
            if not isinstance(row, dict):
                errors.append(f"Override {key} must be an object.")
                continue
            origin = str(row.get("editOrigin") or "LEGACY").strip().upper()
            if origin not in {"USER", "SYSTEM", "AGENT", "LEGACY"}:
                errors.append(f"Override {key} editOrigin must be USER/SYSTEM/AGENT/LEGACY.")
            if row.get("requestKind") not in {"payload", "params"}:
                errors.append(f"Override {key} requestKind must be payload or params.")
            if row.get("mode") not in {"replace", "merge", "paths"}:
                errors.append(f"Override {key} mode must be replace, merge, or paths.")
            if not isinstance(row.get("value"), dict):
                errors.append(f"Override {key} value must be a JSON object.")
        return errors

    def get(self, step_key: str) -> Optional[Dict[str, Any]]:
        key = canonical_step_key(step_key)
        row = (self.data.get("overrides") or {}).get(key)
        if not isinstance(row, dict) or not row.get("enabled", True):
            return None
        return deepcopy(row)

    def apply(
        self,
        step_key: str,
        call_factory: Dict[str, Any],
        context: Dict[str, Any],
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        factory = deepcopy(call_factory)
        row = self.get(step_key)
        if not row:
            return factory, immutable_override_meta(canonical_step_key(step_key), persisted_count=0)
        if not API_REQUEST_VALUE_EDIT_ALLOWED:
            return factory, immutable_override_meta(canonical_step_key(step_key), persisted_count=1)
        # V117 human-governance rule: persisted values are applied to LIVE only
        # when they came from an explicit human edit action. Agent/system/legacy
        # rows may remain as audit evidence but have zero execution authority.
        edit_origin = str(row.get("editOrigin") or "LEGACY").strip().upper()
        if edit_origin != "USER":
            meta = immutable_override_meta(canonical_step_key(step_key), persisted_count=1)
            meta.update({
                "persistedOverrideIgnored": True,
                "ignoredReason": "PAYLOAD_VALUE_EDIT_USER_ONLY",
                "editOrigin": edit_origin,
                "agentEditAllowed": False,
                "userEditAllowed": True,
            })
            return factory, meta

        request_kind = str(row.get("requestKind") or "payload")
        mode = str(row.get("mode") or "replace")
        override_value = _resolve_tokens(deepcopy(row.get("value") or {}), context)
        original = deepcopy(factory.get(request_kind))
        if original is None:
            original = {}
        if mode == "merge":
            effective = _deep_merge(original, override_value)
        elif mode == "paths":
            effective = deepcopy(original)
            if not isinstance(override_value, dict):
                raise ValueError("Path-mode payload edit must be a path/value object.")
            for path, edited_value in override_value.items():
                _set_value_path(effective, str(path), edited_value)
        else:
            effective = override_value
        # Developer-reviewed HIP behavior: workType is internal metadata.
        # Even a full user payload edit must not re-introduce an id/type/object.
        # Omission is the default representation; HIP also accepts null.
        effective = _strip_hip_derived_worktype(step_key, request_kind, effective)
        factory[request_kind] = effective
        meta = {
            "applied": True,
            "stepKey": canonical_step_key(step_key),
            "requestKind": request_kind,
            "mode": mode,
            "note": str(row.get("note") or ""),
            "savedAt": row.get("savedAt"),
            "containsRuntimeTemplates": bool(TOKEN_PATTERN.search(json.dumps(row.get("value") or {}))),
            "editOrigin": "USER",
            "agentEditAllowed": False,
            "userEditAllowed": True,
        }
        return factory, meta

    def summary(self) -> Dict[str, Any]:
        rows = []
        for key, row in sorted((self.data.get("overrides") or {}).items()):
            if not isinstance(row, dict):
                continue
            rows.append({
                "stepKey": key,
                "enabled": bool(row.get("enabled", True)),
                "requestKind": row.get("requestKind"),
                "mode": row.get("mode"),
                "note": row.get("note", ""),
                "savedAt": row.get("savedAt"),
                "editOrigin": str(row.get("editOrigin") or "LEGACY").upper(),
            })
        return {
            "path": str(self.path),
            "valid": not self.errors,
            "errors": list(self.errors),
            "count": sum(1 for row in rows if row["enabled"]),
            "overrides": rows,
            "mutationAllowed": API_REQUEST_MUTATION_ALLOWED,
            "policy": POLICY_NAME,
            "runtimeApplication": "VALUE_EDIT_ENABLED_STRUCTURE_LOCKED" if API_REQUEST_VALUE_EDIT_ALLOWED else "DISABLED",
            "structureMutationAllowed": bool(API_REQUEST_MUTATION_ALLOWED),
            "valueEditAllowed": bool(API_REQUEST_VALUE_EDIT_ALLOWED),
            "userValueEditAllowed": bool(API_REQUEST_VALUE_EDIT_ALLOWED),
            "agentValueEditAllowed": False,
        }


def save_override(
    root: Path,
    step_key: str,
    value: Dict[str, Any],
    *,
    request_kind: str = "payload",
    mode: str = "replace",
    note: str = "",
    enabled: bool = True,
    edit_origin: str = "SYSTEM",
) -> Dict[str, Any]:
    edit_origin = str(edit_origin or "SYSTEM").strip().upper()
    if edit_origin not in {"USER", "SYSTEM", "AGENT", "LEGACY"}:
        raise ValueError("edit_origin must be USER, SYSTEM, AGENT, or LEGACY")
    if request_kind not in {"payload", "params"}:
        raise ValueError("request_kind must be payload or params")
    if mode not in {"replace", "merge", "paths"}:
        raise ValueError("mode must be replace, merge, or paths")
    if not isinstance(value, dict):
        raise ValueError("payload/params override must be a JSON object")

    key = canonical_step_key(step_key)
    expected_kind = canonical_request_kind(key)
    if request_kind != expected_kind:
        raise ValueError(
            f"CANONICAL_PAYLOAD_STRUCTURE_LOCK: {key} must remain {expected_kind}; "
            "the API request kind/attributes are fixed and only values may change."
        )
    family = interface_family_from_workspace(Path(root), key)
    if mode == "paths":
        allowed = set(canonical_leaf_paths(key, interface_family=family))
        unknown = sorted(str(path) for path in value if str(path) not in allowed)
        if unknown:
            raise ValueError(
                "CANONICAL_PAYLOAD_STRUCTURE_LOCK: path-mode edits may change only existing canonical leaf values. "
                + "Unknown/non-leaf paths: " + ", ".join(unknown[:30])
            )
        # workType is HIP-owned and may not be restored through a path edit.
        value = {str(path): deepcopy(v) for path, v in value.items() if not str(path).endswith("workType") and ".workType." not in str(path)}
        _structure_meta = {"pathMode": True, "editableLeafCount": len(allowed)}
    else:
        # Preserve the V59/V60 HIP-owned workType rule before applying the stricter
        # interface-aware structure lock. All other unknown attributes are rejected.
        value = _strip_hip_derived_worktype(key, request_kind, deepcopy(value))
        structure = validate_override_structure(key, request_kind, value, interface_family=family)
        if not structure.get("valid"):
            raise ValueError(
                "CANONICAL_PAYLOAD_STRUCTURE_LOCK: only values of existing developer-approved "
                "attributes for this interface family may change. " + json.dumps(structure.get("errors") or [], ensure_ascii=False)
            )
        value, _structure_meta = sanitize_override_patch(key, request_kind, value, interface_family=family)

    store = PayloadOverrideStore(root)
    if store.errors:
        raise ValueError("Cannot update invalid payload_overrides.json: " + "; ".join(store.errors))
    overrides = deepcopy(store.data.get("overrides") or {})
    overrides[key] = {
        "enabled": bool(enabled),
        "requestKind": request_kind,
        "mode": mode,
        "value": deepcopy(value),
        "note": str(note or ""),
        "savedAt": dt.datetime.now().isoformat(),
        "editOrigin": edit_origin,
        "executionAuthority": "HUMAN_USER_ONLY" if edit_origin == "USER" else "NO_LIVE_AUTHORITY",
        "structureLocked": True,
        "structureReference": "Developer-approved 18-API structure with interface-specific transport template",
        "interfaceFamily": family or None,
    }
    payload = {"version": 1, "overrides": overrides}
    Path(root, "payload_overrides.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return PayloadOverrideStore(root).summary()


def clear_override(root: Path, step_key: str) -> Dict[str, Any]:
    store = PayloadOverrideStore(root)
    overrides = deepcopy(store.data.get("overrides") or {})
    overrides.pop(canonical_step_key(step_key), None)
    Path(root, "payload_overrides.json").write_text(
        json.dumps({"version": 1, "overrides": overrides}, indent=2), encoding="utf-8"
    )
    return PayloadOverrideStore(root).summary()


def clear_all_overrides(root: Path) -> Dict[str, Any]:
    Path(root, "payload_overrides.json").write_text(
        json.dumps({"version": 1, "overrides": {}}, indent=2), encoding="utf-8"
    )
    return PayloadOverrideStore(root).summary()
