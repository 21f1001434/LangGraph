from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from execution_flow import (
    ALL_DEFAULT_ORDER,
    DEFAULT_ORDER,
    ExecutionFlowConfig,
    reset_execution_flow,
    save_execution_flow,
)
from migration_api_contract import MIGRATION_ORDER
from run_agent import Runner
from webapp.backend.app.phase5_service import build_configuration_bundle, import_configuration_bundle
from webapp.backend.app.storage import JsonStore


def _all_rows(flow: ExecutionFlowConfig):
    s = flow.summary()
    return [
        {"stepKey": row["stepKey"], "order": row["order"], "waitAfterSeconds": row.get("waitAfterSeconds", 0)}
        for row in s["liveSteps"]
    ]


def test_v126_default_is_18_base_with_migration_off(tmp_path: Path):
    flow = ExecutionFlowConfig(tmp_path)
    s = flow.summary()
    assert s["version"] == 4  # V129 adds the governed Create/Edit operation selector
    assert s["migrationEnabled"] is False
    assert s["registeredBaseCount"] == 18
    assert s["registeredMigrationCount"] == 7
    assert s["registeredTotalCount"] == 25
    assert s["orderedLiveSteps"] == DEFAULT_ORDER
    assert s["liveStepCount"] == 18


def test_v126_human_can_enable_migration_and_reorder_dependency_safe(tmp_path: Path):
    flow = ExecutionFlowConfig(tmp_path)
    # Place Source Document Type Migration immediately after Source Document Type;
    # its only hard dependency is doctype_source so this is valid.
    desired = list(ALL_DEFAULT_ORDER)
    desired.remove("migrate_doctype_source")
    pos = desired.index("doctype_source") + 1
    desired.insert(pos, "migrate_doctype_source")
    current = {r["stepKey"]: r for r in _all_rows(flow)}
    rows = [{**current[key], "order": i + 1} for i, key in enumerate(desired)]
    saved = save_execution_flow(tmp_path, rows, migration_enabled=True)
    assert saved["migrationEnabled"] is True
    assert saved["liveStepCount"] == 25
    assert saved["orderedLiveSteps"] == desired
    assert saved["userControlled"] is True
    assert saved["executionStrategy"] == "EXACT_SEQUENTIAL"


def test_v126_dependency_violating_order_is_rejected(tmp_path: Path):
    flow = ExecutionFlowConfig(tmp_path)
    desired = list(ALL_DEFAULT_ORDER)
    # flow_deploy cannot run before flow_create.
    desired.remove("flow_deploy")
    desired.insert(0, "flow_deploy")
    current = {r["stepKey"]: r for r in _all_rows(flow)}
    rows = [{**current[key], "order": i + 1} for i, key in enumerate(desired)]
    with pytest.raises(ValueError, match="must run after"):
        save_execution_flow(tmp_path, rows, migration_enabled=True)


def test_v126_runner_uses_explicit_toggle_not_target_environment(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    runner = Runner.__new__(Runner)
    runner.include_migration_in_full_live = True
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    monkeypatch.delenv("HIP_FORCE_MIGRATION_IN_FULL_LIVE", raising=False)
    assert runner.migration_execution_requested() is False
    assert runner.ordered_live_steps() == DEFAULT_ORDER

    rows = _all_rows(runner.execution_flow)
    save_execution_flow(tmp_path, rows, migration_enabled=True)
    runner.execution_flow = ExecutionFlowConfig(tmp_path)
    assert runner.migration_execution_requested() is True
    assert len(runner.ordered_live_steps()) == 25
    assert all(key in runner.ordered_live_steps() for key in MIGRATION_ORDER)


def test_v126_reset_returns_safe_base_only_exact_plan(tmp_path: Path):
    rows = _all_rows(ExecutionFlowConfig(tmp_path))
    save_execution_flow(tmp_path, rows, migration_enabled=True)
    reset = reset_execution_flow(tmp_path)
    assert reset["migrationEnabled"] is False
    assert reset["orderedLiveSteps"] == DEFAULT_ORDER
    assert reset["userControlled"] is True
    assert reset["executionStrategy"] == "EXACT_SEQUENTIAL"


def test_v126_clone_preserves_execution_flow(tmp_path: Path):
    store = JsonStore(tmp_path / "store")
    source = store.create_configuration({"name": "Source", "customer": "LEGRAND"})
    ws = Path(source["workspace"])
    reset_execution_flow(ws)
    flow = ExecutionFlowConfig(ws)
    save_execution_flow(ws, _all_rows(flow), migration_enabled=True)
    cloned = store.clone_configuration(source["id"], "Clone")
    cloned_flow = ExecutionFlowConfig(Path(cloned["workspace"]))
    assert cloned_flow.migration_enabled() is True
    assert cloned_flow.summary()["orderedAllSteps"] == ExecutionFlowConfig(ws).summary()["orderedAllSteps"]


def test_v126_bundle_roundtrip_preserves_execution_flow(tmp_path: Path):
    source_store = JsonStore(tmp_path / "source-store")
    source = source_store.create_configuration({"name": "Source", "customer": "LEGRAND"})
    ws = Path(source["workspace"])
    flow = ExecutionFlowConfig(ws)
    rows = _all_rows(flow)
    # A safe custom wait proves the content survived, not just the default.
    rows[0]["waitAfterSeconds"] = 7
    save_execution_flow(ws, rows, migration_enabled=True)
    source = source_store.get_configuration(source["id"])
    bundle = build_configuration_bundle(source)

    target_store = JsonStore(tmp_path / "target-store")
    imported = import_configuration_bundle(target_store, bundle)
    imported_flow = ExecutionFlowConfig(Path(imported["workspace"]))
    assert imported_flow.migration_enabled() is True
    assert imported_flow.wait_after("validate_source") == 7


def test_v126_frontend_exposes_human_toggle_and_reorder_api():
    root = Path(__file__).resolve().parent
    builder = (root / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    api = (root / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    main = (root / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    assert "Choose Migration ON/OFF and execution order" in builder
    assert "Save execution plan + revalidate" in builder
    assert "api.saveExecutionFlow" in builder
    assert "execution-flow-edit-v1" in api
    assert '@app.put("/api/configurations/{cid}/execution-flow")' in main
    assert "_require_human_execution_flow_action" in main


def test_v126_startup_root_fallback_is_merged():
    root = Path(__file__).resolve().parent
    main = (root / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    bat = (root / "RUN_AGENTIC_HIP.bat").read_text(encoding="utf-8", errors="ignore")
    assert "Frontend not built yet" in main
    assert "dist\\index.html" in bat
    assert "bun run build" in bat.lower()


def test_v126_runner_repair_pass_preserves_saved_order_source_contract():
    root = Path(__file__).resolve().parent
    source = (root / "run_agent.py").read_text(encoding="utf-8")
    assert "completion_business_step_set" in source
    assert "key for key in ordered_steps" in source
    assert "Migration steps are not auto-repaired here" in source
