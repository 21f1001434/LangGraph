@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   Agentic HIP API Configuration Agent - Phase 6 Setup
echo   Primary UI: React/Bun + FastAPI/Python
echo ============================================================
python --version || goto :python_error
python -m pip install -r requirements.txt || goto :fail
where bun >nul 2>nul
if errorlevel 1 goto :bun_error
pushd webapp\frontend
bun install || (popd & goto :fail)
bun run build || (popd & goto :fail)
popd
python runtime_preflight.py --production || goto :fail
echo.
echo Setup complete. Starting the Phase 6 React Studio...
call RUN_AGENTIC_HIP.bat
exit /b %errorlevel%
:python_error
echo Python was not found on PATH.
exit /b 1
:bun_error
echo Bun was not found on PATH.
echo Install Bun for Windows, reopen the terminal, then run this file again.
echo Official installation guide: https://bun.sh/docs/installation
exit /b 1
:fail
echo Setup failed. Review the command output above.
exit /b 1
