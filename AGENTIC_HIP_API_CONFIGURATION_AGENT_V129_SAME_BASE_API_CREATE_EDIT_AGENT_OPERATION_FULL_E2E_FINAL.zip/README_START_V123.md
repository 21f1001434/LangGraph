# START HERE — V123 Intelligent Excel → API Mapper

This package is the full V122 Agentic HIP application plus the V123 governed Excel/CSV → API mapping workflow.

## New V123 workflow

1. Run `SETUP_AGENTIC_HIP.bat` once on a fresh extraction.
2. Run `RUN_AGENTIC_HIP.bat`.
3. Open/build the customer configuration that provides the canonical HIP API contracts.
4. Open **Configure → Excel → API Mapper**.
5. Upload `.xlsx`, `.xlsm`, or `.csv`.
6. Select `AUTO` to rank the best API per row/account, or select one exact API.
7. Optionally leave **Use Dell AIA mapping agents** enabled. If Dell AIA is unavailable, deterministic schema-locked mapping still runs.
8. Review each row as **Good to Trigger**, **Needs Input**, or **Do Not Trigger**.
9. Review Excel column → source value → exact canonical API path → proposed API value → confidence/method.
10. For a **Good to Trigger** row, click **Approve & Stage**. This is the explicit human authorization that persists the agent-prepared VALUES.
11. Run **Agent Preflight**.
12. Only after preflight passes can the user explicitly confirm **Run API LIVE**.

## Governance

- API attributes, nesting, arrays, method, endpoint, request kind, and protected headers are immutable.
- The agent may understand workbook semantics and prepare VALUES only for paths that already exist in the selected canonical request.
- Workbook columns never create new API attributes.
- No analysis call mutates HIP.
- No agent can bypass user Stage approval, preflight, or LIVE confirmation.
- Approved U-HAUL reference remains immutable; clone/create from it before staging customer values.

## Generic API support

AUTO mode evaluates applicable generated requests, so the same engine can be used for Account, Partner, System, Document Type, Map, Rule, Source/Target Transport Profile, validate/audit, Flow create/deploy/history, V122 migration blocks, and future APIs exposed through the canonical request catalog.

## Transport Profile

The mapper understands common team-workbook fields such as HIP account, source/target system, TP name, interface/transport type, document type, environment, server/directory/certificate-related fields, etc. A field is mapped only when a matching canonical attribute exists for the active interface/API contract.

See `README_FINAL_V123_INTELLIGENT_EXCEL_API_MAPPER.md` for implementation details.
