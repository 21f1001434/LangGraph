from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

from execution_flow import STEP_DEFINITIONS


GROUP_COLORS = {
    "Validation": "#2f80ed",
    "Foundation": "#f39c12",
    "Configuration": "#9b51e0",
    "Orchestration": "#10b981",
    "Verification": "#64748b",
    "History": "#64748b",
    "Other": "#2563eb",
}
PASS_COLOR = "#16a34a"
BLOCK_COLOR = "#dc2626"
PENDING_COLOR = "#2563eb"
DISABLED_COLOR = "#94a3b8"


def _plotly():
    import plotly.graph_objects as go
    return go


def _snake_positions(count: int, columns: int = 5) -> List[Tuple[float, float]]:
    positions: List[Tuple[float, float]] = []
    for i in range(count):
        row, col = divmod(i, columns)
        x = col if row % 2 == 0 else (columns - 1 - col)
        y = -row
        positions.append((float(x), float(y)))
    return positions


def _status_by_instance(report: Dict[str, Any] | None) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in (report or {}).get("steps") or []:
        instance = str(row.get("instanceId") or "")
        if instance:
            out[instance] = row
    return out


def mission_flow_figure(flow: Dict[str, Any], report: Dict[str, Any] | None = None):
    """Interactive Scratch-game mission map with hoverable API blocks."""
    go = _plotly()
    components = list(flow.get("components") or [])
    positions = _snake_positions(len(components))
    status_map = _status_by_instance(report)

    fig = go.Figure()
    # Track lines and directional arrows.
    for i in range(max(0, len(positions) - 1)):
        x0, y0 = positions[i]
        x1, y1 = positions[i + 1]
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[y0, y1], mode="lines",
            line=dict(width=5, color="rgba(99,102,241,.28)"),
            hoverinfo="skip", showlegend=False,
        ))
        fig.add_annotation(
            x=x1, y=y1, ax=x0, ay=y0, xref="x", yref="y", axref="x", ayref="y",
            showarrow=True, arrowhead=3, arrowsize=1.1, arrowwidth=2,
            arrowcolor="rgba(99,102,241,.60)", opacity=.9,
        )

    xs, ys, labels, hovers, colors, symbols, sizes = [], [], [], [], [], [], []
    for index, component in enumerate(components, start=1):
        x, y = positions[index - 1]
        instance = str(component.get("instanceId") or "")
        step_key = str(component.get("stepKey") or "")
        meta = STEP_DEFINITIONS.get(step_key) or {}
        group = str(meta.get("group") or "Other")
        label = str(component.get("label") or meta.get("label") or step_key)
        enabled = bool(component.get("enabled", True))
        result_row = status_map.get(instance) or {}
        verdict = str((result_row.get("agentVerdict") or {}).get("verdict") or "").upper()
        outcome = str((result_row.get("agentVerdict") or {}).get("outcome") or "")
        http = (result_row.get("result") or {}).get("status_code")
        elapsed = (result_row.get("result") or {}).get("elapsed_ms")
        if not enabled:
            color, symbol = DISABLED_COLOR, "x"
            state = "DISABLED"
        elif verdict == "PASS":
            color, symbol = PASS_COLOR, "star"
            state = "PASS"
        elif verdict:
            color, symbol = BLOCK_COLOR, "x"
            state = "BLOCKED"
        else:
            color, symbol = GROUP_COLORS.get(group, PENDING_COLOR), "circle"
            state = "READY"
        xs.append(x); ys.append(y); labels.append(str(index)); colors.append(color); symbols.append(symbol)
        sizes.append(44 if verdict else 38)
        hovers.append(
            f"<b>{index}. {label}</b><br>Group: {group}<br>State: {state}"
            f"<br>Instance: {instance}<br>Step key: {step_key}"
            f"<br>HTTP: {http if http is not None else '—'}"
            f"<br>Elapsed: {elapsed if elapsed is not None else '—'} ms"
            f"<br>Outcome: {outcome or '—'}"
        )

    if components:
        fig.add_trace(go.Scatter(
            x=xs, y=ys, mode="markers+text", text=labels, textposition="middle center",
            textfont=dict(color="white", size=13), hovertext=hovers, hoverinfo="text",
            marker=dict(size=sizes, color=colors, symbol=symbols, line=dict(width=3, color="white")),
            showlegend=False,
        ))

    fig.update_layout(
        title=dict(text="🎮 Interactive Mission Map · hover, pan and zoom", x=.02),
        height=max(410, 190 + ((len(components) + 4) // 5) * 145),
        margin=dict(l=20, r=20, t=70, b=20),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(6,18,40,.04)",
        xaxis=dict(visible=False, fixedrange=False), yaxis=dict(visible=False, fixedrange=False),
        dragmode="pan", hovermode="closest",
    )
    return fig


def execution_latency_figure(report: Dict[str, Any]):
    """Interactive latency/status chart for the latest game execution."""
    go = _plotly()
    steps = list(report.get("steps") or [])
    labels, values, colors, hover = [], [], [], []
    for row in steps:
        result = row.get("result") or {}
        verdict = row.get("agentVerdict") or {}
        label = f"{row.get('order')}. {row.get('label') or row.get('stepKey')}"
        elapsed = result.get("elapsed_ms")
        try:
            elapsed_num = float(elapsed or 0)
        except Exception:
            elapsed_num = 0.0
        passed = str(verdict.get("verdict") or "").upper() == "PASS"
        labels.append(label); values.append(elapsed_num); colors.append(PASS_COLOR if passed else BLOCK_COLOR)
        hover.append(
            f"<b>{label}</b><br>Verdict: {verdict.get('verdict') or 'BLOCKED'}"
            f"<br>Outcome: {verdict.get('outcome') or '—'}<br>HTTP: {result.get('status_code') if result.get('status_code') is not None else '—'}"
            f"<br>Elapsed: {elapsed_num:.0f} ms"
        )
    fig = go.Figure(go.Bar(
        x=values, y=labels, orientation="h", marker_color=colors,
        hovertext=hover, hoverinfo="text",
    ))
    fig.update_layout(
        title="⚡ Live API response time & verdict",
        height=max(350, 70 + len(steps) * 38),
        xaxis_title="Elapsed milliseconds", yaxis_title="",
        margin=dict(l=20, r=20, t=60, b=40),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    )
    return fig


def validation_figure(validation: Dict[str, Any]):
    """Interactive per-API contract validation result for uploaded input packages."""
    go = _plotly()
    items = list((validation.get("requests") or {}).get("items") or [])
    labels = [str(row.get("label") or row.get("stepKey") or "API") for row in items]
    values = [1 if row.get("valid") else 0 for row in items]
    colors = [PASS_COLOR if row.get("valid") else BLOCK_COLOR for row in items]
    hover = []
    for row in items:
        errors = "; ".join(str(x) for x in (row.get("errors") or [])) or "None"
        warnings = "; ".join(str(x) for x in (row.get("warnings") or [])) or "None"
        hover.append(f"<b>{row.get('label') or row.get('stepKey')}</b><br>Status: {'PASS' if row.get('valid') else 'BLOCKED'}<br>Errors: {errors}<br>Warnings: {warnings}")
    fig = go.Figure(go.Bar(
        x=values, y=labels, orientation="h", marker_color=colors,
        hovertext=hover, hoverinfo="text",
    ))
    fig.update_layout(
        title="🤖 Agent validation map · all generated API requests",
        height=max(420, 80 + len(items) * 34),
        xaxis=dict(title="Validation", tickmode="array", tickvals=[0, 1], ticktext=["BLOCKED", "PASS"], range=[-0.05, 1.05]),
        yaxis_title="", margin=dict(l=20, r=20, t=65, b=30),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    )
    return fig
