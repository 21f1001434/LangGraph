# V120 Final Package Validation

## Release

V120 ingests the Dev-team HTTPS-AS2 Sender/Receiver `interfaceDetails.parameters` contract supplied on 2026-09-02 while preserving the V119 universal human value-only editor and the immutable 18-API request architecture.

## HTTPS-AS2 contract validation

- Sender schema: **11/11 supplied attributes represented exactly**.
- Receiver schema: **13/13 supplied attributes represented exactly**.
- Removed stale AS2 certificate ID/CN-expiry fields are not emitted by the active V120 AS2 schema.
- Sender certificate equality rule implemented: when `Are SSL and Partner Verification Certificates identical? = Yes`, `SSL Certificate` is omitted from the LIVE request.
- Sender/Receiver file compression rule implemented: when `Are Input Files Compressed? = False`, `Compression Format` is omitted from the LIVE request.
- Enumerated values are validated for Signing Algorithm, Encryption Algorithm, Compression Format, AS2 message compression, asynchronous MDN, EBCDIC, input compression and certificate equality.
- Outer Transport Profile contract remains invariant; only `transportProfileDetails[0].interfaceDetails` varies by interface.
- Human-only value editing remains available in Build Configuration, API Testing Area and API Flow Game; AI/AutoGen/Dell-AIA has no payload edit authority.

## Test results

- Complete repository pytest inventory: **509/509 PASS**.
- Focused V120 + interface lock + V117/V118 governance regression: **42/42 PASS**.
- FastAPI/backend tests with repository root on `PYTHONPATH`: **48/48 PASS**.
- Package validator: **59/59 PASS**.
- Adaptive package validator: **60/60 PASS**.
- Business readiness: **70/70 PASS**.
- Final release validator: **16/16 PASS**.
- Required self-check: **45/45 PASS**.
- Phase 1: **12/12 PASS**.
- Phase 2: **19/19 PASS**.
- Phase 3: **31/31 PASS**.
- Phase 4: **26/26 PASS**.
- Phase 5: **28/28 PASS**.
- Phase 6: **38/38 PASS**.

## Active schema source

The active runtime AS2 schema is:

`schemas/dev_approved_transport_interface_shapes.json` — schema version **3**.

Machine-readable Dev/integration evidence:

`V120_HTTPS_AS2_INTERFACE_CONTRACT_INGEST.json`

## Historical AS2 evidence boundary

V117 AS2 proof JSON files remain in the package as historical release artifacts. Their AS2 certificate-ID/CN-expiry sections are superseded by the V120 contract and are not used by the active V120 runtime schema.

## LIVE boundary

No HIP LIVE API calls were executed during package validation. The validation above verifies request construction, schema locking, UI/backend governance, deterministic conditional omission behavior, and non-mutating release gates.

Runtime proof: `V120_AS2_RUNTIME_PROOF.json` confirms both conditional omissions and confirms the older AS2 certificate ID/CN-expiry fields are absent from active materialized parameters.

## Fresh-extracted ZIP verification

- Package cleanliness before execution: **0 `__pycache__`, 0 `.pyc`, 0 `.env`, 0 runtime report files**.
- Focused V117/V118/V119/V120 governance + interface regression from extracted ZIP: **44/44 PASS**.
- Package validator from extracted ZIP: **59/59 PASS**.
