from pathlib import Path
import os
import subprocess
import sys

from production_guard import validate_production_readiness
from webapp.backend.app.legacy_adapter import _utf8_worker_env


def test_v65_production_guard_uses_effective_document_type_requests(tmp_path: Path, monkeypatch):
    # Raw helper metadata is intentionally stale/wrong. The final gate must use
    # the exact effective request used by API Testing / Flow Game / Execute.
    input_data = {
        "customer": "LEGRAND_NEDERLAND",
        "flow_type": "Translation",
        "requires_data_map": False,
        "objects": {
            "source_document_type": {"api_transaction_type": "OUTBOUND"},
            "target_document_type": {"api_transaction_type": "INBOUND"},
        },
    }
    for name in ("HIP_CLIENT_ID", "HIP_CLIENT_SECRET", "DELL_AIA_CLIENT_ID", "DELL_AIA_CLIENT_SECRET"):
        monkeypatch.setenv(name, "test-value")

    result = validate_production_readiness(
        root=tmp_path,
        input_data=input_data,
        config={"hipEnvironment": "DEV"},
        urls={"document_type": "https://example.test/document-type"},
        token_url="https://example.test/oauth/token",
        requester="agent@example.test",
        verify_ssl=True,
        effective_requests={
            "doctype_source": {"payload": {"transactionType": "INBOUND"}},
            "doctype_target": {"payload": {"transactionType": "OUTBOUND"}},
        },
    )
    checks = {row.get("check") for row in result.get("errors", [])}
    assert "source-transaction-type" not in checks
    assert "target-transaction-type" not in checks


def test_v65_windows_workers_force_utf8(tmp_path: Path):
    env = _utf8_worker_env(tmp_path)
    assert env["PYTHONUTF8"] == "1"
    assert env["PYTHONIOENCODING"].lower() == "utf-8"
    proc = subprocess.run(
        [sys.executable, "-c", "print('customer‑payload ✓')"],
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="strict",
        check=True,
    )
    assert "customer‑payload ✓" in proc.stdout


def test_v65_execute_metrics_do_not_reuse_api_testing_result_metrics():
    root = Path(__file__).resolve().parent
    page = (root / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    css = (root / "webapp/frontend/src/styles.css").read_text(encoding="utf-8")
    assert 'className="execution-result-metrics"' in page
    assert ".execution-result-metrics" in css
    assert "white-space:nowrap" in css
    assert "grid-template-columns:repeat(7,minmax(96px,1fr))" in css
