# START HERE — V124 Patch 2

This is the coherent V124 full package with the Excel Mapper frontend contract synchronization fix.

**Do not merge into the old mixed folder. Extract into a new empty directory.**

Then:

```powershell
python -m pip install -r requirements.txt
cd webapp\frontend
bun install
bun run build
cd ..\..
RUN_AGENTIC_HIP.bat
```

If you want to validate only the frontend contract first, run:

```powershell
.\VERIFY_V124_PATCH2_FRONTEND.ps1
```
