from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import run_agent


ROOT = Path(__file__).resolve().parent


class FakeTokenResponse:
    status_code = 200
    ok = True
    url = "https://token.example.test/oauth/token"
    headers = {"Content-Type": "application/json"}
    history = []
    text = '{"access_token":"TEST_TOKEN","token_type":"Bearer","expires_in":3600}'

    def json(self):
        return {"access_token": "TEST_TOKEN", "token_type": "Bearer", "expires_in": 3600}


def main() -> None:
    env = {
        "HIP_TOKEN_URL": "https://token.example.test/oauth/token",
        "HIP_CLIENT_ID": "hip-id",
        "HIP_CLIENT_SECRET": "hip-secret",
        "ACCOUNT_TOKEN_URL": "https://token.example.test/oauth/token",
        "ACCOUNT_CLIENT_ID": "account-id",
        "ACCOUNT_CLIENT_SECRET": "account-secret",
        "PARTNER_TOKEN_URL": "https://token.example.test/oauth/token",
        "PARTNER_CLIENT_ID": "partner-id",
        "PARTNER_CLIENT_SECRET": "partner-secret",
        "SYSTEM_TOKEN_URL": "https://token.example.test/oauth/token",
        "SYSTEM_CLIENT_ID": "system-id",
        "SYSTEM_CLIENT_SECRET": "system-secret",
    }

    observed = []

    def fake_post(self, url, **kwargs):
        auth = kwargs.get("auth")
        observed.append({
            "url": url,
            "username": getattr(auth, "username", None),
            "password": getattr(auth, "password", None),
            "data": kwargs.get("data"),
            "allow_redirects": kwargs.get("allow_redirects"),
        })
        response = FakeTokenResponse()
        response.url = url
        return response

    run_agent.TOKEN_CACHE.clear()
    with patch.dict(os.environ, env, clear=False), patch.object(
        run_agent.requests.Session,
        "post",
        new=fake_post,
    ):
        runner = run_agent.Runner(llm_enabled=False)
        for kind in ("HIP", "ACCOUNT", "PARTNER", "SYSTEM"):
            token = runner.get_token(kind, "")
            assert token == "TEST_TOKEN"

    usernames = [item["username"] for item in observed]
    assert usernames == ["hip-id", "account-id", "partner-id", "system-id"], usernames
    assert all(item["data"] == {"grant_type": "client_credentials"} for item in observed)
    assert all(item["allow_redirects"] is True for item in observed)

    output = {
        "status": "PASS",
        "buildId": run_agent.BUILD_ID,
        "oauthProfiles": usernames,
        "basicAuth": True,
        "grantType": "client_credentials",
        "separateAccountPartnerSystemCredentials": True,
    }
    path = ROOT / "examples" / "SERVICE_CREDENTIALS_TEST.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
