from __future__ import annotations

import copy
import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from agentq_memory import AgentQTrajectoryMemory
from knowledge_graph import HipKnowledgeGraph


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


def tokens(value: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", str(value).lower()))


def deep_get(data: Any, path: str, default: Any = None) -> Any:
    current = data
    for part in path.split(".") if path else []:
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except Exception:
                return default
        elif isinstance(current, dict):
            if part not in current:
                return default
            current = current[part]
        else:
            return default
    return default if current is None else current


def deep_set(data: Dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".")
    current: Any = data
    for index, part in enumerate(parts[:-1]):
        next_part = parts[index + 1]
        if isinstance(current, list):
            pos = int(part)
            while len(current) <= pos:
                current.append({} if not next_part.isdigit() else [])
            current = current[pos]
        else:
            if part not in current or not isinstance(current[part], (dict, list)):
                current[part] = [] if next_part.isdigit() else {}
            current = current[part]
    final = parts[-1]
    if isinstance(current, list):
        pos = int(final)
        while len(current) <= pos:
            current.append(None)
        current[pos] = value
    else:
        current[final] = value


def deep_delete(data: Dict[str, Any], path: str) -> bool:
    parts = path.split(".")
    current: Any = data
    for part in parts[:-1]:
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except Exception:
                return False
        elif isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return False
    final = parts[-1]
    if isinstance(current, dict) and final in current:
        del current[final]
        return True
    if isinstance(current, list):
        try:
            current.pop(int(final))
            return True
        except Exception:
            return False
    return False


def flatten(data: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    rows: List[Tuple[str, Any]] = []
    # Include container nodes so aliases can map complete arrays/objects such
    # as attributes, conditions and document identifiers.
    if prefix:
        rows.append((prefix, data))
    if isinstance(data, dict):
        for key, value in data.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            rows.extend(flatten(value, path))
    elif isinstance(data, list):
        for index, value in enumerate(data):
            path = f"{prefix}.{index}" if prefix else str(index)
            rows.extend(flatten(value, path))
    return rows


@dataclass
class FieldResolution:
    canonical_path: str
    value: Any
    source_path: str
    confidence: float
    method: str
    required: bool
    safe_to_apply: bool
    reason: str


@dataclass
class MissingField:
    canonical_path: str
    required: bool
    suggestion: Any
    safe_to_apply: bool
    source: str
    question: str


FIELD_SPECS: Dict[str, Dict[str, Any]] = {
    "customer": {"required": True, "aliases": ["customer", "customer_name", "partner_customer", "trading_partner", "client"]},
    "direction": {"required": True, "aliases": ["direction", "flow_direction", "inbound_outbound", "transaction_direction"]},
    "flow_type": {"required": False, "aliases": ["flow_type", "flowType", "translation_passthrough", "processing_type"]},
    "requires_data_map": {"required": False, "aliases": ["requires_data_map", "requiresDataMap", "data_map_required", "mapping_required"]},
    "passthrough_target_document_type_required": {"required": False, "aliases": ["passthrough_target_document_type_required", "passthrough_separate_target_document_type", "separate_target_document_type"]},
    "tx_standard": {"required": False, "aliases": ["tx_standard", "transaction_standard", "standard", "edi_standard"]},
    "tx_code": {"required": True, "aliases": ["tx_code", "transaction_code", "transaction_type_code", "edi_transaction", "message_type"]},
    "tx_name": {"required": False, "aliases": ["tx_name", "transaction_name", "message_name", "document_name"]},
    "dell_app": {"required": False, "aliases": ["dell_app", "source_application", "source_app", "application"]},
    "profile_name": {"required": True, "aliases": ["profile_name", "flow_name", "business_flow_name", "businessflowname"]},
    "partner_identifier_value": {"required": True, "aliases": ["partner_identifier_value", "partnerIdentifierValue", "partner_duns", "duns", "duns_number"], "question": "What is the Dev-approved Partner Identifier / DUNS value for the external partner?"},
    "objects.source_document_type.name": {"required": True, "aliases": ["source_document_type_name", "source_doc_type", "source_doctype", "source_document_name"]},
    "objects.source_document_type.version": {"required": False, "aliases": ["source_document_type_version", "source_doc_version", "source_version"]},
    "objects.source_document_type.data_format_type": {"required": True, "aliases": ["source_data_format", "source_format", "input_format"]},
    "objects.source_document_type.validation_type": {"required": False, "aliases": ["source_validation_type", "source_schema_validation"]},
    "objects.source_document_type.api_transaction_type": {"required": True, "aliases": ["source_api_transaction_type", "source_direction", "source_transaction_direction"]},
    "objects.source_document_type.root_element": {"required": True, "aliases": ["source_root_element", "source_root", "input_root_element"]},
    "objects.source_document_type.attributes_to_configure": {"required": True, "aliases": ["source_attributes", "source_document_attributes", "source_attribute_list"]},
    "objects.target_document_type.name": {"required": True, "aliases": ["target_document_type_name", "target_doc_type", "target_doctype", "target_document_name"]},
    "objects.target_document_type.version": {"required": False, "aliases": ["target_document_type_version", "target_doc_version", "target_version"]},
    "objects.target_document_type.data_format_type": {"required": True, "aliases": ["target_data_format", "target_format", "output_format"]},
    "objects.target_document_type.validation_type": {"required": False, "aliases": ["target_validation_type", "target_schema_validation"]},
    "objects.target_document_type.api_transaction_type": {"required": True, "aliases": ["target_api_transaction_type", "target_direction", "target_transaction_direction"]},
    "objects.target_document_type.root_element": {"required": True, "aliases": ["target_root_element", "target_root", "output_root_element"]},
    "objects.target_document_type.attributes_to_configure": {"required": True, "aliases": ["target_attributes", "target_document_attributes", "target_attribute_list"]},
    "objects.data_map.map_identifier": {"required": True, "aliases": ["map_identifier", "mapping_identifier", "map_id_name"]},
    "objects.data_map.map_identifier_version": {"required": False, "aliases": ["map_identifier_version", "map_version", "mapping_version"]},
    "objects.data_map.map_name": {"required": True, "aliases": ["map_name", "mapping_name", "transformation_name"]},
    "objects.data_map.map_class": {"required": True, "aliases": ["map_class", "mapping_class", "transform_class"]},
    "objects.data_map.map_data_file": {"required": True, "aliases": ["map_data_file", "map_file", "jar_file", "transformation_file"]},
    "objects.rule.name": {"required": True, "aliases": ["rule_name", "mapping_rule_name", "map_rule_name"]},
    "objects.rule.version": {"required": False, "aliases": ["rule_version", "mapping_rule_version"]},
    "objects.rule.conditions.rows": {"required": True, "aliases": ["rule_conditions", "mapping_conditions", "conditions", "routing_conditions"]},
    "objects.source_transport_profile.partner_name": {"required": True, "aliases": ["source_system", "source_system_name", "source_application"]},
    "objects.source_transport_profile.profile_name": {"required": True, "aliases": ["source_transport_profile", "source_tp_name", "source_profile_name"]},
    "objects.source_transport_profile.profile_usage": {"required": True, "aliases": ["source_profile_usage", "source_usage", "source_role"]},
    "objects.source_transport_profile.interface_type": {"required": True, "aliases": ["source_interface_type", "source_protocol", "source_transport_type"]},
    "objects.source_transport_profile.existing_account_name": {"required": True, "aliases": ["source_account", "source_haft_account", "source_existing_account"]},
    "objects.source_transport_profile.subscription_folder": {"required": True, "aliases": ["source_folder", "source_subscription_folder", "source_path"]},
    "objects.target_transport_profile.partner_name": {"required": True, "aliases": ["target_partner", "target_system", "target_partner_name"]},
    "objects.target_transport_profile.profile_name": {"required": True, "aliases": ["target_transport_profile", "target_tp_name", "target_profile_name"]},
    "objects.target_transport_profile.profile_usage": {"required": True, "aliases": ["target_profile_usage", "target_usage", "target_role"]},
    "objects.target_transport_profile.interface_type": {"required": True, "aliases": ["target_interface_type", "target_protocol", "target_transport_type"]},
    "objects.target_transport_profile.existing_account_name": {"required": True, "aliases": ["target_account", "target_haft_account", "target_existing_account"]},
    "objects.target_transport_profile.subscription_folder": {"required": True, "aliases": ["target_folder", "target_subscription_folder", "target_path"]},
}


class AdaptiveHipEngine:
    """Adaptive mapper/change agent for U-HAUL and new HIP customer inputs."""

    def __init__(self, root: Path):
        self.root = Path(root)
        self.reports = self.root / "reports"
        self.reports.mkdir(parents=True, exist_ok=True)
        self.kg = HipKnowledgeGraph(self.root)
        self.agentq = AgentQTrajectoryMemory(self.root)

    def _find_candidate(self, rows: List[Tuple[str, Any]], canonical_path: str, aliases: Sequence[str]) -> Optional[FieldResolution]:
        direct = [(p, v) for p, v in rows if p == canonical_path and v not in (None, "")]
        if direct:
            p, v = direct[0]
            return FieldResolution(canonical_path, v, p, 1.0, "exact-path", True, True, "Exact canonical path supplied.")

        alias_keys = {normalize_key(x) for x in aliases}
        alias_keys.add(normalize_key(canonical_path.split(".")[-1]))
        exact_alias: List[Tuple[str, Any]] = []
        for path, value in rows:
            if value in (None, ""):
                continue
            leaf = normalize_key(path.split(".")[-1])
            full = normalize_key(path)
            if leaf in alias_keys or full in alias_keys:
                exact_alias.append((path, value))
        if exact_alias:
            exact_alias.sort(key=lambda item: (len(item[0].split(".")), len(item[0])))
            p, v = exact_alias[0]
            return FieldResolution(canonical_path, v, p, 0.92, "alias", True, True, "Matched a configured field alias.")

        canonical_tokens = tokens(canonical_path.replace("objects.", ""))
        best: Optional[Tuple[float, str, Any]] = None
        for path, value in rows:
            if value in (None, "") or isinstance(value, (dict, list)):
                continue
            path_tokens = tokens(path)
            if not canonical_tokens or not path_tokens:
                continue
            overlap = len(canonical_tokens & path_tokens) / max(1, len(canonical_tokens | path_tokens))
            if overlap >= 0.45 and (best is None or overlap > best[0]):
                best = (overlap, path, value)
        if best:
            score, p, v = best
            return FieldResolution(canonical_path, v, p, round(score, 3), "token-similarity", True, score >= 0.65, "Matched by field-name token similarity.")
        return None

    @staticmethod
    def _normalize_direction(value: Any) -> str:
        raw = str(value or "").strip().lower()
        if raw in {"outbound", "out", "ob", "sender", "send"}:
            return "Outbound"
        if raw in {"inbound", "in", "ib", "receiver", "receive"}:
            return "Inbound"
        return str(value or "")

    @staticmethod
    def _slug(value: Any) -> str:
        clean = re.sub(r"[^A-Za-z0-9]+", "-", str(value or "").strip()).strip("-")
        return clean.upper()

    def _safe_inferences(self, canonical: Dict[str, Any]) -> List[MissingField]:
        customer = self._slug(deep_get(canonical, "customer", ""))
        direction = self._normalize_direction(deep_get(canonical, "direction", ""))
        tx_code = str(deep_get(canonical, "tx_code", "") or "").strip()
        dell_app = self._slug(deep_get(canonical, "dell_app", "ANS")) or "ANS"
        source_root = deep_get(canonical, "objects.source_document_type.root_element", "")
        target_root = deep_get(canonical, "objects.target_document_type.root_element", "")
        flow_type = str(deep_get(canonical, "flow_type", "") or "").strip().lower()
        requires_map = deep_get(canonical, "requires_data_map", None)
        translation = flow_type == "translation" or (flow_type not in {"passthrough", "pass-through"} and bool(requires_map))
        direction_suffix = "OB" if direction.lower() == "outbound" else "IB" if direction.lower() == "inbound" else ""

        suggestions: List[MissingField] = []
        def suggest(path: str, value: Any, safe: bool, source: str, question: str, required: bool = True) -> None:
            if deep_get(canonical, path, None) in (None, "", [], {}):
                suggestions.append(MissingField(path, required, value, safe, source, question))

        if customer and tx_code and direction_suffix:
            suggest("profile_name", f"{customer}_PC_{tx_code}_{dell_app}_MAPPING_{direction_suffix}", True, "naming-template", "Confirm the generated business flow name.")
        suggest("tx_standard", "X12", True, "default", "Confirm the transaction standard.", False)
        suggest("tx_name", "Ship Notice" if tx_code == "856" else "", tx_code == "856", "transaction-catalog", "Provide the transaction display name.", False)
        # V127: Document Type versions are business evidence, not safe defaults.
        # Do not fabricate 1/1.0 when input/Excel does not supply a version.
        suggest("objects.source_document_type.data_format_type", "XML", True, "default", "Confirm source data format.")
        if translation:
            suggest("objects.target_document_type.data_format_type", "XML", True, "default", "Confirm target data format.")
        suggest("objects.source_document_type.validation_type", "Structure", True, "dev-contract", "Confirm source validation type.", False)
        if translation:
            suggest("objects.target_document_type.validation_type", "Structure", True, "dev-contract", "Confirm target validation type.", False)
        suggest("objects.source_document_type.api_transaction_type", "INBOUND", True, "hip-api-contract", "Confirm source API transaction direction.")
        if translation:
            suggest("objects.target_document_type.api_transaction_type", "OUTBOUND", True, "hip-api-contract", "Confirm target API transaction direction.")
        if customer and tx_code and direction_suffix:
            suggest("objects.source_document_type.name", f"XML_SOURCE_{tx_code}_{customer}_{dell_app}_IB", False, "naming-template", "Provide or approve the source Document Type name.")
            if translation:
                suggest("objects.target_document_type.name", f"XML_TARGET_{tx_code}_{customer}_{dell_app}_OB", False, "naming-template", "Provide or approve the target Document Type name.")
                suggest("objects.rule.name", f"MAP_{tx_code}_{customer}_{dell_app}_RULE", False, "naming-template", "Provide or approve the mapping Rule name.")
            suggest("objects.source_transport_profile.profile_name", f"SFTP_{customer}_{tx_code}_{dell_app}_SRC_IB", False, "naming-template", "Provide or approve the Source TP name.")
            suggest("objects.target_transport_profile.profile_name", f"SFTP_{customer}_{tx_code}_{dell_app}_TGT_OB", False, "naming-template", "Provide or approve the Target TP name.")
        suggest("objects.source_transport_profile.profile_usage", "Sender", True, "direction-rule", "Confirm Source TP usage.")
        suggest("objects.target_transport_profile.profile_usage", "Receiver", True, "direction-rule", "Confirm Target TP usage.")
        suggest("objects.source_transport_profile.interface_type", "SFTP HAFT", False, "protocol-default", "Provide the source interface type.")
        suggest("objects.target_transport_profile.interface_type", "SFTP HAFT", False, "protocol-default", "Provide the target interface type.")
        map_file = deep_get(canonical, "objects.data_map.map_data_file", "")
        if translation and map_file:
            inferred_class = Path(str(map_file)).stem
            suggest("objects.data_map.map_class", inferred_class, inferred_class.startswith("Transform_"), "map-file-name", "Provide or approve the map class name.")
        if translation:
            suggest("objects.data_map.map_identifier_version", "1", True, "default", "Confirm map version.", False)
            suggest("objects.rule.version", "1", True, "default", "Confirm rule version.", False)
        suggest("objects.source_transport_profile.deployment_group", "hip-automation", True, "confirmed-dev-rule", "Confirm Source deployment group.", False)
        suggest("objects.target_transport_profile.deployment_group", "hip-automation", True, "confirmed-dev-rule", "Confirm Target deployment group.", False)
        if source_root:
            suggest("objects.source_document_type.api_document_identifier", {"operator": "ALL", "attributeList": [{"derivedFrom": "TRANSACTION_ROOT_ELEMENT", "value": source_root}]}, True, "root-element", "Confirm source document identifier.")
        if translation and target_root:
            suggest("objects.target_document_type.api_document_identifier", {"operator": "ALL", "attributeList": [{"derivedFrom": "TRANSACTION_ROOT_ELEMENT", "value": target_root}]}, True, "root-element", "Confirm target document identifier.")
        return suggestions

    def analyze_input(self, raw_input: Dict[str, Any], use_aia: bool = False, aia_complete_json: Optional[Callable[..., Dict[str, Any]]] = None) -> Dict[str, Any]:
        rows = flatten(raw_input)
        canonical: Dict[str, Any] = {"objects": {}}
        resolutions: List[FieldResolution] = []
        for path, spec in FIELD_SPECS.items():
            resolution = self._find_candidate(rows, path, spec.get("aliases") or [])
            if resolution:
                resolution.required = bool(spec.get("required"))
                deep_set(canonical, path, resolution.value)
                resolutions.append(resolution)

        if deep_get(canonical, "direction", None):
            deep_set(canonical, "direction", self._normalize_direction(deep_get(canonical, "direction")))

        # Resolve root elements from the exact Dev/API documentIdentifier shape
        # when a separate root_element field was not supplied.
        for kind in ("source", "target"):
            root_path = f"objects.{kind}_document_type.root_element"
            if deep_get(canonical, root_path, None) in (None, ""):
                candidates = [
                    deep_get(raw_input, f"objects.{kind}_document_type.api_document_identifier.attributeList.0.value"),
                    deep_get(raw_input, f"objects.{kind}_document_type.document_identifier.rows.0.value"),
                    deep_get(canonical, f"objects.{kind}_document_type.api_document_identifier.attributeList.0.value"),
                ]
                root_value = next((value for value in candidates if value not in (None, "")), None)
                if root_value:
                    deep_set(canonical, root_path, root_value)
                    resolutions.append(FieldResolution(root_path, root_value, "documentIdentifier", 0.98, "derived-root", True, True, "Derived from the transaction-root document identifier."))

        # Canonical flow applicability is deterministic.  Explicit input wins;
        # otherwise mapping artifacts mean Translation, while absence of mapping
        # artifacts means Passthrough.
        explicit_flow = str(deep_get(canonical, "flow_type", "") or "").strip().lower()
        explicit_requires = deep_get(canonical, "requires_data_map", None)
        has_mapping_artifact = any(
            deep_get(canonical, path, None) not in (None, "", [], {})
            for path in ("objects.data_map.map_identifier", "objects.data_map.map_name", "objects.data_map.map_data_file")
        )
        if explicit_flow in {"translation", "mapping"} or explicit_requires is True or has_mapping_artifact:
            deep_set(canonical, "flow_type", "translation")
            deep_set(canonical, "requires_data_map", True)
        elif explicit_flow in {"passthrough", "pass-through", "pass through"} or explicit_requires is False:
            deep_set(canonical, "flow_type", "passthrough")
            deep_set(canonical, "requires_data_map", False)
        else:
            deep_set(canonical, "flow_type", "passthrough")
            deep_set(canonical, "requires_data_map", False)

        suggestions = self._safe_inferences(canonical)
        missing_paths = {item.canonical_path for item in suggestions}
        translation = str(deep_get(canonical, "flow_type", "") or "").lower() == "translation"
        separate_passthrough_target = bool(deep_get(canonical, "passthrough_target_document_type_required", False)) and not translation
        for path, spec in FIELD_SPECS.items():
            if not translation and path.startswith("objects.data_map."):
                continue
            if not translation and path.startswith("objects.rule."):
                continue
            if not translation and not separate_passthrough_target and path.startswith("objects.target_document_type."):
                continue
            if spec.get("required") and deep_get(canonical, path, None) in (None, "", [], {}):
                if path not in missing_paths:
                    suggestions.append(MissingField(path, True, None, False, "user-required", spec.get("question") or f"Provide the missing value for {path}."))

        aia_suggestions: List[Dict[str, Any]] = []
        if use_aia and aia_complete_json is not None and suggestions:
            safe_missing = [asdict(item) for item in suggestions if "secret" not in item.canonical_path.lower()]
            result = aia_complete_json(
                system=(
                    "You map arbitrary customer HIP configuration JSON into a canonical HIP model. "
                    "Use only the supplied input and field definitions. Never invent credentials, IDs, account names, partner names, XPath expressions, schemas or internal entitlements. "
                    "Return JSON with suggestions: [{canonicalPath,value,confidence,safeToApply,reason,question}]."
                ),
                user=json.dumps({"input": raw_input, "deterministicCanonical": canonical, "missing": safe_missing}, default=str)[:28000],
                temperature=0,
            )
            aia_suggestions = result.get("suggestions") or []

        analysis_id = hashlib.sha256(json.dumps(raw_input, sort_keys=True, default=str).encode()).hexdigest()[:16]
        report = {
            "analysisId": analysis_id,
            "generatedAt": utc_now(),
            "canonicalPreview": canonical,
            "resolutions": [asdict(item) for item in resolutions],
            "missing": [asdict(item) for item in suggestions],
            "aiaSuggestions": aia_suggestions,
            "ready": not any(item.required and not item.safe_to_apply for item in suggestions),
        }
        path = self.reports / "adaptive_input_analysis_latest.json"
        path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
        self.agentq.record_trajectory(
            "input_mapping", {"inputHash": analysis_id, "fieldCount": len(rows)},
            {"resolutions": report["resolutions"]},
            {"missing": report["missing"], "ready": report["ready"]},
            1.0 if report["ready"] else -0.2,
            "Deterministic schema discovery and alias mapping.",
        )
        return report

    def prepare_canonical_input(self, raw_input: Dict[str, Any], apply_safe: bool = True, use_aia: bool = False, aia_complete_json: Optional[Callable[..., Dict[str, Any]]] = None) -> Dict[str, Any]:
        analysis = self.analyze_input(raw_input, use_aia=use_aia, aia_complete_json=aia_complete_json)
        canonical = copy.deepcopy(analysis["canonicalPreview"])
        applied: List[Dict[str, Any]] = []
        unresolved: List[Dict[str, Any]] = []
        for item in analysis["missing"]:
            if apply_safe and item.get("safe_to_apply") and item.get("suggestion") not in (None, ""):
                deep_set(canonical, item["canonical_path"], item["suggestion"])
                applied.append(item)
            else:
                unresolved.append(item)

        # Preserve rich canonical sections already provided in the uploaded input.
        if isinstance(raw_input.get("objects"), dict):
            for object_key, object_value in raw_input["objects"].items():
                existing = deep_get(canonical, f"objects.{object_key}", None)
                if existing in (None, {}, []):
                    deep_set(canonical, f"objects.{object_key}", copy.deepcopy(object_value))
                elif isinstance(existing, dict) and isinstance(object_value, dict):
                    merged = copy.deepcopy(object_value)
                    merged.update(existing)
                    deep_set(canonical, f"objects.{object_key}", merged)

        # Re-establish flow applicability after rich-object preservation.
        # Explicit flow_type/requires_data_map wins; Passthrough defaults to one
        # Document Type and no map/rule. A separate target Document Type is an
        # explicit Passthrough exception only.
        flow_type = str(deep_get(canonical, "flow_type", "") or "").strip().lower()
        translation = flow_type == "translation" or (flow_type not in {"passthrough", "pass-through"} and bool(deep_get(canonical, "requires_data_map", False)))
        separate_passthrough_target = bool(deep_get(canonical, "passthrough_target_document_type_required", False)) and not translation
        deep_set(canonical, "flow_type", "translation" if translation else "passthrough")
        deep_set(canonical, "requires_data_map", bool(translation))
        if not translation:
            deep_set(canonical, "objects.data_map", {
                "map_identifier": "", "map_identifier_version": "", "status": "",
                "map_name": "", "map_class": "", "contivo_version": "", "map_data_file": "",
                "_passthrough": True, "_note": "Passthrough flow — no data map required",
            })
            deep_set(canonical, "objects.rule", {
                "name": "NA", "version": "NA", "rule_type": "NA", "rule_scope": "NA",
                "status": "NA", "description": "NA", "_passthrough": True,
            })
            if not separate_passthrough_target:
                deep_set(canonical, "objects.target_document_type", {
                    "name": "", "version": "", "data_format_type": "", "status": "",
                    "description": "", "validation_type": "",
                    "document_identifier": {"operation": "", "rows": []},
                    "attributes_to_configure": [], "_passthrough": True,
                    "_note": "Passthrough flow — no separate Target Document Type; target reuses Source Document Type.",
                })

        # Convert helper root_element into the exact API identifier shape.
        for kind in (("source", "target") if (translation or separate_passthrough_target) else ("source",)):
            doc_path = f"objects.{kind}_document_type"
            doc = deep_get(canonical, doc_path, {}) or {}
            root_element = doc.pop("root_element", None)
            if root_element and not doc.get("api_document_identifier"):
                doc["api_document_identifier"] = {"operator": "ALL", "attributeList": [{"derivedFrom": "TRANSACTION_ROOT_ELEMENT", "value": root_element}]}
            if root_element and not doc.get("document_identifier"):
                doc["document_identifier"] = {"operation": "All conditions are satisfied", "rows": [{"derived_from": "TRANSACTION_ROOT_ELEMENT", "value": root_element}]}
            deep_set(canonical, doc_path, doc)

        # Enrich the canonical structure expected by the API payload builder.
        customer = self._slug(deep_get(canonical, "customer", "CUSTOMER"))
        tx_code = str(deep_get(canonical, "tx_code", "") or "")
        flow_name = str(deep_get(canonical, "profile_name", "") or "")
        source_doc = deep_get(canonical, "objects.source_document_type", {}) or {}
        target_doc = deep_get(canonical, "objects.target_document_type", {}) or {}

        def doc_name_version(doc: Dict[str, Any]) -> str:
            name = str(doc.get("name") or "").strip()
            version = str(doc.get("version") or "").strip()
            if not name:
                return ""
            return f"{name}({version})" if version else name
        source_doc.setdefault("transaction_type", tx_code)
        source_doc.setdefault("status", "Enable")
        source_doc.setdefault("status_disabled", False)
        source_doc.setdefault("description", source_doc.get("name") or "")
        source_doc.setdefault("last_modified_by", "")
        if translation or separate_passthrough_target:
            target_doc.setdefault("transaction_type", tx_code)
            target_doc.setdefault("status", "Enable")
            target_doc.setdefault("status_disabled", False)
            target_doc.setdefault("description", target_doc.get("name") or "")
            target_doc.setdefault("last_modified_by", "")
        deep_set(canonical, "objects.source_document_type", source_doc)
        deep_set(canonical, "objects.target_document_type", target_doc)

        data_map = deep_get(canonical, "objects.data_map", {}) or {}
        rule = deep_get(canonical, "objects.rule", {}) or {}
        if translation:
            data_map.setdefault("status", "Enable")
            data_map.setdefault("contivo_version", "6.7")
            rule.setdefault("rule_type", "Mapping")
            rule.setdefault("rule_scope", "GLOBAL")
            rule.setdefault("status", "Enable")
            rule.setdefault("description", rule.get("name") or "")
            rule.setdefault("conditions", {"execute_actions_when": "all conditions are satisfied", "rows": []})
            rule.setdefault("actions", {
                "action_name": f"{rule.get('name') or 'MAPPING_RULE'}_ACTION",
                "action_type": "Route Document",
                "mapping_identifier_name_version": f"{data_map.get('map_identifier') or ''}({str(data_map.get('map_identifier_version') or '1')}.0)",
            })
        deep_set(canonical, "objects.data_map", data_map)
        deep_set(canonical, "objects.rule", rule)

        for kind, usage in (("source", "Sender"), ("target", "Receiver")):
            tp_path = f"objects.{kind}_transport_profile"
            tp = deep_get(canonical, tp_path, {}) or {}
            tp.setdefault("profile_usage", usage)
            tp["deployment_group"] = "hip-automation"
            tp.setdefault("interface_environment", "UAT")
            tp.setdefault("existing_account", "Yes")
            tp.setdefault("use_existing_folder", "No")
            tp.setdefault("post_transfer_action", "Move To Archive")
            tp.setdefault("is_compression_required", "FALSE")
            doc = source_doc if kind == "source" else (target_doc if (translation or separate_passthrough_target) and target_doc.get("name") else source_doc)
            tp["document_type"] = doc_name_version(doc)
            deep_set(canonical, tp_path, tp)

        source_tp = deep_get(canonical, "objects.source_transport_profile", {}) or {}
        target_tp = deep_get(canonical, "objects.target_transport_profile", {}) or {}
        conditions = deep_get(canonical, "objects.rule.conditions.rows", []) or []
        flow_conditions = [
            {
                "document_type_name_version": doc_name_version(source_doc),
                "attribute_name": row.get("attribute_name_unit") or row.get("attribute_name"),
                "operator": row.get("operator"),
                "value": row.get("value"),
            }
            for row in conditions if isinstance(row, dict)
        ]
        biz_flow = deep_get(canonical, "objects.biz_flow", {}) or {}
        biz_flow.setdefault("flow_details", {
            "current_flow_version": "1",
            "business_flow_name": flow_name,
            "flow_description": f"{deep_get(canonical, 'direction', 'Outbound')} {tx_code} {deep_get(canonical, 'tx_name', '')} - DELL to {customer}",
        })
        biz_flow.setdefault("configure_source", {
            "source_type": source_tp.get("system_type") or "Dell Application",
            "source_application": source_tp.get("partner_name") or "AIC - DCE",
            "source_transport_profile": source_tp.get("profile_name"),
            "document_type_name_version": doc_name_version(source_doc),
        })
        biz_flow.setdefault("flow_identifiers", {"operator": "all conditions are satisfied", "conditions": flow_conditions})
        effective_target_doc = target_doc if (translation or separate_passthrough_target) and target_doc.get("name") else source_doc
        target_cfg = biz_flow.setdefault("configure_targets", {
            "target_type": target_tp.get("system_type") or "Partner",
            "target_application": target_tp.get("partner_name"),
            "target_transport_profile": target_tp.get("profile_name"),
            "document_type_name_version": doc_name_version(effective_target_doc),
        })
        if isinstance(target_cfg, dict) and not translation and not separate_passthrough_target:
            target_cfg["document_type_name_version"] = doc_name_version(source_doc)
        if not translation:
            steps = biz_flow.get("process_steps") if isinstance(biz_flow.get("process_steps"), list) else []
            biz_flow["process_steps"] = [
                step for step in steps
                if isinstance(step, dict) and str(step.get("step_type") or step.get("type") or "").strip().lower()
                not in {"mapping transformer", "mappingtransformer", "mapping"}
            ]
        deep_set(canonical, "objects.biz_flow", biz_flow)

        output = {
            "canonicalInput": canonical,
            "appliedSafeSuggestions": applied,
            "unresolvedQuestions": unresolved,
            "ready": not any(item.get("required") for item in unresolved),
            "analysis": analysis,
        }
        path = self.reports / "adaptive_canonical_input_latest.json"
        path.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
        return output

    def _deterministic_change_patch(self, request_text: str) -> List[Dict[str, Any]]:
        text = request_text.strip()
        lower = text.lower()
        patch: List[Dict[str, Any]] = []

        url = re.search(r"https?://[^\s\]\)\"']+", text)
        if url and ("base" in lower or "url" in lower):
            patch.append({"target": "config", "op": "set", "path": "hip_config_service_base_url", "value": url.group(0).rstrip(".,")})

        # Dev-team automation rule is mandatory for every interface.  A user/LLM
        # request must never override the automation deployment group.
        if re.search(r"(?:deployment\s*group|deploymentgroup)", text, flags=re.I):
            patch.extend([
                {"target": "config", "op": "set", "path": "source_deployment_group_name", "value": "hip-automation"},
                {"target": "config", "op": "set", "path": "target_deployment_group_name", "value": "hip-automation"},
                {"target": "input", "op": "set", "path": "objects.source_transport_profile.deployment_group", "value": "hip-automation"},
                {"target": "input", "op": "set", "path": "objects.target_transport_profile.deployment_group", "value": "hip-automation"},
            ])

        for label, paths in {
            "source account": [("config", "source_haft_account"), ("input", "objects.source_transport_profile.existing_account_name")],
            "target account": [("config", "target_haft_account"), ("input", "objects.target_transport_profile.existing_account_name")],
        }.items():
            match = re.search(rf"{label}\s*(?:is|=|to|use)?\s*[\"']?([A-Za-z0-9_.-]+)", text, flags=re.I)
            if match:
                for target, path in paths:
                    patch.append({"target": target, "op": "set", "path": path, "value": match.group(1)})

        domain = re.search(r"system\s+domain(?:id|\s*id)?\s*(?:is|=|to|use)?\s*([0-9a-f-]{20,})", text, flags=re.I)
        if domain:
            patch.append({"target": "config", "op": "set", "path": "system_domain_id", "value": domain.group(1)})

        primary_domain = re.search(r"primary\s*domain\s*(?:is|=|to|use)?\s*[\"']?([A-Za-z][A-Za-z ]+?)(?:\.|,|$)", text, flags=re.I)
        if primary_domain:
            patch.append({"target": "config", "op": "set", "path": "partner_primary_domain", "value": primary_domain.group(1).strip()})

        partner_id = re.search(
            r"(?:partner\s*(?:identifier|id)|duns(?:\s*number)?)\s*(?:is|=|to|use)?\s*[\"']?([A-Za-z0-9_.:-]+)",
            text, flags=re.I,
        )
        if partner_id:
            value = partner_id.group(1).strip()
            patch.extend([
                {"target": "input", "op": "set", "path": "partner_identifier_value", "value": value},
                {"target": "config", "op": "set", "path": "partner_identifier_value", "value": value},
            ])

        external_partner = re.search(
            r"(?:external|target)\s*partner(?:\s*(?:name|application))?\s*(?:is|=|to|use)?\s*[\"']?([^\n,.;]+)",
            text, flags=re.I,
        )
        if external_partner:
            value = external_partner.group(1).strip().strip('\"\'')
            if value:
                direction = str(input_data.get("direction") or "Outbound").lower()
                tp_side = "source" if direction == "inbound" else "target"
                patch.extend([
                    {"target": "input", "op": "set", "path": f"objects.{tp_side}_transport_profile.partner_name", "value": value},
                    {"target": "config", "op": "set", "path": "target_system_name" if tp_side == "target" else "source_system_name", "value": value},
                ])

        remove_matches = re.findall(r"remove\s+(?:the\s+)?(?:field\s+)?([A-Za-z0-9_.\[\]-]+)", text, flags=re.I)
        for field in remove_matches:
            patch.append({"target": "config", "op": "remove", "path": field.strip(".")})

        replace = re.search(r"replace\s+[\"']?([^\"']+?)[\"']?\s+with\s+[\"']?([^\"']+?)[\"']?(?:\.|,|$)", text, flags=re.I)
        if replace:
            patch.append({"target": "search", "op": "replace-value", "old": replace.group(1).strip(), "value": replace.group(2).strip()})

        # Remove duplicates while retaining order.
        unique: List[Dict[str, Any]] = []
        seen: set[str] = set()
        for item in patch:
            key = json.dumps(item, sort_keys=True, default=str)
            if key not in seen:
                seen.add(key)
                unique.append(item)
        return unique

    def propose_change(self, request_text: str, input_data: Dict[str, Any], config: Dict[str, Any], use_aia: bool = False, aia_complete_json: Optional[Callable[..., Dict[str, Any]]] = None) -> Dict[str, Any]:
        patch = self._deterministic_change_patch(request_text)
        aia_patch: List[Dict[str, Any]] = []
        if use_aia and aia_complete_json is not None:
            result = aia_complete_json(
                system=(
                    "Translate a HIP developer change request into safe JSON patch operations. "
                    "Allowed targets: input or config. Allowed ops: set or remove. "
                    "Never modify credentials, tokens, secrets, runtime IDs or execute the patch. "
                    "Return JSON with patch, assumptions, questions and affectedSteps."
                ),
                user=json.dumps({"request": request_text, "input": input_data, "config": config}, default=str)[:26000],
                temperature=0,
            )
            aia_patch = [item for item in (result.get("patch") or []) if item.get("target") in {"input", "config"} and item.get("op") in {"set", "remove"}]
            for item in aia_patch:
                path = str(item.get("path") or "").lower()
                if "deployment_group" in path or "deploymentgroup" in path:
                    item["op"] = "set"
                    item["value"] = "hip-automation"
            existing = {json.dumps(item, sort_keys=True, default=str) for item in patch}
            for item in aia_patch:
                key = json.dumps(item, sort_keys=True, default=str)
                if key not in existing:
                    patch.append(item)
                    existing.add(key)

        affected: set[str] = set()
        for item in patch:
            path = str(item.get("path") or "")
            if "document_type" in path:
                affected.update({"document_type_source", "document_type_target", "map", "rule", "source_tp", "target_tp", "flow_create"})
            elif "map" in path:
                affected.update({"map", "rule", "flow_create"})
            elif "rule" in path:
                affected.update({"rule", "flow_create"})
            elif "transport" in path or "account" in path or "deployment_group" in path:
                affected.update({"account_source", "account_target", "source_tp", "target_tp", "flow_create"})
            elif "flow" in path or "base_url" in path:
                affected.update({"flow_validate", "flow_create", "flow_deploy", "flow_history"})
        change_id = hashlib.sha256(f"{request_text}|{utc_now()}".encode()).hexdigest()[:12]
        proposal = {
            "changeId": change_id,
            "request": request_text,
            "patch": patch,
            "deterministicPatchCount": len(patch) - len(aia_patch),
            "aiaPatchCount": len(aia_patch),
            "impact": {"affectedSteps": sorted(affected), "requiresApproval": True},
            "questions": [] if patch else ["The request could not be mapped safely. Provide the exact target field and value."],
            "status": "PROPOSED",
        }
        (self.reports / "change_proposal_latest.json").write_text(json.dumps(proposal, indent=2, default=str), encoding="utf-8")
        candidate_id = self.agentq.add_patch_candidate("dev_change", patch, request_text, "deterministic+aia" if aia_patch else "deterministic")
        proposal["agentQCandidateId"] = candidate_id
        self.kg.record_dev_change(change_id, request_text, patch, "PROPOSED", proposal["impact"])
        return proposal

    @staticmethod
    def _replace_values(node: Any, old: Any, new: Any) -> int:
        count = 0
        if isinstance(node, dict):
            for key, value in list(node.items()):
                if value == old:
                    node[key] = new
                    count += 1
                else:
                    count += AdaptiveHipEngine._replace_values(value, old, new)
        elif isinstance(node, list):
            for index, value in enumerate(list(node)):
                if value == old:
                    node[index] = new
                    count += 1
                else:
                    count += AdaptiveHipEngine._replace_values(value, old, new)
        return count

    def apply_change(self, proposal: Dict[str, Any], input_data: Dict[str, Any], config: Dict[str, Any], approve: bool) -> Dict[str, Any]:
        if not approve:
            return {"applied": False, "reason": "Approval is required.", "proposal": proposal}
        updated_input = copy.deepcopy(input_data)
        updated_config = copy.deepcopy(config)
        applied: List[Dict[str, Any]] = []
        for item in proposal.get("patch") or []:
            target = item.get("target")
            op = item.get("op")
            path = item.get("path")
            if target == "search" and op == "replace-value":
                count = self._replace_values(updated_input, item.get("old"), item.get("value"))
                count += self._replace_values(updated_config, item.get("old"), item.get("value"))
                applied.append({**item, "replacementCount": count})
                continue
            destination = updated_input if target == "input" else updated_config if target == "config" else None
            if destination is None or not path:
                continue
            if op == "set":
                deep_set(destination, path, item.get("value"))
                applied.append(item)
            elif op == "remove" and deep_delete(destination, path):
                applied.append(item)
        # Final policy guard: automation deployment group cannot be changed by
        # free-text edits, search/replace, imported legacy input or LLM patches.
        deep_set(updated_input, "objects.source_transport_profile.deployment_group", "hip-automation")
        deep_set(updated_input, "objects.target_transport_profile.deployment_group", "hip-automation")
        updated_config["source_deployment_group_name"] = "hip-automation"
        updated_config["target_deployment_group_name"] = "hip-automation"

        result = {
            "applied": True,
            "input": updated_input,
            "config": updated_config,
            "appliedOperations": applied,
            "changeId": proposal.get("changeId"),
            "affectedSteps": (proposal.get("impact") or {}).get("affectedSteps") or [],
        }
        self.kg.record_dev_change(str(proposal.get("changeId")), str(proposal.get("request")), proposal.get("patch") or [], "APPLIED", proposal.get("impact") or {})
        (self.reports / "change_applied_latest.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
        return result

    def derive_config_updates(self, canonical: Dict[str, Any], existing_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        config = copy.deepcopy(existing_config or {})
        source_tp = deep_get(canonical, "objects.source_transport_profile", {}) or {}
        target_tp = deep_get(canonical, "objects.target_transport_profile", {}) or {}
        biz_source = deep_get(canonical, "objects.biz_flow.configure_source", {}) or {}
        biz_target = deep_get(canonical, "objects.biz_flow.configure_targets", {}) or {}
        config.update({
            "source_system_name": source_tp.get("partner_name"),
            "target_system_name": target_tp.get("partner_name"),
            "source_haft_account": source_tp.get("existing_account_name"),
            "target_haft_account": target_tp.get("existing_account_name"),
            "source_deployment_group_name": "hip-automation",
            "target_deployment_group_name": "hip-automation",
            "source_transport_profile_name": biz_source.get("source_transport_profile") or source_tp.get("profile_name"),
            "target_transport_profile_name": biz_target.get("target_transport_profile") or target_tp.get("profile_name"),
            "flowVersion": str(deep_get(canonical, "objects.biz_flow.flow_details.current_flow_version", "1.0")),
        })
        # Runtime IDs belong to a previous customer/run and must be rediscovered.
        for key in ("source_document_type_id", "target_document_type_id", "map_id", "rule_id", "existing_flow_id", "workOrderId", "taskId"):
            config[key] = None
        return config

    def record_mapping_graph(self, mapper_manifest: Dict[str, Any]) -> Dict[str, Any]:
        context = mapper_manifest.get("businessContext") or {}
        self.kg.record_input_mapping(str(context.get("customer") or "UNKNOWN"), mapper_manifest.get("lineage") or {}, context)
        self.kg.record_dependency_manifest(mapper_manifest.get("sequence") or [])
        return self.kg.stats()

    def record_api_result(self, sequence: int, step_key: str, result: Any) -> None:
        status = getattr(result, "classification", "") or "UNKNOWN"
        success = bool(getattr(result, "business_success", False)) or status in {"PASS", "EXISTING"}
        extracted = getattr(result, "extracted", {}) or {}
        response = getattr(result, "response_preview", "") or getattr(result, "error", "")
        self.kg.record_api_result(sequence, step_key, status, response, extracted)
        reward = 1.0 if success else -1.0
        critique = "Resolved successfully." if success else str(getattr(result, "issue", "") or response)[:1200]
        self.agentq.record_trajectory(
            f"api:{step_key}",
            {"sequence": sequence, "stepKey": step_key},
            {"request": getattr(result, "request_preview", "")},
            {"status": status, "response": response, "extracted": extracted},
            reward,
            critique,
        )

    def status(self) -> Dict[str, Any]:
        return {"knowledgeGraph": self.kg.stats(), "agentQMemory": self.agentq.stats()}
