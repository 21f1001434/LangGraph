from __future__ import annotations

from unittest.mock import patch

import run_agent
from report_insights import analyze_api_response


def _result(*, group="Document Type", api="Create source document type", status=500,
            classification="BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", success=False,
            response="", extracted=None, issue=""):
    return run_agent.Result(
        1, group, api, "v106-test", "POST", "https://mock/api", "HIP", "",
        status, classification, success, 1, "", "{}", response,
        extracted or {}, "API_BACKEND_OR_ERROR_HANDLING", "", "API_BACKEND_OR_ERROR_HANDLING",
        issue, "",
    )


def test_v106_build_id_keeps_strict_live_metadata():
    build_id = run_agent.BUILD_ID.lower()
    assert any(tag in build_id.lower() for tag in ("v117", "v118", "v119", "v120", "v121", "v122"))
    assert "strict" in build_id
    assert "live" in build_id


def test_v106_pcf_route_missing_is_api_upstream_route_unavailable():
    runner = run_agent.Runner(llm_enabled=False)
    text = "Requested route (hip-partners-authz-service1.pcf.dell.com) does not exist."
    classification, ok = runner.classify_http(404, text)
    assert classification == "API_UPSTREAM_ROUTE_UNAVAILABLE"
    assert ok is False

    owner, issue, action = runner.deterministic_owner({
        "classification": classification,
        "status_code": 404,
        "response_preview": text,
        "error": "",
        "group": "Account",
        "api": "Create source account",
        "business_success": False,
    })
    assert owner == "API_UPSTREAM_ROUTE_UNAVAILABLE"
    assert "upstream" in issue.lower()
    assert "HIP_ACCOUNT_API_URL" in action


def test_v106_environment_can_replace_account_partner_system_urls_without_payload_change():
    replacements = {
        "HIP_ACCOUNT_API_URL": "https://replacement.example/account",
        "HIP_PARTNER_API_URL": "https://replacement.example/partner",
        "HIP_SYSTEM_API_URL": "https://replacement.example/system",
    }
    with patch.dict("os.environ", replacements, clear=False):
        runner = run_agent.Runner(llm_enabled=False)
    assert runner.urls["account"] == replacements["HIP_ACCOUNT_API_URL"]
    assert runner.urls["partner"] == replacements["HIP_PARTNER_API_URL"]
    assert runner.urls["system"] == replacements["HIP_SYSTEM_API_URL"]
    assert runner.endpoint_overrides == {
        "account": replacements["HIP_ACCOUNT_API_URL"],
        "partner": replacements["HIP_PARTNER_API_URL"],
        "system": replacements["HIP_SYSTEM_API_URL"],
    }


def test_v106_document_type_already_exists_passes_without_document_type_id():
    runner = run_agent.Runner(llm_enabled=False)
    response = (
        '{"error":true,"message":"Create failed","detail":'
        '"An active DocumentType with this name already exists in environment DEV.",'
        '"status":500,"data":null}'
    )
    r = _result(response=response)
    owner, issue, action = runner.deterministic_owner({
        "classification": r.classification,
        "status_code": r.status_code,
        "response_preview": r.response_preview,
        "error": r.error,
        "group": r.group,
        "api": r.api,
        "business_success": r.business_success,
    })
    r.deterministic_owner = owner
    r.final_owner = owner
    r.issue = issue
    r.action_required = action

    assert owner == "EXPECTED_EXISTING_OBJECT"
    assert runner.source_doc_id() == 0
    # Critical V106 behavior: doctypeId is no longer a downstream requirement.
    assert runner.enforce_live_id_integrity("doctype_source", r, require_dependency_ids=True) is True
    assert r.classification != "LIVE_ID_UNRESOLVED"
    assert runner.source_doc_id() == 0
    verdict = analyze_api_response(r)
    assert verdict["verdict"] == "PASS"
    assert verdict["outcome"] == "EXISTING"


def test_v106_rule_fk_is_backend_contract_mismatch_and_never_runs_fake_id_repair():
    runner = run_agent.Runner(llm_enabled=False)
    runner.runtime_state["source_document_type_id"] = 10483
    r = _result(
        group="Rule",
        api="Create mapping rule",
        response='{"error":"ORA-02291: integrity constraint (SHARED.FK_RULE_DOCUMENTTYPE) violated - parent key not found"}',
        issue="RULE_DOCUMENTTYPE parent key not found",
    )

    assert runner.enforce_live_id_integrity("rule", r, require_dependency_ids=True) is False
    assert runner.source_doc_id() == 10483
    assert r.classification == "API_BACKEND_CONTRACT_MISMATCH"
    assert r.final_owner == "API_BACKEND_CONTRACT_MISMATCH"
    assert r.extracted["backendContractMismatch"] == {
        "constraint": "RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE",
        "requestContainsDocumentTypeId": False,
        "documentTypeResolution": "name+version",
        "runtimeIdMutationPerformed": False,
    }
    verdict = analyze_api_response(r)
    assert verdict["verdict"] == "FAIL"
    assert verdict["outcome"] == "API_BACKEND_CONTRACT_MISMATCH"


def test_v106_approved_rule_and_tp_payloads_use_document_type_name_version_not_id():
    runner = run_agent.Runner(llm_enabled=False)
    rule = runner.rule_payload()
    assert "documentTypeId" not in rule
    assert rule.get("documentTypeName")
    assert rule.get("documentTypeVersion") is not None

    # Both source and target TP orchestration contracts are name/version based.
    src = runner.tp_orch_payload(runner.source_tp(), "source")
    tgt = runner.tp_orch_payload(runner.target_tp(), "target")
    for payload in (src, tgt):
        serialized = str(payload)
        assert "documentTypeId" not in serialized
        details = payload["transportProfileDetails"][0]["documentTypeDetails"][0]
        assert details.get("documentTypeName")
        assert details.get("documentTypeVersion") is not None
