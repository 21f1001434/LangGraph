from __future__ import annotations

import asyncio
import json
import importlib.util
import importlib.metadata
import os
import platform
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from .execution_manager import ExecutionManager
from .parallel_manager import ParallelManager
from .legacy_adapter import (
    LEGACY_ROOT, api_catalog, migration_api_catalog, all_api_catalog, apply_configuration_answers, build_configuration, refresh_input_extraction_blueprint,
    interface_catalog, preview_api_requests, preview_migration_requests, preview_all_api_requests, preflight_flow_requests, transaction_metadata, connection_readiness, api_test_request, production_preflight, apply_inline_validation_fixes,
)
from .models import (AnswerPayload, ConfigurationCreate, ConfigurationPatch, ExecutionStart, ExecutionResume, NodeApproval, TemplateCreate, FlowDefinition, FlowNodeAction,
    ParallelQueueCreate, ParallelSourcesQueueCreate, ParallelQueueDeleteMany, UhalDemoCreate, ParallelBatchStart, PipelineCreate, PipelineRun, LearnAskPayload, CloneRequest, TemplateLifecycleRequest, ApiTestRequest, ValidationFixPayload, PayloadOverrideSave, ExecutionFlowSave)
from .storage import JsonStore
from .runtime_paths import resolve_runtime_root, migrate_legacy_runtime
from .resilient_io import atomic_write_json
from .phase2_service import (validate_configuration, configuration_evidence, mapping_learning_state, teach_mapping_reference,
    learn_records, ingest_learn_file, ask_learn, list_reports, read_report)
from .templates import (builtin_templates, generated_template_from_configuration, approved_uhal_translation_template, is_uhal_customer, is_uhal_template, is_uhal_passthrough_template)
from .flow_engine import compile_flow, apply_safe_fixes
from .phase5_service import build_configuration_bundle, import_configuration_bundle, inspect_configuration_bundle, build_execution_evidence_bundle
from .excel_api_mapper import analyze_workbook
from payload_overrides import PayloadOverrideStore, save_override, clear_override
from api_contract_policy import POLICY_NAME, assert_no_request_override, immutable_flow_graph
from parallel_configurations import _SNAPSHOT_DIRS, _SNAPSHOT_FILES
from customer_intake_report import write_customer_intake_report, REPORT_HTML, REPORT_JSON
from migration_api_contract import MIGRATION_STEP_DEFINITIONS
from execution_flow import ExecutionFlowConfig, save_execution_flow, reset_execution_flow

LEGACY_RUNTIME_ROOT = LEGACY_ROOT / "webapp" / "runtime"
RUNTIME_ROOT = resolve_runtime_root(LEGACY_ROOT)
# Best-effort upgrade path. The packaged source tree remains read-only; mutable
# state is copied to the per-user runtime only when it can be read safely.
RUNTIME_MIGRATION = migrate_legacy_runtime(LEGACY_RUNTIME_ROOT, RUNTIME_ROOT)
STORE = JsonStore(RUNTIME_ROOT)
EXECUTIONS = ExecutionManager(STORE)
PARALLEL = ParallelManager(STORE)
PIPELINE_ROOT = RUNTIME_ROOT / "pipelines"
PIPELINE_ROOT.mkdir(parents=True, exist_ok=True)

_UHAL_PARALLEL_SOURCE_ID = "reference:uhal"
_UHAL_APPROVAL_STATUS = "DEV_APPROVED"

app = FastAPI(title="HIP API Agent Studio", version="0.8.5")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)

@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> Response:
    # Browsers request this automatically. Return an empty success response so the
    # production terminal does not show a misleading 404 during an otherwise healthy startup.
    return Response(status_code=204)





def _approved_uhal_template() -> Dict[str, Any]:
    input_path = LEGACY_ROOT / "input.json"
    if not input_path.exists():
        raise ValueError("The packaged approved U-HAUL input.json is missing.")
    data = json.loads(input_path.read_text(encoding="utf-8"))
    if not is_uhal_customer(data.get("customer")) or str(data.get("direction") or "").lower() != "outbound" or str(data.get("tx_code") or "") != "856":
        raise ValueError("The packaged U-HAUL reference is not the approved Outbound 856 configuration.")
    if not bool(data.get("requires_data_map")):
        raise ValueError("The packaged U-HAUL reference must be Translation (requires_data_map=true).")
    return approved_uhal_translation_template(data)


def _approved_uhal_validation() -> Dict[str, Any]:
    """Return the immutable developer-approval contract for the shipped U-HAUL reference.

    This is intentionally not a mutable customer validation state.  Runtime/API
    preflight still runs immediately before LIVE work; that can report an
    environment or connectivity problem without changing the approval of the
    reference configuration itself.
    """
    items = []
    for row in api_catalog():
        items.append({
            "stepKey": row.get("key"),
            "label": row.get("label"),
            "group": row.get("group"),
            "valid": True,
            "approval": _UHAL_APPROVAL_STATUS,
            "approvalSource": "developer-approved U-HAUL Outbound 856 Translation test reference",
        })
    total = len(items) or 18
    return {
        "ok": True,
        "approval": {
            "status": _UHAL_APPROVAL_STATUS,
            "immutableReference": True,
            "testReady": True,
            "runtimeCheckedSeparately": True,
        },
        "mapper": {"ok": True, "errors": [], "issues": []},
        "requests": {
            "ok": True,
            "validCount": total,
            "total": total,
            "blockedCount": 0,
            "items": items,
            "blockedItems": [],
        },
        "executionPlan": {"ok": True},
        "executionFlow": {"ok": True},
    }


def _is_approved_uhal_reference(record: Dict[str, Any] | None) -> bool:
    row = record or {}
    return bool(
        str(row.get("managed_reference_source") or "") == _UHAL_PARALLEL_SOURCE_ID
        or (
            bool(row.get("approved_reference"))
            and is_uhal_customer(row.get("customer") or row.get("name"))
        )
    )


def _approved_uhal_patch(record: Dict[str, Any] | None = None) -> Dict[str, Any]:
    row = record or {}
    return {
        "managed_reference_source": _UHAL_PARALLEL_SOURCE_ID,
        "flow_source_id": _UHAL_PARALLEL_SOURCE_ID,
        "approved_reference": True,
        "immutable_reference": True,
        "reference_approval_status": _UHAL_APPROVAL_STATUS,
        "test_ready": True,
        "status": _UHAL_APPROVAL_STATUS,
        "validation": _approved_uhal_validation(),
        "questions": [],
        "resolved_flow_type": "Translation",
        "build_summary": {
            **(row.get("build_summary") or {}),
            "managed_reference": True,
            "source_id": _UHAL_PARALLEL_SOURCE_ID,
            "approved_reference": True,
            "immutable_reference": True,
            "approval_status": _UHAL_APPROVAL_STATUS,
            "runtime_checked_separately": True,
        },
    }


def _require_editable_configuration(record: Dict[str, Any], action: str) -> None:
    if not _is_approved_uhal_reference(record):
        return
    raise HTTPException(
        409,
        detail={
            "message": f"The developer-approved U-HAUL reference is immutable and cannot be changed while {action}.",
            "approvalStatus": _UHAL_APPROVAL_STATUS,
            "nextAction": "Use Create from U-HAUL / Clone to make an editable customer configuration, then change values on that clone.",
        },
    )


def _builtin_template_catalog() -> List[Dict[str, Any]]:
    # Put the validated customer reference first so Flow Game/Template UX lands
    # on the proven example before generic starter templates.
    return [_approved_uhal_template()] + builtin_templates()


def _visible_custom_templates() -> List[Dict[str, Any]]:
    # Upgrade-safe cleanup at read time: old U-HAUL Passthrough/generated clones
    # are hidden. U-HAUL is intentionally represented by one approved Translation
    # template only. Other customers can still use Passthrough where appropriate.
    return [row for row in STORE.list_templates() if not is_uhal_template(row)]


def _template_catalog() -> List[Dict[str, Any]]:
    return _builtin_template_catalog() + _visible_custom_templates()


def _guard_template_payload(payload: Dict[str, Any]) -> None:
    if is_uhal_passthrough_template(payload):
        raise HTTPException(400, "U-HAUL Passthrough is not an approved template. Use the validated U-HAUL Outbound 856 Translation template.")


def _resolved_flow_type(record: Dict[str, Any]) -> str:
    """Return the canonical flow type produced by the Input Builder.

    The UI may keep ``flow_type=Auto`` as the user's preference. Once input.json
    exists, ``requires_data_map`` is the canonical deterministic result and must
    drive the API Flow Game/template selection.
    """
    try:
        input_path = Path(str(record.get("workspace") or "")) / "input.json"
        if input_path.exists():
            data = json.loads(input_path.read_text(encoding="utf-8"))
            if is_uhal_customer(data.get("customer") or record.get("customer")):
                return "Translation"
            if "requires_data_map" in data:
                return "Translation" if bool(data.get("requires_data_map")) else "Passthrough"
    except Exception:
        pass
    explicit = str(record.get("flow_type") or "").strip()
    return explicit if explicit in {"Translation", "Passthrough"} else ""


def _sync_generated_template(configuration_id: str, canonical: Dict[str, Any]) -> Dict[str, Any]:
    """Keep one customer template synchronized with the final canonical values.

    Repeated builds/answers update the same template id and create template
    history only when the reusable business values/graph actually changed.
    U-HAUL is special: only the packaged validated Translation reference is
    exposed, so builds never create a second U-HAUL template.
    """
    if is_uhal_customer(canonical.get("customer")):
        return _approved_uhal_template()
    payload = generated_template_from_configuration(configuration_id, canonical)
    tid = f"generated-{configuration_id}"
    try:
        current = STORE.get_template(tid)
    except KeyError:
        current = {}
    comparable = ("name", "description", "direction", "transaction_code", "flow_type", "nodes", "edges", "variables", "default_values", "source_configuration_id", "tags")
    if current and all(current.get(key) == payload.get(key) for key in comparable):
        return current
    return STORE.save_template(payload, template_id=tid)


def _decorate_configuration(record: Dict[str, Any], *, include_input: bool = False) -> Dict[str, Any]:
    value = dict(record)
    resolved = _resolved_flow_type(value)
    if resolved:
        value["resolved_flow_type"] = resolved
    input_path = Path(str(value.get("workspace") or "")) / "input.json"
    value["input_built"] = input_path.exists()
    if include_input and input_path.exists():
        try:
            value["input_json"] = json.loads(input_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return value

def _actor(request: Request) -> str:
    return str(request.headers.get("X-HIP-Actor") or "User").strip()[:200] or "User"


def _require_human_payload_edit_action(request: Request) -> str:
    """Allow payload value changes only from an explicit human UI action.

    The governed AI skills have no editor tool/entrypoint. The HTTP editor also
    requires a dedicated user-action header so background agents/system calls
    cannot accidentally acquire payload-edit authority.
    """
    action = str(request.headers.get("X-HIP-User-Action") or "").strip().lower()
    actor = _actor(request)
    if action != "payload-value-edit-v1":
        raise HTTPException(403, detail={
            "message": "Payload value editing is HUMAN USER ONLY. The AI/agent may inspect and validate but cannot edit payload values.",
            "requiredHeader": "X-HIP-User-Action: payload-value-edit-v1",
            "agentEditAllowed": False,
            "userEditAllowed": True,
        })
    lowered = actor.lower()
    if any(token in lowered for token in ("agent", "autogen", "dell aia", "llm", "assistant")):
        raise HTTPException(403, detail={
            "message": "AI/agent identities are not authorized to edit payload values.",
            "agentEditAllowed": False,
            "userEditAllowed": True,
        })
    return actor


def _require_human_execution_flow_action(request: Request) -> str:
    """Execution ordering and Migration ON/OFF are explicit human run-plan choices."""
    action = str(request.headers.get("X-HIP-User-Action") or "").strip().lower()
    actor = _actor(request)
    if action != "execution-flow-edit-v1":
        raise HTTPException(403, detail={
            "message": "Execution Flow editing is HUMAN USER ONLY. The AI/agent may validate a proposed order but cannot save, reorder, enable, or disable LIVE steps.",
            "requiredHeader": "X-HIP-User-Action: execution-flow-edit-v1",
            "agentEditAllowed": False,
            "userEditAllowed": True,
        })
    lowered = actor.lower()
    if any(token in lowered for token in ("agent", "autogen", "dell aia", "llm", "assistant")):
        raise HTTPException(403, detail={
            "message": "AI/agent identities are not authorized to change the LIVE execution flow.",
            "agentEditAllowed": False,
            "userEditAllowed": True,
        })
    return actor


def _blocking_configuration_questions(record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return unresolved human decisions that must be completed before API work.

    This is intentionally server-side. UI button state is only convenience; direct
    API calls, bookmarked pages and stale browser state must obey the same gate.
    """
    return [
        q for q in (record.get("questions") or [])
        if isinstance(q, dict) and not bool(q.get("informational"))
    ]


def _require_configuration_decisions_resolved(record: Dict[str, Any], action: str) -> None:
    blockers = _blocking_configuration_questions(record)
    if not blockers:
        return
    conflicts = []
    for q in blockers:
        if str(q.get("type") or "").lower() != "conflict":
            continue
        c = q.get("conflict") if isinstance(q.get("conflict"), dict) else {}
        conflicts.append({
            "id": q.get("id"), "path": q.get("path"), "label": q.get("label"),
            "fileValues": c.get("fileValues") or [], "fileSources": c.get("fileSources") or [],
            "selectedValue": c.get("selectedValue"), "selectedField": c.get("selectedField"),
        })
    raise HTTPException(
        400,
        detail={
            "message": f"Resolve {len(blockers)} required Build Configuration decision(s) before {action}.",
            "blockerCount": len(blockers),
            "conflictCount": len(conflicts),
            "conflicts": conflicts,
            "nextAction": "Return to Build Configuration, compare Customer File Evidence with Your Selected Value, choose either one or enter another approved value, then apply decisions and re-check.",
        },
    )


def _audit_entity(path: str) -> tuple[str, str]:
    parts = [part for part in path.split("/") if part]
    if len(parts) >= 3 and parts[1] == "configurations":
        return "configuration", parts[2]
    if len(parts) >= 3 and parts[1] == "templates":
        return "template", parts[2]
    if len(parts) >= 3 and parts[1] == "executions":
        return "execution", parts[2]
    if len(parts) >= 2 and parts[1] == "parallel":
        return "parallel", parts[2] if len(parts) > 2 else ""
    if len(parts) >= 2 and parts[1] == "configuration-bundles":
        return "configuration_bundle", "import"
    return "api", ""


@app.middleware("http")
async def audit_mutations(request: Request, call_next):
    response = await call_next(request)
    if request.method.upper() in {"POST", "PUT", "PATCH", "DELETE"} and request.url.path.startswith("/api/") and response.status_code < 500:
        entity_type, entity_id = _audit_entity(request.url.path)
        try:
            STORE.append_audit(
                f"{request.method.upper()} {request.url.path}", entity_type, entity_id, actor=_actor(request),
                summary=f"HTTP {response.status_code}", metadata={"status": response.status_code},
            )
        except Exception:
            pass
    return response


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {"ok": True, "service": "HIP API Agent Studio", "legacyRoot": str(LEGACY_ROOT)}


@app.get("/api/bootstrap")
def bootstrap() -> Dict[str, Any]:
    return {
        "api_catalog": api_catalog(),
        "migration_api_catalog": migration_api_catalog(),
        "all_api_catalog": all_api_catalog(),
        "interfaces": interface_catalog(),
        "transactions": transaction_metadata(),
        "templates": _template_catalog(),
        "deployment_group": "hip-automation",
        "mapping_learning": mapping_learning_state(),
        "phase": 6,
        "capabilities": {
            "configurationLibrary": True, "portableBundles": True, "tamperEvidentAudit": True,
            "templateLifecycle": True, "executionEvidenceBundles": True, "streamlitFallback": False,
            "studioWebPrimary": True, "apiTestingArea": True, "connectionCenter": True, "singlePortProduction": True,
            "autoGenParallelExecution": True, "maxStableAutoGenAgents": 4,
            "descriptionTriggeredSkills": True, "expertSourcedSkills": True,
            "boundedAgentContext": True, "deterministicSkillEntrypoints": True, "preRunSkillVetting": True,
            "intelligentExcelApiMapper": True, "humanGatedMappedPayloadStaging": True,
        },
    }




def _safe_distribution_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except Exception:
        return ""

@app.get("/api/system/status")
def system_status() -> Dict[str, Any]:
    """HIP API Agent Studio runtime status. No secrets are returned."""
    frontend_dist = LEGACY_ROOT / "webapp" / "frontend" / "dist"
    try:
        from .skill_governance import vet_all_skills
        _skill_vetting = vet_all_skills(LEGACY_ROOT)
        _skills_vetted = _skill_vetting.get("status") == "PASS"
        _skill_count = int(_skill_vetting.get("count") or 0)
        _skill_error = ""
    except Exception as exc:
        _skills_vetted = False
        _skill_count = 0
        _skill_error = f"{type(exc).__name__}: {exc}"
    credential_env = {
        "hip": {"clientId": bool(os.getenv("HIP_CLIENT_ID")), "clientSecret": bool(os.getenv("HIP_CLIENT_SECRET")), "tokenUrl": bool(os.getenv("HIP_TOKEN_URL"))},
        "account": {"clientId": bool(os.getenv("ACCOUNT_CLIENT_ID")), "clientSecret": bool(os.getenv("ACCOUNT_CLIENT_SECRET")), "tokenUrl": bool(os.getenv("ACCOUNT_TOKEN_URL"))},
        "partner": {"clientId": bool(os.getenv("PARTNER_CLIENT_ID")), "clientSecret": bool(os.getenv("PARTNER_CLIENT_SECRET")), "tokenUrl": bool(os.getenv("PARTNER_TOKEN_URL"))},
        "system": {"clientId": bool(os.getenv("SYSTEM_CLIENT_ID")), "clientSecret": bool(os.getenv("SYSTEM_CLIENT_SECRET")), "tokenUrl": bool(os.getenv("SYSTEM_TOKEN_URL"))},
        "dellAia": {"clientId": bool(os.getenv("DELL_AIA_CLIENT_ID") or os.getenv("AIA_CLIENT_ID")), "clientSecret": bool(os.getenv("DELL_AIA_CLIENT_SECRET") or os.getenv("AIA_CLIENT_SECRET")), "tokenUrl": bool(os.getenv("AIA_TOKEN_URL"))},
    }
    return {
        "ok": True,
        "phase": 6,
        "ui": "HIP API Agent Studio Web UI",
        "backend": "FastAPI/Python",
        "agentFramework": "Microsoft AutoGen AgentChat",
        "autoGenVersionRequired": "0.7.5",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "bunAvailable": bool(shutil.which("bun")),
        "bunPath": shutil.which("bun") or "",
        "frontendBuilt": frontend_dist.is_dir() and (frontend_dist / "index.html").exists(),
        "singlePortReady": frontend_dist.is_dir() and (frontend_dist / "index.html").exists(),
        "deploymentGroup": "hip-automation",
        "apiBlocks": len(api_catalog()),
        "migrationApiBlocks": len(migration_api_catalog()),
        "totalReusableApiBlocks": len(all_api_catalog()),
        "skillPolicy": {
            "descriptionTriggered": True,
            "preRunVetting": True,
            "contextBudgeted": True,
            "deterministicEntrypointsOnly": True,
            "arbitrarySkillCodeExecution": False,
            "vetted": _skills_vetted,
            "skillCount": _skill_count,
            "vettingError": _skill_error,
        },
        "streamlitRequired": False,
        "legacyStreamlitInstalled": bool(importlib.util.find_spec("streamlit")),
        "tuning": {
            "parallelWorkers": min(4, max(1, int(os.getenv("HIP_PARALLEL_CONFIG_WORKERS", "4") or "4"))),
            "autoGenInstalled": bool(importlib.util.find_spec("autogen_agentchat")),
            "autoGenApi": "AgentChat",
            "autoGenVersion": (_safe_distribution_version("autogen-agentchat") if importlib.util.find_spec("autogen_agentchat") else ""),
            "autoGenAgentLimit": 4,
            "knownUnstableAgentCount": 5,
            "knownUnstableReason": "HTTP 429",
            "httpPoolSize": int(os.getenv("HIP_HTTP_POOL_SIZE", "24") or "24"),
            "reuseValidatedRequests": str(os.getenv("HIP_REUSE_VALIDATED_REQUESTS", "true")).lower() not in {"0", "false", "no"},
            "approvalTimeoutSeconds": int(os.getenv("HIP_NODE_APPROVAL_TIMEOUT_SECONDS", "3600") or "3600"),
        },
        "credentialEnvironment": credential_env,
        "runtimeRoot": str(RUNTIME_ROOT),
        "runtimePolicy": "Mutable state is stored in a deeply write-probed per-user runtime-v82 outside the packaged/OneDrive source tree, with temp fallback. Set HIP_STUDIO_RUNTIME_ROOT to override.",
        "runtimeMigration": RUNTIME_MIGRATION,
        "note": "Credential booleans reflect environment variables only. Existing Test.py fallback credentials are checked by the connection diagnostic without exposing values.",
    }


@app.get("/api/configurations/{cid}/readiness")
def configuration_readiness(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        readiness = connection_readiness(Path(record["workspace"]))
        if _is_approved_uhal_reference(record):
            readiness["referenceApproval"] = {
                "status": _UHAL_APPROVAL_STATUS,
                "approved": True,
                "testReady": True,
                "immutable": True,
                "note": "Runtime connectivity is separate from developer approval of the U-HAUL test reference.",
            }
        return readiness
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except Exception as exc:
        raise HTTPException(400, f"Connection/readiness check failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/api-tests/{step_key}/preflight")
def api_test_preflight(cid: str, step_key: str, payload: ApiTestRequest) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    if not (Path(record["workspace"]) / "input.json").exists():
        raise HTTPException(400, "Build input.json before testing an API block.")
    _require_configuration_decisions_resolved(record, "opening API Testing preflight")
    try:
        assert_no_request_override(payload.request_override, context="API Testing preflight")
        return api_test_request(Path(record["workspace"]), step_key, request_override={}, override_mode="merge", execute=False)
    except Exception as exc:
        raise HTTPException(400, f"API test preflight failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/api-tests/{step_key}/execute")
def api_test_execute(cid: str, step_key: str, payload: ApiTestRequest, request: Request) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "LIVE API Testing Area execution requires explicit confirmation.")
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    if not (Path(record["workspace"]) / "input.json").exists():
        raise HTTPException(400, "Build input.json before testing an API block.")
    _require_configuration_decisions_resolved(record, "executing an API Testing Area block")
    try:
        assert_no_request_override(payload.request_override, context="API Testing LIVE execution")
        result = api_test_request(Path(record["workspace"]), step_key, request_override={}, override_mode="merge", execute=True)
        STORE.append_audit("LIVE_API_TEST", "configuration", cid, actor=_actor(request), summary=f"API Testing Area executed {step_key}", metadata={"stepKey": step_key, "ok": bool(result.get("ok")), "executed": bool(result.get("executed"))})
        return result
    except Exception as exc:
        raise HTTPException(400, f"LIVE API test failed: {type(exc).__name__}: {exc}")



def _value_leaf_diffs(before: Any, after: Any, prefix: str = "") -> Dict[str, Any]:
    """Return changed canonical leaf values as dotted paths.

    Request structure is validated separately. This function never represents
    add/remove operations; it only records values that differ from the generated
    customer request. Fixed-shape arrays use numeric path segments.
    """
    changes: Dict[str, Any] = {}
    if isinstance(before, dict) and isinstance(after, dict):
        for key in before:
            if key not in after:
                continue
            path = f"{prefix}.{key}" if prefix else str(key)
            changes.update(_value_leaf_diffs(before[key], after[key], path))
        return changes
    if isinstance(before, list) and isinstance(after, list):
        for index in range(min(len(before), len(after))):
            path = f"{prefix}.{index}" if prefix else str(index)
            changes.update(_value_leaf_diffs(before[index], after[index], path))
        return changes
    if before != after:
        changes[prefix] = after
    return changes


def _exact_same_structure(before: Any, after: Any) -> bool:
    """True when object keys/list cardinality are exactly unchanged."""
    if isinstance(before, dict):
        if not isinstance(after, dict) or set(before) != set(after):
            return False
        return all(_exact_same_structure(before[k], after[k]) for k in before)
    if isinstance(before, list):
        if not isinstance(after, list) or len(before) != len(after):
            return False
        return all(_exact_same_structure(a, b) for a, b in zip(before, after))
    return not isinstance(after, (dict, list))


def _get_dotted(value: Any, path: str) -> Any:
    node = value
    for part in [p for p in str(path or "").split(".") if p != ""]:
        if isinstance(node, dict):
            node = node.get(part)
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return None
    return node


def _sync_linked_identity_value(workspace: Path, step_key: str, edited: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Synchronize identity edits that must remain consistent across APIs.

    A Transport Profile name is referenced by validate/create/audit calls, so an
    edit in the Source/Target TP payload is promoted to canonical input.json.
    This is deterministic value synchronization, not API-shape mutation.
    """
    path = Path(workspace) / "input.json"
    if not path.exists():
        return []
    try:
        canonical = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if not isinstance(canonical, dict):
        return []

    syncs: List[Dict[str, Any]] = []
    mapping = {
        "source_tp": ("transportProfileDetails.0.transportProfileName", "source_transport_profile"),
        "target_tp": ("transportProfileDetails.0.transportProfileName", "target_transport_profile"),
    }
    item = mapping.get(str(step_key or ""))
    if item:
        request_path, object_key = item
        name = str(_get_dotted(edited, request_path) or "").strip()
        if name:
            objects = canonical.setdefault("objects", {})
            tp = objects.get(object_key)
            if isinstance(tp, list):
                target = next((x for x in tp if isinstance(x, dict)), None)
                if target is None:
                    target = {}
                    tp.append(target)
            elif isinstance(tp, dict):
                target = tp
            else:
                target = {}
                objects[object_key] = target
            before = str(target.get("profile_name") or "")
            if before != name:
                target["profile_name"] = name
                syncs.append({"canonicalPath": f"objects.{object_key}.profile_name", "before": before, "after": name})

    if syncs:
        atomic_write_json(path, canonical)
    return syncs


def _sync_migration_environment_values(workspace: Path, source_step: str, edited: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Propagate one human-entered migration environment to all seven existing contracts.

    sourceEnvironment/targetEnvironment are existing attributes on every Dev-published
    Migration payload. This function changes only those values and preserves every
    payload key/nesting rule. It never creates a new API attribute.
    """
    if not str(source_step or "").startswith("migrate_"):
        return []
    fields = [f for f in ("sourceEnvironment", "targetEnvironment") if f in edited]
    if not fields:
        return []
    preview = preview_all_api_requests(workspace)
    rows = {str(x.get("stepKey") or ""): x for x in (preview.get("items") or []) if isinstance(x, dict)}
    syncs: List[Dict[str, Any]] = []
    for step in MIGRATION_STEP_DEFINITIONS:
        row = rows.get(step)
        if not row or row.get("applicable") is False:
            continue
        request_kind = str(row.get("requestKind") or "payload")
        if request_kind != "payload":
            continue
        generated = row.get("generatedPayload") if isinstance(row.get("generatedPayload"), dict) else {}
        effective = row.get("payload") if isinstance(row.get("payload"), dict) else dict(generated)
        updated = json.loads(json.dumps(effective))
        changed = False
        for field in fields:
            if field in updated and updated.get(field) != edited.get(field):
                before = updated.get(field)
                updated[field] = edited.get(field)
                changed = True
                syncs.append({"stepKey": step, "field": field, "before": before, "after": edited.get(field)})
        if changed:
            if not _exact_same_structure(generated, updated):
                raise ValueError("CANONICAL_PAYLOAD_STRUCTURE_LOCK: linked Migration environment synchronization changed request structure.")
            diffs = _value_leaf_diffs(generated, updated)
            if diffs:
                save_override(workspace, step, diffs, request_kind="payload", mode="paths", note="Human-linked Migration environment synchronization", enabled=True, edit_origin="USER")
            else:
                clear_override(workspace, step)
    return syncs


@app.put("/api/configurations/{cid}/payload-overrides/{step_key}")
def save_configuration_payload_override(cid: str, step_key: str, payload: PayloadOverrideSave, request: Request) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    human_actor = _require_human_payload_edit_action(request)
    _require_editable_configuration(record, "editing API payload values")
    _require_configuration_decisions_resolved(record, "editing API payload values")
    try:
        preview = preview_all_api_requests(workspace)
        row = next((x for x in (preview.get("items") or []) if str(x.get("stepKey") or "") == str(step_key)), None)
        if not isinstance(row, dict):
            raise ValueError(f"Unknown API step: {step_key}")
        if row.get("applicable") is False:
            raise ValueError(f"{step_key} is not applicable to this configuration.")
        request_kind = str(row.get("requestKind") or payload.request_kind or "payload")
        if payload.request_kind != request_kind:
            raise ValueError(f"{step_key} uses {request_kind}; request kind cannot be changed.")
        generated = row.get("generatedParams") if request_kind == "params" else row.get("generatedPayload")
        generated = generated if isinstance(generated, dict) else {}
        edited = payload.value if isinstance(payload.value, dict) else {}
        if not _exact_same_structure(generated, edited):
            raise ValueError(
                "CANONICAL_PAYLOAD_STRUCTURE_LOCK: Payload Value Editor changes values only. "
                "Do not add/remove/rename fields, change nesting, or change array cardinality."
            )

        # Identity fields that are referenced by several API calls are promoted
        # to canonical input before the path edit is stored. This is what makes a
        # Source/Target TP-name edit propagate to validate/audit/dependent calls.
        identity_sync = _sync_linked_identity_value(workspace, step_key, edited)
        if identity_sync:
            preview = preview_all_api_requests(workspace)
            row = next((x for x in (preview.get("items") or []) if str(x.get("stepKey") or "") == str(step_key)), row)
            generated = row.get("generatedParams") if request_kind == "params" else row.get("generatedPayload")
            generated = generated if isinstance(generated, dict) else {}

        path_edits = _value_leaf_diffs(generated, edited)
        before = PayloadOverrideStore(workspace).summary()
        if path_edits:
            summary = save_override(
                workspace, step_key, path_edits,
                request_kind=request_kind, mode="paths",
                note=payload.note or "Human user-edited values from API Testing Area", enabled=True, edit_origin="USER",
            )
        else:
            summary = clear_override(workspace, step_key)

        migration_environment_sync = _sync_migration_environment_values(workspace, step_key, edited)
        if migration_environment_sync:
            summary = PayloadOverrideStore(workspace).summary()

        validation = validate_configuration(workspace)
        STORE.update_configuration(cid, {"validation": validation, "status": "VALIDATED" if validation.get("ok") else "VALIDATION_BLOCKED"})
        # V125: a queued READY snapshot must never retain values from before a
        # human save. Refresh not-yet-started jobs for this exact configuration
        # and recompute their tamper-evident hashes. Running/completed jobs are
        # deliberately left immutable.
        queue_refresh = PARALLEL.refresh_ready_jobs_for_configuration({**record, "id": cid}, validation)
        STORE.append_audit(
            "PAYLOAD_VALUE_EDIT_SAVED", "configuration", cid, actor=human_actor,
            summary=f"Saved schema-locked value edit for {step_key}",
            metadata={
                "stepKey": step_key, "requestKind": request_kind,
                "mode": "paths", "editedPaths": sorted(path_edits),
                "identitySync": identity_sync, "migrationEnvironmentSync": migration_environment_sync, "beforeCount": before.get("count", 0),
                "afterCount": summary.get("count", 0), "validationOk": bool(validation.get("ok")),
                "queueRefresh": queue_refresh,
            },
        )
        return {
            "ok": bool(validation.get("ok")), "override": summary,
            "validation": validation, "editedPaths": sorted(path_edits),
            "identitySync": identity_sync, "migrationEnvironmentSync": migration_environment_sync, "queueRefresh": queue_refresh,
            "policy": "HUMAN_USER_VALUES_EDITABLE_STRUCTURE_IMMUTABLE_AGENT_READ_ONLY",
            "agentEditAllowed": False, "userEditAllowed": True,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not save payload value edit: {type(exc).__name__}: {exc}")


@app.delete("/api/configurations/{cid}/payload-overrides/{step_key}")
def clear_configuration_payload_override(cid: str, step_key: str, request: Request) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    human_actor = _require_human_payload_edit_action(request)
    _require_editable_configuration(record, "clearing API payload overrides")
    _require_configuration_decisions_resolved(record, "editing API payload overrides")
    try:
        before = PayloadOverrideStore(workspace).summary()
        summary = clear_override(workspace, step_key)
        validation = validate_configuration(workspace)
        STORE.update_configuration(cid, {"validation": validation, "status": "VALIDATED" if validation.get("ok") else "VALIDATION_BLOCKED"})
        queue_refresh = PARALLEL.refresh_ready_jobs_for_configuration({**record, "id": cid}, validation)
        STORE.append_audit("PAYLOAD_OVERRIDE_CLEARED", "configuration", cid, actor=human_actor, summary=f"Cleared persistent payload override for {step_key}", metadata={"stepKey": step_key, "beforeCount": before.get("count", 0), "afterCount": summary.get("count", 0), "validationOk": bool(validation.get("ok")), "queueRefresh": queue_refresh})
        return {"ok": bool(validation.get("ok")), "override": summary, "validation": validation, "queueRefresh": queue_refresh}
    except Exception as exc:
        raise HTTPException(400, f"Could not clear payload override: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/execution-flow")
def get_configuration_execution_flow(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    return ExecutionFlowConfig(Path(record["workspace"])).summary()


@app.put("/api/configurations/{cid}/execution-flow")
def save_configuration_execution_flow(cid: str, payload: ExecutionFlowSave, request: Request) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    actor = _require_human_execution_flow_action(request)
    _require_editable_configuration(record, "changing the LIVE execution flow")
    _require_configuration_decisions_resolved(record, "changing the LIVE execution flow")
    workspace = Path(record["workspace"])
    try:
        rows = [row.model_dump() for row in payload.steps]
        if not rows:
            raise ValueError("Execution flow must include the registered API steps.")
        summary = save_execution_flow(workspace, rows, migration_enabled=payload.migrationEnabled)
        validation = validate_configuration(workspace)
        status = "VALIDATED" if bool(validation.get("fullLiveReady") if payload.migrationEnabled else validation.get("ok")) else "VALIDATION_BLOCKED"
        STORE.update_configuration(cid, {"validation": validation, "status": status})
        queue_refresh = PARALLEL.refresh_ready_jobs_for_configuration({**record, "id": cid}, validation)
        STORE.append_audit(
            "EXECUTION_FLOW_SAVED", "configuration", cid, actor=actor,
            summary=f"Saved human execution flow; Migration {'ON' if payload.migrationEnabled else 'OFF'}",
            metadata={
                "migrationEnabled": bool(payload.migrationEnabled),
                "orderedLiveSteps": list(summary.get("orderedLiveSteps") or []),
                "registeredTotalCount": int(summary.get("registeredTotalCount") or 25),
                "validationOk": bool(validation.get("fullLiveReady") if payload.migrationEnabled else validation.get("ok")),
                "queueRefresh": queue_refresh,
            },
        )
        return {**summary, "validation": validation, "queueRefresh": queue_refresh, "agentEditAllowed": False, "userEditAllowed": True}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not save execution flow: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/execution-flow/reset")
def reset_configuration_execution_flow(cid: str, request: Request) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    actor = _require_human_execution_flow_action(request)
    _require_editable_configuration(record, "resetting the LIVE execution flow")
    workspace = Path(record["workspace"])
    summary = reset_execution_flow(workspace)
    validation = validate_configuration(workspace)
    STORE.update_configuration(cid, {"validation": validation, "status": "VALIDATED" if validation.get("ok") else "VALIDATION_BLOCKED"})
    queue_refresh = PARALLEL.refresh_ready_jobs_for_configuration({**record, "id": cid}, validation)
    STORE.append_audit(
        "EXECUTION_FLOW_RESET", "configuration", cid, actor=actor,
        summary="Reset execution flow to dependency-safe default with Migration OFF",
        metadata={"migrationEnabled": False, "orderedLiveSteps": summary.get("orderedLiveSteps"), "queueRefresh": queue_refresh},
    )
    return {**summary, "validation": validation, "queueRefresh": queue_refresh, "agentEditAllowed": False, "userEditAllowed": True}


@app.get("/api/audit")
def audit_log(entity_type: str = "", entity_id: str = "", limit: int = 200) -> List[Dict[str, Any]]:
    return STORE.list_audit(entity_type=entity_type, entity_id=entity_id, limit=limit)


@app.get("/api/audit/verify")
def audit_verify() -> Dict[str, Any]:
    return STORE.verify_audit()


@app.get("/api/configurations")
def list_configurations() -> List[Dict[str, Any]]:
    # U-HAUL is a first-class, immutable developer-approved configuration.
    # It is kept in a normal workspace only so all Studio pages can consume the
    # same files; its approval state cannot be downgraded by customer validation.
    try:
        approved = _materialize_flow_source(_UHAL_PARALLEL_SOURCE_ID)
        approved_id = str(approved.get("id") or "")
    except Exception:
        approved_id = ""
    rows = []
    for row in STORE.list_configurations():
        if str(row.get("managed_reference_source") or "") == _UHAL_PARALLEL_SOURCE_ID and str(row.get("id") or "") != approved_id:
            # Hide stale upgrade mirrors. The one canonical approved reference is
            # materialized/synchronized above.
            continue
        if is_uhal_customer(row.get("customer") or row.get("name")) and not _is_approved_uhal_reference(row) and not bool(row.get("cloned_from_approved_reference") or row.get("starter_source")):
            # Old releases could persist extra U-HAUL workspaces (including
            # Passthrough). They are not the approved reference and are hidden.
            continue
        rows.append(row)
    rows.sort(key=lambda row: (0 if _is_approved_uhal_reference(row) else 1, str(row.get("customer") or row.get("name") or "").lower()))
    return [_decorate_configuration(row) for row in rows]


@app.post("/api/configurations")
def create_configuration(payload: ConfigurationCreate) -> Dict[str, Any]:
    return STORE.create_configuration(payload.model_dump())


@app.get("/api/configurations/{cid}")
def get_configuration(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    return _decorate_configuration(record, include_input=True)


@app.delete("/api/configurations/{cid}")
def delete_configuration(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_editable_configuration(record, "deleting the configuration")
    deleted = STORE.delete_configuration(cid)
    return {"deleted": bool(deleted), "id": cid}


@app.post("/api/configurations/{cid}/clone")
def clone_configuration(cid: str, payload: CloneRequest) -> Dict[str, Any]:
    try:
        source = STORE.get_configuration(cid)
        cloned = STORE.clone_configuration(cid, payload.name)
        if _is_approved_uhal_reference(source):
            cloned = STORE.update_configuration(cloned["id"], {
                "status": "STARTER_READY",
                "validation": {},
                "questions": [],
                "starter_source": _UHAL_PARALLEL_SOURCE_ID,
                "cloned_from_approved_reference": True,
                "build_summary": {
                    **(cloned.get("build_summary") or {}),
                    "starter_source": _UHAL_PARALLEL_SOURCE_ID,
                    "approval_inherited_as_starting_point_only": True,
                    "requires_customer_validation_after_changes": True,
                },
            })
        return _decorate_configuration(cloned, include_input=True)
    except KeyError:
        raise HTTPException(404, "Configuration not found")


@app.get("/api/configurations/{cid}/bundle")
def export_configuration_bundle(cid: str, request: Request) -> Response:
    try:
        record = STORE.get_configuration(cid)
        data = build_configuration_bundle(record)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except Exception as exc:
        raise HTTPException(400, f"Could not export configuration bundle: {exc}")
    filename = f"agentic_hip_{cid}_configuration.zip"
    STORE.append_audit("EXPORT_CONFIGURATION_BUNDLE", "configuration", cid, actor=_actor(request), summary="Portable configuration bundle exported", metadata={"bytes": len(data)})
    return Response(content=data, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/api/configuration-bundles/inspect")
async def inspect_bundle(bundle: UploadFile = File(...)) -> Dict[str, Any]:
    try:
        return inspect_configuration_bundle(await bundle.read())
    except Exception as exc:
        raise HTTPException(400, f"Bundle inspection failed: {exc}")


@app.post("/api/configuration-bundles/import")
async def import_bundle(bundle: UploadFile = File(...)) -> Dict[str, Any]:
    try:
        return import_configuration_bundle(STORE, await bundle.read())
    except Exception as exc:
        raise HTTPException(400, f"Bundle import failed: {exc}")


@app.patch("/api/configurations/{cid}")
def patch_configuration(cid: str, payload: ConfigurationPatch) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        _require_editable_configuration(record, "editing configuration values")
        changes = payload.model_dump(exclude_none=True)
        if changes:
            changes["validation"] = {}
            changes["status"] = "CONFIGURATION_CHANGED"
        return STORE.update_configuration(cid, changes)
    except KeyError:
        raise HTTPException(404, "Configuration not found")


@app.post("/api/configurations/{cid}/files")
async def upload_files(cid: str, files: List[UploadFile] = File(...)) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_editable_configuration(record, "uploading/replacing customer files")
    upload_dir = Path(record["workspace"]) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved = []
    for item in files:
        name = Path(item.filename or "upload.bin").name
        target = upload_dir / name
        with target.open("wb") as fh:
            shutil.copyfileobj(item.file, fh)
        saved.append({"name": name, "size": target.stat().st_size})
    current = {x.get("name"): x for x in record.get("uploaded_files", [])}
    for row in saved:
        current[row["name"]] = row
    return STORE.update_configuration(cid, {"uploaded_files": list(current.values()), "status": "FILES_UPLOADED", "validation": {}})


@app.post("/api/configurations/{cid}/build")
def build(cid: str, use_dell_aia: bool = True) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        _require_editable_configuration(record, "rebuilding the configuration")
        result = build_configuration(Path(record["workspace"]), record, use_dell_aia=use_dell_aia)
        status = "READY_FOR_API_MAPPING" if result["ready_for_api_mapping"] else "NEEDS_INPUT"
        resolved_flow_type = "Translation" if bool((result.get("input") or {}).get("requires_data_map")) else "Passthrough"
        built_input = result.get("input") or {}
        generated_template = _sync_generated_template(cid, built_input)
        updated_record = STORE.update_configuration(cid, {
            "status": status,
            "validation": {},
            "questions": result["questions"],
            "resolved_flow_type": resolved_flow_type,
            # Keep the configuration card aligned with a structurally-approved
            # uploaded HIP JSON.  This prevents a fresh card's convenience
            # defaults (Outbound/850) from disagreeing with an approved Inbound
            # customer configuration such as Legrand.
            "direction": built_input.get("direction") or record.get("direction"),
            "transaction_code": built_input.get("tx_code") or record.get("transaction_code"),
            "customer": built_input.get("customer") or record.get("customer"),
            "build_summary": {
                "ready_for_api_mapping": result["ready_for_api_mapping"], "deployment_group": result["deployment_group"],
                "uploaded_files": result["uploaded_files"], "resolved_flow_type": resolved_flow_type,
                "authoritative_json": result.get("authoritative_json") or "",
                "generated_template_id": generated_template.get("id", ""),
                "generated_template_version": generated_template.get("version", 1),
                "input_extraction_blueprint": ((built_input.get("_input_extraction_blueprint") or {}).get("summary") or {}),
            },
        })
        try:
            result["intake_report"] = write_customer_intake_report(Path(updated_record["workspace"]), updated_record, LEGACY_ROOT)
        except Exception as report_exc:
            result["intake_report_error"] = f"{type(report_exc).__name__}: {report_exc}"
        result["generated_template"] = generated_template
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Build failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/answers")
def answer_questions(cid: str, payload: AnswerPayload) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        _require_editable_configuration(record, "answering configuration questions")
        result = apply_configuration_answers(Path(record["workspace"]), record, payload.answers)
        resolved_flow_type = "Translation" if bool((result.get("input") or {}).get("requires_data_map")) else "Passthrough"
        generated_template = _sync_generated_template(cid, result.get("input") or {})
        resolved_input = result.get("input") or {}
        updated_record = STORE.update_configuration(cid, {
            "status": "READY_FOR_API_MAPPING" if result["ready_for_api_mapping"] else "NEEDS_INPUT",
            "validation": {},
            "questions": result["questions"],
            "resolved_flow_type": resolved_flow_type,
            "customer": resolved_input.get("customer") or record.get("customer"),
            "direction": resolved_input.get("direction") or record.get("direction"),
            "transaction_code": resolved_input.get("tx_code") or record.get("transaction_code"),
            "transaction_name": resolved_input.get("tx_name") or record.get("transaction_name"),
            "flow_type": resolved_flow_type,
            "source_interface": result.get("effective_source_interface") or record.get("source_interface"),
            "target_interface": result.get("effective_target_interface") or record.get("target_interface"),
            "build_summary": {**(record.get("build_summary") or {}), "generated_template_id": generated_template.get("id", ""), "generated_template_version": generated_template.get("version", 1)},
        })
        try:
            result["intake_report"] = write_customer_intake_report(Path(updated_record["workspace"]), updated_record, LEGACY_ROOT)
        except Exception as report_exc:
            result["intake_report_error"] = f"{type(report_exc).__name__}: {report_exc}"
        result["generated_template"] = generated_template
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not apply answers: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/api-requests")
def configuration_api_requests(cid: str) -> Dict[str, Any]:
    """Return generated requests annotated with the latest persisted contract state.

    Preview generation alone only proves that a request object can be rendered; it
    does *not* mean that request passed the HIP contract validator.  The API Testing
    Area therefore receives READY/BLOCKED/NOT_VALIDATED from the same validation
    result used by Build Configuration, preventing the old all-READY false signal.
    """
    try:
        record = STORE.get_configuration(cid)
        if _is_approved_uhal_reference(record):
            record = STORE.update_configuration(cid, _approved_uhal_patch(record))
        _require_configuration_decisions_resolved(record, "opening API Testing Area requests")
        workspace = Path(record["workspace"])
        # Preserve the historical preview contract for incomplete/test workspaces,
        # while adding V122 Migration blocks whenever a real built input.json is
        # present. This keeps legacy callers deterministic and avoids inventing
        # Migration identities before a canonical configuration exists.
        base_preview = preview_api_requests(workspace)
        if (workspace / "input.json").exists():
            migration_preview = preview_migration_requests(workspace)
            result = {
                "items": list(base_preview.get("items") or []) + list(migration_preview.get("items") or []),
                "configurationItems": list(base_preview.get("items") or []),
                "migrationItems": list(migration_preview.get("items") or []),
            }
        else:
            result = base_preview
        validation = record.get("validation") or {}
        requests_validation = validation.get("requests") or {}
        validation_items = {str(item.get("stepKey") or ""): item for item in (requests_validation.get("items") or []) if isinstance(item, dict)}
        blocked_items = {str(item.get("stepKey") or ""): item for item in (requests_validation.get("blockedItems") or []) if isinstance(item, dict)}
        for item in result.get("items") or []:
            if not isinstance(item, dict):
                continue
            key = str(item.get("stepKey") or "")
            contract = validation_items.get(key) or blocked_items.get(key)
            is_migration = key.startswith("migrate_")
            if item.get("applicable") is False:
                status = "NOT_APPLICABLE"
            elif is_migration:
                # Migration APIs are additive reusable blocks and are not part of
                # the historical 18-step Build validation inventory. Their preview
                # carries a deterministic local readiness check; API Testing/Flow
                # Game still run the normal contract preflight before LIVE.
                status = "READY" if bool(item.get("migrationReady")) else "BLOCKED"
                contract = {
                    "valid": bool(item.get("migrationReady")),
                    "errors": list(item.get("migrationErrors") or []),
                    "source": "migration-preview-readiness",
                }
            elif isinstance(contract, dict) and contract.get("valid") is False:
                status = "BLOCKED"
            elif isinstance(contract, dict) and contract.get("valid") is True:
                status = "READY"
            elif not validation:
                status = "NOT_VALIDATED"
            else:
                # Never infer per-API READY from a global PASS when this exact
                # contract row is absent. READY requires explicit contract evidence.
                status = "UNKNOWN"
            item["contractStatus"] = status
            item["contractValidation"] = contract or {}
        result["validation"] = validation
        result["contractSummary"] = {
            "ok": bool(validation.get("ok")),
            "validCount": int(requests_validation.get("validCount") or 0),
            "total": int(requests_validation.get("total") or len(result.get("items") or [])),
            "blockedCount": int(requests_validation.get("blockedCount") or max(0, int(requests_validation.get("total") or len(result.get("items") or [])) - int(requests_validation.get("validCount") or 0))),
        }
        return result
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not preview API requests: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/intelligent-mapper/analyze")
async def intelligent_excel_api_mapper(
    cid: str,
    workbook: UploadFile = File(...),
    api_key: str = Form("AUTO"),
    sheet_name: str = Form(""),
    header_row: int = Form(0),
    use_dell_aia: bool = Form(True),
) -> Dict[str, Any]:
    """Analyze Excel/CSV rows against immutable generated HIP API requests.

    Dell AIA/deterministic agents may map workbook data and prepare changed values
    only for exact existing canonical leaves. This analysis endpoint itself is
    non-mutating. The user must explicitly approve the agent-prepared value set
    through the schema-locked staging endpoint before it can affect LIVE requests.
    """
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    if not (workspace / "input.json").exists():
        raise HTTPException(400, "Build input.json before mapping workbook rows to API payloads.")
    _require_configuration_decisions_resolved(record, "mapping workbook rows to API payloads")
    try:
        data = await workbook.read()
        preview = preview_all_api_requests(workspace)
        # Reuse the same persisted contract status annotations shown in API Testing.
        validation = record.get("validation") or {}
        request_validation = validation.get("requests") or {}
        validation_items = {str(item.get("stepKey") or ""): item for item in (request_validation.get("items") or []) if isinstance(item, dict)}
        blocked_items = {str(item.get("stepKey") or ""): item for item in (request_validation.get("blockedItems") or []) if isinstance(item, dict)}
        for row in preview.get("items") or []:
            if not isinstance(row, dict):
                continue
            key = str(row.get("stepKey") or "")
            contract = validation_items.get(key) or blocked_items.get(key)
            if row.get("applicable") is False:
                row["contractStatus"] = "NOT_APPLICABLE"
            elif key.startswith("migrate_"):
                row["contractStatus"] = "READY" if bool(row.get("migrationReady")) else "BLOCKED"
            elif isinstance(contract, dict) and contract.get("valid") is False:
                row["contractStatus"] = "BLOCKED"
            elif isinstance(contract, dict) and contract.get("valid") is True:
                row["contractStatus"] = "READY"
            else:
                row["contractStatus"] = "NOT_VALIDATED" if not validation else "UNKNOWN"
        result = analyze_workbook(
            filename=workbook.filename or "workbook.xlsx",
            data=data,
            preview_items=preview.get("items") or [],
            selected_api=api_key,
            requested_sheet=sheet_name,
            requested_header_row=header_row,
            use_dell_aia=use_dell_aia,
        )
        result["configuration"] = {
            "id": cid, "name": record.get("name"), "customer": record.get("customer"),
            "status": record.get("status"), "immutableReference": _is_approved_uhal_reference(record),
        }
        STORE.append_audit(
            "INTELLIGENT_EXCEL_API_MAPPING", "configuration", cid, actor="Agent (value-mapping; schema-locked)",
            summary=f"Analyzed {result.get('summary', {}).get('rows', 0)} workbook rows against HIP API contracts",
            metadata={
                "filename": workbook.filename or "", "apiKey": api_key,
                "sheet": result.get("sheet", {}).get("name"),
                "llmUsed": bool(result.get("llm", {}).get("used")),
                "goodToTrigger": result.get("summary", {}).get("GOOD_TO_TRIGGER", 0),
                "needsInput": result.get("summary", {}).get("NEEDS_INPUT", 0),
                "doNotTrigger": result.get("summary", {}).get("DO_NOT_TRIGGER", 0),
                "mutated": False,
            },
        )
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Intelligent workbook mapping failed: {type(exc).__name__}: {exc}")


@app.get("/api/templates")
def templates() -> List[Dict[str, Any]]:
    return _template_catalog()


@app.post("/api/templates")
def create_template(payload: TemplateCreate) -> Dict[str, Any]:
    body = payload.model_dump()
    _guard_template_payload(body)
    return STORE.save_template(body)


@app.put("/api/templates/{tid}")
def update_template(tid: str, payload: TemplateCreate) -> Dict[str, Any]:
    if tid.startswith("builtin-"):
        raise HTTPException(400, "Clone a built-in template before editing it.")
    body = payload.model_dump()
    _guard_template_payload(body)
    return STORE.save_template(body, template_id=tid)


@app.delete("/api/templates/{tid}")
def delete_template(tid: str) -> Dict[str, Any]:
    if tid.startswith("builtin-"):
        raise HTTPException(400, "Built-in templates cannot be deleted.")
    return {"deleted": STORE.delete_template(tid)}


@app.get("/api/templates/{tid}/versions")
def template_versions(tid: str) -> List[Dict[str, Any]]:
    if tid.startswith("builtin-"):
        match = [t for t in _builtin_template_catalog() if t.get("id") == tid]
        return match
    try:
        STORE.get_template(tid)
    except KeyError:
        raise HTTPException(404, "Template not found")
    return STORE.list_template_versions(tid)


@app.post("/api/templates/{tid}/clone")
def clone_template(tid: str, payload: CloneRequest) -> Dict[str, Any]:
    if tid.startswith("builtin-"):
        source = next((t for t in _builtin_template_catalog() if t.get("id") == tid), None)
        if not source:
            raise HTTPException(404, "Template not found")
        body = {key: source.get(key) for key in ("name", "description", "direction", "transaction_code", "flow_type", "nodes", "edges", "variables", "tags")}
        body["name"] = payload.name or f"{source.get('name')} Copy"
        cloned = STORE.save_template(body)
        cloned["source_template_id"] = tid
        STORE._write(STORE.template_root / f"{cloned['id']}.json", cloned)
        STORE._write(STORE.template_history_root / cloned["id"] / "v1.json", cloned)
        return cloned
    try:
        return STORE.clone_template(tid, payload.name)
    except KeyError:
        raise HTTPException(404, "Template not found")


@app.post("/api/templates/{tid}/publish")
def publish_template(tid: str, payload: TemplateLifecycleRequest) -> Dict[str, Any]:
    if tid.startswith("builtin-"):
        raise HTTPException(400, "Built-in templates are already published.")
    try:
        return STORE.set_template_lifecycle(tid, "PUBLISHED")
    except KeyError:
        raise HTTPException(404, "Template not found")


@app.post("/api/templates/{tid}/archive")
def archive_template(tid: str, payload: TemplateLifecycleRequest) -> Dict[str, Any]:
    if tid.startswith("builtin-"):
        raise HTTPException(400, "Built-in templates cannot be archived.")
    try:
        return STORE.set_template_lifecycle(tid, "ARCHIVED")
    except KeyError:
        raise HTTPException(404, "Template not found")


@app.post("/api/configurations/{cid}/flow/preflight")
def flow_preflight(cid: str, flow: FlowDefinition) -> Dict[str, Any]:
    try:
        config = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(config["workspace"])
    input_path = workspace / "input.json"
    if not input_path.exists():
        raise HTTPException(400, "Build input.json before validating the API Flow.")
    _require_configuration_decisions_resolved(config, "opening API Flow preflight")
    try:
        preview = preview_all_api_requests(workspace)
        graph = immutable_flow_graph(flow.model_dump())
        compilation = compile_flow(graph, [row["key"] for row in all_api_catalog()], preview)
        contract = {"ok": False, "items": []}
        if compilation.get("ok"):
            graph["execution_order"] = compilation.get("executionOrder") or []
            contract = preflight_flow_requests(workspace, graph)
        result = {
            **compilation,
            "contractValidation": contract,
            "configurationValidation": config.get("validation") or {},
            "readyForLive": bool(compilation.get("ok") and contract.get("ok") and (config.get("validation") or {}).get("ok")),
        }
        (workspace / "reports" / "react_flow_preflight_latest.json").write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Flow preflight failed: {type(exc).__name__}: {exc}")


def _flow_node_agent_check(config: Dict[str, Any], node_id: str, flow: FlowDefinition) -> Dict[str, Any]:
    """Run a fresh, non-mutating safety check for exactly one Flow Game block.

    Standalone execution deliberately refuses blocks whose request depends on
    runtime edge mappings because those values only exist after upstream blocks
    execute. The user can still run the complete graph or replace the request
    with concrete values/remove the runtime mapping before retrying.
    """
    workspace = Path(str(config.get("workspace") or ""))
    if not (workspace / "input.json").exists():
        raise HTTPException(400, "Build input.json before checking an API Flow block.")
    _require_configuration_decisions_resolved(config, "checking an API Flow block")

    graph = immutable_flow_graph(flow.model_dump())
    node = next((row for row in graph.get("nodes") or [] if str(row.get("id") or "") == str(node_id)), None)
    if not node:
        raise HTTPException(404, "Selected API Flow block was not found.")

    incoming_mapped = [
        edge for edge in (graph.get("edges") or [])
        if str(edge.get("target") or "") == str(node_id) and bool(edge.get("mappings") or [])
    ]
    config_valid = bool((config.get("validation") or {}).get("ok"))
    enabled = bool(node.get("enabled", True))

    preview = api_test_request(
        workspace,
        str(node.get("api_key") or ""),
        request_override={},
        override_mode="merge",
        execute=False,
    )
    applicable = bool(preview.get("applicable", True))
    contract_valid = bool(preview.get("ok") and (preview.get("contractValidation") or {}).get("valid", True))

    checks: List[Dict[str, Any]] = [
        {
            "key": "configuration_validation",
            "label": "Customer configuration validation",
            "status": "PASS" if config_valid else "BLOCKED",
            "reason": "Latest customer configuration validation passed." if config_valid else "Run Build Configuration validation again before LIVE execution.",
        },
        {
            "key": "block_enabled",
            "label": "Block enabled",
            "status": "PASS" if enabled else "BLOCKED",
            "reason": "Block is enabled." if enabled else "Enable this block before running it individually.",
        },
        {
            "key": "applicability",
            "label": "API applicability",
            "status": "PASS" if applicable else "BLOCKED",
            "reason": "API applies to this customer configuration." if applicable else str(preview.get("applicabilityReason") or "This API is not applicable to the active configuration."),
        },
        {
            "key": "request_contract",
            "label": "Effective payload / API contract",
            "status": "PASS" if contract_valid else "BLOCKED",
            "reason": "The effective request satisfies the API contract." if contract_valid else "The effective request has missing or invalid contract fields.",
        },
        {
            "key": "runtime_dependencies",
            "label": "Standalone runtime dependencies",
            "status": "PASS" if not incoming_mapped else "BLOCKED",
            "reason": "No unresolved upstream runtime mapping is required." if not incoming_mapped else f"{len(incoming_mapped)} incoming connection(s) inject runtime values from upstream blocks. Run prerequisites/the full flow, or replace those values with concrete payload values before a standalone run.",
        },
    ]
    ready = all(row.get("status") == "PASS" for row in checks)
    summary = (
        "Agent check PASS. This block can be executed individually with its current effective request."
        if ready else
        "Agent check BLOCKED. Fix the failed checks before this block can make a LIVE call."
    )
    return {
        **preview,
        "ok": ready,
        "readyForLive": ready,
        "nodeId": str(node_id),
        "stepKey": str(node.get("api_key") or preview.get("stepKey") or ""),
        "agentCheck": {
            "ready": ready,
            "verdict": "PASS" if ready else "BLOCKED",
            "summary": summary,
            "checks": checks,
            "incomingRuntimeMappings": sum(len(edge.get("mappings") or []) for edge in incoming_mapped),
            "approvalRequired": bool(node.get("approval_required", False)),
            "approvalNote": "The final individual LIVE confirmation is recorded as the operator approval for this one-block execution." if node.get("approval_required") else "",
        },
    }


@app.post("/api/configurations/{cid}/flow/nodes/{node_id}/preflight")
def flow_node_preflight(cid: str, node_id: str, payload: FlowNodeAction) -> Dict[str, Any]:
    try:
        config = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    try:
        return _flow_node_agent_check(config, node_id, payload.flow)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Individual block agent check failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/flow/nodes/{node_id}/execute")
def flow_node_execute(cid: str, node_id: str, payload: FlowNodeAction, request: Request) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "Individual LIVE block execution requires explicit confirmation.")
    try:
        config = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")

    checked = _flow_node_agent_check(config, node_id, payload.flow)
    if not checked.get("readyForLive"):
        raise HTTPException(400, detail={"message": "Agent check blocked this individual LIVE API call.", "agentCheck": checked.get("agentCheck")})

    graph = immutable_flow_graph(payload.flow.model_dump())
    node = next(row for row in (graph.get("nodes") or []) if str(row.get("id") or "") == str(node_id))
    workspace = Path(str(config.get("workspace") or ""))
    try:
        final_validation = validate_configuration(workspace)
        if not final_validation.get("ok"):
            raise HTTPException(400, detail={"message": "Fresh customer/API validation failed immediately before the individual LIVE call. No LIVE API call was made.", "validation": final_validation})
        final_preflight = production_preflight(workspace)
        if not final_preflight.get("ready"):
            raise HTTPException(400, detail={"message": "Production preflight failed immediately before the individual LIVE call. No LIVE API call was made.", "preflight": final_preflight})
        evidence = {"ready": True, "nodeId": node_id, "stepKey": node.get("api_key"), "agentCheck": checked.get("agentCheck"), "configurationValidation": final_validation, "productionPreflight": final_preflight}
        reports = workspace / "reports"; reports.mkdir(parents=True, exist_ok=True)
        (reports / "flow_node_final_pre_live_checks_latest.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        result = api_test_request(
            Path(str(config.get("workspace") or "")),
            str(node.get("api_key") or ""),
            request_override={},
            override_mode="merge",
            execute=True,
        )
        result["agentCheck"] = checked.get("agentCheck")
        result["nodeId"] = str(node_id)
        STORE.append_audit(
            "LIVE_FLOW_BLOCK", "configuration", cid, actor=_actor(request),
            summary=f"API Flow Game executed individual block {node_id}",
            metadata={"nodeId": node_id, "stepKey": node.get("api_key"), "ok": bool(result.get("ok")), "verdict": (result.get("verdict") or {}).get("verdict")},
        )
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Individual LIVE block failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/flow/autofix")
def flow_autofix(cid: str, flow: FlowDefinition) -> Dict[str, Any]:
    try:
        config = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_configuration_decisions_resolved(config, "auto-fixing the API Flow")
    try:
        preview = preview_api_requests(Path(config["workspace"]))
        graph = immutable_flow_graph(flow.model_dump())
        compilation = compile_flow(graph, [row["key"] for row in all_api_catalog()], preview)
        fixed = apply_safe_fixes(graph, compilation)
        second = compile_flow(fixed["flow"], [row["key"] for row in all_api_catalog()], preview)
        return {**fixed, "before": compilation, "after": second}
    except Exception as exc:
        raise HTTPException(400, f"Agent flow fix failed: {type(exc).__name__}: {exc}")


@app.get("/api/executions")
def executions(configuration_id: str = "") -> List[Dict[str, Any]]:
    return STORE.list_executions(configuration_id=configuration_id)


@app.post("/api/executions")
async def start_execution(payload: ExecutionStart) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "Live execution confirmation is required.")
    try:
        config = STORE.get_configuration(payload.configuration_id)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(config["workspace"])
    input_path = workspace / "input.json"
    if not input_path.exists():
        raise HTTPException(400, "Build input.json before running the API Flow.")
    _require_configuration_decisions_resolved(config, "LIVE graph execution")
    if not (config.get("validation") or {}).get("ok"):
        raise HTTPException(400, "Agent validation must PASS before LIVE graph execution.")
    graph = immutable_flow_graph(payload.flow.model_dump())
    try:
        final_validation = validate_configuration(workspace)
        if not final_validation.get("ok"):
            raise HTTPException(400, {"message": "Fresh customer/API validation failed immediately before LIVE graph execution. No LIVE HIP API call was made.", "validation": final_validation})
        final_preflight = production_preflight(workspace)
        if not final_preflight.get("ready"):
            raise HTTPException(400, {"message": "Production preflight failed immediately before LIVE graph execution. No LIVE HIP API call was made.", "preflight": final_preflight})
        evidence = {"ready": True, "configurationValidation": final_validation, "productionPreflight": final_preflight}
        reports = workspace / "reports"; reports.mkdir(parents=True, exist_ok=True)
        (reports / "flow_final_pre_live_checks_latest.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        preview = preview_all_api_requests(workspace)
        compilation = compile_flow(graph, [row["key"] for row in all_api_catalog()], preview)
        if not compilation.get("ok"):
            raise HTTPException(400, {"message": "API Flow graph validation failed.", "errors": compilation.get("errors")})
        graph["execution_order"] = compilation.get("executionOrder") or []
        contract = preflight_flow_requests(workspace, graph)
        if not contract.get("ok"):
            raise HTTPException(400, {"message": "One or more graph requests failed agent/API contract preflight.", "items": contract.get("items")})
        loop = asyncio.get_running_loop()
        return EXECUTIONS.start(config, graph, loop, resume_from_execution=payload.resume_execution_id)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(400, f"LIVE graph preflight failed: {type(exc).__name__}: {exc}")


@app.get("/api/executions/{execution_id}")
def execution(execution_id: str) -> Dict[str, Any]:
    value = STORE.get_execution(execution_id)
    if not value:
        raise HTTPException(404, "Execution not found")
    return value


@app.get("/api/executions/{execution_id}/evidence-bundle")
def execution_evidence_bundle(execution_id: str, request: Request) -> Response:
    record = STORE.get_execution(execution_id)
    if not record:
        raise HTTPException(404, "Execution not found")
    try:
        config = STORE.get_configuration(str(record.get("configuration_id") or ""))
        reports = list_reports(Path(config["workspace"]))
        data = build_execution_evidence_bundle(record, config, reports)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    filename = f"agentic_hip_execution_{execution_id}_evidence.zip"
    STORE.append_audit("EXPORT_EXECUTION_EVIDENCE", "execution", execution_id, actor=_actor(request), summary="Execution evidence bundle exported", metadata={"bytes": len(data)})
    return Response(content=data, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str) -> Dict[str, Any]:
    try:
        return EXECUTIONS.cancel(execution_id, asyncio.get_running_loop())
    except ValueError as exc:
        raise HTTPException(404, str(exc))


@app.post("/api/executions/{execution_id}/nodes/{node_id}/approve")
def approve_execution_node(execution_id: str, node_id: str, payload: NodeApproval) -> Dict[str, Any]:
    try:
        return EXECUTIONS.approve_node(execution_id, node_id, payload.approved_by, payload.note)
    except (ValueError, KeyError) as exc:
        raise HTTPException(404, str(exc))


@app.post("/api/executions/{execution_id}/resume")
async def resume_execution(execution_id: str, payload: ExecutionResume) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "Live resume confirmation is required.")
    previous = STORE.get_execution(execution_id)
    if not previous:
        raise HTTPException(404, "Execution not found")
    if str(previous.get("status") or "").upper() not in {"BLOCKED", "ERROR", "CANCELLED"}:
        raise HTTPException(400, "Only BLOCKED, ERROR, or CANCELLED executions can be resumed.")
    try:
        config = STORE.get_configuration(str(previous.get("configuration_id") or ""))
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    if not (config.get("validation") or {}).get("ok"):
        raise HTTPException(400, "Agent validation must still PASS before resuming LIVE execution.")
    graph = dict(previous.get("flow") or {})
    try:
        preview = preview_api_requests(Path(config["workspace"]))
        compilation = compile_flow(graph, [row["key"] for row in all_api_catalog()], preview)
        if not compilation.get("ok"):
            raise HTTPException(400, {"message": "Saved API Flow graph is no longer valid.", "errors": compilation.get("errors")})
        graph["execution_order"] = compilation.get("executionOrder") or []
        contract = preflight_flow_requests(Path(config["workspace"]), graph)
        if not contract.get("ok"):
            raise HTTPException(400, {"message": "One or more remaining graph requests failed preflight.", "items": contract.get("items")})
        return EXECUTIONS.start(config, graph, asyncio.get_running_loop(), resume_from_execution=execution_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"LIVE resume preflight failed: {type(exc).__name__}: {exc}")


@app.get("/api/executions/compare/{left_id}/{right_id}")
def compare_executions(left_id: str, right_id: str) -> Dict[str, Any]:
    try:
        return EXECUTIONS.compare(left_id, right_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc))


@app.websocket("/ws/executions/{execution_id}")
async def execution_ws(websocket: WebSocket, execution_id: str) -> None:
    await websocket.accept()
    queue = await EXECUTIONS.subscribe(execution_id)
    try:
        while True:
            event = await queue.get()
            await websocket.send_json(event)
            if event.get("type") in {"execution.completed", "execution.error", "execution.cancelled"}:
                break
    except WebSocketDisconnect:
        pass
    finally:
        EXECUTIONS.unsubscribe(execution_id, queue)


@app.post("/api/configurations/{cid}/validate")
def validate_config(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    if _is_approved_uhal_reference(record):
        # U-HAUL approval is a developer-owned immutable baseline. Do not turn a
        # runtime/preflight problem into a customer-validation blocker.
        result = _approved_uhal_validation()
        STORE.update_configuration(cid, _approved_uhal_patch(record))
        return result
    required_questions = [q for q in (record.get("questions") or []) if not q.get("informational")]
    if required_questions:
        raise HTTPException(400, "Resolve the agent's required questions before final API validation.")
    try:
        result = validate_configuration(Path(record["workspace"]))
        patch = {"validation": result, "status": "VALIDATED" if result.get("ok") else "VALIDATION_BLOCKED"}
        updated_record = STORE.update_configuration(cid, patch)
        try:
            write_customer_intake_report(Path(updated_record["workspace"]), updated_record, LEGACY_ROOT)
        except Exception:
            pass
        if result.get("ok") and str(record.get("input_mode") or "") == "input_files":
            try:
                patch["mapping_learning"] = teach_mapping_reference(Path(record["workspace"]))
                STORE.update_configuration(cid, {"mapping_learning": patch["mapping_learning"]})
            except Exception:
                pass
        return result
    except Exception as exc:
        raise HTTPException(400, f"Validation failed: {type(exc).__name__}: {exc}")


@app.post("/api/configurations/{cid}/validation-fixes")
def apply_validation_fixes(cid: str, payload: ValidationFixPayload) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_editable_configuration(record, "applying validation fixes")
    validation = record.get("validation") or {}
    blocked_fields = {
        (str(item.get("stepKey") or ""), str(err.get("field") or ""))
        for item in ((validation.get("requests") or {}).get("blockedItems") or [])
        for err in (item.get("errors") or []) if isinstance(err, dict)
    }
    requested = [fix.model_dump() for fix in payload.fixes]
    if not requested:
        raise HTTPException(400, "Enter at least one correction before applying fixes.")
    invalid = [(row.get("step_key"), row.get("field")) for row in requested if (str(row.get("step_key") or ""), str(row.get("field") or "")) not in blocked_fields]
    if invalid:
        raise HTTPException(400, f"Inline fixes are allowed only for fields in the latest blocked validation: {invalid}")
    try:
        workspace = Path(record["workspace"])
        repair = apply_inline_validation_fixes(workspace, requested)
        result = validate_configuration(workspace)
        canonical = json.loads((workspace / "input.json").read_text(encoding="utf-8"))
        canonical = refresh_input_extraction_blueprint(workspace, canonical, record)
        generated_template = _sync_generated_template(cid, canonical)
        updated_record = STORE.update_configuration(cid, {
            "validation": result,
            "status": "VALIDATED" if result.get("ok") else "VALIDATION_BLOCKED",
            "build_summary": {**(record.get("build_summary") or {}), "generated_template_id": generated_template.get("id", ""), "generated_template_version": generated_template.get("version", 1)},
        })
        intake_report = write_customer_intake_report(workspace, updated_record, LEGACY_ROOT)
        return {"ok": bool(result.get("ok")), "repair": repair, "validation": result, "generated_template": generated_template, "intake_report": intake_report}
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(400, f"Could not apply inline validation fix: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/evidence")
def evidence(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        return configuration_evidence(Path(record["workspace"]))
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except Exception as exc:
        raise HTTPException(400, f"Could not inspect evidence: {type(exc).__name__}: {exc}")


@app.get("/api/mapping-learning")
def mapping_learning() -> Dict[str, Any]:
    return mapping_learning_state()


@app.post("/api/configurations/{cid}/mapping-learning/teach")
def teach_mapping(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_configuration_decisions_resolved(record, "teaching the mapping learner")
    validation = record.get("validation") or {}
    if not validation.get("ok"):
        raise HTTPException(400, "Agent validation must PASS before this pair can become a mapping reference.")
    try:
        result = teach_mapping_reference(Path(record["workspace"]))
        STORE.update_configuration(cid, {"mapping_learning": result})
        return result
    except Exception as exc:
        raise HTTPException(400, f"Could not teach mapping learner: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/learn/records")
def config_learn_records(cid: str) -> List[Dict[str, Any]]:
    try:
        record = STORE.get_configuration(cid)
        return learn_records(Path(record["workspace"]))
    except KeyError:
        raise HTTPException(404, "Configuration not found")


@app.post("/api/configurations/{cid}/learn/files")
async def config_learn_files(cid: str, question: str = "", files: List[UploadFile] = File(...)) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    learned = []
    for item in files:
        data = await item.read()
        try:
            learned.append(ingest_learn_file(Path(record["workspace"]), item.filename or "evidence.bin", data, item.content_type or "", question))
        except Exception as exc:
            learned.append({"filename": item.filename, "error": f"{type(exc).__name__}: {exc}"})
    return {"learned": learned, "records": learn_records(Path(record["workspace"]))}


@app.post("/api/configurations/{cid}/learn/ask")
def config_learn_ask(cid: str, payload: LearnAskPayload) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        return ask_learn(Path(record["workspace"]), payload.question)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except Exception as exc:
        raise HTTPException(400, f"Learn could not answer: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/extraction-blueprint")
def extraction_blueprint(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    input_path = workspace / "input.json"
    if not input_path.exists():
        raise HTTPException(400, "Build input.json first.")
    canonical = json.loads(input_path.read_text(encoding="utf-8"))
    canonical = refresh_input_extraction_blueprint(workspace, canonical, record)
    return {"ok": True, "report": "input_extraction_blueprint_execution_latest.json", "blueprint": canonical.get("_input_extraction_blueprint") or {}}


@app.get("/api/configurations/{cid}/extraction-blueprint/download")
def extraction_blueprint_download(cid: str) -> Response:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    input_path = workspace / "input.json"
    if not input_path.exists():
        raise HTTPException(400, "Build input.json first.")
    canonical = json.loads(input_path.read_text(encoding="utf-8"))
    refresh_input_extraction_blueprint(workspace, canonical, record)
    path = workspace / "reports" / "input_extraction_blueprint_execution_latest.json"
    return Response(content=path.read_bytes(), media_type="application/json; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="input_extraction_blueprint_execution_latest.json"'})


@app.get("/api/configurations/{cid}/intake-report")
def customer_intake_report(cid: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    if not (workspace / "input.json").exists():
        raise HTTPException(400, "Build input.json first so the agent can compare extracted, derived and user-required values.")
    try:
        model = write_customer_intake_report(workspace, record, LEGACY_ROOT)
        return {"ok": True, "report": REPORT_HTML, "json": REPORT_JSON, "summary": model}
    except Exception as exc:
        raise HTTPException(400, f"Could not generate customer intake report: {type(exc).__name__}: {exc}")


@app.get("/api/configurations/{cid}/intake-report/download")
def customer_intake_report_download(cid: str) -> Response:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"])
    if not (workspace / "input.json").exists():
        raise HTTPException(400, "Build input.json first.")
    try:
        write_customer_intake_report(workspace, record, LEGACY_ROOT)
    except Exception as exc:
        raise HTTPException(400, f"Could not generate customer intake report: {type(exc).__name__}: {exc}")
    path = workspace / "reports" / REPORT_HTML
    return Response(content=path.read_bytes(), media_type="text/html; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{REPORT_HTML}"'})


@app.get("/api/configurations/{cid}/reports")
def config_reports(cid: str) -> List[Dict[str, Any]]:
    try:
        record = STORE.get_configuration(cid)
        return list_reports(Path(record["workspace"]))
    except KeyError:
        raise HTTPException(404, "Configuration not found")


@app.get("/api/configurations/{cid}/reports/{report_name}")
def config_report(cid: str, report_name: str) -> Dict[str, Any]:
    try:
        record = STORE.get_configuration(cid)
        return read_report(Path(record["workspace"]), report_name)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    except FileNotFoundError:
        raise HTTPException(404, "Report not found")


@app.get("/api/configurations/{cid}/reports/{report_name}/download")
def config_report_download(cid: str, report_name: str) -> Response:
    try:
        record = STORE.get_configuration(cid)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    workspace = Path(record["workspace"]).resolve()
    safe_name = Path(report_name).name
    path = (workspace / "reports" / safe_name).resolve()
    if path.parent != (workspace / "reports").resolve() or not path.exists() or not path.is_file():
        raise HTTPException(404, "Report not found")
    media = "text/html; charset=utf-8" if path.suffix.lower() in {".html", ".htm"} else "application/octet-stream"
    return Response(content=path.read_bytes(), media_type=media, headers={"Content-Disposition": f'attachment; filename="{safe_name}"'})



def _parallel_reference_uhal() -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Expose the shipped U-HAUL reference as immutable DEV APPROVED test data."""
    input_path = LEGACY_ROOT / "input.json"
    if not input_path.exists():
        raise ValueError("The packaged U-HAUL reference input.json is missing.")
    data = json.loads(input_path.read_text(encoding="utf-8"))
    if not is_uhal_customer(data.get("customer")) or str(data.get("direction") or "").lower() != "outbound" or str(data.get("tx_code") or "") != "856" or not bool(data.get("requires_data_map")):
        raise ValueError("The packaged U-HAUL reference no longer matches the developer-approved Outbound 856 Translation baseline.")
    validation = _approved_uhal_validation()
    config = {
        "id": _UHAL_PARALLEL_SOURCE_ID,
        "workspace": str(LEGACY_ROOT),
        "name": str(data.get("profile_name") or "U-HAUL Outbound 856 Translation"),
        "customer": str(data.get("customer") or "U-HAUL"),
        "direction": str(data.get("direction") or "Outbound"),
        "transaction_code": str(data.get("tx_code") or "856"),
        "flow_type": "Translation",
        "parallelSourceKind": "reference",
        "approved_reference": True,
        "immutable_reference": True,
        "reference_approval_status": _UHAL_APPROVAL_STATUS,
        "test_ready": True,
    }
    return config, validation


def _managed_flow_reference_configuration(source_id: str) -> Dict[str, Any] | None:
    """Return the persisted editable mirror for a packaged Flow source, if one exists.

    U-HAUL is exposed to the user as one logical customer source. Once the user
    opens it in API Testing / Flow Game, however, edits are intentionally saved
    into a private managed configuration workspace. Execute must use that same
    workspace (and its payload_overrides.json) instead of silently reverting to
    the untouched packaged reference.
    """
    sid = str(source_id or "").strip()
    if not sid:
        return None
    candidates = [
        row for row in STORE.list_configurations()
        if str(row.get("managed_reference_source") or "") == sid
    ]
    # Prefer the newest valid persisted mirror if a prior upgrade left more than
    # one record behind. Normal operation creates only one.
    candidates.sort(key=lambda row: str(row.get("updated_at") or row.get("created_at") or ""), reverse=True)
    for row in candidates:
        workspace = Path(str(row.get("workspace") or ""))
        if (workspace / "input.json").exists():
            return row
    return None


def _copy_flow_reference_snapshot(source: Path, destination: Path) -> None:
    """Copy only execution-relevant reference evidence into an editable Flow workspace."""
    destination.mkdir(parents=True, exist_ok=True)
    for name in _SNAPSHOT_FILES:
        src = source / name
        if src.is_file():
            shutil.copy2(src, destination / name)
    for name in _SNAPSHOT_DIRS:
        src = source / name
        if src.is_dir():
            dst = destination / name
            try:
                # Do not delete/recreate an existing runtime evidence folder.
                # Enterprise Windows protection can deny rmtree even when normal
                # reads/writes are allowed. Merge is sufficient for the immutable
                # packaged reference and avoids the V81 WinError 5 regression.
                shutil.copytree(src, dst, dirs_exist_ok=True)
            except PermissionError:
                # input.json and the approved request/plan files are authoritative
                # for U-HAUL testing. A protected evidence directory must never
                # downgrade the developer-approved reference or block startup.
                continue
    for name in ("uploads", "payloads", "reports"):
        (destination / name).mkdir(parents=True, exist_ok=True)


def _materialize_flow_source(source_id: str) -> Dict[str, Any]:
    """Return a Studio configuration workspace for a selectable Flow source.

    The packaged U-HAUL source is synchronized into one immutable workspace so
    API Testing and Flow Game can use normal configuration endpoints.  Edits are
    intentionally rejected; users create an editable clone instead.
    """
    sid = str(source_id or "").strip()
    if sid != _UHAL_PARALLEL_SOURCE_ID:
        try:
            return _decorate_configuration(STORE.get_configuration(sid), include_input=True)
        except KeyError:
            raise ValueError(f"Unknown Flow Game customer source: {sid}")

    reference, _ = _parallel_reference_uhal()
    source = Path(str(reference.get("workspace") or ""))
    data = json.loads((source / "input.json").read_text(encoding="utf-8"))
    mirror = _managed_flow_reference_configuration(sid)
    if not mirror:
        mirror = STORE.create_configuration({
            "name": "U-HAUL Outbound 856 Translation · Developer Approved",
            "customer": str(data.get("customer") or "U-HAUL"),
            "direction": "Outbound",
            "transaction_code": "856",
            "transaction_name": str(data.get("tx_name") or "ASN"),
            "flow_type": "Translation",
            "source_interface": "SFTP",
            "target_interface": "SFTP",
            "input_mode": "input_files",
            "user_instructions": "Immutable developer-approved U-HAUL test reference. Create from U-HAUL to make customer changes.",
        })
    workspace = Path(str(mirror.get("workspace") or ""))
    _copy_flow_reference_snapshot(source, workspace)
    updated = STORE.update_configuration(mirror["id"], {
        "name": "U-HAUL Outbound 856 Translation · Developer Approved",
        "customer": str(data.get("customer") or "U-HAUL"),
        "direction": "Outbound",
        "transaction_code": "856",
        "transaction_name": str(data.get("tx_name") or "ASN"),
        "flow_type": "Translation",
        "source_interface": "SFTP",
        "target_interface": "SFTP",
        "input_mode": "input_files",
        "user_instructions": "Immutable developer-approved U-HAUL test reference. Create from U-HAUL to make customer changes.",
        **_approved_uhal_patch(mirror),
    })
    return _decorate_configuration(updated, include_input=True)


@app.post("/api/flow/sources/{source_id:path}/materialize")
def materialize_flow_source(source_id: str) -> Dict[str, Any]:
    """Activate a validated customer or the immutable approved U-HAUL Flow workspace."""
    try:
        source, validation, _kind = _resolve_parallel_source(source_id, revalidate=True)
        if not validation.get("ok"):
            requests = validation.get("requests") or {}
            raise ValueError(f"{source.get('customer') or source.get('name')}: validation is BLOCKED ({requests.get('validCount', 0)}/{requests.get('total', 18)} API contracts).")
        return _materialize_flow_source(source_id)
    except Exception as exc:
        raise HTTPException(400, f"Could not load Flow Game customer payload: {type(exc).__name__}: {exc}")


def _parallel_source_details(configuration: Dict[str, Any], validation: Dict[str, Any], *, source_kind: str = "configuration") -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    try:
        data = json.loads((Path(configuration["workspace"]) / "input.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    approved_reference = bool(_is_approved_uhal_reference(configuration) or source_kind == "reference" and is_uhal_customer(data.get("customer") or configuration.get("customer")))
    requests = validation.get("requests") or {}
    total = int(requests.get("total") or 18)
    valid = int(requests.get("validCount") or (total if approved_reference else 0))
    applicable = requests.get("applicableCount")
    required_questions = [] if approved_reference else [q for q in (configuration.get("questions") or []) if not q.get("informational")]
    is_ready = True if approved_reference else (bool(validation.get("ok")) and not required_questions)
    return {
        "sourceId": str(configuration.get("id") or ""),
        "configurationId": str(configuration.get("id") or ""),
        "repairConfigurationId": "" if approved_reference else str(configuration.get("id") or ""),
        "sourceKind": "reference" if approved_reference else source_kind,
        "name": str(configuration.get("name") or data.get("profile_name") or data.get("customer") or "Configuration"),
        "customer": str(data.get("customer") or configuration.get("customer") or configuration.get("name") or "CUSTOMER"),
        "direction": str(data.get("direction") or configuration.get("direction") or ""),
        "transactionCode": str(data.get("tx_code") or configuration.get("transaction_code") or ""),
        "flowType": "Translation" if is_uhal_customer(data.get("customer") or configuration.get("customer")) else ("Translation" if bool(data.get("requires_data_map")) else ("Passthrough" if "requires_data_map" in data else str(configuration.get("flow_type") or ""))),
        "validated": is_ready,
        "validCount": valid,
        "totalContracts": total,
        "applicableCount": applicable,
        "status": _UHAL_APPROVAL_STATUS if approved_reference else ("VALIDATED" if is_ready else ("NEEDS_INPUT" if required_questions else "BLOCKED")),
        "approvalStatus": _UHAL_APPROVAL_STATUS if approved_reference else "",
        "approvedReference": approved_reference,
        "immutableReference": approved_reference,
        "testReady": True if approved_reference else is_ready,
        "runtimeCheckedSeparately": approved_reference,
        "blockerCount": len(required_questions),
        "questions": required_questions,
        "nextAction": ("Developer approved and test-ready. Runtime credentials/connectivity are checked separately at preflight/LIVE time." if approved_reference else (f"Answer {len(required_questions)} required configuration decision(s)." if required_questions else ("Open the issue details and correct the blocked API value(s)." if not validation.get("ok") else "Ready to run."))),
    }


def _resolve_parallel_source(source_id: str, *, revalidate: bool = True) -> tuple[Dict[str, Any], Dict[str, Any], str]:
    sid = str(source_id or "").strip()
    if sid == _UHAL_PARALLEL_SOURCE_ID:
        # Always execute/snapshot the immutable packaged baseline. A user who
        # wants different values must create an editable clone, which has its own
        # configuration id and validation lifecycle.
        config, validation = _parallel_reference_uhal()
        return config, validation, "reference"
    try:
        config = STORE.get_configuration(sid)
    except KeyError:
        raise ValueError(f"Unknown customer configuration: {sid}")
    workspace = Path(config["workspace"])
    if not (workspace / "input.json").exists():
        raise ValueError(f"{config.get('customer') or config.get('name') or sid}: build input.json before parallel execution.")
    blockers = _blocking_configuration_questions(config)
    if blockers:
        raise ValueError(f"{config.get('customer') or config.get('name') or sid}: resolve {len(blockers)} required Build Configuration decision(s) before parallel execution.")
    validation = config.get("validation") or {}
    if revalidate or not validation.get("ok"):
        validation = validate_configuration(workspace)
        STORE.update_configuration(config["id"], {"validation": validation, "status": "VALIDATED" if validation.get("ok") else "VALIDATION_BLOCKED"})
        config = STORE.get_configuration(config["id"])
    return config, validation, "configuration"


def _queue_parallel_source(source_id: str, label: str = "", *, instance_index: int | None = None, instance_count: int | None = None, instance_group_id: str = "") -> Dict[str, Any]:
    config, validation, source_kind = _resolve_parallel_source(source_id, revalidate=True)
    if not validation.get("ok"):
        requests = validation.get("requests") or {}
        raise ValueError(f"{config.get('customer') or config.get('name')}: validation is BLOCKED ({requests.get('validCount', 0)}/{requests.get('total', 18)} API contracts).")
    queued = PARALLEL.queue_configuration(config, validation, label, demo_instance=instance_index, demo_count=instance_count, instance_group_id=instance_group_id)
    if instance_index and instance_count and instance_count > 1:
        queued["label"] = f"{queued.get('customer') or config.get('customer') or 'CUSTOMER'} · {queued.get('flow') or config.get('name') or 'FLOW'} · Instance {instance_index}/{instance_count}"
    queued["sourceId"] = str(source_id)
    queued["sourceKind"] = source_kind
    # Persist source identity in the queue manifest so refreshes retain it.
    manifest_path = PARALLEL.queue_root / str(queued["jobId"]) / "manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["sourceId"] = str(source_id)
        manifest["sourceKind"] = source_kind
        if instance_group_id:
            manifest["instanceGroupId"] = str(instance_group_id)
        if instance_index and instance_count and instance_count > 1:
            manifest["demoInstance"] = int(instance_index)
            manifest["demoInstanceCount"] = int(instance_count)
            manifest["label"] = queued.get("label")
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        queued = manifest
    except Exception:
        pass
    return queued


@app.get("/api/parallel/sources")
def parallel_sources() -> List[Dict[str, Any]]:
    """List selectable customer configurations with approval and validation separated."""
    rows: List[Dict[str, Any]] = []
    try:
        mirror = _materialize_flow_source(_UHAL_PARALLEL_SOURCE_ID)
        reference_row = _parallel_source_details(mirror, _approved_uhal_validation(), source_kind="reference")
        reference_row.update({
            "sourceId": _UHAL_PARALLEL_SOURCE_ID,
            "configurationId": str(mirror.get("id") or ""),
            "repairConfigurationId": "",
            "sourceKind": "reference",
            "persistedEdits": False,
            "approvedReference": True,
            "immutableReference": True,
            "approvalStatus": _UHAL_APPROVAL_STATUS,
            "status": _UHAL_APPROVAL_STATUS,
            "validated": True,
            "testReady": True,
            "validCount": 18,
            "totalContracts": 18,
            "nextAction": "Developer approved and test-ready. Runtime credentials/connectivity are checked separately when you preflight or run LIVE.",
        })
        rows.append(reference_row)
    except Exception as exc:
        rows.append({
            "sourceId": _UHAL_PARALLEL_SOURCE_ID,
            "configurationId": "",
            "repairConfigurationId": "",
            "sourceKind": "reference",
            "name": "U-HAUL Outbound 856 Translation · Developer Approved",
            "customer": "U-HAUL",
            "direction": "Outbound",
            "transactionCode": "856",
            "flowType": "Translation",
            "validated": False,
            "validCount": 18,
            "totalContracts": 18,
            "status": "REFERENCE_LOAD_ERROR",
            "approvalStatus": _UHAL_APPROVAL_STATUS,
            "approvedReference": True,
            "immutableReference": True,
            "testReady": False,
            "blockerCount": 0,
            "questions": [],
            "nextAction": "The approved reference could not be loaded from this installation. Restore the packaged files; do not edit the U-HAUL reference.",
            "error": f"{type(exc).__name__}: {exc}",
        })
    for config in STORE.list_configurations():
        if _is_approved_uhal_reference(config):
            continue
        workspace = Path(str(config.get("workspace") or ""))
        if not (workspace / "input.json").exists():
            continue
        blockers = _blocking_configuration_questions(config)
        validation = config.get("validation") or {}
        detail = _parallel_source_details(config, validation, source_kind="configuration")
        # Hide stale U-HAUL workspaces from old releases. Intentional editable
        # clones created by "Create from U-HAUL" remain visible and use the normal
        # customer validation lifecycle.
        if is_uhal_customer(detail.get("customer")) and not bool(config.get("cloned_from_approved_reference") or config.get("starter_source")):
            continue
        if blockers:
            detail["validated"] = False
            detail["status"] = "NEEDS_INPUT"
        rows.append(detail)
    return sorted(rows, key=lambda row: (0 if row.get("sourceId") == _UHAL_PARALLEL_SOURCE_ID else 1, 0 if row.get("validated") else 1, str(row.get("customer") or "").lower(), str(row.get("name") or "").lower()))


@app.get("/api/parallel/queue")
def parallel_queue() -> List[Dict[str, Any]]:
    return PARALLEL.list_queue()


@app.post("/api/parallel/queue")
def parallel_queue_add(payload: ParallelQueueCreate) -> Dict[str, Any]:
    try:
        return _queue_parallel_source(payload.configuration_id, payload.label)
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/parallel/queue-sources")
def parallel_queue_sources(payload: ParallelSourcesQueueCreate) -> Dict[str, Any]:
    source_ids = [str(value or "").strip() for value in payload.source_ids if str(value or "").strip()]
    if not source_ids:
        raise HTTPException(400, "Select at least one validated customer.")
    if len(source_ids) > 50:
        raise HTTPException(400, "Select at most 50 customer configurations at a time.")
    created: List[Dict[str, Any]] = []
    errors: List[Dict[str, str]] = []
    totals = {source_id: source_ids.count(source_id) for source_id in set(source_ids)}
    seen: Dict[str, int] = {}
    group_ids = {source_id: ("ig" + uuid.uuid4().hex[:10]) for source_id, total in totals.items() if total > 1}
    for source_id in source_ids:
        seen[source_id] = seen.get(source_id, 0) + 1
        try:
            total = totals.get(source_id, 1)
            created.append(_queue_parallel_source(
                source_id,
                instance_index=seen[source_id] if total > 1 else None,
                instance_count=total if total > 1 else None,
                instance_group_id=group_ids.get(source_id, ""),
            ))
        except Exception as exc:
            errors.append({"sourceId": source_id, "error": str(exc)})
    return {"created": len(created), "items": created, "errors": errors}


@app.delete("/api/parallel/queue/{job_id}")
def parallel_queue_delete(job_id: str) -> Dict[str, Any]:
    return {"deleted": PARALLEL.delete_job(job_id), "jobId": job_id}


@app.post("/api/parallel/queue/delete-many")
def parallel_queue_delete_many(payload: ParallelQueueDeleteMany) -> Dict[str, Any]:
    job_ids = [str(value or "").strip() for value in payload.job_ids if str(value or "").strip()]
    if not job_ids:
        return {"deleted": [], "notFound": [], "deletedCount": 0}
    return PARALLEL.delete_jobs(job_ids)


def _create_parallel_demo_instances(payload: UhalDemoCreate) -> Dict[str, Any]:
    try:
        config = STORE.get_configuration(payload.configuration_id)
    except KeyError:
        raise HTTPException(404, "Configuration not found")
    _require_configuration_decisions_resolved(config, "creating parallel execution instances")
    try:
        validation = validate_configuration(Path(config["workspace"]))
        STORE.update_configuration(config["id"], {"validation": validation, "status": "VALIDATED" if validation.get("ok") else "VALIDATION_BLOCKED"})
        config = STORE.get_configuration(config["id"])
    except Exception as exc:
        raise HTTPException(400, f"Could not revalidate the active configuration: {type(exc).__name__}: {exc}")
    if not validation.get("ok"):
        raise HTTPException(400, "The active configuration no longer passes validation. Fix the blockers before creating instances.")
    try:
        rows = PARALLEL.create_demo_instances(config, validation, payload.count)
        return {"created": len(rows), "items": rows}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/parallel/demo-instances")
def parallel_demo_instances(payload: UhalDemoCreate) -> Dict[str, Any]:
    return _create_parallel_demo_instances(payload)


@app.post("/api/parallel/uhal-demo")
def parallel_uhal_demo(payload: UhalDemoCreate) -> Dict[str, Any]:
    # Backward-compatible alias retained for existing callers/bookmarks.
    return _create_parallel_demo_instances(payload)


def _pipeline_path(pipeline_id: str) -> Path:
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(pipeline_id or ""))[:80]
    return PIPELINE_ROOT / f"{safe}.json"


def _read_pipeline(pipeline_id: str) -> Dict[str, Any]:
    path = _pipeline_path(pipeline_id)
    if not path.exists():
        raise HTTPException(404, "Pipeline not found")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(500, f"Pipeline metadata could not be read: {type(exc).__name__}: {exc}")


def _validate_pipeline_source_ids(source_ids: List[str]) -> Dict[str, Any]:
    stages: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for index, source_id in enumerate(source_ids, start=1):
        try:
            config, validation, source_kind = _resolve_parallel_source(source_id, revalidate=True)
            requests = validation.get("requests") or {}
            ok = bool(validation.get("fullLiveReady") if (validation.get("migration") or {}).get("requested") else validation.get("ok"))
            stage = {
                "index": index, "sourceId": source_id, "sourceKind": source_kind,
                "configurationId": config.get("id"),
                "customer": config.get("customer") or config.get("name") or source_id,
                "direction": config.get("direction"), "transactionCode": config.get("transaction_code") or config.get("tx_code"),
                "flowType": config.get("resolved_flow_type") or config.get("flow_type"),
                "ok": ok, "validCount": requests.get("validCount", 18 if ok else 0), "total": requests.get("total", 18),
            }
            stages.append(stage)
            if not ok:
                errors.append({"index": index, "sourceId": source_id, "customer": stage["customer"], "error": "Payload/API contract validation did not pass."})
        except Exception as exc:
            errors.append({"index": index, "sourceId": source_id, "error": f"{type(exc).__name__}: {exc}"})
            stages.append({"index": index, "sourceId": source_id, "ok": False, "validCount": 0, "total": 18})
    return {"ok": bool(source_ids) and not errors, "stageCount": len(source_ids), "stages": stages, "errors": errors, "validatedAt": datetime.now(timezone.utc).isoformat()}


@app.get("/api/pipelines")
def pipelines() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for path in sorted(PIPELINE_ROOT.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            if value:
                rows.append(value)
        except Exception:
            continue
    return rows


@app.post("/api/pipelines")
def pipeline_create(payload: PipelineCreate) -> Dict[str, Any]:
    source_ids = [str(x).strip() for x in payload.source_ids if str(x).strip()]
    if not source_ids:
        raise HTTPException(400, "Add at least one customer payload stage to the pipeline.")
    if len(source_ids) > 20:
        raise HTTPException(400, "A pipeline can contain at most 20 stages.")
    validation = _validate_pipeline_source_ids(source_ids)
    pipeline_id = "pipe_" + uuid.uuid4().hex[:10]
    record = {
        "id": pipeline_id, "name": str(payload.name or "HIP Customer Pipeline").strip() or "HIP Customer Pipeline",
        "sourceIds": source_ids, "status": "READY" if validation.get("ok") else "NEEDS_ATTENTION",
        "validation": validation, "createdAt": datetime.now(timezone.utc).isoformat(), "updatedAt": datetime.now(timezone.utc).isoformat(),
    }
    atomic_write_json(_pipeline_path(pipeline_id), record)
    return record


@app.put("/api/pipelines/{pipeline_id}")
def pipeline_update(pipeline_id: str, payload: PipelineCreate) -> Dict[str, Any]:
    current = _read_pipeline(pipeline_id)
    source_ids = [str(x).strip() for x in payload.source_ids if str(x).strip()]
    if not source_ids:
        raise HTTPException(400, "Add at least one customer payload stage to the pipeline.")
    validation = _validate_pipeline_source_ids(source_ids)
    current.update({
        "name": str(payload.name or current.get("name") or "HIP Customer Pipeline").strip(),
        "sourceIds": source_ids, "status": "READY" if validation.get("ok") else "NEEDS_ATTENTION",
        "validation": validation, "updatedAt": datetime.now(timezone.utc).isoformat(),
    })
    atomic_write_json(_pipeline_path(pipeline_id), current)
    return current


@app.delete("/api/pipelines/{pipeline_id}")
def pipeline_delete(pipeline_id: str) -> Dict[str, Any]:
    path = _pipeline_path(pipeline_id)
    if not path.exists():
        raise HTTPException(404, "Pipeline not found")
    path.unlink()
    return {"deleted": True, "id": pipeline_id}


@app.post("/api/pipelines/{pipeline_id}/validate")
def pipeline_validate(pipeline_id: str) -> Dict[str, Any]:
    record = _read_pipeline(pipeline_id)
    validation = _validate_pipeline_source_ids(list(record.get("sourceIds") or []))
    record["validation"] = validation
    record["status"] = "READY" if validation.get("ok") else "NEEDS_ATTENTION"
    record["updatedAt"] = datetime.now(timezone.utc).isoformat()
    atomic_write_json(_pipeline_path(pipeline_id), record)
    return record


@app.post("/api/pipelines/{pipeline_id}/run")
async def pipeline_run(pipeline_id: str, payload: PipelineRun) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "LIVE pipeline execution confirmation is required.")
    record = _read_pipeline(pipeline_id)
    source_ids = list(record.get("sourceIds") or [])
    validation = _validate_pipeline_source_ids(source_ids)
    record["validation"] = validation
    record["status"] = "READY" if validation.get("ok") else "NEEDS_ATTENTION"
    record["updatedAt"] = datetime.now(timezone.utc).isoformat()
    atomic_write_json(_pipeline_path(pipeline_id), record)
    if not validation.get("ok"):
        raise HTTPException(400, {"message": "Pipeline blocked: every payload must validate before any LIVE API call starts.", "validation": validation})
    # Validate every stage first, then freeze every immutable payload snapshot. Only
    # after all snapshots exist do we start the all-preflight sequential pipeline.
    created: List[Dict[str, Any]] = []
    try:
        for index, source_id in enumerate(source_ids, start=1):
            created.append(_queue_parallel_source(source_id, f"{record.get('name')} · Stage {index}/{len(source_ids)}"))
    except Exception as exc:
        for item in created:
            try:
                PARALLEL.delete_job(str(item.get("jobId") or ""))
            except Exception:
                pass
        raise HTTPException(400, f"Pipeline snapshot creation failed before LIVE execution: {type(exc).__name__}: {exc}")
    loop = asyncio.get_running_loop()
    batch = PARALLEL.start_batch([str(x.get("jobId")) for x in created], 1, loop, batch_kind="PIPELINE", preflight_all=True, stop_on_error=True, pipeline_id=pipeline_id)
    record["lastBatchId"] = batch.get("batchId")
    record["lastRunAt"] = datetime.now(timezone.utc).isoformat()
    atomic_write_json(_pipeline_path(pipeline_id), record)
    return batch


@app.get("/api/parallel/batches")
def parallel_batches() -> List[Dict[str, Any]]:
    return PARALLEL.list_batches()


@app.post("/api/parallel/batches")
async def parallel_batch_start(payload: ParallelBatchStart) -> Dict[str, Any]:
    if not payload.confirm_live:
        raise HTTPException(400, "LIVE execution confirmation is required.")
    loop = asyncio.get_running_loop()
    try:
        return PARALLEL.start_batch(payload.job_ids, payload.workers, loop)
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/parallel/batches/{batch_id}")
def parallel_batch(batch_id: str) -> Dict[str, Any]:
    value = PARALLEL.get_batch(batch_id)
    if not value:
        raise HTTPException(404, "Parallel batch not found")
    return value


@app.post("/api/parallel/batches/{batch_id}/stop")
async def parallel_batch_stop(batch_id: str) -> Dict[str, Any]:
    loop = asyncio.get_running_loop()
    try:
        return PARALLEL.stop_batch(batch_id, loop)
    except ValueError as exc:
        raise HTTPException(404, str(exc))


@app.post("/api/parallel/batches/{batch_id}/jobs/{job_id}/stop")
async def parallel_job_stop(batch_id: str, job_id: str) -> Dict[str, Any]:
    loop = asyncio.get_running_loop()
    try:
        return PARALLEL.stop_job(batch_id, job_id, loop)
    except ValueError as exc:
        raise HTTPException(404, str(exc))


@app.get("/api/parallel/batches/{batch_id}/report")
def parallel_batch_report(batch_id: str) -> Response:
    path = PARALLEL.batch_report_path(batch_id)
    if not path:
        raise HTTPException(404, "Parallel HTML report is not available yet")
    return Response(content=path.read_bytes(), media_type="text/html; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{path.name}"'})


@app.websocket("/ws/parallel/{batch_id}")
async def parallel_ws(websocket: WebSocket, batch_id: str) -> None:
    await websocket.accept()
    queue = await PARALLEL.subscribe(batch_id)
    try:
        while True:
            event = await queue.get()
            await websocket.send_json(event)
            if event.get("type") == "batch.completed":
                break
    except WebSocketDisconnect:
        pass
    finally:
        PARALLEL.unsubscribe(batch_id, queue)


# Phase 6 production mode: when the Bun/Vite frontend has been built, FastAPI can serve
# the compiled React application from the same process/port. API and WebSocket routes
# above retain priority because this mount is registered last.
_FRONTEND_DIST = LEGACY_ROOT / "webapp" / "frontend" / "dist"
_FRONTEND_INDEX = _FRONTEND_DIST / "index.html"
if _FRONTEND_INDEX.is_file():
    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIST), html=True), name="agentic-hip-react")
else:
    @app.get("/", include_in_schema=False, response_class=HTMLResponse)
    def frontend_not_built() -> HTMLResponse:
        return HTMLResponse(
            status_code=200,
            content="""<!doctype html>
<html><head><meta charset="utf-8"><title>HIP API Agent Studio</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;background:#f6f8fb;color:#172033;margin:0;padding:48px}main{max-width:820px;margin:auto;background:white;border:1px solid #dce3ee;border-radius:16px;padding:32px;box-shadow:0 12px 35px rgba(20,35,60,.08)}code,pre{background:#f2f5f9;border-radius:8px;padding:3px 6px}pre{padding:16px;overflow:auto}.ok{color:#087a45;font-weight:700}</style></head>
<body><main><h1>Frontend not built yet</h1>
<p class="ok">HIP API Agent Studio backend is running and FastAPI is healthy on port 8765.</p>
<p>The React frontend has not been built in this extracted folder, so there is no <code>webapp/frontend/dist/index.html</code> to serve yet.</p>
<h2>Production / single-port</h2><pre>cd webapp\\frontend
bun install
bun run build
cd ..\\..
RUN_AGENTIC_HIP.bat</pre>
<h2>Development / hot reload</h2><pre>RUN_AGENTIC_HIP_DEV.bat</pre>
<p>Development mode opens the UI at <code>http://127.0.0.1:5173</code> and keeps the API at <code>http://127.0.0.1:8765</code>.</p>
<p>Backend health: <a href="/api/health">/api/health</a> · System status: <a href="/api/system/status">/api/system/status</a></p>
</main></body></html>""",
        )
