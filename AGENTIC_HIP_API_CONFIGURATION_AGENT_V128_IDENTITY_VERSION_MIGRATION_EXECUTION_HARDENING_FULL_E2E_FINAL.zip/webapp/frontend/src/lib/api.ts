import type { Bootstrap, Configuration, FlowTemplate, MappingLearning, Evidence, ParallelJob, ParallelSource, ParallelBatch, PipelineDefinition, LearnRecord, ReportRecord, FlowPreflight, ExecutionRecord, ExecutionComparison, AuditEvent, AuditVerification, BundleInspection, SystemStatus, ConnectionReadiness, ApiTestResult, IntelligentMapperResult, ExecutionFlowSummary, ExecutionFlowStep } from '../types';

function actor(){try{return localStorage.getItem('hip.operator')||'User'}catch{return 'User'}}
let activeRequests=0;
function activity(delta:number,url:string){
  activeRequests=Math.max(0,activeRequests+delta);
  if(typeof window!=='undefined')window.dispatchEvent(new CustomEvent('hip:api-activity',{detail:{count:activeRequests,url,active:activeRequests>0}}));
}
async function request<T>(url:string, init?:RequestInit):Promise<T>{
  const headers=new Headers(init?.headers||{});headers.set('X-HIP-Actor',actor());activity(1,url);
  try{
    const response=await fetch(url,{...init,headers});
    if(!response.ok){
      const text=await response.text();
      let detail=text;
      try{const parsed=JSON.parse(text);const raw=parsed?.detail||parsed?.message||text;detail=typeof raw==='string'?raw:String(raw?.message||JSON.stringify(raw))}catch{}
      throw new Error(detail||`${response.status} ${response.statusText}`);
    }
    return await response.json() as T;
  }finally{activity(-1,url)}
}
async function download(url:string,filename:string){const headers=new Headers();headers.set('X-HIP-Actor',actor());activity(1,url);try{const r=await fetch(url,{headers});if(!r.ok){const text=await r.text();let detail=text;try{const parsed=JSON.parse(text);const raw=parsed?.detail||parsed?.message||text;detail=typeof raw==='string'?raw:String(raw?.message||JSON.stringify(raw))}catch{}throw new Error(detail)}const blob=await r.blob();const href=URL.createObjectURL(blob);const a=document.createElement('a');a.href=href;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(href)}finally{activity(-1,url)}}
export const api={
  bootstrap:()=>request<Bootstrap>('/api/bootstrap'), configurations:()=>request<Configuration[]>('/api/configurations'),
  createConfiguration:(body:Partial<Configuration>)=>request<Configuration>('/api/configurations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  patchConfiguration:(id:string,body:Partial<Configuration>)=>request<Configuration>(`/api/configurations/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  deleteConfiguration:(id:string)=>request<any>(`/api/configurations/${id}`,{method:'DELETE'}),
  cloneConfiguration:(id:string,name='')=>request<Configuration>(`/api/configurations/${id}/clone`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}),
  exportConfiguration:(id:string,name:string)=>download(`/api/configurations/${id}/bundle`,`${name.replace(/[^a-z0-9_-]+/gi,'_')||'hip_configuration'}.zip`),
  inspectBundle:async(file:File)=>{const form=new FormData();form.append('bundle',file);return request<BundleInspection>('/api/configuration-bundles/inspect',{method:'POST',body:form})},
  importBundle:async(file:File)=>{const form=new FormData();form.append('bundle',file);return request<Configuration>('/api/configuration-bundles/import',{method:'POST',body:form})},
  getConfiguration:(id:string)=>request<Configuration>(`/api/configurations/${id}`),
  uploadFiles:async(id:string,files:File[])=>{const form=new FormData();files.forEach(f=>form.append('files',f));return request<Configuration>(`/api/configurations/${id}/files`,{method:'POST',body:form})},
  buildConfiguration:(id:string)=>request<any>(`/api/configurations/${id}/build`,{method:'POST'}),
  answerQuestions:(id:string,answers:Record<string,unknown>)=>request<any>(`/api/configurations/${id}/answers`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({answers})}),
  validateConfiguration:(id:string)=>request<any>(`/api/configurations/${id}/validate`,{method:'POST'}),
  applyValidationFixes:(id:string,fixes:{step_key:string;field:string;value:unknown}[])=>request<any>(`/api/configurations/${id}/validation-fixes`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({fixes})}),
  evidence:(id:string)=>request<Evidence>(`/api/configurations/${id}/evidence`),
  intakeReport:(id:string)=>request<any>(`/api/configurations/${id}/intake-report`),
  extractionBlueprint:(id:string)=>request<any>(`/api/configurations/${id}/extraction-blueprint`),
  downloadExtractionBlueprint:(id:string)=>download(`/api/configurations/${id}/extraction-blueprint/download`,'input_extraction_blueprint_execution_latest.json'),
  downloadIntakeReport:(id:string)=>download(`/api/configurations/${id}/intake-report/download`,'HIP_customer_intake_requirements_latest.html'),
  mappingLearning:()=>request<MappingLearning>('/api/mapping-learning'),
  teachMapping:(id:string)=>request<MappingLearning>(`/api/configurations/${id}/mapping-learning/teach`,{method:'POST'}),
  apiRequests:(id:string)=>request<any>(`/api/configurations/${id}/api-requests`),
  analyzeWorkbook:async(id:string,file:File,apiKey='AUTO',sheetName='',headerRow=0,useDellAia=true)=>{const form=new FormData();form.append('workbook',file);form.append('api_key',apiKey);form.append('sheet_name',sheetName);form.append('header_row',String(Math.max(0,headerRow||0)));form.append('use_dell_aia',String(useDellAia));return request<IntelligentMapperResult>(`/api/configurations/${id}/intelligent-mapper/analyze`,{method:'POST',body:form})},
  templates:()=>request<FlowTemplate[]>('/api/templates'),
  saveTemplate:(body:Omit<FlowTemplate,'id'|'version'|'builtin'>)=>request<FlowTemplate>('/api/templates',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  templateVersions:(id:string)=>request<FlowTemplate[]>(`/api/templates/${id}/versions`),
  cloneTemplate:(id:string,name='')=>request<FlowTemplate>(`/api/templates/${id}/clone`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}),
  publishTemplate:(id:string)=>request<FlowTemplate>(`/api/templates/${id}/publish`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({note:''})}),
  archiveTemplate:(id:string)=>request<FlowTemplate>(`/api/templates/${id}/archive`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({note:''})}),
  startExecution:(configurationId:string,flow:unknown,resumeExecutionId='')=>request<any>('/api/executions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({configuration_id:configurationId,flow,confirm_live:true,resume_execution_id:resumeExecutionId})}),
  preflightFlow:(configurationId:string,flow:unknown)=>request<FlowPreflight>(`/api/configurations/${configurationId}/flow/preflight`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(flow)}),
  autofixFlow:(configurationId:string,flow:unknown)=>request<any>(`/api/configurations/${configurationId}/flow/autofix`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(flow)}),
  preflightFlowNode:(configurationId:string,nodeId:string,flow:unknown)=>request<ApiTestResult>(`/api/configurations/${configurationId}/flow/nodes/${encodeURIComponent(nodeId)}/preflight`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({flow,confirm_live:false})}),
  executeFlowNode:(configurationId:string,nodeId:string,flow:unknown)=>request<ApiTestResult>(`/api/configurations/${configurationId}/flow/nodes/${encodeURIComponent(nodeId)}/execute`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({flow,confirm_live:true})}),
  executions:(configurationId='')=>request<ExecutionRecord[]>(`/api/executions${configurationId?`?configuration_id=${encodeURIComponent(configurationId)}`:''}`),
  execution:(id:string)=>request<ExecutionRecord>(`/api/executions/${id}`),
  exportExecutionEvidence:(id:string)=>download(`/api/executions/${id}/evidence-bundle`,`agentic_hip_execution_${id}_evidence.zip`),
  cancelExecution:(id:string)=>request<ExecutionRecord>(`/api/executions/${id}/cancel`,{method:'POST'}),
  approveNode:(executionId:string,nodeId:string,note='')=>request<any>(`/api/executions/${executionId}/nodes/${encodeURIComponent(nodeId)}/approve`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({approved_by:actor(),note})}),
  resumeExecution:(id:string)=>request<ExecutionRecord>(`/api/executions/${id}/resume`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm_live:true})}),
  compareExecutions:(left:string,right:string)=>request<ExecutionComparison>(`/api/executions/compare/${left}/${right}`),
  parallelSources:()=>request<ParallelSource[]>('/api/parallel/sources'),
  materializeFlowSource:(sourceId:string)=>request<Configuration>(`/api/flow/sources/${encodeURIComponent(sourceId)}/materialize`,{method:'POST'}),
  parallelQueue:()=>request<ParallelJob[]>('/api/parallel/queue'),
  queueParallel:(configurationId:string,label='')=>request<ParallelJob>('/api/parallel/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({configuration_id:configurationId,label})}),
  queueParallelSources:(sourceIds:string[])=>request<{created:number;items:ParallelJob[];errors:{sourceId:string;error:string}[]}>('/api/parallel/queue-sources',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source_ids:sourceIds})}),
  deleteParallel:(jobId:string)=>request<any>(`/api/parallel/queue/${jobId}`,{method:'DELETE'}),
  deleteParallelMany:(jobIds:string[])=>request<any>('/api/parallel/queue/delete-many',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:jobIds})}),
  createParallelInstances:(configurationId:string,count:number)=>request<any>('/api/parallel/demo-instances',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({configuration_id:configurationId,count})}),
  parallelBatches:()=>request<ParallelBatch[]>('/api/parallel/batches'),
  startParallel:(jobIds:string[],workers:number)=>request<ParallelBatch>('/api/parallel/batches',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:jobIds,workers:Math.max(1,Math.min(4,workers)),confirm_live:true})}),
  parallelBatch:(batchId:string)=>request<ParallelBatch>(`/api/parallel/batches/${batchId}`),
  stopParallelBatch:(batchId:string)=>request<ParallelBatch>(`/api/parallel/batches/${batchId}/stop`,{method:'POST'}),
  stopParallelJob:(batchId:string,jobId:string)=>request<ParallelBatch>(`/api/parallel/batches/${batchId}/jobs/${jobId}/stop`,{method:'POST'}),
  downloadParallelReport:(batchId:string)=>download(`/api/parallel/batches/${batchId}/report`,`HIP_parallel_final_report_${batchId}.html`),
  pipelines:()=>request<PipelineDefinition[]>('/api/pipelines'),
  createPipeline:(name:string,sourceIds:string[])=>request<PipelineDefinition>('/api/pipelines',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,source_ids:sourceIds})}),
  updatePipeline:(id:string,name:string,sourceIds:string[])=>request<PipelineDefinition>(`/api/pipelines/${id}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,source_ids:sourceIds})}),
  deletePipeline:(id:string)=>request<any>(`/api/pipelines/${id}`,{method:'DELETE'}),
  validatePipeline:(id:string)=>request<PipelineDefinition>(`/api/pipelines/${id}/validate`,{method:'POST'}),
  runPipeline:(id:string)=>request<ParallelBatch>(`/api/pipelines/${id}/run`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm_live:true})}),
  learnRecords:(id:string)=>request<LearnRecord[]>(`/api/configurations/${id}/learn/records`),
  learnFiles:async(id:string,files:File[],question:string)=>{const form=new FormData();files.forEach(f=>form.append('files',f));const qs=question?`?question=${encodeURIComponent(question)}`:'';return request<any>(`/api/configurations/${id}/learn/files${qs}`,{method:'POST',body:form})},
  askLearn:(id:string,question:string)=>request<any>(`/api/configurations/${id}/learn/ask`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question})}),
  reports:(id:string)=>request<ReportRecord[]>(`/api/configurations/${id}/reports`),
  report:(id:string,name:string)=>request<any>(`/api/configurations/${id}/reports/${encodeURIComponent(name)}`),
  downloadReport:(id:string,name:string)=>download(`/api/configurations/${id}/reports/${encodeURIComponent(name)}/download`,name),
  audit:(entityType='',entityId='',limit=200)=>request<AuditEvent[]>(`/api/audit?entity_type=${encodeURIComponent(entityType)}&entity_id=${encodeURIComponent(entityId)}&limit=${limit}`),
  verifyAudit:()=>request<AuditVerification>('/api/audit/verify'),
  systemStatus:()=>request<SystemStatus>('/api/system/status'),
  readiness:(id:string)=>request<ConnectionReadiness>(`/api/configurations/${id}/readiness`),
  apiTestPreflight:(id:string,stepKey:string,requestOverride:Record<string,unknown>,overrideMode:'merge'|'replace'='merge')=>request<ApiTestResult>(`/api/configurations/${id}/api-tests/${encodeURIComponent(stepKey)}/preflight`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_override:requestOverride,override_mode:overrideMode,confirm_live:false})}),
  apiTestExecute:(id:string,stepKey:string,requestOverride:Record<string,unknown>,overrideMode:'merge'|'replace'='merge')=>request<ApiTestResult>(`/api/configurations/${id}/api-tests/${encodeURIComponent(stepKey)}/execute`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_override:requestOverride,override_mode:overrideMode,confirm_live:true})}),
  executionFlow:(id:string)=>request<ExecutionFlowSummary>(`/api/configurations/${id}/execution-flow`),
  saveExecutionFlow:(id:string,migrationEnabled:boolean,steps:ExecutionFlowStep[])=>request<ExecutionFlowSummary>(`/api/configurations/${id}/execution-flow`,{method:'PUT',headers:{'Content-Type':'application/json','X-HIP-User-Action':'execution-flow-edit-v1','X-HIP-Actor':'Human User'},body:JSON.stringify({migrationEnabled,steps:steps.map(({stepKey,order,waitAfterSeconds})=>({stepKey,order,waitAfterSeconds}))})}),
  resetExecutionFlow:(id:string)=>request<ExecutionFlowSummary>(`/api/configurations/${id}/execution-flow/reset`,{method:'POST',headers:{'X-HIP-User-Action':'execution-flow-edit-v1','X-HIP-Actor':'Human User'}}),
  savePayloadOverride:(id:string,stepKey:string,value:Record<string,unknown>,requestKind:'payload'|'params'='payload',mode:'merge'|'replace'|'paths'='paths')=>request<any>(`/api/configurations/${id}/payload-overrides/${encodeURIComponent(stepKey)}`,{method:'PUT',headers:{'Content-Type':'application/json','X-HIP-User-Action':'payload-value-edit-v1','X-HIP-Actor':'Human User'},body:JSON.stringify({value,request_kind:requestKind,mode,note:'Human user-edited existing API value (value-only editor)'})}),
  clearPayloadOverride:(id:string,stepKey:string)=>request<any>(`/api/configurations/${id}/payload-overrides/${encodeURIComponent(stepKey)}`,{method:'DELETE',headers:{'X-HIP-User-Action':'payload-value-edit-v1','X-HIP-Actor':'Human User'}}),
};
