from .safe_io import install_safe_path_io

install_safe_path_io()

__version__ = "2.2.2"
