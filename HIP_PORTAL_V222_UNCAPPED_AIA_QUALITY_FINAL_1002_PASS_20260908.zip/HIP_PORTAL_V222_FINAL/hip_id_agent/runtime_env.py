from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List

from dotenv import load_dotenv


def _candidate_env_files(root: str | Path | None = None) -> List[Path]:
    """Return deterministic .env candidates, preserving explicit operator override first."""
    candidates: List[Path] = []
    explicit = str(os.getenv("HIP_ENV_FILE") or "").strip()
    if explicit:
        candidates.append(Path(explicit).expanduser())

    if root is not None:
        candidates.append(Path(root).expanduser() / ".env")

    candidates.append(Path.cwd() / ".env")

    # The package root is a stable fallback for direct Python/uvicorn launches.
    package_root = Path(__file__).resolve().parents[1]
    candidates.append(package_root / ".env")

    deduped: List[Path] = []
    seen: set[str] = set()
    for item in candidates:
        try:
            key = str(item.resolve())
        except Exception:
            key = str(item)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def load_runtime_env(root: str | Path | None = None, *, override: bool = False) -> Dict[str, Any]:
    """Load the HIP runtime .env deterministically.

    Order:
      1. HIP_ENV_FILE (explicit external file)
      2. <root>/.env when a root is supplied
      3. current-working-directory/.env
      4. package-root/.env

    Existing process environment wins by default. This is important when the
    operator intentionally injects credentials through PowerShell/CI instead of
    a file.
    """
    loaded: List[str] = []
    checked: List[str] = []
    for path in _candidate_env_files(root):
        checked.append(str(path))
        try:
            if path.is_file():
                load_dotenv(dotenv_path=path, override=override)
                loaded.append(str(path))
        except Exception:
            # Environment loading must never crash the application. The normal
            # model/readiness checks will report missing values precisely.
            continue
    return {
        "loaded": bool(loaded),
        "loaded_files": loaded,
        "checked_files": checked,
        "explicit_env_file": str(os.getenv("HIP_ENV_FILE") or "").strip(),
    }
