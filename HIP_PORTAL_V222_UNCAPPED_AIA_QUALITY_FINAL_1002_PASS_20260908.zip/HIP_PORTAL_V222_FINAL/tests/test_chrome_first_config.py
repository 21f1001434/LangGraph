from pathlib import Path

import yaml

from hip_id_agent.config import load_config, AppConfig
from hip_id_agent.browser_session import BrowserSession


def test_config_example_uses_installed_microsoft_edge_by_default():
    raw = yaml.safe_load(Path("config.example.yaml").read_text(encoding="utf-8"))
    assert raw["portal"]["chromium_channel"] == "msedge"
    assert "edge_executable_path" in raw["portal"]


def test_bundled_config_yaml_exists_and_uses_edge():
    assert Path("config.yaml").exists()
    cfg = load_config("config.yaml")
    assert cfg.portal.chromium_channel == "msedge"
    assert cfg.portal.edge_executable_path is None


def test_portal_config_default_is_edge():
    cfg = AppConfig()
    assert cfg.portal.chromium_channel == "msedge"


def test_browser_launch_kwargs_use_explicit_edge_executable_path(tmp_path):
    cfg = AppConfig()
    cfg.portal.browser_user_data_dir = str(tmp_path / "profile")
    cfg.portal.edge_executable_path = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
    cfg.portal.chromium_channel = "msedge"
    session = BrowserSession(cfg, tmp_path / "run")

    # Verify the config supports explicit corporate Edge path and does not require bundled Chromium.
    assert session.config.portal.edge_executable_path.endswith("msedge.exe")
    assert session.config.portal.chromium_channel == "msedge"


def test_shipped_configs_are_portable_and_aligned():
    for name in ("config.yaml", "config.example.yaml", "config.mcp-required.windows.yaml"):
        raw = yaml.safe_load(Path(name).read_text(encoding="utf-8"))
        assert raw["reporting"]["runs_dir"] == "./runs"
        assert raw["mcp"]["playwright_mcp_command"] == "auto"
        assert raw["mcp"]["chrome_devtools_command"] == "auto"
        assert "portal_learning" in raw
        assert "runtime_self_heal" in raw
    strict = yaml.safe_load(Path("config.mcp-required.windows.yaml").read_text(encoding="utf-8"))
    assert strict["mcp"]["use_playwright_mcp"] is True
    assert strict["mcp"]["use_chrome_devtools_mcp"] is True
    assert strict["mcp"]["use_hip_intelligence_mcp"] is True
    assert strict["mcp"]["hip_intelligence_mcp_required"] is True
