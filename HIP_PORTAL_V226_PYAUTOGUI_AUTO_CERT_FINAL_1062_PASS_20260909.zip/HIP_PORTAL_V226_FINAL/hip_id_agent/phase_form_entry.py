from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional

from .safe_io import safe_write_json
from .security import mask_sensitive_data, mask_sensitive_string


AsyncLocatorFinder = Callable[[Any], Awaitable[Any]]
AsyncBoolProbe = Callable[[Any], Awaitable[bool]]
AsyncAddClicker = Callable[[Any, int], Awaitable[bool]]
AsyncAfterAdd = Callable[[Any], Awaitable[Dict[str, Any]]]


async def _safe_bool(probe: Optional[AsyncBoolProbe], page: Any) -> bool:
    if probe is None:
        return False
    try:
        return bool(await probe(page))
    except Exception:
        return False


async def _dom_generation(page: Any) -> int:
    try:
        return int(await page.evaluate("Number(window.__HIP_DOM_GENERATION || window.__HIP_DOM_EVENT_SEQ || 0)"))
    except Exception:
        return 0


async def _mcp_find_evidence(browser: Any, terms: List[str]) -> List[Dict[str, Any]]:
    """Collect browser_find evidence without using it as an executor.

    The physical action still goes through BrowserSession.click_and_wait, which
    performs semantic fusion, AutoWebGLM approval, AgentQ/MCP safety and effect
    verification. browser_find is used here as a ReAct observation so the loop
    can shrink the candidate space after a failed DOM lookup.
    """
    backend = getattr(browser, "playwright_mcp_backend", None)
    rows: List[Dict[str, Any]] = []
    if backend is None:
        return rows
    for term in terms:
        try:
            result = await backend.find(text=term)
            rows.append({
                "term": term,
                "ok": True,
                "text": str((result or {}).get("text") or "")[:3500],
                "fallback": bool((result or {}).get("fallback")),
            })
        except Exception as exc:
            rows.append({"term": term, "ok": False, "error": mask_sensitive_string(str(exc))[:1000]})
    return rows


async def _recovery_intelligence(browser: Any, *, phase: str, task: str, label: str = "+ Add") -> Dict[str, Any]:
    """Read-only multi-modal ReAct observation for a failed form-entry step.

    AutoWebGLM/Browser-Use/LangChain/Gemma are allowed to inspect and propose,
    but the deterministic expected intent remains authoritative.  No proposed
    selector/action is executed directly from this payload.
    """
    fn = getattr(browser, "browser_intelligence_recovery_context", None)
    if not callable(fn):
        return {"available": False, "reason": "browser intelligence recovery context unavailable"}
    try:
        result = await fn(
            task=task, include_autowebglm_proposal=True,
            expected_intent={
                "action": "click", "label": label, "phase": phase,
                "mutation_risk": False, "structural_opener": True,
                "goal": "open the active HIP create form and verify the new surface",
            },
        )
        return mask_sensitive_data(result if isinstance(result, dict) else {"result": result})
    except Exception as exc:
        return {"available": False, "error": mask_sensitive_string(str(exc))[:1200]}


async def _react_route_back(browser: Any, listing_url: str, *, phase: str) -> Dict[str, Any]:
    if not listing_url:
        return {"pass": False, "status": "no_listing_url"}
    try:
        fn = getattr(browser, "_react_ensure_target_surface", None)
        if callable(fn):
            result = await fn(listing_url, max_steps=3)
            return mask_sensitive_data(result if isinstance(result, dict) else {"pass": bool(result)})
    except Exception as exc:
        return {"pass": False, "status": "react_route_failed", "error": mask_sensitive_string(str(exc))[:1200]}
    try:
        await browser.navigate(listing_url)
        return {"pass": True, "status": "navigate_fallback"}
    except Exception as exc:
        return {"pass": False, "status": "navigate_failed", "error": mask_sensitive_string(str(exc))[:1200]}


async def ensure_phase_form_entry(
    *,
    page: Any,
    browser: Any,
    phase: str,
    listing_url: str,
    find_add: AsyncLocatorFinder,
    is_form_open: AsyncBoolProbe,
    evidence_dir: Optional[Path] = None,
    click_add: Optional[AsyncAddClicker] = None,
    after_add: Optional[AsyncAfterAdd] = None,
    is_intermediate_surface: Optional[AsyncBoolProbe] = None,
    max_steps: int = 4,
    settle_ms: int = 900,
) -> Dict[str, Any]:
    """Bounded ReAct controller for opening the correct HIP create form.

    Standard HIP phases use:
      listing -> top-right + Add -> active create form

    BizFlow uses:
      listing -> top-right + Add -> template/card surface -> card link/action -> multi-tab form

    The loop is intentionally deterministic and safe.  It *observes* through the
    accessibility snapshot/browser_find plus DOM state, *plans* one structural
    action, dispatches through the normal BrowserSession semantic executor, then
    proves the expected surface before proceeding.  A failure is raised instead
    of silently returning an empty form, so the mission-level ReAct self-healer
    can reopen the phase and retry autonomously.
    """
    phase_n = str(phase or "").strip().lower()
    audit: Dict[str, Any] = {
        "schema_version": "hip.phase-form-entry-react.v1",
        "phase": phase_n,
        "listing_url": str(listing_url or ""),
        "max_steps": max(1, int(max_steps)),
        "steps": [],
        "pass": False,
        "status": "starting",
    }

    async def persist() -> None:
        if evidence_dir is None:
            return
        try:
            Path(evidence_dir).mkdir(parents=True, exist_ok=True)
            safe_write_json(Path(evidence_dir) / "phase_form_entry_react.json", mask_sensitive_data(audit))
        except Exception:
            pass

    if await _safe_bool(is_form_open, page):
        audit.update({"pass": True, "status": "form_already_open", "attempts": 0})
        await persist()
        return audit

    for step_no in range(1, max(1, int(max_steps)) + 1):
        before_url = str(getattr(page, "url", "") or "")
        before_gen = await _dom_generation(page)
        form_before = await _safe_bool(is_form_open, page)
        intermediate_before = await _safe_bool(is_intermediate_surface, page)
        mcp_terms = ["+ Add", "Add"]
        if phase_n in {"biz_flow", "bizflow"}:
            mcp_terms.extend(["Create Biz Flow", "Flow Template"])
        mcp_find = await _mcp_find_evidence(browser, mcp_terms)
        step: Dict[str, Any] = {
            "step": step_no,
            "observe": {
                "url": before_url,
                "dom_generation": before_gen,
                "form_open": form_before,
                "intermediate_surface": intermediate_before,
                "browser_find": mcp_find,
            },
            "plan": "",
            "action": {},
            "effect": {},
        }
        audit["steps"].append(step)

        if form_before:
            audit.update({"pass": True, "status": "form_open", "attempts": step_no - 1})
            await persist()
            return audit

        # BizFlow may already be sitting on the template picker after a prior
        # partial attempt.  Continue from that state instead of clicking + Add a
        # second time.
        if intermediate_before and after_add is not None:
            step["plan"] = "launch_intermediate_form"
            try:
                launch = await after_add(page)
                step["action"] = {"kind": "after_add", "result": mask_sensitive_data(launch)}
            except Exception as exc:
                step["action"] = {"kind": "after_add", "error": mask_sensitive_string(str(exc))[:1200]}
            await page.wait_for_timeout(settle_ms)
            form_after = await _safe_bool(is_form_open, page)
            step["effect"] = {
                "form_open": form_after,
                "intermediate_surface": await _safe_bool(is_intermediate_surface, page),
                "dom_generation": await _dom_generation(page),
            }
            await persist()
            if form_after:
                audit.update({"pass": True, "status": "form_open_after_intermediate_launch", "attempts": step_no})
                await persist()
                return audit
            # A stale template surface gets one route reset before the next loop.
            step["recovery"] = await _react_route_back(browser, listing_url, phase=phase_n)
            await page.wait_for_timeout(settle_ms)
            continue

        # Standard state: locate the page-level + Add structural opener.
        add = None
        try:
            add = await find_add(page)
        except Exception as exc:
            step["find_add_error"] = mask_sensitive_string(str(exc))[:1200]

        if add is None:
            step["plan"] = "reobserve_and_route_listing"
            step["action"] = {"kind": "add_not_found"}
            step["recovery_intelligence"] = await _recovery_intelligence(
                browser, phase=phase_n,
                task=f"HIP {phase_n}: the page-level + Add structural opener was not found. Re-observe the current page and explain where the top-right Add control or correct listing surface is, without clicking anything.",
            )
            step["recovery"] = await _react_route_back(browser, listing_url, phase=phase_n)
            await page.wait_for_timeout(settle_ms)
            step["effect"] = {
                "url": str(getattr(page, "url", "") or ""),
                "form_open": await _safe_bool(is_form_open, page),
                "intermediate_surface": await _safe_bool(is_intermediate_surface, page),
                "dom_generation": await _dom_generation(page),
            }
            await persist()
            continue

        step["plan"] = "click_page_add_structural_opener"
        clicked = False
        try:
            if click_add is not None:
                clicked = bool(await click_add(add, step_no))
            else:
                await browser.click_and_wait(
                    action=f"structural_opener phase_entry {phase_n} + Add",
                    locator=add,
                    selector=f"+ Add {phase_n}",
                    mutation_risk=False,
                )
                clicked = True
            step["action"] = {"kind": "click_add", "clicked": clicked}
        except Exception as exc:
            step["action"] = {
                "kind": "click_add",
                "clicked": False,
                "error": mask_sensitive_string(str(exc))[:1800],
            }
        await page.wait_for_timeout(settle_ms)

        form_after_add = await _safe_bool(is_form_open, page)
        intermediate_after_add = await _safe_bool(is_intermediate_surface, page)
        after_gen = await _dom_generation(page)
        step["effect"] = {
            "form_open": form_after_add,
            "intermediate_surface": intermediate_after_add,
            "dom_generation": after_gen,
            "dom_generation_changed": bool(after_gen != before_gen),
            "url": str(getattr(page, "url", "") or ""),
        }
        await persist()

        if form_after_add:
            audit.update({"pass": True, "status": "form_open_after_add", "attempts": step_no})
            await persist()
            return audit

        if intermediate_after_add and after_add is not None:
            step["plan"] = "click_add_then_launch_intermediate_form"
            try:
                launch = await after_add(page)
                step["after_add"] = mask_sensitive_data(launch)
            except Exception as exc:
                step["after_add"] = {"error": mask_sensitive_string(str(exc))[:1800]}
            await page.wait_for_timeout(max(settle_ms, 1200))
            final_form = await _safe_bool(is_form_open, page)
            step["effect_after_intermediate"] = {
                "form_open": final_form,
                "intermediate_surface": await _safe_bool(is_intermediate_surface, page),
                "dom_generation": await _dom_generation(page),
            }
            await persist()
            if final_form:
                audit.update({"pass": True, "status": "form_open_after_add_and_intermediate", "attempts": step_no})
                await persist()
                return audit

        # No verified effect: ask the existing multimodal browser-intelligence
        # stack to re-observe the failure, but keep the deterministic expected
        # intent fixed. Then return to the canonical listing and retry.
        step["recovery_intelligence"] = await _recovery_intelligence(
            browser, phase=phase_n,
            task=(
                f"HIP {phase_n}: + Add was attempted but the expected create form did not open. "
                "Inspect DOM/accessibility/vision evidence and identify whether a drawer, template picker, overlay, wrong Add control, or route drift explains the missing effect. Do not execute a portal action."
            ),
        )
        step["recovery"] = await _react_route_back(browser, listing_url, phase=phase_n)
        await page.wait_for_timeout(settle_ms)
        await persist()

    audit.update({
        "pass": False,
        "status": "blocked",
        "error_code": "HIP_FORM_ENTRY_NOT_OPENED",
        "reason": "active create form surface lost after bounded ReAct +Add/form-launch recovery",
    })
    await persist()
    raise RuntimeError(
        "HIP_FORM_ENTRY_NOT_OPENED: active form surface lost; bounded ReAct opener could not complete "
        f"listing -> + Add -> form for phase={phase_n}. "
        "This is recoverable by the mission self-heal loop and must not be downgraded to an empty-form warning."
    )
