from __future__ import annotations

import asyncio
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from playwright.async_api import Locator, Page

from .security import mask_sensitive_string
from .semantic_affordance import selector_looks_generation_volatile

_PHASE_KEYWORDS = {
    "data_map": ["Create Map", "Map Identifier", "Map Data", "Input Schema Validation", "Output Schema Validation"],
    "source_document_type": ["Document Type Name", "Root Element", "Validation Type", "Attributes"],
    "target_document_type": ["Document Type Name", "Root Element", "Validation Type", "Attributes"],
    "rule": ["Create Rule", "Rule Name", "Conditions", "Actions"],
    "source_transport_profile": ["Create Transport Profile", "System Type", "Profile Usage", "Interface Type", "Existing Account", "Document Type Supported"],
    "target_transport_profile": ["Create Transport Profile", "System Type", "Profile Usage", "Interface Type", "Existing Account", "Document Type Supported"],
    "transport_profile": ["Create Transport Profile", "System Type", "Profile Usage", "Interface Type", "Existing Account", "Document Type Supported"],
    "biz_flow": ["Create Biz Flow", "Flow Details", "Configure Source", "Configure Target", "Configure Routing"],
}

_ROOT_JS = r"""
({phase, keywords}) => {
  function visible(el){
    if(!el || !el.getBoundingClientRect) return false;
    const r=el.getBoundingClientRect(); const s=getComputedStyle(el);
    return !!(r.width && r.height && s.display!=='none' && s.visibility!=='hidden' && Number(s.opacity||'1')!==0);
  }
  function cssPath(el){
    if(!el || !el.tagName) return 'body';
    if(el === document.body) return 'body';
    const parts=[]; let node=el;
    while(node && node.nodeType===1 && parts.length<8){
      let part=node.tagName.toLowerCase();
      if(node.id){ part += '#'+CSS.escape(node.id); parts.unshift(part); break; }
      const cls=(node.className||'').toString().trim().split(/\s+/).filter(Boolean).slice(0,3).map(c=>'.'+CSS.escape(c)).join('');
      part += cls;
      const parent=node.parentElement;
      if(parent){
        const same=Array.from(parent.children).filter(x=>x.tagName===node.tagName);
        if(same.length>1) part += `:nth-of-type(${same.indexOf(node)+1})`;
      }
      parts.unshift(part); node=parent;
    }
    return parts.join(' > ') || 'body';
  }
  const lowerPhase=(phase||'').toLowerCase();
  const roots=Array.from(document.querySelectorAll('[role="dialog"], dds-drawer, .dds__drawer, .dds__modal, .modal-dialog, form, app-create-biz-flow, app-bizflow, app-transport-profile, app-transport_profiles, app-data-map, app-datamap, main, body')).filter(visible);
  const kws=(keywords||[]).map(x=>String(x||'').toLowerCase());
  const rows=roots.map(el=>{
    const txt=(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();
    const low=txt.toLowerCase();
    let score=0;
    for(const kw of kws){ if(kw && low.includes(kw)) score += 5; }
    const controls=Array.from(el.querySelectorAll('input:not([type=hidden]), textarea, select, [role=combobox], input[type=file]')).filter(visible).length;
    score += Math.min(controls, 10);
    if(/create map|create transport profile|create biz flow|create rule/i.test(txt)) score += 20;
    if(lowerPhase.includes('biz') && /b2b-flow-pubsub-template/i.test(txt) && !/flow details|configure source|configure target|configure routing/i.test(txt)) score -= 40;
    if(/items per page|filter by column|table search/i.test(txt) && !/create map|create transport profile|flow details|configure source|configure target|configure routing/i.test(txt)) score -= 20;
    const r=el.getBoundingClientRect();
    return {selector:cssPath(el), text:txt.slice(0,3000), score, controls, area:Math.max(1,r.width*r.height)};
  }).filter(x=>x.score>0).sort((a,b)=>(b.score-a.score)||(a.area-b.area));
  return rows[0] || {selector:'body', text:(document.body.innerText||'').slice(0,3000), score:0, controls:0, area:0};
}
"""

async def active_form_root_info(page: Page, phase: str) -> Dict[str, Any]:
    try:
        return await page.evaluate(_ROOT_JS, {"phase": phase, "keywords": _PHASE_KEYWORDS.get(phase, _PHASE_KEYWORDS.get("transport_profile", []))})
    except Exception as exc:
        return {"selector": "body", "text": "", "score": 0, "controls": 0, "error": mask_sensitive_string(str(exc))}

async def get_active_form_root(page: Page, phase: str) -> Locator:
    info = await active_form_root_info(page, phase)
    return page.locator(str(info.get("selector") or "body")).first

async def active_form_text(page: Page, phase: str) -> str:
    info = await active_form_root_info(page, phase)
    return str(info.get("text") or "")

async def close_open_dropdown(page: Page, phase: str = "") -> None:
    """Close a DDS/listbox popup without clicking the page shell.

    Earlier builds clicked a blank/root location to dismiss dropdowns.  On the
    HIP Angular shell that click is captured as a mutating app-container click
    and can also close drawers.  This helper is intentionally non-clicking:
    it blurs the active element and dispatches focusout/change only.
    """
    try:
        await page.evaluate(r"""
() => {
  const el = document.activeElement;
  if (el && el !== document.body) {
    try { el.dispatchEvent(new Event('change', {bubbles:true})); } catch(e) {}
    try { el.dispatchEvent(new FocusEvent('blur', {bubbles:true})); } catch(e) {}
    try { el.blur(); } catch(e) {}
  }
  for (const lb of Array.from(document.querySelectorAll('[role=listbox], .dds__dropdown__list, .dds__popover, .dds__menu'))) {
    const txt=(lb.innerText||lb.textContent||'').trim();
    if (!txt) continue;
    lb.setAttribute('data-hip-dropdown-blurred','true');
  }
  return true;
}
""")
        await page.wait_for_timeout(100)
    except Exception:
        pass

async def assert_active_surface(page: Page, phase: str) -> Dict[str, Any]:
    text = (await active_form_text(page, phase)).lower()
    fatal: List[str] = []
    if phase == "data_map":
        required = ["create map", "map identifier", "map data", "input schema validation", "output schema validation"]
        if not all(x in text for x in required):
            fatal.append("Data Map active form root is not the Create Map surface with required upload fields.")
    elif phase in {"source_transport_profile", "target_transport_profile", "transport_profile"}:
        if "create transport profile" not in text or not any(x in text for x in ["interface type", "sftp haft", "existing account", "document type supported"]):
            fatal.append("Transport Profile active form root is not the expanded Create Transport Profile wizard.")
    elif phase == "biz_flow":
        if "b2b-flow-pubsub-template" in text and not any(x in text for x in ["flow details", "configure source", "configure target", "configure routing"]):
            fatal.append("BizFlow active surface is still the template picker, not the wizard.")
        elif not any(x in text for x in ["flow details", "configure source", "configure target", "configure routing", "business flow name"]):
            fatal.append("BizFlow wizard tabs are not visible.")
    return {"phase": phase, "fatal": fatal, "surface_text_sample": text[:500]}



# ---------------------------------------------------------------------------
# Sticky fill/value preservation helpers
# ---------------------------------------------------------------------------
# HIP/DDS comboboxes are Angular controlled. During option inventory, row-level
# +Add, or tab navigation, the portal can rerender a control and briefly reset a
# displayed value back to blank/Select.  These helpers record values that were
# intentionally filled and provide a best-effort restore pass before screenshots
# and before moving to the next nested BizFlow section.  They never click
# Save/Create/Submit; they only restore already-entered field values.

_EMPTY_CONTROL_VALUES = {"", "select", "select...", "choose", "--select--", "none", "null"}


async def _ensure_page_interactable(page: Page, *, action: str, selector: str = "") -> None:
    """Use the shared persistent-session auth/overlay guard when available."""
    session = getattr(page, "_hip_browser_session", None)
    if session is None:
        return
    try:
        await session.ensure_interactable(action=action, selector=selector, timeout_ms=25000)
    except AttributeError:
        return


def semantic_runtime_enabled(page: Page) -> bool:
    """Whether Layer-11 fail-closed semantic execution owns this page."""
    session = getattr(page, "_hip_browser_session", None)
    gate = getattr(session, "semantic_action_gate", None) if session is not None else None
    return bool(gate is not None and getattr(gate, "enabled", False))


async def open_control_for_discovery(page: Page, selector: str, *, label: str = "HIP Portal dropdown", phase: str = "") -> bool:
    """Open a read-only dropdown/control through the governed semantic executor.

    Discovery is still a browser action: prove the exact control, let AutoWebGLM
    approve the intent, execute Playwright MCP first, then verify the structural
    effect.  No raw locator/DOM click is allowed to bypass a semantic rejection.
    """
    if not selector:
        return False
    await _ensure_page_interactable(page, action="open control for read-only option discovery", selector=selector)
    loc = page.locator(selector).first
    resolution, loc, selector, _ = await _semantic_prepare(
        page, action="click", selector=selector, label=label, phase=phase, locator=loc
    )
    await _autowebglm_primary_gate(page, action="click", selector=selector, label=label)
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    clicked = False
    if backend is not None:
        try:
            await backend.click(selector, element=label)
            clicked = True
        except Exception:
            clicked = False

    # Layer-11 read-only discovery is intentionally stricter than the generic
    # deterministic fallback policy: the pasted/release contract requires the
    # *execution* itself to pass through Playwright MCP.  Once semantic runtime
    # owns the page, an unavailable/failed MCP click is authoritative and MUST
    # NOT silently fall through to raw locator.click()/HTMLElement.click().
    if semantic_runtime_enabled(page) and not clicked:
        return False

    # Standalone/offline utility pages that do not have the governed semantic
    # runtime attached may retain the historical Playwright click fallback.
    if not clicked:
        try:
            await loc.scroll_into_view_if_needed(timeout=1800)
            await loc.click(timeout=2500)
            clicked = True
        except Exception:
            return False

    await page.wait_for_timeout(180)
    await _semantic_commit(page, resolution=resolution, action="click", exact_value_verified=False, phase=phase)
    return True

def _norm_control_value(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())

def _looks_empty_control_value(value: str) -> bool:
    return _norm_control_value(value).lower() in _EMPTY_CONTROL_VALUES

async def _lock_filled_value(page: Page, selector: str, value: str, *, key: str = "", label: str = "", combo: bool = False) -> None:
    if not selector or value is None or _looks_empty_control_value(str(value)):
        return
    if semantic_runtime_enabled(page) and selector_looks_generation_volatile(selector):
        return
    try:
        await page.evaluate(r"""
({selector, value, key, label, combo}) => {
  window.__HIP_FILLED_VALUE_LOCKS = window.__HIP_FILLED_VALUE_LOCKS || {};
  const now = Date.now();
  const next = {selector, value:String(value||''), key:String(key||''), label:String(label||''), combo:!!combo, ts:now};
  const existing = window.__HIP_FILLED_VALUE_LOCKS[selector];
  // If two different semantic fills accidentally target the same DOM selector,
  // it means a generic label matcher picked the wrong control.  Do not keep a
  // sticky lock in that case, otherwise the restore pass causes the visible
  // "filled then unfilled/overwritten" behavior.
  if (existing && String(existing.value||'').trim() && String(existing.value||'').trim() !== next.value.trim()) {
    const oldKey = String(existing.key||'');
    const newKey = String(next.key||'');
    if (!oldKey || !newKey || oldKey !== newKey) {
      delete window.__HIP_FILLED_VALUE_LOCKS[selector];
      const el = document.querySelector(selector);
      if (el) {
        el.setAttribute('data-hip-lock-conflict', 'true');
        el.removeAttribute('data-hip-locked-value');
        el.removeAttribute('data-hip-locked-key');
        el.removeAttribute('data-hip-locked-label');
      }
      return false;
    }
  }
  window.__HIP_FILLED_VALUE_LOCKS[selector] = next;
  const el = document.querySelector(selector);
  if (el) {
    el.setAttribute('data-hip-locked-value', String(value||''));
    el.setAttribute('data-hip-locked-at', String(now));
    if (key) el.setAttribute('data-hip-locked-key', String(key));
    if (label) el.setAttribute('data-hip-locked-label', String(label));
  }
  return true;
}
""", {"selector": selector, "value": value, "key": key, "label": label, "combo": combo})
    except Exception:
        pass

async def _restore_previous_value(page: Page, selector: str, value: str) -> bool:
    if not selector or _looks_empty_control_value(value):
        return False
    try:
        res = await page.evaluate(r"""
({selector, value}) => {
  const el = document.querySelector(selector);
  if (!el || el.disabled || el.readOnly || el.getAttribute('aria-disabled') === 'true') return false;
  const before = el.value || el.getAttribute('aria-valuetext') || el.textContent || '';
  el.scrollIntoView({block:'center', inline:'nearest'});
  el.focus();
  const tag = (el.tagName||'').toLowerCase();
  if (tag === 'select') {
    const target = String(value||'').trim().toLowerCase();
    const opts = Array.from(el.options||[]);
    const m = opts.find(o => (o.text||'').trim().toLowerCase() === target) || opts.find(o => String(o.value||'').trim().toLowerCase() === target);
    if (m) el.value = m.value; else el.value = value;
  } else if (el.getAttribute('contenteditable') === 'true') {
    el.textContent = value;
  } else {
    el.value = value;
  }
  for (const ev of ['input','change','blur']) el.dispatchEvent(new Event(ev, {bubbles:true}));
  return {ok:true, before, after: el.value || el.getAttribute('aria-valuetext') || el.textContent || ''};
}
""", {"selector": selector, "value": value})
        return bool(res and res.get("ok"))
    except Exception:
        return False

async def restore_filled_values(page: Page, phase: str = "", *, reason: str = "", attempts: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Restore already-filled controls that regressed to blank/Select.

    This is a DOM/model preservation pass, not a new semantic fill.  It avoids
    the common "filled then unfilled" failure caused by DDS overlay close,
    virtualized row recreation, or tab transition.
    """
    audit: Dict[str, Any] = {"phase": phase, "reason": reason, "checked": 0, "restored": 0, "items": []}
    try:
        rows = await page.evaluate(r"""
() => {
  const locks = window.__HIP_FILLED_VALUE_LOCKS || {};
  function visible(el){
    if(!el || !el.getBoundingClientRect) return false;
    const r=el.getBoundingClientRect(); const s=getComputedStyle(el);
    return !!(r.width && r.height && s.display!=='none' && s.visibility!=='hidden');
  }
  return Object.values(locks).map(lock => {
    const el = document.querySelector(lock.selector);
    const current = el ? (el.value || el.getAttribute('aria-valuetext') || el.getAttribute('title') || el.textContent || '') : '';
    return {...lock, exists: !!el, visible: visible(el), current: String(current||'')};
  });
}
""")
    except Exception as exc:
        audit["error"] = mask_sensitive_string(str(exc))
        return audit
    if not isinstance(rows, list):
        return audit
    for row in rows:
        selector = str(row.get("selector") or "")
        wanted = str(row.get("value") or "")
        current = str(row.get("current") or "")
        audit["checked"] += 1
        if not selector or not wanted or not row.get("exists"):
            continue
        if semantic_runtime_enabled(page) and selector_looks_generation_volatile(selector):
            audit["items"].append({"selector": selector, "restored": False, "skipped": "generation_volatile_selector", "key": row.get("key"), "label": row.get("label")})
            continue
        # Only restore if the field became empty/Select or visibly lost the intended value.
        cur_norm = _norm_control_value(current).lower()
        want_norm = _norm_control_value(wanted).lower()
        if cur_norm and cur_norm not in _EMPTY_CONTROL_VALUES and (cur_norm == want_norm or want_norm in cur_norm or cur_norm in want_norm):
            continue
        ok = await _restore_previous_value(page, selector, wanted)
        item = {"selector": selector, "value": wanted, "previous": current, "restored": ok, "key": row.get("key"), "label": row.get("label")}
        audit["items"].append(item)
        if attempts is not None:
            attempts.append({"label": row.get("label") or "sticky_restore", "key": row.get("key") or "sticky_restore", "selector": selector, "value_used": wanted, "previous_value": current, "success": ok, "filled": ok, "sticky_restore": True, "reason": reason, "safety": "restore only; no Save/Create/Submit clicked", "scoped_to_active_root": True})
        if ok:
            audit["restored"] += 1
    if audit["restored"]:
        try:
            await page.wait_for_timeout(150)
        except Exception:
            pass
    return audit

async def _autowebglm_primary_gate(
    page: Page, *, action: str, selector: str, label: str = "", value: str = ""
) -> Dict[str, Any]:
    session = getattr(page, "_hip_browser_session", None)
    if session is None or not hasattr(session, "_autowebglm_primary_decision"):
        return {"status": "bypassed", "framework": "autowebglm"}
    return await session._autowebglm_primary_decision(
        action=action, selector=selector, label=label or selector, value=value
    )

async def _semantic_prepare(
    page: Page, *, action: str, selector: str, label: str = "", phase: str = "", locator: Locator | None = None
) -> tuple[Dict[str, Any], Locator, str, Dict[str, Any]]:
    """Apply Layer-11 semantic proof/rebind without importing BrowserSession."""
    loc = locator or page.locator(selector).first
    session = getattr(page, "_hip_browser_session", None)
    if session is None or not hasattr(session, "_semantic_action_preflight"):
        return ({"pass": True, "status": "session_unavailable", "confidence": 1.0}, loc, selector, {"pass": True, "status": "not_required"})
    previous_phase = getattr(session, "_active_phase_name", "")
    if phase and not previous_phase:
        try:
            session._active_phase_name = phase
        except Exception:
            pass
    try:
        resolution = await session._semantic_action_preflight(
            action=action, locator=loc, selector=selector, label=label or selector
        )
        fresh_loc, fresh_selector, revalidation = await session._semantic_dispatch_target(
            resolution=resolution, locator=loc, selector=selector
        )
        trace = getattr(session, "mission_trace", None)
        trace_phase = str(getattr(session, "_active_phase_name", "") or phase or "")
        if trace is not None and trace_phase:
            try:
                trace.record_observation(
                    trace_phase,
                    summary=f"Semantic target {resolution.get('semantic_control_id') or 'unidentified'} approved for {action}",
                    source="semantic_action_gate",
                    details={
                        "semantic_control_id": resolution.get("semantic_control_id") or "",
                        "confidence": resolution.get("confidence"),
                        "margin": resolution.get("margin"),
                        "status": resolution.get("status") or "",
                        "revalidation": revalidation.get("status") or "",
                    },
                )
            except Exception:
                pass
        return resolution, fresh_loc, fresh_selector, revalidation
    finally:
        if phase and not previous_phase:
            try:
                session._active_phase_name = previous_phase
            except Exception:
                pass


async def _semantic_commit(
    page: Page, *, resolution: Dict[str, Any], action: str, exact_value_verified: bool, phase: str = ""
) -> Dict[str, Any]:
    session = getattr(page, "_hip_browser_session", None)
    if session is None or not hasattr(session, "_semantic_post_action_verify") or not resolution.get("semantic_control_id"):
        return {"pass": True, "status": "not_required", "confidence": 1.0}
    previous_phase = getattr(session, "_active_phase_name", "")
    if phase and not previous_phase:
        try:
            session._active_phase_name = phase
        except Exception:
            pass
    try:
        effect = await session._semantic_post_action_verify(
            resolution=resolution, action=action, exact_value_verified=exact_value_verified
        )
        trace = getattr(session, "mission_trace", None)
        trace_phase = str(getattr(session, "_active_phase_name", "") or phase or "")
        if trace is not None and trace_phase:
            try:
                trace.record_observation(
                    trace_phase,
                    summary=f"Semantic effect verified: {effect.get('effect_type') or 'effect'}",
                    source="semantic_action_gate",
                    details={
                        "semantic_control_id": resolution.get("semantic_control_id") or "",
                        "effect_pass": bool(effect.get("pass")),
                        "effect_type": effect.get("effect_type") or "",
                        "effect_confidence": effect.get("confidence"),
                    },
                )
            except Exception:
                pass
        return effect
    finally:
        if phase and not previous_phase:
            try:
                session._active_phase_name = previous_phase
            except Exception:
                pass

async def set_text_controls_batch(page: Page, items: List[Dict[str, Any]], *, phase: str = "") -> Dict[str, Any]:
    """Fill multiple ordinary text controls through Playwright MCP browser_fill_form.

    Every field is independently semantic-gated and rebound first.  Only after all
    fields have unique current-generation targets do we execute one structured MCP
    call.  Exact post-fill values and semantic effects are then verified one-by-one.
    DDS/Material dropdowns are intentionally excluded and retain their specialized
    drivers.
    """
    rows = [dict(x) for x in items if isinstance(x, dict) and x.get("selector") and x.get("value") is not None]
    if not rows:
        return {"pass": True, "status": "no_fields", "field_count": 0}
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    if backend is None or "browser_fill_form" not in getattr(getattr(backend, "client", None), "tools", {}):
        if semantic_runtime_enabled(page):
            return {"pass": False, "status": "browser_fill_form_required", "field_count": len(rows)}
        return {"pass": False, "status": "browser_fill_form_unavailable", "field_count": len(rows)}

    prepared: List[Dict[str, Any]] = []
    for row in rows:
        selector = str(row.get("selector") or "")
        label = str(row.get("label") or row.get("field") or "HIP Portal text field")
        section = str(row.get("section") or "")
        await _ensure_page_interactable(page, action="fill verified form batch", selector=selector)
        resolution, loc, fresh_selector, revalidation = await _semantic_prepare(
            page, action="fill", selector=selector, label=label, phase=phase, locator=page.locator(selector).first
        )
        await _autowebglm_primary_gate(page, action="fill", selector=fresh_selector, label=label, value=str(row.get("value") or ""))
        ref_proof = await backend.find_ref(label, expected_role="textbox", section=section)
        if ref_proof.get("status") != "unique_match":
            return {
                "pass": False, "status": "browser_find_ref_not_unique", "field": label,
                "ref_proof": ref_proof, "field_count": len(rows),
            }
        prepared.append({
            "label": label, "section": section, "selector": fresh_selector, "locator": loc,
            "resolution": resolution, "revalidation": revalidation, "value": str(row.get("value") or ""),
            "ref": str(ref_proof.get("ref") or ""),
        })

    try:
        await backend.fill_form([
            {"target": row["ref"], "ref": row["ref"], "element": row["label"], "name": row["label"], "type": "textbox", "value": row["value"]}
            for row in prepared
        ])
    except Exception as exc:
        return {"pass": False, "status": "browser_fill_form_failed", "error": mask_sensitive_string(str(exc)), "field_count": len(prepared)}

    results = []
    all_ok = True
    for row in prepared:
        try:
            await page.wait_for_timeout(100)
            actual = await _read_control_value(row["locator"]) if await row["locator"].count() else ""
            exact = _option_semantic_key(actual) == _option_semantic_key(row["value"]) or str(row["value"]).strip().lower() == str(actual).strip().lower()
            if exact:
                await _lock_filled_value(page, row["selector"], row["value"], combo=False)
                effect = await _semantic_commit(page, resolution=row["resolution"], action="fill", exact_value_verified=True, phase=phase)
                exact = bool(effect.get("pass", True))
            results.append({"label": row["label"], "selector": row["selector"], "ref": row["ref"], "exact_verified": exact})
            all_ok = all_ok and exact
        except Exception as exc:
            all_ok = False
            results.append({"label": row["label"], "selector": row["selector"], "ref": row["ref"], "exact_verified": False, "error": mask_sensitive_string(str(exc))})
    return {
        "pass": all_ok, "status": "verified" if all_ok else "post_verify_failed",
        "executor": "playwright-mcp:browser_fill_form", "field_count": len(prepared),
        "fields": results, "values_stored": False,
    }


async def set_text_control(page: Page, root: Locator | None, selector: str, value: str, *, phase: str = "") -> bool:
    if not selector:
        return False
    await _ensure_page_interactable(page, action="fill text control", selector=selector)
    semantic_resolution, semantic_loc, selector, semantic_revalidation = await _semantic_prepare(
        page, action="fill", selector=selector, label="HIP Portal text field", phase=phase, locator=page.locator(selector).first
    )
    await _autowebglm_primary_gate(page, action="fill", selector=selector, label="HIP Portal text field", value=str(value))
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    if backend is not None:
        try:
            ref_proof = await backend.find_ref(str((semantic_resolution.get("candidate") or {}).get("label") or "HIP Portal text field"), expected_role="textbox", section=str((semantic_resolution.get("candidate") or {}).get("section") or ""))
            target = str(ref_proof.get("ref") or selector)
            if semantic_runtime_enabled(page) and ref_proof.get("status") != "unique_match":
                return False
            await backend.fill(target, str(value), element="HIP Portal text field")
            await page.wait_for_timeout(180)
            actual = await _read_control_value(semantic_loc) if await semantic_loc.count() else ""
            exact = _option_semantic_key(actual) == _option_semantic_key(value) or str(value).strip().lower() == str(actual).strip().lower()
            if exact:
                await _lock_filled_value(page, selector, str(value), combo=False)
                await _semantic_commit(page, resolution=semantic_resolution, action="fill", exact_value_verified=True, phase=phase)
                return True
        except Exception:
            if semantic_runtime_enabled(page):
                return False
    if semantic_runtime_enabled(page):
        return False
    js = r"""
({selector, value}) => {
  const el=document.querySelector(selector);
  if(!el) return {ok:false, reason:'not-found'};
  if(el.disabled || el.readOnly || el.getAttribute('aria-disabled')==='true') return {ok:false, reason:'disabled'};
  const tag=(el.tagName||'').toLowerCase();
  const type=(el.getAttribute('type')||'').toLowerCase();
  if(type==='file') return {ok:false, reason:'file'};
  el.scrollIntoView({block:'center', inline:'nearest'});
  el.focus();
  if(tag==='select'){
    const val=String(value||'').trim().toLowerCase();
    const opts=Array.from(el.options||[]);
    const m=opts.find(o=>(o.text||'').trim().toLowerCase()===val)||opts.find(o=>String(o.value||'').trim().toLowerCase()===val)||opts.find(o=>(o.text||'').toLowerCase().includes(val));
    if(m) el.value=m.value; else el.value=value;
  } else if(el.getAttribute('contenteditable')==='true') {
    el.textContent=value;
  } else {
    el.value=value;
  }
  for(const ev of ['input','change','blur']) el.dispatchEvent(new Event(ev,{bubbles:true}));
  return {ok:true, value:el.value||el.textContent||''};
}
"""
    try:
        result = await page.evaluate(js, {"selector": selector, "value": value})
        ok = bool(result and result.get("ok"))
        if ok:
            await _lock_filled_value(page, selector, str(value), combo=False)
            actual = await _read_control_value(semantic_loc) if await semantic_loc.count() else str(result.get("value") or "")
            exact = _option_semantic_key(actual) == _option_semantic_key(value) or str(value).strip().lower() == str(actual).strip().lower()
            if not exact:
                return False
            await _semantic_commit(page, resolution=semantic_resolution, action="fill", exact_value_verified=True, phase=phase)
        return ok
    except Exception:
        return False

def _option_semantic_key(value: Any) -> str:
    """Normalize a DDS option/value without depending on presentation punctuation.

    HIP input contracts intentionally use stable enum-like values such as
    ``TRANSACTION_ROOT_ELEMENT`` and ``ELEMENT_IN_PAYLOAD`` while DDS renders
    human labels such as ``Transaction Root Element`` and ``Element In Payload``.
    Treat those as the same semantic option, but do not accept arbitrary
    substring matches.
    """
    text = str(value or "").strip().lower()
    text = re.sub(r"[_\-/]+", " ", text)
    text = re.sub(r"[^a-z0-9.()]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _combobox_value_variants(value: str) -> List[str]:
    raw = str(value or "").strip()
    if not raw:
        return []
    variants: List[str] = []

    def add(v: str) -> None:
        v = re.sub(r"\s+", " ", str(v or "").strip())
        if v and v.lower() not in {x.lower() for x in variants}:
            variants.append(v)

    add(raw)
    # Enum/value -> DDS display-label variants.
    if "_" in raw or "-" in raw:
        spaced = re.sub(r"[_-]+", " ", raw)
        add(spaced)
        add(" ".join(token.capitalize() if token else token for token in spaced.lower().split(" ")))
    # Some DDS lists render ``Name (1.0)`` while input data uses ``Name(1.0)``.
    add(re.sub(r"\s*\(\s*([0-9.]+)\s*\)\s*$", r" (\1)", raw))
    # Base-name fallbacks are retained only as *candidate* variants. The option
    # selector below requires the winning candidate to be unique, so a list with
    # multiple versions cannot be selected from the base name alone.
    add(re.sub(r"\s*\(\s*[0-9.]+\s*\)\s*$", "", raw))
    if "," in raw:
        add(raw.split(",", 1)[0])
    return variants


async def _read_control_value(locator: Locator) -> str:
    try:
        return str(await locator.evaluate("""el => {
          if (!el) return '';
          const tag=(el.tagName||'').toLowerCase();
          if (tag === 'select') return (el.options && el.selectedIndex >= 0) ? (el.options[el.selectedIndex].text || el.value || '') : (el.value || '');
          return el.value || el.getAttribute('aria-valuetext') || el.getAttribute('data-value') || el.getAttribute('title') || '';
        }"""))
    except Exception:
        try:
            return str(await locator.input_value(timeout=700))
        except Exception:
            return ""


def _value_matches_variants(current: Any, variants: List[str]) -> bool:
    key = _option_semantic_key(current)
    if not key or key in {"select", "select...", "choose", "select one", "none"}:
        return False
    return any(key == _option_semantic_key(v) for v in variants if _option_semantic_key(v))


async def _dds_single_select_snapshot(page: Page, selector: str) -> Dict[str, Any]:
    """Return commit evidence for one *owned* DDS single-select.

    DDS often portals the listbox outside ``dds-dropdown``.  The old collector
    searched only descendants of the component (or, during clicking, the whole
    page), which could both miss the real committed option and click an option
    belonging to another dropdown.  This snapshot follows ``aria-controls`` /
    ``aria-owns`` and assigns unique current-run tokens to the owned options.
    """
    try:
        result = await page.evaluate(r"""
(selector) => {
  const clean=v=>String(v||'').replace(/\s+/g,' ').trim();
  const visible=el=>{if(!el||!el.getBoundingClientRect)return false;const r=el.getBoundingClientRect();const s=getComputedStyle(el);return !!(r.width&&r.height&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||'1')!==0);};
  const input=document.querySelector(selector);
  if(!input) return {found:false, options:[], selected_values:[], committed_candidates:[]};
  const dd=input.closest('dds-dropdown,app-generic-dropdown,[data-dds-dropdown]');
  const listId=input.getAttribute('aria-controls') || input.getAttribute('aria-owns') || '';
  let list=(listId && document.getElementById(listId)) || null;
  if(!list && dd) list=dd.querySelector('[role=listbox],.dds__dropdown__list,.dds__menu');
  const optionRoot=list || dd;
  const optionEls=optionRoot ? Array.from(optionRoot.querySelectorAll('[role=option],button.dds__dropdown__item-option,.dds__dropdown__item-option,li[role=option]')) : [];
  const options=optionEls.map((el,index)=>{
    let token=el.getAttribute('data-hip-single-option-token')||'';
    if(!token){token=`hip-single-opt-${Date.now()}-${index}-${Math.random().toString(36).slice(2,8)}`;el.setAttribute('data-hip-single-option-token',token);}
    const cls=el.classList||{contains:()=>false};
    const selected=el.getAttribute('aria-selected')==='true' || el.getAttribute('data-selected')==='true' || el.getAttribute('aria-checked')==='true' || cls.contains('dds__dropdown__item-selected') || cls.contains('dds__dropdown__item--selected');
    return {text:clean(el.innerText||el.textContent),selected,disabled:el.getAttribute('aria-disabled')==='true'||!!el.disabled,visible:visible(el),id:el.id||'',aria_posinset:el.getAttribute('aria-posinset')||'',token};
  }).filter(x=>x.text);
  const selectedOptions=options.filter(x=>x.selected).map(x=>x.text);
  const selectedLabels=[];
  if(dd){
    for(const el of Array.from(dd.querySelectorAll('.dds__tag,.dds__chip,[class*=selected-value],[class*=selection__label],[class*=dropdown__selection]'))){
      const t=clean(el.innerText||el.textContent);
      if(t && !/^\d+\s+selected$/i.test(t) && t.toLowerCase()!=='select all' && !selectedLabels.some(x=>x.toLowerCase()===t.toLowerCase())) selectedLabels.push(t);
    }
  }
  const rawValue=clean(input.value||input.getAttribute('aria-valuetext')||input.getAttribute('data-value')||input.getAttribute('title')||'');
  const committed=[];
  for(const t of [rawValue,...selectedOptions,...selectedLabels]) if(t && !committed.some(x=>x.toLowerCase()===t.toLowerCase())) committed.push(t);
  return {
    found:true,
    selector,
    input_value:rawValue,
    list_id:(list&&list.id)||listId,
    expanded:input.getAttribute('aria-expanded')==='true' || !!(list&&visible(list)),
    aria_activedescendant:input.getAttribute('aria-activedescendant')||'',
    readonly:!!input.readOnly,
    disabled:!!input.disabled||input.getAttribute('aria-disabled')==='true',
    options,
    selected_values:selectedOptions,
    selected_labels:selectedLabels,
    committed_candidates:committed,
  };
}
""", selector)
        return dict(result or {}) if isinstance(result, dict) else {}
    except Exception:
        return {}


def _single_select_snapshot_matches(snapshot: Dict[str, Any], variants: List[str]) -> bool:
    for value in snapshot.get("committed_candidates", []) if isinstance(snapshot, dict) else []:
        if _value_matches_variants(value, variants):
            return True
    return False


def _single_option_rank(text: str, raw_value: str, variants: List[str]) -> int:
    key = _option_semantic_key(text)
    raw_key = _option_semantic_key(raw_value)
    if key and raw_key and key == raw_key:
        return 100
    variant_keys = [_option_semantic_key(v) for v in variants if _option_semantic_key(v)]
    if key in variant_keys:
        # Earlier variants are stronger (raw/display-enum forms precede base-name).
        return max(60, 95 - variant_keys.index(key) * 5)
    # Only tolerate a version suffix difference when the non-version base is exact.
    text_base = re.sub(r"\s*\(\s*[0-9.]+\s*\)\s*$", "", key).strip()
    raw_base = re.sub(r"\s*\(\s*[0-9.]+\s*\)\s*$", "", raw_key).strip()
    if text_base and raw_base and text_base == raw_base:
        return 55
    return 0


def _choose_unique_single_option(snapshot: Dict[str, Any], raw_value: str, variants: List[str]) -> Dict[str, Any] | None:
    ranked: List[tuple[int, Dict[str, Any]]] = []
    for option in snapshot.get("options", []) if isinstance(snapshot, dict) else []:
        if not isinstance(option, dict) or option.get("disabled"):
            continue
        score = _single_option_rank(str(option.get("text") or ""), raw_value, variants)
        if score > 0:
            ranked.append((score, option))
    ranked.sort(key=lambda item: item[0], reverse=True)
    if not ranked:
        return None
    best_score = ranked[0][0]
    best = [dict(option) for score, option in ranked if score == best_score]
    # Never guess between two equally good candidates (common when multiple
    # Document Type versions share the same base label).
    return best[0] if len(best) == 1 else None


def _single_option_selector(snapshot: Dict[str, Any], option: Dict[str, Any]) -> str:
    oid = str(option.get("id") or "").strip()
    if oid:
        return f'[id="{_css_attr_value(oid)}"]'
    token = str(option.get("token") or "").strip()
    if token:
        return f'[data-hip-single-option-token="{_css_attr_value(token)}"]'
    list_id = str(snapshot.get("list_id") or "").strip()
    pos = str(option.get("aria_posinset") or "").strip()
    if list_id and pos:
        return f'[id="{_css_attr_value(list_id)}"] [role="option"][aria-posinset="{_css_attr_value(pos)}"]'
    return ""


async def read_last_single_select_audit(page: Page) -> Dict[str, Any]:
    audit = getattr(page, "_hip_last_single_select_audit", None)
    return dict(audit) if isinstance(audit, dict) else {}


async def _set_single_select_audit(page: Page, audit: Dict[str, Any]) -> None:
    try:
        setattr(page, "_hip_last_single_select_audit", dict(audit))
    except Exception:
        pass


async def _combobox_value_matches(locator: Locator, variants: List[str], *, page: Page | None = None, selector: str = "") -> bool:
    current = await _read_control_value(locator)
    if _value_matches_variants(current, variants):
        return True
    if page is not None and selector:
        snapshot = await _dds_single_select_snapshot(page, selector)
        return _single_select_snapshot_matches(snapshot, variants)
    return False


async def _open_owned_single_select(page: Page, selector: str, backend: Any = None) -> Dict[str, Any]:
    snapshot = await _dds_single_select_snapshot(page, selector)
    if snapshot.get("expanded") and snapshot.get("options"):
        return snapshot
    # AutoWebGLM has already approved the select intent. Execute the physical
    # open through Playwright MCP first so DDS controls follow the same primary
    # executor contract as BrowserSession.click_and_wait.
    opened = False
    if backend is not None:
        try:
            await backend.click(selector, element="HIP Portal DDS combobox")
            opened = True
        except Exception:
            opened = False
    if not opened:
        loc = page.locator(selector).first
        try:
            await loc.scroll_into_view_if_needed(timeout=1800)
            await loc.click(timeout=2500)
        except Exception:
            pass
    deadline = asyncio.get_running_loop().time() + 2.8
    last = snapshot
    while asyncio.get_running_loop().time() < deadline:
        last = await _dds_single_select_snapshot(page, selector)
        if last.get("options"):
            return last
        await page.wait_for_timeout(90)
    return last


async def _click_owned_single_option(
    page: Page, snapshot: Dict[str, Any], option: Dict[str, Any], backend: Any = None, *, phase: str = ""
) -> bool:
    """Click one uniquely-owned DDS option through the semantic action gate."""
    option_selector = _single_option_selector(snapshot, option)
    if not option_selector:
        return False
    loc = page.locator(option_selector).first
    try:
        resolution, loc, option_selector, _ = await _semantic_prepare(
            page, action="select", selector=option_selector,
            label=str(option.get("text") or "HIP Portal DDS option"), phase=phase, locator=loc
        )
    except Exception:
        return False
    clicked = False
    if backend is not None:
        try:
            await backend.click(option_selector, element=f"HIP Portal DDS option {option.get('text') or ''}")
            clicked = True
        except Exception:
            clicked = False
    if not clicked:
        try:
            if await loc.count():
                await loc.scroll_into_view_if_needed(timeout=1200)
                await loc.click(timeout=2200)
                clicked = True
        except Exception:
            clicked = False
    if not clicked:
        return False
    try:
        await page.wait_for_timeout(100)
        await _semantic_commit(page, resolution=resolution, action="select", exact_value_verified=False, phase=phase)
        return True
    except Exception:
        return False


async def select_dds_combobox(page: Page, root: Locator | None, selector: str, value: str, *, phase: str = "") -> bool:
    """Select one DDS value using the combobox-owned listbox and prove commit.

    Key properties:
    * AutoWebGLM approves the vetted select intent;
    * official Playwright MCP executes first on the same authenticated tab;
    * deterministic Python Playwright is an exact DDS fallback only;
    * only the listbox owned by this combobox is searched/clicked;
    * enum input values (``ELEMENT_IN_PAYLOAD``) match human DDS labels;
    * a blank search textbox does not erase a valid selected-option/chip commit;
    * Enter is never pressed blindly when no unique exact candidate exists;
    * failure returns False so AgentQ/recovery can choose a different action.
    """
    if not selector or value in (None, ""):
        return False
    await _ensure_page_interactable(page, action=f"select DDS combobox {value}", selector=selector)
    raw_value = str(value)
    variants = _combobox_value_variants(raw_value)
    if not variants:
        return False
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    loc = page.locator(selector).first
    audit: Dict[str, Any] = {
        "selector": selector,
        "requested_value": raw_value,
        "variants": variants,
        "phase": phase,
        "success": False,
        "executor": "autowebglm->playwright-mcp-primary->python-playwright-fallback",
        "attempts": [],
    }
    try:
        if not await loc.count():
            audit["reason"] = "combobox selector not found"
            await _set_single_select_audit(page, audit)
            return False
        semantic_resolution, loc, selector, semantic_revalidation = await _semantic_prepare(
            page, action="select", selector=selector,
            label=f"HIP Portal DDS combobox ({phase or 'form'})", phase=phase, locator=loc
        )
        audit["semantic_gate"] = {
            "semantic_control_id": semantic_resolution.get("semantic_control_id") or "",
            "confidence": semantic_resolution.get("confidence"),
            "margin": semantic_resolution.get("margin"),
            "status": semantic_resolution.get("status") or "",
            "revalidation": semantic_revalidation.get("status") or "",
        }
        async def _semantic_success() -> bool:
            effect = await _semantic_commit(
                page, resolution=semantic_resolution, action="select", exact_value_verified=True, phase=phase
            )
            audit["semantic_effect"] = {
                "pass": bool(effect.get("pass")),
                "type": effect.get("effect_type") or "",
                "confidence": effect.get("confidence"),
            }
            return True
        tag_name = str(await loc.evaluate("el => (el.tagName || '').toLowerCase()"))
        previous_snapshot = await _dds_single_select_snapshot(page, selector)
        if await _combobox_value_matches(loc, variants, page=page, selector=selector):
            committed = next((x for x in previous_snapshot.get("committed_candidates", []) if _value_matches_variants(x, variants)), raw_value)
            await _lock_filled_value(page, selector, str(committed or raw_value), combo=True)
            audit.update({"success": True, "reason": "already committed", "commit_snapshot": previous_snapshot})
            await _set_single_select_audit(page, audit)
            return await _semantic_success()

        awg_decision = await _autowebglm_primary_gate(
            page, action="select", selector=selector, label=f"HIP Portal DDS combobox ({phase or 'form'})", value=raw_value
        )
        audit["autowebglm_primary"] = {
            "status": awg_decision.get("status"),
            "framework": awg_decision.get("framework"),
            "command": awg_decision.get("command"),
            "aligned": awg_decision.get("aligned"),
        }

        if tag_name == "select":
            # Native select: AutoWebGLM already approved the exact semantic value.
            # Execute through Playwright MCP first, then local select_option only
            # when MCP cannot address this control.
            if backend is not None:
                for term in variants:
                    try:
                        await backend.select_option(selector, term, element="HIP Portal dropdown")
                        await page.wait_for_timeout(180)
                        if await _combobox_value_matches(loc, variants, page=page, selector=selector):
                            await _lock_filled_value(page, selector, raw_value, combo=True)
                            audit.update({"success": True, "reason": "MCP native select committed", "selected_term": term, "actual_executor": "playwright-mcp"})
                            await _set_single_select_audit(page, audit)
                            return await _semantic_success()
                    except Exception as exc:
                        audit["attempts"].append({"stage": "mcp_native_select", "term": term, "error": mask_sensitive_string(str(exc))})
            for term in variants:
                try:
                    await loc.select_option(label=term, timeout=1500)
                except Exception:
                    try:
                        await loc.select_option(value=term, timeout=1500)
                    except Exception:
                        continue
                await page.wait_for_timeout(160)
                if await _combobox_value_matches(loc, variants, page=page, selector=selector):
                    await _lock_filled_value(page, selector, raw_value, combo=True)
                    audit.update({"success": True, "reason": "native select committed", "selected_term": term})
                    await _set_single_select_audit(page, audit)
                    return await _semantic_success()
            audit["reason"] = "native select had no exact committed option through Playwright MCP or deterministic fallback"
            await _set_single_select_audit(page, audit)
            return False

        # Open this DDS control and inspect only its owned listbox.
        snapshot = await _open_owned_single_select(page, selector, backend)
        option = _choose_unique_single_option(snapshot, raw_value, variants)
        audit["attempts"].append({
            "stage": "owned_listbox_initial",
            "option_count": len(snapshot.get("options", [])),
            "chosen_option": (option or {}).get("text"),
            "list_id": snapshot.get("list_id"),
        })
        if option is not None and await _click_owned_single_option(page, snapshot, option, backend, phase=phase):
            await page.wait_for_timeout(220)
            committed_snapshot = await _dds_single_select_snapshot(page, selector)
            if await _combobox_value_matches(loc, variants, page=page, selector=selector):
                committed = next((x for x in committed_snapshot.get("committed_candidates", []) if _value_matches_variants(x, variants)), option.get("text") or raw_value)
                await _lock_filled_value(page, selector, str(committed), combo=True)
                audit.update({"success": True, "reason": "owned DDS option committed", "chosen_option": option.get("text"), "commit_snapshot": committed_snapshot})
                await _set_single_select_audit(page, audit)
                return await _semantic_success()

        # Search only inside this combobox, then require one unique candidate.
        # Many DDS inputs are searchable even though their committed display
        # becomes blank after selection. Playwright MCP performs the physical
        # click/type first; deterministic Python Playwright is a bounded fallback.
        for term in variants:
            # MCP-primary search path.
            if backend is not None:
                try:
                    await close_open_dropdown(page, phase)
                    await backend.click(selector, element="HIP Portal DDS combobox")
                    await backend.fill(selector, term, element="HIP Portal DDS combobox search")
                    await page.wait_for_timeout(320)
                    searched = await _dds_single_select_snapshot(page, selector)
                    option = _choose_unique_single_option(searched, raw_value, variants)
                    audit["attempts"].append({
                        "stage": "mcp_search_owned_listbox",
                        "term": term,
                        "option_count": len(searched.get("options", [])),
                        "chosen_option": (option or {}).get("text"),
                        "list_id": searched.get("list_id"),
                    })
                    if option is not None and await _click_owned_single_option(page, searched, option, backend, phase=phase):
                        await page.wait_for_timeout(220)
                        committed_snapshot = await _dds_single_select_snapshot(page, selector)
                        if await _combobox_value_matches(loc, variants, page=page, selector=selector):
                            committed = next((x for x in committed_snapshot.get("committed_candidates", []) if _value_matches_variants(x, variants)), option.get("text") or raw_value)
                            await _lock_filled_value(page, selector, str(committed), combo=True)
                            audit.update({
                                "success": True,
                                "reason": "Playwright MCP search + owned DDS option committed",
                                "chosen_option": option.get("text"),
                                "commit_snapshot": committed_snapshot,
                                "actual_executor": "playwright-mcp",
                            })
                            await _set_single_select_audit(page, audit)
                            return await _semantic_success()
                except Exception as exc:
                    audit["attempts"].append({"stage": "mcp_search_exception", "term": term, "error": mask_sensitive_string(str(exc))})

            # Exact local fallback when MCP cannot address the custom DDS textbox.
            try:
                await close_open_dropdown(page, phase)
                await loc.click(timeout=1800)
                try:
                    await loc.fill(term, timeout=1800)
                except Exception:
                    try:
                        await loc.press("Control+A", timeout=600)
                        await loc.type(term, delay=10, timeout=1800)
                    except Exception as exc:
                        audit["attempts"].append({"stage": "search_type", "term": term, "error": mask_sensitive_string(str(exc))})
                        continue
                await page.wait_for_timeout(320)
                searched = await _dds_single_select_snapshot(page, selector)
                option = _choose_unique_single_option(searched, raw_value, variants)
                audit["attempts"].append({
                    "stage": "python_fallback_owned_listbox_search",
                    "term": term,
                    "option_count": len(searched.get("options", [])),
                    "chosen_option": (option or {}).get("text"),
                    "list_id": searched.get("list_id"),
                })
                if option is None:
                    continue
                if not await _click_owned_single_option(page, searched, option, None, phase=phase):
                    continue
                await page.wait_for_timeout(220)
                committed_snapshot = await _dds_single_select_snapshot(page, selector)
                if await _combobox_value_matches(loc, variants, page=page, selector=selector):
                    committed = next((x for x in committed_snapshot.get("committed_candidates", []) if _value_matches_variants(x, variants)), option.get("text") or raw_value)
                    await _lock_filled_value(page, selector, str(committed), combo=True)
                    audit.update({
                        "success": True,
                        "reason": "Python Playwright fallback search + owned DDS option committed",
                        "chosen_option": option.get("text"),
                        "commit_snapshot": committed_snapshot,
                        "actual_executor": "python-playwright-fallback",
                    })
                    await _set_single_select_audit(page, audit)
                    return await _semantic_success()
            except Exception as exc:
                audit["attempts"].append({"stage": "python_search_exception", "term": term, "error": mask_sensitive_string(str(exc))})
                continue

        # No free-text/set-value fallback for a true DDS single-select.  Directly
        # assigning the search input can look filled while Angular still holds no
        # selected option—the exact failure mode seen in the live Document Type
        # runs.  Restore an earlier valid selection if search temporarily cleared it.
        previous_committed = next((x for x in previous_snapshot.get("committed_candidates", []) if x and _option_semantic_key(x) not in {"select", "choose"}), "")
        if previous_committed:
            try:
                await _restore_previous_value(page, selector, previous_committed)
            except Exception:
                pass
        await close_open_dropdown(page, phase)
        audit.update({"success": False, "reason": "no unique owned DDS option reached exact committed state", "final_snapshot": await _dds_single_select_snapshot(page, selector)})
        await _set_single_select_audit(page, audit)
        return False
    except Exception as exc:
        await close_open_dropdown(page, phase)
        audit.update({"success": False, "reason": "single-select exception", "error": mask_sensitive_string(str(exc))})
        await _set_single_select_audit(page, audit)
        return False

async def upload_file_control(page: Page, root: Locator | None, field_name_or_label: str, file_path: str | Path, *, phase: str = "") -> Dict[str, Any]:
    p = Path(str(file_path))
    audit: Dict[str, Any] = {"field": field_name_or_label, "asset_path": str(p), "filled": False, "upload_attempted": True}
    if not p.exists():
        audit["reason"] = "file path does not exist"
        return audit
    label = field_name_or_label.lower()
    stable: List[str] = []
    if "map" in label and "schema" not in label:
        stable += ['input[type="file"][name="mapData"]', 'input[type="file"][id*="mapData" i]', 'input[type="file"][id*="map" i]']
    if "input" in label or "source" in label:
        stable += ['input[type="file"][name="inputSchema"]', 'input[type="file"][id*="inputSchema" i]', 'input[type="file"][id*="source" i]']
    if "output" in label or "target" in label:
        stable += ['input[type="file"][name="outputSchema"]', 'input[type="file"][id*="outputSchema" i]', 'input[type="file"][id*="target" i]']
    stable.append('input[type="file"]')
    root_sel = None
    try:
        root_info = await active_form_root_info(page, phase or "data_map")
        root_sel = str(root_info.get("selector") or "body")
    except Exception:
        root_sel = "body"
    for sel in stable:
        scoped = f"{root_sel} {sel}" if root_sel and root_sel != "body" else sel
        try:
            locs = page.locator(scoped)
            n = await locs.count()
            for i in range(n):
                loc = locs.nth(i)
                semantic_resolution, loc, semantic_selector, semantic_revalidation = await _semantic_prepare(
                    page, action="upload", selector=scoped, label=field_name_or_label or "HIP file upload", phase=phase, locator=loc
                )
                await _autowebglm_primary_gate(
                    page, action="upload", selector=semantic_selector, label=field_name_or_label or "HIP file upload"
                )
                await loc.set_input_files(str(p), timeout=12000)
                await page.wait_for_timeout(350)
                visible = False
                try:
                    visible = bool(await page.evaluate("""
(name) => {
  const body=(document.body.innerText||document.body.textContent||'');
  const inputs=Array.from(document.querySelectorAll('input[type=file]')).map(i=>Array.from(i.files||[]).map(f=>f.name).join(' ')).join(' ');
  return body.includes(name) || inputs.includes(name);
}
""", p.name))
                except Exception:
                    pass
                if not visible:
                    raise RuntimeError("HIP file upload did not become visible/committed on the semantically resolved control")
                semantic_effect = await _semantic_commit(
                    page, resolution=semantic_resolution, action="upload", exact_value_verified=True, phase=phase
                )
                audit.update({
                    "filled": True, "success": True, "uploaded_file_name": p.name, "file_input_selector": semantic_selector,
                    "filename_visible_after_upload": visible, "reason": "uploaded into semantically verified active form input[type=file]",
                    "semantic_gate": {
                        "semantic_control_id": semantic_resolution.get("semantic_control_id") or "",
                        "confidence": semantic_resolution.get("confidence"), "margin": semantic_resolution.get("margin"),
                        "status": semantic_resolution.get("status") or "", "revalidation": semantic_revalidation.get("status") or "",
                    },
                    "semantic_effect": {"pass": bool(semantic_effect.get("pass")), "effect_type": semantic_effect.get("effect_type") or "", "confidence": semantic_effect.get("confidence")},
                })
                return audit
        except Exception as exc:
            audit["last_error"] = mask_sensitive_string(str(exc))
            continue
    audit["reason"] = "no usable input[type=file] found in active form root"
    return audit

async def click_visible_tab(page: Page, root: Locator | None, aliases: List[str], *, phase: str = "") -> Dict[str, Any]:
    audit = {"clicked": False, "alias": "", "selector": "", "executor": ""}
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    for a in aliases:
        for sel in [f"[role=tab]:has-text('{a}')", f"button:has-text('{a}')", f"a:has-text('{a}')", f"text=/{re.escape(a)}/i"]:
            try:
                loc = page.locator(sel).first
                if not (await loc.count() and await loc.is_visible(timeout=800)):
                    continue
                semantic_resolution, loc, semantic_selector, semantic_revalidation = await _semantic_prepare(
                    page, action="click", selector=sel, label=f"HIP Portal tab {a}", phase=phase, locator=loc
                )
                await _autowebglm_primary_gate(page, action="click", selector=semantic_selector, label=f"HIP Portal tab {a}")
                executor = "python-playwright-fallback"
                if backend is not None:
                    try:
                        await backend.click(semantic_selector, element=f"HIP Portal tab {a}")
                        executor = "playwright-mcp"
                    except Exception:
                        await loc.click(timeout=2000)
                else:
                    await loc.click(timeout=2000)
                await page.wait_for_timeout(800)
                semantic_effect = await _semantic_commit(
                    page, resolution=semantic_resolution, action="click", exact_value_verified=False, phase=phase
                )
                audit.update({
                    "clicked": True, "alias": a, "selector": semantic_selector, "executor": executor,
                    "semantic_gate": {
                        "semantic_control_id": semantic_resolution.get("semantic_control_id") or "",
                        "confidence": semantic_resolution.get("confidence"), "margin": semantic_resolution.get("margin"),
                        "status": semantic_resolution.get("status") or "", "revalidation": semantic_revalidation.get("status") or "",
                    },
                    "semantic_effect": {"pass": bool(semantic_effect.get("pass")), "effect_type": semantic_effect.get("effect_type") or "", "confidence": semantic_effect.get("confidence")},
                })
                return audit
            except Exception as exc:
                audit["last_error"] = mask_sensitive_string(str(exc))
                continue
    return audit


def _css_attr_value(value: Any) -> str:
    """Escape a string for use inside a double-quoted CSS attribute selector."""
    return str(value or "").replace("\\", "\\\\").replace('"', '\\"')


def _multiselect_selected_values_from_snapshot(snapshot: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    for option in snapshot.get("options", []) if isinstance(snapshot, dict) else []:
        if not isinstance(option, dict) or not option.get("selected"):
            continue
        text = re.sub(r"\s+", " ", str(option.get("text") or "").strip())
        if text and text.lower() != "select all" and text.lower() not in {x.lower() for x in out}:
            out.append(text)
    for text_value in snapshot.get("selected_labels", []) if isinstance(snapshot, dict) else []:
        text = re.sub(r"\s+", " ", str(text_value or "").strip())
        if re.fullmatch(r"\d+\s+selected", text, flags=re.I):
            continue
        if text and text.lower() != "select all" and text.lower() not in {x.lower() for x in out}:
            out.append(text)
    return out


def _find_multiselect_option(snapshot: Dict[str, Any], value: str) -> Optional[Dict[str, Any]]:
    target = re.sub(r"\s+", " ", str(value or "").strip()).lower()
    for option in snapshot.get("options", []) if isinstance(snapshot, dict) else []:
        if not isinstance(option, dict):
            continue
        text = re.sub(r"\s+", " ", str(option.get("text") or "").strip()).lower()
        if text == target:
            return dict(option)
    return None


def _unique_multiselect_option_selector(snapshot: Dict[str, Any], option: Dict[str, Any]) -> str:
    """Return a selector that resolves to exactly one DDS option.

    HIP DDS wraps each option in its own element.  A selector such as
    ``#list button:nth-of-type(1)`` therefore matches the first button inside
    *every* wrapper and triggers Playwright strict-mode violations.  DDS exposes
    ``aria-posinset`` on each option, which is stable and unique within the
    associated listbox, so prefer that contract.
    """
    option_id = str(option.get("id") or "").strip()
    if option_id:
        return f'[id="{_css_attr_value(option_id)}"]'
    list_id = str(snapshot.get("list_id") or "").strip()
    position = str(option.get("aria_posinset") or "").strip()
    if list_id and position:
        return (
            f'[id="{_css_attr_value(list_id)}"] '
            f'[role="option"][aria-posinset="{_css_attr_value(position)}"]'
        )
    token = str(option.get("token") or "").strip()
    if token:
        return f'[data-hip-option-token="{_css_attr_value(token)}"]'
    return ""


def _multiselect_delta(wanted: List[str], selected: List[str]) -> Dict[str, List[str]]:
    wanted_map = {str(x).strip().lower(): str(x).strip() for x in wanted if str(x).strip()}
    selected_map = {str(x).strip().lower(): str(x).strip() for x in selected if str(x).strip()}
    return {
        "missing": [wanted_map[k] for k in wanted_map if k not in selected_map],
        "extra": [selected_map[k] for k in selected_map if k not in wanted_map],
    }


async def _dds_multiselect_snapshot(page: Page, selector: str) -> Dict[str, Any]:
    try:
        result = await page.evaluate(r"""
(selector) => {
  const input=document.querySelector(selector);
  const dd=input && input.closest('dds-dropdown');
  if(!input || !dd) return {found:false, list_id:'', expanded:false, search_value:'', options:[], selected_labels:[]};
  const clean=v=>String(v||'').replace(/\s+/g,' ').trim();
  const listId=input.getAttribute('aria-controls') || '';
  const list=(listId && document.getElementById(listId)) || dd.querySelector('[role=listbox],.dds__dropdown__list');
  const optionRoot=list || dd;
  const optionEls=Array.from(optionRoot.querySelectorAll('[role=option],button.dds__dropdown__item-option,.dds__dropdown__item-option'));
  const options=optionEls.map((el,index)=>{
    const iconSelected=!!el.querySelector('.dds__dropdown__item-selected,[class*="item-selected"]');
    const selected=el.getAttribute('aria-selected')==='true' || el.getAttribute('data-selected')==='true' || el.getAttribute('aria-checked')==='true' || iconSelected;
    let token=el.getAttribute('data-hip-option-token') || '';
    if(!token){token=`hip-opt-${Date.now()}-${index}-${Math.random().toString(36).slice(2,8)}`;el.setAttribute('data-hip-option-token',token);}
    return {
      text:clean(el.innerText||el.textContent),
      selected,
      disabled:el.getAttribute('aria-disabled')==='true' || !!el.disabled,
      id:el.id||'',
      aria_posinset:el.getAttribute('aria-posinset')||'',
      aria_setsize:el.getAttribute('aria-setsize')||'',
      token
    };
  });
  const selectedLabels=[];
  for(const el of Array.from(dd.querySelectorAll('.dds__tag,.dds__chip,[class*="selected-value"],[class*="selection__label"]'))){
    const text=clean(el.innerText||el.textContent);
    if(text && !/^\d+\s+selected$/i.test(text) && !selectedLabels.some(x=>x.toLowerCase()===text.toLowerCase())) selectedLabels.push(text);
  }
  const popup=dd.querySelector('.dds__dropdown__popup,[role=presentation]');
  const popupHidden=!!(popup && (popup.classList.contains('dds__dropdown__popup--hidden') || popup.getAttribute('aria-hidden')==='true'));
  const selectionMode = clean(dd.getAttribute('selection') || input.getAttribute('aria-multiselectable') || '');
  const isMultiple = selectionMode.toLowerCase()==='multiple' || input.getAttribute('aria-multiselectable')==='true' || !!dd.querySelector('.dds__dropdown--is-multiple');
  const loadingEls=Array.from(dd.querySelectorAll('[aria-busy=true],.dds__loading,.dds__spinner,[class*=loading],[class*=spinner]'));
  const visibleLoading=loadingEls.some(el=>{const r=el.getBoundingClientRect();const s=getComputedStyle(el);return !!(r.width&&r.height&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||'1')!==0);});
  const loading = input.getAttribute('aria-busy')==='true' || dd.getAttribute('aria-busy')==='true' || visibleLoading;
  const setSizes=options.map(x=>parseInt(x.aria_setsize||'0',10)).filter(x=>Number.isFinite(x)&&x>0);
  const declaredSetSize=setSizes.length?Math.max(...setSizes):0;
  const summary=clean(dd.innerText||dd.textContent);
  const countMatch=summary.match(/(\d+)\s+selected/i);
  return {
    found:true,
    list_id:(list&&list.id)||listId,
    expanded:input.getAttribute('aria-expanded')==='true' || !popupHidden,
    search_value:String(input.value||''),
    options,
    selected_labels:selectedLabels,
    summary_text:summary,
    selection_mode:isMultiple?'multiple':'single',
    loading,
    declared_set_size:declaredSetSize,
    visible_option_count:options.length,
    selected_count_summary:countMatch?parseInt(countMatch[1],10):null,
    has_select_all:options.some(x=>clean(x.text).toLowerCase()==='select all')
  };
}
""", selector)
        return dict(result or {}) if isinstance(result, dict) else {}
    except Exception:
        return {}


async def _selected_multiselect_values(page: Page, selector: str) -> List[str]:
    return _multiselect_selected_values_from_snapshot(await _dds_multiselect_snapshot(page, selector))


async def _open_dds_multiselect(page: Page, selector: str, backend: Any) -> Dict[str, Any]:
    snapshot = await _dds_multiselect_snapshot(page, selector)
    if snapshot.get("expanded") and snapshot.get("options"):
        return snapshot
    loc = page.locator(selector).first
    try:
        if backend is not None:
            await backend.click(selector, element="HIP Portal DDS multi-select")
        else:
            await loc.click(timeout=2200)
    except Exception:
        try:
            await loc.click(timeout=2200)
        except Exception:
            return snapshot
    await page.wait_for_timeout(220)
    return await _dds_multiselect_snapshot(page, selector)


async def _set_dds_multiselect_search(page: Page, selector: str, value: str, backend: Any) -> None:
    """Set only the search text without deleting selected DDS chips.

    Backspace/Delete on an empty DDS multi-select input removes the most recently
    selected chip.  Only clear when the input actually contains search text, and
    use ``fill('')`` rather than a destructive key on an empty input.
    """
    loc = page.locator(selector).first
    try:
        current = str(await loc.input_value(timeout=1200) or "")
    except Exception:
        current = ""
    target = str(value or "")
    if current == target:
        return
    if current:
        try:
            await loc.fill("")
        except Exception:
            if backend is not None:
                await backend.press(selector, "Control+A", element="HIP Portal DDS multi-select search")
                await backend.press(selector, "Backspace", element="HIP Portal DDS multi-select search")
    if target:
        if backend is not None:
            try:
                await backend.fill(selector, target, element="HIP Portal DDS multi-select search")
            except Exception:
                await loc.fill(target)
        else:
            await loc.fill(target)
    await page.wait_for_timeout(220)


async def _click_dds_multiselect_option(
    page: Page, selector: str, value: str, backend: Any, *, phase: str = ""
) -> bool:
    if not selector:
        return False
    loc = page.locator(selector).first
    try:
        resolution, loc, selector, _ = await _semantic_prepare(
            page, action="select", selector=selector,
            label=f"HIP Portal multi-select option {value}", phase=phase, locator=loc
        )
    except Exception:
        return False
    clicked = False
    if backend is not None:
        try:
            await backend.click(selector, element=f"HIP Portal multi-select option {value}")
            clicked = True
        except Exception:
            clicked = False
    if not clicked:
        try:
            if await loc.count() == 1 and await loc.first.is_visible(timeout=900):
                await loc.first.click(timeout=2400)
                clicked = True
        except Exception:
            clicked = False
    if not clicked:
        return False
    try:
        await page.wait_for_timeout(100)
        await _semantic_commit(page, resolution=resolution, action="select", exact_value_verified=False, phase=phase)
        return True
    except Exception:
        return False


async def _publish_multiselect_audit(page: Page, audit: Dict[str, Any]) -> None:
    try:
        await page.evaluate("audit => { window.__HIP_LAST_MULTISELECT_AUDIT = audit; }", audit)
    except Exception:
        pass


async def read_last_multiselect_audit(page: Page) -> Dict[str, Any]:
    try:
        result = await page.evaluate("() => window.__HIP_LAST_MULTISELECT_AUDIT || {}")
        return dict(result or {}) if isinstance(result, dict) else {}
    except Exception:
        return {}


async def _wait_dds_multiselect_snapshot_stable(
    page: Page,
    selector: str,
    *,
    timeout_ms: int = 2600,
    stable_samples: int = 2,
) -> Dict[str, Any]:
    """Wait until selection and option-universe state stop changing."""
    deadline = asyncio.get_running_loop().time() + max(0.3, timeout_ms / 1000.0)
    previous = None
    stable = 0
    last: Dict[str, Any] = {}
    samples = 0
    while asyncio.get_running_loop().time() < deadline:
        samples += 1
        last = await _dds_multiselect_snapshot(page, selector)
        selected = sorted(x.lower() for x in _multiselect_selected_values_from_snapshot(last))
        options = sorted(
            (re.sub(r"\s+", " ", str(x.get("text") or "").strip()).lower(), bool(x.get("selected")), bool(x.get("disabled")))
            for x in last.get("options", []) if isinstance(x, dict)
        )
        digest = (tuple(selected), tuple(options), bool(last.get("loading")), str(last.get("search_value") or ""))
        if digest == previous and not last.get("loading"):
            stable += 1
        else:
            stable = 1 if not last.get("loading") else 0
        previous = digest
        if stable >= stable_samples:
            return {**last, "option_universe_stable": True, "stability_samples": samples, "consecutive_samples": stable}
        await page.wait_for_timeout(90)
    return {**last, "option_universe_stable": False, "stability_samples": samples, "consecutive_samples": stable}


async def set_checkbox_value(
    page: Page,
    selector: str,
    desired: bool,
    *,
    label: str = "",
    phase: str = "",
) -> bool:
    """Set a checkbox/switch through semantic proof + Playwright MCP first."""
    if not selector:
        return False
    await _ensure_page_interactable(page, action=f"set checkbox {label or selector}", selector=selector)
    loc = page.locator(selector).first
    if not await loc.count():
        return False
    try:
        resolution, loc, selector, _ = await _semantic_prepare(
            page, action="select", selector=selector,
            label=f"HIP Portal checkbox {label or selector}", phase=phase, locator=loc
        )
    except Exception:
        return False
    try:
        current = await loc.is_checked(timeout=1200)
    except Exception:
        try:
            current = str(await loc.get_attribute("aria-checked") or "").lower() == "true"
        except Exception:
            return False
    if bool(current) != bool(desired):
        await _autowebglm_primary_gate(
            page, action="click", selector=selector, label=f"HIP Portal checkbox {label or selector}", value=str(bool(desired)).lower()
        )
        backend = getattr(page, "_hip_playwright_mcp_backend", None)
        try:
            if backend is not None:
                await backend.click(selector, element=f"HIP Portal checkbox {label or selector}")
            elif str(await loc.get_attribute("type") or "").lower() == "checkbox":
                await loc.set_checked(bool(desired), timeout=2400)
            else:
                await loc.click(timeout=2400)
        except Exception:
            try:
                await loc.click(timeout=2400)
            except Exception:
                return False
    await page.wait_for_timeout(160)
    try:
        checked = await loc.is_checked(timeout=1200)
    except Exception:
        checked = str(await loc.get_attribute("aria-checked") or "").lower() == "true"
    exact = bool(checked) == bool(desired)
    if exact:
        try:
            await _semantic_commit(page, resolution=resolution, action="select", exact_value_verified=True, phase=phase)
        except Exception:
            return False
    return exact


async def select_dds_multiselect(
    page: Page,
    root: Locator | None,
    selector: str,
    values: List[str],
    *,
    phase: str = "",
) -> bool:
    """Commit an exact set in a DDS ``selection=multiple`` dropdown.

    Contract:
    * one explicit exact option click per delta item;
    * no blind Enter, Select All, bulk clear, or empty-search Backspace;
    * previously requested selections are preserved after every additive click;
    * extra selections are removed only by clicking the exact selected option;
    * the popup is reopened for an authoritative aria/data-selected verification.
    """
    wanted: List[str] = []
    duplicate_inputs: List[str] = []
    seen: set[str] = set()
    for value in values or []:
        text = re.sub(r"\s+", " ", str(value or "").strip())
        low = text.lower()
        if not text:
            continue
        if low == "select all" or re.fullmatch(r"\d+\s+selected", text, flags=re.I):
            await _publish_multiselect_audit(page, {"pass": False, "reason": "presentation or Select All value is not an explicit business selection", "requested": values})
            return False
        if low in seen:
            duplicate_inputs.append(text)
            continue
        seen.add(low)
        wanted.append(text)
    audit: Dict[str, Any] = {
        "schema_version": "hip.multiselect-transaction.v2",
        "selector": selector,
        "phase": phase,
        "requested": wanted,
        "duplicate_requested_values": duplicate_inputs,
        "actions": [],
        "pass": False,
    }
    if not selector or not wanted or duplicate_inputs:
        audit["reason"] = "selector/values missing or duplicate requested values"
        await _publish_multiselect_audit(page, audit)
        return False
    await _ensure_page_interactable(page, action="select DDS multi-select exact set", selector=selector)
    loc = page.locator(selector).first
    if not await loc.count():
        audit["reason"] = "multi-select input not found"
        await _publish_multiselect_audit(page, audit)
        return False
    semantic_resolution, loc, selector, semantic_revalidation = await _semantic_prepare(
        page, action="select", selector=selector,
        label=f"HIP Portal DDS multi-select ({phase or 'form'})", phase=phase, locator=loc
    )
    audit["semantic_gate"] = {
        "semantic_control_id": semantic_resolution.get("semantic_control_id") or "",
        "confidence": semantic_resolution.get("confidence"),
        "margin": semantic_resolution.get("margin"),
        "status": semantic_resolution.get("status") or "",
        "revalidation": semantic_revalidation.get("status") or "",
    }
    backend = getattr(page, "_hip_playwright_mcp_backend", None)

    initial = await _open_dds_multiselect(page, selector, backend)
    initial = await _wait_dds_multiselect_snapshot_stable(page, selector)
    if not initial.get("selection_mode") and initial.get("found") and initial.get("options"):
        # Compatibility for injected/test backends that predate the richer DDS
        # snapshot. The public function itself is the multi-select-only executor,
        # and the shared semantic resolver has already required selection=multiple.
        initial["selection_mode"] = "multiple"
        initial["selection_mode_inference"] = "multiselect-executor-contract"
    audit["initial_snapshot"] = initial
    if not initial.get("found") or initial.get("selection_mode") != "multiple":
        audit["reason"] = "target control is not proven to be selection=multiple"
        await close_open_dropdown(page, phase)
        await _publish_multiselect_audit(page, audit)
        return False
    if not initial.get("option_universe_stable"):
        audit["reason"] = "multi-select option universe did not stabilize"
        await close_open_dropdown(page, phase)
        await _publish_multiselect_audit(page, audit)
        return False

    # Reconcile over bounded rerender cycles; every selector is reacquired from a
    # fresh snapshot because DDS often replaces option nodes after each click.
    for cycle in range(4):
        snapshot = await _open_dds_multiselect(page, selector, backend)
        snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
        selected = _multiselect_selected_values_from_snapshot(snapshot)
        delta = _multiselect_delta(wanted, selected)
        audit["actions"].append({"cycle": cycle + 1, "selected_before": selected, "delta": delta})
        if not delta["missing"] and not delta["extra"]:
            break

        # Remove extras one at a time by exact selected-option click. Never use
        # search-input deletion because empty Backspace removes the last chip.
        for extra in list(delta["extra"]):
            snapshot = await _open_dds_multiselect(page, selector, backend)
            snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
            before_selected = _multiselect_selected_values_from_snapshot(snapshot)
            option = _find_multiselect_option(snapshot, extra)
            if option is None:
                await _set_dds_multiselect_search(page, selector, extra, backend)
                snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
                option = _find_multiselect_option(snapshot, extra)
            if option is None or not option.get("selected"):
                audit["reason"] = f"extra selected option not uniquely removable: {extra}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            option_selector = _unique_multiselect_option_selector(snapshot, option)
            if option_selector:
                await _autowebglm_primary_gate(
                    page, action="click", selector=option_selector, label=f"HIP Portal multi-select remove {extra}", value=extra
                )
            if not option_selector or not await _click_dds_multiselect_option(page, option_selector, extra, backend, phase=phase):
                audit["reason"] = f"failed explicit removal click: {extra}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            after = await _wait_dds_multiselect_snapshot_stable(page, selector)
            after_selected = _multiselect_selected_values_from_snapshot(after)
            preserved = {x.lower() for x in before_selected if x.lower() != extra.lower()}
            if extra.lower() in {x.lower() for x in after_selected} or not preserved.issubset({x.lower() for x in after_selected}):
                audit["reason"] = f"removal transaction changed unintended selections: {extra}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            audit["actions"].append({"action": "remove_extra", "value": extra, "selected_after": after_selected})

        for value in list(delta["missing"]):
            snapshot = await _open_dds_multiselect(page, selector, backend)
            snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
            before_selected = _multiselect_selected_values_from_snapshot(snapshot)
            option = _find_multiselect_option(snapshot, value)
            if option is None:
                await _set_dds_multiselect_search(page, selector, value, backend)
                snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
                option = _find_multiselect_option(snapshot, value)
            if option is None:
                audit["reason"] = f"exact option not found after stable search: {value}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            if option.get("disabled"):
                audit["reason"] = f"requested option is disabled: {value}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            if re.sub(r"\s+", " ", str(option.get("text") or "").strip()).lower() == "select all":
                audit["reason"] = "Select All is forbidden for explicit exact-set replay"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            option_selector = _unique_multiselect_option_selector(snapshot, option)
            await _autowebglm_primary_gate(
                page, action="select", selector=selector, label=f"HIP Portal multi-select ({phase or 'form'})", value=value
            )
            if not option_selector or not await _click_dds_multiselect_option(page, option_selector, value, backend, phase=phase):
                audit["reason"] = f"failed explicit option click: {value}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            after = await _wait_dds_multiselect_snapshot_stable(page, selector)
            after_selected = _multiselect_selected_values_from_snapshot(after)
            before_set = {x.lower() for x in before_selected}
            after_set = {x.lower() for x in after_selected}
            if value.lower() not in after_set or not before_set.issubset(after_set):
                audit["reason"] = f"additive selection proof failed: {value}"
                await close_open_dropdown(page, phase)
                await _publish_multiselect_audit(page, audit)
                return False
            audit["actions"].append({"action": "add_missing", "value": value, "selected_after": after_selected})
            await _set_dds_multiselect_search(page, selector, "", backend)

    final_snapshot = await _open_dds_multiselect(page, selector, backend)
    final_snapshot = await _wait_dds_multiselect_snapshot_stable(page, selector)
    if not final_snapshot.get("selection_mode") and final_snapshot.get("found") and final_snapshot.get("options"):
        final_snapshot["selection_mode"] = "multiple"
        final_snapshot["selection_mode_inference"] = "multiselect-executor-contract"
    selected = _multiselect_selected_values_from_snapshot(final_snapshot)
    wanted_set = {x.lower() for x in wanted}
    selected_set = {x.lower() for x in selected}
    summary_count = final_snapshot.get("selected_count_summary")
    count_match = summary_count in (None, len(selected)) and len(selected) == len(wanted)
    exact = bool(
        final_snapshot.get("selection_mode") == "multiple"
        and final_snapshot.get("option_universe_stable")
        and wanted_set == selected_set
        and count_match
    )
    audit.update({
        "final_snapshot": final_snapshot,
        "selected": selected,
        "missing": [x for x in wanted if x.lower() not in selected_set],
        "extra": [x for x in selected if x.lower() not in wanted_set],
        "selected_count_match": count_match,
        "pass": exact,
        "reason": "exact normalized multi-select set committed" if exact else "final authoritative exact-set proof failed",
    })
    await close_open_dropdown(page, phase)
    await _publish_multiselect_audit(page, audit)
    try:
        await page.evaluate(r"""
(selector) => {const el=document.querySelector(selector);if(el){el.removeAttribute('data-hip-locked-value');el.removeAttribute('data-hip-locked-at');}}
""", selector)
    except Exception:
        pass
    if exact:
        effect = await _semantic_commit(
            page, resolution=semantic_resolution, action="select", exact_value_verified=True, phase=phase
        )
        audit["semantic_effect"] = {
            "pass": bool(effect.get("pass")),
            "type": effect.get("effect_type") or "",
            "confidence": effect.get("confidence"),
        }
        await _publish_multiselect_audit(page, audit)
    return exact


async def set_boolean_control(
    page: Page,
    root: Locator | None,
    selector: str,
    value: str | bool,
    *,
    phase: str = "",
) -> bool:
    """Set a checkbox/switch/toggle to the requested boolean state and verify it.

    The helper is deliberately selector-bound: it never searches for a generic
    Yes/No control elsewhere on the page.  This is important on BizFlow where
    several independent switches/checkboxes are visible at once.
    """
    if not selector:
        return False
    normalized = re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")
    truthy = {"1", "true", "yes", "on", "enable", "enabled", "not_disabled"}
    falsy = {"0", "false", "no", "off", "disable", "disabled", "not_enabled", "not_enable"}
    if isinstance(value, bool):
        desired = bool(value)
    elif normalized in truthy:
        desired = True
    elif normalized in falsy:
        desired = False
    else:
        return False
    await _ensure_page_interactable(page, action=f"set boolean control {desired}", selector=selector)
    loc = page.locator(selector).first
    if not await loc.count():
        return False
    try:
        semantic_resolution, loc, selector, semantic_revalidation = await _semantic_prepare(
            page, action="select", selector=selector,
            label=f"HIP Portal boolean control ({phase or 'form'})", phase=phase, locator=loc
        )
    except Exception:
        return False

    async def _checked() -> bool | None:
        try:
            loc = page.locator(selector).first
            if not await loc.count():
                return None
            return bool(await loc.evaluate("el => !!el.checked || el.getAttribute('aria-checked')==='true' || el.getAttribute('data-checked')==='true'"))
        except Exception:
            return None

    current = await _checked()
    if current is None:
        return False
    if current == desired:
        return True
    backend = getattr(page, "_hip_playwright_mcp_backend", None)
    try:
        if backend is not None:
            await backend.click(selector, element=f"HIP Portal boolean control -> {desired}")
        else:
            await page.locator(selector).first.click(timeout=2400)
    except Exception:
        try:
            await page.evaluate("""({selector}) => {
              const el=document.querySelector(selector); if(!el) return false;
              const clickable=el.closest('label,dds-switch,dds-checkbox')?.querySelector('input,[role=\"switch\"],[role=\"checkbox\"]') || el;
              clickable.click(); return true;
            }""", {"selector": selector})
        except Exception:
            return False
    await page.wait_for_timeout(180)
    exact = (await _checked()) == desired
    if exact:
        try:
            await _semantic_commit(page, resolution=semantic_resolution, action="select", exact_value_verified=True, phase=phase)
        except Exception:
            return False
    return exact


async def select_radio_value(
    page: Page,
    root: Locator | None,
    value: str,
    *,
    section: str = "",
    phase: str = "",
) -> bool:
    """Click and verify a visible radio by its semantic label."""
    target=re.sub(r"\s+", " ", str(value or "").strip())
    if not target:
        return False
    await _ensure_page_interactable(page, action=f"select radio {target}")
    try:
        found=await page.evaluate(r"""
({value,section}) => {
  const clean=v=>String(v||'').replace(/\s+/g,' ').trim();
  const low=clean(value).toLowerCase();
  const sec=clean(section).toLowerCase();
  function visible(el){const host=el.closest('label,.dds__radio-button,[role=radio]')||el;const r=host.getBoundingClientRect();const s=getComputedStyle(host);return !!(r.width&&r.height&&s.display!=='none'&&s.visibility!=='hidden');}
  function css(el){if(el.id)return `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}`;const p=[];let n=el;while(n&&n.nodeType===1&&p.length<8){let x=n.tagName.toLowerCase();const par=n.parentElement;if(par){const same=Array.from(par.children).filter(y=>y.tagName===n.tagName);if(same.length>1)x+=`:nth-of-type(${same.indexOf(n)+1})`;}p.unshift(x);n=par;}return p.join(' > ');}
  const rows=Array.from(document.querySelectorAll('input[type=radio],[role=radio]')).filter(visible).map(el=>{const lab=el.id?document.querySelector(`label[for="${CSS.escape(el.id)}"]`):el.closest('label');const text=clean((lab&&(lab.innerText||lab.textContent))||el.getAttribute('aria-label')||el.value||'');const fs=el.closest('fieldset');const legend=clean(fs&&fs.querySelector('legend')&&(fs.querySelector('legend').innerText||fs.querySelector('legend').textContent));return {selector:css(el),text,section:legend};});
  return rows.find(x=>(!sec||x.section.toLowerCase().includes(sec)||sec.includes(x.section.toLowerCase()))&&(x.text.toLowerCase()===low||x.text.toLowerCase().includes(low)||low.includes(x.text.toLowerCase())))||null;
}
""", {"value": target, "section": section})
        if not found or not found.get("selector"):
            return False
        selector=str(found["selector"])
        try:
            semantic_resolution, radio_loc, selector, semantic_revalidation = await _semantic_prepare(
                page, action="select", selector=selector, label=f"HIP Portal radio {target}",
                phase=phase, locator=page.locator(selector).first
            )
        except Exception:
            return False
        await _autowebglm_primary_gate(
            page, action="click", selector=selector, label=f"HIP Portal radio {target}", value=target
        )
        backend=getattr(page, "_hip_playwright_mcp_backend", None)
        if backend is not None:
            try:
                await backend.click(selector, element=f"HIP Portal radio {target}")
            except Exception:
                await radio_loc.click(timeout=2200)
        else:
            await radio_loc.click(timeout=2200)
        await page.wait_for_timeout(180)
        checked=await radio_loc.evaluate("el => !!el.checked || el.getAttribute('aria-checked')==='true'")
        if bool(checked):
            await _semantic_commit(page, resolution=semantic_resolution, action="select", exact_value_verified=True, phase=phase)
        return bool(checked)
    except Exception:
        return False
