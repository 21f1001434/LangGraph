from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Mapping

from .governance import redact


def _e(v: Any) -> str:
    return html.escape(str(v if v is not None else ""), quote=True)


def _status(row: Mapping[str, Any]) -> tuple[str, str]:
    s = str(row.get("status") or "")
    if s == "GOOD_TO_TRIGGER": return "GOOD TO GO", "good"
    if s == "NEEDS_INPUT": return "NEEDS INPUT", "needs"
    return "NOT READY", "blocked"


def _items(values: Iterable[Any]) -> str:
    rows = [str(x) for x in values if str(x or "").strip()]
    return "<ul>" + "".join(f"<li>{_e(x)}</li>" for x in rows) + "</ul>" if rows else '<span class="muted">None</span>'


def _mapping_rows(row: Mapping[str, Any]) -> str:
    sensitive = set(str(x) for x in ((row.get("contractSnapshot") or {}).get("sensitive_paths") or []))
    data = []
    for m in row.get("mappings") or []:
        path = str(m.get("targetPath") or "")
        source_value = "<redacted>" if path in sensitive else m.get("sourceValue")
        mapped_value = "<redacted>" if path in sensitive else m.get("mappedValue")
        data.append(
            "<tr>"
            f"<td><b>{_e(m.get('sourceColumn'))}</b><small>{_e(source_value)}</small></td>"
            f"<td><code>{_e(path)}</code></td>"
            f"<td>{_e(mapped_value)}</td>"
            f"<td>{round(float(m.get('confidence') or 0)*100)}%</td>"
            f"<td>{_e(m.get('method'))}</td>"
            "</tr>"
        )
    return "".join(data) or '<tr><td colspan="5" class="muted">No safe mappings.</td></tr>'


def _unmapped_rows(row: Mapping[str, Any]) -> str:
    details = row.get("unmappedDetails") or []
    return "".join(
        "<tr>"
        f"<td><b>{_e(x.get('column'))}</b><small>{_e(x.get('value'))}</small></td>"
        f'<td><span class="tag">{_e(x.get("classification"))}</span></td>'
        f"<td>{_e(x.get('reason'))}</td>"
        "</tr>" for x in details
    ) or '<tr><td colspan="3" class="muted">None.</td></tr>'


def _check_rows(row: Mapping[str, Any]) -> str:
    out=[]
    for x in row.get("readinessChecks") or []:
        status=str(x.get("status") or "")
        cls="good" if status in {"PASS", "OPTIONAL"} else ("needs" if status=="REVIEW" else "blocked")
        out.append(
            "<tr>"
            f"<td><b>{_e(x.get('name'))}</b></td>"
            f'<td><span class="status {cls}">{_e(status)}</span></td>'
            f"<td>{_e(x.get('detail'))}</td>"
            f"<td>{_e('YES' if x.get('blocking') else 'NO')}</td>"
            "</tr>"
        )
    return "".join(out) or '<tr><td colspan="4" class="muted">No readiness checks recorded.</td></tr>'


def _field_matrix_rows(row: Mapping[str, Any]) -> str:
    sensitive=set(str(x) for x in ((row.get("contractSnapshot") or {}).get("sensitive_paths") or []))
    out=[]
    for x in row.get("fieldMatrix") or []:
        path=str(x.get("path") or "")
        value="<redacted>" if path in sensitive else x.get("value")
        source_value="<redacted>" if path in sensitive else x.get("sourceValue")
        state=str(x.get("state") or "")
        cls="good" if state=="OK" else ("needs" if state=="MISSING" else "")
        suggestions=", ".join(str(v) for v in (x.get("suggestedExcelColumns") or []))
        out.append(
            "<tr>"
            f"<td><code>{_e(path)}</code><small>{_e(x.get('field'))}</small></td>"
            f"<td>{_e('YES' if x.get('required') else 'NO')}</td>"
            f"<td>{_e(value)}</td>"
            f"<td><span class=\"tag {cls}\">{_e(x.get('sourceType'))}</span><small>{_e(x.get('sourceColumn'))}{(' · '+_e(source_value)) if str(source_value or '') else ''}</small></td>"
            f"<td>{_e(suggestions)}</td>"
            "</tr>"
        )
    return "".join(out) or '<tr><td colspan="5" class="muted">No field inventory recorded.</td></tr>'


def _diagnostic_summary(analysis: Mapping[str, Any]) -> str:
    diag=analysis.get("diagnosticsSummary") or {}
    blockers=diag.get("topBlockers") or []
    ifaces=diag.get("interfaceMappings") or []
    blocker_html="".join(f'<div class="diag-item"><b>{_e(x.get("count"))}</b><span>{_e(x.get("check"))}</span></div>' for x in blockers[:8]) or '<span class="muted">No blocking checks.</span>'
    iface_html="".join(f'<div class="diag-item"><b>{_e(x.get("count"))}</b><span>{_e(x.get("excelValue"))} → {_e(x.get("apiValue") or "unrecognized")}</span></div>' for x in ifaces[:8]) or '<span class="muted">No interface values.</span>'
    return f'<div class="two-col"><div class="callout"><h3>Top readiness blockers</h3><div class="diag-grid">{blocker_html}</div></div><div class="callout"><h3>Excel interface → API interface</h3><div class="diag-grid">{iface_html}</div></div></div>'


def render_tp_readiness_report(analysis: Mapping[str, Any]) -> str:
    summary = analysis.get("summary") or {}
    actions = analysis.get("tpActions") or analysis.get("allApiResults") or analysis.get("results") or []
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    file = analysis.get("file") or {}
    llm = analysis.get("llm") or {}
    source_rows = []
    details = []
    for idx, row in enumerate(actions, start=1):
        label, cls = _status(row)
        blockers = row.get("blockers") or row.get("missingRequiredPaths") or []
        source_rows.append(
            "<tr>"
            f"<td>{_e(row.get('sheetName'))}!{_e(row.get('excelRow'))}</td>"
            f"<td><b>{_e(row.get('customerName') or row.get('lensTpName'))}</b></td>"
            f"<td>{_e(row.get('applicationTracking'))}</td>"
            f"<td><b>{_e(row.get('hipAccountName') or row.get('account'))}</b></td>"
            f"<td>{_e(row.get('tpRole'))}</td>"
            f"<td><b>{_e(row.get('tpName'))}</b><small>{_e(row.get('lensTpName'))}</small></td>"
            f"<td>{_e(row.get('systemName'))}</td>"
            f"<td>{_e(row.get('interfaceType'))}<small>Excel: {_e(row.get('interfaceRawValue'))} · {_e(row.get('interfaceSourceColumn'))}</small></td>"
            f"<td>{_e(row.get('documentTypeName'))}</td>"
            f"<td>{_e(row.get('mappedCount'))}</td>"
            f"<td><b>{_e(row.get('score'))}</b>/100</td>"
            f'<td><span class="status {cls}">{label}</span></td>'
            f"<td>{_e('; '.join(str(x) for x in blockers[:3]))}</td>"
            "</tr>"
        )
        contract = row.get("contractSnapshot") or {}
        safe_payload = redact(row.get("proposedRequest") or {}, contract.get("sensitive_paths") or [])
        details.append(f"""
        <section class="detail-card" id="action-{idx}">
          <div class="detail-head">
            <div><span class="eyebrow">TP candidate {idx}</span><h2>{_e(row.get('hipAccountName') or row.get('account'))} · {_e(row.get('tpName') or 'Unnamed TP')}</h2>
              <p>{_e(row.get('sheetName'))}!{_e(row.get('excelRow'))} · {_e(row.get('tpRole'))} · {_e(row.get('interfaceType'))}</p></div>
            <span class="status {cls}">{label} · {_e(row.get('score'))}/100</span>
          </div>
          <div class="facts">
            <div><span>Customer</span><b>{_e(row.get('customerName') or row.get('lensTpName'))}</b></div>
            <div><span>Application</span><b>{_e(row.get('applicationTracking'))}</b></div>
            <div><span>System</span><b>{_e(row.get('systemName'))}</b></div>
            <div><span>Document type</span><b>{_e(row.get('documentTypeName'))}</b></div>
            <div><span>HIP account</span><b>{_e(row.get('hipAccountName'))}</b></div>
            <div><span>Interface from Excel</span><b>{_e(row.get('interfaceRawValue'))}</b><small>{_e(row.get('interfaceSourceColumn'))}</small></div>
            <div><span>Interface family</span><b>{_e(row.get('interfaceFamily'))}</b></div>
          </div>
          <div class="two-col">
            <div class="callout"><h3>Decision reasons / blockers</h3><p><b>{_e(row.get('decisionReason'))}</b></p>{_items(blockers)}</div>
            <div class="callout"><h3>Warnings</h3>{_items(row.get('warnings') or [])}</div>
          </div>
          <h3>Readiness checks</h3>
          <table><thead><tr><th>Check</th><th>Status</th><th>Detail</th><th>Blocking</th></tr></thead><tbody>{_check_rows(row)}</tbody></table>
          <h3>Excel → TP payload mapping</h3>
          <table><thead><tr><th>Excel evidence</th><th>Canonical TP path</th><th>Mapped value</th><th>Confidence</th><th>Mapper</th></tr></thead><tbody>{_mapping_rows(row)}</tbody></table>
          <h3>Complete TP API field coverage</h3>
          <p class="muted">Every canonical leaf is shown below, including values from Excel, V122 contract defaults, role-derived values, runtime values, optional blanks and missing required fields.</p>
          <div style="overflow:auto"><table><thead><tr><th>TP API field/path</th><th>Required</th><th>Final value</th><th>Value source</th><th>Expected Excel column(s)</th></tr></thead><tbody>{_field_matrix_rows(row)}</tbody></table></div>
          <h3>Excel fields not injected into TP payload</h3>
          <table><thead><tr><th>Excel evidence</th><th>Classification</th><th>Reason</th></tr></thead><tbody>{_unmapped_rows(row)}</tbody></table>
          <details><summary>Schema-locked proposed TP request</summary><pre>{_e(json.dumps(safe_payload, indent=2, ensure_ascii=False, default=str))}</pre></details>
          <p class="contract-note">Contract: {_e(row.get('apiKey'))} · v{_e(row.get('contractVersion'))} · {_e(row.get('interfaceReference'))}</p>
        </section>
        """)

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TP Readiness Report · {_e(analysis.get('analysisId'))}</title>
<style>
:root{{--ink:#172033;--muted:#667085;--line:#e4e7ec;--panel:#fff;--bg:#f7f9fc;--blue:#175cd3;--green:#027a48;--greenbg:#ecfdf3;--amber:#b54708;--amberbg:#fffaeb;--red:#b42318;--redbg:#fef3f2}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 Inter,Segoe UI,Arial,sans-serif}} .page{{max-width:1500px;margin:auto;padding:36px}}
.hero{{background:linear-gradient(135deg,#101828,#1d2939 55%,#1849a9);color:white;border-radius:22px;padding:30px 34px;box-shadow:0 18px 45px #10182822}} .hero h1{{font-size:32px;margin:5px 0}} .hero p{{margin:0;color:#d0d5dd}}
.eyebrow{{font-size:11px;text-transform:uppercase;letter-spacing:.14em;font-weight:800;color:#84adff}} .metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:18px 0 24px}} .metric{{background:white;border:1px solid var(--line);border-radius:16px;padding:18px}} .metric span{{display:block;color:var(--muted);font-size:12px}} .metric b{{font-size:28px}} .metric.good b{{color:var(--green)}} .metric.needs b{{color:var(--amber)}} .metric.blocked b{{color:var(--red)}}
.panel,.detail-card{{background:white;border:1px solid var(--line);border-radius:18px;padding:22px;margin:18px 0;box-shadow:0 8px 25px #1018280a}} .panel h2,.detail-card h2{{margin:0 0 4px}} .muted,small{{display:block;color:var(--muted);font-size:12px}}
table{{width:100%;border-collapse:collapse;font-size:12px}} th{{text-align:left;color:#475467;background:#f9fafb;border-bottom:1px solid var(--line);padding:10px;white-space:nowrap}} td{{padding:10px;border-bottom:1px solid #f0f1f3;vertical-align:top}} code{{font-family:Consolas,monospace;font-size:11px}} .status{{display:inline-block;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:800;white-space:nowrap}} .status.good{{background:var(--greenbg);color:var(--green)}} .status.needs{{background:var(--amberbg);color:var(--amber)}} .status.blocked{{background:var(--redbg);color:var(--red)}}
.detail-head{{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}} .detail-head p{{margin:0;color:var(--muted)}} .facts{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}} .facts div{{background:#f9fafb;border:1px solid var(--line);border-radius:12px;padding:12px}} .facts span{{display:block;color:var(--muted);font-size:11px}} .two-col{{display:grid;grid-template-columns:1fr 1fr;gap:12px}} .callout{{background:#f9fafb;border-radius:12px;padding:12px 16px}} .callout h3{{margin:0 0 5px}} .callout ul{{margin:6px 0;padding-left:18px}} .tag{{font-size:10px;font-weight:800;background:#eef4ff;color:#3538cd;border-radius:999px;padding:4px 7px}} .tag.good{{background:var(--greenbg);color:var(--green)}} .tag.needs{{background:var(--amberbg);color:var(--amber)}} .diag-grid{{display:grid;gap:8px}} .diag-item{{display:flex;gap:10px;align-items:center;padding:8px 10px;border:1px solid var(--line);border-radius:10px;background:white}} .diag-item b{{min-width:34px;font-size:18px}} details{{margin-top:14px;border:1px solid var(--line);border-radius:12px;padding:10px 14px}} summary{{font-weight:700;cursor:pointer}} pre{{overflow:auto;background:#101828;color:#e4e7ec;border-radius:10px;padding:14px;font:11px/1.5 Consolas,monospace}} .contract-note{{color:var(--muted);font-size:11px}}
.footer{{color:var(--muted);font-size:11px;padding:18px 2px}} @media print{{body{{background:white}} .page{{max-width:none;padding:12px}} .hero,.panel,.detail-card{{box-shadow:none}} details{{break-inside:avoid}}}} @media(max-width:900px){{.metrics,.facts{{grid-template-columns:repeat(2,1fr)}}.two-col{{grid-template-columns:1fr}}.page{{padding:16px}}}}
</style></head><body><div class="page">
<section class="hero"><span class="eyebrow">Intelligent TP Excel Readiness Agent · V122 contract parity</span><h1>Transport Profile Readiness Report</h1><p>Workbook: {_e(file.get('name'))} · Analysis: {_e(analysis.get('analysisId'))} · Generated {generated}</p></section>
<section class="metrics"><div class="metric"><span>TP candidates</span><b>{_e(summary.get('tpActions', summary.get('rows',0)))}</b></div><div class="metric"><span>Accounts</span><b>{_e(summary.get('accounts',0))}</b></div><div class="metric good"><span>Good to go</span><b>{_e(summary.get('GOOD_TO_TRIGGER',0))}</b></div><div class="metric needs"><span>Needs input</span><b>{_e(summary.get('NEEDS_INPUT',0))}</b></div><div class="metric blocked"><span>Not ready</span><b>{_e(summary.get('DO_NOT_TRIGGER',0))}</b></div></section>
<section class="panel"><h2>Why records are / are not ready</h2>{_diagnostic_summary(analysis)}</section>
<section class="panel"><h2>Executive readiness view</h2><p class="muted"><b>Team-corrected provenance policy:</b> the API-facing Excel <code>Interface Type</code> is authoritative when present; legacy Source/Target Interface Type is only a fallback. <code>Directory</code> is never used as <code>Subscription Folder</code>. HIP Account is never used as FILE <code>Existing Account Name</code>. Document type stays empty when Excel has no document data. Only Good-to-Go TP actions should be staged for bulk execution.</p><div style="overflow:auto"><table><thead><tr><th>Excel</th><th>Customer</th><th>Application</th><th>HIP Account</th><th>TP role</th><th>TP name</th><th>System</th><th>Interface</th><th>Document type</th><th>Mapped</th><th>Score</th><th>Decision</th><th>Blocker / reason</th></tr></thead><tbody>{''.join(source_rows)}</tbody></table></div></section>
<section class="panel"><h2>Agent & governance evidence</h2><div class="facts"><div><span>Dell AIA</span><b>{_e('Used' if llm.get('used') else 'Deterministic fallback')}</b></div><div><span>Schema policy</span><b>TP attributes immutable</b></div><div><span>Execution</span><b>Human stage + preflight</b></div><div><span>Parallel LIVE</span><b>Good-to-Go only</b></div></div><p class="muted">Unmapped Excel evidence is retained in this report and is never converted into a new TP API attribute. Sensitive values are redacted from the HTML payload evidence.</p></section>
{''.join(details)}
<div class="footer">Generated by Intelligent TP Excel Readiness & Parallel Execution Agent. This report is decision evidence; LIVE execution remains governed by runtime allowlist, human staging, preflight and explicit confirmation.</div>
</div></body></html>"""
