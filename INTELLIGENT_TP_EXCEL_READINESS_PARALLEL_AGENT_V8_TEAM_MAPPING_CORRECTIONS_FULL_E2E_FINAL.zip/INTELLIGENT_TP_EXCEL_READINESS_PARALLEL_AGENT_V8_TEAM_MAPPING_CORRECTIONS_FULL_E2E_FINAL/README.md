# Intelligent TP Excel Readiness & Parallel Execution Agent — V8

Standalone Transport Profile (TP) Excel mapping, readiness, HTML reporting, health diagnostics, staging/preflight and controlled parallel HIP API execution.

V8 is the team-corrected build for the current SFTP/TP workbook.

## Current end-to-end flow

`Excel with multiple customers → detect TP sheet/header → read exact TP values → lock API-facing Interface Type → select approved V122 TP contract → exact/provenance-safe mapping → readiness checks → GOOD TO GO / NEEDS INPUT / NOT READY → per-customer UI + master/individual HTML reports → select Good TPs → stage → preflight → parallel LIVE`

The application remains standalone at runtime but keeps the same V122 environment/OAuth pattern and TP API contracts.

## V8 team corrections

### 1. API `interfaceType` uses the correct Excel field

When an exact generic `Interface Type` column exists, it is authoritative for TP API interface selection. This fixes rows where the legacy `Source Interface Type` contains values such as `Directory Monitor inbound` while the API-facing `Interface Type` contains `SFTP Server`.

Priority:

1. `Interface Type`
2. `TP Interface Type`
3. `API Interface Type`
4. only when none of those exists: role-specific `Source Interface Type` / `Target Interface Type`

Approved value canonicalization still applies only to the explicit interface cell, for example:

- `SFTP`, `SFTP Server`, `SFTP HAFT` → API `SFTP HAFT`
- `FTP`, `FTP Server` → API `FTP`
- `AS2`, `HTTPS-AS2` → API `HTTPS-AS2`
- `HTTPS`, `REST` → API `HTTPS`
- `NAS` → API `NAS`
- approved Rabbit MQ labels → API `Rabbit MQ`

The LLM cannot infer interface type from TP name, hostname, port, Directory, Delivery Type or any other column.

### 2. `Directory` is never `Subscription Folder`

This is now a hard provenance rule.

`Directory` remains evidence-only connectivity information. It is never written to:

`transportProfileDetails[0].interfaceDetails[0].parameters["Subscription Folder"]`

Subscription Folder is populated only from an explicit TP field such as:

- `Subscription Folder`
- `TP Subscription Folder`
- `Transport Profile Subscription Folder`
- an equivalent grouped Transport Profile Details / Subscription Folder column

If the Excel has no subscription folder, the payload leaves it empty. V8 does not invent or derive one from Directory.

### 3. HIP Account is never FILE `Existing Account Name`

`Hip Account names` is displayed as the HIP/business account in the UI/report, but is not reused as:

`transportProfileDetails[0].interfaceDetails[0].parameters["Existing Account Name"]`

Existing Account Name can come only from exact TP-specific evidence such as:

- `Existing Account Name`
- `TP Existing Account Name`
- `Transport Profile Account`
- `TP Account`
- the grouped Excel column under `Add > Transport Profile Details > Account`

This fixes the ATEA-style workbook where several different columns are all named `Account`.

### 4. Multi-row/grouped Excel headers are preserved

V8 understands repeated leaf headers by retaining the parent/group context from the rows above the detected header row.

For example, instead of losing all three columns as:

- `Account`
- `Account (2)`
- `Account (3)`

V8 can preserve labels such as:

- `Add > Partner Details > Account`
- `Add > Transport Profile Details > Account`

Only the Transport Profile Details account is eligible for FILE Existing Account Name.

### 5. `transportProfileName` does not require a DEV-prefixed field

The API field is simply:

`transportProfileDetails[0].transportProfileName`

V8 accepts exact Excel aliases including:

- `Transport Profile Name`
- `Source Transport Profile Name`
- `Target Transport Profile Name`
- `DEV-Transport Profile Name`
- `TP Name`

`DEV-Transport Profile Name` is only an Excel alias; it is not an API requirement. `LENS TP Name` remains customer/reference evidence and is not used as executable TP identity.

### 6. Document Type can be empty

Per team feedback, if document type data is not available, V8 leaves:

- `documentTypeName = ""`
- `documentTypeVersion = ""`

Document Type is not a hard readiness blocker for the current TP intake.

When Excel contains `NAME(1.0)`, V8 still safely splits it into separate API name/version fields. When Excel provides an explicit Document Type Version column, that explicit value takes precedence.

### 7. Core TP fields are provenance locked

The Dell AIA agent is advisory. The following leaves cannot be filled by semantic guessing:

- `systemName`
- `transportProfileName`
- `interfaceType`
- `documentTypeName`
- `documentTypeVersion`
- FILE `Subscription Folder`
- FILE `Existing Account Name`

They must come from approved exact Excel evidence, role/runtime values, or remain empty/blocked according to the contract.

## Readiness behavior

Core hard checks include:

- Interface provided
- Interface recognized
- TP role resolved
- System mapped
- transportProfileName mapped
- Interface Type mapped
- FILE Existing Account Name present when required
- protected-field provenance valid
- required interface parameters present
- schema lock valid
- field rules valid
- duplicate identity check
- mapping confidence

Document Type appears as `OPTIONAL` when absent and does not block readiness.

## UI / HTML report

For each customer/TP, V8 shows:

- Excel worksheet + row
- Customer / LENS TP
- Application Tracking
- HIP Account
- TP role
- transportProfileName
- System
- Excel API Interface Type + exact source column
- canonical API interfaceType
- TP Existing Account Name + exact source column
- Subscription Folder + exact source column / blank
- Document Type + version
- every Excel → payload mapping
- every canonical TP API field
- source type for every value
- readiness checklist
- blockers and warnings
- evidence-only fields such as Directory/SFTP server/port/authentication
- redacted final payload

Master HTML readiness report:

`GET /api/tp/analyses/{analysisId}/report.html`

Individual customer/TP report:

`GET /api/tp/analyses/{analysisId}/actions/{actionId}/report.html`

## Agent/API health

The dashboard checks:

- FastAPI backend
- Dell AIA / configured model
- HIP OAuth
- Source TP service
- Target TP service

The TP service health verdict uses the non-mutating U-HAUL validation route rather than declaring the create API down because an unsupported OPTIONS call returns HTTP 500.

Use **Runtime & Governance → Run U-HAUL TP Smoke Test** to test the V122-compatible Source and Target TP validation path without creating a TP.

## Parallel execution

Only `GOOD TO GO` TP actions can be bulk-selected.

`Select → Stage Selected → optional four-eyes approval → Preflight Selected → type LIVE ALL → parallel TP API execution`

The worker count respects the V122 stability controls and remains capped at 4 by default.

## Manual Windows / PowerShell run

```powershell
cd "C:\path\INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V8_TEAM_MAPPING_CORRECTIONS_FULL_E2E_FINAL"
py -3.11 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
```

Open `http://127.0.0.1:8088`.

Use the same credential/runtime values as the working V122 `.env`.

## Safety

No agent can add/remove/rename TP API attributes. Human payload edits are schema locked. LIVE requires runtime enablement, host allowlisting, stage, preflight and explicit confirmation. Bulk LIVE additionally requires `LIVE ALL`.

No authenticated HIP TP Create mutation was performed while building V8.

See `UPGRADE_V8_TEAM_MAPPING_CORRECTIONS.md` and `V8_FINAL_VALIDATION.md`.
