from __future__ import annotations

import os
from pathlib import Path
from typing import Any, List, Literal

import yaml
from pydantic import BaseModel, Field


def _expand(value: Any) -> Any:
    if isinstance(value, str):
        return os.path.expandvars(os.path.expanduser(value))
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    return value


class PortalConfig(BaseModel):
    # Use the Dell BizLink pages directly by default. The user/browser session must have Dell SSO access.
    base_url: str = "https://developer.dell.com/hybrid-integrations/bizlink/partner"
    environment: str = "DEV"
    browser_user_data_dir: str = "./data/chrome_profile"
    headless: bool = False
    timeout_ms: int = 45000
    sso_timeout_seconds: int = 900
    # Portal loading watchdog. The agent waits for genuine Angular/DDS loading
    # to finish. When the same blocking loading state persists for five minutes,
    # it refreshes the current page once inside the same authenticated context.
    loading_watchdog_timeout_seconds: int = 300
    loading_watchdog_poll_seconds: float = 1.0
    loading_watchdog_max_refreshes_per_phase: int = 1
    # A generic spinner/progressbar/aria-busy marker is not enough to block the
    # agent. The watchdog requires consecutive evidence that a visible overlay
    # actually covers the active form or intercepts the requested control.
    loading_watchdog_consecutive_blocking_samples: int = 2
    loading_watchdog_min_viewport_ratio: float = 0.08
    loading_watchdog_min_surface_cover_ratio: float = 0.45
    loading_watchdog_ignore_passive_indicators: bool = True
    # A page reload is allowed only after the blocking loader has remained continuously
    # present for the timeout AND the configured multimodal vision model confirms
    # that a real loading surface is still visible.
    loading_watchdog_vision_confirm_before_refresh: bool = True
    loading_watchdog_vision_confidence_threshold: float = 0.70
    loading_watchdog_vision_fail_closed: bool = True
    autonomous_page_health_enabled: bool = True
    chromium_channel: str | None = "chrome"  # Google Chrome Stable is the primary HIP browser; Edge is startup fallback.
    edge_executable_path: str | None = None  # optional full path to msedge.exe for locked-down corporate images
    chrome_executable_path: str | None = None  # optional explicit Google Chrome path
    # Browser fallback is startup-only.  Once Dell SSO/mission execution begins,
    # the browser is never switched underneath the authenticated task.
    allow_browser_fallback: bool = True
    fallback_to_chrome: bool = True
    fallback_to_edge: bool = True
    fallback_to_playwright_chromium: bool = True
    chrome_user_data_dir: str = "./data/chrome_profile"
    edge_user_data_dir: str = "./data/edge_profile"
    chromium_user_data_dir: str = "./data/chromium_profile"
    startup_cdp_probe_seconds: float = 8.0
    slow_mo_ms: int = 0
    launch_args: List[str] = Field(default_factory=lambda: ["--start-maximized", "--disable-blink-features=AutomationControlled"])
    sso_success_url_patterns: List[str] = Field(default_factory=lambda: ["/hybrid-integrations", "/bizlink", "/portal", "/configuration", "/home", "/dashboard"])
    sso_login_url_keywords: List[str] = Field(default_factory=lambda: ["login", "signin", "sso", "auth", "saml", "oauth", "okta", "ping"])
    sso_positive_texts: List[str] = Field(default_factory=lambda: ["partner", "system", "bizlink", "hybrid integrations", "configuration", "transport profile", "flow"])




class BrowserConfig(BaseModel):
    search_timeout_ms: int = 30000
    detail_timeout_ms: int = 30000
    network_idle_timeout_ms: int = 5000


class NavigationConfig(BaseModel):
    # These are the first-class routes requested by the user.
    partner_candidate_paths: List[str] = Field(default_factory=lambda: [
        "https://developer.dell.com/hybrid-integrations/bizlink/partner",
        "/hybrid-integrations/bizlink/partner",
    ])
    system_candidate_paths: List[str] = Field(default_factory=lambda: [
        "https://developer.dell.com/hybrid-integrations/bizlink/system",
        "/hybrid-integrations/bizlink/system",
    ])
    partner_nav_texts: List[str] = Field(default_factory=lambda: ["Partners", "Partner", "Trading Partners", "Partner Management", "BizLink Partner"])
    system_nav_texts: List[str] = Field(default_factory=lambda: ["Systems", "System", "System Management", "BizLink System"])
    search_labels: List[str] = Field(default_factory=lambda: ["Search", "Filter", "Name", "Partner Name", "System Name", "Keyword"])
    detail_link_texts: List[str] = Field(default_factory=lambda: ["View", "Details", "Edit", "Open", "Manage", "Name", "Identifier"])
    menu_button_texts: List[str] = Field(default_factory=lambda: ["Menu", "Navigation", "Configuration", "Setup", "Admin", "Hybrid Integrations", "BizLink"])


class ExtractionConfig(BaseModel):
    minimum_confidence: float = 0.90
    open_first_matching_row: bool = True
    capture_network_json: bool = True
    capture_all_network_metadata: bool = True
    capture_cdp_network: bool = True
    save_har: bool = False
    max_network_body_chars: int = 150000
    max_network_events_in_report: int = 120
    query_aliases: List[str] = Field(default_factory=list)
    include_previous_network_memory: bool = True
    collect_dom_clicks: bool = True
    collect_dom_events: bool = True
    collect_dom_mutations: bool = True
    max_dom_event_records: int = 6000
    max_dom_mutation_records: int = 6000
    screenshot_each_click: bool = False
    max_explore_clicks: int = 12
    overwrite_existing_ids: bool = False


class ExplorationConfig(BaseModel):
    enabled: bool = False
    collect_all_pages: bool = False
    explore_partner: bool = True
    explore_system: bool = True
    # BizLink Partner/System pages are parent-card first. Child items such as
    # AS2TEST partners and AIC-DCE domains often do not appear from the top
    # grid search; they appear only after opening an Account/Domain parent card
    # action menu (Show Partner(s) / View Domain). When exploration is enabled,
    # prefer that parent-card discovery before direct child search.
    prefer_nested_discovery: bool = True
    # In Dell BizLink the query AS2TEST/AIC-DCE is usually a child row under
    # a parent Account card. Do not search the child query in the top-level
    # Account/System grid by default during exploration.
    search_first: bool = False
    # If nested discovery cannot find the child, keep this false to avoid
    # typing a child partner/domain into the wrong top-level parent search box.
    # Set true only for portals where the child is directly searchable.
    allow_direct_child_search_fallback: bool = False
    max_pages: int = 5
    max_cards_per_page: int = 80
    max_actions_per_entity: int = 6
    max_total_actions: int = 80
    allow_unsafe_clicks: bool = False
    open_edit_pages_for_readonly_capture: bool = True

    # Dedicated HIP form exploration agent. It enumerates structural parent values,
    # records the child controls revealed/hidden/enabled for each value, and persists
    # a plan-ready form knowledge graph. Final mutations remain blocked.
    form_knowledge_agent_enabled: bool = True
    explore_parent_value_branches: bool = True
    max_parent_controls: int = 24
    max_values_per_parent: int = 30
    settle_ms: int = 700
    use_llm_dependency_analyst: bool = True
    fail_closed_on_restore_error: bool = False
    safe_action_keywords: List[str] = Field(default_factory=lambda: ["view", "show", "details", "detail", "open", "edit", "partners", "domains", "systems", "users", "biz flows", "deployment groups"])
    unsafe_action_keywords: List[str] = Field(default_factory=lambda: ["delete", "remove", "update", "save", "submit", "create", "add", "reset", "disable", "enable", "archive"])




class PortalBrainConfig(BaseModel):
    # Persistent long-term memory shared by every HIP Portal run. Knowledge is
    # promoted only after deterministic/LLM/vision judge approval.
    enabled: bool = True
    directory: str = "portal_brain"
    bootstrap_from_runs: bool = True
    require_judge_pass_for_promotion: bool = True
    learn_warning_runs_as_candidates: bool = True
    min_validated_edge_confidence: float = 0.60
    max_source_runs: int = 300
    prefer_semantic_locators: bool = True
    reject_dynamic_selectors_as_primary: bool = True

    # Reviewed canonical HIP KB. It seeds page identity, field/input mappings,
    # parent-value-child dependencies, hard gates and negative evidence. Canonical
    # knowledge guides planning but never replaces live MCP/DOM/text/vision proof.
    auto_import_unified_kb: bool = True
    unified_kb_path: str = "./knowledge_base/HIP_Unified_Deep_KB.json"
    unified_kg_path: str = "./knowledge_base/HIP_Unified_Knowledge_Graph.json"
    unified_kb_required: bool = True
    force_unified_kb_reimport: bool = False

    # Adaptive KB self-healing. The reviewed KB is a strong seed, but live
    # Playwright-MCP exploration plus deterministic/text/vision judge evidence
    # may add missing facts or supersede a proven-wrong canonical dependency.
    self_heal_kb: bool = True
    auto_apply_validated_kb_repairs: bool = True
    kb_repair_min_confirmations: int = 1
    kb_supersede_min_confirmations: int = 2
    preserve_original_kb: bool = True
    export_corrected_kb_after_run: bool = True
    revalidate_known_parent_branches: bool = True

    # Reusable structural memory for similar HIP flow/form families. Values are
    # never stored; only judge-validated topology, semantic bindings, action order
    # and wait/event contracts are eligible for replay.
    flow_pattern_memory_enabled: bool = True
    flow_pattern_min_similarity: float = 0.78
    flow_pattern_max_patterns: int = 500
    flow_pattern_allow_cross_phase_same_family: bool = True

class PortalLearningConfig(BaseModel):
    # Deep portal-learning layer. It observes every phase through Python
    # Playwright, Playwright MCP and Chrome DevTools MCP, then promotes only
    # judge-approved facts into the persistent Portal Brain.
    enabled: bool = True
    capture_accessibility_snapshots: bool = True
    accessibility_snapshot_depth: int = 12
    capture_devtools_snapshots: bool = True
    capture_api_contracts: bool = True
    capture_validation_rules: bool = True
    capture_storage_key_names: bool = True
    capture_performance_trace: bool = True
    # Performance traces are intentionally limited to retries by default because
    # tracing every successful action adds cost without improving form learning.
    performance_trace_on_retry_only: bool = True
    max_network_contracts_per_phase: int = 250
    max_control_signatures_per_phase: int = 800
    max_exploration_agenda_items: int = 50
    promote_only_after_judge_pass: bool = True
    detect_portal_drift: bool = True
    information_gain_agenda: bool = True
    fail_open_for_learning_capture: bool = True
    # Maximum-observability mode captures structural DOM, hidden/visible control
    # ownership, mutation/event timelines, resources and input-to-control coverage.
    # It is read-only and strips values/credentials before writing evidence.
    maximum_observability_enabled: bool = True
    capture_sanitized_dom_structure: bool = True
    maximum_observability_max_controls: int = 5000
    maximum_observability_max_events: int = 2500
    maximum_observability_max_dom_chars: int = 2000000


class RuntimeSelfHealConfig(BaseModel):
    # Closed-loop runtime recovery. Repairs are safe browser/session operations
    # only; final portal mutations remain prohibited.
    enabled: bool = True
    max_phase_attempts: int = 5
    max_total_repairs: int = 20
    max_repeated_failure_signature: int = 2
    # Anti-stagnation guards are NEVER disabled by ``until_complete``. A live
    # portal phase must demonstrate progress; the same failure state cannot be
    # replayed forever and no phase may occupy the browser for hours.
    max_no_progress_repeats: int = 3
    max_phase_wall_seconds: int = 1200
    # Active structural watchdog. Unlike failure-signature counting, this runs
    # while the phase coroutine is still alive and interrupts repeated UI cycles.
    no_progress_watchdog_seconds: float = 90.0
    no_progress_poll_seconds: float = 5.0
    no_progress_recent_signature_limit: int = 12
    use_aia_advisor: bool = True
    aia_advisor_timeout_seconds: int = 20
    aia_advisor_context_max_chars: int = 96000
    capture_evidence: bool = True
    retry_unknown_once: bool = True
    fail_closed: bool = True
    # When enabled, ordinary attempt count is progress-driven rather than fixed.
    # Anti-stagnation signature and wall-clock guards remain mandatory so a
    # broken Document Type/DDS control can never spin for hours.
    until_complete: bool = False
    exploration_exploitation: bool = True
    # Capture independent evidence from local Playwright plus both browser MCPs
    # for every failed attempt. This is intentionally structured/redacted rather
    # than an unrestricted page dump, so it remains safe to upload and review.
    forensic_evidence: bool = True
    forensic_event_window: int = 250
    capture_validated_trajectory: bool = True


class APIRequestConfig(BaseModel):
    name: str
    method: str = "POST"
    path: str
    body_path: str | None = None


class APIConfig(BaseModel):
    # Legacy configured API client. Real writes remain disabled by default.
    enabled: bool = False
    dry_run: bool = True
    base_url: str = ""
    token_env_var: str = "HIP_API_TOKEN"
    token_command: List[str] = Field(default_factory=list)
    requester_id: str = ""
    account_id: str = ""
    work_order_id: str = ""
    requests: List[APIRequestConfig] = Field(default_factory=list)

    # Browser-grounded form/API intelligence. The same authenticated Chrome
    # session captures every request caused by form open/fill. No endpoint or
    # payload key may be invented by the LLM.
    capture_observed_contracts: bool = True
    dual_ui_api: bool = False
    capture_submit_payload: bool = False
    execution_mode: Literal["capture", "dry_run", "validate", "write"] = "capture"
    require_capture_for_completion: bool = False
    max_observed_contracts_per_phase: int = 500
    capture_request_response_transactions: bool = True
    max_observed_transactions_per_phase: int = 2000
    export_openapi: bool = True
    export_postman: bool = True
    build_ui_api_crosswalk: bool = True
    replay_observed_safe_reads: bool = False
    replay_observed_validation_requests: bool = False

    # Write mode is two-key fail-closed: the CLI/config flag and the environment
    # variable must both be enabled. The captured submit request is blocked first;
    # only the separately authenticated API replay may perform a mutation.
    allow_mutating_methods: bool = False
    mutation_confirmation_env_var: str = "HIP_ALLOW_API_MUTATION"
    allowed_api_hosts: List[str] = Field(default_factory=list)


class AIAConfig(BaseModel):
    enabled: bool = False
    endpoint_env_var: str = "AIA_ENDPOINT"
    base_url_env_var: str = "OPENAI_BASE_URL"
    token_env_var: str = "AIA_TOKEN"
    token_command: List[str] = Field(default_factory=list)
    auth_mode: Literal["auto", "sso", "client_credentials", "env", "command"] = "auto"
    client_id_env_var: str = "CLIENT_ID"
    client_secret_env_var: str = "CLIENT_SECRET"
    use_aia_auth_package: bool = True
    model: str = "gpt-oss-120b"
    timeout_seconds: int = 90
    max_snapshot_chars: int = 40000


class ReportingConfig(BaseModel):
    runs_dir: str = "./runs"
    memory_dir: str = "./data/hip_memory"
    screenshot_dir_name: str = "screenshots"
    save_html: bool = True
    save_markdown: bool = True
    save_json: bool = True


class SecurityConfig(BaseModel):
    mask_secrets: bool = True
    save_cookies: bool = False
    save_tokens: bool = False
    save_authorization_headers: bool = False


class GovernanceConfig(BaseModel):
    # Production change-governance controls layered on top of the existing
    # three-key mutation gate. Read/draft navigation remains lightweight;
    # mutation operations additionally require an authorized operator role,
    # duplicate protection and post-change verification.
    enabled: bool = True
    operator_role_env_var: str = "HIP_OPERATOR_ROLE"
    default_operator_role: str = "viewer"
    approval_id_env_var: str = "HIP_CHANGE_APPROVAL_ID"
    require_approval_id_for_mutation: bool = False
    read_roles: List[str] = Field(default_factory=lambda: ["viewer", "business", "support", "technical", "admin"])
    draft_roles: List[str] = Field(default_factory=lambda: ["business", "support", "technical", "admin"])
    mutation_roles: List[str] = Field(default_factory=lambda: ["technical", "admin"])
    require_certified_family_for_mutation: bool = True
    require_preview_for_mutation: bool = True
    require_post_change_api_success: bool = True
    require_post_change_mcp_assurance: bool = True
    duplicate_window_hours: int = 168
    # After any physical mutation click dispatch, never fire a second backend
    # mutation merely because the browser/UI timed out. Reconcile read-only
    # network and visible outcome evidence inside this bounded window instead.
    mutation_reconciliation_timeout_seconds: float = 3.0
    mutation_reconciliation_poll_seconds: float = 0.25
    allow_pre_dispatch_rebind: bool = True
    # An identical mutation whose prior process ended after execution started or
    # with an indeterminate/partial write outcome is quarantined across runs.
    # force_repeat_mutation does not bypass this fail-closed safety boundary.
    block_unresolved_mutation_replay: bool = True
    ledger_filename: str = "change_audit_ledger.jsonl"


class MCPConfig(BaseModel):
    # Three complementary MCPs: Playwright and Chrome DevTools attach to the
    # authenticated browser; HIP Intelligence is a local value-free planner,
    # critic, drift and trajectory-memory service and opens no browser.
    browser_backend: Literal["playwright", "mcp", "auto"] = "mcp"
    use_playwright_mcp: bool = True
    use_chrome_devtools_mcp: bool = True
    use_browser_mcp_for_sso: bool = False

    # Local value-free intelligence MCP. It does not control another browser.
    # It exposes web representation, action planning, critic, drift and
    # trajectory-memory tools used by the shared HIP state-transaction engine.
    use_hip_intelligence_mcp: bool = True
    hip_intelligence_mcp_required: bool = True
    hip_intelligence_mcp_command: str = ""  # empty = current Python executable
    hip_intelligence_mcp_args: List[str] = Field(default_factory=list)
    hip_intelligence_mcp_startup_timeout_seconds: int = 20

    # Official Microsoft Playwright MCP server. It attaches to the same Chrome/Edge
    # instance through CDP so accessibility snapshots, safe actions and verification
    # operate on the exact HIP Portal tab used by the deterministic executor.
    playwright_mcp_command: str = "auto"
    playwright_mcp_args: List[str] = Field(default_factory=lambda: ["@playwright/mcp@0.0.79"])
    playwright_mcp_startup_timeout_seconds: int = 45
    playwright_mcp_remote_debugging_port: int = 9237
    playwright_mcp_cdp_timeout_ms: int = 30000
    playwright_mcp_action_timeout_ms: int = 15000
    playwright_mcp_navigation_timeout_ms: int = 60000
    playwright_mcp_expect_timeout_ms: int = 10000
    playwright_mcp_preflight_headless: bool = True
    playwright_mcp_primary_for_safe_actions: bool = True
    playwright_mcp_find_first: bool = True
    playwright_mcp_fill_form_enabled: bool = True
    playwright_mcp_fill_form_min_fields: int = 2
    playwright_mcp_verify_every_action: bool = True
    playwright_mcp_snapshot_after_action: bool = True
    playwright_mcp_required_when_require_mcp: bool = True

    # Pre-existing Chrome DevTools MCP stdio server. Used alongside Playwright MCP
    # as an independent CDP/DOM/network/console witness in governed Layer-11 execution.
    chrome_devtools_command: str = "auto"
    chrome_devtools_args: List[str] = Field(default_factory=lambda: ["chrome-devtools-mcp@1.6.0", "--no-usage-statistics"])
    chrome_devtools_startup_timeout_seconds: int = 30
    chrome_devtools_request_timeout_seconds: float = 30.0
    chrome_devtools_shutdown_timeout_seconds: float = 3.0
    chrome_devtools_mcp_direct_backend_enabled: bool = False
    chrome_devtools_attach_same_browser: bool = True
    chrome_devtools_experimental_page_id_routing: bool = True
    require_dual_mcp_same_surface: bool = True
    # SSO and Angular redirects can temporarily hide the selected page from the
    # Chrome DevTools MCP. Poll after authentication rather than failing on the
    # first empty list_pages response.
    dual_mcp_same_surface_timeout_seconds: float = 30.0
    dual_mcp_same_surface_poll_seconds: float = 1.0

    # v2.1 Layer 6: same-browser executor recovery. If an MCP/CDP transport
    # disconnects after SSO, only the MCP clients may be restarted; the browser
    # process/profile is locked. The exact HIP tab/route must be uniquely re-proven
    # before execution continues.
    executor_rebind_enabled: bool = True
    executor_rebind_timeout_seconds: float = 12.0
    executor_rebind_max_attempts_per_phase: int = 2
    executor_rebind_fail_on_ambiguous_tabs: bool = True


class ExpertSkillConfig(BaseModel):
    """Description-triggered deterministic skill orchestration.

    These controls encode the operating principles used by the HIP agent: a user
    description selects vetted expert skills, deterministic scripts execute first,
    and only phase-local context is loaded unless recovery needs more evidence.
    """
    enabled: bool = True
    description_trigger_enabled: bool = True
    require_skill_vetting: bool = True
    deterministic_first: bool = True
    # Larger but still bounded context. Normal planning is phase-local; recovery
    # may expand into broader semantic evidence without dumping cookies/values.
    context_max_chars: int = 64000
    recovery_context_max_chars: int = 128000
    max_capabilities_per_family: int = 48
    browser_use_recovery_context: bool = True
    broad_context_only_on_recovery: bool = True


class AutoWebGLMConfig(BaseModel):
    """Primary AutoWebGLM browser-decision framework for HIP.

    AutoWebGLM owns the observation/action policy layer: task + simplified HTML +
    viewport + action history -> one browser command.  Existing HIP deterministic
    drivers are registered as verified tool adapters that execute the approved
    action and prove the resulting Angular/DDS state.  The original ChatGLM3-6B
    research checkpoint is optional; the existing Dell AIA endpoint can predict
    the same protocol when no native wrapper is configured.
    """
    enabled: bool = True
    primary_framework: bool = True
    recovery_only: bool = False
    deterministic_tool_fallback: bool = True
    require_intent_alignment: bool = True
    max_primary_decision_seconds: int = 12
    use_existing_dell_aia: bool = True
    native_model_command: List[str] = Field(default_factory=list)
    max_html_chars: int = 70000
    max_history_actions: int = 40
    max_tabs: int = 12
    max_prompt_chars: int = 110000
    timeout_seconds: int = 20
    require_agentq_reward_gate: bool = True
    allowed_actions: List[str] = Field(default_factory=lambda: [
        "click", "hover", "select", "type_string", "press_key", "scroll_page", "go",
        "jump_to", "switch_tab", "user_input", "finish"
    ])
    block_mutation_labels: bool = True




class SemanticUnderstandingConfig(BaseModel):
    """Layer 11 semantic website-understanding and multi-evidence action gate.

    The gate never invents business values. It proves that a reviewed deterministic
    intent still resolves to one live HIP control before Playwright MCP can execute
    it, and learns only value-free control/state fingerprints after exact success.
    """
    enabled: bool = True
    execute_confidence_threshold: float = 0.90
    reobserve_confidence_threshold: float = 0.75
    self_heal_confidence_threshold: float = 0.55
    ambiguity_margin: float = 0.08
    require_playwright_mcp_evidence: bool = True
    require_devtools_evidence: bool = True
    use_hip_intelligence_mcp_consensus: bool = True
    require_hip_intelligence_mcp_evidence: bool = True
    use_vision_for_ambiguity: bool = True
    vision_confirmation_boost: float = 0.08
    fail_closed: bool = True
    require_post_action_effect: bool = True
    revalidate_before_dispatch: bool = True
    prefer_stable_semantic_selector_for_mcp: bool = True
    learn_control_fingerprints: bool = True
    learn_state_graph: bool = True
    max_ranked_candidates_evidence: int = 6

class LangChainBrowserToolkitConfig(BaseModel):
    """Read-only LangChain Playwright toolkit on the SAME authenticated Edge.

    CDP attachment is recovery-only by default.  The primary Playwright context owns
    Edge during SSO and normal deterministic filling; auxiliary CDP clients are not
    allowed to destabilize the login/session path.
    """
    enabled: bool = True
    attach_same_browser: bool = True
    startup_attach: bool = False
    attach_timeout_seconds: float = 8.0
    read_only: bool = True
    fail_open_if_unavailable: bool = True
    timeout_seconds: float = 6.0
    max_text_chars: int = 30000
    max_element_chars: int = 30000
    allowed_tools: List[str] = Field(default_factory=lambda: [
        "current_webpage", "extract_text", "get_elements", "extract_hyperlinks"
    ])


class PyAutoGUIConfig(BaseModel):
    """Tertiary desktop fallback behind the governed browser executors.

    PyAutoGUI MCP is preferred over direct in-process PyAutoGUI so desktop
    operations have an explicit MCP capability/audit channel. It never replaces
    Playwright MCP for normal HIP web controls and cannot perform final tenant
    mutations by default.
    """
    enabled: bool = True
    windows_only: bool = True

    # Community pyautogui-mcp package, run from the current Python environment by
    # default: ``python -m pyautogui_mcp --transport stdio``. It is an optional
    # tertiary channel, not a Live GO/NO-GO blocker unless mcp_required=true.
    mcp_enabled: bool = True
    mcp_required: bool = False
    mcp_command: str = ""
    mcp_args: List[str] = Field(default_factory=list)
    mcp_prefix: str = "pyautogui_"
    mcp_startup_timeout_seconds: int = 20
    mcp_request_timeout_seconds: float = 15.0
    mcp_shutdown_timeout_seconds: float = 3.0
    # Large screenshot results can exceed asyncio's default 64 KiB stdio line
    # limit. Keep a bounded but practical MCP message allowance.
    mcp_stream_limit_bytes: int = 32 * 1024 * 1024
    prefer_mcp: bool = True
    allow_local_fallback_if_mcp_unavailable: bool = True

    allow_mutation_clicks: bool = False
    allow_native_screen_targets: bool = True
    native_target_confidence_threshold: float = 0.97
    native_target_evidence_sources: List[str] = Field(default_factory=lambda: ["vision", "native_dialog", "browser_chrome"])
    ascii_only_text: bool = True
    max_attempts_per_action: int = 1
    locator_timeout_ms: int = 5000
    stability_wait_ms: int = 150
    bbox_stability_tolerance_px: float = 3.0
    screen_margin_px: int = 2
    move_duration_seconds: float = 0.12
    key_interval_seconds: float = 0.01
    settle_ms: int = 300
    pause_seconds: float = 0.05
    verify_after_fill: bool = True
    verify_after_click_event: bool = True



class VisionRuntimeConfig(BaseModel):
    """Multimodal vision perception used during normal recovery and loading health.

    The existing strict SectionJudge remains the final vision gate. This bridge gives
    the live browser controller visual awareness before section completion, including
    the five-minute loading watchdog requested for Edge.
    """
    enabled: bool = True
    require_model: bool = True
    use_for_recovery: bool = True
    use_for_loading_watchdog: bool = True
    loading_refresh_after_seconds: int = 300
    loading_confidence_threshold: float = 0.70
    timeout_seconds: int = 30
    max_prompt_chars: int = 24000
    max_recovery_summary_chars: int = 12000
    fail_closed_when_unavailable: bool = True
    auto_discovery: bool = True
    auto_candidates: List[str] = Field(default_factory=lambda: ["gemma-3-27b-it", "pixtral-12b-2409"])

class BrowserUseConfig(BaseModel):
    """Browser-Use/WebUI-inspired browser/session capabilities for HIP.

    Browser Use remains perception/recovery only. The governed Playwright/MCP
    executor is authoritative for state-changing HIP actions. Optional WebUI-style
    conveniences (own-browser CDP attachment, recordings, traces, downloads and
    session history) are evidence/session features, not mutation bypasses.
    """
    enabled: bool = True
    attach_same_browser: bool = True
    # When true with cdp_url, the deterministic HIP executor also attaches to that
    # already-running Microsoft Edge/Chromium instance instead of launching a second browser. This is the HIP
    # equivalent of browser-use/web-ui's "Use Own Browser" mode.
    use_own_browser: bool = False
    cdp_url: str = ""  # empty = derive from mcp.playwright_mcp_remote_debugging_port
    keep_alive: bool = True
    keep_browser_open: bool = True
    # Important for corporate Edge/SSO: Browser-Use uses its own CDP websocket
    # client. Do not attach it while Dell SSO is in progress.  Normal filling is
    # owned by the deterministic Playwright context; Browser-Use attaches only when
    # recovery perception is requested.
    startup_attach: bool = False
    recovery_only_attach: bool = True
    attach_timeout_seconds: float = 8.0
    snapshot_timeout_seconds: float = 4.0
    detach_after_recovery: bool = True
    use_state_snapshot_for_recovery: bool = True
    dynamic_repeatable_rows: bool = True
    fail_open_if_unavailable: bool = True
    max_state_chars: int = 60000
    # Optional Browser-Use WebUI-style browser evidence. Recording/trace are off by
    # default because they may be large and can contain portal content.
    record_video: bool = False
    record_video_dir: str = ""
    record_video_width: int = 1440
    record_video_height: int = 950
    capture_playwright_trace: bool = False
    trace_dir: str = ""
    trace_screenshots: bool = True
    trace_snapshots: bool = True
    trace_sources: bool = False
    save_downloads: bool = True
    download_dir: str = ""
    save_session_history: bool = True
    history_dir: str = ""
    capture_state_on_phase_transition: bool = True
    capture_state_after_actions: bool = False
    max_history_entries: int = 400


class LiveRuntimeCertificationConfig(BaseModel):
    """Strict live-environment certificate consumed by the Live GO/NO-GO gate."""
    enabled: bool = True
    require_for_live_go_no_go: bool = False
    ttl_seconds: int = 3600
    require_pyautogui_mcp: bool = True
    latest_certificate_relative_path: str = ".hip_runtime/live_runtime_certificate.json"



class AppConfig(BaseModel):
    portal: PortalConfig = Field(default_factory=PortalConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    navigation: NavigationConfig = Field(default_factory=NavigationConfig)
    extraction: ExtractionConfig = Field(default_factory=ExtractionConfig)
    exploration: ExplorationConfig = Field(default_factory=ExplorationConfig)
    brain: PortalBrainConfig = Field(default_factory=PortalBrainConfig)
    portal_learning: PortalLearningConfig = Field(default_factory=PortalLearningConfig)
    runtime_self_heal: RuntimeSelfHealConfig = Field(default_factory=RuntimeSelfHealConfig)
    api: APIConfig = Field(default_factory=APIConfig)
    aia: AIAConfig = Field(default_factory=AIAConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    browser_use: BrowserUseConfig = Field(default_factory=BrowserUseConfig)
    autowebglm: AutoWebGLMConfig = Field(default_factory=AutoWebGLMConfig)
    semantic_understanding: SemanticUnderstandingConfig = Field(default_factory=SemanticUnderstandingConfig)
    langchain_browser_toolkit: LangChainBrowserToolkitConfig = Field(default_factory=LangChainBrowserToolkitConfig)
    expert_skills: ExpertSkillConfig = Field(default_factory=ExpertSkillConfig)
    pyautogui: PyAutoGUIConfig = Field(default_factory=PyAutoGUIConfig)
    vision_runtime: VisionRuntimeConfig = Field(default_factory=VisionRuntimeConfig)
    live_runtime_certification: LiveRuntimeCertificationConfig = Field(default_factory=LiveRuntimeCertificationConfig)
    reporting: ReportingConfig = Field(default_factory=ReportingConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    governance: GovernanceConfig = Field(default_factory=GovernanceConfig)


def load_config(path: str | Path) -> AppConfig:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    raw = _expand(raw)
    return AppConfig.model_validate(raw)
