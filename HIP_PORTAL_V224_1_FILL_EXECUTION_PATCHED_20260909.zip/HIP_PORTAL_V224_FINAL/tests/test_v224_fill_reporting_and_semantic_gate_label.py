from __future__ import annotations

"""Regression tests for the V224 "all phases blocked, Filled (0)" run.

Two defects were reproduced from run UHAUL-POASN-20260909-153649, where every
phase reported ``Filled (0)`` and was blocked by the section judge:

1.  ``fill_and_log(action_type="search")`` emits an ActionEvent of type
    ``search``.  The mission trace classified that as a *click*, so every
    type-ahead/combobox value the agent committed was invisible in the filled
    ledger.  Eight discovery modules use that path, including
    ``transport_profile_deep_discovery``.

2.  ``fill_and_log`` passed the raw CSS selector as the semantic-gate label,
    while the click and press paths pass human-readable text.  A CSS selector
    can never appear in a Playwright MCP / DevTools MCP accessibility snapshot,
    so once the DOM anchor was lost the gate failed both required evidence
    checks *and* dropped below ``self_heal_confidence_threshold`` -- yielding
    status ``blocked`` (no recovery pass) instead of ``rediscover``.
"""

import inspect
import re
from pathlib import Path

from hip_id_agent.browser_session import BrowserSession
from hip_id_agent.mission_trace import MissionTraceLedger, read_mission_trace
from hip_id_agent.models import ActionEvent
from hip_id_agent.semantic_control import _contains_semantic, rank_semantic_candidates

_PROVENANCE = {
    "planner": "autowebglm-primary",
    "primary_executor": "playwright-mcp",
    "actual_executor": "playwright-mcp",
    "playwright_mcp_available": True,
    "playwright_mcp_attempted": True,
    "playwright_mcp_succeeded": True,
}


def test_type_ahead_search_is_reported_as_filled_not_clicked(tmp_path: Path):
    """A committed combobox value must appear in the filled ledger."""
    trace = MissionTraceLedger(tmp_path, run_id="run-v224", phases=["source_transport_profile"])
    trace.mark_phase("source_transport_profile", status="running", attempt=1)

    trace.record_action(ActionEvent(
        action_id="act-00001", type="fill", target='[formcontrolname="profileName"]',
        value_redacted="UHAUL_STP", execution_provenance=_PROVENANCE,
    ), phase="source_transport_profile")
    trace.record_action(ActionEvent(
        action_id="act-00002", type="search", target='[formcontrolname="protocol"]',
        value_redacted="SFTP", execution_provenance=_PROVENANCE,
    ), phase="source_transport_profile")
    trace.record_action(ActionEvent(
        action_id="act-00003", type="click", target='button[name="save"]',
        execution_provenance=_PROVENANCE,
    ), phase="source_transport_profile")
    trace.record_action(ActionEvent(
        action_id="act-00004", type="press", target='[formcontrolname="protocol"]',
        execution_provenance=_PROVENANCE,
    ), phase="source_transport_profile")

    step = read_mission_trace(tmp_path)["steps"][0]

    # Both committed values are filled evidence; click/press remain separate.
    assert len(step["filled"]) == 2
    assert len(step["clicked"]) == 2
    targets = {row["target"] for row in step["filled"]}
    assert '[formcontrolname="protocol"]' in targets

    modes = {row["target"]: row.get("entry_mode") for row in step["filled"]}
    assert modes['[formcontrolname="profileName"]'] == "direct_fill"
    assert modes['[formcontrolname="protocol"]'] == "type_ahead_search"


def test_search_values_are_still_masked(tmp_path: Path):
    trace = MissionTraceLedger(tmp_path, run_id="run-v224", phases=["data_map"])
    trace.mark_phase("data_map", status="running", attempt=1)
    trace.record_action(ActionEvent(
        action_id="act-00001", type="search", target="password",
        value_redacted="hunter2", was_secret=True,
    ), phase="data_map")
    step = read_mission_trace(tmp_path)["steps"][0]
    assert step["filled"][0]["value"] == "***MASKED***"


def test_fill_path_sends_a_human_readable_label_to_the_semantic_gate():
    """fill_and_log must not hand a raw CSS selector to the gate."""
    source = inspect.getsource(BrowserSession.fill_and_log)
    assert "_accessible_label_for" in source, "fill must resolve an accessible label"
    assert "label=selector or action_type" not in source, (
        "fill still passes the raw CSS selector as the semantic label"
    )


def test_humanize_selector_yields_matchable_tokens():
    humanize = BrowserSession._humanize_selector
    assert humanize('[formcontrolname="profileName"]') == "profile name"
    assert humanize('input[name="sourceDocumentType"]') == "source document type"
    assert humanize("#transportProfileHostName") == "transport profile host name"


def test_selector_label_cannot_prove_a_target_but_a_real_label_can():
    """The evidence check the gate performs, at the level that regressed."""
    axe_text = ("Source Transport Profile textbox Transport Profile Name "
                "combobox Protocol button Save")
    assert _contains_semantic(axe_text, '[formcontrolname="profileName"]') is False
    assert _contains_semantic(axe_text, "Transport Profile Name") is True
    assert _contains_semantic(axe_text, BrowserSession._humanize_selector(
        '[formcontrolname="profileName"]')) is True


def test_lost_anchor_fill_reaches_a_recovery_status_not_a_hard_block():
    """With a real label the gate self-heals; with a selector it dead-ends.

    Mirrors SemanticActionGate.resolve's status ladder using its own ranking
    function, for the case where the DOM anchor was lost mid-capture.
    """
    controls = [
        {"anchor_match": False, "label": "Transport Profile Name", "tag": "input",
         "role": "textbox", "type": "text", "section": "Source Transport Profile",
         "framework_key": "profileName", "name": "profileName", "visible": True,
         "enabled": True, "selector": '[formcontrolname="profileName"]'},
        {"anchor_match": False, "label": "Protocol", "tag": "input", "role": "combobox",
         "type": "text", "section": "Source Transport Profile", "framework_key": "protocol",
         "name": "protocol", "visible": True, "enabled": True,
         "selector": '[formcontrolname="protocol"]'},
    ]
    axe_text = ("Source Transport Profile textbox Transport Profile Name "
                "combobox Protocol")

    def confidence_for(label: str) -> float:
        ranked = rank_semantic_candidates(
            candidates=controls, action="fill", expected_label=label,
            expected_section="Source Transport Profile",
            accessibility_text=axe_text, devtools_text=axe_text,
            memory=None, phase="source_transport_profile",
        )
        return float(ranked[0].get("score") or 0.0) if ranked else 0.0

    self_heal_threshold = 0.55
    selector_conf = confidence_for('[formcontrolname="profileName"]')
    label_conf = confidence_for("Transport Profile Name")

    # Below the self-heal floor => resolve() returns "blocked" and
    # _semantic_action_preflight raises without attempting recovery.
    assert selector_conf < self_heal_threshold
    # Above it => "rediscover"/"reobserve", which retries and can then approve.
    assert label_conf >= self_heal_threshold
