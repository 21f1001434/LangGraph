# V224.1 — fill-execution and fill-reporting patch

Applied on top of `HIP_PORTAL_V224_AGENTIC_FORM_ENTRY_BIZFLOW_FINAL_1039_PASS_20260909`
after analysing run `UHAUL-POASN-20260909-153649`, in which all 7 phases were
blocked by the section judge and every phase reported `Filled (0)`.

## Verification status

**Not certified working end to end.** These are three targeted defect fixes
found by static analysis and offline simulation. The application was never
executed against the HIP Portal during this work — no Windows host, no Edge/CDP,
no Dell SSO, no AIA endpoint, no MCP servers, and no network to install the
runtime dependencies. Treat this as a candidate build to test, not a verified
release.

What *was* verified:

- All 238 Python files parse.
- 6 new regression tests pass (run with a minimal `pydantic` stub, which a real
  environment does not need).
- The existing `test_v210_layer5_mission_trace_playwright_mcp.py` trace
  assertions still hold.
- Secret masking still applies to `search` events.
- No module gates on the `filled` / `clicked` counters.

## Changes

Three files differ from the 20260909 baseline. Nothing else was touched.

### 1. `hip_id_agent/mission_trace.py`

`fill_and_log(action_type="search")` emits an `ActionEvent` of type `search`.
`record_action` classified that as a *click*, so every type-ahead / combobox
value the agent committed was absent from the filled ledger. Eight modules use
that path, including `transport_profile_deep_discovery.py` (P05-STP, P06-TTP).

`search` is now recorded as filled evidence, tagged
`entry_mode: "type_ahead_search"` to remain distinguishable from `direct_fill`.
`click` and `press` are unchanged.

### 2. `hip_id_agent/browser_session.py` — semantic gate label

`fill_and_log` passed the raw CSS selector as the semantic-gate label, while
click passes `action or selector` and press passes human-readable text. Once the
DOM anchor was lost (Angular/DDS re-render between `setAttribute` and
`page.evaluate`), that selector became the label used to prove the target
against Playwright MCP and DevTools MCP accessibility evidence — which a CSS
selector can never match. Both required evidence checks failed, confidence fell
below `self_heal_confidence_threshold` (0.55), and the gate returned `blocked`
rather than `rediscover`, so `_semantic_action_preflight` raised
`HIP_SEMANTIC_ACTION_BLOCKED` with no recovery pass. An equivalent click got one.

Added `_accessible_label_for()`, reading the control's accessible name from the
live element using the same identity sources as `INVENTORY_JS`, and
`_humanize_selector()` as a last resort (`[formcontrolname="profileName"]` →
`profile name`).

No threshold was lowered and no evidence requirement bypassed. The gate remains
fail-closed.

### 3. `hip_id_agent/browser_session.py` — AutoWebGLM planner label

The same selector also reached `_autowebglm_primary_decision`, which raises
`HIP_AUTOWEBGLM_PRIMARY_INTENT_REJECTED` when `require_intent_alignment` is on.
A CSS selector cannot be aligned against a business field name, giving fills a
second rejection path clicks never faced. Now mirrors the click path, using the
resolved semantic candidate label.

### New: `tests/test_v224_fill_reporting_and_semantic_gate_label.py`

Six tests covering all three defects, including the gate's status ladder for a
lost-anchor fill.

## First re-run: what to check

1. Do P05-STP and P06-TTP still report `Filled 0`? With change 1 in place, any
   type-ahead value that commits will now appear there.
2. Inspect
   `runs/<run-id>/browser_intelligence/semantic_action_gate/*_pre_fill.json`.
   `status: blocked` with `playwright_mcp.matched: false` means change 2
   addressed the live cause. `playwright_mcp.available: false` means the real
   problem is MCP attachment and these fixes are necessary but not sufficient.

If the filled counters move but phases still block, the remaining cause is
downstream in the judge's expectation build, not in fill execution.

## Known limit

Change 2 only takes effect **when DOM anchoring fails**. It has not been shown
that anchoring fails on every field across all seven phases, so it may not fully
explain `Filled = 0` everywhere.
