# V8 — Team TP Mapping Corrections

## Feedback implemented

The HIP team reviewed generated SFTP TP mappings and identified these defects:

- Subscription Folder was incorrectly taking `Directory`.
- `interfaceType` was taking the wrong Excel interface field.
- FILE `Existing Account Name` was taking the wrong account value.
- `DEV-Transport Profile Name` was being treated too much like a requirement; the API only needs `transportProfileName`.
- `documentTypeName` must stay empty when document data is unavailable.

## Corrections

1. Exact generic `Interface Type` now wins over legacy Source/Target Interface Type when present.
2. `Directory → Subscription Folder` mapping is completely removed from deterministic and LLM paths.
3. `HIP Account → Existing Account Name` mapping is completely removed.
4. Grouped duplicate Excel headers now preserve parent context, allowing the Transport Profile Details `Account` field to be selected correctly.
5. FILE Existing Account Name uses only explicit TP-specific account evidence.
6. Subscription Folder uses only explicit TP-specific subscription evidence and may remain blank.
7. Document Type name/version are optional for the current TP intake and remain blank when unavailable.
8. Transport Profile name accepts generic/role-specific/DEV Excel aliases; no DEV-prefixed column is required.
9. Core TP leaves are provenance locked so Dell AIA cannot semantically override these rules.
10. UI/readiness/HTML evidence shows protected-field provenance explicitly.

## Team-shaped regression scenario

A workbook row containing:

- `Source Interface Type = Directory Monitor inbound`
- `Interface Type = SFTP Server`
- `Hip Account names = ATEA_PC`
- `Add > Transport Profile Details > Account = dklp_dell`
- `Directory = /TestInbound`
- blank Document Type

now produces:

- API `interfaceType = SFTP HAFT` from exact `Interface Type`
- FILE `Existing Account Name = dklp_dell`
- `Subscription Folder = ""` unless explicitly supplied
- `documentTypeName = ""`
- `documentTypeVersion = ""`
- `Directory` retained only as evidence
- HIP Account displayed as `ATEA_PC` but not injected as Existing Account Name

