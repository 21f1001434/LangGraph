# V3 Upgrade — V122 Environment Parity + Multi-API Bulk LIVE

## Fixed from V2

1. Replaced standalone AIA/target-auth configuration as the primary runtime contract with the V122 environment-variable model.
2. Added separate ACCOUNT/PARTNER/SYSTEM OAuth profiles exactly like V122; other HIP APIs reuse HIP OAuth.
3. Added V122 URL overrides, TLS/CA bundle, requester ID, timeout/retry and migration environment behavior.
4. Changed AUTO from one-best-API-only to a complete per-row/per-API applicability matrix.
5. Changed batch staging from top recommendation only to every `GOOD_TO_TRIGGER` API action.
6. Added batch preflight across all staged API actions.
7. Added governed bulk LIVE with exact `LIVE ALL` confirmation.
8. Added dependency-wave ordering and V122-aligned max concurrency (default effective cap 4).
9. Seeded the 25 V122-derived API contracts as approved/LIVE-capable while keeping global LIVE disabled by default.
10. Added UI inspection of every applicable API action, not only the primary recommendation.

## Safety retained

Bulk execution does not weaken the existing gates. Every item still requires an immutable approved contract, schema-locked payload, passed preflight, unchanged fingerprint, host allowlist, required approval, valid OAuth profile and global LIVE configuration.
