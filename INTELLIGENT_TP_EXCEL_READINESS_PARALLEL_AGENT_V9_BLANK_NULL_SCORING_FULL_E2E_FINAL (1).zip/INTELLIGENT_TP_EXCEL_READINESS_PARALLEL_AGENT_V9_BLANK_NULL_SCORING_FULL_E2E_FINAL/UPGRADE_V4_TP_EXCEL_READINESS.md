# V4 Upgrade — TP Excel Readiness + Selective Parallel LIVE

V4 narrows the current primary workflow to the actual team input: an Excel workbook containing Transport Profile information for multiple accounts.

## Changes from V3

- Replaced generic all-API primary UI with a TP-specific readiness workspace.
- Each Excel row is evaluated only as Source/Target Transport Profile work.
- Added V122 interface-specific dynamic TP payload contracts for FILE/SFTP/FTP, HTTPS, HTTPS-AS2, NAS, and Rabbit MQ.
- Added explicit unsupported-interface blocking.
- Added receiver AS2 SSL Certificate readiness gate; no sample certificate default is allowed.
- Added role inference using TP naming + source/target system/interface evidence.
- Added TP-specific data/evidence extraction and classification.
- Added evidence-only handling so server/port/auth columns are not invented as TP payload attributes.
- Added polished, self-contained HTML readiness report.
- Added TP Readiness Queue with search/filter/select only Good-to-Go candidates.
- Added per-TP exact mapping inspection and schema-locked value editor.
- Added selected TP batch stage, optional bulk four-eyes approval, batch preflight and controlled parallel LIVE.
- Added worksheet/Excel-row traceability to execution evidence.
- Retained all V122 environment settings and V122 four-worker stability behavior.

## Current release principle

The agent may understand and map values, but the backend contract remains authoritative. A field present in Excel does not become an API field unless it exists in the selected V122-approved TP schema.
