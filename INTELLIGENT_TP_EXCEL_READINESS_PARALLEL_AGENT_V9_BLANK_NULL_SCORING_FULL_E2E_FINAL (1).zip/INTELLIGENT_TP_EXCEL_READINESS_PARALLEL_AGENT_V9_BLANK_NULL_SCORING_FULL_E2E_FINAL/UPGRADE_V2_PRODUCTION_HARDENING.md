# V2 Production Hardening Upgrade

Added on top of the original standalone Excel → API Decision Agent:

- Contract version/owner/lifecycle governance + immutable contract SHA-256
- Per-field validation rules (type/enum/regex/min/max/length)
- Workbook data-quality profiling and duplicate identity detection
- Prior-success duplicate guard with allow/warn/block policy
- Optional four-eyes approval workflow
- Batch Stage-Good and batch preflight (no batch LIVE)
- Contract/payload fingerprint lock between stage, preflight and LIVE
- Safe idempotency-aware retry with exponential backoff
- Per-host circuit breaker
- Sensitive request/response redaction
- GET/HEAD-only remote preflight checks
- Tamper-evident append-only SHA-256 audit chain
- Readiness CSV export
- Per-API starter CSV template generation
- OpenAPI 3 / Swagger 2 JSON/YAML conversion to DRAFT contracts
- Postman Collection conversion with auth-secret masking
- Catalog validation for dependencies/cycles/unsafe definitions
- Expanded system/runtime UI and evidence surfaces
