# V8 Final Validation — Team Mapping Corrections

## Release

- Application: Intelligent TP Excel Readiness & Parallel Execution Agent
- Version: 8.0.0
- Focus: exact Excel evidence -> V122 Transport Profile payload mapping
- Live HIP mutation during validation: **NO**

## Team feedback implemented

| Team finding | V8 behavior | Validation |
|---|---|---|
| `DEV-Transport Profile Name` wording was treated as mandatory | API requires `transportProfileName`; Excel may provide Source/Target/Transport Profile Name or the legacy DEV-labelled column. `LENS TP Name` is never used as executable TP identity. | PASS |
| `documentTypeName` should be empty when Excel has no document type | Document type name/version are optional for this TP readiness flow. Missing evidence stays blank; no `1` / `1.0` is fabricated. `NAME(1.0)` is split only when that exact syntax is present. | PASS |
| Subscription Folder was taking `Directory` | Hard provenance lock: `Directory` is evidence-only and can never populate `Subscription Folder`. Subscription Folder is mapped only from an explicit subscription-folder field. | PASS |
| interfaceType was taking the wrong Excel column/value | Exact generic `Interface Type` / `TP Interface Type` / `API Interface Type` is authoritative when present. Legacy Source/Target Interface Type fields cannot override it. `SFTP Server` is explicitly canonicalized to V122 API `SFTP HAFT`. | PASS |
| Existing Account Name was wrong | `Hip Account names` / `HIP Account` are metadata only and never populate FILE `Existing Account Name`. The value comes from explicit TP Existing Account fields or the grouped Transport Profile Details `Account` column. | PASS |
| Duplicate `Account` headers lost their business context | Workbook reader preserves parent/group context for duplicate headers so `Transport Profile Details > ... > Account` can be distinguished from unrelated Account columns. | PASS |

## Readiness behavior

For a FILE/SFTP TP candidate, V8 hard-checks the executable TP core and provenance rather than treating optional evidence as mandatory:

- System mapped
- `transportProfileName` mapped
- explicit Excel Interface Type recognized and mapped to the approved V122 API value
- Existing Account Name available from approved TP-specific evidence
- schema lock / field rules / duplicate conflicts / mapping confidence

Document Type is optional: if unavailable in Excel, name and version remain blank.
Subscription Folder is optional unless explicitly supplied; it is never derived from Directory.

## Team-shaped regression case

Representative input:

- `DEV-Transport Profile Name = SFTP_ATEA_SRC_OB`
- `Interface Type = SFTP Server`
- legacy `Source Interface Type = Directory Monitor inbound`
- `Hip Account names = ATEA_PC`
- grouped `Transport Profile Details > Account = dklp_dell`
- `Directory = /TestInbound`
- Document Type blank

Expected / verified output:

- `transportProfileName = SFTP_ATEA_SRC_OB`
- API `interfaceType = SFTP HAFT`
- HIP Account metadata = `ATEA_PC`
- FILE `Existing Account Name = dklp_dell`
- FILE `Subscription Folder = ""`
- `Directory = /TestInbound` remains evidence-only
- document type name/version remain blank
- readiness = `GOOD_TO_TRIGGER` when all other required TP evidence is present

## Automated validation

- Pytest: **56 / 56 PASS**
- Python compilation: **PASS**
- Frontend JavaScript syntax: **PASS**
- `GET /api/health`: **HTTP 200**
- `GET /api/bootstrap`: **HTTP 200**
- `GET /`: **HTTP 200**
- API catalog at bootstrap: **25 contracts, valid**

## Runtime / credential note

The validation container intentionally does not contain the user's Dell credentials. Therefore an authenticated Dell AIA / HIP LIVE mutation was not executed here. The application retains the V122-compatible runtime/OAuth environment model and the non-mutating U-HAUL TP validation smoke test for execution in the user's credentialed environment.

## Safety

- LLM cannot change API schema/paths.
- Provenance-locked fields cannot be filled by fuzzy/LLM fallback.
- Missing values remain missing unless an approved deterministic runtime/default rule exists.
- LIVE and bulk LIVE remain separately governed by environment flags, contract permissions, preflight/fingerprint checks, host allowlisting, and explicit confirmation.
