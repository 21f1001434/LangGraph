from __future__ import annotations

import csv
import io
import json
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .catalog import CATALOG_PATH, catalog_public, load_catalog, normalize_contract, parse_imported_catalog, schema_locked, validate_catalog
from .executor import bulk_live_enabled, execute, four_eyes_required, live_enabled, parallel_workers, preflight, probe_contract_endpoint, probe_uhal_tp_validation, remote_preflight_enabled, runtime_summary, target_auth_diagnostics, test_contract_oauth
from .governance import fingerprint, identity_fingerprint, validate_field_rules
from .llm import DellAIAClient
from .importers import parse_api_definition
from .mapper import analyze_workbook
from .tp_service import analyze_tp_workbook, TP_KEYS
from .reporting import render_tp_readiness_report
from .uhal_reference import create_payload as uhal_create_payload, validation_payload as uhal_validation_payload
from .state import STATE

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env", override=False)
STATIC = ROOT / "app" / "static"
REFERENCE_CATALOG = ROOT / "config" / "api_catalog.reference.json"

app = FastAPI(title="Intelligent TP Excel Readiness & Parallel Execution Agent", version="9.0.0")


def contracts():
    if STATE.session_catalog is not None: return deepcopy(STATE.session_catalog)
    return load_catalog()


def contract_by_key(key: str):
    row = next((c for c in contracts() if c["key"] == key), None)
    if not row: raise HTTPException(404, f"API contract {key!r} not found")
    return row


class StageRequest(BaseModel):
    analysisId: str; rowId: str; payload: Dict[str, Any]; reviewer: str = "Human User"

class BatchStageRequest(BaseModel):
    analysisId: str; reviewer: str = "Human User"

class TPBatchStageRequest(BaseModel):
    analysisId: str
    actionIds: List[str] = []
    reviewer: str = "Human User"

class BatchPreflightRequest(BaseModel):
    stageIds: List[str]

class BatchExecuteRequest(BaseModel):
    stageIds: List[str]
    confirmation: str = Field(..., description="Must be exactly LIVE ALL")
    actor: str = "Human User"
    continueOnError: bool = True
    maxWorkers: int = 0

class ApprovalRequest(BaseModel):
    approver: str; comment: str = ""

class BatchApprovalRequest(BaseModel):
    stageIds: List[str]
    approver: str
    comment: str = ""

class ExecuteRequest(BaseModel):
    confirmation: str = Field(..., description="Must be exactly LIVE")
    actor: str = "Human User"


def _stage_row(analysis: Dict[str, Any], row: Dict[str, Any], payload: Dict[str, Any], reviewer: str) -> Dict[str, Any]:
    # TP V4 can create an interface-specific schema snapshot per Excel row. Prefer
    # that exact analyzed contract so AS2/NAS/Rabbit MQ cannot fall back to the FILE shape.
    snapshot = row.get("contractSnapshot") if isinstance(row.get("contractSnapshot"), dict) else None
    contract = normalize_contract(snapshot) if snapshot else contract_by_key(str(row.get("apiKey") or ""))
    if not schema_locked(contract["canonical_request"], payload):
        raise ValueError("API attributes/nesting/cardinality changed. Only values may be edited")
    if not schema_locked(row.get("baseRequest") or {}, payload):
        raise ValueError("Payload no longer matches the analyzed API schema")
    findings = validate_field_rules(payload, contract)
    staged = STATE.stage({
        "analysisId": analysis.get("analysisId"), "rowId": row.get("rowId") or row.get("actionId"), "excelRow": row.get("excelRow"), "sheetName": row.get("sheetName"), "account": row.get("hipAccountName") or row.get("account"),
        "analysisStatus": row.get("status"), "analysisScore": row.get("score"), "apiKey": contract["key"], "apiName": contract["name"],
        "reviewer": reviewer, "payload": deepcopy(payload), "contractSnapshot": {k: deepcopy(v) for k, v in contract.items()},
        "contractSha256": contract.get("contract_sha256"), "contractVersion": contract.get("version"),
        "identityFingerprint": identity_fingerprint(contract, payload), "fieldRuleFindingsAtStage": findings,
        "mappingEvidence": deepcopy(row.get("mappings") or []), "unmappedColumns": deepcopy(row.get("unmappedColumns") or []),
    })
    if not four_eyes_required():
        staged["approvalStatus"] = "APPROVED"
        staged["approvals"] = [{"approver": reviewer, "comment": "Single-review mode: staging approval", "approvedAt": staged.get("createdAt")}]
        STATE.save_stage(staged)
    return staged


@app.get("/api/health")
def health() -> Dict[str, Any]:
    client = DellAIAClient(); cs = contracts()
    return {
        "ok": True, "app": "Intelligent TP Excel Readiness & Parallel Execution Agent", "version": "9.0.0",
        "catalogApis": len(cs), "catalogValid": validate_catalog(cs)["valid"], "llm": client.diagnostics(),
        "liveExecutionEnabled": live_enabled(), "bulkLiveEnabled": bulk_live_enabled(), "bulkWorkers": parallel_workers(),
        "remotePreflightEnabled": remote_preflight_enabled(), "fourEyesRequired": four_eyes_required(),
        "targetApiAuth": target_auth_diagnostics(), "runtime": runtime_summary(),
    }


@app.post("/api/runtime/deep-health")
def deep_runtime_health() -> Dict[str, Any]:
    """Actively verify agent, OAuth and the real TP validation service.

    V7 no longer declares the create API DOWN because an OPTIONS request returns
    HTTP 500. Source/Target TP health is established with the V122 non-mutating
    U-HAUL validation request. The create route OPTIONS result is retained only as
    secondary/inconclusive diagnostics. No TP Create request is sent here.
    """
    checked = datetime.now(timezone.utc).isoformat()
    cs = contracts()
    validation = validate_catalog(cs)
    source = next((c for c in cs if c.get("key") == "source_tp"), None)
    target = next((c for c in cs if c.get("key") == "target_tp"), None)
    llm = DellAIAClient().test()
    oauth = test_contract_oauth(source) if source else {"ok": False, "state": "DOWN", "message": "source_tp contract missing"}
    if source and oauth.get("ok"):
        source_api = probe_uhal_tp_validation(source, "source")
    elif source:
        source_api = {"ok": False, "state": "AUTH_FAILED", "message": "U-HAUL source validation not run because HIP OAuth failed", "mutating": False}
    else:
        source_api = {"ok": False, "state": "DOWN", "message": "source_tp contract missing"}
    if target and oauth.get("ok"):
        target_api = probe_uhal_tp_validation(target, "target")
    elif target:
        target_api = {"ok": False, "state": "AUTH_FAILED", "message": "U-HAUL target validation not run because HIP OAuth failed", "mutating": False}
    else:
        target_api = {"ok": False, "state": "DOWN", "message": "target_tp contract missing"}
    create_route = probe_contract_endpoint(source, authenticated=False) if source else {"ok": False, "state": "DOWN", "message": "source_tp contract missing"}
    components = {
        "backend": {"ok": True, "state": "UP", "message": "FastAPI backend is running"},
        "catalog": {"ok": bool(validation.get("valid")), "state": "UP" if validation.get("valid") else "DOWN", "message": f"{len(cs)} API contracts loaded; {len(validation.get('errors') or [])} validation error(s)"},
        "agent": {"ok": bool(llm.get("ok")), "state": "UP" if llm.get("ok") else "DOWN", "message": (f"Dell AIA {llm.get('diagnostics',{}).get('model','')} responded successfully" if llm.get("ok") else llm.get("error") or "Dell AIA test failed"), "details": llm.get("diagnostics") or {}},
        "hipOauth": oauth,
        "sourceTpApi": source_api,
        "targetTpApi": target_api,
        "tpCreateRouteProbe": create_route,
    }
    critical = [components["backend"], components["catalog"], components["agent"], components["hipOauth"], components["sourceTpApi"], components["targetTpApi"]]
    overall = all(bool(x.get("ok")) for x in critical)
    return {
        "ok": overall, "checkedAt": checked, "overallState": "UP" if overall else "ATTENTION",
        "nonMutating": True, "healthMethod": "V122_UHAL_TP_VALIDATION",
        "components": components, "runtime": runtime_summary(),
        "note": "Source/Target TP API verdicts come from non-mutating U-HAUL validation POSTs. Create-route OPTIONS is diagnostic only."
    }


@app.post("/api/runtime/uhal-tp-smoke")
def uhal_tp_smoke() -> Dict[str, Any]:
    """Non-mutating V122 U-HAUL TP smoke test using exact supplied reference values."""
    cs = contracts()
    source = next((c for c in cs if c.get("key") == "source_tp"), None)
    target = next((c for c in cs if c.get("key") == "target_tp"), None)
    if not source or not target:
        raise HTTPException(500, "source_tp / target_tp contracts are missing")
    oauth = test_contract_oauth(source)
    src = probe_uhal_tp_validation(source, "source") if oauth.get("ok") else {"ok": False, "state": "AUTH_FAILED", "message": "OAuth failed"}
    tgt = probe_uhal_tp_validation(target, "target") if oauth.get("ok") else {"ok": False, "state": "AUTH_FAILED", "message": "OAuth failed"}
    src_create = uhal_create_payload("source")
    tgt_create = uhal_create_payload("target")
    result = {
        "ok": bool(oauth.get("ok") and src.get("ok") and tgt.get("ok")),
        "nonMutating": True, "reference": "V122 developer-approved U-HAUL Transport Profile",
        "oauth": oauth, "sourceValidation": src, "targetValidation": tgt,
        "sourceValidationPayload": uhal_validation_payload("source"),
        "targetValidationPayload": uhal_validation_payload("target"),
        "sourceCreatePayloadPreview": src_create, "targetCreatePayloadPreview": tgt_create,
        "sourceCreateFingerprint": fingerprint(src_create), "targetCreateFingerprint": fingerprint(tgt_create),
        "message": "No TP Create API was called. This smoke test validates OAuth + TP validator + exact V122 U-HAUL payload parity."
    }
    STATE.audit("UHAL_TP_SMOKE_TEST", details={"ok": result["ok"], "sourceState": src.get("state"), "targetState": tgt.get("state")})
    return result


@app.get("/api/bootstrap")
def bootstrap() -> Dict[str, Any]:
    client = DellAIAClient(); cs = contracts()
    return {
        "app": {"name": "Intelligent TP Excel Readiness & Parallel Execution Agent", "version": "9.0.0", "standalone": True, "envCompatibility": "V122", "currentMode": "TRANSPORT_PROFILE_ONLY"},
        "catalog": catalog_public(cs), "catalogValidation": validate_catalog(cs), "llm": client.diagnostics(),
        "liveExecutionEnabled": live_enabled(), "remotePreflightEnabled": remote_preflight_enabled(), "fourEyesRequired": four_eyes_required(),
        "targetApiAuth": target_auth_diagnostics(), "bulkLiveEnabled": bulk_live_enabled(), "bulkWorkers": parallel_workers(), "runtime": runtime_summary(),
        "governance": {"schemaImmutable": True, "agentCanMapValues": True, "agentCanExecute": False, "humanStageRequired": True,
                       "approvalWorkflow": "four-eyes" if four_eyes_required() else "single-review", "preflightRequired": True,
                       "explicitLiveConfirmation": "LIVE", "hostAllowlistRequired": True, "contractVersionLocked": True,
                       "duplicateGuard": True, "tamperEvidentAudit": True, "sensitiveLogRedaction": True, "multiApiMatrix": True, "bulkStagePreflightLive": True, "v122Environment": True},
    }


@app.get("/api/catalog")
def get_catalog() -> Dict[str, Any]:
    cs = contracts(); return {"apis": catalog_public(cs), "validation": validate_catalog(cs)}

@app.get("/api/catalog/validate")
def catalog_validate() -> Dict[str, Any]: return validate_catalog(contracts())

@app.post("/api/catalog/import")
async def import_catalog(file: UploadFile = File(...), persist: bool = Form(True)) -> Dict[str, Any]:
    try:
        imported = parse_imported_catalog(await file.read()); STATE.session_catalog = imported
        if persist:
            serializable = [{k: deepcopy(v) for k, v in c.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}} for c in imported]
            CATALOG_PATH.write_text(json.dumps({"apis": serializable}, ensure_ascii=False, indent=2), encoding="utf-8")
        STATE.audit("CATALOG_IMPORTED", details={"count": len(imported), "persisted": bool(persist)})
        return {"ok": True, "count": len(imported), "persisted": bool(persist), "validation": validate_catalog(imported), "apis": catalog_public(imported)}
    except Exception as exc: raise HTTPException(400, f"Could not import API catalog: {type(exc).__name__}: {exc}")

@app.post("/api/catalog/import-spec")
async def import_api_spec(file: UploadFile = File(...), persist: bool = Form(False)) -> Dict[str, Any]:
    try:
        raw_rows, kind = parse_api_definition(await file.read(), file.filename or "")
        imported = [normalize_contract(x) for x in raw_rows]
        validation = validate_catalog(imported)
        if validation["errors"]:
            raise ValueError("; ".join(validation["errors"][:10]))
        # Spec imports are intentionally DRAFT and LIVE-disabled. Merge into current catalog by key.
        merged = {c["key"]: c for c in contracts()}
        for c in imported:
            merged[c["key"]] = c
        final = list(merged.values()); STATE.session_catalog = final
        if persist:
            serializable = [{k: deepcopy(v) for k, v in c.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}} for c in final]
            CATALOG_PATH.write_text(json.dumps({"apis": serializable}, ensure_ascii=False, indent=2), encoding="utf-8")
        STATE.audit("API_SPEC_IMPORTED", details={"kind": kind, "operations": len(imported), "persisted": bool(persist)})
        return {"ok": True, "kind": kind, "count": len(imported), "persisted": bool(persist), "validation": validate_catalog(final), "apis": catalog_public(imported)}
    except Exception as exc:
        raise HTTPException(400, f"Could not import API definition: {type(exc).__name__}: {exc}")


@app.post("/api/catalog/reset")
def reset_catalog() -> Dict[str, Any]:
    if not REFERENCE_CATALOG.exists(): raise HTTPException(404, "Reference catalog not found")
    shutil.copy2(REFERENCE_CATALOG, CATALOG_PATH); STATE.session_catalog = None; STATE.audit("CATALOG_RESET")
    return {"ok": True, "apis": catalog_public(load_catalog())}

@app.get("/api/catalog/export")
def export_catalog() -> FileResponse: return FileResponse(CATALOG_PATH, media_type="application/json", filename="api_catalog.json")

@app.get("/api/catalog/{api_key}/excel-template.csv")
def api_excel_template(api_key: str) -> Response:
    contract = contract_by_key(api_key)
    # Prefer friendly aliases when they uniquely point at a canonical path; otherwise use the exact path.
    aliases = contract.get("header_aliases") or {}
    path_to_header: Dict[str, str] = {}
    for header, target in aliases.items():
        targets = [target] if isinstance(target, str) else target if isinstance(target, list) else []
        for t in targets:
            if str(t) in contract.get("paths", []) and str(t) not in path_to_header:
                path_to_header[str(t)] = str(header)
    headers = [path_to_header.get(path, path) for path in contract.get("paths", [])]
    out = io.StringIO(); writer = csv.writer(out); writer.writerow(headers)
    return Response(out.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{api_key}_excel_template.csv"'})



@app.post("/api/llm/test")
def llm_test() -> Dict[str, Any]: return DellAIAClient().test()


@app.post("/api/analyze")
async def analyze(workbook: UploadFile = File(...), api_key: str = Form("AUTO"), sheet_name: str = Form(""), header_row: int = Form(0), use_llm: bool = Form(True)) -> Dict[str, Any]:
    try:
        result = analyze_workbook(filename=workbook.filename or "workbook.xlsx", data=await workbook.read(), contracts=contracts(),
                                  selected_api=str(api_key or "AUTO"), requested_sheet=sheet_name, header_row=int(header_row or 0), use_llm=bool(use_llm))
        analysis_id = STATE.add_analysis(result); return STATE.get_analysis(analysis_id)
    except Exception as exc: raise HTTPException(400, f"Workbook analysis failed: {type(exc).__name__}: {exc}")

@app.post("/api/tp/analyze")
async def analyze_transport_profiles(
    workbook: UploadFile = File(...),
    tp_scope: str = Form("BOTH"),
    sheet_name: str = Form(""),
    header_row: int = Form(0),
    use_llm: bool = Form(True),
    scan_all_sheets: bool = Form(True),
) -> Dict[str, Any]:
    try:
        result = analyze_tp_workbook(
            filename=workbook.filename or "transport_profiles.xlsx", data=await workbook.read(), contracts=contracts(),
            scope=str(tp_scope or "BOTH"), requested_sheet=sheet_name, header_row=int(header_row or 0),
            use_llm=bool(use_llm), scan_all_sheets=bool(scan_all_sheets),
        )
        analysis_id = STATE.add_analysis(result)
        return STATE.get_analysis(analysis_id)
    except Exception as exc:
        raise HTTPException(400, f"TP workbook analysis failed: {type(exc).__name__}: {exc}")


@app.get("/api/tp/analyses/{analysis_id}/actions/{action_id}")
def tp_action_detail(analysis_id: str, action_id: str) -> Dict[str, Any]:
    try:
        analysis = STATE.get_analysis(analysis_id)
    except KeyError:
        raise HTTPException(404, "TP analysis session not found")
    actions = analysis.get("allApiResults") or analysis.get("tpActions") or analysis.get("results") or []
    row = next((r for r in actions if str(r.get("actionId") or r.get("rowId") or "") == str(action_id)), None)
    if not row:
        raise HTTPException(404, "TP customer/action mapping not found")
    return {"analysisId": analysis_id, "action": row}


@app.get("/api/tp/analyses/{analysis_id}/actions/{action_id}/report.html")
def tp_action_report(analysis_id: str, action_id: str, download: bool = True) -> Response:
    try:
        analysis = STATE.get_analysis(analysis_id)
    except KeyError:
        raise HTTPException(404, "TP analysis session not found")
    actions = analysis.get("allApiResults") or analysis.get("tpActions") or analysis.get("results") or []
    row = next((r for r in actions if str(r.get("actionId") or r.get("rowId") or "") == str(action_id)), None)
    if not row:
        raise HTTPException(404, "TP customer/action mapping not found")
    mini = deepcopy(analysis)
    mini["tpActions"] = [deepcopy(row)]; mini["allApiResults"] = [deepcopy(row)]; mini["results"] = [deepcopy(row)]
    status = str(row.get("status") or "")
    mini["summary"] = {"records": 1, "accounts": 1, "tpActions": 1, "rows": 1, "GOOD_TO_TRIGGER": int(status == "GOOD_TO_TRIGGER"), "NEEDS_INPUT": int(status == "NEEDS_INPUT"), "DO_NOT_TRIGGER": int(status == "DO_NOT_TRIGGER")}
    mini["diagnosticsSummary"] = {"topBlockers": [{"check": c.get("name"), "count": 1} for c in (row.get("readinessChecks") or []) if c.get("blocking")], "interfaceMappings": [{"excelValue": row.get("interfaceRawValue"), "apiValue": row.get("interfaceType"), "count": 1}]}
    body = render_tp_readiness_report(mini)
    safe_name = str(row.get("tpName") or row.get("hipAccountName") or "TP").replace("/", "_").replace("\\", "_")
    headers = {"Content-Disposition": f'attachment; filename="TP_Mapping_{safe_name}_{row.get("excelRow")}.html"'} if download else {}
    return Response(body, media_type="text/html; charset=utf-8", headers=headers)


@app.get("/api/tp/analyses/{analysis_id}/report.html")
def tp_readiness_report(analysis_id: str, download: bool = True) -> Response:
    try:
        analysis = STATE.get_analysis(analysis_id)
    except KeyError:
        raise HTTPException(404, "TP analysis session not found")
    if analysis.get("mode") != "TRANSPORT_PROFILE_ONLY":
        raise HTTPException(400, "This analysis is not a TP-only readiness analysis")
    body = render_tp_readiness_report(analysis)
    headers = {}
    if download:
        headers["Content-Disposition"] = f'attachment; filename="TP_Readiness_{analysis_id}.html"'
    return Response(body, media_type="text/html; charset=utf-8", headers=headers)


@app.post("/api/tp/batch/stage")
def tp_batch_stage_selected(req: TPBatchStageRequest) -> Dict[str, Any]:
    try:
        analysis = STATE.get_analysis(req.analysisId)
    except KeyError:
        raise HTTPException(404, "TP analysis session not found")
    if analysis.get("mode") != "TRANSPORT_PROFILE_ONLY":
        raise HTTPException(400, "Selected analysis is not TP-only")
    actions = analysis.get("allApiResults") or analysis.get("tpActions") or []
    wanted = set(req.actionIds or [])
    selected = [r for r in actions if (not wanted or str(r.get("actionId") or "") in wanted)]
    stages, skipped = [], []
    for row in selected:
        aid = row.get("actionId") or row.get("rowId")
        if row.get("apiKey") not in TP_KEYS:
            skipped.append({"actionId": aid, "reason": "not a TP Create action"}); continue
        if row.get("status") != "GOOD_TO_TRIGGER":
            skipped.append({"actionId": aid, "reason": row.get("readinessLabel") or row.get("status")}); continue
        try:
            stages.append(_stage_row(analysis, row, deepcopy(row.get("proposedRequest") or {}), req.reviewer))
        except Exception as exc:
            skipped.append({"actionId": aid, "reason": str(exc)})
    STATE.audit("TP_BATCH_STAGE", actor=req.reviewer, details={"analysisId": req.analysisId, "selected": len(selected), "staged": len(stages), "skipped": len(skipped)})
    return {"ok": True, "selected": len(selected), "staged": len(stages), "skipped": skipped, "stages": stages}


@app.get("/api/analyses/{analysis_id}/export.csv")
def export_analysis_csv(analysis_id: str) -> Response:
    try: analysis = STATE.get_analysis(analysis_id)
    except KeyError: raise HTTPException(404, "Analysis session not found")
    out = io.StringIO(); writer = csv.writer(out)
    writer.writerow(["sheet", "excelRow", "account", "tpRole", "tpName", "systemName", "interfaceType", "documentTypeName", "apiKey", "status", "readinessLabel", "score", "mappedCount", "missingRequiredPaths", "unmappedColumns", "warnings"])
    rows = analysis.get("tpActions") or analysis.get("results") or []
    for r in rows:
        writer.writerow([r.get("sheetName"), r.get("excelRow"), r.get("hipAccountName") or r.get("account"), r.get("tpRole"), r.get("tpName"), r.get("systemName"), r.get("interfaceType"), r.get("documentTypeName"), r.get("apiKey"), r.get("status"), r.get("readinessLabel"), r.get("score"), r.get("mappedCount"),
                         " | ".join(r.get("missingRequiredPaths") or []), " | ".join(r.get("unmappedColumns") or []), " | ".join(r.get("warnings") or [])])
    return Response(out.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{analysis_id}_readiness.csv"'})


@app.post("/api/stage")
def stage(req: StageRequest) -> Dict[str, Any]:
    try:
        analysis = STATE.get_analysis(req.analysisId)
    except KeyError:
        raise HTTPException(404, "Analysis session not found. Re-analyze the workbook")
    candidates = list(analysis.get("results") or []) + list(analysis.get("allApiResults") or [])
    row = next((r for r in candidates if r.get("rowId") == req.rowId or r.get("actionId") == req.rowId), None)
    if not row:
        raise HTTPException(404, "Analyzed API action not found")
    try:
        staged = _stage_row(analysis, row, req.payload, req.reviewer)
    except Exception as exc:
        raise HTTPException(400, f"Stage rejected: {exc}")
    return {"ok": True, "stage": staged}


@app.post("/api/batch/stage-good")
def batch_stage_good(req: BatchStageRequest) -> Dict[str, Any]:
    try:
        analysis = STATE.get_analysis(req.analysisId)
    except KeyError:
        raise HTTPException(404, "Analysis session not found")
    # AUTO mode stages every applicable GOOD API action, not only the top recommendation.
    source_rows = analysis.get("allApiResults") or analysis.get("results") or []
    stages = []
    skipped = []
    seen: set[tuple[int, str, str]] = set()
    for row in source_rows:
        marker = (int(row.get("excelRow") or 0), str(row.get("apiKey") or ""), str(row.get("identityFingerprint") or ""))
        if marker in seen:
            continue
        seen.add(marker)
        if row.get("status") != "GOOD_TO_TRIGGER":
            skipped.append({"actionId": row.get("actionId") or row.get("rowId"), "excelRow": row.get("excelRow"), "apiKey": row.get("apiKey"), "reason": row.get("status")})
            continue
        try:
            stages.append(_stage_row(analysis, row, deepcopy(row.get("proposedRequest") or {}), req.reviewer))
        except Exception as exc:
            skipped.append({"actionId": row.get("actionId") or row.get("rowId"), "excelRow": row.get("excelRow"), "apiKey": row.get("apiKey"), "reason": str(exc)})
    STATE.audit("BATCH_STAGE_GOOD", actor=req.reviewer, details={"analysisId": req.analysisId, "staged": len(stages), "skipped": len(skipped)})
    return {"ok": True, "staged": len(stages), "skipped": skipped, "stages": stages}


@app.post("/api/stages/{stage_id}/approve")
def approve_stage(stage_id: str, req: ApprovalRequest) -> Dict[str, Any]:
    try:
        stage = STATE.approve_stage(stage_id, req.approver, req.comment, four_eyes=four_eyes_required())
    except KeyError:
        raise HTTPException(404, "Stage not found")
    except Exception as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "stage": stage}


@app.post("/api/stages/{stage_id}/reject")
def reject_stage(stage_id: str, req: ApprovalRequest) -> Dict[str, Any]:
    try:
        stage = STATE.reject_stage(stage_id, req.approver, req.comment)
    except KeyError:
        raise HTTPException(404, "Stage not found")
    return {"ok": True, "stage": stage}


@app.post("/api/batch/approve")
def batch_approve(req: BatchApprovalRequest) -> Dict[str, Any]:
    approved = []
    failed = []
    for stage_id in req.stageIds[:1000]:
        try:
            stage = STATE.approve_stage(stage_id, req.approver, req.comment, four_eyes=four_eyes_required())
            approved.append({"stageId": stage_id, "approvalStatus": stage.get("approvalStatus")})
        except Exception as exc:
            failed.append({"stageId": stage_id, "error": str(exc)})
    STATE.audit("BATCH_STAGE_APPROVED", actor=req.approver, details={"approved": len(approved), "failed": len(failed)})
    return {"ok": not failed, "approved": len(approved), "failed": failed, "stages": approved}


def _preflight_stage(stage_id: str) -> Dict[str, Any]:
    stage = STATE.get_stage(stage_id)
    contract = normalize_contract(stage.get("contractSnapshot") or {})
    duplicate = STATE.successful_duplicate(contract["key"], str(stage.get("identityFingerprint") or ""))
    result = preflight(stage, contract, duplicate_run=duplicate)
    stage["preflight"] = result
    STATE.save_stage(stage)
    STATE.audit("PREFLIGHT_RUN", stage_id=stage_id, details={"passed": result.get("passed"), "errors": len(result.get("errors") or []), "warnings": len(result.get("warnings") or [])})
    return result


@app.post("/api/stages/{stage_id}/preflight")
def run_preflight(stage_id: str) -> Dict[str, Any]:
    try:
        result = _preflight_stage(stage_id)
    except KeyError:
        raise HTTPException(404, "Stage not found")
    return {"ok": True, "stageId": stage_id, "preflight": result}


@app.post("/api/batch/preflight")
def batch_preflight(req: BatchPreflightRequest) -> Dict[str, Any]:
    results = []
    for stage_id in req.stageIds[:1000]:
        try:
            pf = _preflight_stage(stage_id)
            results.append({"stageId": stage_id, "passed": pf.get("passed"), "errors": pf.get("errors"), "warnings": pf.get("warnings"), "apiKey": STATE.get_stage(stage_id).get("apiKey")})
        except Exception as exc:
            results.append({"stageId": stage_id, "passed": False, "errors": [str(exc)], "warnings": []})
    STATE.audit("BATCH_PREFLIGHT", details={"total": len(results), "passed": sum(1 for x in results if x.get("passed"))})
    return {"ok": True, "passed": sum(1 for x in results if x.get("passed")), "total": len(results), "results": results}


@app.post("/api/stages/{stage_id}/execute")
def run_live(stage_id: str, req: ExecuteRequest) -> Dict[str, Any]:
    try:
        stage = STATE.get_stage(stage_id)
    except KeyError:
        raise HTTPException(404, "Stage not found")
    contract = normalize_contract(stage.get("contractSnapshot") or {})
    try:
        run = execute(stage, contract, req.confirmation, actor=req.actor)
    except Exception as exc:
        raise HTTPException(400, f"LIVE execution blocked/failed before response: {type(exc).__name__}: {exc}")
    saved = STATE.save_run(run)
    stage["executed"] = True
    stage["runId"] = saved["runId"]
    STATE.save_stage(stage)
    return {"ok": True, "run": saved}


def _dependency_depth(key: str, by_key: Dict[str, Dict[str, Any]], memo: Dict[str, int]) -> int:
    if key in memo:
        return memo[key]
    deps = [d for d in (by_key.get(key, {}).get("depends_on") or []) if d in by_key]
    memo[key] = 0 if not deps else 1 + max(_dependency_depth(d, by_key, memo) for d in deps)
    return memo[key]


@app.post("/api/batch/execute")
def batch_execute(req: BatchExecuteRequest) -> Dict[str, Any]:
    if str(req.confirmation or "").strip() != "LIVE ALL":
        raise HTTPException(400, "Type LIVE ALL exactly to confirm bulk execution")
    if not live_enabled():
        raise HTTPException(400, "HIP_LIVE_API_EXECUTION=true is required")
    if not bulk_live_enabled():
        raise HTTPException(400, "Bulk LIVE is disabled. Set HIP_BULK_LIVE_EXECUTION=true (or use V122 strict LIVE mode)")

    loaded = []
    for stage_id in req.stageIds[:1000]:
        try:
            stage = STATE.get_stage(stage_id)
            contract = normalize_contract(stage.get("contractSnapshot") or {})
            pf = stage.get("preflight") or {}
            if stage.get("executed"):
                loaded.append({"stage": stage, "contract": contract, "skip": "already executed"})
            elif not pf.get("passed"):
                loaded.append({"stage": stage, "contract": contract, "skip": "preflight not passed"})
            else:
                loaded.append({"stage": stage, "contract": contract, "skip": ""})
        except Exception as exc:
            loaded.append({"stage": {"stageId": stage_id}, "contract": {}, "skip": f"load failed: {exc}"})

    executable = [x for x in loaded if not x["skip"]]
    contracts_by_key = {x["contract"]["key"]: x["contract"] for x in executable if x.get("contract")}
    memo: Dict[str, int] = {}
    waves: Dict[int, List[Dict[str, Any]]] = {}
    for item in executable:
        depth = _dependency_depth(item["contract"]["key"], contracts_by_key, memo)
        waves.setdefault(depth, []).append(item)

    max_workers = req.maxWorkers if req.maxWorkers > 0 else parallel_workers()
    max_workers = max(1, min(max_workers, parallel_workers()))
    succeeded: set[tuple[int, str]] = set()
    failed: set[tuple[int, str]] = set()
    results: List[Dict[str, Any]] = []
    skipped = [
        {"stageId": x["stage"].get("stageId"), "apiKey": x.get("contract", {}).get("key"), "excelRow": x["stage"].get("excelRow"), "reason": x["skip"]}
        for x in loaded if x["skip"]
    ]

    def run_one(item: Dict[str, Any]) -> Dict[str, Any]:
        stage = item["stage"]
        contract = item["contract"]
        run = execute(stage, contract, "LIVE", actor=req.actor)
        saved = STATE.save_run(run)
        stage["executed"] = True
        stage["runId"] = saved["runId"]
        STATE.save_stage(stage)
        return saved

    for depth in sorted(waves):
        wave = []
        for item in waves[depth]:
            stage = item["stage"]
            contract = item["contract"]
            excel_row = int(stage.get("excelRow") or 0)
            deps_present = [d for d in (contract.get("depends_on") or []) if any(int(x["stage"].get("excelRow") or 0) == excel_row and x.get("contract", {}).get("key") == d for x in executable)]
            failed_deps = [d for d in deps_present if (excel_row, d) in failed]
            if failed_deps:
                skipped.append({"stageId": stage.get("stageId"), "apiKey": contract.get("key"), "excelRow": excel_row, "reason": "dependency failed: " + ", ".join(failed_deps)})
                failed.add((excel_row, contract["key"]))
            else:
                wave.append(item)
        if not wave:
            continue
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="hip-bulk") as pool:
            futures = {pool.submit(run_one, item): item for item in wave}
            for future in as_completed(futures):
                item = futures[future]
                stage = item["stage"]
                contract = item["contract"]
                key = (int(stage.get("excelRow") or 0), contract["key"])
                try:
                    run = future.result()
                    results.append(run)
                    if run.get("success"):
                        succeeded.add(key)
                    else:
                        failed.add(key)
                        if not req.continueOnError:
                            skipped.extend({"stageId": f["stage"].get("stageId"), "apiKey": f["contract"].get("key"), "excelRow": f["stage"].get("excelRow"), "reason": "batch stopped after API failure"} for later_depth in sorted(waves) if later_depth > depth for f in waves[later_depth])
                            break
                except Exception as exc:
                    failed.add(key)
                    results.append({"stageId": stage.get("stageId"), "apiKey": contract.get("key"), "apiName": contract.get("name"), "excelRow": stage.get("excelRow"), "account": stage.get("account"), "success": False, "error": f"{type(exc).__name__}: {exc}"})
                    if not req.continueOnError:
                        break

    summary = {
        "requested": len(req.stageIds),
        "executed": len(results),
        "successful": sum(1 for r in results if r.get("success")),
        "failed": sum(1 for r in results if not r.get("success")),
        "skipped": len(skipped),
        "workers": max_workers,
        "waves": len(waves),
    }
    STATE.audit("BATCH_LIVE_EXECUTED", actor=req.actor, details=summary)
    return {"ok": True, "summary": summary, "runs": results, "skipped": skipped}

@app.get("/api/history")
def history(limit: int = 100) -> Dict[str, Any]: return {"runs": STATE.history(max(1, min(int(limit), 500)))}

@app.get("/api/audit")
def audit(limit: int = 200) -> Dict[str, Any]: return {"events": STATE.audit_history(max(1, min(int(limit), 1000)))}

app.mount("/assets", StaticFiles(directory=STATIC), name="assets")
@app.get("/")
def ui() -> FileResponse: return FileResponse(STATIC / "index.html")
