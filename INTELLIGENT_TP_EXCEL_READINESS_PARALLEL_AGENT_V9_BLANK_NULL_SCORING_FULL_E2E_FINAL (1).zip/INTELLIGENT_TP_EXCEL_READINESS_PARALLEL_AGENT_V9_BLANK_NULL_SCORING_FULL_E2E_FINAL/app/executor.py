from __future__ import annotations

import os
import re
import threading
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Mapping
from urllib.parse import urlparse

import requests

from .catalog import read_path, schema_locked
from .governance import fingerprint, identity_fingerprint, redact, validate_field_rules
from .runtime_config import (
    bulk_live_enabled,
    credential_profile,
    host_allowed,
    live_enabled,
    oauth_settings,
    parallel_workers,
    request_timeout,
    request_verify,
    resolve_contract_url,
    retry_attempts_default,
    runtime_summary,
)
from .workbook import blank
from .uhal_reference import validation_payload as uhal_validation_payload

_ENV_PATTERN = re.compile(r"\$\{([A-Z0-9_]+)\}")
_PAYLOAD_PATTERN = re.compile(r"\$\{payload:([^}]+)\}")
_CIRCUITS: Dict[str, Dict[str, Any]] = {}
_CIRCUIT_LOCK = threading.RLock()
_TOKEN_CACHE: Dict[str, tuple[str, float]] = {}
_TOKEN_LOCK = threading.RLock()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def four_eyes_required() -> bool:
    return str(os.getenv("FOUR_EYES_REQUIRED", "false")).strip().lower() in {"1", "true", "yes", "y"}


def remote_preflight_enabled() -> bool:
    return str(os.getenv("ENABLE_REMOTE_PREFLIGHT_CHECKS", "false")).strip().lower() in {"1", "true", "yes", "y"}


def resolve_env(value: Any, missing: set[str]) -> Any:
    if isinstance(value, dict):
        return {k: resolve_env(v, missing) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_env(v, missing) for v in value]
    if not isinstance(value, str):
        return value

    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        env = os.getenv(key)
        if env is None or env == "":
            missing.add(key)
            return match.group(0)
        return env

    return _ENV_PATTERN.sub(repl, value)


def resolve_payload_templates(value: Any, payload: Mapping[str, Any]) -> Any:
    if isinstance(value, dict):
        return {k: resolve_payload_templates(v, payload) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_payload_templates(v, payload) for v in value]
    if not isinstance(value, str):
        return value
    return _PAYLOAD_PATTERN.sub(
        lambda m: str(read_path(payload, m.group(1)) if read_path(payload, m.group(1)) is not None else ""), value
    )


def _extract_token(body: Any) -> str:
    if isinstance(body, dict):
        for key in ("access_token", "accessToken", "token", "bearerToken", "id_token"):
            value = body.get(key)
            if value:
                return str(value)
        nested = body.get("data")
        if isinstance(nested, dict):
            for key in ("access_token", "accessToken", "token", "bearerToken"):
                value = nested.get(key)
                if value:
                    return str(value)
    return ""


def _oauth_token_for_contract(contract: Mapping[str, Any]) -> str:
    profile = credential_profile(contract)
    settings = oauth_settings(profile)
    if not (settings["token_url"] and settings["client_id"] and settings["client_secret"]):
        raise ValueError(f"{profile} OAuth is not configured in the V122 environment")
    cache_key = f"{profile}:{settings['token_url']}:{settings['client_id']}:{settings['scope']}"
    with _TOKEN_LOCK:
        cached = _TOKEN_CACHE.get(cache_key)
        if cached and cached[1] > time.time() + 60:
            return cached[0]

    data: Dict[str, str] = {"grant_type": "client_credentials"}
    if settings["scope"]:
        data["scope"] = settings["scope"]
    headers = {
        "Accept": "application/json",
        "User-Agent": os.getenv("HIP_TOKEN_USER_AGENT", "PostmanRuntime/7.49.0"),
    }
    response = requests.post(
        settings["token_url"],
        data=data,
        auth=(settings["client_id"], settings["client_secret"]),
        headers=headers,
        timeout=request_timeout(),
        verify=request_verify(),
    )
    if response.status_code in {400, 401, 403}:
        response = requests.post(
            settings["token_url"],
            data={**data, "client_id": settings["client_id"], "client_secret": settings["client_secret"]},
            headers=headers,
            timeout=request_timeout(),
            verify=request_verify(),
        )
    response.raise_for_status()
    try:
        body: Any = response.json()
    except Exception:
        body = response.text.strip()
    token = _extract_token(body) if isinstance(body, dict) else str(body or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token:
        raise ValueError(f"{profile} OAuth response did not include an access token")
    expires = 1800
    if isinstance(body, dict):
        try:
            expires = int(body.get("expires_in") or 1800)
        except Exception:
            expires = 1800
    with _TOKEN_LOCK:
        _TOKEN_CACHE[cache_key] = (token, time.time() + max(120, expires))
    return token


def _target_bearer_value(contract: Mapping[str, Any]) -> str:
    # Compatibility direct token first, then exact V122 per-API OAuth profiles.
    authorization = str(os.getenv("HIP_AUTHORIZATION") or "").strip()
    if authorization:
        return authorization if authorization.lower().startswith("bearer ") else f"Bearer {authorization}"
    token = str(os.getenv("TARGET_API_BEARER_TOKEN") or os.getenv("HIP_BEARER_TOKEN") or "").strip()
    if token:
        return token if token.lower().startswith("bearer ") else f"Bearer {token}"
    return f"Bearer {_oauth_token_for_contract(contract)}"


def target_auth_diagnostics(contract: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    if contract is not None:
        profile = credential_profile(contract)
        settings = oauth_settings(profile)
        ready = bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or (settings["token_url"] and settings["client_id"] and settings["client_secret"]))
        return {"ready": ready, "profile": profile, "mode": "V122 profile OAuth" if ready else "not configured", "tokenUrlConfigured": bool(settings["token_url"])}
    rows = {}
    for profile in ("HIP", "ACCOUNT", "PARTNER", "SYSTEM"):
        s = oauth_settings(profile)
        rows[profile] = {
            "ready": bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or (s["token_url"] and s["client_id"] and s["client_secret"])),
            "tokenUrlConfigured": bool(s["token_url"]),
            "clientIdConfigured": bool(s["client_id"]),
        }
    return {"ready": all(v["ready"] for v in rows.values()), "mode": "V122 credential profiles", "profiles": rows}


def _resolve_execution_headers(
    raw_headers: Mapping[str, Any],
    missing: set[str],
    *,
    contract: Mapping[str, Any],
    payload: Mapping[str, Any],
    stage_account: str = "",
) -> Dict[str, str]:
    headers: Dict[str, str] = {}
    for key, raw in dict(raw_headers or {}).items():
        raw_text = str(raw).strip()
        if raw_text in {"${HIP_AUTHORIZATION}", "${TARGET_API_TOKEN}"}:
            try:
                headers[str(key)] = _target_bearer_value(contract)
            except Exception:
                missing.add(f"{credential_profile(contract)}_OAUTH")
            continue
        if raw_text in {"${HIP_ACCOUNT_NAME}", "${STAGE_ACCOUNT}"}:
            account_name = str(os.getenv("HIP_ACCOUNT_NAME") or stage_account or "").strip()
            if account_name:
                headers[str(key)] = account_name
            else:
                missing.add("HIP_ACCOUNT_NAME_OR_EXCEL_ACCOUNT")
            continue
        expanded = resolve_payload_templates(raw, payload)
        headers[str(key)] = str(resolve_env(expanded, missing))
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers.setdefault("x-requester-id", requester)
    return headers


def test_contract_oauth(contract: Mapping[str, Any]) -> Dict[str, Any]:
    """Actively test the exact V122 OAuth profile without exposing the token."""
    profile = credential_profile(contract)
    started = time.perf_counter()
    try:
        bearer = _target_bearer_value(contract)
        direct = bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or os.getenv("HIP_BEARER_TOKEN"))
        return {
            "ok": True,
            "state": "UP",
            "profile": profile,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "tokenReceived": bool(bearer),
            "message": f"{profile} authentication material is available ({'direct bearer' if direct else 'V122 client-credentials OAuth'})",
        }
    except Exception as exc:
        return {
            "ok": False,
            "state": "DOWN",
            "profile": profile,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "tokenReceived": False,
            "message": f"{type(exc).__name__}: {exc}",
        }


def probe_contract_endpoint(contract: Mapping[str, Any], *, authenticated: bool = True) -> Dict[str, Any]:
    """Non-mutating endpoint probe. OPTIONS is used; 4xx/405 still proves gateway reachability."""
    url = resolve_contract_url(contract)
    started = time.perf_counter()
    if not url:
        return {"ok": False, "state": "DOWN", "url": "", "message": "TP API URL is empty", "elapsedMs": 0}
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "message": "TP API host is not allowlisted", "elapsedMs": 0}
    headers = {"Accept": "application/json"}
    if authenticated:
        try:
            headers["Authorization"] = _target_bearer_value(contract)
        except Exception as exc:
            return {"ok": False, "state": "AUTH_FAILED", "url": url, "message": f"OAuth failed before API probe: {type(exc).__name__}: {exc}", "elapsedMs": int((time.perf_counter()-started)*1000)}
    try:
        response = requests.options(url, headers=headers, timeout=request_timeout(), verify=request_verify(), allow_redirects=True)
        status = int(response.status_code)
        if 200 <= status < 400:
            state = "UP"; ok = True; message = f"TP API/gateway responded HTTP {status} to safe OPTIONS probe"
        elif status in {401, 403}:
            state = "AUTH_FAILED"; ok = False; message = f"TP API/gateway responded HTTP {status}; network is reachable but authentication/authorization was not accepted"
        elif status in {400, 404, 405, 409, 415, 422}:
            state = "REACHABLE"; ok = True; message = f"TP API/gateway is reachable (HTTP {status}; OPTIONS may not be supported)"
        elif status == 429:
            state = "DEGRADED"; ok = False; message = "TP API/gateway returned HTTP 429 rate limit"
        elif status >= 500:
            # Create orchestration routes in V122 can return 500 to OPTIONS even when
            # authenticated POST traffic is healthy. Treat this probe as inconclusive,
            # never as proof that the TP API is down. Deep health uses the non-mutating
            # U-HAUL validation route for the actual service verdict.
            state = "INCONCLUSIVE"; ok = True; message = f"Create route returned HTTP {status} to OPTIONS; this method probe is inconclusive, not an API-down verdict"
        else:
            state = "DEGRADED"; ok = False; message = f"TP API/gateway returned HTTP {status}"
        return {"ok": ok, "state": state, "url": url, "statusCode": status, "elapsedMs": int((time.perf_counter()-started)*1000), "message": message}
    except Exception as exc:
        return {"ok": False, "state": "DOWN", "url": url, "elapsedMs": int((time.perf_counter()-started)*1000), "message": f"{type(exc).__name__}: {exc}"}


def probe_uhal_tp_validation(contract: Mapping[str, Any], role: str) -> Dict[str, Any]:
    """Run the V122 U-HAUL TP *validation* call as a non-mutating service smoke test.

    This tests the same HIP OAuth profile, host, TLS settings and TP interface payload
    family used by LIVE execution, without sending the orchestration/create request.
    Business validation responses (400/409/422) prove that the TP service is reachable;
    401/403 are auth failures and 5xx are genuine service/gateway failures.
    """
    started = time.perf_counter()
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    url = base + "/api/transport-profiles/validate-unique-interface-detail"
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "role": role, "message": "TP validation host is not allowlisted", "elapsedMs": 0}
    try:
        bearer = _target_bearer_value(contract)
    except Exception as exc:
        return {"ok": False, "state": "AUTH_FAILED", "url": url, "role": role, "message": f"OAuth failed before U-HAUL TP validation: {type(exc).__name__}: {exc}", "elapsedMs": int((time.perf_counter()-started)*1000)}
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    payload = uhal_validation_payload(role)
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=request_timeout(), verify=request_verify())
        status = int(response.status_code)
        if 200 <= status < 300:
            state, ok = "UP", True
            message = f"U-HAUL {role} TP validation responded HTTP {status}"
        elif status in {400, 404, 409, 415, 422}:
            # The validator ran and returned a business/request verdict. This is
            # sufficient to prove service + route reachability; surface the status
            # separately so the operator can inspect the validation semantics.
            state, ok = "REACHABLE", True
            message = f"U-HAUL {role} TP validation route is reachable (HTTP {status} business/request verdict)"
        elif status in {401, 403}:
            state, ok = "AUTH_FAILED", False
            message = f"U-HAUL {role} TP validation rejected authentication/authorization (HTTP {status})"
        elif status == 429:
            state, ok = "DEGRADED", False
            message = "U-HAUL TP validation returned HTTP 429 rate limit"
        else:
            state, ok = ("DOWN" if status >= 500 else "DEGRADED"), False
            message = f"U-HAUL {role} TP validation returned HTTP {status}"
        preview = ""
        try:
            body = response.json()
            preview = str(redact(body))[:600]
        except Exception:
            preview = str(response.text or "")[:600]
        return {
            "ok": ok, "state": state, "url": url, "role": role,
            "statusCode": status, "elapsedMs": int((time.perf_counter()-started)*1000),
            "message": message, "responsePreview": preview,
            "reference": "V122 developer-approved U-HAUL SFTP HAFT validation payload",
            "mutating": False,
        }
    except Exception as exc:
        return {"ok": False, "state": "DOWN", "url": url, "role": role, "elapsedMs": int((time.perf_counter()-started)*1000), "message": f"{type(exc).__name__}: {exc}", "mutating": False}

def _circuit_state(url: str) -> Dict[str, Any]:
    host = (urlparse(url).hostname or "unknown").lower()
    with _CIRCUIT_LOCK:
        row = _CIRCUITS.setdefault(host, {"failures": 0, "openedAt": 0.0})
        threshold = int(os.getenv("CIRCUIT_BREAKER_FAILURES", "5"))
        cooldown = int(os.getenv("CIRCUIT_BREAKER_COOLDOWN_SECONDS", "60"))
        open_now = row["failures"] >= threshold and (time.time() - row["openedAt"]) < cooldown
        if row["failures"] >= threshold and not open_now:
            row["failures"] = 0
            row["openedAt"] = 0.0
        return {"host": host, "open": open_now, **row}


def _record_circuit(url: str, success: bool) -> None:
    host = (urlparse(url).hostname or "unknown").lower()
    with _CIRCUIT_LOCK:
        row = _CIRCUITS.setdefault(host, {"failures": 0, "openedAt": 0.0})
        if success:
            row["failures"] = 0
            row["openedAt"] = 0.0
        else:
            row["failures"] += 1
            if row["failures"] >= int(os.getenv("CIRCUIT_BREAKER_FAILURES", "5")):
                row["openedAt"] = time.time()


def _run_remote_checks(payload: Mapping[str, Any], contract: Mapping[str, Any], stage_account: str = "") -> Dict[str, Any]:
    checks = list(contract.get("preflight_checks") or [])
    if not checks:
        return {"enabled": remote_preflight_enabled(), "configured": 0, "results": [], "passed": True}
    if not remote_preflight_enabled():
        return {"enabled": False, "configured": len(checks), "results": [], "passed": True, "note": "ENABLE_REMOTE_PREFLIGHT_CHECKS=false"}
    timeout = int(os.getenv("REMOTE_PREFLIGHT_TIMEOUT_SECONDS", "30"))
    results = []
    for check in checks:
        missing: set[str] = set()
        method = str(check.get("method") or "GET").upper()
        if method not in {"GET", "HEAD"}:
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Only GET/HEAD preflight checks are permitted"})
            continue
        url = str(resolve_env(resolve_payload_templates(check.get("url") or "", payload), missing))
        if not host_allowed(url):
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Preflight check host is not allowlisted"})
            continue
        headers = _resolve_execution_headers(
            resolve_payload_templates(check.get("headers") or contract.get("headers") or {}, payload),
            missing,
            contract=contract,
            payload=payload,
            stage_account=stage_account,
        )
        params = resolve_payload_templates(check.get("params") or {}, payload)
        if missing:
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Missing env: " + ", ".join(sorted(missing))})
            continue
        try:
            resp = requests.request(method, url, headers={"Accept": "application/json", **headers}, params=params, timeout=timeout, verify=request_verify())
            expected = set(int(x) for x in (check.get("success_statuses") or check.get("successStatuses") or [200]))
            passed = resp.status_code in expected
            results.append({"name": check.get("name", "check"), "passed": passed, "statusCode": resp.status_code, "required": bool(check.get("required", True))})
        except Exception as exc:
            results.append({"name": check.get("name", "check"), "passed": False, "required": bool(check.get("required", True)), "error": f"{type(exc).__name__}: {exc}"})
    passed = all(r.get("passed") or not r.get("required", True) for r in results)
    return {"enabled": True, "configured": len(checks), "results": results, "passed": passed}


def preflight(stage: Mapping[str, Any], contract: Mapping[str, Any], duplicate_run: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    payload = stage.get("payload")
    base = contract.get("canonical_request")
    if not isinstance(payload, dict) or not isinstance(base, dict):
        errors.append("Staged request is not a JSON object")
    elif not schema_locked(base, payload):
        errors.append("Schema lock failed: API attributes/nesting/cardinality changed")
    missing_required = [p for p in (contract.get("required_paths") or []) if blank(read_path(payload, p))]
    if missing_required:
        errors.append("Missing required values: " + ", ".join(missing_required))
    field_findings = validate_field_rules(payload or {}, contract)
    if field_findings:
        errors.extend([f["message"] for f in field_findings])
    if str(contract.get("lifecycle_status") or "APPROVED") != "APPROVED":
        errors.append(f"Contract lifecycle is {contract.get('lifecycle_status')}; APPROVED is required")
    if stage.get("contractSha256") and stage.get("contractSha256") != contract.get("contract_sha256"):
        errors.append("Contract snapshot hash changed since staging")
    if not contract.get("url"):
        errors.append("API URL is empty")
    if not contract.get("method"):
        errors.append("HTTP method is empty")
    if not contract.get("allow_live", True):
        warnings.append("This contract is marked allow_live=false")
    if stage.get("approvalStatus") == "REJECTED":
        errors.append("Stage was rejected by an approver")
    if four_eyes_required() and stage.get("approvalStatus") != "APPROVED":
        errors.append("Four-eyes approval is required before LIVE execution")

    resolved_url = resolve_contract_url(contract)
    missing_env: set[str] = set()
    _resolve_execution_headers(
        contract.get("headers") or {},
        missing_env,
        contract=contract,
        payload=payload or {},
        stage_account=str(stage.get("account") or ""),
    )
    if missing_env:
        warnings.append("Execution environment variables not configured: " + ", ".join(sorted(missing_env)))
    if resolved_url and not host_allowed(resolved_url):
        warnings.append("Remote host is not allowlisted; LIVE remains blocked")
    if not live_enabled():
        warnings.append("HIP_LIVE_API_EXECUTION is false; LIVE remains blocked")

    duplicate_policy = str(contract.get("duplicate_policy") or "warn")
    duplicate = None
    if duplicate_run:
        duplicate = {"runId": duplicate_run.get("runId"), "executedAt": duplicate_run.get("executedAt"), "statusCode": duplicate_run.get("statusCode")}
        msg = f"A prior successful execution exists for the same object identity: {duplicate.get('runId')}"
        if duplicate_policy == "block":
            errors.append(msg)
        elif duplicate_policy == "warn":
            warnings.append(msg)

    remote = _run_remote_checks(payload or {}, contract, str(stage.get("account") or ""))
    if remote.get("configured") and not remote.get("enabled"):
        warnings.append("Remote read-only preflight checks are configured but disabled")
    if remote.get("enabled") and not remote.get("passed"):
        errors.append("One or more required remote preflight checks failed")
    circuit = _circuit_state(resolved_url) if resolved_url else {"open": False}
    if circuit.get("open"):
        errors.append(f"Circuit breaker is open for host {circuit.get('host')}")

    passed = not errors
    return {
        "passed": passed,
        "checkedAt": _now(),
        "errors": errors,
        "warnings": warnings,
        "missingRequiredPaths": missing_required,
        "fieldRuleFindings": field_findings,
        "payloadSha256": fingerprint(payload),
        "identityFingerprint": identity_fingerprint(contract, payload or {}),
        "contractSha256": contract.get("contract_sha256"),
        "schemaLocked": isinstance(payload, dict) and isinstance(base, dict) and schema_locked(base, payload),
        "liveEnabled": live_enabled(),
        "bulkLiveEnabled": bulk_live_enabled(),
        "hostAllowed": bool(resolved_url and host_allowed(resolved_url)),
        "resolvedUrl": resolved_url,
        "contractAllowsLive": bool(contract.get("allow_live", True)),
        "contractApproved": contract.get("lifecycle_status") == "APPROVED",
        "approvalStatus": stage.get("approvalStatus", "PENDING"),
        "fourEyesRequired": four_eyes_required(),
        "duplicate": duplicate,
        "duplicatePolicy": duplicate_policy,
        "remoteChecks": remote,
        "circuitBreaker": circuit,
        "targetAuth": target_auth_diagnostics(contract),
        "credentialProfile": credential_profile(contract),
        "runtime": runtime_summary(),
    }


def _can_retry(method: str, contract: Mapping[str, Any]) -> bool:
    if method in {"GET", "HEAD", "PUT", "DELETE"}:
        return True
    return bool(contract.get("idempotency_header"))


def execute(stage: Mapping[str, Any], contract: Mapping[str, Any], confirmation: str, actor: str = "Human User") -> Dict[str, Any]:
    pf = stage.get("preflight") or {}
    if str(confirmation or "").strip() != "LIVE":
        raise ValueError("Type LIVE exactly to confirm execution")
    if not pf.get("passed"):
        raise ValueError("Agent preflight has not passed")
    if pf.get("payloadSha256") != fingerprint(stage.get("payload")):
        raise ValueError("Staged payload changed after preflight; run preflight again")
    if pf.get("contractSha256") != contract.get("contract_sha256"):
        raise ValueError("API contract changed after preflight; stage/preflight again")
    if four_eyes_required() and stage.get("approvalStatus") != "APPROVED":
        raise ValueError("Four-eyes approval has not been completed")
    if not live_enabled():
        raise ValueError("LIVE execution is disabled. Set HIP_LIVE_API_EXECUTION=true in the V122-style .env")
    if not contract.get("allow_live", True):
        raise ValueError("This API contract has allow_live=false")
    if contract.get("lifecycle_status") != "APPROVED":
        raise ValueError("Only APPROVED API contracts may execute LIVE")

    url = resolve_contract_url(contract)
    payload = deepcopy(stage.get("payload") or {})
    missing: set[str] = set()
    headers = _resolve_execution_headers(
        deepcopy(contract.get("headers") or {}),
        missing,
        contract=contract,
        payload=payload,
        stage_account=str(stage.get("account") or ""),
    )
    if missing:
        raise ValueError("Missing execution environment variables: " + ", ".join(sorted(missing)))
    if not host_allowed(url):
        raise ValueError("LIVE target host is not allowlisted")
    circuit = _circuit_state(url)
    if circuit.get("open"):
        raise ValueError(f"Circuit breaker is open for host {circuit.get('host')}")

    method = str(contract.get("method") or "POST").upper()
    request_kind = str(contract.get("request_kind") or "payload")
    request_headers = {"Accept": "application/json", **headers}
    if request_kind == "payload":
        request_headers.setdefault("Content-Type", "application/json")
    idem_header = str(contract.get("idempotency_header") or "").strip()
    if idem_header:
        request_headers[idem_header] = pf.get("identityFingerprint") or fingerprint(payload)

    retry = contract.get("retry_policy") or {}
    configured_attempts = int(retry.get("max_attempts", retry_attempts_default()))
    max_attempts = configured_attempts if retry.get("enabled") and _can_retry(method, contract) else 1
    max_attempts = max(1, min(max_attempts, retry_attempts_default()))
    statuses = set(retry.get("statuses") or [429, 502, 503, 504])
    backoff = float(retry.get("backoff_seconds", 1.0))
    attempt_rows = []
    response = None
    start_all = time.perf_counter()
    for attempt in range(1, max_attempts + 1):
        start = time.perf_counter()
        try:
            response = requests.request(
                method,
                url,
                headers=request_headers,
                params=payload if request_kind == "params" else None,
                json=payload if request_kind == "payload" else None,
                timeout=request_timeout(),
                verify=request_verify(),
            )
            elapsed = int((time.perf_counter() - start) * 1000)
            attempt_rows.append({"attempt": attempt, "statusCode": response.status_code, "elapsedMs": elapsed})
            if response.status_code not in statuses or attempt >= max_attempts:
                break
        except requests.RequestException as exc:
            elapsed = int((time.perf_counter() - start) * 1000)
            attempt_rows.append({"attempt": attempt, "error": f"{type(exc).__name__}: {exc}", "elapsedMs": elapsed})
            if attempt >= max_attempts:
                raise
        time.sleep(backoff * (2 ** (attempt - 1)))
    if response is None:
        raise ValueError("No HTTP response received")
    elapsed_ms = int((time.perf_counter() - start_all) * 1000)
    try:
        response_body: Any = response.json()
    except Exception:
        response_body = response.text[:20000]
    success = response.status_code in set(contract.get("success_statuses") or [200, 201, 202, 204])
    _record_circuit(url, success)
    return {
        "runId": "",
        "stageId": stage.get("stageId"),
        "analysisId": stage.get("analysisId"),
        "rowId": stage.get("rowId"),
        "excelRow": stage.get("excelRow"),
        "sheetName": stage.get("sheetName"),
        "account": stage.get("account"),
        "apiKey": contract.get("key"),
        "apiName": contract.get("name"),
        "apiVersion": contract.get("version"),
        "contractSha256": contract.get("contract_sha256"),
        "credentialProfile": credential_profile(contract),
        "actor": actor,
        "executedAt": _now(),
        "method": method,
        "url": url,
        "statusCode": response.status_code,
        "success": success,
        "elapsedMs": elapsed_ms,
        "attempts": attempt_rows,
        "payloadSha256": fingerprint(payload),
        "identityFingerprint": pf.get("identityFingerprint") or identity_fingerprint(contract, payload),
        "request": {"kind": request_kind, "payload": redact(payload, contract.get("sensitive_paths") or [])},
        "response": redact(response_body),
    }


__all__ = [
    "bulk_live_enabled",
    "execute",
    "four_eyes_required",
    "live_enabled",
    "parallel_workers",
    "preflight",
    "remote_preflight_enabled",
    "runtime_summary",
    "target_auth_diagnostics",
]
