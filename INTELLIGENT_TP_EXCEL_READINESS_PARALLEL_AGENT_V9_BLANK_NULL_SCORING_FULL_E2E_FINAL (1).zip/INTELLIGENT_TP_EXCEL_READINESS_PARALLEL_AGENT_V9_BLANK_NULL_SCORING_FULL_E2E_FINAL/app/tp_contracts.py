from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Mapping
import os

from .catalog import normalize_contract

# V122 transport-interface contract parity. These are the same developer-approved
# interfaceDetails parameter names used by the supplied V122 code base. The outer
# Transport Profile request remains unchanged; only interfaceType/parameters vary.
INTERFACE_FAMILIES: Dict[str, Dict[str, Any]] = {
    "FILE": {
        "types": {"SFTP", "SFTP HAFT", "SFTP-HAFT", "FTP"},
        "source_keys": ["Interface Environment", "File Filtering Pattern", "Post Transfer Action", "Is Compression Required", "Use Existing Folder", "Existing Account", "Subscription Folder", "Existing Account Name"],
        "target_keys": ["Interface Environment", "File Filtering Pattern", "Post Transfer Action", "Is Compression Required", "Use Existing Folder", "Existing Account", "Subscription Folder", "Existing Account Name"],
        # Team correction (2026-09-09): Directory is NOT Subscription Folder.
        # Subscription Folder may legitimately be blank when the workbook does not
        # provide that TP attribute.  Existing Account Name remains the only FILE
        # parameter that must be supplied for an execution-ready existing-account TP.
        "source_required": ["Existing Account Name"], "target_required": ["Existing Account Name"],
        "source_defaults": {"Interface Environment":"UAT", "File Filtering Pattern":".*\\*.", "Post Transfer Action":"Move To Archive", "Is Compression Required":"FALSE", "Use Existing Folder":"No", "Existing Account":"Yes", "Subscription Folder":"", "Existing Account Name":""},
        "target_defaults": {"Interface Environment":"UAT", "File Filtering Pattern":".*\\*.", "Post Transfer Action":"Move To Archive", "Is Compression Required":"FALSE", "Use Existing Folder":"No", "Existing Account":"Yes", "Subscription Folder":"", "Existing Account Name":""},
        "allowed": {}, "sensitive": [],
        "reference": "V122 FILE/SFTP/FTP developer-approved interface schema",
    },
    "HTTPS": {
        "types": {"HTTPS", "REST", "HTTPS REST"},
        "source_keys": ["Protocol", "HIP URL", "Proxy URI", "Request Method", "Request Format", "Sender Authentication Type", "Are Input Files Compressed?", "Sender Grant Type"],
        "target_keys": ["Protocol", "Partner URL", "Request Method", "Request Format", "Receiver Authentication Type", "Gateway URL", "Are Input Files Compressed?", "Receiver Grant Type", "Receiver Token Endpoint", "Receiver Client Id", "Receiver Client Secret"],
        "source_required": [],
        "target_required": ["Partner URL", "Receiver Grant Type", "Receiver Token Endpoint", "Receiver Client Id", "Receiver Client Secret"],
        "source_defaults": {"Protocol":"REST", "HIP URL":"URL will be shared later after API Publish is successful.", "Proxy URI":"dce-common-sv1", "Request Method":"POST", "Request Format":"Request Body", "Sender Authentication Type":"OAuth2", "Are Input Files Compressed?":"False", "Sender Grant Type":"client_credentials"},
        "target_defaults": {"Protocol":"REST", "Partner URL":"", "Request Method":"POST", "Request Format":"Request Body", "Receiver Authentication Type":"OAuth2", "Gateway URL":"URL will be shared later after API Publish is successful.", "Are Input Files Compressed?":"False", "Receiver Grant Type":"", "Receiver Token Endpoint":"", "Receiver Client Id":"", "Receiver Client Secret":""},
        "allowed": {},
        "sensitive": ["Receiver Client Secret"],
        "reference": "V122 HTTPS receiver OAuth/URL/request developer-approved interface schema",
    },
    "HTTPS_AS2": {
        "types": {"HTTPS-AS2", "AS2", "HTTPS AS2"},
        "source_keys": ["Interface Environment", "Request Method", "Partner Identifier", "Dell Identifier", "Partner Verification Certificate", "Are SSL and Partner Verification Certificates identical?", "AS2 URL", "Are Input Files Compressed?", "Is EBCDIC enabled?", "SSL Certificate", "Compression Format"],
        "target_keys": ["Interface Environment", "Request Method", "Partner URL", "Partner Identifier", "Dell Identifier", "Signing Algorithm", "Encryption Algorithm", "Encryption Certificate", "SSL Certificate", "Enable AS2 Message Compression", "Asynchronous MDN Required", "Are Input Files Compressed?", "Is EBCDIC enabled?", "Compression Format"],
        "source_required": ["Interface Environment", "Request Method", "Partner Identifier", "Dell Identifier", "Partner Verification Certificate", "Are SSL and Partner Verification Certificates identical?", "AS2 URL", "Are Input Files Compressed?", "Is EBCDIC enabled?"],
        "target_required": ["Interface Environment", "Request Method", "Partner URL", "Partner Identifier", "Dell Identifier", "Signing Algorithm", "Encryption Algorithm", "Encryption Certificate", "SSL Certificate", "Enable AS2 Message Compression", "Asynchronous MDN Required", "Are Input Files Compressed?", "Is EBCDIC enabled?"],
        "source_defaults": {"Interface Environment":"UAT", "Request Method":"POST", "Partner Identifier":"", "Dell Identifier":"", "Partner Verification Certificate":"", "Are SSL and Partner Verification Certificates identical?":"No", "AS2 URL":"", "Are Input Files Compressed?":"False", "Is EBCDIC enabled?":"False", "SSL Certificate":"", "Compression Format":""},
        "target_defaults": {"Interface Environment":"UAT", "Request Method":"POST", "Partner URL":"", "Partner Identifier":"", "Dell Identifier":"", "Signing Algorithm":"", "Encryption Algorithm":"", "Encryption Certificate":"", "SSL Certificate":"", "Enable AS2 Message Compression":"False", "Asynchronous MDN Required":"False", "Are Input Files Compressed?":"False", "Is EBCDIC enabled?":"False", "Compression Format":""},
        "allowed": {
            "Signing Algorithm":["SHA1","SHA256","SHA512"], "Encryption Algorithm":["AES128","AES256"],
            "Are SSL and Partner Verification Certificates identical?":["Yes","No"], "Enable AS2 Message Compression":["True","False"],
            "Asynchronous MDN Required":["True","False"], "Are Input Files Compressed?":["True","False"], "Is EBCDIC enabled?":["True","False"],
            "Compression Format":["GZIP","ZIP","TAR"],
        },
        "sensitive": [],
        "reference": "V122 HTTPS-AS2 dev-approved Sender/Receiver interface schema; receiver SSL Certificate required",
    },
    "NAS": {
        "types": {"NAS"},
        "source_keys": ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS", "Cron Expression"],
        "target_keys": ["Protocol", "Server Name", "Server Path", "AD Group"],
        "source_required": ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS"],
        "target_required": ["Protocol", "Server Name", "Server Path", "AD Group"],
        "source_defaults": {}, "target_defaults": {},
        "allowed": {"Protocol":["NFS","SMB","Multi Protocol"], "Post File Transfer Action NAS":["Delete","Move To Archive","Rename"], "Polling Interval":["Every 5 Minutes","Every 15 Minutes","Every 30 Minutes","Every Hour","Every 12 Hours","Every Day","Cron Expression"]},
        "sensitive": [],
        "reference": "V122 additive NAS dev-team interface schema (2026-09-07)",
    },
    "RABBIT_MQ": {
        "types": {"RABBIT MQ", "RABBITMQ", "RABBIT-MQ"},
        "source_keys": ["Interface Environment", "Exchange Name"], "target_keys": ["Interface Environment", "Exchange Name"],
        "source_required": ["Interface Environment", "Exchange Name"], "target_required": ["Interface Environment", "Exchange Name"],
        "source_defaults": {}, "target_defaults": {},
        "allowed": {"Interface Environment":["DEV","TEST","PERF"]}, "sensitive": [],
        "reference": "V122 additive Rabbit MQ dev-team interface schema (2026-09-07)",
    },
}

ROLE_ALIASES = {
    "source": {
        "source system": "systemName",
        "system": "systemName",
        "source interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "source transport profile name": "transportProfileDetails.0.transportProfileName",
        "source tp name": "transportProfileDetails.0.transportProfileName",
        "dev transport profile name": "transportProfileDetails.0.transportProfileName",
        "transport profile name": "transportProfileDetails.0.transportProfileName",
        "tp name": "transportProfileDetails.0.transportProfileName",
        "document type name": "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
        "document type": "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
        "document type version": "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion",
    },
    "target": {
        "target system": "systemName",
        "system": "systemName",
        "target interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "target transport profile name": "transportProfileDetails.0.transportProfileName",
        "target tp name": "transportProfileDetails.0.transportProfileName",
        "dev transport profile name": "transportProfileDetails.0.transportProfileName",
        "transport profile name": "transportProfileDetails.0.transportProfileName",
        "tp name": "transportProfileDetails.0.transportProfileName",
        "document type name": "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
        "document type": "transportProfileDetails.0.documentTypeDetails.0.documentTypeName",
        "document type version": "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion",
    },
}

# These are explicit business labels accepted ONLY when they occur inside the
# authoritative Excel Interface Type cell. They are canonicalization aliases,
# not inference signals from other columns.
INTERFACE_VALUE_ALIASES = {
    "SFTP": ("FILE", "SFTP HAFT"),
    "SFTP HAFT": ("FILE", "SFTP HAFT"),
    "SFTP-HAFT": ("FILE", "SFTP HAFT"),
    "SFTP SERVER": ("FILE", "SFTP HAFT"),
    "SFTP HAFT SERVER": ("FILE", "SFTP HAFT"),
    "SFTP-HAFT SERVER": ("FILE", "SFTP HAFT"),
    "FTP": ("FILE", "FTP"),
    "FTP SERVER": ("FILE", "FTP"),
    "HTTPS": ("HTTPS", "HTTPS"),
    "HTTPS SERVER": ("HTTPS", "HTTPS"),
    "REST": ("HTTPS", "HTTPS"),
    "REST API": ("HTTPS", "HTTPS"),
    "HTTPS REST": ("HTTPS", "HTTPS"),
    "HTTPS REST API": ("HTTPS", "HTTPS"),
    "AS2": ("HTTPS_AS2", "HTTPS-AS2"),
    "AS2 SERVER": ("HTTPS_AS2", "HTTPS-AS2"),
    "HTTPS-AS2": ("HTTPS_AS2", "HTTPS-AS2"),
    "HTTPS AS2": ("HTTPS_AS2", "HTTPS-AS2"),
    "HTTPS AS2 SERVER": ("HTTPS_AS2", "HTTPS-AS2"),
    "NAS": ("NAS", "NAS"),
    "NAS SERVER": ("NAS", "NAS"),
    "RABBIT MQ": ("RABBIT_MQ", "Rabbit MQ"),
    "RABBITMQ": ("RABBIT_MQ", "Rabbit MQ"),
    "RABBIT-MQ": ("RABBIT_MQ", "Rabbit MQ"),
    "RABBIT MQ SERVER": ("RABBIT_MQ", "Rabbit MQ"),
}

PARAMETER_ALIASES = {
    # Provenance lock: Directory is a connectivity path, not the HIP TP
    # Subscription Folder; HIP Account is also not the FILE Existing Account Name.
    # Only explicit TP/account/subscription labels are allowed for these leaves.
    "subscription folder": "Subscription Folder", "tp subscription folder": "Subscription Folder", "transport profile subscription folder": "Subscription Folder",
    "existing account name": "Existing Account Name", "tp existing account name": "Existing Account Name", "transport profile account": "Existing Account Name", "tp account": "Existing Account Name",
    "interface environment": "Interface Environment", "exchange name": "Exchange Name", "server name": "Server Name", "server path": "Server Path",
    "ad group": "AD Group", "partner url": "Partner URL", "as2 url": "AS2 URL", "ssl certificate": "SSL Certificate",
    "encryption certificate": "Encryption Certificate", "signing algorithm": "Signing Algorithm", "encryption algorithm": "Encryption Algorithm",
    "partner identifier": "Partner Identifier", "dell identifier": "Dell Identifier", "request method": "Request Method",
}


def _interface_alias_key(interface_type: Any) -> str:
    raw = str(interface_type or "").strip().upper().replace("_", " ")
    raw = " ".join(raw.replace("/", " ").split())
    return raw


def interface_family(interface_type: Any) -> str:
    raw = _interface_alias_key(interface_type)
    alias = INTERFACE_VALUE_ALIASES.get(raw)
    return alias[0] if alias else ""


def canonical_interface_type(interface_type: Any, family: str) -> str:
    raw = _interface_alias_key(interface_type)
    alias = INTERFACE_VALUE_ALIASES.get(raw)
    if alias and alias[0] == family:
        return alias[1]
    return str(interface_type or "").strip()


def interface_alias_info(interface_type: Any) -> Dict[str, str]:
    raw = _interface_alias_key(interface_type)
    alias = INTERFACE_VALUE_ALIASES.get(raw)
    if not alias:
        return {"excelValue": str(interface_type or "").strip(), "recognized": "false", "family": "", "canonical": "", "aliasKey": raw}
    return {"excelValue": str(interface_type or "").strip(), "recognized": "true", "family": alias[0], "canonical": alias[1], "aliasKey": raw}


def dynamic_tp_contract(base: Mapping[str, Any], role: str, interface_type: Any) -> Dict[str, Any]:
    role = "target" if str(role).lower().startswith("target") else "source"
    family = interface_family(interface_type)
    if not family:
        raise ValueError(f"Unsupported TP interface type {interface_type!r}; no V122 dev-approved interface schema is registered")
    profile = INTERFACE_FAMILIES[family]
    raw = {k: deepcopy(v) for k, v in base.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}}
    payload = deepcopy(base["canonical_request"])
    payload["requestedBy"] = str(os.getenv("HIP_REQUESTED_BY") or payload.get("requestedBy") or "").strip()
    payload["hipEnvironment"] = str(os.getenv("HIP_ENVIRONMENT") or payload.get("hipEnvironment") or "DEV").strip()
    detail = payload["transportProfileDetails"][0]
    iface = detail["interfaceDetails"][0]
    iface["interfaceType"] = canonical_interface_type(interface_type, family)
    keys = profile[f"{role}_keys"]
    defaults = profile.get(f"{role}_defaults") or {}
    iface["parameters"] = {key: deepcopy(defaults.get(key, "")) for key in keys}
    detail["transportProfileUsage"] = "Sender" if role == "source" else "Receiver"
    payload["systemType"] = "Dell Application" if role == "source" else "Partner"
    raw["canonical_request"] = payload
    raw["name"] = "Source TP orchestration create ONLY" if role == "source" else "Target TP orchestration create ONLY"
    raw["description"] = f"V122 schema-locked {role.title()} Transport Profile Create · {family}"
    raw["notes"] = list(raw.get("notes") or []) + [profile["reference"], f"Dynamic interface family: {family}"]
    param_prefix = "transportProfileDetails.0.interfaceDetails.0.parameters."
    # Team correction (2026-09-09): document type is optional for TP creation in
    # this intake. If the workbook does not provide it, keep both name/version
    # empty; never fabricate a document type merely to satisfy readiness.
    doc_name_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
    doc_version_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"
    required = [
        p for p in (base.get("required_paths") or [])
        if ".parameters." not in p and p not in {doc_name_path, doc_version_path}
    ]
    required += [param_prefix + key for key in profile.get(f"{role}_required") or []]
    raw["required_paths"] = required
    # The executable TP identity is system + transportProfileName.  Document type
    # cannot be an identity component when it is legitimately optional/blank.
    raw["identity_paths"] = ["systemName", "transportProfileDetails.0.transportProfileName"]
    raw["sensitive_paths"] = list(base.get("sensitive_paths") or []) + [param_prefix + key for key in profile.get("sensitive") or []]
    rules = deepcopy(base.get("field_rules") or {})
    for key, allowed in (profile.get("allowed") or {}).items():
        if key in keys:
            rules[param_prefix + key] = {"type":"string", "enum": list(allowed)}
    raw["field_rules"] = rules
    aliases = deepcopy(base.get("header_aliases") or {})
    aliases.update(ROLE_ALIASES[role])
    for key in keys:
        # Exact API parameter labels are safe Excel aliases for the same leaf.
        aliases.setdefault(key, param_prefix + key)
    for header, key in PARAMETER_ALIASES.items():
        if key in keys:
            aliases[header] = param_prefix + key
    raw["header_aliases"] = aliases
    contract = normalize_contract(raw)
    contract["tp_role"] = role
    contract["interface_family"] = family
    contract["interface_reference"] = profile["reference"]
    return contract


def superset_tp_contract(base: Mapping[str, Any], role: str) -> Dict[str, Any]:
    """LLM-only schema containing the union of approved parameter leaves.

    Final row mapping is always revalidated against the exact dynamic contract.
    """
    role = "target" if str(role).lower().startswith("target") else "source"
    raw = {k: deepcopy(v) for k, v in base.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}}
    payload = deepcopy(base["canonical_request"])
    union = []
    for profile in INTERFACE_FAMILIES.values():
        for key in profile[f"{role}_keys"]:
            if key not in union: union.append(key)
    payload["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"] = {k:"" for k in union}
    raw["canonical_request"] = payload
    raw["required_paths"] = [p for p in (base.get("required_paths") or []) if ".parameters." not in p]
    raw["sensitive_paths"] = []
    raw["field_rules"] = {}
    aliases = deepcopy(base.get("header_aliases") or {}); aliases.update(ROLE_ALIASES[role])
    prefix = "transportProfileDetails.0.interfaceDetails.0.parameters."
    for header, key in PARAMETER_ALIASES.items():
        if key in union: aliases[header] = prefix + key
    raw["header_aliases"] = aliases
    return normalize_contract(raw)
