from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Mapping
from urllib.parse import urlparse


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def request_timeout() -> int:
    return max(1, int(os.getenv("HTTP_TIMEOUT_SECONDS", os.getenv("API_TIMEOUT_SECONDS", "90")) or 90))


def request_verify() -> Any:
    ca = str(os.getenv("HIP_CA_BUNDLE") or "").strip()
    if ca:
        return ca
    return env_bool("HIP_VERIFY_SSL", env_bool("API_VERIFY_TLS", True))


def retry_attempts_default() -> int:
    return max(1, min(int(os.getenv("HTTP_RETRY_ATTEMPTS", "3") or 3), 8))


def live_enabled() -> bool:
    # V122-native flag wins. ENABLE_LIVE_EXECUTION remains a compatibility alias.
    if os.getenv("HIP_LIVE_API_EXECUTION") is not None:
        return env_bool("HIP_LIVE_API_EXECUTION", False)
    return env_bool("ENABLE_LIVE_EXECUTION", False)


def bulk_live_enabled() -> bool:
    # Bulk LIVE is an additional explicit gate. When absent, mirror V122 strict-LIVE intent.
    if os.getenv("HIP_BULK_LIVE_EXECUTION") is not None:
        return env_bool("HIP_BULK_LIVE_EXECUTION", False)
    return env_bool("HIP_STRICT_LIVE_PIPELINE", False) and live_enabled()


def strict_live_pipeline() -> bool:
    return env_bool("HIP_STRICT_LIVE_PIPELINE", False)


def no_reuse_live() -> bool:
    return env_bool("HIP_NO_REUSE_LIVE", True)


def parallel_workers() -> int:
    configured = max(1, int(os.getenv("HIP_PARALLEL_CONFIG_WORKERS", "4") or 4))
    stable = max(1, int(os.getenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4") or 4))
    hard = max(1, int(os.getenv("HIP_BULK_MAX_WORKERS", str(configured)) or configured))
    return min(configured, stable, hard, 8)


def allowed_hosts() -> list[str]:
    raw = str(os.getenv("ALLOWED_API_HOSTS") or "").strip()
    if raw:
        return [x.strip().lower() for x in raw.split(",") if x.strip()]
    # V122's packaged DEV/SIT endpoints all sit under dell.com. Keep the standalone
    # runner blocked outside Dell unless the operator explicitly expands the list.
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service")
    host = (urlparse(base).hostname or "").lower()
    return [host] if host else []


def host_allowed(url: str) -> bool:
    host = (urlparse(str(url or "")).hostname or "").lower()
    return bool(host and any(host == item or host.endswith("." + item) for item in allowed_hosts()))


def credential_profile(contract: Mapping[str, Any]) -> str:
    key = str(contract.get("key") or "").lower()
    group = str(contract.get("group") or "").lower()
    url = str(contract.get("url") or "").lower()
    if key.startswith("account_") or group == "account" or "/authz/account" in url:
        return "ACCOUNT"
    if key.startswith("partner_") or group == "partner" or "/authz/partner" in url:
        return "PARTNER"
    if key.startswith("system_") or group == "system" or "/domain-systems/" in url:
        return "SYSTEM"
    return "HIP"


def oauth_settings(profile: str) -> Dict[str, str]:
    profile = str(profile or "HIP").upper()
    prefix = profile if profile in {"ACCOUNT", "PARTNER", "SYSTEM"} else "HIP"
    return {
        "profile": prefix,
        "token_url": str(os.getenv(f"{prefix}_TOKEN_URL") or os.getenv("HIP_TOKEN_URL") or "").strip(),
        "client_id": str(os.getenv(f"{prefix}_CLIENT_ID") or (os.getenv("HIP_CLIENT_ID") if prefix != "HIP" else "") or "").strip(),
        "client_secret": str(os.getenv(f"{prefix}_CLIENT_SECRET") or (os.getenv("HIP_CLIENT_SECRET") if prefix != "HIP" else "") or "").strip(),
        "scope": str(os.getenv(f"{prefix}_SCOPE") or (os.getenv("HIP_SCOPE") if prefix != "HIP" else "") or "").strip(),
    }


def resolve_contract_url(contract: Mapping[str, Any]) -> str:
    key = str(contract.get("key") or "").lower()
    original = str(contract.get("url") or "").strip()
    if not original:
        return original
    if key.startswith("account_") and os.getenv("HIP_ACCOUNT_API_URL"):
        return str(os.getenv("HIP_ACCOUNT_API_URL") or "").rstrip("/")
    if key.startswith("partner_") and os.getenv("HIP_PARTNER_API_URL"):
        return str(os.getenv("HIP_PARTNER_API_URL") or "").rstrip("/")
    if key.startswith("system_") and os.getenv("HIP_SYSTEM_API_URL"):
        return str(os.getenv("HIP_SYSTEM_API_URL") or "").rstrip("/")
    configured_base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "").rstrip("/")
    marker = "/hip-config-service/"
    if configured_base and marker in original:
        suffix = original.split(marker, 1)[1]
        return configured_base + "/" + suffix.lstrip("/")
    return original


def runtime_summary() -> Dict[str, Any]:
    return {
        "environment": os.getenv("HIP_ENVIRONMENT", "DEV"),
        "requestedBy": os.getenv("HIP_REQUESTED_BY", ""),
        "userId": os.getenv("HIP_USER_ID", ""),
        "verifySsl": bool(request_verify()) if not isinstance(request_verify(), str) else True,
        "caBundleConfigured": isinstance(request_verify(), str),
        "timeoutSeconds": request_timeout(),
        "retryAttempts": retry_attempts_default(),
        "liveEnabled": live_enabled(),
        "bulkLiveEnabled": bulk_live_enabled(),
        "strictLivePipeline": strict_live_pipeline(),
        "noReuseLive": no_reuse_live(),
        "parallelWorkers": parallel_workers(),
        "allowedHosts": allowed_hosts(),
    }
