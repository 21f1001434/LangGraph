from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List, Mapping, Sequence, Tuple
import os
import re

from .catalog import read_path, write_path, schema_locked
from .governance import fingerprint, identity_fingerprint, profile_records, validate_field_rules
from .mapper import evaluate_row, run_agents, validated_llm_hints
from .tp_contracts import dynamic_tp_contract, interface_family, interface_alias_info, superset_tp_contract
from .workbook import blank, detect_header, display, headers_and_records, norm_text, read_workbook

TP_KEYS = {"source_tp", "target_tp"}

TP_NAME_PATH = "transportProfileDetails.0.transportProfileName"
INTERFACE_TYPE_PATH = "transportProfileDetails.0.interfaceDetails.0.interfaceType"
DOC_NAME_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
DOC_VERSION_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"
SUBSCRIPTION_FOLDER_PATH = "transportProfileDetails.0.interfaceDetails.0.parameters.Subscription Folder"
EXISTING_ACCOUNT_PATH = "transportProfileDetails.0.interfaceDetails.0.parameters.Existing Account Name"

# These business-critical leaves are provenance locked. The LLM can explain and
# suggest optional mappings, but it cannot populate these from semantic guesses.
PROVENANCE_LOCKED_PATHS = {
    "systemName", TP_NAME_PATH, INTERFACE_TYPE_PATH, DOC_NAME_PATH, DOC_VERSION_PATH,
    SUBSCRIPTION_FOLDER_PATH, EXISTING_ACCOUNT_PATH,
}


def _value(values: Mapping[str, Any], *hints: str) -> Tuple[str, Any]:
    normalized = [(h, norm_text(h), v) for h, v in values.items()]
    for hint in hints:
        nh = norm_text(hint)
        for h, n, v in normalized:
            if n == nh and not blank(v): return h, v
    for hint in hints:
        nh = norm_text(hint)
        for h, n, v in normalized:
            if (nh in n or n in nh) and not blank(v): return h, v
    return "", ""


def _tp_sheet_score(headers: Sequence[str]) -> int:
    text = " | ".join(norm_text(h) for h in headers)
    signals = ["transport profile", "tp name", "interface type", "source system", "target system", "document type", "hip account", "lens tp"]
    return sum(2 if signal in text else 0 for signal in signals) + (2 if "transport" in text and "profile" in text else 0)


def _explicit_tp_name(values: Mapping[str, Any]) -> Tuple[str, Any]:
    # LENS TP Name is a customer/reference label in the supplied workbook. It is
    # never executable TP identity. LIVE TP identity must come from the explicit
    # DEV/Source/Target Transport Profile name columns.
    return _value(values, "DEV-Transport Profile Name", "DEV Transport Profile Name", "Source Transport Profile Name", "Target Transport Profile Name", "Transport Profile Name", "TP Name")


def _tp_name(values: Mapping[str, Any]) -> Tuple[str, Any]:
    header, value = _explicit_tp_name(values)
    if not blank(value):
        return header, value
    return _value(values, "LENS TP Name")


def _role_candidates(values: Mapping[str, Any], scope: str) -> Tuple[List[str], bool, str]:
    scope = str(scope or "BOTH").upper()
    if scope == "SOURCE": return ["source"], False, "User selected Source TP"
    if scope == "TARGET": return ["target"], False, "User selected Target TP"
    _, tp_name = _explicit_tp_name(values)
    name = str(tp_name or "").upper()
    tokens = set(re.findall(r"[A-Z0-9]+", name))
    if tokens & {"SRC", "SOURCE", "SENDER", "SNDR"}:
        return ["source"], False, "TP name contains source/sender role evidence"
    if tokens & {"TGT", "TARGET", "RECEIVER", "RCVR", "RECV"}:
        return ["target"], False, "TP name contains target/receiver role evidence"
    _, src_system = _value(values, "Source System")
    _, src_iface = _value(values, "Source Interface Type")
    _, tgt_system = _value(values, "Target System")
    _, tgt_iface = _value(values, "Target Interface Type")
    src = not blank(src_system) or not blank(src_iface)
    tgt = not blank(tgt_system) or not blank(tgt_iface)
    if src and not tgt: return ["source"], False, "Source-specific system/interface evidence"
    if tgt and not src: return ["target"], False, "Target-specific system/interface evidence"
    if src and tgt: return ["source", "target"], True, "Both Source and Target evidence are populated; both TP candidates require review unless role is encoded in TP name"
    return ["source", "target"], True, "No unambiguous Source/Target role evidence was found"


def _exact_value(values: Mapping[str, Any], *headers: str) -> Tuple[str, Any]:
    """Return only an explicitly named Excel column; never semantic/fuzzy inference."""
    lookup = {norm_text(h): h for h in values}
    for wanted in headers:
        actual = lookup.get(norm_text(wanted))
        if actual is not None and not blank(values.get(actual)):
            return actual, values.get(actual)
    return "", ""


def _interface_value(values: Mapping[str, Any], role: str) -> Tuple[str, Any]:
    """Interface selection is Excel-authoritative.

    The app may use the role-specific Interface Type column or an exact generic
    `Interface Type` column. It MUST NOT infer interface from TP names, server
    names, URLs, ports, authentication fields, delivery type, or the LLM.
    """
    # Team workbook correction: the generic ``Interface Type`` column is the
    # API-facing interface value. Legacy Source/Target Interface Type columns can
    # contain operational labels such as "Directory Monitor inbound" or
    # "MQ-Series Integration" and must not override it.
    generic = _exact_value(values, "Interface Type", "TP Interface Type", "API Interface Type")
    if generic[0]:
        return generic
    if role == "source":
        return _exact_value(values, "Source Interface Type")
    return _exact_value(values, "Target Interface Type")


def _field(values: Mapping[str, Any], *names: str) -> str:
    _, value = _value(values, *names)
    return display(value)


def _exact_field(values: Mapping[str, Any], *names: str) -> str:
    _, value = _exact_value(values, *names)
    return display(value)


def _hip_account(values: Mapping[str, Any]) -> str:
    # Avoid fuzzy generic "Account" matching (which produced values such as
    # Yes/Catalogues in V6). Only explicit HIP/account identity headers qualify.
    return _exact_field(values, "Hip Account names", "Hip Account name", "HIP Account", "Existing Account Name")


def _customer_label(values: Mapping[str, Any]) -> str:
    return _exact_field(values, "LENS TP Name", "Customer", "Customer Name", "Partner Name")


def _mapping_priority(header: str, path: str) -> int:
    h = norm_text(header)
    if "source interface type" in h or "target interface type" in h or h == "interface type": return 120
    if "source transport profile name" in h or "target transport profile name" in h: return 120
    if h == "transport profile name": return 118
    if "dev transport profile name" in h: return 112
    if "source system" in h or "target system" in h: return 108
    if "document type name" in h: return 106
    if "document type version" in h: return 104
    if "lens tp name" in h: return 70
    return 90


def _contextual_tp_parameter_path(header: str, contract: Mapping[str, Any]) -> str:
    """Resolve grouped Excel headers that identify TP-specific parameters.

    Example: the source workbook has several columns named ``Account`` under
    different parent groups.  Only ``Add >Transport Profile Details > Account``
    is the FILE ``Existing Account Name``.
    """
    n = norm_text(header)
    paths = set(str(p) for p in contract.get("paths") or [])
    if "transport profile" in n and "account" in n and EXISTING_ACCOUNT_PATH in paths:
        return EXISTING_ACCOUNT_PATH
    if "transport profile" in n and "subscription folder" in n and SUBSCRIPTION_FOLDER_PATH in paths:
        return SUBSCRIPTION_FOLDER_PATH
    return ""


def _parameter_excel_value(values: Mapping[str, Any], path: str) -> Tuple[str, Any]:
    """Return only approved exact/contextual Excel evidence for sensitive FILE leaves."""
    if path == SUBSCRIPTION_FOLDER_PATH:
        header, value = _exact_value(values, "Subscription Folder", "TP Subscription Folder", "Transport Profile Subscription Folder")
        if header:
            return header, value
        for h, v in values.items():
            n = norm_text(h)
            if "transport profile" in n and "subscription folder" in n and not blank(v):
                return h, v
        return "", ""
    if path == EXISTING_ACCOUNT_PATH:
        header, value = _exact_value(values, "Existing Account Name", "TP Existing Account Name", "Transport Profile Account", "TP Account")
        if header:
            return header, value
        for h, v in values.items():
            n = norm_text(h)
            if "transport profile" in n and "account" in n and not blank(v):
                return h, v
        return "", ""
    return "", ""


def _strict_tp_column_map(headers: Sequence[str], values: Mapping[str, Any], contract: Mapping[str, Any], llm_hints: Mapping[Tuple[str, str], Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """TP-only mapper: approved exact aliases first, high-confidence LLM only as fallback.

    This intentionally avoids the generic fuzzy mapper because TP readiness must not
    become optimistic from unrelated workbook columns. Unknown fields remain evidence.
    """
    paths = set(str(p) for p in contract.get("paths") or [])
    alias_lookup = {norm_text(k): v for k, v in (contract.get("header_aliases") or {}).items()}
    candidates: List[Tuple[int, str, str, Dict[str, Any]]] = []
    for header in headers:
        if blank(values.get(header)):
            continue
        target = alias_lookup.get(norm_text(header))
        if not target:
            target = _contextual_tp_parameter_path(header, contract)
        targets = [target] if isinstance(target, str) else target if isinstance(target, list) else []
        for path in targets:
            path = str(path)
            if path in paths:
                candidates.append((_mapping_priority(header, path), header, path, {
                    "path": path, "confidence": 0.99, "method": "Approved TP Excel alias",
                    "reason": "Excel header exactly matches an approved TP field alias.",
                }))
                break
    candidates.sort(key=lambda x: x[0], reverse=True)
    out: Dict[str, Dict[str, Any]] = {}
    used: set[str] = set()
    for _, header, path, meta in candidates:
        if path in used:
            continue
        out[header] = meta; used.add(path)

    # LLM is advisory and only fills a still-unmapped approved leaf at very high confidence.
    for header in headers:
        if header in out or blank(values.get(header)):
            continue
        hint = llm_hints.get((str(contract.get("key") or ""), header))
        if not hint or float(hint.get("confidence") or 0) < 0.93:
            continue
        path = str(hint.get("path") or "")
        if path not in paths or path in used:
            continue
        # Core TP identity/provenance fields are never delegated to the LLM.
        # This prevents Directory→Subscription Folder, HIP Account→Existing
        # Account Name, LENS name→TP name, and similar optimistic mappings.
        if path in PROVENANCE_LOCKED_PATHS:
            continue
        out[header] = {
            "path": path, "confidence": round(float(hint.get("confidence") or 0), 3),
            "method": "Dell AIA high-confidence hint",
            "reason": str(hint.get("reason") or "High-confidence semantic match to an approved TP path")[:400],
        }
        used.add(path)
    return out


def _suggested_excel_columns(contract: Mapping[str, Any], path: str) -> List[str]:
    suggestions=[]
    for header, target in (contract.get("header_aliases") or {}).items():
        targets=[target] if isinstance(target,str) else target if isinstance(target,list) else []
        if path in [str(x) for x in targets]:
            suggestions.append(str(header))
    # Keep the report concise and stable.
    return suggestions[:6]


def _postprocess_v122_payload(row: Dict[str, Any], values: Mapping[str, Any]) -> None:
    """Normalize mapped values to the exact V122 TP request semantics.

    - split Document Type NAME(1.0) into documentTypeName + documentTypeVersion;
    - preserve an explicit Document Type Version column when supplied;
    - populate the fixed V122 customer/haftAccount tag values from workbook evidence.
    """
    payload = row.get("proposedRequest") or {}
    if not isinstance(payload, dict):
        return
    doc_name_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
    doc_ver_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"
    doc_header, doc_raw = _exact_value(values, "Document Type Name", "Document Type")
    ver_header, ver_raw = _exact_value(values, "Document Type Version", "Doc Type Version")
    parsed_name = ""
    parsed_ver = ""
    if not blank(doc_raw):
        text = display(doc_raw).strip()
        match = re.match(r"^(.*?)\s*\(\s*([0-9]+(?:\.[0-9]+)*)\s*\)\s*$", text)
        if match:
            parsed_name = match.group(1).strip()
            parsed_ver = match.group(2).strip()
        else:
            parsed_name = text
    if parsed_name:
        write_path(payload, doc_name_path, parsed_name)
        existing = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == doc_name_path), None)
        if existing:
            existing["mappedValue"] = parsed_name
            if parsed_ver:
                existing["method"] = "Approved TP Excel alias + V122 document name/version parser"
                existing["reason"] = "Document Type cell contained NAME(version); V122 sends name and version in separate fields."
    explicit_ver = display(ver_raw).strip() if not blank(ver_raw) else ""
    final_ver = explicit_ver or parsed_ver
    if final_ver:
        write_path(payload, doc_ver_path, final_ver)
        if not any(str(m.get("targetPath")) == doc_ver_path for m in row.get("mappings") or []):
            row.setdefault("mappings", []).append({
                "sourceColumn": ver_header or doc_header,
                "sourceValue": explicit_ver or display(doc_raw),
                "targetPath": doc_ver_path,
                "mappedValue": final_ver,
                "confidence": 1.0,
                "method": "Explicit document version" if explicit_ver else "Parsed V122 document version",
                "reason": "V122 Transport Profile orchestration requires documentTypeVersion as a separate field.",
            })
    # Hard provenance correction for FILE account/folder leaves.  Directory is
    # never Subscription Folder, and HIP Account is never Existing Account Name.
    for path in (SUBSCRIPTION_FOLDER_PATH, EXISTING_ACCOUNT_PATH):
        if read_path(payload, path) is None:
            continue
        header, raw_value = _parameter_excel_value(values, path)
        final_value = display(raw_value) if header and not blank(raw_value) else ""
        write_path(payload, path, final_value)
        # Remove any earlier mapping to this protected leaf and rebuild it only
        # from approved exact/contextual Excel evidence.
        row["mappings"] = [m for m in (row.get("mappings") or []) if str(m.get("targetPath")) != path]
        if header:
            row.setdefault("mappings", []).append({
                "sourceColumn": header,
                "sourceValue": raw_value,
                "targetPath": path,
                "mappedValue": final_value,
                "confidence": 1.0,
                "method": "Exact TP Excel provenance",
                "reason": "Mapped only from the explicit Transport Profile parameter field; semantic inference is disabled for this API leaf.",
            })

    # V122 reference always emits the two tags even when tag-change=false.
    detail = ((payload.get("transportProfileDetails") or [{}])[0]) if isinstance(payload, dict) else {}
    if isinstance(detail, dict):
        customer = _customer_label(values)
        params = (((detail.get("interfaceDetails") or [{}])[0]).get("parameters") or {}) if detail.get("interfaceDetails") else {}
        account = display(params.get("Existing Account Name")) if isinstance(params, dict) else ""
        tags = detail.get("tags")
        if isinstance(tags, list) and len(tags) >= 2:
            tags[0]["key"] = "customer"; tags[0]["value"] = customer
            tags[1]["key"] = "haftAccount"; tags[1]["value"] = account
    row["proposedRequest"] = payload
    row["mappedPaths"] = sorted({str(m.get("targetPath")) for m in row.get("mappings") or [] if m.get("targetPath")})
    row["mappedCount"] = len(row["mappedPaths"])


def _reassess_after_postprocess(row: Dict[str, Any], contract: Mapping[str, Any]) -> None:
    """Recompute execution readiness after deterministic V122 value normalization.

    evaluate_row runs before the NAME(version) parser. V7 must therefore recompute
    required fields, identity, field rules, and status after the final payload has
    been normalized; otherwise a valid U-HAUL row can remain NEEDS_INPUT from a
    stale pre-normalization decision.
    """
    proposed = row.get("proposedRequest") or {}
    required = [str(p) for p in (contract.get("required_paths") or [])]
    identity = [str(p) for p in (contract.get("identity_paths") or [])]
    mapped_paths = [str(p) for p in (row.get("mappedPaths") or [])]
    missing = [p for p in required if blank(read_path(proposed, p))]
    structure_ok = schema_locked(contract.get("canonical_request") or {}, proposed)
    findings = validate_field_rules(proposed, contract)
    low = [m for m in (row.get("mappings") or []) if float(m.get("confidence") or 0) < 0.64]
    identity_from_excel = (not identity) or any(p in mapped_paths for p in identity)
    lifecycle = str(contract.get("lifecycle_status") or "APPROVED")

    warnings = [str(w) for w in (row.get("warnings") or [])]
    # Drop stale messages that can be made false by deterministic post-processing.
    warnings = [w for w in warnings if not w.startswith("API contract lifecycle is") and "field-rule" not in w.lower()]
    if not structure_ok:
        status = "DO_NOT_TRIGGER"
        if "Schema-lock violation detected" not in warnings:
            warnings.append("Schema-lock violation detected")
    elif lifecycle == "DEPRECATED":
        status = "DO_NOT_TRIGGER"
        if "API contract is DEPRECATED and cannot be recommended for new execution" not in warnings:
            warnings.append("API contract is DEPRECATED and cannot be recommended for new execution")
    elif not row.get("mappings"):
        status = "DO_NOT_TRIGGER"
        if "No workbook values could be mapped safely into this API" not in warnings:
            warnings.append("No workbook values could be mapped safely into this API")
    elif missing:
        status = "NEEDS_INPUT"
    elif lifecycle != "APPROVED":
        status = "NEEDS_INPUT"
        warnings.append(f"API contract lifecycle is {lifecycle}; APPROVED is required for a final trigger recommendation")
    elif findings:
        status = "NEEDS_INPUT"
        warnings.extend([str(f.get("message")) for f in findings[:8] if f.get("message")])
    elif not identity_from_excel:
        status = "NEEDS_INPUT"
        if "Object identity is inherited from the catalog template; map or confirm an identity value from this Excel row" not in warnings:
            warnings.append("Object identity is inherited from the catalog template; map or confirm an identity value from this Excel row")
    elif low:
        status = "NEEDS_INPUT"
        if "At least one mapping has low confidence and requires review" not in warnings:
            warnings.append("At least one mapping has low confidence and requires review")
    else:
        status = "GOOD_TO_TRIGGER"

    row["requiredPaths"] = required
    row["missingRequiredPaths"] = missing
    row["identityPaths"] = identity
    row["identityMappedFromExcel"] = identity_from_excel
    row["identityFingerprint"] = identity_fingerprint(contract, proposed)
    row["fieldRuleFindings"] = findings
    row["structureLocked"] = structure_ok
    row["status"] = status
    row["goodToTrigger"] = status == "GOOD_TO_TRIGGER"
    row["warnings"] = list(dict.fromkeys(warnings))


def _field_matrix(row: Mapping[str, Any], contract: Mapping[str, Any]) -> List[Dict[str, Any]]:
    proposed=row.get("proposedRequest") or {}
    base=contract.get("canonical_request") or {}
    mappings={str(m.get("targetPath")):m for m in row.get("mappings") or []}
    required=set(str(p) for p in contract.get("required_paths") or [])
    out=[]
    for path in contract.get("paths") or []:
        path=str(path); value=read_path(proposed,path); base_value=read_path(base,path); m=mappings.get(path)
        req=path in required
        if m:
            canonicalized = path.endswith(".interfaceType") and display(m.get("sourceValue")) != display(m.get("mappedValue"))
            source_type="EXCEL_CANONICALIZED" if canonicalized else "EXCEL"
            source_column=m.get("sourceColumn") or ""; source_value=m.get("sourceValue") or ""
            confidence=m.get("confidence"); method=m.get("method") or ""
        elif path == "requestedBy" and str(os.getenv("HIP_REQUESTED_BY") or "").strip():
            source_type="RUNTIME_ENV"; source_column="HIP_REQUESTED_BY"; source_value=os.getenv("HIP_REQUESTED_BY",""); confidence=1.0; method="V122 runtime"
        elif path == "hipEnvironment":
            source_type="RUNTIME_ENV"; source_column="HIP_ENVIRONMENT"; source_value=os.getenv("HIP_ENVIRONMENT", "DEV"); confidence=1.0; method="V122 runtime"
        elif path.endswith(".transportProfileUsage") or path == "systemType":
            source_type="ROLE_DERIVED"; source_column="TP role"; source_value=row.get("tpRole") or ""; confidence=1.0; method="Approved TP role contract"
        elif ".interfaceDetails.0.parameters." in path and not blank(value):
            source_type="INTERFACE_DEFAULT"; source_column="Approved interface contract"; source_value=display(value); confidence=1.0; method="V122 interface default"
        elif not blank(value):
            source_type="CONTRACT_FIXED"; source_column="Approved TP contract"; source_value=display(value); confidence=1.0; method="V122 canonical contract"
        elif req:
            source_type="MISSING_REQUIRED"; source_column=""; source_value=""; confidence=None; method="Required value missing"
        else:
            source_type="OPTIONAL_EMPTY"; source_column=""; source_value=""; confidence=None; method="Optional value not supplied"
        out.append({
            "path":path, "field":path.split(".")[-1], "required":req, "value":value, "baseValue":base_value,
            "sourceType":source_type, "sourceColumn":source_column, "sourceValue":source_value,
            "confidence":confidence, "method":method, "suggestedExcelColumns":_suggested_excel_columns(contract,path),
            "state":"MISSING" if req and blank(value) else ("OPTIONAL" if not req and blank(value) else "OK"),
        })
    return out


def _payload_completeness(row: Mapping[str, Any]) -> Dict[str, Any]:
    """Score actual payload value completeness.

    Blank/null/NaN-like values receive zero credit. Required leaves are weighted
    3x so a missing execution-critical value hurts the score more than a missing
    optional value. This score is deliberately independent of the trigger
    decision: GOOD_TO_TRIGGER means mandatory execution gates passed, not that
    every optional payload leaf was populated.
    """
    matrix = list(row.get("fieldMatrix") or [])
    total_weight = 0.0
    populated_weight = 0.0
    populated = 0
    blank_required = 0
    blank_optional = 0
    blank_fields: List[Dict[str, Any]] = []
    for item in matrix:
        required = bool(item.get("required"))
        weight = 3.0 if required else 1.0
        total_weight += weight
        value = item.get("value")
        if blank(value):
            if required:
                blank_required += 1
            else:
                blank_optional += 1
            blank_fields.append({
                "path": str(item.get("path") or ""),
                "field": str(item.get("field") or ""),
                "required": required,
                "sourceType": str(item.get("sourceType") or ""),
            })
        else:
            populated += 1
            populated_weight += weight
    score = int(round((populated_weight / total_weight) * 100)) if total_weight else 0
    return {
        "score": max(0, min(100, score)),
        "canonicalFieldCount": len(matrix),
        "populatedFieldCount": populated,
        "blankFieldCount": blank_required + blank_optional,
        "blankRequiredFieldCount": blank_required,
        "blankOptionalFieldCount": blank_optional,
        "blankFields": blank_fields,
        "weighting": "required=3x, optional=1x; blank/null/NaN/empty values=0 credit",
    }


def _refresh_readiness_diagnostics(row: Dict[str, Any]) -> None:
    missing=list(row.get("missingRequiredPaths") or [])
    contract=row.get("contractSnapshot") or {}
    friendly_missing=[]
    for path in missing:
        friendly_missing.append({"path":path,"field":str(path).split(".")[-1],"suggestedExcelColumns":_suggested_excel_columns(contract,str(path))})
    row["missingRequiredDetails"]=friendly_missing
    checks=[]
    def add(name:str, ok:bool, detail:str, blocking:bool=True, status_if_fail:str="FAIL"):
        checks.append({"name":name,"status":"PASS" if ok else status_if_fail,"detail":detail,"blocking":bool(blocking and not ok)})
    add("Interface provided in Excel", bool(row.get("interfaceProvidedByExcel")), f"{row.get('interfaceSourceColumn') or 'No Interface Type column'} = {row.get('interfaceRawValue') or 'blank'}")
    add("Interface recognized", bool(row.get("interfaceFamily") not in {"", "MISSING", "UNSUPPORTED"}), f"Excel {row.get('interfaceRawValue') or '—'} → API {row.get('interfaceType') or '—'}")
    add("TP role resolved", not bool(row.get("roleAmbiguous")), str(row.get("roleReason") or ""), blocking=True, status_if_fail="REVIEW")
    required_labels={
        "systemName":"System",
        TP_NAME_PATH:"transportProfileName",
        INTERFACE_TYPE_PATH:"Interface Type",
    }
    for path,label in required_labels.items():
        if path in (row.get("requiredPaths") or []):
            value=read_path(row.get("proposedRequest") or {},path)
            add(f"{label} mapped", not blank(value), f"{value if not blank(value) else 'Missing'}")
    doc_value = read_path(row.get("proposedRequest") or {}, DOC_NAME_PATH)
    checks.append({
        "name":"Document Type",
        "status":"PASS" if not blank(doc_value) else "MISSING_OPTIONAL",
        "detail":f"{doc_value}" if not blank(doc_value) else "Not supplied; kept empty by team rule. It does not block execution, but it lowers completeness score.",
        "blocking":False,
    })
    contract_paths = set(str(p) for p in contract.get("paths") or [])
    if SUBSCRIPTION_FOLDER_PATH in contract_paths:
        sub_map = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == SUBSCRIPTION_FOLDER_PATH), None)
        sub_ok = not sub_map or norm_text(sub_map.get("sourceColumn")) != "directory"
        add("Subscription Folder provenance", sub_ok, "Directory is not used as Subscription Folder" if sub_ok else "Invalid provenance: Directory was mapped to Subscription Folder")
    if EXISTING_ACCOUNT_PATH in contract_paths:
        acct_map = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == EXISTING_ACCOUNT_PATH), None)
        acct_source = norm_text(acct_map.get("sourceColumn")) if acct_map else ""
        acct_ok = not acct_map or "hip account" not in acct_source
        add("Existing Account Name provenance", acct_ok, "HIP Account is not used as Existing Account Name" if acct_ok else "Invalid provenance: HIP Account was mapped to Existing Account Name")
    param_missing=[p for p in missing if ".parameters." in str(p)]
    add("Required interface parameters", not param_missing, "All required interface parameters present" if not param_missing else "Missing: "+", ".join(str(p).split(".")[-1] for p in param_missing))
    add("Schema lock", bool(row.get("structureLocked")), "Payload attributes/nesting match the approved TP contract")
    findings=row.get("fieldRuleFindings") or []
    add("Field rules", not findings, "No field-rule violations" if not findings else "; ".join(str(x.get("message")) for x in findings[:3]))
    dup=bool(row.get("duplicateWorkbookIdentity"))
    add("Duplicate TP identity", not dup, "Unique in workbook" if not dup else "Also found at "+", ".join(row.get("duplicateWorkbookRows") or []), blocking=True, status_if_fail="REVIEW")
    low=[m for m in row.get("mappings") or [] if float(m.get("confidence") or 0)<0.90]
    add("Mapping confidence", not low, "All mappings are approved aliases / high confidence" if not low else f"{len(low)} mapping(s) require review", blocking=True, status_if_fail="REVIEW")

    completeness = _payload_completeness(row)
    blank_count = int(completeness["blankFieldCount"])
    checks.append({
        "name":"Payload value completeness",
        "status":"PASS" if blank_count == 0 else "INCOMPLETE",
        "detail":(
            f"{completeness['populatedFieldCount']}/{completeness['canonicalFieldCount']} canonical payload fields have values; "
            f"{completeness['blankRequiredFieldCount']} required and {completeness['blankOptionalFieldCount']} optional field(s) are blank/null. "
            "Blank/null values receive zero score credit."
        ),
        "blocking":False,
    })

    row["readinessChecks"]=checks
    blocking=[c for c in checks if c.get("blocking")]
    passed=len([c for c in checks if c.get("status")=="PASS"])
    row["failedCheckCount"]=len(blocking)
    row["passedCheckCount"]=passed
    row.update({k:v for k,v in completeness.items() if k != "score"})

    # V9: score is no longer forced to 100 for GOOD_TO_TRIGGER. Missing values
    # always reduce score. Status remains governed by mandatory hard checks.
    score = int(completeness["score"])
    if row.get("roleAmbiguous"):
        score -= 8
    score -= min(10, len(low) * 3)
    score -= min(16, len(findings) * 4)
    if not row.get("structureLocked"):
        score -= 25
    if row.get("status")=="NEEDS_INPUT":
        score=min(89, score)
    elif row.get("status")=="DO_NOT_TRIGGER":
        score=min(49, score)
    row["score"] = max(0, min(100, int(round(score))))
    row["completenessScore"] = int(completeness["score"])
    row["scoreBasis"] = "Payload value completeness: required fields weighted 3x, optional fields 1x; blank/null/NaN/empty values receive zero credit. Execution status is a separate hard-gate decision."

    if row.get("status")=="GOOD_TO_TRIGGER":
        if blank_count:
            reason=f"All mandatory execution checks passed; {blank_count} optional/null payload field(s) are not populated, so completeness score is {row['score']}/100."
        else:
            reason="All mandatory execution checks passed and all canonical payload values are populated."
    elif row.get("status")=="NEEDS_INPUT":
        reason="Input/review required: " + ("; ".join(c.get("detail") for c in blocking[:4]) if blocking else "review warnings")
    else:
        reason="Blocked: " + ("; ".join(c.get("detail") for c in blocking[:4]) if blocking else "; ".join(row.get("warnings") or [])[:500])
    row["decisionReason"]=reason

def _unmapped_details(row: Mapping[str, Any], values: Mapping[str, Any]) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    metadata_terms = ("application tracking", "lens tp", "hip account", "b2b", "biz input", "biz flow", "migration", "staging profile", "test profile", "action to take", "dell po", "data found")
    connectivity_terms = ("sftp server", "port", "directory", "authentication", "password", "private key", "contact", "sending account")
    for header in row.get("unmappedColumns") or []:
        value = display(values.get(header))
        n = norm_text(header)
        if any(x in n for x in metadata_terms):
            reason = "Reference/operational metadata; not an attribute in the approved TP Create payload."
            kind = "REFERENCE"
        elif any(x in n for x in connectivity_terms):
            reason = "Connectivity evidence is retained for review but is not injected into another TP field. In particular, Directory is never mapped to Subscription Folder."
            kind = "EVIDENCE_ONLY"
        else:
            reason = "No safe canonical TP payload path matched this Excel field; agent did not invent an attribute."
            kind = "UNMAPPED"
        rows.append({"column": str(header), "value": value, "classification": kind, "reason": reason})
    return rows


def _enrich(row: Dict[str, Any], values: Mapping[str, Any], *, sheet_name: str, role: str, role_ambiguous: bool, role_reason: str, interface_source: str, interface_raw: Any, contract: Mapping[str, Any]) -> Dict[str, Any]:
    row["sheetName"] = sheet_name
    row["tpRole"] = "SOURCE / SENDER" if role == "source" else "TARGET / RECEIVER"
    row["tpRoleKey"] = role
    row["roleReason"] = role_reason
    row["roleAmbiguous"] = role_ambiguous
    row["interfaceSourceColumn"] = interface_source
    row["interfaceRawValue"] = display(interface_raw)
    row["interfaceProvidedByExcel"] = bool(interface_source and not blank(interface_raw))
    row["interfaceInferenceUsed"] = False
    row["interfaceSelectionPolicy"] = "EXPLICIT_EXCEL_INTERFACE_TYPE_ONLY"
    row["interfaceFamily"] = contract.get("interface_family")
    row["interfaceReference"] = contract.get("interface_reference")
    row["interfaceAlias"] = interface_alias_info(interface_raw)
    row["interfaceCanonicalized"] = display(interface_raw) != display(((row.get("proposedRequest") or {}).get("transportProfileDetails") or [{}])[0].get("interfaceDetails", [{}])[0].get("interfaceType", "")) if row.get("proposedRequest") else False
    payload = row.get("proposedRequest") or {}
    detail = ((payload.get("transportProfileDetails") or [{}])[0]) if isinstance(payload, dict) else {}
    iface = ((detail.get("interfaceDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    doc = ((detail.get("documentTypeDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    row["tpName"] = display(detail.get("transportProfileName"))
    row["systemName"] = display(payload.get("systemName")) if isinstance(payload, dict) else ""
    row["interfaceType"] = display(iface.get("interfaceType"))
    row["documentTypeName"] = display(doc.get("documentTypeName"))
    row["hipAccountName"] = _hip_account(values)
    row["customerName"] = _customer_label(values)
    row["applicationTracking"] = _exact_field(values, "Application Tracking")
    row["lensTpName"] = _exact_field(values, "LENS TP Name")
    row["unmappedDetails"] = _unmapped_details(row, values)
    row["contractSnapshot"] = {k: deepcopy(v) for k, v in contract.items()}
    if role_ambiguous and row.get("status") == "GOOD_TO_TRIGGER":
        row["status"] = "NEEDS_INPUT"; row["goodToTrigger"] = False; row["score"] = max(0, int(row.get("score") or 0) - 12)
        row.setdefault("warnings", []).append("Source/Target TP role is ambiguous. Confirm the role before LIVE execution.")
    # The API requires transportProfileName, not a DEV-prefixed Excel label.
    # DEV-Transport Profile Name remains only one accepted exact Excel alias.
    row["readinessLabel"] = "GOOD TO GO" if row.get("status") == "GOOD_TO_TRIGGER" else ("NEEDS INPUT" if row.get("status") == "NEEDS_INPUT" else "NOT READY")
    blockers = list(row.get("missingRequiredPaths") or []) + [f.get("message") for f in row.get("fieldRuleFindings") or []]
    if role_ambiguous: blockers.append("Confirm Source/Target TP role")
    row["blockers"] = [str(x) for x in blockers if x]
    row["fieldMatrix"] = _field_matrix(row, contract)
    _refresh_readiness_diagnostics(row)
    return row


def _unsupported(record: Mapping[str, Any], values: Mapping[str, Any], sheet_name: str, role: str, role_ambiguous: bool, role_reason: str, iface_header: str, iface_value: Any, message: str, *, missing_interface: bool = False) -> Dict[str, Any]:
    tp_header, tp = _tp_name(values)
    account = _hip_account(values) or _exact_field(values, "Application Tracking") or _customer_label(values) or display(tp) or f"Row {record.get('excelRow')}"
    return {
        "excelRow": int(record.get("excelRow") or 0), "sheetName": sheet_name, "account": account, "recordLabel": f"{sheet_name}!{record.get('excelRow')}",
        "apiKey": "source_tp" if role == "source" else "target_tp", "apiName": "Source TP orchestration create ONLY" if role == "source" else "Target TP orchestration create ONLY",
        "group":"Transport Profile", "method":"POST", "url":"", "requestKind":"payload", "status":"NEEDS_INPUT" if missing_interface else "DO_NOT_TRIGGER", "goodToTrigger":False, "readinessLabel":"NEEDS INPUT" if missing_interface else "NOT READY", "score":15 if missing_interface else 0,
        "mappings":[], "mappedCount":0, "mappedPaths":[], "requiredPaths":[], "missingRequiredPaths":["Supported interface type"], "identityPaths":[], "identityMappedFromExcel":False, "identityFingerprint":"",
        "fieldRuleFindings":[], "warnings":[message], "unmappedColumns":[h for h,v in values.items() if not blank(v)], "unmappedDetails":[], "baseRequest":{}, "proposedRequest":{}, "structureLocked":True,
        "tpRole":"SOURCE / SENDER" if role == "source" else "TARGET / RECEIVER", "tpRoleKey":role, "roleAmbiguous":role_ambiguous, "roleReason":role_reason,
        "interfaceSourceColumn":iface_header, "interfaceRawValue":display(iface_value), "interfaceProvidedByExcel":bool(iface_header and not blank(iface_value)), "interfaceInferenceUsed":False, "interfaceSelectionPolicy":"EXPLICIT_EXCEL_INTERFACE_TYPE_ONLY", "interfaceFamily":"MISSING" if missing_interface else "UNSUPPORTED", "interfaceReference":"Interface is selected only from an explicit Excel Interface Type cell; no inference is permitted",
        "tpName":display(tp), "systemName":"", "interfaceType":display(iface_value), "documentTypeName":_exact_field(values,"Document Type Name"), "hipAccountName":_hip_account(values), "customerName":_customer_label(values),
        "applicationTracking":_exact_field(values,"Application Tracking"), "lensTpName":_exact_field(values,"LENS TP Name"), "blockers":[message], "contractSnapshot":{},
        "fieldMatrix": [], "missingRequiredDetails": [{"path":"transportProfileDetails.0.interfaceDetails.0.interfaceType","field":"interfaceType","suggestedExcelColumns":["Source Interface Type" if role=="source" else "Target Interface Type","Interface Type"]}],
        "readinessChecks": [
            {"name":"Interface provided in Excel","status":"PASS" if (iface_header and not blank(iface_value)) else "FAIL","detail":f"{iface_header or 'No Interface Type column'} = {display(iface_value) or 'blank'}","blocking":not bool(iface_header and not blank(iface_value))},
            {"name":"Interface recognized","status":"FAIL","detail":message,"blocking":True},
            {"name":"TP role resolved","status":"REVIEW" if role_ambiguous else "PASS","detail":role_reason,"blocking":bool(role_ambiguous)},
        ],
        "failedCheckCount": 1 + int(not bool(iface_header and not blank(iface_value))) + int(bool(role_ambiguous)),
        "passedCheckCount": int(bool(iface_header and not blank(iface_value))) + int(not role_ambiguous),
        "decisionReason": message,
    }


def _consolidate_duplicate_evidence(actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Merge exact repeated evidence; block only same-identity payload conflicts."""
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    passthrough: List[Dict[str, Any]] = []
    for row in actions:
        ident = str(row.get("identityFingerprint") or "")
        if not ident:
            passthrough.append(row); continue
        groups.setdefault((str(row.get("apiKey") or ""), ident), []).append(row)
    merged: List[Dict[str, Any]] = list(passthrough)
    for group in groups.values():
        if len(group) == 1:
            group[0]["duplicateWorkbookIdentity"] = False
            group[0]["duplicateWorkbookRows"] = []
            merged.append(group[0]); continue
        labels = [f"{x.get('sheetName')}!{x.get('excelRow')}" for x in group]
        payload_groups: Dict[str, List[Dict[str, Any]]] = {}
        for row in group:
            payload_groups.setdefault(fingerprint(row.get("proposedRequest") or {}), []).append(row)
        if len(payload_groups) == 1:
            canonical = group[0]
            canonical["duplicateWorkbookIdentity"] = False
            canonical["duplicateWorkbookRows"] = []
            canonical["evidenceRows"] = labels
            canonical["mergedDuplicateEvidenceCount"] = len(group) - 1
            canonical.setdefault("warnings", []).append(
                f"Merged {len(group)} identical workbook evidence rows for the same TP identity: " + ", ".join(labels)
            )
            merged.append(canonical)
        else:
            for row in group:
                row["duplicateWorkbookIdentity"] = True
                row["duplicateWorkbookRows"] = labels
                row["conflictingDuplicateIdentity"] = True
                row.setdefault("warnings", []).append("Conflicting payload values exist for the same TP identity at " + ", ".join(labels))
                if row.get("status") == "GOOD_TO_TRIGGER":
                    row["status"] = "NEEDS_INPUT"; row["goodToTrigger"] = False; row["readinessLabel"] = "NEEDS INPUT"
                row.setdefault("blockers", []).append("Conflicting duplicate TP identity in workbook")
                merged.append(row)
    return merged


def analyze_tp_workbook(*, filename: str, data: bytes, contracts: Sequence[Mapping[str, Any]], scope: str="BOTH", requested_sheet: str="", header_row: int=0, use_llm: bool=True, scan_all_sheets: bool=True) -> Dict[str, Any]:
    bases = {c["key"]: deepcopy(c) for c in contracts if c.get("key") in TP_KEYS}
    if "source_tp" not in bases or "target_tp" not in bases:
        raise ValueError("The API catalog must contain both source_tp and target_tp V122 Transport Profile Create contracts")
    workbook = read_workbook(filename, data)
    prepared = []
    for sheet in workbook.get("sheets") or []:
        if requested_sheet and str(sheet.get("name")) != requested_sheet: continue
        rows = sheet.get("rows") or []
        if not rows: continue
        idx = max(0, header_row-1) if header_row else detect_header(rows)
        headers, records = headers_and_records(rows, idx)
        score = _tp_sheet_score(headers)
        if requested_sheet or not scan_all_sheets or score >= 6:
            prepared.append((sheet, idx, headers, records, score))
            if not scan_all_sheets and not requested_sheet: break
    if requested_sheet and not prepared: raise ValueError(f"Worksheet {requested_sheet!r} was not found or has no data")
    if not prepared:
        raise ValueError("No Transport Profile worksheet was detected. Expected TP/interface/system/document/account columns")

    all_headers: List[str] = []
    samples: List[Mapping[str, Any]] = []
    for _,_,headers,records,_ in prepared:
        for h in headers:
            if h not in all_headers: all_headers.append(h)
        samples.extend([r["values"] for r in records[:3]])
    supersets = [superset_tp_contract(bases["source_tp"],"source"), superset_tp_contract(bases["target_tp"],"target")]
    llm = run_agents(all_headers, samples[:8], supersets, use_llm)

    actions: List[Dict[str, Any]] = []
    sheet_meta=[]
    for sheet, idx, headers, records, score in prepared:
        sheet_name=str(sheet.get("name") or "Sheet")
        sheet_meta.append({"name":sheet_name,"headerRow":idx+1,"columnCount":len(headers),"dataRowCount":len(records),"tpScore":score})
        for record in records:
            values=record.get("values") or {}
            roles, ambiguous, role_reason = _role_candidates(values, scope)
            for role in roles:
                iface_header, iface_value = _interface_value(values, role)
                if blank(iface_value):
                    actions.append(_unsupported(record, values, sheet_name, role, ambiguous, role_reason, iface_header, iface_value, "Explicit Excel Interface Type is missing. Provide Source Interface Type / Target Interface Type (or exact Interface Type). The agent will not infer it from any other Excel field.", missing_interface=True)); continue
                family=interface_family(iface_value)
                if not family:
                    actions.append(_unsupported(record, values, sheet_name, role, ambiguous, role_reason, iface_header, iface_value, f"Interface type {display(iface_value)!r} is not registered in the V122 dev-approved TP interface catalog.")); continue
                base=bases["source_tp" if role=="source" else "target_tp"]
                contract=dynamic_tp_contract(base, role, iface_value)
                hints=validated_llm_hints(llm, headers, {contract["key"]:contract})
                cmap=_strict_tp_column_map(headers, values, contract, hints)
                # Hard interface lock: interface contract selection and the interfaceType
                # payload leaf are sourced only from the explicit Excel interface cell.
                interface_path = "transportProfileDetails.0.interfaceDetails.0.interfaceType"
                cmap = {h: meta for h, meta in cmap.items() if str(meta.get("path")) != interface_path}
                cmap[iface_header] = {
                    "path": interface_path,
                    "confidence": 1.0,
                    "method": "Explicit Excel interface lock",
                    "reason": "Interface Type was explicitly provided in Excel; inference is disabled.",
                }
                row=evaluate_row(record, contract, cmap)
                _postprocess_v122_payload(row, values)
                _reassess_after_postprocess(row, contract)
                row=_enrich(row, values, sheet_name=sheet_name, role=role, role_ambiguous=ambiguous, role_reason=role_reason, interface_source=iface_header, interface_raw=iface_value, contract=contract)
                actions.append(row)
    actions = _consolidate_duplicate_evidence(actions)
    for action in actions:
        _refresh_readiness_diagnostics(action)

    # In BOTH mode an ambiguous record can generate two review candidates. Keep both visible,
    # but never allow them to be bulk-staged until a role has been confirmed (they are NEEDS_INPUT).
    good=sum(1 for r in actions if r.get("status")=="GOOD_TO_TRIGGER")
    needs=sum(1 for r in actions if r.get("status")=="NEEDS_INPUT")
    blocked=sum(1 for r in actions if r.get("status")=="DO_NOT_TRIGGER")
    unique_records={(r.get("sheetName"),r.get("excelRow")) for r in actions}
    accounts={r.get("hipAccountName") or r.get("account") for r in actions if (r.get("hipAccountName") or r.get("account"))}
    blocker_counts: Dict[str, int] = {}
    interface_counts: Dict[Tuple[str, str], int] = {}
    for r in actions:
        for check in r.get("readinessChecks") or []:
            if check.get("blocking"):
                key=str(check.get("name") or "Readiness blocker")
                blocker_counts[key]=blocker_counts.get(key,0)+1
        raw=display(r.get("interfaceRawValue")); canonical=display(r.get("interfaceType"))
        if raw:
            interface_counts[(raw,canonical)]=interface_counts.get((raw,canonical),0)+1
    diagnostics_summary={
        "mergedDuplicateEvidenceRows": sum(int(r.get("mergedDuplicateEvidenceCount") or 0) for r in actions),
        "topBlockers":[{"check":k,"count":v} for k,v in sorted(blocker_counts.items(), key=lambda x:(-x[1],x[0]))],
        "interfaceMappings":[{"excelValue":k[0],"apiValue":k[1],"count":v} for k,v in sorted(interface_counts.items(), key=lambda x:(-x[1],x[0][0]))],
    }
    return {
        "ok":True, "mode":"TRANSPORT_PROFILE_ONLY", "policy":"V122_TP_SCHEMA_LOCK_EXCEL_READINESS_HUMAN_STAGE_PARALLEL_LIVE",
        "file":{"name":filename,"format":workbook["format"],"size":len(data)},
        "sheet":{"name":prepared[0][0].get("name"),"headerRow":prepared[0][1]+1,"headers":prepared[0][2],"dataRowCount":len(prepared[0][3])},
        "sheets":sheet_meta, "selectionMode":"TP_ONLY", "tpScope":scope,
        "summary":{"records":len(unique_records),"accounts":len(accounts),"tpActions":len(actions),"GOOD_TO_TRIGGER":good,"NEEDS_INPUT":needs,"DO_NOT_TRIGGER":blocked,"GOOD_API_ACTIONS":good,"rows":len(actions)},
        "diagnosticsSummary": diagnostics_summary,
        "results":deepcopy(actions), "allApiResults":deepcopy(actions), "tpActions":actions,
        "dataProfile": profile_records(all_headers, [{"values":{h:v for h,v in (sample or {}).items()}} for sample in samples]) if samples else {"rowCount":0,"columnCount":len(all_headers),"columns":[]},
        "llm":llm,
        "governance":{"tpOnly":True,"schemaImmutable":True,"agentCanEditSchema":False,"humanStageRequired":True,"preflightRequired":True,"parallelLiveSupported":True,"maxParallelWorkers":4},
        "notes":[
            "Only Source/Target Transport Profile Create contracts are evaluated in this phase; other APIs are intentionally excluded.",
            "Interface Type is mandatory Excel input. Exact generic Interface Type is authoritative when present; legacy Source/Target Interface Type is only a fallback when the API Interface Type column is absent. The LLM is never allowed to infer it.",
            "Directory is never Subscription Folder, and HIP Account is never Existing Account Name. These protected leaves require exact TP-specific Excel provenance.",
            "documentTypeName/documentTypeVersion are optional for this intake and remain empty when the workbook has no document type evidence.",
            "Each TP action is then mapped against the exact V122 interface-specific schema (FILE, HTTPS, HTTPS-AS2, NAS or Rabbit MQ).",
            "Excel evidence not present in the canonical TP payload is reported but never injected as a new API attribute.",
            "Bulk execution stages only GOOD_TO_TRIGGER TP actions and executes preflight-passed selections in parallel using the V122 worker cap.",
        ],
    }
