from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Mapping

from .catalog import read_path, write_path
from .workbook import blank, display, norm_text

SECRET_KEY_RE = re.compile(r"(password|secret|token|authorization|api[-_ ]?key|private[-_ ]?key|certificate)", re.I)


def fingerprint(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def identity_fingerprint(contract: Mapping[str, Any], payload: Mapping[str, Any]) -> str:
    paths = list(contract.get("identity_paths") or [])
    values = {path: read_path(payload, path) for path in paths}
    if not paths:
        values = {"payload": payload}
    return fingerprint({"apiKey": contract.get("key"), "identity": values})


def validate_field_rules(payload: Mapping[str, Any], contract: Mapping[str, Any]) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []
    rules = contract.get("field_rules") or {}
    for path, rule in rules.items():
        if not isinstance(rule, Mapping):
            continue
        value = read_path(payload, str(path))
        if blank(value):
            if bool(rule.get("required")):
                findings.append({"path": path, "code": "required", "message": f"{path} is required"})
            continue
        expected = str(rule.get("type") or "").lower()
        if expected:
            ok = {
                "string": isinstance(value, str),
                "integer": isinstance(value, int) and not isinstance(value, bool),
                "number": isinstance(value, (int, float)) and not isinstance(value, bool),
                "boolean": isinstance(value, bool),
            }.get(expected, True)
            if not ok:
                findings.append({"path": path, "code": "type", "message": f"{path} must be {expected}"})
                continue
        text = display(value)
        if "min_length" in rule and len(text) < int(rule["min_length"]):
            findings.append({"path": path, "code": "min_length", "message": f"{path} must be at least {int(rule['min_length'])} characters"})
        if "max_length" in rule and len(text) > int(rule["max_length"]):
            findings.append({"path": path, "code": "max_length", "message": f"{path} exceeds max length {int(rule['max_length'])}"})
        enum = rule.get("enum")
        if isinstance(enum, list) and enum and value not in enum:
            findings.append({"path": path, "code": "enum", "message": f"{path} must be one of {enum}"})
        pattern = rule.get("pattern")
        if pattern:
            try:
                if not re.fullmatch(str(pattern), text):
                    findings.append({"path": path, "code": "pattern", "message": f"{path} does not match required pattern"})
            except re.error:
                findings.append({"path": path, "code": "invalid_rule", "message": f"{path} has an invalid catalog regex rule"})
        if "min" in rule:
            try:
                if float(value) < float(rule["min"]):
                    findings.append({"path": path, "code": "min", "message": f"{path} must be >= {rule['min']}"})
            except Exception:
                findings.append({"path": path, "code": "number", "message": f"{path} must be numeric"})
        if "max" in rule:
            try:
                if float(value) > float(rule["max"]):
                    findings.append({"path": path, "code": "max", "message": f"{path} must be <= {rule['max']}"})
            except Exception:
                findings.append({"path": path, "code": "number", "message": f"{path} must be numeric"})
    return findings


def redact(value: Any, sensitive_paths: Iterable[str] = ()) -> Any:
    safe = deepcopy(value)
    if isinstance(safe, dict):
        for path in sensitive_paths:
            try:
                if read_path(safe, path) is not None:
                    write_path(safe, path, "<redacted>")
            except Exception:
                pass
    def walk(node: Any) -> Any:
        if isinstance(node, dict):
            return {k: ("<redacted>" if SECRET_KEY_RE.search(str(k)) else walk(v)) for k, v in node.items()}
        if isinstance(node, list):
            return [walk(v) for v in node]
        return node
    return walk(safe)


def profile_records(headers: List[str], records: List[Mapping[str, Any]]) -> Dict[str, Any]:
    cols: List[Dict[str, Any]] = []
    for header in headers:
        values = [(r.get("values") or {}).get(header) for r in records]
        populated = [v for v in values if not blank(v)]
        unique = len({display(v) for v in populated})
        sample = [display(v)[:80] for v in populated[:3]]
        inferred = "empty"
        if populated:
            if all(isinstance(v, bool) for v in populated): inferred = "boolean"
            elif all(isinstance(v, int) and not isinstance(v, bool) for v in populated): inferred = "integer"
            elif all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in populated): inferred = "number"
            else: inferred = "text"
        cols.append({
            "header": header,
            "populated": len(populated),
            "blank": len(values) - len(populated),
            "blankPct": round((len(values) - len(populated)) * 100 / max(1, len(values)), 1),
            "unique": unique,
            "inferredType": inferred,
            "sample": sample,
            "sensitiveHint": bool(SECRET_KEY_RE.search(norm_text(header))),
        })
    return {"rowCount": len(records), "columnCount": len(headers), "columns": cols}
