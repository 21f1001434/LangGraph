from __future__ import annotations

import json
import os
import zipfile
from io import BytesIO

import pytest
from fastapi.testclient import TestClient

from app.catalog import load_catalog, schema_locked
from app.executor import execute, preflight
from app.main import app
from app.mapper import analyze_workbook


def mini_xlsx(interface="SFTP HAFT") -> bytes:
    out = BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>''')
        z.writestr("_rels/.rels", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>''')
        z.writestr("xl/workbook.xml", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="SFTP_UAT" sheetId="1" r:id="rId1"/></sheets></workbook>''')
        z.writestr("xl/_rels/workbook.xml.rels", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>''')
        z.writestr("xl/worksheets/sheet1.xml", f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>
<row r="1"><c r="A1" t="inlineStr"><is><t>Source System</t></is></c><c r="B1" t="inlineStr"><is><t>DEV-Transport Profile Name</t></is></c><c r="C1" t="inlineStr"><is><t>Source Interface Type</t></is></c><c r="D1" t="inlineStr"><is><t>Document Type Name</t></is></c><c r="E1" t="inlineStr"><is><t>Hip Account names</t></is></c><c r="F1" t="inlineStr"><is><t>SFTP Server</t></is></c><c r="G1" t="inlineStr"><is><t>Directory</t></is></c><c r="H1" t="inlineStr"><is><t>Document Type Version</t></is></c><c r="I1" t="inlineStr"><is><t>Existing Account Name</t></is></c><c r="J1" t="inlineStr"><is><t>Subscription Folder</t></is></c></row>
<row r="2"><c r="A2" t="inlineStr"><is><t>AIC - DCE</t></is></c><c r="B2" t="inlineStr"><is><t>SFTP_ACME_ASN_SRC_OB</t></is></c><c r="C2" t="inlineStr"><is><t>{interface}</t></is></c><c r="D2" t="inlineStr"><is><t>XML_ACME_ASN_10</t></is></c><c r="E2" t="inlineStr"><is><t>acme-hip-account</t></is></c><c r="F2" t="inlineStr"><is><t>sftp.acme.example</t></is></c><c r="G2" t="inlineStr"><is><t>/remote/wrong-for-subscription</t></is></c><c r="H2" t="inlineStr"><is><t>1.0</t></is></c><c r="I2" t="inlineStr"><is><t>haft-acme</t></is></c><c r="J2" t="inlineStr"><is><t>/SFTP_ACME_ASN_SRC_OB</t></is></c></row>
</sheetData></worksheet>''')
    return out.getvalue()


def source_tp_contract():
    return next(c for c in load_catalog() if c["key"] == "source_tp")


def test_health_and_ui_are_standalone():
    client = TestClient(app)
    health = client.get("/api/health").json()
    assert health["ok"] is True
    assert health["app"] == "Intelligent TP Excel Readiness & Parallel Execution Agent"
    assert client.get("/").status_code == 200


def test_transport_profile_mapping_is_schema_locked_and_ready():
    c = source_tp_contract()
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="source_tp", use_llm=False)
    row = result["results"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"
    assert row["apiKey"] == "source_tp"
    assert row["proposedRequest"]["systemName"] == "AIC - DCE"
    assert row["proposedRequest"]["transportProfileDetails"][0]["transportProfileName"] == "SFTP_ACME_ASN_SRC_OB"
    assert row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["interfaceType"] == "SFTP HAFT"
    assert row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]["documentTypeName"] == "XML_ACME_ASN_10"
    assert "SFTP Server" in row["unmappedColumns"]
    assert schema_locked(row["baseRequest"], row["proposedRequest"])


def test_auto_mode_recommends_a_transport_profile_api():
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=load_catalog(), selected_api="AUTO", use_llm=False)
    row = result["results"][0]
    assert row["apiKey"] in {"source_tp", "validate_source", "migrate_source_tp"}
    assert row["mappedCount"] >= 2
    assert row["apiAlternatives"]


def test_schema_change_is_rejected_by_lock():
    c = source_tp_contract()
    payload = json.loads(json.dumps(c["canonical_request"]))
    payload["agentInventedAttribute"] = "not allowed"
    assert schema_locked(c["canonical_request"], payload) is False


def test_preflight_passes_structure_with_v122_live_gate_off(monkeypatch):
    c = source_tp_contract()
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="source_tp", use_llm=False)
    row = result["results"][0]
    stage = {"stageId": "test", "payload": row["proposedRequest"], "preflight": None}
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "false")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    pf = preflight(stage, c)
    assert pf["passed"] is True
    assert pf["contractAllowsLive"] is True
    assert pf["liveEnabled"] is False


def test_live_execution_cannot_run_without_explicit_enable(monkeypatch):
    c = source_tp_contract()
    payload = json.loads(json.dumps(c["canonical_request"]))
    # Fill required paths with harmless local values to reach the execution gate.
    from app.catalog import write_path
    for p in c["required_paths"]:
        current = None
        if p.endswith("interfaceType"):
            current = "SFTP HAFT"
        elif p.endswith("documentTypeName"):
            current = "DOC"
        else:
            current = "VALUE"
        write_path(payload, p, current)
    stage = {"stageId": "test", "payload": payload}
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "false")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    stage["preflight"] = preflight(stage, c)
    with pytest.raises(ValueError, match="disabled"):
        execute(stage, c, "LIVE")


def test_api_endpoint_analyze_stage_preflight_without_live():
    client = TestClient(app)
    response = client.post(
        "/api/analyze",
        files={"workbook": ("team.xlsx", mini_xlsx(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
        data={"api_key": "source_tp", "use_llm": "false"},
    )
    assert response.status_code == 200
    analysis = response.json(); row = analysis["results"][0]
    staged = client.post("/api/stage", json={"analysisId": analysis["analysisId"], "rowId": row["rowId"], "payload": row["proposedRequest"], "reviewer": "Test Human"})
    assert staged.status_code == 200
    stage_id = staged.json()["stage"]["stageId"]
    pf = client.post(f"/api/stages/{stage_id}/preflight")
    assert pf.status_code == 200
    assert pf.json()["preflight"]["passed"] is True


def test_field_rule_violation_downgrades_readiness():
    c = source_tp_contract()
    c["field_rules"] = {"transportProfileDetails.0.transportProfileName": {"type": "string", "max_length": 8}}
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="source_tp", use_llm=False)
    row = result["results"][0]
    assert row["status"] == "NEEDS_INPUT"
    assert row["fieldRuleFindings"]
    assert "max length" in row["fieldRuleFindings"][0]["message"]


def test_duplicate_identity_inside_workbook_is_flagged_for_review():
    raw = mini_xlsx()
    # Add a duplicate of row 2 as row 3 by editing the tiny test xlsx XML.
    src = BytesIO(raw); out = BytesIO()
    with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for name in zin.namelist():
            body = zin.read(name)
            if name == "xl/worksheets/sheet1.xml":
                text = body.decode("utf-8")
                row2 = text.split('<row r="2">', 1)[1].split('</row>', 1)[0]
                row3 = row2.replace('r="A2"', 'r="A3"').replace('r="B2"', 'r="B3"').replace('r="C2"', 'r="C3"').replace('r="D2"', 'r="D3"').replace('r="E2"', 'r="E3"').replace('r="F2"', 'r="F3"')
                text = text.replace('</sheetData>', f'<row r="3">{row3}</row></sheetData>')
                body = text.encode("utf-8")
            zout.writestr(name, body)
    result = analyze_workbook(filename="team.xlsx", data=out.getvalue(), contracts=[source_tp_contract()], selected_api="source_tp", use_llm=False)
    assert len(result["results"]) == 2
    assert all(r["duplicateWorkbookIdentity"] for r in result["results"])
    assert all(r["status"] == "NEEDS_INPUT" for r in result["results"])


def test_draft_contract_is_not_good_to_trigger():
    c = source_tp_contract(); c["lifecycle_status"] = "DRAFT"
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="source_tp", use_llm=False)
    assert result["results"][0]["status"] == "NEEDS_INPUT"
    assert any("DRAFT" in x for x in result["results"][0]["warnings"])


def test_duplicate_policy_block_fails_preflight():
    c = source_tp_contract(); c["duplicate_policy"] = "block"
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="source_tp", use_llm=False)
    row = result["results"][0]
    stage = {"stageId": "dup", "payload": row["proposedRequest"], "approvalStatus": "APPROVED", "contractSha256": c.get("contract_sha256")}
    duplicate = {"runId": "run_prior", "executedAt": "2026-09-07T00:00:00Z", "statusCode": 201, "success": True}
    pf = preflight(stage, c, duplicate_run=duplicate)
    assert pf["passed"] is False
    assert any("prior successful execution" in e for e in pf["errors"])


def test_four_eyes_requires_different_approver(monkeypatch):
    from app.state import STATE
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "true")
    stage = STATE.stage({"reviewer": "Alice", "apiKey": "x", "payload": {}, "contractSnapshot": {}})
    with pytest.raises(ValueError, match="different approver"):
        STATE.approve_stage(stage["stageId"], "Alice", four_eyes=True)
    approved = STATE.approve_stage(stage["stageId"], "Bob", "looks good", four_eyes=True)
    assert approved["approvalStatus"] == "APPROVED"


def test_catalog_rejects_mutating_remote_preflight_check():
    from app.catalog import normalize_contract
    raw = {
        "key": "unsafe_check", "method": "POST", "url": "https://api.example.com", "canonical_request": {"name": ""},
        "preflight_checks": [{"name": "bad", "method": "POST", "url": "https://api.example.com/check"}],
    }
    with pytest.raises(ValueError, match="GET/HEAD"):
        normalize_contract(raw)


def test_execute_redacts_sensitive_payload_and_retries_only_with_idempotency(monkeypatch):
    from app.catalog import normalize_contract
    import app.executor as ex
    c = normalize_contract({
        "key": "safe_post", "name": "safe post", "method": "POST", "url": "https://safe.example.com/create", "request_kind": "payload",
        "canonical_request": {"name": "", "password": ""}, "required_paths": ["name"], "identity_paths": ["name"],
        "sensitive_paths": ["password"], "allow_live": True, "idempotency_header": "Idempotency-Key",
        "retry_policy": {"enabled": True, "max_attempts": 2, "backoff_seconds": 0, "statuses": [503]},
    })
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true"); monkeypatch.setenv("ALLOWED_API_HOSTS", "safe.example.com"); monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer test")
    class Resp:
        def __init__(self, code): self.status_code=code; self.text='ok'
        def json(self): return {"token": "secret-response", "result": "ok"}
    calls=[]
    def fake_request(*args, **kwargs):
        calls.append(kwargs); return Resp(503 if len(calls)==1 else 201)
    monkeypatch.setattr(ex.requests, "request", fake_request)
    payload={"name":"ACME","password":"super-secret"}
    stage={"stageId":"s", "payload":payload, "approvalStatus":"APPROVED", "contractSha256":c["contract_sha256"]}
    stage["preflight"] = preflight(stage, c)
    run=execute(stage,c,"LIVE")
    assert len(calls)==2
    assert run["success"] is True
    assert run["request"]["payload"]["password"] == "<redacted>"
    assert run["response"]["token"] == "<redacted>"
    assert "Idempotency-Key" in calls[0]["headers"]


def test_audit_chain_links_events():
    from app.state import STATE
    a = STATE.audit("TEST_A", actor="tester")
    b = STATE.audit("TEST_B", actor="tester")
    assert b["previousSha256"] == a["eventSha256"]
    assert b["eventSha256"] != a["eventSha256"]


def test_openapi_import_creates_draft_schema_locked_contracts():
    from app.importers import parse_api_definition
    spec = {
        "openapi": "3.0.0",
        "info": {"title": "Demo", "version": "2.1"},
        "servers": [{"url": "https://api.example.com"}],
        "paths": {
            "/customers": {
                "post": {
                    "operationId": "createCustomer",
                    "summary": "Create Customer",
                    "requestBody": {"content": {"application/json": {"schema": {
                        "type": "object", "required": ["name"], "properties": {"name": {"type": "string", "maxLength": 20}, "active": {"type": "boolean"}}
                    }}}},
                    "responses": {"201": {"description": "created"}}
                }
            }
        }
    }
    rows, kind = parse_api_definition(json.dumps(spec).encode(), "openapi.json")
    assert kind == "OpenAPI/Swagger"
    assert len(rows) == 1
    c = rows[0]
    assert c["lifecycle_status"] == "DRAFT"
    assert c["allow_live"] is False
    assert c["canonical_request"] == {"name": "", "active": False}
    assert "name" in c["required_paths"]
    assert c["field_rules"]["name"]["max_length"] == 20


def test_postman_import_masks_auth_and_stays_draft():
    from app.importers import parse_api_definition
    coll = {"info": {"schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"}, "item": [{"name": "Create X", "request": {"method": "POST", "url": {"raw": "https://api.example.com/x"}, "header": [{"key": "Authorization", "value": "Bearer real-secret"}], "body": {"mode": "raw", "raw": '{"name":""}'}}}]}
    rows, kind = parse_api_definition(json.dumps(coll).encode(), "collection.json")
    assert kind == "Postman"
    assert rows[0]["headers"]["Authorization"] == "${TARGET_API_TOKEN}"
    assert rows[0]["lifecycle_status"] == "DRAFT"
    assert rows[0]["allow_live"] is False



def test_auto_mode_returns_multi_api_applicability_matrix():
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=load_catalog(), selected_api="AUTO", use_llm=False)
    assert result["summary"]["apiActions"] >= 1
    assert result["allApiResults"]
    assert any(r["apiKey"] == "source_tp" for r in result["allApiResults"])
    assert result["summary"]["GOOD_API_ACTIONS"] == sum(1 for r in result["allApiResults"] if r["status"] == "GOOD_TO_TRIGGER")


def test_seed_catalog_is_approved_and_bulk_capable():
    contracts = load_catalog()
    assert len(contracts) == 25
    assert all(c["lifecycle_status"] == "APPROVED" for c in contracts)
    assert all(c["allow_live"] is True for c in contracts)
    assert next(c for c in contracts if c["key"] == "flow_deploy")["depends_on"] == ["flow_create"]


def test_v122_env_file_contains_original_runtime_contract():
    from pathlib import Path
    env = (Path(__file__).resolve().parents[1] / ".env.example").read_text(encoding="utf-8")
    required = [
        "HIP_CONFIG_SERVICE_BASE_URL=", "HIP_TOKEN_URL=", "HIP_CLIENT_ID=", "HIP_CLIENT_SECRET=",
        "ACCOUNT_TOKEN_URL=", "ACCOUNT_CLIENT_ID=", "PARTNER_TOKEN_URL=", "PARTNER_CLIENT_ID=",
        "SYSTEM_TOKEN_URL=", "SYSTEM_CLIENT_ID=", "USE_DELL_SSO=", "DELL_AUTH_MODE=",
        "DELL_AIA_BASE_URL=", "DELL_AIA_MODEL=gpt-oss-120b", "DELL_AIA_CLIENT_ID=",
        "HIP_REQUESTED_BY=", "HIP_USER_ID=", "HIP_ENVIRONMENT=DEV", "HIP_VERIFY_SSL=true",
        "HTTP_TIMEOUT_SECONDS=90", "HTTP_RETRY_ATTEMPTS=3", "HIP_PARALLEL_CONFIG_WORKERS=4",
        "HIP_AUTOGEN_MAX_STABLE_AGENTS=4", "HIP_NO_REUSE_LIVE=true",
    ]
    for token in required:
        assert token in env, token


def test_dell_aia_uses_v122_env_names(monkeypatch):
    from app.llm import DellAIAClient
    monkeypatch.setenv("DELL_AIA_BASE_URL", "https://aia.example/v1")
    monkeypatch.setenv("DELL_AIA_MODEL", "gpt-oss-120b")
    monkeypatch.setenv("DELL_AIA_CLIENT_ID", "cid")
    monkeypatch.setenv("DELL_AIA_CLIENT_SECRET", "secret")
    client = DellAIAClient()
    assert client.base_url == "https://aia.example/v1"
    assert client.model == "gpt-oss-120b"
    assert client.available() is True
    assert client.diagnostics()["envCompatibility"] == "V122"


def test_v122_profile_selection_for_account_partner_system():
    from app.runtime_config import credential_profile
    by = {c["key"]: c for c in load_catalog()}
    assert credential_profile(by["account_source"]) == "ACCOUNT"
    assert credential_profile(by["partner_target"]) == "PARTNER"
    assert credential_profile(by["system_source"]) == "SYSTEM"
    assert credential_profile(by["source_tp"]) == "HIP"
    assert credential_profile(by["flow_deploy"]) == "HIP"


def test_v122_url_override_is_applied(monkeypatch):
    from app.runtime_config import resolve_contract_url
    c = source_tp_contract()
    monkeypatch.setenv("HIP_CONFIG_SERVICE_BASE_URL", "https://new.example.com/hip-config-service")
    assert resolve_contract_url(c).startswith("https://new.example.com/hip-config-service/")


def test_batch_stage_good_uses_all_good_api_actions():
    client = TestClient(app)
    response = client.post(
        "/api/analyze",
        files={"workbook": ("team.xlsx", mini_xlsx(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
        data={"api_key": "AUTO", "use_llm": "false"},
    )
    assert response.status_code == 200
    analysis = response.json()
    expected = analysis["summary"]["GOOD_API_ACTIONS"]
    out = client.post("/api/batch/stage-good", json={"analysisId": analysis["analysisId"], "reviewer": "Bulk Human"})
    assert out.status_code == 200
    assert out.json()["staged"] == expected


def test_batch_live_requires_live_all_and_v122_bulk_gate(monkeypatch):
    client = TestClient(app)
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "false")
    bad = client.post("/api/batch/execute", json={"stageIds": [], "confirmation": "LIVE", "actor": "Tester"})
    assert bad.status_code == 400
    blocked = client.post("/api/batch/execute", json={"stageIds": [], "confirmation": "LIVE ALL", "actor": "Tester"})
    assert blocked.status_code == 400
    assert "Bulk LIVE is disabled" in blocked.json()["detail"]


def test_batch_live_executes_preflight_passed_stages_in_dependency_waves(monkeypatch):
    import app.main as mainmod
    from app.catalog import normalize_contract
    from app.state import STATE

    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "safe.example.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer test")
    monkeypatch.setenv("HIP_PARALLEL_CONFIG_WORKERS", "4")
    monkeypatch.setenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4")

    c1 = normalize_contract({
        "key": "first", "name": "first", "method": "POST", "url": "https://safe.example.com/first",
        "canonical_request": {"name": ""}, "required_paths": ["name"], "identity_paths": ["name"],
        "headers": {"Authorization": "${HIP_AUTHORIZATION}"}, "allow_live": True,
    })
    c2 = normalize_contract({
        "key": "second", "name": "second", "method": "POST", "url": "https://safe.example.com/second",
        "canonical_request": {"name": ""}, "required_paths": ["name"], "identity_paths": ["name"],
        "headers": {"Authorization": "${HIP_AUTHORIZATION}"}, "depends_on": ["first"], "allow_live": True,
    })
    s1 = STATE.stage({"reviewer":"A","excelRow":2,"account":"acct","apiKey":"first","payload":{"name":"x"},"contractSnapshot":c1,"contractSha256":c1["contract_sha256"],"identityFingerprint":"i1"})
    s2 = STATE.stage({"reviewer":"A","excelRow":2,"account":"acct","apiKey":"second","payload":{"name":"x"},"contractSnapshot":c2,"contractSha256":c2["contract_sha256"],"identityFingerprint":"i2"})
    for stage, contract in [(s1,c1),(s2,c2)]:
        stage["approvalStatus"]="APPROVED"
        stage["preflight"] = preflight(stage, contract)
        STATE.save_stage(stage)

    order=[]
    class Resp:
        status_code=201
        text='{}'
        def json(self): return {"ok":True}
    def fake_request(method, url, **kwargs):
        order.append(url)
        return Resp()
    monkeypatch.setattr("app.executor.requests.request", fake_request)
    # main.contract_by_key isn't involved because contractSnapshot is used.
    client=TestClient(app)
    out=client.post("/api/batch/execute",json={"stageIds":[s2["stageId"],s1["stageId"]],"confirmation":"LIVE ALL","actor":"Tester"})
    assert out.status_code==200, out.text
    body=out.json()
    assert body["summary"]["successful"]==2
    assert order[0].endswith("/first") and order[1].endswith("/second")


def test_v122_migration_environment_defaults_are_used(monkeypatch):
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "QA")
    c = next(c for c in load_catalog() if c["key"] == "migrate_source_tp")
    result = analyze_workbook(filename="team.xlsx", data=mini_xlsx(), contracts=[c], selected_api="migrate_source_tp", use_llm=False)
    payload = result["results"][0]["proposedRequest"]
    assert payload["sourceEnvironment"] == "DEV"
    assert payload["targetEnvironment"] == "QA"


def test_batch_four_eyes_approval_endpoint(monkeypatch):
    from app.state import STATE
    client = TestClient(app)
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "true")
    s1 = STATE.stage({"reviewer":"Alice","apiKey":"x","payload":{},"contractSnapshot":{}})
    s2 = STATE.stage({"reviewer":"Alice","apiKey":"y","payload":{},"contractSnapshot":{}})
    out = client.post("/api/batch/approve", json={"stageIds":[s1["stageId"],s2["stageId"]],"approver":"Bob","comment":"batch review"})
    assert out.status_code == 200
    assert out.json()["approved"] == 2
    assert STATE.get_stage(s1["stageId"])["approvalStatus"] == "APPROVED"


def tp_xlsx(headers, values, sheet="TP_DATA") -> bytes:
    from xml.sax.saxutils import escape
    def cell(col, row, value):
        n = col + 1
        letters = ""
        while n:
            n, rem = divmod(n - 1, 26)
            letters = chr(65 + rem) + letters
        return f'<c r="{letters}{row}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>'
    out = BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="{sheet}" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        h = "".join(cell(i, 1, v) for i, v in enumerate(headers))
        r = "".join(cell(i, 2, v) for i, v in enumerate(values))
        z.writestr("xl/worksheets/sheet1.xml", f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">{h}</row><row r="2">{r}</row></sheetData></worksheet>')
    return out.getvalue()


def test_v4_tp_only_endpoint_generates_good_to_go_and_html_report():
    client = TestClient(app)
    r = client.post('/api/tp/analyze', files={'workbook': ('tp.xlsx', mini_xlsx('SFTP'), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}, data={'tp_scope': 'BOTH', 'use_llm': 'false', 'scan_all_sheets': 'true'})
    assert r.status_code == 200, r.text
    a = r.json()
    assert a['mode'] == 'TRANSPORT_PROFILE_ONLY'
    assert a['summary']['GOOD_TO_TRIGGER'] == 1
    action = a['allApiResults'][0]
    assert action['readinessLabel'] == 'GOOD TO GO'
    assert action['interfaceType'] == 'SFTP HAFT'
    assert action['tpRoleKey'] == 'source'
    report = client.get(f"/api/tp/analyses/{a['analysisId']}/report.html?download=false")
    assert report.status_code == 200
    assert 'Transport Profile Readiness Report' in report.text
    assert 'SFTP_ACME_ASN_SRC_OB' in report.text
    assert 'SFTP Server' in report.text
    assert 'EVIDENCE_ONLY' in report.text


def test_v4_as2_target_uses_exact_v122_interface_schema_and_ssl_required():
    headers = ['Target System','DEV-Transport Profile Name','Target Interface Type','Document Type Name','Document Type Version','Hip Account names','Interface Environment','Request Method','Partner URL','Partner Identifier','Dell Identifier','Signing Algorithm','Encryption Algorithm','Encryption Certificate','SSL Certificate','Enable AS2 Message Compression','Asynchronous MDN Required','Are Input Files Compressed?','Is EBCDIC enabled?']
    values = ['dce-test-partner','AS2_ACME_850_TGT_IB','AS2','EDI_850','1.0','acme','UAT','POST','https://partner.example/as2','PARTNER-AS2','DELL-AS2','SHA256','AES256','enc.cer','partner-root.crt','False','False','False','False']
    client = TestClient(app)
    r = client.post('/api/tp/analyze', files={'workbook': ('as2.xlsx', tp_xlsx(headers, values), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}, data={'tp_scope': 'BOTH', 'use_llm': 'false'})
    assert r.status_code == 200, r.text
    row = r.json()['allApiResults'][0]
    assert row['tpRoleKey'] == 'target'
    assert row['interfaceFamily'] == 'HTTPS_AS2'
    assert row['interfaceType'] == 'HTTPS-AS2'
    assert row['status'] == 'GOOD_TO_TRIGGER'
    params = row['proposedRequest']['transportProfileDetails'][0]['interfaceDetails'][0]['parameters']
    assert params['SSL Certificate'] == 'partner-root.crt'
    assert 'Signing Algorithm' in params
    assert 'Existing Account Name' not in params


def test_v4_as2_target_missing_ssl_is_not_good_to_go():
    headers = ['Target System','DEV-Transport Profile Name','Target Interface Type','Document Type Name','Document Type Version','Hip Account names','Interface Environment','Request Method','Partner URL','Partner Identifier','Dell Identifier','Signing Algorithm','Encryption Algorithm','Encryption Certificate','SSL Certificate','Enable AS2 Message Compression','Asynchronous MDN Required','Are Input Files Compressed?','Is EBCDIC enabled?']
    values = ['dce-test-partner','AS2_ACME_850_TGT_IB','AS2','EDI_850','1.0','acme','UAT','POST','https://partner.example/as2','PARTNER-AS2','DELL-AS2','SHA256','AES256','enc.cer','','False','False','False','False']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='as2.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='BOTH', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'NEEDS_INPUT'
    assert any(p.endswith('SSL Certificate') for p in row['missingRequiredPaths'])


def test_v4_tp_batch_stage_selected_only_stages_selected_good_actions():
    client = TestClient(app)
    r = client.post('/api/tp/analyze', files={'workbook': ('tp.xlsx', mini_xlsx('SFTP'), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}, data={'tp_scope': 'BOTH', 'use_llm': 'false'})
    a = r.json()
    good = [x for x in a['allApiResults'] if x['status'] == 'GOOD_TO_TRIGGER']
    out = client.post('/api/tp/batch/stage', json={'analysisId': a['analysisId'], 'actionIds': [good[0]['actionId']], 'reviewer': 'TP Reviewer'})
    assert out.status_code == 200, out.text
    assert out.json()['staged'] == 1
    assert out.json()['stages'][0]['apiKey'] in {'source_tp', 'target_tp'}


def test_v4_unsupported_interface_is_not_ready_and_never_bulk_good():
    headers = ['Source System','DEV-Transport Profile Name','Source Interface Type','Document Type Name','Hip Account names']
    values = ['AIC - DCE','MQ_ACME_SRC_IB','MQ-Series Integration','XML_ACME','acme']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='BOTH', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'DO_NOT_TRIGGER'
    assert row['readinessLabel'] == 'NOT READY'
    assert out['summary']['GOOD_TO_TRIGGER'] == 0
    assert 'not registered' in row['warnings'][0]


def test_v5_interface_type_is_taken_only_from_explicit_excel_column_not_other_clues():
    # TP name and SFTP Server both strongly suggest SFTP, but no explicit Interface Type column exists.
    headers = ['Source System','DEV-Transport Profile Name','Document Type Name','Hip Account names','SFTP Server','Actual Delivery Type']
    values = ['AIC - DCE','SFTP_ACME_ASN_SRC_OB','XML_ACME_ASN_10','acme-account','sftp.acme.example','SFTP']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'NEEDS_INPUT'
    assert row['readinessLabel'] == 'NEEDS INPUT'
    assert row['interfaceProvidedByExcel'] is False
    assert row['interfaceInferenceUsed'] is False
    assert row['interfaceSourceColumn'] == ''
    assert row['interfaceFamily'] == 'MISSING'
    assert 'will not infer' in row['warnings'][0]
    assert out['summary']['GOOD_TO_TRIGGER'] == 0


def test_v5_explicit_excel_interface_is_hard_locked_into_mapping():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=mini_xlsx('SFTP'), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'GOOD_TO_TRIGGER'
    assert row['interfaceProvidedByExcel'] is True
    assert row['interfaceInferenceUsed'] is False
    assert row['interfaceSourceColumn'] == 'Source Interface Type'
    assert row['interfaceRawValue'] == 'SFTP'
    assert row['interfaceType'] == 'SFTP HAFT'  # approved API canonical label
    interface_path = 'transportProfileDetails.0.interfaceDetails.0.interfaceType'
    mapping = next(m for m in row['mappings'] if m['targetPath'] == interface_path)
    assert mapping['sourceColumn'] == 'Source Interface Type'
    assert mapping['sourceValue'] == 'SFTP'
    assert mapping['mappedValue'] == 'SFTP HAFT'
    assert mapping['method'] == 'Explicit Excel interface lock'
    assert mapping['confidence'] == 1.0


def test_v5_generic_exact_interface_type_column_is_allowed_but_delivery_type_is_not():
    headers = ['Source System','DEV-Transport Profile Name','Interface Type','Document Type Name','Hip Account names']
    values = ['AIC - DCE','FTP_ACME_ASN_SRC_OB','FTP','XML_ACME_ASN_10','acme-account']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['interfaceSourceColumn'] == 'Interface Type'
    assert row['interfaceRawValue'] == 'FTP'
    assert row['interfaceType'] == 'FTP'
    assert row['interfaceFamily'] == 'FILE'
    assert row['interfaceInferenceUsed'] is False


def test_v5_unknown_explicit_interface_is_not_ready_not_reinterpreted():
    headers = ['Source System','DEV-Transport Profile Name','Source Interface Type','Document Type Name','Hip Account names','SFTP Server']
    values = ['AIC - DCE','SFTP_ACME_ASN_SRC_OB','MQ-Series Integration','XML_ACME_ASN_10','acme-account','sftp.acme.example']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'DO_NOT_TRIGGER'
    assert row['readinessLabel'] == 'NOT READY'
    assert row['interfaceProvidedByExcel'] is True
    assert row['interfaceRawValue'] == 'MQ-Series Integration'
    assert row['interfaceInferenceUsed'] is False
    assert 'not registered' in row['warnings'][0]


def test_v6_explicit_sftp_server_business_label_canonicalizes_without_inference():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=mini_xlsx('SFTP Server'), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'GOOD_TO_TRIGGER'
    assert row['interfaceRawValue'] == 'SFTP Server'
    assert row['interfaceType'] == 'SFTP HAFT'
    assert row['interfaceFamily'] == 'FILE'
    assert row['interfaceInferenceUsed'] is False
    assert row['interfaceCanonicalized'] is True
    # SFTP Server evidence is still not injected as a server URL because FILE TP schema has no such leaf.
    assert 'SFTP Server' in row['unmappedColumns']
    assert all(m['sourceColumn'] != 'SFTP Server' for m in row['mappings'])


def test_v6_tp_mapping_is_strict_and_field_matrix_explains_every_canonical_leaf():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=mini_xlsx('SFTP Server'), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    paths = set(row['contractSnapshot']['paths'])
    matrix_paths = {x['path'] for x in row['fieldMatrix']}
    assert matrix_paths == paths
    assert any(x['path'] == 'systemName' and x['sourceType'] == 'EXCEL' for x in row['fieldMatrix'])
    assert any(x['path'].endswith('.interfaceType') and x['sourceType'] == 'EXCEL_CANONICALIZED' for x in row['fieldMatrix'])
    assert row['readinessChecks']
    assert row['status'] == 'GOOD_TO_TRIGGER'
    assert row['score'] < 100
    assert 'optional/null payload field(s)' in row['decisionReason']


def test_v6_missing_required_field_has_friendly_readiness_diagnostics():
    headers = ['Source System','DEV-Transport Profile Name','Source Interface Type','Document Type Name','Hip Account names']
    values = ['', 'SFTP_ACME_SRC_OB', 'SFTP Server', 'XML_ACME', 'acme-account']
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename='tp.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'NEEDS_INPUT'
    assert 'systemName' in row['missingRequiredPaths']
    assert any(x['name'] == 'System mapped' and x['status'] == 'FAIL' for x in row['readinessChecks'])
    assert any(x['check'] == 'System mapped' and x['count'] == 1 for x in out['diagnosticsSummary']['topBlockers'])
    assert 'Input/review required' in row['decisionReason']


def test_v6_individual_customer_mapping_report_endpoint():
    client = TestClient(app)
    r = client.post('/api/tp/analyze', files={'workbook': ('tp.xlsx', mini_xlsx('SFTP Server'), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}, data={'tp_scope': 'SOURCE', 'use_llm': 'false'})
    assert r.status_code == 200, r.text
    a = r.json(); row = a['allApiResults'][0]; action_id = row['actionId']
    detail = client.get(f"/api/tp/analyses/{a['analysisId']}/actions/{action_id}")
    assert detail.status_code == 200
    assert detail.json()['action']['tpName'] == 'SFTP_ACME_ASN_SRC_OB'
    report = client.get(f"/api/tp/analyses/{a['analysisId']}/actions/{action_id}/report.html?download=false")
    assert report.status_code == 200
    assert 'Complete TP API field coverage' in report.text
    assert 'Readiness checks' in report.text
    assert 'SFTP Server' in report.text and 'SFTP HAFT' in report.text


def test_v6_deep_health_endpoint_is_non_mutating_and_reports_all_components(monkeypatch):
    import app.main as main_module
    monkeypatch.setattr(main_module.DellAIAClient, 'test', lambda self: {'ok': True, 'diagnostics': {'model': 'gpt-oss-120b'}})
    monkeypatch.setattr(main_module, 'test_contract_oauth', lambda c: {'ok': True, 'state': 'UP', 'message': 'oauth ok'})
    monkeypatch.setattr(main_module, 'probe_uhal_tp_validation', lambda c, role: {'ok': True, 'state': 'UP', 'message': f'{role} uhal validate ok', 'mutating': False})
    monkeypatch.setattr(main_module, 'probe_contract_endpoint', lambda c, authenticated=True: {'ok': True, 'state': 'INCONCLUSIVE', 'message': 'create OPTIONS inconclusive'})
    client = TestClient(app)
    out = client.post('/api/runtime/deep-health')
    assert out.status_code == 200
    body = out.json()
    assert body['ok'] is True and body['nonMutating'] is True
    assert set(body['components']) >= {'backend','catalog','agent','hipOauth','sourceTpApi','targetTpApi'}


def test_v6_ui_contains_loading_health_and_full_field_mapping_controls():
    client = TestClient(app)
    html = client.get('/').text
    for needle in ['busyOverlay','refreshHealthBtn','runtimeHealthBtn','readinessChecksBody','fieldMatrixBody','customerReportBtn','diagnosticsSection']:
        assert needle in html


def test_v7_create_options_500_is_inconclusive_not_api_down(monkeypatch):
    import app.executor as ex
    class Resp:
        status_code = 500
        text = 'method not supported here'
    monkeypatch.setattr(ex, 'host_allowed', lambda url: True)
    monkeypatch.setattr(ex.requests, 'options', lambda *a, **k: Resp())
    row = ex.probe_contract_endpoint(source_tp_contract(), authenticated=False)
    assert row['ok'] is True
    assert row['state'] == 'INCONCLUSIVE'
    assert 'not an API-down verdict' in row['message']


def test_v7_uhal_smoke_uses_non_mutating_validator_and_exact_reference(monkeypatch):
    import app.main as main_module
    from app.uhal_reference import validation_payload, create_payload
    monkeypatch.setattr(main_module, 'test_contract_oauth', lambda c: {'ok': True, 'state': 'UP', 'message': 'oauth ok'})
    monkeypatch.setattr(main_module, 'probe_uhal_tp_validation', lambda c, role: {'ok': True, 'state': 'UP', 'message': f'{role} validator ok', 'statusCode': 200, 'mutating': False})
    out = TestClient(app).post('/api/runtime/uhal-tp-smoke')
    assert out.status_code == 200
    body = out.json()
    assert body['ok'] is True and body['nonMutating'] is True
    assert body['sourceValidationPayload'] == validation_payload('source')
    assert body['targetValidationPayload'] == validation_payload('target')
    assert body['sourceCreatePayloadPreview'] == create_payload('source')
    assert body['targetCreatePayloadPreview'] == create_payload('target')
    assert 'No TP Create API was called' in body['message']


def test_v7_uhal_source_excel_maps_to_v122_payload_parity():
    from app.tp_service import analyze_tp_workbook
    from app.uhal_reference import create_payload
    headers = ['Application Tracking','LENS TP Name','Source System','DEV-Transport Profile Name','Source Interface Type','Document Type Name','Hip Account names','Directory','Existing Account Name','Subscription Folder']
    values = ['UHAL-ASN','U-HAUL','AIC - DCE','SFTP_U-HAUL_ASN_PC_SRC_IB','SFTP Server','XML_DellAutoASN_10_U-HAUL_ANS_IB(1.0)','UHAL_HIP','/remote/uhaul','haftatap10251594','/SFTP_U-HAUL_ASN_PC_SRC_IB']
    out = analyze_tp_workbook(filename='uhal.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'GOOD_TO_TRIGGER' and row['score'] < 100
    got = row['proposedRequest']; ref = create_payload('source')
    assert got['systemName'] == ref['systemName']
    gd, rd = got['transportProfileDetails'][0], ref['transportProfileDetails'][0]
    assert gd['transportProfileName'] == rd['transportProfileName']
    assert gd['documentTypeDetails'] == rd['documentTypeDetails']
    assert gd['interfaceDetails'][0]['parameters'] == rd['interfaceDetails'][0]['parameters']
    assert gd['tags'] == rd['tags']


def test_v7_uhal_target_excel_maps_to_v122_payload_parity():
    from app.tp_service import analyze_tp_workbook
    from app.uhal_reference import create_payload
    headers = ['Application Tracking','LENS TP Name','Target System','DEV-Transport Profile Name','Target Interface Type','Document Type Name','Hip Account names','Directory','Existing Account Name','Subscription Folder']
    values = ['UHAL-ASN','U-HAUL','dce-test-partner','SFTP_U-HAUL_ASN_PC_TGT_OB','SFTP Server','XML_SHIPMENT_NOTICE_10_U-HAUL_ANS_OB(1.0)','UHAL_HIP','/remote/uhaul','haftatap10251593','/Inbound/ASN']
    out = analyze_tp_workbook(filename='uhal.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='TARGET', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'GOOD_TO_TRIGGER' and row['score'] < 100
    got = row['proposedRequest']; ref = create_payload('target')
    assert got['systemName'] == ref['systemName']
    gd, rd = got['transportProfileDetails'][0], ref['transportProfileDetails'][0]
    assert gd['transportProfileName'] == rd['transportProfileName']
    assert gd['documentTypeDetails'] == rd['documentTypeDetails']
    assert gd['interfaceDetails'][0]['parameters'] == rd['interfaceDetails'][0]['parameters']
    assert gd['tags'] == rd['tags']


def test_v7_lens_tp_name_is_reference_only_not_executable_identity():
    from app.tp_service import analyze_tp_workbook
    headers = ['LENS TP Name','Source System','Source Interface Type','Document Type Name','Hip Account names','Directory']
    values = ['U-HAUL','AIC - DCE','SFTP Server','XML_DellAutoASN_10_U-HAUL_ANS_IB(1.0)','haftatap10251594','/SFTP_U-HAUL_ASN_PC_SRC_IB']
    out = analyze_tp_workbook(filename='uhal.xlsx', data=tp_xlsx(headers, values), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    row = out['tpActions'][0]
    assert row['status'] == 'NEEDS_INPUT'
    assert row['tpName'] == ''
    assert 'transportProfileDetails.0.transportProfileName' in row['missingRequiredPaths']
    assert row['customerName'] == 'U-HAUL'


def _two_row_tp_xlsx(headers, row1, row2):
    from io import BytesIO
    import zipfile
    from xml.sax.saxutils import escape
    def cell(col, row, value):
        n = col + 1; letters = ''
        while n:
            n, rem = divmod(n - 1, 26); letters = chr(65 + rem) + letters
        return f'<c r="{letters}{row}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>'
    out = BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="TP" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        h = ''.join(cell(i, 1, v) for i, v in enumerate(headers))
        r1 = ''.join(cell(i, 2, v) for i, v in enumerate(row1)); r2 = ''.join(cell(i, 3, v) for i, v in enumerate(row2))
        z.writestr('xl/worksheets/sheet1.xml', f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">{h}</row><row r="2">{r1}</row><row r="3">{r2}</row></sheetData></worksheet>')
    return out.getvalue()


def test_v7_identical_duplicate_evidence_merges_but_conflict_blocks():
    from app.tp_service import analyze_tp_workbook
    headers = ['LENS TP Name','Source System','DEV-Transport Profile Name','Source Interface Type','Document Type Name','Hip Account names','Directory','Existing Account Name','Subscription Folder']
    base = ['U-HAUL','AIC - DCE','SFTP_U-HAUL_ASN_PC_SRC_IB','SFTP Server','XML_DellAutoASN_10_U-HAUL_ANS_IB(1.0)','UHAL_HIP','/remote/uhaul','haftatap10251594','/SFTP_U-HAUL_ASN_PC_SRC_IB']
    same = analyze_tp_workbook(filename='dupe.xlsx', data=_two_row_tp_xlsx(headers, base, base), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    assert len(same['tpActions']) == 1
    assert same['tpActions'][0]['status'] == 'GOOD_TO_TRIGGER'
    assert same['tpActions'][0]['mergedDuplicateEvidenceCount'] == 1
    conflict_row = list(base); conflict_row[-1] = '/DIFFERENT'
    conflict = analyze_tp_workbook(filename='dupe.xlsx', data=_two_row_tp_xlsx(headers, base, conflict_row), contracts=load_catalog(), scope='SOURCE', use_llm=False)
    assert len(conflict['tpActions']) == 2
    assert all(x['status'] == 'NEEDS_INPUT' and x['conflictingDuplicateIdentity'] for x in conflict['tpActions'])



def _team_multilevel_xlsx(*, tp_name="SFTP_ATEA_SRC_OB", doc="", hip_account="ATEA_PC", legacy_source_interface="Directory Monitor inbound", api_interface="SFTP Server", tp_account="dklp_dell", directory="/TestInbound", subscription=""):
    """Workbook shape mirroring the team's multi-row/grouped SFTP_UAT sheet."""
    from xml.sax.saxutils import escape
    def cell(col, row, value):
        n = col + 1; letters = ""
        while n:
            n, rem = divmod(n - 1, 26); letters = chr(65 + rem) + letters
        if value == "":
            return ""
        return f'<c r="{letters}{row}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>'
    out = BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="SFTP_UAT" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        # Repeated Account leaves with parent group labels just like the team sheet.
        parents = ["", "", "", "", "", "", "", "", "", "Add >Partner Details", "", "Add >Transport Profile Details", "", "", ""]
        subparents = ["", "", "", "", "", "", "", "", "", "OpenText", "", "OpenText", "", "", ""]
        headers = ["Application Tracking","LENS TP Name","Source System","DEV-Transport Profile Name","Source Interface Type","Target Interface Type","Document Type Name","Hip Account names","Interface Type","Account","Contact","Account","SFTP Server","Port","Directory"]
        values = ["DELL_PREMIER","ATEA Norway","AIC - DCE",tp_name,legacy_source_interface,"",doc,hip_account,api_interface,"atea.se","ops@atea.example",tp_account,"ftp.atea.com","22",directory]
        # Optionally add an explicit correct Subscription Folder column.
        if subscription:
            parents.append("Add >Transport Profile Details"); subparents.append("OpenText"); headers.append("Subscription Folder"); values.append(subscription)
        r1=''.join(cell(i,1,v) for i,v in enumerate(parents)); r2=''.join(cell(i,2,v) for i,v in enumerate(subparents)); r3=''.join(cell(i,3,v) for i,v in enumerate(headers)); r4=''.join(cell(i,4,v) for i,v in enumerate(values))
        z.writestr("xl/worksheets/sheet1.xml", f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">{r1}</row><row r="2">{r2}</row><row r="3">{r3}</row><row r="4">{r4}</row></sheetData></worksheet>')
    return out.getvalue()


def test_v8_team_interface_uses_api_interface_type_not_legacy_source_interface():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    assert row["interfaceSourceColumn"] == "Interface Type"
    assert row["interfaceRawValue"] == "SFTP Server"
    assert row["interfaceType"] == "SFTP HAFT"
    assert all(m["sourceColumn"] != "Source Interface Type" for m in row["mappings"] if m["targetPath"].endswith("interfaceType"))


def test_v8_team_directory_never_maps_to_subscription_folder():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(directory="/TestInbound", subscription=""), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    params = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params["Subscription Folder"] == ""
    assert not any(m["targetPath"].endswith("Subscription Folder") and "directory" in m["sourceColumn"].lower() for m in row["mappings"])
    assert any(x["column"] == "Directory" and "never mapped to Subscription Folder" in x["reason"] for x in row["unmappedDetails"])


def test_v8_team_existing_account_comes_from_transport_profile_details_account_not_hip_account():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(hip_account="ATEA_PC", tp_account="dklp_dell"), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    params = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params["Existing Account Name"] == "dklp_dell"
    mapping = next(m for m in row["mappings"] if m["targetPath"].endswith("Existing Account Name"))
    assert "transport profile" in mapping["sourceColumn"].lower()
    assert mapping["sourceValue"] == "dklp_dell"
    assert row["hipAccountName"] == "ATEA_PC"


def test_v8_document_type_is_optional_and_left_empty_when_excel_has_no_data():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(doc=""), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    docs = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"][0]
    assert docs["documentTypeName"] == ""
    assert docs["documentTypeVersion"] == ""
    assert "transportProfileDetails.0.documentTypeDetails.0.documentTypeName" not in row["missingRequiredPaths"]
    assert any(c["name"] == "Document Type" and c["status"] == "MISSING_OPTIONAL" and not c["blocking"] for c in row["readinessChecks"])
    assert row["blankOptionalFieldCount"] >= 2
    assert row["score"] < 100
    assert row["status"] == "GOOD_TO_TRIGGER"


def test_v8_transport_profile_name_does_not_require_dev_prefixed_column():
    from app.tp_service import analyze_tp_workbook
    headers = ["Source System","Transport Profile Name","Interface Type","Existing Account Name"]
    values = ["AIC - DCE","SFTP_GOLD_GROUP_SRC_OB","SFTP Server","dell"]
    out = analyze_tp_workbook(filename="team.xlsx", data=tp_xlsx(headers, values), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    assert row["tpName"] == "SFTP_GOLD_GROUP_SRC_OB"
    assert row["status"] == "GOOD_TO_TRIGGER"
    mapping = next(m for m in row["mappings"] if m["targetPath"].endswith("transportProfileName"))
    assert mapping["sourceColumn"] == "Transport Profile Name"


def test_v8_subscription_folder_maps_only_when_explicitly_provided():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(directory="/remote", subscription="/SUBSCRIPTION"), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    params = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params["Subscription Folder"] == "/SUBSCRIPTION"
    mapping = next(m for m in row["mappings"] if m["targetPath"].endswith("Subscription Folder"))
    assert "Subscription Folder" in mapping["sourceColumn"]
    assert mapping["sourceValue"] == "/SUBSCRIPTION"


def test_v8_missing_transport_profile_existing_account_is_needs_input_not_filled_from_hip_account():
    from app.tp_service import analyze_tp_workbook
    out = analyze_tp_workbook(filename="team.xlsx", data=_team_multilevel_xlsx(hip_account="ATEA_PC", tp_account=""), contracts=load_catalog(), scope="SOURCE", use_llm=False)
    row = out["tpActions"][0]
    params = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params["Existing Account Name"] == ""
    assert row["status"] == "NEEDS_INPUT"
    assert any(str(p).endswith("Existing Account Name") for p in row["missingRequiredPaths"])
    assert row["hipAccountName"] == "ATEA_PC"


def test_v9_blank_null_nan_and_whitespace_are_missing_values():
    from app.workbook import blank
    import math
    for value in (None, "", "   ", "null", "NULL", "none", "NaN", "<NA>", float("nan"), [], {}):
        assert blank(value), repr(value)
    assert not blank(0)
    assert not blank(False)
    assert not blank("0")


def test_v9_optional_blank_values_reduce_score_without_blocking_good_to_go():
    from app.tp_service import analyze_tp_workbook
    blank_doc = analyze_tp_workbook(
        filename="team.xlsx", data=_team_multilevel_xlsx(doc="", subscription=""),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )["tpActions"][0]
    filled_doc = analyze_tp_workbook(
        filename="team.xlsx", data=_team_multilevel_xlsx(doc="XML_TEAM_DOC(1.0)", subscription="/SUBSCRIPTION"),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )["tpActions"][0]
    assert blank_doc["status"] == "GOOD_TO_TRIGGER"
    assert filled_doc["status"] == "GOOD_TO_TRIGGER"
    assert blank_doc["blankFieldCount"] > filled_doc["blankFieldCount"]
    assert blank_doc["score"] < filled_doc["score"]
    assert blank_doc["completenessScore"] == blank_doc["score"]
    assert "blank/null/NaN/empty values receive zero credit" in blank_doc["scoreBasis"]


def test_v9_required_blank_has_stronger_score_penalty_and_blocks_execution():
    from app.tp_service import analyze_tp_workbook
    headers = ["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name"]
    complete = analyze_tp_workbook(
        filename="tp.xlsx", data=tp_xlsx(headers, ["AIC - DCE", "SFTP_SCORE_SRC_IB", "SFTP Server", "acct1"]),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )["tpActions"][0]
    missing = analyze_tp_workbook(
        filename="tp.xlsx", data=tp_xlsx(headers, ["", "SFTP_SCORE_SRC_IB", "SFTP Server", "acct1"]),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )["tpActions"][0]
    assert complete["status"] == "GOOD_TO_TRIGGER"
    assert missing["status"] == "NEEDS_INPUT"
    assert missing["blankRequiredFieldCount"] >= 1
    assert missing["score"] < complete["score"]
    assert "systemName" in missing["missingRequiredPaths"]


def test_v9_ui_and_report_expose_blank_null_completeness_counts():
    from app.reporting import render_tp_readiness_report
    from app.tp_service import analyze_tp_workbook
    row_analysis = analyze_tp_workbook(
        filename="team.xlsx", data=_team_multilevel_xlsx(doc=""),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )
    row_analysis["analysisId"] = "v9-score-test"
    html = render_tp_readiness_report(row_analysis)
    assert "Blank / null fields" in html
    assert "Blank/null values = zero credit" in html
    ui = TestClient(app).get('/').text
    js = TestClient(app).get('/assets/app.js').text
    assert 'Readiness' in ui
    assert 'Blank / null payload fields' in js
