# V11 — Dell LIVE HTTP + Immutable Interface Contract

V11 hardens the standalone TP Excel agent for real Dell HIP execution while enforcing a strict **values-only mutation boundary**.

## Execution model

1. Excel supplies the authoritative `Interface Type`.
2. The application selects the approved interface-specific TP contract (SFTP HAFT, SFTP Server, FTP, HTTPS, HTTPS-AS2, NAS, or Rabbit MQ).
3. That contract fixes the JSON attribute names, nesting, list cardinality, HTTP method, URL route, protected header names, TP role, and interface selector.
4. Excel/agent mapping may populate customer values only.
5. A human may edit customer leaf values only. Adding/removing/renaming/re-nesting attributes is rejected at Stage.
6. Preflight fingerprints the payload, contract, attribute manifest, locked selector values, resolved Dell URL, method, and header names.
7. LIVE re-checks all fingerprints and **rebuilds the outgoing body through the canonical selected-interface schema** before `requests.request(...)` sends it to Dell.
8. Any schema/selector/URL/method change after preflight blocks execution and requires re-analysis/re-stage/re-preflight.

## Interface-driven attribute changes

Attributes are allowed to differ **between approved interface contracts**. They are not allowed to mutate after the interface contract is selected.

Examples:

- `SFTP HAFT` uses the FILE/SFTP HAFT parameter schema.
- `SFTP Server` uses the V130 conditional SFTP Server schema.
- `HTTPS-AS2` uses the approved AS2 receiver/sender schema.
- `NAS` and `Rabbit MQ` use their own approved schemas.

For conditional SFTP Server values (Linux/Windows, Password/Key, Sender/Partner, Rename/Archive/Cron/Compression/EBCDIC), the correct conditional attribute set is materialized during analysis. Changing a condition later in a way that would require a different attribute set is rejected; the row must be re-analyzed so a new approved schema can be selected and locked.

## Contract-owned value locks

V11 also prevents edits to selector/runtime fields that define the execution contract:

- `operation`
- `requestedBy`
- `hipEnvironment`
- `systemType`
- `deploymentGroupName`
- `transportProfileOperation`
- `transportProfileUsage`
- `interfaceRole`
- `interfaceType`

Customer values such as system name, TP name, document values, account values and interface parameters remain editable where the selected contract permits them.

## Dell LIVE gates

A Stage can execute only when all relevant gates pass:

- analysis status is executable
- selected contract is `APPROVED` and `allow_live=true`
- immutable schema check passes
- locked selector values match
- required/conditional field rules pass
- Stage payload fingerprint matches Preflight
- contract fingerprint matches Preflight
- execution-plan fingerprint matches (URL/method/schema/selectors/header names)
- Dell target host is allowlisted
- HIP OAuth/direct bearer configuration is available
- `HIP_LIVE_API_EXECUTION=true`
- optional four-eyes approval is complete
- circuit breaker is closed
- PROD guard passes when `HIP_ENVIRONMENT=PROD`
- operator types exactly `LIVE` (or `LIVE ALL` for governed bulk)

For PROD, V130 parity requires:

```text
PRODUCTION_EXECUTION_CONFIRMATION=YES
CHANGE_TICKET=<approved change ticket>
```

## New operator diagnostics

- `GET /api/runtime/live-readiness` — non-mutating view of global Dell LIVE gates and resolved TP endpoints.
- `GET /api/stages/{stage_id}/live-plan` — redacted, non-mutating preview of the exact selected contract, URL, method, attribute manifest, locked paths and preflight readiness for a staged TP.

Neither endpoint sends a TP Create call.

## Automated proof

V11 adds tests that prove:

- normal customer value edits are allowed
- invented/removed/re-nested attributes are blocked
- `interfaceType` cannot be changed after interface selection
- payload preflight and Dell LIVE readiness are separate
- final LIVE HTTP body is rebuilt from the canonical interface schema
- resolved Dell execution boundary cannot change after preflight
- V130 PROD confirmation/change-ticket guard is enforced
- SFTP Server and SFTP HAFT do not share an attribute schema
- runtime LIVE-readiness reports a real network boundary and values-only policy
- staged LIVE-plan preview matches the selected immutable contract

No real Dell mutation is performed by automated tests; only the final external HTTP call is mocked in LIVE-path tests.
