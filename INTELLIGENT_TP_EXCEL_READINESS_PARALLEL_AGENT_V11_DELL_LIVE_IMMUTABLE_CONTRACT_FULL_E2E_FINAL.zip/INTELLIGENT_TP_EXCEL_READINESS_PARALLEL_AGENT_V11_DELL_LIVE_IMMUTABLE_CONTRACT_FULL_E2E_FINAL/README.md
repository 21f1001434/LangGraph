# Intelligent TP Excel Readiness & Parallel Execution Agent — V11

Standalone Transport Profile (TP) Excel mapping, readiness, HTML reporting, health diagnostics, governed staging/preflight, and controlled parallel HIP TP API execution.

V11 is the Dell-LIVE-hardened all-interface release. It keeps all V10 interface support plus the V8/V9 mapping/scoring corrections, and adds an immutable HTTP execution boundary: **the selected interface determines the approved attribute schema; after selection, only customer values may change.** `SFTP Server` remains a separate V130 contract and is never coerced to `SFTP HAFT`.

## Supported TP interface contracts

The application can analyze, map, stage, preflight and execute Source/Sender and Target/Receiver TP Create requests for:

| Excel/API Interface | Contract family | LIVE Create |
|---|---|---|
| SFTP / SFTP HAFT | FILE / SFTP HAFT | Yes |
| **SFTP Server** | **V130 SFTP Server conditional contract** | **Yes** |
| FTP | FILE / FTP | Yes |
| HTTPS / REST | HTTPS | Yes |
| AS2 / HTTPS-AS2 | HTTPS-AS2 | Yes |
| NAS | NAS | Yes |
| Rabbit MQ | Rabbit MQ | Yes |

The interface is selected only from the authoritative Excel Interface Type cell. The LLM cannot infer an interface from TP name, hostname, Directory, port, delivery type, or other workbook clues.

## End-to-end flow

`Excel with multiple customers / TPs → detect TP rows → read explicit Interface Type → select + lock exact approved interface contract → map Excel evidence into values only → apply conditional interface rules → blank/null-aware completeness score → GOOD TO GO / NEEDS INPUT / NOT READY → rich UI + master/individual HTML reports → select Good TPs → Stage (schema + selector lock) → optional four-eyes approval → Preflight (payload + contract + execution-plan fingerprints) → LIVE / LIVE ALL → rebuild final HTTP body from canonical interface schema → real Dell HIP TP Create call → execution evidence + audit`

### V11 immutable LIVE boundary

V11 does not allow the agent or human payload editor to mutate TP attributes after an interface contract is selected. It locks JSON keys, nesting, list cardinality, method, resolved route, protected header names, TP role/interface selectors, and contract version. Only permitted leaf values may change. Before sending LIVE, the server reconstructs the outgoing request from the canonical selected-interface schema plus the staged scalar values.

Attributes **can differ across interfaces** because every interface has its own pre-approved contract. If an SFTP Server condition (for example Linux → Windows or Password → Key) requires a different conditional attribute set, the record must be re-analyzed so that the new contract shape is created and locked; the editor cannot mutate the existing staged shape.

Non-mutating diagnostics are available at `/api/runtime/live-readiness` and `/api/stages/{stage_id}/live-plan`.

## V130 SFTP Server rules

The Dev-team SFTP Server contract is implemented from the V130 R1 source and the supplied screenshots.

Base interface:

```json
{
  "interfaceType": "SFTP Server",
  "interfaceRole": "Primary",
  "parameters": {
    "Server Type": "Linux",
    "Server Name": "...",
    "Server Path": "...",
    "File Filtering Pattern": "...",
    "Post File Transfer Action": "Delete",
    "Polling Interval": "Cron Expression",
    "Are Input Files Compressed?": "True",
    "SPA URL": "",
    "Api Name": "",
    "Server Port": "22",
    "Login Authentication Type": "Password",
    "Username": "...",
    "Password": "...",
    "Cron Expression": "...",
    "Compression Format": "ZIP"
  }
}
```

Conditional behavior is schema locked:

- Dell Application: Server Type may be `Linux` or `Windows`.
- Partner: Server Type is `Linux` only.
- Linux: send `Server Port` + `Login Authentication Type`.
- Windows: send only Windows login-authentication fields; Linux auth fields are pruned.
- Login Authentication Type: `Password` or `Key`.
- Password auth: send `Username` + `Password`.
- Key auth: send `SSH Username` and fixed `SSH Key = haft_aut_sftp_server_private_key`.
- Windows Login Authentication Type: `Password`; send Windows username/password.
- Sender only: File Filtering Pattern, Post File Transfer Action, Polling Interval.
- Rename action: requires `Rename` (`Timestamp (yyyyddMMhhmmss)` or `Random Text`).
- Linux + Move To Archive: requires `Archive File Path`.
- Cron polling: requires `Cron Expression`.
- Compressed input: requires `Compression Format` (`GZIP`, `ZIP`, `TAR`).
- Partner only: `Is EBCDIC enabled?`; when true requires approved `Code Page`.
- Inactive conditional fields are omitted from the final HTTP payload, not sent as misleading blanks.

For SFTP Server only, approved Excel aliases include:

- `SFTP Server` → `Server Name`
- `Directory` → `Server Path`
- `Port` → `Server Port`
- authentication/user/password fields → the corresponding SFTP Server parameter

This is intentionally different from SFTP HAFT. For **SFTP HAFT**, `Directory` still never becomes `Subscription Folder`.

## Team mapping corrections retained

Core TP fields are provenance locked:

- `systemName`
- `transportProfileName`
- `interfaceType`
- `documentTypeName`
- `documentTypeVersion`
- FILE `Subscription Folder`
- FILE `Existing Account Name`

Important rules:

- Exact generic `Interface Type` wins over legacy Source/Target Interface Type columns when present.
- `SFTP Server` remains `SFTP Server`; it is not normalized to SFTP HAFT.
- `SFTP` / `SFTP HAFT` canonicalize to API `SFTP HAFT`.
- `Directory` is evidence-only for FILE/SFTP HAFT but maps to `Server Path` for the distinct SFTP Server contract.
- HIP Account never becomes FILE `Existing Account Name`.
- Grouped duplicate Excel headers retain parent context so `Transport Profile Details > Account` can be distinguished from unrelated Account columns.
- `transportProfileName` may come from Transport Profile Name / Source TP / Target TP / DEV-Transport Profile Name aliases; `LENS TP Name` is reference evidence only.
- If Document Type is absent, name/version remain blank. No fabricated `1` or `1.0`.
- If Excel contains `NAME(1.0)`, name/version are split into separate API fields; an explicit version column takes precedence.

## Blank/null-aware score

Execution readiness and completeness are separate.

A TP can be `GOOD TO GO` when all mandatory execution conditions pass while scoring below 100 because optional values are absent.

Missing values include:

- `null` / `None`
- empty string / whitespace
- `N/A`, `NA`, `NaN`, `<NA>`, `none`
- empty list/object

Numeric `0` and boolean `false` remain valid populated values.

Scoring weights:

- required populated field: weight 3
- required blank/null field: 0 credit and may block
- optional populated field: weight 1
- optional blank/null field: 0 credit

The UI/report shows populated fields, blank/null count, blank required count, blank optional count, and score basis.

## Per-customer mapping and reports

Every TP action exposes:

- workbook sheet + row
- customer/application/HIP account
- Source or Target role
- exact Excel interface value and source column
- canonical API interface
- complete TP API field matrix
- Excel source column/value for each mapping
- runtime/default/canonicalized values
- missing fields
- readiness checklist
- warnings/blockers
- evidence-only columns
- redacted final payload

Master HTML report:

`GET /api/tp/analyses/{analysisId}/report.html`

Individual TP report:

`GET /api/tp/analyses/{analysisId}/actions/{actionId}/report.html`

## UI and loading states

The application includes:

- TP Readiness Queue
- interface/role/status/search filters
- customer-by-customer payload mapping drawer
- master and individual HTML report download
- Agent/API health dashboard
- supported-interface catalog
- loading spinner/overlay for analyze, health tests, stage, preflight and LIVE execution
- selected Good-to-Go bulk actions

## Agent/API health

The Runtime & Governance page checks:

- FastAPI backend
- Dell AIA model availability
- HIP OAuth
- Source TP service
- Target TP service

The U-HAUL smoke test uses the non-mutating TP validation endpoint rather than sending unsupported OPTIONS to the Create route.

## Governed LIVE execution

Single action:

`GOOD TO GO → Stage → optional approval → Preflight → type LIVE → TP Create`

Bulk:

`Select Good TPs → Stage Selected → optional bulk approval → Preflight Selected → type LIVE ALL → parallel TP Create`

Independent requests execute concurrently with the effective worker cap:

`min(HIP_BULK_MAX_WORKERS, HIP_PARALLEL_CONFIG_WORKERS, HIP_AUTOGEN_MAX_STABLE_AGENTS)`

The supplied V130/V122 defaults cap at 4 workers.

Each item retains independent PASS/FAIL/skipped evidence. One failed TP does not erase successful independent results.

## Environment compatibility

V11 retains every environment key from the uploaded V130/V122 codebase and adds only standalone governance/bulk controls. OAuth ownership remains compatible with that codebase:

- Account API → `ACCOUNT_*`
- Partner API → `PARTNER_*`
- System API → `SYSTEM_*`
- Document Type/Map/Rule/TP/Flow/Migration → `HIP_*`
- Dell AIA → `DELL_AIA_*`

For this TP-focused app, Transport Profile execution uses the `HIP_*` OAuth/runtime settings.

Copy `.env.example` to `.env` and place the same working local values used by the V130/V122 application. Do not commit credentials.

## Manual Windows / PowerShell run

```powershell
cd "C:\path\INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V11_DELL_LIVE_IMMUTABLE_CONTRACT_FULL_E2E_FINAL"
py -3.11 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
```

Open `http://127.0.0.1:8088`.

For analysis-only testing, keep:

```text
HIP_LIVE_API_EXECUTION=false
HIP_BULK_LIVE_EXECUTION=false
```

For approved LIVE testing, the relevant contract must remain approved/live-enabled and local environment gates/host allowlist must also be enabled.

## Validation

V11 automated coverage includes all V10 coverage plus:

- all previous V9 mapping, readiness, reporting, health and governance tests
- every Source/Sender interface maps Good-to-Go with complete required evidence
- every Target/Receiver interface maps Good-to-Go with complete required evidence
- every Source interface passes Stage → Preflight → mocked LIVE TP Create
- every Target interface passes Stage → Preflight → mocked LIVE TP Create
- a seven-interface workbook passes bulk Stage → batch Preflight → parallel mocked LIVE ALL
- V130 SFTP Server Linux/Windows, Password/Key, Sender-only, Partner-only, rename/archive/cron/compression/EBCDIC conditions
- SFTP Server `Directory → Server Path` while SFTP HAFT `Directory` never becomes Subscription Folder
- supported interface catalog exposes all seven as LIVE Create capable
- value-only Stage accepts customer value changes but rejects added/removed/re-nested attributes
- interface/role/runtime selector values are contract-owned and immutable after selection
- Preflight fingerprints the actual Dell execution boundary
- LIVE reconstructs the outgoing JSON from the canonical interface schema before the real HTTP call
- URL/method/schema/selector drift after Preflight is blocked
- PROD requires V130 confirmation and change ticket
- LIVE-readiness and staged LIVE-plan diagnostics are non-mutating

When the configured LIVE gates are enabled, production code makes a real `requests.request(...)` call to the resolved Dell HIP endpoint. No authenticated Dell HIP Create mutation is performed by automated release tests; external HTTP is mocked only at the final network boundary.

See `UPGRADE_V10_ALL_TP_INTERFACES.md`, `UPGRADE_V11_DELL_LIVE_IMMUTABLE_CONTRACT.md`, and `V11_FINAL_VALIDATION.md`.
