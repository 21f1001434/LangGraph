# V10 — All Transport Profile Interfaces + V130 SFTP Server

## Scope

V10 expands the standalone multi-account Excel → TP application so every supported TP interface can use the same readiness, HTML-report, Stage, Preflight and LIVE/parallel execution workflow.

## Supported interfaces

1. SFTP HAFT
2. SFTP Server — V130 conditional contract
3. FTP
4. HTTPS
5. HTTPS-AS2
6. NAS
7. Rabbit MQ

Both Source/Sender and Target/Receiver contracts are supported.

## Critical V130 correction

`SFTP Server` is a distinct interface. It is never converted to `SFTP HAFT`.

The implementation imports the V130 conditional parameter semantics into `app/sftp_server_contract.py` and integrates them through `app/tp_contracts.py`.

### SFTP Server context rules

- Dell Application supports Linux or Windows.
- Partner supports Linux only.
- Linux requires Server Port + Login Authentication Type.
- Password auth requires Username + Password.
- Key auth requires SSH Username and automatically emits fixed SSH Key `haft_aut_sftp_server_private_key`.
- Windows requires Windows Login Authentication Type = Password and Windows username/password.
- Sender-only fields: File Filtering Pattern, Post File Transfer Action, Polling Interval.
- Rename requires Rename mode.
- Linux + Move To Archive requires Archive File Path.
- Cron polling requires Cron Expression.
- Compression=True requires Compression Format GZIP/ZIP/TAR.
- Partner requires Is EBCDIC enabled?; True requires an approved Code Page.
- Inactive conditional parameters are pruned at the HTTP boundary.

### Excel aliases under SFTP Server

Only after `Interface Type = SFTP Server` locks this contract:

- SFTP Server → Server Name
- Directory → Server Path
- Port → Server Port
- authentication/user/password → matching auth parameter

These aliases do not apply to SFTP HAFT.

## All-interface LIVE workflow

Every exact interface request uses the same Create endpoint contract and governance:

`Analyze → readiness → Stage → Preflight → LIVE`

Bulk:

`Select Good → Stage Selected → Preflight Selected → LIVE ALL → parallel execution`

The application exposes `GET /api/tp/interfaces` so the UI can show interface family, Source/Target support, parameter counts and LIVE Create capability.

## Regression additions

V10 adds tests for:

- Source mapping for all seven interfaces
- Target mapping for all seven interfaces
- Source Stage/Preflight/LIVE for all seven interfaces
- Target Stage/Preflight/LIVE for all seven interfaces
- one workbook containing all seven interfaces through bulk Stage/Preflight/parallel LIVE ALL
- V130 SFTP Server conditional materialization and invalid combinations
- interface-catalog metadata

External Dell calls in automated tests are replaced only at the final requests boundary with deterministic HTTP 201 responses. The complete internal mapping, staging, schema fingerprint, preflight and executor logic still runs.
