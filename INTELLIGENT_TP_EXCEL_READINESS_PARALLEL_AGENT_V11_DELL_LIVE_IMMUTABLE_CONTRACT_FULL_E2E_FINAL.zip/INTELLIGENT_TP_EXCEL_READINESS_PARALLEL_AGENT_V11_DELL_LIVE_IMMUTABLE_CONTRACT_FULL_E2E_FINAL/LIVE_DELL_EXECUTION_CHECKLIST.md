# Dell LIVE Transport Profile Execution Checklist — V11

Use this checklist before the first real Dell HIP TP Create call.

## 1. Environment

Copy the same working values from the V130/V122 environment into `.env`.

At minimum for TP Create:

```text
HIP_CONFIG_SERVICE_BASE_URL=<approved Dell HIP config-service base>
HIP_TOKEN_URL=<working HIP OAuth token URL>
HIP_CLIENT_ID=<client id>
HIP_CLIENT_SECRET=<client secret>
HIP_SCOPE=<scope if required>
HIP_REQUESTED_BY=<approved requester>
HIP_USER_ID=<user if required>
HIP_ENVIRONMENT=DEV|SIT|PROD
HIP_VERIFY_SSL=true
HIP_CA_BUNDLE=<corporate CA bundle if required>
HTTP_TIMEOUT_SECONDS=90
HTTP_RETRY_ATTEMPTS=3
ALLOWED_API_HOSTS=<approved Dell host>
HIP_LIVE_API_EXECUTION=true
HIP_STRICT_LIVE_PIPELINE=true
HIP_BULK_LIVE_EXECUTION=true   # only when bulk LIVE is approved
```

For PROD also set:

```text
PRODUCTION_EXECUTION_CONFIRMATION=YES
CHANGE_TICKET=<approved change ticket>
```

## 2. Start

```powershell
.\.venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
```

## 3. Non-mutating runtime verification

Open/verify:

- `GET /api/health`
- `POST /api/runtime/deep-health`
- `POST /api/runtime/uhal-tp-smoke`
- `GET /api/runtime/live-readiness`

The U-HAUL smoke test uses the validation route, not TP Create.

## 4. Excel analysis

Upload the TP workbook. Interface Type must be explicit in Excel. The selected interface determines the immutable attribute schema.

Review each customer/TP:

- selected interface
- Source/Target role
- exact Excel → API value provenance
- blank/null completeness score
- required and conditional fields
- final redacted payload

## 5. Stage

Stage only a `GOOD TO GO` TP. V11 rejects:

- added attributes
- removed attributes
- renamed attributes
- changed nesting
- changed array/list cardinality
- changed interface selector
- changed role selector
- changed operation/runtime selector

Approved customer leaf values may change.

## 6. Preflight

Preflight must report:

```text
passed = true
executionReady = true
attributeMutationBlocked = true
schemaSha256 == canonicalSchemaSha256
hostAllowed = true
contractApproved = true
contractAllowsLive = true
liveEnabled = true
```

If `passed=true` but `executionReady=false`, the payload is valid but an environment/runtime LIVE gate is still closed.

## 7. Inspect exact LIVE plan

Call:

`GET /api/stages/{stage_id}/live-plan`

Review method, resolved URL, interface, attribute manifest, locked value paths, schema fingerprints and execution-plan fingerprint. This endpoint is non-mutating.

## 8. Execute

Single TP: type exactly `LIVE`.

Bulk selected TPs: type exactly `LIVE ALL` after batch preflight. Bulk execution still validates each Stage independently and uses the configured safe worker cap.

At the final HTTP boundary V11 reconstructs the outgoing request from the immutable selected-interface canonical schema plus the staged values, then sends it with `requests.request(...)` to the resolved Dell HIP endpoint.

## 9. Evidence

Verify Execution History / audit evidence for:

- exact TP/customer
- Excel sheet/row
- interface
- resolved endpoint
- HTTP status
- elapsed time/retries
- payload/schema/execution-plan fingerprints
- redacted request/response

Secrets are not stored in clear text in execution evidence.
