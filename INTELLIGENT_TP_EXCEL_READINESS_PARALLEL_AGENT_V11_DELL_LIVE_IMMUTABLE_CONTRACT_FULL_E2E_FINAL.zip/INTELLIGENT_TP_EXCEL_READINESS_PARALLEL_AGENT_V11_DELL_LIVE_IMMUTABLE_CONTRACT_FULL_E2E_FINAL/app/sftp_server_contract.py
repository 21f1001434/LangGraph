from __future__ import annotations

"""Dev-supplied SFTP Server Transport Profile interface contract (2026-09-14).

This is deliberately separate from the historical ``SFTP HAFT`` FILE family.
The developer supplied an exact ``interfaceType = SFTP Server`` parameter model
with context-sensitive fields.  The helpers in this module centralise those
rules so Builder/Studio, preview, Migration and LIVE materialisation all use the
same semantics.
"""

from typing import Any, Dict, Iterable, List

SFTP_SERVER_INTERFACE_TYPE = "SFTP Server"
SFTP_SERVER_FAMILY = "SFTP_SERVER"
SFTP_SERVER_SSH_KEY = "haft_aut_sftp_server_private_key"

SERVER_TYPES_DELL = ("Linux", "Windows")
SERVER_TYPES_PARTNER = ("Linux",)
LOGIN_AUTH_TYPES = ("Password", "Key")
WINDOWS_LOGIN_AUTH_TYPES = ("Password",)
POST_FILE_TRANSFER_ACTIONS = ("Delete", "Move To Archive", "Rename")
RENAME_VALUES = ("Timestamp (yyyyddMMhhmmss)", "Random Text")
POLLING_INTERVALS = (
    "Every 5 Minutes",
    "Every 15 Minutes",
    "Every 30 Minutes",
    "Every Hour",
    "Every 12 Hours",
    "Every Day",
    "Cron Expression",
)
BOOL_TEXT_VALUES = ("True", "False")
COMPRESSION_FORMATS = ("GZIP", "ZIP", "TAR")

# Exact list shown in the Dev-team SFTP Server guidance screenshot.
CODE_PAGES = (
    "Cp037", "Cp1140", "Cp273", "Cp1141", "Cp277", "Cp1142", "Cp278", "Cp1143",
    "Cp280", "Cp1144", "Cp284", "Cp1145", "Cp285", "Cp1146", "Cp297", "Cp1147",
    "Cp500", "Cp1148", "Cp871", "Cp1149", "Cp1026", "Cp1047", "Cp290", "Cp420",
    "Cp424", "Cp838", "Cp856", "Cp875", "Cp918", "Cp921", "Cp922", "Cp930",
    "Cp933", "Cp935", "Cp937", "Cp939", "Cp860", "Cp861", "Cp863", "Cp864",
    "Cp865", "Cp868", "Cp869", "Cp870", "Cp1006", "Cp1025", "Cp1046", "Cp1097",
    "Cp1098", "Cp1112", "Cp1122", "Cp1123", "Cp1124", "Cp1129", "Cp1166", "Cp1364",
    "Cp1381", "Cp1383", "Cp300", "Cp33722", "Cp833", "Cp834", "Cp942", "Cp942C",
    "Cp943", "Cp943C", "Cp948", "Cp949", "Cp949C", "Cp950", "Cp964", "Cp970",
)

# Superset of every Dev-approved SFTP Server parameter.  The LIVE payload uses
# only the applicable subset after the conditional rules below are evaluated.
PARAMETER_KEYS = (
    "Server Type",
    "Server Name",
    "Server Path",
    "File Filtering Pattern",
    "Post File Transfer Action",
    "Polling Interval",
    "Are Input Files Compressed?",
    "SPA URL",
    "Api Name",
    "Server Port",
    "Login Authentication Type",
    "Username",
    "Password",
    "SSH Username",
    "SSH Key",
    "Windows Login Authentication Type",
    "Windows Username",
    "Windows Password",
    "Rename",
    "Archive File Path",
    "Cron Expression",
    "Compression Format",
    "Is EBCDIC enabled?",
    "Code Page",
)

SENSITIVE_FIELDS = ("Password", "Windows Password")


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _canonical_enum(field: str, value: Any, allowed: Iterable[str], *, allow_blank: bool = True) -> str:
    raw = _clean(value)
    if not raw and allow_blank:
        return ""
    mapping = {str(item).strip().lower(): str(item) for item in allowed}
    canonical = mapping.get(raw.lower())
    if canonical is None:
        raise ValueError(
            f"INVALID_INTERFACE_VALUE: {field}={raw!r}; allowed values are {', '.join(mapping.values())}."
        )
    return canonical


def _canonical_bool(field: str, value: Any) -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, bool):
        return "True" if value else "False"
    raw = _clean(value).lower()
    aliases = {
        "true": "True", "yes": "True", "1": "True", "y": "True",
        "false": "False", "no": "False", "0": "False", "n": "False",
    }
    if raw in aliases:
        return aliases[raw]
    return _canonical_enum(field, value, BOOL_TEXT_VALUES)


def is_partner(system_type: Any) -> bool:
    return _clean(system_type).lower() == "partner"


def is_dell_application(system_type: Any) -> bool:
    return _clean(system_type).lower() in {"dell application", "dell", "application"}


def is_sender(profile_usage: Any) -> bool:
    return _clean(profile_usage).lower() in {"sender", "source"}


def materialize_sftp_server_parameters(
    supplied: Dict[str, Any] | None,
    *,
    system_type: Any,
    profile_usage: Any,
    include_missing_common: bool = True,
) -> Dict[str, Any]:
    """Return the exact context-applicable SFTP Server parameter subset.

    ``include_missing_common=True`` is used by generated requests so required
    common fields remain visible as blank/HITL values rather than disappearing.
    The canonical payload lock uses ``False`` when it only needs to prune a
    human edit without manufacturing absent optional keys.
    """

    supplied = dict(supplied or {})

    # Accept a harmless capitalisation alias but emit the Dev-approved key.
    if "API Name" in supplied and "Api Name" not in supplied:
        supplied["Api Name"] = supplied.get("API Name")

    partner = is_partner(system_type)
    sender = is_sender(profile_usage)

    def present(key: str) -> bool:
        return key in supplied

    def add(out: Dict[str, Any], key: str, value: Any, *, common: bool = False) -> None:
        if common and include_missing_common:
            out[key] = "" if value is None else value
        elif present(key) or value not in (None, ""):
            out[key] = value

    server_type = _canonical_enum(
        "Server Type",
        supplied.get("Server Type"),
        SERVER_TYPES_DELL,
    )
    if partner and server_type == "Windows":
        raise ValueError("INVALID_INTERFACE_VALUE: Partner SFTP Server supports Server Type=Linux only.")

    compressed = _canonical_bool("Are Input Files Compressed?", supplied.get("Are Input Files Compressed?"))

    out: Dict[str, Any] = {}
    add(out, "Server Type", server_type, common=True)
    add(out, "Server Name", supplied.get("Server Name", ""), common=True)
    add(out, "Server Path", supplied.get("Server Path", ""), common=True)

    if sender:
        add(out, "File Filtering Pattern", supplied.get("File Filtering Pattern", ""), common=True)
        post_action = _canonical_enum(
            "Post File Transfer Action", supplied.get("Post File Transfer Action"), POST_FILE_TRANSFER_ACTIONS
        )
        polling = _canonical_enum("Polling Interval", supplied.get("Polling Interval"), POLLING_INTERVALS)
        add(out, "Post File Transfer Action", post_action, common=True)
        add(out, "Polling Interval", polling, common=True)
    else:
        post_action = ""
        polling = ""

    add(out, "Are Input Files Compressed?", compressed, common=True)
    # The Dev example explicitly includes both optional fields even when blank.
    add(out, "SPA URL", supplied.get("SPA URL", ""), common=True)
    add(out, "Api Name", supplied.get("Api Name", ""), common=True)

    if server_type == "Linux":
        add(out, "Server Port", supplied.get("Server Port", ""), common=True)
        login_auth = _canonical_enum(
            "Login Authentication Type", supplied.get("Login Authentication Type"), LOGIN_AUTH_TYPES
        )
        add(out, "Login Authentication Type", login_auth, common=True)
        if login_auth == "Password":
            add(out, "Username", supplied.get("Username", ""), common=True)
            add(out, "Password", supplied.get("Password", ""), common=True)
        elif login_auth == "Key":
            add(out, "SSH Username", supplied.get("SSH Username", ""), common=True)
            supplied_key = _clean(supplied.get("SSH Key"))
            if supplied_key and supplied_key != SFTP_SERVER_SSH_KEY:
                raise ValueError(
                    "INVALID_INTERFACE_VALUE: SSH Key must be the Dev-approved constant "
                    f"{SFTP_SERVER_SSH_KEY!r}."
                )
            # Dev instruction: always send this exact key when Key auth is used.
            out["SSH Key"] = SFTP_SERVER_SSH_KEY
    elif server_type == "Windows":
        windows_auth = _canonical_enum(
            "Windows Login Authentication Type",
            supplied.get("Windows Login Authentication Type"),
            WINDOWS_LOGIN_AUTH_TYPES,
        )
        add(out, "Windows Login Authentication Type", windows_auth, common=True)
        if windows_auth == "Password":
            add(out, "Windows Username", supplied.get("Windows Username", ""), common=True)
            add(out, "Windows Password", supplied.get("Windows Password", ""), common=True)

    if sender:
        if post_action == "Rename":
            rename_value = _canonical_enum("Rename", supplied.get("Rename"), RENAME_VALUES)
            add(out, "Rename", rename_value, common=True)
        elif post_action == "Move To Archive" and server_type == "Linux":
            add(out, "Archive File Path", supplied.get("Archive File Path", ""), common=True)

        if polling == "Cron Expression":
            add(out, "Cron Expression", supplied.get("Cron Expression", ""), common=True)

    if compressed == "True":
        compression = _canonical_enum("Compression Format", supplied.get("Compression Format"), COMPRESSION_FORMATS)
        add(out, "Compression Format", compression, common=True)

    if partner:
        ebcdic = _canonical_bool("Is EBCDIC enabled?", supplied.get("Is EBCDIC enabled?"))
        add(out, "Is EBCDIC enabled?", ebcdic, common=True)
        if ebcdic == "True":
            code_page = _canonical_enum("Code Page", supplied.get("Code Page"), CODE_PAGES)
            add(out, "Code Page", code_page, common=True)

    # Keep output order locked to PARAMETER_KEYS regardless of input dict order.
    return {key: out[key] for key in PARAMETER_KEYS if key in out}


def missing_sftp_server_values(
    params: Dict[str, Any] | None,
    *,
    system_type: Any,
    profile_usage: Any,
) -> List[str]:
    """Return only values that are conditionally required for this TP context."""
    params = dict(params or {})
    missing: List[str] = []

    def require(field: str) -> None:
        if _clean(params.get(field)) == "" and field not in missing:
            missing.append(field)

    require("Server Type")
    require("Server Name")
    require("Server Path")
    require("Are Input Files Compressed?")

    server_type = _clean(params.get("Server Type"))
    if server_type.lower() == "linux":
        require("Server Port")
        require("Login Authentication Type")
        auth = _clean(params.get("Login Authentication Type")).lower()
        if auth == "password":
            require("Username")
            require("Password")
        elif auth == "key":
            require("SSH Username")
            # SSH Key is deterministic and injected by the materializer.
    elif server_type.lower() == "windows":
        require("Windows Login Authentication Type")
        if _clean(params.get("Windows Login Authentication Type")).lower() == "password":
            require("Windows Username")
            require("Windows Password")

    if is_sender(profile_usage):
        require("File Filtering Pattern")
        require("Post File Transfer Action")
        require("Polling Interval")
        action = _clean(params.get("Post File Transfer Action")).lower()
        if action == "rename":
            require("Rename")
        elif action == "move to archive" and server_type.lower() == "linux":
            require("Archive File Path")
        if _clean(params.get("Polling Interval")).lower() == "cron expression":
            require("Cron Expression")

    if _clean(params.get("Are Input Files Compressed?")).lower() == "true":
        require("Compression Format")

    if is_partner(system_type):
        require("Is EBCDIC enabled?")
        if _clean(params.get("Is EBCDIC enabled?")).lower() == "true":
            require("Code Page")

    return missing


def parameter_allowed_values() -> Dict[str, List[str]]:
    """Metadata for UI controls and contract documentation."""
    return {
        "Server Type": list(SERVER_TYPES_DELL),
        "Login Authentication Type": list(LOGIN_AUTH_TYPES),
        "Windows Login Authentication Type": list(WINDOWS_LOGIN_AUTH_TYPES),
        "Post File Transfer Action": list(POST_FILE_TRANSFER_ACTIONS),
        "Rename": list(RENAME_VALUES),
        "Polling Interval": list(POLLING_INTERVALS),
        "Are Input Files Compressed?": list(BOOL_TEXT_VALUES),
        "Compression Format": list(COMPRESSION_FORMATS),
        "Is EBCDIC enabled?": list(BOOL_TEXT_VALUES),
        "Code Page": list(CODE_PAGES),
    }
