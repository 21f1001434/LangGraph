from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List, Mapping, Tuple
import os

from .catalog import normalize_contract
from .sftp_server_contract import (
    PARAMETER_KEYS as SFTP_SERVER_PARAMETER_KEYS,
    SENSITIVE_FIELDS as SFTP_SERVER_SENSITIVE_FIELDS,
    SFTP_SERVER_SSH_KEY,
    SERVER_TYPES_DELL,
    SERVER_TYPES_PARTNER,
    LOGIN_AUTH_TYPES,
    WINDOWS_LOGIN_AUTH_TYPES,
    POST_FILE_TRANSFER_ACTIONS,
    RENAME_VALUES,
    POLLING_INTERVALS as SFTP_SERVER_POLLING_INTERVALS,
    BOOL_TEXT_VALUES,
    COMPRESSION_FORMATS as SFTP_SERVER_COMPRESSION_FORMATS,
    CODE_PAGES as SFTP_SERVER_CODE_PAGES,
    materialize_sftp_server_parameters,
)

PARAM_PREFIX = "transportProfileDetails.0.interfaceDetails.0.parameters."
DOC_NAME_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
DOC_VERSION_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"

# Dev-approved Transport Profile interface contracts currently supported by the
# standalone Excel -> TP execution application.  The V130 package supplied by
# the user is the source of truth for SFTP Server.  Historical V122 contracts
# remain authoritative for the other built-ins.
INTERFACE_FAMILIES: Dict[str, Dict[str, Any]] = {
    "FILE": {
        "display": "SFTP HAFT / FTP",
        "types": {"SFTP", "SFTP HAFT", "SFTP-HAFT", "FTP"},
        "source_keys": ["Interface Environment", "File Filtering Pattern", "Post Transfer Action", "Is Compression Required", "Use Existing Folder", "Existing Account", "Subscription Folder", "Existing Account Name"],
        "target_keys": ["Interface Environment", "File Filtering Pattern", "Post Transfer Action", "Is Compression Required", "Use Existing Folder", "Existing Account", "Subscription Folder", "Existing Account Name"],
        "source_required": ["Existing Account Name"],
        "target_required": ["Existing Account Name"],
        "source_defaults": {"Interface Environment":"UAT", "File Filtering Pattern":".*\\*.", "Post Transfer Action":"Move To Archive", "Is Compression Required":"FALSE", "Use Existing Folder":"No", "Existing Account":"Yes", "Subscription Folder":"", "Existing Account Name":""},
        "target_defaults": {"Interface Environment":"UAT", "File Filtering Pattern":".*\\*.", "Post Transfer Action":"Move To Archive", "Is Compression Required":"FALSE", "Use Existing Folder":"No", "Existing Account":"Yes", "Subscription Folder":"", "Existing Account Name":""},
        "allowed": {}, "sensitive": [],
        "reference": "V122 FILE/SFTP HAFT/FTP developer-approved interface schema",
    },
    "SFTP_SERVER": {
        "display": "SFTP Server",
        "types": {"SFTP SERVER", "SFTP-SERVER"},
        "source_keys": list(SFTP_SERVER_PARAMETER_KEYS),
        "target_keys": list(SFTP_SERVER_PARAMETER_KEYS),
        # Common requirements. Conditional requirements are added after the
        # workbook values have selected Linux/Windows/auth/action/polling/etc.
        "source_required": ["Server Type", "Server Name", "Server Path", "Are Input Files Compressed?"],
        "target_required": ["Server Type", "Server Name", "Server Path", "Are Input Files Compressed?"],
        "source_defaults": {}, "target_defaults": {},
        "source_allowed": {
            "Server Type": list(SERVER_TYPES_DELL),
            "Login Authentication Type": list(LOGIN_AUTH_TYPES),
            "Windows Login Authentication Type": list(WINDOWS_LOGIN_AUTH_TYPES),
            "Post File Transfer Action": list(POST_FILE_TRANSFER_ACTIONS),
            "Rename": list(RENAME_VALUES),
            "Polling Interval": list(SFTP_SERVER_POLLING_INTERVALS),
            "Are Input Files Compressed?": list(BOOL_TEXT_VALUES),
            "Compression Format": list(SFTP_SERVER_COMPRESSION_FORMATS),
            "SSH Key": [SFTP_SERVER_SSH_KEY],
        },
        "target_allowed": {
            "Server Type": list(SERVER_TYPES_PARTNER),
            "Login Authentication Type": list(LOGIN_AUTH_TYPES),
            "Windows Login Authentication Type": list(WINDOWS_LOGIN_AUTH_TYPES),
            "Are Input Files Compressed?": list(BOOL_TEXT_VALUES),
            "Compression Format": list(SFTP_SERVER_COMPRESSION_FORMATS),
            "Is EBCDIC enabled?": list(BOOL_TEXT_VALUES),
            "Code Page": list(SFTP_SERVER_CODE_PAGES),
            "SSH Key": [SFTP_SERVER_SSH_KEY],
        },
        "sensitive": list(SFTP_SERVER_SENSITIVE_FIELDS),
        "reference": "V130 Dev-team SFTP Server conditional interfaceDetails contract supplied 2026-09-14",
    },
    "HTTPS": {
        "display": "HTTPS / REST",
        "types": {"HTTPS", "REST", "HTTPS REST"},
        "source_keys": ["Protocol", "HIP URL", "Proxy URI", "Request Method", "Request Format", "Sender Authentication Type", "Are Input Files Compressed?", "Sender Grant Type"],
        "target_keys": ["Protocol", "Partner URL", "Request Method", "Request Format", "Receiver Authentication Type", "Gateway URL", "Are Input Files Compressed?", "Receiver Grant Type", "Receiver Token Endpoint", "Receiver Client Id", "Receiver Client Secret"],
        "source_required": [],
        "target_required": ["Partner URL", "Receiver Grant Type", "Receiver Token Endpoint", "Receiver Client Id", "Receiver Client Secret"],
        "source_defaults": {"Protocol":"REST", "HIP URL":"URL will be shared later after API Publish is successful.", "Proxy URI":"dce-common-sv1", "Request Method":"POST", "Request Format":"Request Body", "Sender Authentication Type":"OAuth2", "Are Input Files Compressed?":"False", "Sender Grant Type":"client_credentials"},
        "target_defaults": {"Protocol":"REST", "Partner URL":"", "Request Method":"POST", "Request Format":"Request Body", "Receiver Authentication Type":"OAuth2", "Gateway URL":"URL will be shared later after API Publish is successful.", "Are Input Files Compressed?":"False", "Receiver Grant Type":"", "Receiver Token Endpoint":"", "Receiver Client Id":"", "Receiver Client Secret":""},
        "allowed": {}, "sensitive": ["Receiver Client Secret"],
        "reference": "V122 HTTPS sender/receiver OAuth/URL/request developer-approved interface schema",
    },
    "HTTPS_AS2": {
        "display": "HTTPS-AS2",
        "types": {"HTTPS-AS2", "AS2", "HTTPS AS2"},
        "source_keys": ["Interface Environment", "Request Method", "Partner Identifier", "Dell Identifier", "Partner Verification Certificate", "Are SSL and Partner Verification Certificates identical?", "AS2 URL", "Are Input Files Compressed?", "Is EBCDIC enabled?", "SSL Certificate", "Compression Format"],
        "target_keys": ["Interface Environment", "Request Method", "Partner URL", "Partner Identifier", "Dell Identifier", "Signing Algorithm", "Encryption Algorithm", "Encryption Certificate", "SSL Certificate", "Enable AS2 Message Compression", "Asynchronous MDN Required", "Are Input Files Compressed?", "Is EBCDIC enabled?", "Compression Format"],
        "source_required": ["Interface Environment", "Request Method", "Partner Identifier", "Dell Identifier", "Partner Verification Certificate", "Are SSL and Partner Verification Certificates identical?", "AS2 URL", "Are Input Files Compressed?", "Is EBCDIC enabled?"],
        "target_required": ["Interface Environment", "Request Method", "Partner URL", "Partner Identifier", "Dell Identifier", "Signing Algorithm", "Encryption Algorithm", "Encryption Certificate", "SSL Certificate", "Enable AS2 Message Compression", "Asynchronous MDN Required", "Are Input Files Compressed?", "Is EBCDIC enabled?"],
        "source_defaults": {"Interface Environment":"UAT", "Request Method":"POST", "Partner Identifier":"", "Dell Identifier":"", "Partner Verification Certificate":"", "Are SSL and Partner Verification Certificates identical?":"No", "AS2 URL":"", "Are Input Files Compressed?":"False", "Is EBCDIC enabled?":"False", "SSL Certificate":"", "Compression Format":""},
        # V9/V10 intentionally require the receiver SSL certificate as evidence;
        # do not reuse the V130 sample certificate as a customer default.
        "target_defaults": {"Interface Environment":"UAT", "Request Method":"POST", "Partner URL":"", "Partner Identifier":"", "Dell Identifier":"", "Signing Algorithm":"", "Encryption Algorithm":"", "Encryption Certificate":"", "SSL Certificate":"", "Enable AS2 Message Compression":"False", "Asynchronous MDN Required":"False", "Are Input Files Compressed?":"False", "Is EBCDIC enabled?":"False", "Compression Format":""},
        "allowed": {
            "Signing Algorithm":["SHA1","SHA256","SHA512"], "Encryption Algorithm":["AES128","AES256"],
            "Are SSL and Partner Verification Certificates identical?":["Yes","No"], "Enable AS2 Message Compression":["True","False"],
            "Asynchronous MDN Required":["True","False"], "Are Input Files Compressed?":["True","False"], "Is EBCDIC enabled?":["True","False"],
            "Compression Format":["GZIP","ZIP","TAR"],
        },
        "sensitive": [],
        "reference": "V120/V121 HTTPS-AS2 Dev-approved Sender/Receiver interface schema; receiver SSL Certificate required",
    },
    "NAS": {
        "display": "NAS",
        "types": {"NAS"},
        "source_keys": ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS", "Cron Expression"],
        "target_keys": ["Protocol", "Server Name", "Server Path", "AD Group"],
        "source_required": ["Protocol", "Server Name", "Server Path", "AD Group", "File Filtering Pattern", "Polling Interval", "Post File Transfer Action NAS"],
        "target_required": ["Protocol", "Server Name", "Server Path", "AD Group"],
        "source_defaults": {}, "target_defaults": {},
        "allowed": {"Protocol":["NFS","SMB","Multi Protocol"], "Post File Transfer Action NAS":["Delete","Move To Archive","Rename"], "Polling Interval":["Every 5 Minutes","Every 15 Minutes","Every 30 Minutes","Every Hour","Every 12 Hours","Every Day","Cron Expression"]},
        "sensitive": [],
        "reference": "V122 additive NAS Dev-team interface schema (2026-09-07)",
    },
    "RABBIT_MQ": {
        "display": "Rabbit MQ",
        "types": {"RABBIT MQ", "RABBITMQ", "RABBIT-MQ"},
        "source_keys": ["Interface Environment", "Exchange Name"], "target_keys": ["Interface Environment", "Exchange Name"],
        "source_required": ["Interface Environment", "Exchange Name"], "target_required": ["Interface Environment", "Exchange Name"],
        "source_defaults": {}, "target_defaults": {},
        "allowed": {"Interface Environment":["DEV","TEST","PERF"]}, "sensitive": [],
        "reference": "V122 additive Rabbit MQ Dev-team interface schema (2026-09-07)",
    },
}

ROLE_ALIASES = {
    "source": {
        "source system": "systemName", "system": "systemName",
        "source interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "source transport profile name": "transportProfileDetails.0.transportProfileName",
        "source tp name": "transportProfileDetails.0.transportProfileName",
        "dev transport profile name": "transportProfileDetails.0.transportProfileName",
        "transport profile name": "transportProfileDetails.0.transportProfileName", "tp name": "transportProfileDetails.0.transportProfileName",
        "document type name": DOC_NAME_PATH, "document type": DOC_NAME_PATH, "document type version": DOC_VERSION_PATH,
    },
    "target": {
        "target system": "systemName", "system": "systemName",
        "target interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "interface type": "transportProfileDetails.0.interfaceDetails.0.interfaceType",
        "target transport profile name": "transportProfileDetails.0.transportProfileName",
        "target tp name": "transportProfileDetails.0.transportProfileName",
        "dev transport profile name": "transportProfileDetails.0.transportProfileName",
        "transport profile name": "transportProfileDetails.0.transportProfileName", "tp name": "transportProfileDetails.0.transportProfileName",
        "document type name": DOC_NAME_PATH, "document type": DOC_NAME_PATH, "document type version": DOC_VERSION_PATH,
    },
}

# Only the value in the authoritative Excel Interface Type cell may select a
# family.  These entries canonicalize that explicit value; they are not clues
# from other workbook columns.
INTERFACE_VALUE_ALIASES = {
    "SFTP": ("FILE", "SFTP HAFT"),
    "SFTP HAFT": ("FILE", "SFTP HAFT"),
    "SFTP-HAFT": ("FILE", "SFTP HAFT"),
    # V130 correction: SFTP Server is a distinct API interface, NOT SFTP HAFT.
    "SFTP SERVER": ("SFTP_SERVER", "SFTP Server"),
    "SFTP-SERVER": ("SFTP_SERVER", "SFTP Server"),
    "SFTP HAFT SERVER": ("FILE", "SFTP HAFT"),
    "SFTP-HAFT SERVER": ("FILE", "SFTP HAFT"),
    "FTP": ("FILE", "FTP"), "FTP SERVER": ("FILE", "FTP"),
    "HTTPS": ("HTTPS", "HTTPS"), "HTTPS SERVER": ("HTTPS", "HTTPS"), "REST": ("HTTPS", "HTTPS"), "REST API": ("HTTPS", "HTTPS"), "HTTPS REST": ("HTTPS", "HTTPS"), "HTTPS REST API": ("HTTPS", "HTTPS"),
    "AS2": ("HTTPS_AS2", "HTTPS-AS2"), "AS2 SERVER": ("HTTPS_AS2", "HTTPS-AS2"), "HTTPS-AS2": ("HTTPS_AS2", "HTTPS-AS2"), "HTTPS AS2": ("HTTPS_AS2", "HTTPS-AS2"), "HTTPS AS2 SERVER": ("HTTPS_AS2", "HTTPS-AS2"),
    "NAS": ("NAS", "NAS"), "NAS SERVER": ("NAS", "NAS"),
    "RABBIT MQ": ("RABBIT_MQ", "Rabbit MQ"), "RABBITMQ": ("RABBIT_MQ", "Rabbit MQ"), "RABBIT-MQ": ("RABBIT_MQ", "Rabbit MQ"), "RABBIT MQ SERVER": ("RABBIT_MQ", "Rabbit MQ"),
}

PARAMETER_ALIASES = {
    "subscription folder": "Subscription Folder", "tp subscription folder": "Subscription Folder", "transport profile subscription folder": "Subscription Folder",
    "existing account name": "Existing Account Name", "tp existing account name": "Existing Account Name", "transport profile account": "Existing Account Name", "tp account": "Existing Account Name",
    "interface environment": "Interface Environment", "exchange name": "Exchange Name", "server name": "Server Name", "server path": "Server Path",
    "ad group": "AD Group", "partner url": "Partner URL", "as2 url": "AS2 URL", "ssl certificate": "SSL Certificate",
    "encryption certificate": "Encryption Certificate", "signing algorithm": "Signing Algorithm", "encryption algorithm": "Encryption Algorithm",
    "partner identifier": "Partner Identifier", "dell identifier": "Dell Identifier", "request method": "Request Method",
}

# Exact Excel aliases that are safe only when SFTP Server is already locked by
# the authoritative Interface Type cell.  This allows the existing SFTP workbook
# columns to feed the new V130 parameters without permitting cross-family guesses.
SFTP_SERVER_EXCEL_ALIASES = {
    "sftp server": "Server Name",
    "sftp server name": "Server Name",
    "host": "Server Name",
    "host name": "Server Name",
    "hostname": "Server Name",
    "directory": "Server Path",
    "sftp directory": "Server Path",
    "path": "Server Path",
    "sftp path": "Server Path",
    "port": "Server Port",
    "sftp port": "Server Port",
    "authentication": "Login Authentication Type",
    "authentication type": "Login Authentication Type",
    "sftp authentication": "Login Authentication Type",
    "login authentication": "Login Authentication Type",
    "user name": "Username",
    "sftp username": "Username",
    "sftp user": "Username",
    "sftp password": "Password",
    "ssh user": "SSH Username",
    "ssh username": "SSH Username",
    "file filter": "File Filtering Pattern",
    "file filtering pattern": "File Filtering Pattern",
    "post file transfer action": "Post File Transfer Action",
    "polling interval": "Polling Interval",
    "cron": "Cron Expression",
    "cron expression": "Cron Expression",
    "compression format": "Compression Format",
    "are input files compressed": "Are Input Files Compressed?",
    "are input files compressed?": "Are Input Files Compressed?",
    "server type": "Server Type",
    "spa url": "SPA URL",
    "api name": "Api Name",
    "windows username": "Windows Username",
    "windows password": "Windows Password",
    "windows login authentication type": "Windows Login Authentication Type",
    "archive file path": "Archive File Path",
    "rename": "Rename",
    "is ebcdic enabled": "Is EBCDIC enabled?",
    "is ebcdic enabled?": "Is EBCDIC enabled?",
    "code page": "Code Page",
}


def _interface_alias_key(interface_type: Any) -> str:
    raw = str(interface_type or "").strip().upper().replace("_", " ")
    return " ".join(raw.replace("/", " ").split())


def interface_family(interface_type: Any) -> str:
    alias = INTERFACE_VALUE_ALIASES.get(_interface_alias_key(interface_type))
    return alias[0] if alias else ""


def canonical_interface_type(interface_type: Any, family: str) -> str:
    alias = INTERFACE_VALUE_ALIASES.get(_interface_alias_key(interface_type))
    return alias[1] if alias and alias[0] == family else str(interface_type or "").strip()


def interface_alias_info(interface_type: Any) -> Dict[str, str]:
    raw = _interface_alias_key(interface_type)
    alias = INTERFACE_VALUE_ALIASES.get(raw)
    if not alias:
        return {"excelValue": str(interface_type or "").strip(), "recognized": "false", "family": "", "canonical": "", "aliasKey": raw}
    return {"excelValue": str(interface_type or "").strip(), "recognized": "true", "family": alias[0], "canonical": alias[1], "aliasKey": raw}


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _bool_text(value: Any) -> str:
    raw = _clean(value).lower()
    if raw in {"true", "yes", "1", "y"}: return "True"
    if raw in {"false", "no", "0", "n"}: return "False"
    return _clean(value)


def _sftp_server_required_fields(params: Mapping[str, Any], *, role: str) -> List[str]:
    required = ["Server Type", "Server Name", "Server Path", "Are Input Files Compressed?"]
    server_type = _clean(params.get("Server Type")).lower()
    auth = _clean(params.get("Login Authentication Type")).lower()
    win_auth = _clean(params.get("Windows Login Authentication Type")).lower()
    action = _clean(params.get("Post File Transfer Action")).lower()
    polling = _clean(params.get("Polling Interval")).lower()
    compressed = _bool_text(params.get("Are Input Files Compressed?"))
    ebcdic = _bool_text(params.get("Is EBCDIC enabled?"))
    if server_type == "linux":
        required += ["Server Port", "Login Authentication Type"]
        if auth == "password": required += ["Username", "Password"]
        elif auth == "key": required += ["SSH Username", "SSH Key"]
    elif server_type == "windows":
        required += ["Windows Login Authentication Type"]
        if win_auth == "password": required += ["Windows Username", "Windows Password"]
    if role == "source":
        required += ["File Filtering Pattern", "Post File Transfer Action", "Polling Interval"]
        if action == "rename": required += ["Rename"]
        elif action == "move to archive" and server_type == "linux": required += ["Archive File Path"]
        if polling == "cron expression": required += ["Cron Expression"]
    if compressed == "True": required += ["Compression Format"]
    if role == "target":
        required += ["Is EBCDIC enabled?"]
        if ebcdic == "True": required += ["Code Page"]
    return list(dict.fromkeys(required))


def _profile_allowed(profile: Mapping[str, Any], role: str) -> Mapping[str, List[str]]:
    return profile.get(f"{role}_allowed") or profile.get("allowed") or {}


def _base_required(base: Mapping[str, Any]) -> List[str]:
    return [p for p in (base.get("required_paths") or []) if ".parameters." not in p and p not in {DOC_NAME_PATH, DOC_VERSION_PATH}]


def dynamic_tp_contract(base: Mapping[str, Any], role: str, interface_type: Any) -> Dict[str, Any]:
    role = "target" if str(role).lower().startswith("target") else "source"
    family = interface_family(interface_type)
    if not family:
        raise ValueError(f"Unsupported TP interface type {interface_type!r}; no Dev-approved interface schema is registered")
    profile = INTERFACE_FAMILIES[family]
    raw = {k: deepcopy(v) for k, v in base.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}}
    payload = deepcopy(base["canonical_request"])
    payload["requestedBy"] = str(os.getenv("HIP_REQUESTED_BY") or payload.get("requestedBy") or "").strip()
    payload["hipEnvironment"] = str(os.getenv("HIP_ENVIRONMENT") or payload.get("hipEnvironment") or "DEV").strip()
    detail = payload["transportProfileDetails"][0]
    iface = detail["interfaceDetails"][0]
    iface["interfaceType"] = canonical_interface_type(interface_type, family)
    keys = list(profile[f"{role}_keys"])
    defaults = profile.get(f"{role}_defaults") or {}
    iface["parameters"] = {key: deepcopy(defaults.get(key, "")) for key in keys}
    detail["transportProfileUsage"] = "Sender" if role == "source" else "Receiver"
    payload["systemType"] = "Dell Application" if role == "source" else "Partner"
    raw["canonical_request"] = payload
    raw["name"] = "Source TP orchestration create ONLY" if role == "source" else "Target TP orchestration create ONLY"
    raw["description"] = f"Schema-locked {role.title()} Transport Profile Create · {profile.get('display') or family}"
    raw["notes"] = list(raw.get("notes") or []) + [profile["reference"], f"Dynamic interface family: {family}"]
    required = _base_required(base) + [PARAM_PREFIX + key for key in profile.get(f"{role}_required") or []]
    raw["required_paths"] = required
    raw["identity_paths"] = ["systemName", "transportProfileDetails.0.transportProfileName"]
    # V11 Dell LIVE contract ownership: these values select/identify the exact
    # approved TP contract and therefore cannot be edited as customer data.
    # All other canonical leaves remain value-editable subject to field rules.
    raw["locked_value_paths"] = [
        "operation",
        "requestedBy",
        "hipEnvironment",
        "systemType",
        "transportProfileDetails.0.deploymentGroupName",
        "transportProfileDetails.0.transportProfileOperation",
        "transportProfileDetails.0.transportProfileUsage",
        "transportProfileDetails.0.interfaceDetails.0.interfaceRole",
        "transportProfileDetails.0.interfaceDetails.0.interfaceType",
    ]
    raw["sensitive_paths"] = list(base.get("sensitive_paths") or []) + [PARAM_PREFIX + key for key in profile.get("sensitive") or []]
    rules = deepcopy(base.get("field_rules") or {})
    for key, allowed in _profile_allowed(profile, role).items():
        if key in keys:
            rules[PARAM_PREFIX + key] = {"type":"string", "enum": list(allowed)}
    raw["field_rules"] = rules
    aliases = deepcopy(base.get("header_aliases") or {})
    aliases.update(ROLE_ALIASES[role])
    for key in keys:
        aliases.setdefault(key, PARAM_PREFIX + key)
    for header, key in PARAMETER_ALIASES.items():
        if key in keys:
            aliases[header] = PARAM_PREFIX + key
    if family == "SFTP_SERVER":
        for header, key in SFTP_SERVER_EXCEL_ALIASES.items():
            if key in keys:
                aliases[header] = PARAM_PREFIX + key
    raw["header_aliases"] = aliases
    # Dynamic interface contracts may prune sensitive leaves owned by another
    # interface/role. Keep sensitive_paths exact to this canonical request.
    from .catalog import flatten_leaves
    active_leaf_paths = {path for path, _ in flatten_leaves(payload)}
    raw["sensitive_paths"] = [p for p in raw.get("sensitive_paths", []) if p in active_leaf_paths]
    contract = normalize_contract(raw)
    contract["tp_role"] = role
    contract["interface_family"] = family
    contract["interface_reference"] = profile["reference"]
    contract["interface_display"] = profile.get("display") or family
    contract["supported_for_live"] = True
    return contract


def _as2_materialize(params: Mapping[str, Any], role: str) -> Dict[str, Any]:
    out = dict(params or {})
    if role == "source" and _clean(out.get("Are SSL and Partner Verification Certificates identical?")).lower() == "yes":
        out.pop("SSL Certificate", None)
    if _bool_text(out.get("Are Input Files Compressed?")) != "True":
        out.pop("Compression Format", None)
    return out


def finalize_tp_contract(contract: Mapping[str, Any], payload: Mapping[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """Apply interface conditionals after Excel mapping.

    Returns (exact_contract, exact_payload, conditional_findings).  For SFTP
    Server this is the V130 HTTP-boundary materializer: inactive fields are
    removed, the fixed SSH key is injected only for Key auth, and conditional
    required fields are reflected in required_paths.
    """
    out_payload = deepcopy(payload)
    family = str(contract.get("interface_family") or "")
    role = str(contract.get("tp_role") or "source")
    findings: List[Dict[str, Any]] = []
    details = out_payload.get("transportProfileDetails") or []
    if not details or not isinstance(details[0], dict):
        return normalize_contract(dict(contract)), out_payload, findings
    detail = details[0]
    interfaces = detail.get("interfaceDetails") or []
    if not interfaces or not isinstance(interfaces[0], dict):
        return normalize_contract(dict(contract)), out_payload, findings
    params = dict(interfaces[0].get("parameters") or {})

    if family == "SFTP_SERVER":
        try:
            params = materialize_sftp_server_parameters(
                params,
                system_type=out_payload.get("systemType") or ("Dell Application" if role == "source" else "Partner"),
                profile_usage=detail.get("transportProfileUsage") or ("Sender" if role == "source" else "Receiver"),
                include_missing_common=True,
            )
        except ValueError as exc:
            findings.append({"path": PARAM_PREFIX.rstrip("."), "message": str(exc), "type": "interface_condition"})
            # Keep only the approved keys; do not let an invalid row escape the
            # schema lock even though it still needs human correction.
            allowed = set(SFTP_SERVER_PARAMETER_KEYS)
            params = {k: v for k, v in params.items() if k in allowed}
        interfaces[0]["parameters"] = params
    elif family == "HTTPS_AS2":
        interfaces[0]["parameters"] = _as2_materialize(params, role)
    elif family == "NAS" and role == "source":
        protocol = _clean(params.get("Protocol"))
        action = _clean(params.get("Post File Transfer Action NAS"))
        polling = _clean(params.get("Polling Interval"))
        if protocol == "NFS" and action and action != "Delete":
            findings.append({"path": PARAM_PREFIX + "Post File Transfer Action NAS", "message": "NAS Protocol=NFS supports only Post File Transfer Action NAS=Delete.", "type":"interface_condition"})
        if polling == "Cron Expression" and not _clean(params.get("Cron Expression")):
            findings.append({"path": PARAM_PREFIX + "Cron Expression", "message": "NAS Cron Expression is required when Polling Interval=Cron Expression.", "type":"interface_condition"})

    raw = {k: deepcopy(v) for k, v in dict(contract).items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}}
    raw["canonical_request"] = deepcopy(out_payload)
    required = [p for p in (contract.get("required_paths") or []) if ".parameters." not in p]
    if family == "SFTP_SERVER":
        active_required = _sftp_server_required_fields(interfaces[0].get("parameters") or {}, role=role)
        required += [PARAM_PREFIX + key for key in active_required if key in (interfaces[0].get("parameters") or {})]
    elif family == "HTTPS_AS2":
        profile = INTERFACE_FAMILIES[family]
        active_required = list(profile.get(f"{role}_required") or [])
        if _bool_text((interfaces[0].get("parameters") or {}).get("Are Input Files Compressed?")) == "True":
            active_required.append("Compression Format")
        required += [PARAM_PREFIX + key for key in active_required if key in (interfaces[0].get("parameters") or {})]
    elif family == "NAS":
        profile = INTERFACE_FAMILIES[family]
        active_required = list(profile.get(f"{role}_required") or [])
        if role == "source" and _clean((interfaces[0].get("parameters") or {}).get("Polling Interval")) == "Cron Expression":
            active_required.append("Cron Expression")
        required += [PARAM_PREFIX + key for key in active_required if key in (interfaces[0].get("parameters") or {})]
    else:
        profile = INTERFACE_FAMILIES.get(family) or {}
        required += [PARAM_PREFIX + key for key in profile.get(f"{role}_required") or [] if key in (interfaces[0].get("parameters") or {})]
    raw["required_paths"] = list(dict.fromkeys(required))

    # Field rules must match the active parameter shape after conditional prune.
    active_keys = set((interfaces[0].get("parameters") or {}).keys())
    rules = {k: deepcopy(v) for k, v in (contract.get("field_rules") or {}).items() if ".parameters." not in str(k)}
    profile = INTERFACE_FAMILIES.get(family) or {}
    for key, allowed in _profile_allowed(profile, role).items():
        if key in active_keys:
            rules[PARAM_PREFIX + key] = {"type":"string", "enum": list(allowed)}
    raw["field_rules"] = rules
    # Conditional materialization can remove sensitive leaves (for example
    # Password when Key auth is selected, or Windows Password for Linux).
    # normalize_contract requires sensitive paths to exist in the exact canonical
    # request, so retain only active leaves at the HTTP boundary.
    from .catalog import flatten_leaves
    active_leaf_paths = {path for path, _ in flatten_leaves(out_payload)}
    raw["sensitive_paths"] = [p for p in (contract.get("sensitive_paths") or []) if p in active_leaf_paths]
    exact = normalize_contract(raw)
    exact["tp_role"] = role
    exact["interface_family"] = family
    exact["interface_reference"] = contract.get("interface_reference")
    exact["interface_display"] = contract.get("interface_display")
    exact["supported_for_live"] = True
    return exact, out_payload, findings


def validate_interface_payload(payload: Mapping[str, Any], contract: Mapping[str, Any]) -> List[Dict[str, Any]]:
    """Validate conditional cross-field rules without changing the staged value."""
    family = str(contract.get("interface_family") or "")
    role = str(contract.get("tp_role") or "source")
    findings: List[Dict[str, Any]] = []
    try:
        details = (payload.get("transportProfileDetails") or []) if isinstance(payload, Mapping) else []
        detail = details[0] if details else {}
        iface = (detail.get("interfaceDetails") or [{}])[0]
        params = dict(iface.get("parameters") or {})
    except Exception:
        return [{"path":"transportProfileDetails.0.interfaceDetails.0.parameters", "message":"Interface parameters are not structurally valid", "type":"interface_condition"}]

    if family == "SFTP_SERVER":
        try:
            materialized = materialize_sftp_server_parameters(
                params,
                system_type=payload.get("systemType") or ("Dell Application" if role == "source" else "Partner"),
                profile_usage=detail.get("transportProfileUsage") or ("Sender" if role == "source" else "Receiver"),
                include_missing_common=True,
            )
            # A user edit that changes a conditional driver (e.g. Linux->Windows)
            # must not silently change the HTTP schema after staging.
            if list(materialized.keys()) != list(params.keys()):
                findings.append({"path": PARAM_PREFIX.rstrip("."), "message":"Conditional interface field set changed after staging. Re-analyze/re-stage so inactive SFTP Server fields can be pruned safely.", "type":"interface_condition"})
            for field in _sftp_server_required_fields(materialized, role=role):
                if not _clean(materialized.get(field)):
                    findings.append({"path":PARAM_PREFIX + field, "message":f"SFTP Server {field} is required for the selected conditions.", "type":"interface_condition"})
        except ValueError as exc:
            findings.append({"path":PARAM_PREFIX.rstrip("."), "message":str(exc), "type":"interface_condition"})
    elif family == "NAS" and role == "source":
        if _clean(params.get("Protocol")) == "NFS" and _clean(params.get("Post File Transfer Action NAS")) not in {"", "Delete"}:
            findings.append({"path":PARAM_PREFIX + "Post File Transfer Action NAS", "message":"NAS Protocol=NFS supports only Post File Transfer Action NAS=Delete.", "type":"interface_condition"})
        if _clean(params.get("Polling Interval")) == "Cron Expression" and not _clean(params.get("Cron Expression")):
            findings.append({"path":PARAM_PREFIX + "Cron Expression", "message":"NAS Cron Expression is required when Polling Interval=Cron Expression.", "type":"interface_condition"})
    elif family == "HTTPS_AS2":
        if _bool_text(params.get("Are Input Files Compressed?")) == "True" and not _clean(params.get("Compression Format")):
            findings.append({"path":PARAM_PREFIX + "Compression Format", "message":"HTTPS-AS2 Compression Format is required when Are Input Files Compressed?=True.", "type":"interface_condition"})
    return findings


def interface_catalog_public() -> List[Dict[str, Any]]:
    """UI/report metadata proving which TP interfaces can use Create LIVE."""
    rows: List[Dict[str, Any]] = []
    examples = [
        ("SFTP HAFT", "FILE"), ("SFTP Server", "SFTP_SERVER"), ("FTP", "FILE"),
        ("HTTPS", "HTTPS"), ("HTTPS-AS2", "HTTPS_AS2"), ("NAS", "NAS"), ("Rabbit MQ", "RABBIT_MQ"),
    ]
    for name, family in examples:
        p = INTERFACE_FAMILIES[family]
        rows.append({
            "interfaceType": name, "family": family, "displayName": p.get("display") or name,
            "sourceSupported": True, "targetSupported": True, "liveCreateSupported": True,
            "sourceParameterCount": len(p.get("source_keys") or []), "targetParameterCount": len(p.get("target_keys") or []),
            "reference": p.get("reference"),
        })
    return rows


def superset_tp_contract(base: Mapping[str, Any], role: str) -> Dict[str, Any]:
    """LLM-only schema containing the union of every approved parameter leaf."""
    role = "target" if str(role).lower().startswith("target") else "source"
    raw = {k: deepcopy(v) for k, v in base.items() if k not in {"paths", "canonical_leaf_count", "contract_sha256"}}
    payload = deepcopy(base["canonical_request"])
    union: List[str] = []
    for profile in INTERFACE_FAMILIES.values():
        for key in profile[f"{role}_keys"]:
            if key not in union: union.append(key)
    payload["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"] = {k:"" for k in union}
    raw["canonical_request"] = payload
    raw["required_paths"] = [p for p in (base.get("required_paths") or []) if ".parameters." not in p]
    raw["sensitive_paths"] = []
    raw["field_rules"] = {}
    aliases = deepcopy(base.get("header_aliases") or {}); aliases.update(ROLE_ALIASES[role])
    for key in union: aliases.setdefault(key, PARAM_PREFIX + key)
    for header, key in PARAMETER_ALIASES.items():
        if key in union: aliases[header] = PARAM_PREFIX + key
    for header, key in SFTP_SERVER_EXCEL_ALIASES.items():
        if key in union: aliases[header] = PARAM_PREFIX + key
    raw["header_aliases"] = aliases
    return normalize_contract(raw)
