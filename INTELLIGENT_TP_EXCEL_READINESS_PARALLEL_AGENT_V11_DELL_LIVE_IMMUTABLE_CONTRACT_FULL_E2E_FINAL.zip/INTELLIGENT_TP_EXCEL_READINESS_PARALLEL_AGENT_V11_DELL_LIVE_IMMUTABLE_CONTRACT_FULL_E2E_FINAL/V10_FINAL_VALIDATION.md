# V10 Final Validation — All TP Interfaces

Validation date: 2026-09-14

Release: `INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V10_ALL_TP_INTERFACES_FULL_E2E_FINAL`

## Verdict

**PASS — release package ready for local V130/V122 credentialed validation.**

Automated tests execute the complete internal Analyze → mapping → readiness → Stage → Preflight → executor path. External Dell Create HTTP calls are mocked only at the final network boundary; no authenticated HIP TP Create mutation was performed during release validation.

## Automated regression

`python -m pytest -q`

**95 passed**

Coverage includes:

- V9 blank/null completeness scoring and all previous V8/V7/V6/V5 behavior
- Source/Sender mapping for every built-in TP interface
- Target/Receiver mapping for every built-in TP interface
- Source Stage → Preflight → mocked LIVE Create for every interface
- Target Stage → Preflight → mocked LIVE Create for every interface
- seven-interface multi-row workbook → bulk Stage → batch Preflight → parallel mocked `LIVE ALL`
- SFTP Server Linux/Windows conditional shapes
- SFTP Server Password/Key authentication and fixed SSH key
- Sender-only post-transfer/polling/filter fields
- Partner-only EBCDIC/code-page rules
- rename/archive/cron/compression conditional requirements
- distinct SFTP Server vs SFTP HAFT behavior
- HTML/UI/reporting/governance/readiness regressions

## Supported TP interfaces

`GET /api/tp/interfaces` returned HTTP 200 with **7** interfaces and `liveCreateSupported=true` for all:

1. SFTP HAFT
2. SFTP Server
3. FTP
4. HTTPS
5. HTTPS-AS2
6. NAS
7. Rabbit MQ

Both Source and Target are exposed as supported for each built-in contract.

## V130 SFTP Server source-of-truth check

`app/sftp_server_contract.py` is byte-for-byte identical to the uploaded V130 R1 reference module.

SHA-256 for both copies:

`c901b38bd0e226d93f5baa05316fdd5e38e8a1a632fbfb6559c07d7b16215f60`

The integration layer keeps `SFTP Server` as a distinct interface family and never canonicalizes it to SFTP HAFT.

## Environment parity

Uploaded V130 `.env.example`:

- 72 configured entries
- 71 unique keys

V10 `.env.example`:

- 82 configured entries
- 81 unique keys
- **0 V130 keys missing**

The additional V10 keys are standalone governance/bulk controls; existing V130/V122 keys are retained.

## Build/static checks

- `python -m compileall -q app tests` — PASS
- `node --check app/static/app.js` — PASS

## Local smoke checks

FastAPI TestClient against the packaged application:

- `/api/health` — HTTP 200
- `/api/bootstrap` — HTTP 200
- `/api/tp/interfaces` — HTTP 200
- `/` — HTTP 200

## Important safety properties

- Interface selection comes only from the authoritative Excel Interface Type field.
- The agent cannot add/remove/rename API attributes.
- Blank/null values reduce the completeness score.
- Required missing values can block execution.
- Stage fingerprints the payload/contract.
- Preflight must pass before LIVE.
- LIVE requires runtime enablement + host allowlist + explicit confirmation.
- Bulk LIVE requires `LIVE ALL` and respects the configured concurrency cap.
- Sensitive values are redacted in stored evidence.

## External environment note

A real Dell HIP Create request was intentionally not sent from the release-validation environment. Use the local V130-compatible `.env` credentials and the in-app Agent/API health/smoke controls before enabling LIVE execution.
